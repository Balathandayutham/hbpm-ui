package com.mcafee.mdm.testing.junit;

import java.io.File;
import java.io.StringWriter;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.mcafee.mdm.delegator.ServiceDelegator;
import com.mcafee.mdm.exception.ServiceProcessingException;
import com.mcafee.mdm.generated.MdmUpsertPartyRequest;
import com.mcafee.mdm.generated.MdmUpsertPartyResponse;


@RunWith(SpringJUnit4ClassRunner.class)
public class TestMDMUpsertPartyProfile extends TestM4MBase{
	@Autowired
	private ServiceDelegator serviceDelegator;

	@Test
	public void testMDMUpsertParty() throws ServiceProcessingException,
	JAXBException {
		MdmUpsertPartyRequest request=createRequest();
		assertTrue("serviceDelegator is NULL!!", serviceDelegator != null);
		assertFalse("request is NULL!!", request == null);
		MdmUpsertPartyResponse response=serviceDelegator.mdmUpsertPartyProfile(request);
		assertFalse("response is NULL!!", response == null);
		printObjectTreeInXML(MdmUpsertPartyResponse.class, response);
		
	}
	private MdmUpsertPartyRequest createRequest() throws JAXBException {
		MdmUpsertPartyRequest request = null;
		JAXBContext jaxbContext = JAXBContext
				.newInstance(MdmUpsertPartyRequest.class);
		Unmarshaller jaxbUnMarshaller = jaxbContext.createUnmarshaller();
		File ft=new File(
				"D:\\requestXML\\End_Customer_Account_Request.xml");
		
		System.out.println(ft.isFile());
		request = (MdmUpsertPartyRequest) jaxbUnMarshaller.unmarshal(new File(
				"D:\\requestXML\\End_Customer_Account_Request.xml"));
		return request;
	}
	
	public static void printObjectTreeInXML(Class<?> objectClass, Object classObject) {
        try {
              JAXBContext jaxbContext = JAXBContext.newInstance(objectClass);
              Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
                     jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);

                    StringWriter strWriter = new StringWriter();
                     jaxbMarshaller.marshal(classObject, strWriter);
                     String msgTxt = strWriter.getBuffer().toString();
                     LOG.debug(objectClass.getName() + " object tree :\n" + msgTxt);
        } catch (JAXBException jaxEx) {
              LOG.error("Failed to create JAXBContext/Marshaller for " + objectClass.getName() + ": " + jaxEx);
              jaxEx.printStackTrace();
        } catch (Exception excp) {
              LOG.error("Failed to convert " + objectClass.getName() + " object into XML: " + excp);
              excp.printStackTrace();
        }
    }
}
