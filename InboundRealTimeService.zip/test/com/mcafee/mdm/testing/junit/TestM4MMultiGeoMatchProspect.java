package com.mcafee.mdm.testing.junit;

import java.io.File;
import java.util.List;
import java.util.Map;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.util.CollectionUtils;

import com.mcafee.mdm.dao.SearchProspectPartyDAO;
import com.mcafee.mdm.exception.ServiceProcessingException;
import com.mcafee.mdm.generated.PartyXrefType;
import com.mcafee.mdm.generated.UpsertPartyRequest;
import com.siperian.sif.message.Record;

@RunWith(SpringJUnit4ClassRunner.class)
public class TestM4MMultiGeoMatchProspect extends TestM4MBase {
	@Autowired
	private SearchProspectPartyDAO searchProspectPartyDAO;

	@Test
	public void testMultiGeoMatchFoundMatch()
			throws ServiceProcessingException, JAXBException {
		assertTrue("searchProspectPartyDAO is NULL!!",
				searchProspectPartyDAO != null);
//		PartyXrefType partyXrefType = createRequest(
//				new File(
//						"D:\\McAfee\\Projects\\M4M\\TestXMLs\\UpsertTest_STG_Match.xml"))
//				.getParty().get(0);
		//D:\IntelWorkSpace\TestXMLs
		PartyXrefType partyXrefType = createRequest(
				new File(
						"D:\\IntelWorkSpace\\TestXMLs\\findBestMatchedMultiGeoCityOrSingletonDunsAccount_3Tier.xml"))
				.getParty().get(0);
		
		LOG.info("Calling findBestMatchedMultiGeoCityOrSingletonDunsAccount method for JUnit ");
		Map<String, List<String>> searchRecordList = searchProspectPartyDAO.findBestMatchedMultiGeoCityOrSingletonDunsAccount(partyXrefType);
		Boolean isFound = !CollectionUtils.isEmpty(searchRecordList);
		LOG.debug("isFound::" + isFound);
		assertTrue("isFound is NOT TRUE::"   + isFound, isFound);
	}

	private UpsertPartyRequest createRequest(File file) throws JAXBException {
		UpsertPartyRequest request = null;
		JAXBContext jaxbContext = JAXBContext
				.newInstance(UpsertPartyRequest.class);
		Unmarshaller jaxbUnMarshaller = jaxbContext.createUnmarshaller();
		request = (UpsertPartyRequest) jaxbUnMarshaller.unmarshal(file);
		return request;
	}
}
