package com.mcafee.mdm.testing.junit;

import java.io.File;
import java.sql.SQLException;
import java.util.Properties;

import javax.annotation.Resource;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.mcafee.mdm.dao.TrilliumCleanserDAO;
import com.mcafee.mdm.dao.TrilliumLookUpDAO;
import com.mcafee.mdm.exception.ServiceProcessingException;
import com.mcafee.mdm.generated.PartyXrefType;
import com.mcafee.mdm.generated.SearchPartyRequest;
import com.mcafee.mdm.generated.UpsertPartyRequest;
import com.mcafee.mdm.util.Util;

@RunWith(SpringJUnit4ClassRunner.class)
public class TestAccountTrillium extends TestM4MBase {
	@Autowired
	private TrilliumCleanserDAO trilliumCleanserDAO;
	@Autowired
	private TrilliumLookUpDAO trilliumLookUpDAO;
	
	@Resource(name = "configProp")
	private Properties configProps;

	@Test
	public void testAccountTrillumCall() throws ServiceProcessingException, JAXBException, SQLException {

		String mdmStateCountryArr[] = new String[10];
		boolean setTrilliumValue = false;
		boolean isInTrilliumList = false;

		UpsertPartyRequest request = createRequest();

		for (PartyXrefType curParty : request.getParty()) {
			if (!Util.isNullOrEmpty(curParty.getXREF().get(0).getSRCSYSTEM())) {
				try {
					isInTrilliumList = trilliumLookUpDAO.checkInTrilliumCountryProjectMap(curParty);
					if (isInTrilliumList) {
						LOG.info("Going For TRILLIUM Procedure");
						mdmStateCountryArr = trilliumLookUpDAO.convertSRCToMDMDataUpsert(curParty,
								curParty.getXREF().get(0).getSRCSYSTEM());
						if (!Util.isNullOrEmpty(mdmStateCountryArr[1])) {
							curParty.getAddress().get(0).setSTATECD(mdmStateCountryArr[0]);
						}
						LOG.info("Trillium Call is being made.");
						setTrilliumValue = trilliumCleanserDAO.callTrilliumCleanser(curParty, Boolean.FALSE);
						trilliumLookUpDAO.convertTrilliumToSRCData(setTrilliumValue, curParty,
								curParty.getXREF().get(0).getSRCSYSTEM());
						trilliumLookUpDAO.convertTrilliumToSRCCountry(curParty, curParty.getXREF().get(0).getSRCSYSTEM());
					} else {
						LOG.info("Input Country not within list of 71 Countries, So No TRILLIUM Call.");
					}
				}catch(Exception e) {
					LOG.error("Error in Trillium", e);
				}
			} else {
				LOG.info("BY Passing TRILLIUM Call Since No SRC_SYSTEM");
			}
		}
	}
	
	@Test
	public void testFuzzySearchTrillumCall() throws ServiceProcessingException, JAXBException, SQLException {
		String mdmStateCountryArr[] = new String[10];
		boolean setTrilliumValue = false;
		boolean isInTrilliumList = false;

		SearchPartyRequest request = createRequestSearch();
		boolean reqParamValid = Util.searchRequestValidation(request);
		boolean ismdmStateCdConverted = false;
		try{		
			if(reqParamValid) {
				if (!Util.isNullOrEmpty(request.getPartySearchCriteria().getSRCSYSTEM()))	{
					trilliumLookUpDAO.convertCustGrpToMdmLov(request.getPartySearchCriteria(), request.getPartySearchCriteria().getSRCSYSTEM());
					isInTrilliumList = trilliumLookUpDAO.checkInTrilliumCountryProjectMap(request.getPartySearchCriteria());
					if(isInTrilliumList)	{
						LOG.info("Going For TRILLIUM Procedure");
						mdmStateCountryArr = trilliumLookUpDAO.fetchMDMData(request.getPartySearchCriteria());
						if(Util.isNullOrEmpty(mdmStateCountryArr[1]))	{
							mdmStateCountryArr = trilliumLookUpDAO.convertSRCToMDMDataSearch(request.getPartySearchCriteria(), request.getPartySearchCriteria().getSRCSYSTEM());
						}
						if (!Util.isNullOrEmpty(mdmStateCountryArr[1]))	{
							request.getPartySearchCriteria().setSTATECD(mdmStateCountryArr[0]);
							LOG.info("Trillium Call is being made.");
							setTrilliumValue = trilliumCleanserDAO.callTrilliumCleanser(request.getPartySearchCriteria());
							trilliumLookUpDAO.convertTrilliumToMDMData(setTrilliumValue, request.getPartySearchCriteria());	
							ismdmStateCdConverted = true;
						}
					} else {
						LOG.info("Input Country not within list of 71 Countries, So No TRILLIUM Call.");
						LOG.debug("Converting Input StateCd to MDM StateCd");
						trilliumLookUpDAO.convertTrilliumToMDMData(setTrilliumValue, request.getPartySearchCriteria());
						ismdmStateCdConverted = true;
					}
					
				} else {
					LOG.info("Directly Calling TRILLIUM Cleanser With Source Inputs Since No SRC_SYSTEM");
					isInTrilliumList = trilliumLookUpDAO.checkInTrilliumCountryProjectMap(request.getPartySearchCriteria());
					if(isInTrilliumList)	{	
						LOG.info("Trillium Call is being made.");
						setTrilliumValue = trilliumCleanserDAO.callTrilliumCleanser(request.getPartySearchCriteria());
						trilliumLookUpDAO.convertTrilliumToMDMData(setTrilliumValue, request.getPartySearchCriteria());
						ismdmStateCdConverted = true;
					} else {
						LOG.info("Input Country not within list of 71 Countries, So No TRILLIUM Call.");
						LOG.debug("Converting Input StateCd to MDM StateCd");
						trilliumLookUpDAO.convertTrilliumToMDMData(setTrilliumValue, request.getPartySearchCriteria());
						ismdmStateCdConverted = true;
					}	
				}
			}
		} catch(Exception excp) {
        	LOG.error("Trillim cleanse failed while processing searchPartyProfile Request: " , excp);
        }
		
		if (!ismdmStateCdConverted )	{
			LOG.debug("Converting Input StateCd to MDM StateCd");
			trilliumLookUpDAO.convertTrilliumToMDMData(setTrilliumValue, request.getPartySearchCriteria());
		}
	}


	private UpsertPartyRequest createRequest() throws JAXBException {
		UpsertPartyRequest request = null;
		JAXBContext jaxbContext = JAXBContext.newInstance(UpsertPartyRequest.class);
		Unmarshaller jaxbUnMarshaller = jaxbContext.createUnmarshaller();
		request = (UpsertPartyRequest) jaxbUnMarshaller
				.unmarshal(new File("D:\\McAfee\\Projects\\Scrum\\TestXML\\4-7U8NRS3.xml"));
		return request;
	}
	
	private SearchPartyRequest createRequestSearch() throws JAXBException {
		SearchPartyRequest request = null;
		JAXBContext jaxbContext = JAXBContext.newInstance(SearchPartyRequest.class);
		Unmarshaller jaxbUnMarshaller = jaxbContext.createUnmarshaller();
		request = (SearchPartyRequest) jaxbUnMarshaller
				.unmarshal(new File("D:\\McAfee\\Projects\\Scrum\\TestXML\\4-7U8NRS3-Search.xml"));
		return request;
	}
}
