package com.mcafee.mdm.testing.junit;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.mcafee.mdm.constants.Constant;
import com.mcafee.mdm.dao.AdobeUpsertPartyContactDAO;
import com.mcafee.mdm.delegator.ServiceDelegator;
import com.mcafee.mdm.exception.ServiceProcessingException;
import com.mcafee.mdm.generated.AccountXrefType;
import com.mcafee.mdm.generated.AddressXrefType;
import com.mcafee.mdm.generated.CommunicationXrefType;
import com.mcafee.mdm.generated.MdmUpsertPartyResponse;
import com.mcafee.mdm.generated.PartyPerson;
import com.mcafee.mdm.generated.PartyPersonXrefType;
import com.mcafee.mdm.generated.PartyXrefType;
import com.mcafee.mdm.generated.StatusType;
import com.mcafee.mdm.generated.UpsertPartyRequest;
import com.mcafee.mdm.generated.XREFType;
import com.mcafee.mdm.util.Util;
import com.mcafee.mdm.util.ValidatorUtil;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:com/mcafee/mdm/testing/config/beans.xml" })
public class TestAdobeContactDataValidation extends TestM4MBase  {
	
	@Autowired
	private AdobeUpsertPartyContactDAO adobeUpsertPartyContactDAO;

	@Autowired
	private ValidatorUtil validatorUtil;
	
	//Validate request for null msg tracking id
	@Test
	public void testValidateMsgTrackingIDWithNull() {
		MdmUpsertPartyResponse response = new MdmUpsertPartyResponse();
		PartyXrefType party = new PartyXrefType();
		party.setMSGTRKNID(null);
		XREFType xref = new XREFType();
		xref.setSRCSYSTEM("ADB");
		try {
			validatorUtil.validateMsgTrackingId(party, response,false);
		} catch (ServiceProcessingException e) {
			e.printStackTrace();
		}
		assertEquals(Constant.ERROR_ACCOUNT_MSG_TRKN_ID_VALIDATION, response.getUpsertStatus().getErrorCode());
	}
	
	//Validate request for valid partytype
	@Test
	public void testupsertDataValidationWithValidPartyType() {
		MdmUpsertPartyResponse response = new MdmUpsertPartyResponse();
		PartyXrefType party = new PartyXrefType();
		party.setPARTYTYPE("Person");
		StatusType upsertStatus = new StatusType();
		response.setUpsertStatus(upsertStatus);
		try {
			adobeUpsertPartyContactDAO.upsertDataValidation(party, response, false, false, "0");
		} catch (ServiceProcessingException e) {
			e.printStackTrace();
		}
		System.out.println("actual error code : " + response.getUpsertStatus().getErrorCode());
		System.out.println("expected  error code  : " + Constant.ERROR_ACCOUNT_INVALID_PTY_TYP);
		assertFalse("Valid party type",
				Constant.ERROR_CONTACT_INVALID_PTY_TYP.equals(response.getUpsertStatus().getErrorCode()));
	}
	
	//validate request for invalid party_type
	@Test
	public void testupsertDataValidationWithInvalidPartyType() {
		MdmUpsertPartyResponse response = new MdmUpsertPartyResponse();
		PartyXrefType party = new PartyXrefType();
		party.setPARTYTYPE("Customer");
		StatusType upsertStatus = new StatusType();
		response.setUpsertStatus(upsertStatus);
		try {
			adobeUpsertPartyContactDAO.upsertDataValidation(party, response, false, false, "0");
		} catch (ServiceProcessingException e) {
			e.printStackTrace();
		}
		assertTrue("Invalid party type",
				Constant.ERROR_CONTACT_INVALID_PTY_TYP.equals(response.getUpsertStatus().getErrorCode()));
	}
	
	
		
	
	//validate request with Communication type not having email address
	@Test
	public void testupsertDataValidationWithNullEmail() {
		MdmUpsertPartyResponse response = new MdmUpsertPartyResponse();
		PartyXrefType party = new PartyXrefType();
		party.setPARTYTYPE("Person");
		StatusType upsertStatus = new StatusType();
		response.setUpsertStatus(upsertStatus);
		PartyPersonXrefType person = new PartyPersonXrefType();
		person.setFIRSTNAME("Ferrai");
		person.setLASTNAME("Sony");
		person.setREPORTEDCOMPANYNAME("Verizon");
		party.getPartyPerson().add(person);
		XREFType xref = new XREFType();
		xref.setSRCPKEY("dfj");
		xref.setSRCSYSTEM("ADB");
		party.getXREF().add(xref);
		CommunicationXrefType comm = new CommunicationXrefType();
		comm.setCOMMTYPE("Phone");
		party.getCommunication().add(comm);
		try {
			adobeUpsertPartyContactDAO.upsertDataValidation(party, response, false, false, "0");
		} catch (ServiceProcessingException e) {
			e.printStackTrace();
		}
		assertTrue("Communication type has email address",
				Constant.ERROR_CONTACT_EMPTY_EMAIL_ADDR.equals(response.getUpsertStatus().getErrorCode()));
	}
	
	
	// Check for null reportedname
	@Test
	public void testValidateContactNameWithNULL(){
		PartyXrefType upsertParty = new PartyXrefType();
		XREFType xref = new XREFType();
		xref.setSRCPKEY("001q000000lvgXKAAY");
		upsertParty.getXREF().add(xref);
		upsertParty.setPARTYNAME(null);
		PartyPersonXrefType person = new PartyPersonXrefType();
		person.setFIRSTNAME("Ferrai");
		person.setLASTNAME("Sony");
		person.setREPORTEDCOMPANYNAME(null);
		upsertParty.getPartyPerson().add(person);
		MdmUpsertPartyResponse upsertPartyResponse = new MdmUpsertPartyResponse();
		StatusType statusType = new StatusType();
		upsertPartyResponse.setUpsertStatus(statusType);
		boolean retry = false;
		boolean executeNextStep = false;
		String rowidObject = null;
		try {
			adobeUpsertPartyContactDAO.checkDataQualityUpsert(upsertParty, upsertPartyResponse, retry, executeNextStep, rowidObject);
		} catch (ServiceProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		assertTrue("Contact reported name valid", Constant.ERROR_CONTACT_NAME_UNKWN.equals(upsertPartyResponse.getUpsertStatus().getErrorCode()));
	}
	
	//Check for null addressline1
	@Test
	public void testValidateContactAddressLine1WithNULL(){
		PartyXrefType upsertParty = new PartyXrefType();
		XREFType xref = new XREFType();
		xref.setSRCPKEY("001q000000lvgXKAAY");
		upsertParty.getXREF().add(xref);
		upsertParty.setPARTYNAME("sony Ferrari");
		PartyPersonXrefType person = new PartyPersonXrefType();
		person.setFIRSTNAME("Ferrai");
		person.setLASTNAME("Sony");
		person.setREPORTEDCOMPANYNAME("Verizon");
		upsertParty.getPartyPerson().add(person);
		AddressXrefType address = new AddressXrefType();
		address.setSTATECD("SHANGAI");
		address.setCOUNTRYCD("USA");
		address.setADDRLN1(null);
		upsertParty.getAddress().add(address);
		MdmUpsertPartyResponse upsertPartyResponse = new MdmUpsertPartyResponse();
		StatusType statusType = new StatusType();
		upsertPartyResponse.setUpsertStatus(statusType);
		boolean retry = false;
		boolean executeNextStep = false;
		String rowidObject = null;
		try {
			adobeUpsertPartyContactDAO.checkDataQualityUpsert(upsertParty, upsertPartyResponse, retry, executeNextStep, rowidObject);
		} catch (ServiceProcessingException e) {
			e.printStackTrace();
		}
		assertTrue("Contact address line1 is valid", Constant.ERROR_CONTACT_ADDR_LN1_UNKWN.equals(upsertPartyResponse.getUpsertStatus().getErrorCode()));
	}
	
	//Check for null city
	@Test
	public void testValidateContactCityNULL(){
		PartyXrefType upsertParty = new PartyXrefType();
		XREFType xref = new XREFType();
		xref.setSRCPKEY("001q000000lvgXKAAY");
		upsertParty.getXREF().add(xref);
		upsertParty.setPARTYNAME("sony Ferrari");
		PartyPersonXrefType person = new PartyPersonXrefType();
		person.setFIRSTNAME("Ferrai");
		person.setLASTNAME("Sony");
		person.setREPORTEDCOMPANYNAME("Verizon");
		upsertParty.getPartyPerson().add(person);
		AddressXrefType address = new AddressXrefType();
		address.setSTATECD("New York");
		address.setCOUNTRYCD("USA");
		address.setADDRLN1("Shenzai street");
		address.setCITY(null);
		upsertParty.getAddress().add(address);
		MdmUpsertPartyResponse upsertPartyResponse = new MdmUpsertPartyResponse();
		StatusType statusType = new StatusType();
		upsertPartyResponse.setUpsertStatus(statusType);
		boolean retry = false;
		boolean executeNextStep = false;
		String rowidObject = null;
		try {
			adobeUpsertPartyContactDAO.checkDataQualityUpsert(upsertParty, upsertPartyResponse, retry, executeNextStep, rowidObject);
		} catch (ServiceProcessingException e) {
			e.printStackTrace();
		}
		assertTrue("Contact city is valid", Constant.ERROR_CONTACT_CITY_UNKWN.equals(upsertPartyResponse.getUpsertStatus().getErrorCode()));
	}
	
	//Check for junk city
	@Test
	public void testValidateContactCityJunk(){
		PartyXrefType upsertParty = new PartyXrefType();
		XREFType xref = new XREFType();
		xref.setSRCPKEY("001q000000lvgXKAAY");
		upsertParty.getXREF().add(xref);
		upsertParty.setPARTYNAME("sony Ferrari");
		PartyPersonXrefType person = new PartyPersonXrefType();
		person.setFIRSTNAME("Ferrai");
		person.setLASTNAME("Sony");
		person.setREPORTEDCOMPANYNAME("Verizon");
		upsertParty.getPartyPerson().add(person);
		AddressXrefType address = new AddressXrefType();
		address.setSTATECD("New York");
		address.setCOUNTRYCD("USA");
		address.setADDRLN1("Shenzai street");
		address.setCITY("4001");
		upsertParty.getAddress().add(address);
		MdmUpsertPartyResponse upsertPartyResponse = new MdmUpsertPartyResponse();
		StatusType statusType = new StatusType();
		upsertPartyResponse.setUpsertStatus(statusType);
		boolean retry = false;
		boolean executeNextStep = false;
		String rowidObject = null;
		try {
			adobeUpsertPartyContactDAO.checkDataQualityUpsert(upsertParty, upsertPartyResponse, retry, executeNextStep, rowidObject);
		} catch (ServiceProcessingException e) {
			e.printStackTrace();
		}
		assertTrue("Contact city is not junk", Constant.ERROR_CONTACT_ADDR_INVALID.equals(upsertPartyResponse.getUpsertStatus().getErrorCode()));
	}
	
	//validate request with null fname and lname
	@Test
	public void testRequestWithNullFnameLname() {
		
		PartyXrefType upsertParty = new PartyXrefType();
		XREFType xref = new XREFType();
		xref.setSRCPKEY("001q000000lvgXKAAY");
		upsertParty.getXREF().add(xref);
		upsertParty.setPARTYNAME(null);
		PartyPersonXrefType person = new PartyPersonXrefType();
		person.setFIRSTNAME(null);
		person.setLASTNAME(null);
		person.setREPORTEDCOMPANYNAME("Infortreellis");
		upsertParty.getPartyPerson().add(person);
		MdmUpsertPartyResponse upsertPartyResponse = new MdmUpsertPartyResponse();
		StatusType statusType = new StatusType();
		upsertPartyResponse.setUpsertStatus(statusType);
		boolean retry = false;
		boolean executeNextStep = false;
		String rowidObject = null;
		try {
			adobeUpsertPartyContactDAO.checkDataQualityUpsert(upsertParty, upsertPartyResponse, retry, executeNextStep, rowidObject);
		} catch (ServiceProcessingException e) {
			e.printStackTrace();
		}
		assertTrue("Either fname or lname is present", Constant.ERROR_CONTACT_EMPTY_FNAME_LANME.equals(upsertPartyResponse.getUpsertStatus().getErrorCode()));
	}
	
	//validate request for invalid state and country combo
	@Test
	public void testRequestWithStateCountryMismatch() {
		MdmUpsertPartyResponse response = new MdmUpsertPartyResponse();
		PartyXrefType party = new PartyXrefType();
		party.setPARTYTYPE("Person");
		StatusType upsertStatus = new StatusType();
		response.setUpsertStatus(upsertStatus);
		PartyPersonXrefType person = new PartyPersonXrefType();
		person.setFIRSTNAME("Ferrai");
		person.setLASTNAME("Sony");
		person.setREPORTEDCOMPANYNAME("Verizon");
		party.getPartyPerson().add(person);
		XREFType xref = new XREFType();
		xref.setSRCPKEY("dfj");
		xref.setSRCSYSTEM("ADB");
		party.getXREF().add(xref);
		CommunicationXrefType comm = new CommunicationXrefType();
		comm.setCOMMTYPE("Email");
		comm.setCOMMVALUE("devispr@gmail.com");
		party.getCommunication().add(comm);
		AddressXrefType address = new AddressXrefType();
		address.setSTATECD("SHANGAI");
		address.setCOUNTRYCD("USA");
		address.setADDRLN1("North pole street");
		party.getAddress().add(address);
		try {
			adobeUpsertPartyContactDAO.checkDataQualityUpsert(party, response, false, false, "0");
		} catch (ServiceProcessingException e) {
			e.printStackTrace();
		}
		assertTrue("Valid country state",
				Constant.ERROR_CONTACT_COUNTRY_STATE_MISMATCH.equals(response.getUpsertStatus().getErrorCode()));
	}

		
	//create adobe contact request
	private PartyXrefType createADBContactRequest(String srcPkey,String srcSystem, String partyType, String boclasscode, String partyName, String addressLine1, String addressLine2, String city, String stateCd, String countryCd, String msgTrkId, String statusCd,String ucn) {
		PartyXrefType request = new PartyXrefType();
		request.setLASTUPDATEDATE("28-02-2018 03:00:43");
		request.setSRCCREATEDT("28-02-2018 03:00:43");
		request.setPARTYTYPE(partyType);
		request.setPARTYNAME(partyName);
		request.setSTATUSCD(statusCd);
		request.setBOCLASSCODE(boclasscode);
		request.setMSGTRKNID(msgTrkId);
		request.setUCN(ucn);

		XREFType xref = new XREFType();
		xref.setSRCPKEY(srcPkey);
		xref.setSRCSYSTEM(srcSystem);
		request.getXREF().add(xref);

		AddressXrefType address = new AddressXrefType();
		address.setSRCSYSTEM(srcSystem);
		address.setSRCPKEY(srcPkey);
		address.setADDRLN1(addressLine1);
		address.setADDRLN2(addressLine2);
		address.setADDRLN3(null);
		address.setCITY(city);
		address.setSTATECD(stateCd);
		address.setCOUNTRYCD(countryCd);
		address.setADDRSTATUS(statusCd);
		address.setADDRTYPE("Mailing");
		request.getAddress().add(address);

		PartyPersonXrefType partyPerson = new PartyPersonXrefType();
		partyPerson.setSRCPKEY(srcPkey);
		partyPerson.setSRCSYSTEM(srcSystem);
		partyPerson.setREPORTEDCOMPANYNAME("ADM Cop Ltd");
		partyPerson.setFIRSTNAME("Blake");
		partyPerson.setLASTNAME("Smith");
		partyPerson.setJOBLEVEL("C-Level");
		partyPerson.setJOBROLE("IT - Network / Security");
		partyPerson.setJOBTITLE("Chief Information Security Ofr");
		partyPerson.setPREFLANGUAGE("English - American");
		partyPerson.setPERSONSTATUS("A");
		partyPerson.setPERSONTYPE("Person");
		request.getPartyPerson().add(partyPerson);
		
		CommunicationXrefType commXrefType = new CommunicationXrefType();
		commXrefType.setSRCPKEY(srcPkey);
		commXrefType.setSRCSYSTEM(srcSystem);
		commXrefType.setCOMMTYPE("Email");
		commXrefType.setCOMMVALUE("blake.smith@asi-securitypartners.com");
		commXrefType.setCOMMSTATUS(statusCd);
		request.getCommunication().add(commXrefType);
		
		CommunicationXrefType commXrefTypePhone = new CommunicationXrefType();
		commXrefTypePhone.setSRCPKEY(srcPkey);
		commXrefTypePhone.setSRCSYSTEM(srcSystem);
		commXrefTypePhone.setCOMMTYPE("Phone");
		commXrefTypePhone.setCOMMVALUE("9876987654");
		commXrefTypePhone.setCOMMSTATUS(statusCd);
		request.getCommunication().add(commXrefTypePhone);

		return request;
	}
}
