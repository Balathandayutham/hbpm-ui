package com.mcafee.mdm.testing.junit;

import java.util.HashMap;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.mcafee.mdm.dao.GetPartyDAO;
import com.mcafee.mdm.dao.UpsertMarketingDAO;
import com.mcafee.mdm.dao.UpsertPartyDAO;
import com.mcafee.mdm.dao.pojo.HighestScoreRecordHolder;
import com.mcafee.mdm.generated.PartyType;
import com.mcafee.mdm.generated.PartyXrefType;
import com.mcafee.mdm.generated.UpsertPartyResponse;
import com.mcafee.mdm.generated.XREFType;
import com.siperian.sif.client.SiperianClient;

@RunWith(SpringJUnit4ClassRunner.class)
public class TestMatchMergeReprocess extends TestM4MBase{
	@Autowired
	private UpsertMarketingDAO upsertMarketingDao;
	@Autowired
	private UpsertPartyDAO upsertPartyDao;
	@Autowired
	private GetPartyDAO getPartyDAO;
//	@Autowired
//	private UpsertPartyResponse upsertResponse;
	
	
	@Test
	public void testprocessMatchAndMerge() throws Exception {
//		assertTrue("upsertResponse is NULL!!", upsertResponse != null);
		assertTrue("upsertPartyDao is NULL!!", upsertPartyDao != null);
		UpsertPartyResponse upsertResponse = new UpsertPartyResponse();
	//	SiperianClient siperianClient = (SiperianClient) upsertPartyDao.checkOut();
		
		PartyType survivingPartyProfileFromBO = new PartyType();
		survivingPartyProfileFromBO = getPartyDAO.getBOParty("18972479");
		upsertPartyDao.mergeProcessMultipleChild(survivingPartyProfileFromBO, null);
		
	//	UpsertPartyResponse upsertResponse = new UpsertPartyResponse();
		//+ "\nError Message::"	+ upsertResponse.getParty().get(0).getErrorMsg());
	//	assertFalse("isValid::" + isValid, isValid);
	//	assertTrue("Incorrect Error Message::"+ upsertResponse.getParty().get(0).getErrorMsg(),"SRC Pkey not found for account with UCN".equals(upsertResponse.getParty().get(0).getErrorMsg()));
	}
}
