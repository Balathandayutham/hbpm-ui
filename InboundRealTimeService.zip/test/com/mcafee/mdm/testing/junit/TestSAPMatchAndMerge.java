package com.mcafee.mdm.testing.junit;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.Random;

import javax.transaction.UserTransaction;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.mcafee.mdm.constants.Constant;
import com.mcafee.mdm.dao.FNOUpsertPartyDAO;
import com.mcafee.mdm.dao.GetPartyDAO;
import com.mcafee.mdm.dao.SAPUpsertPartyDAO;
import com.mcafee.mdm.dao.SearchPartyDAO;
import com.mcafee.mdm.exception.ServiceProcessingException;
import com.mcafee.mdm.generated.AccountXrefType;
import com.mcafee.mdm.generated.AddressXrefType;
import com.mcafee.mdm.generated.CommunicationXrefType;
import com.mcafee.mdm.generated.MdmUpsertPartyResponse;
import com.mcafee.mdm.generated.PartyXrefType;
import com.mcafee.mdm.generated.StatusType;
import com.mcafee.mdm.generated.XREFType;
import com.siperian.sif.client.EjbSiperianClient;
import com.siperian.sif.client.SiperianClient;

public class TestSAPMatchAndMerge extends TestM4MBase {
	
	@Autowired
	SAPUpsertPartyDAO sapUpsertPartyDAO;
	@Autowired
	private FNOUpsertPartyDAO fnoUpsertPartyDao;
	@Autowired
	private GetPartyDAO getPartyDAO;
	@Autowired
	private SearchPartyDAO searchPartyDAO;
	@Test
	public void testSAPCustomerSearchMatch() throws Exception{
		//Creating FNO data 39237466
		MdmUpsertPartyResponse upsertPartyResponse1 = new MdmUpsertPartyResponse();
		upsertPartyResponse1.setUpsertStatus(new StatusType());
		String rowid_object = null;
		PartyXrefType request=createRequest("fno6000sap","Customer","Jerry Macron","Loyd Street","Silicon Valley");
		fnoUpsertPartyDao.processCleansePutRequest(request, upsertPartyResponse1, false, false, null);
		fnoUpsertPartyDao.upsertTokenize(request, upsertPartyResponse1, false, false, null);
		fnoUpsertPartyDao.upsertUCNStampProcess(request, upsertPartyResponse1, false, false, null);
		PartyXrefType partyXrefType = new PartyXrefType();
		PartyXrefType insertedPartyData = new PartyXrefType();
		MdmUpsertPartyResponse upsertPartyResponse = new MdmUpsertPartyResponse();
		
		// Testing rule No. 2
		System.out.println("TESTING MATCH RULE 1 Customer Deduplication RuleSet");
		System.out.println("===============================================================================================================================================================");
		partyXrefType = createSAPRequest("account704SAP","SAP","Customer","Organization","Jerry Macron","Loyd Street","Silicon Valley","Roswell","NM","US","678457","Active","11295436341", "Caroline_Irvy@asi-securitypartners.com");
		try {
			sapUpsertPartyDAO.processCleansePutRequest(partyXrefType, upsertPartyResponse, false, false, "0");
			sapUpsertPartyDAO.upsertTokenize(partyXrefType, upsertPartyResponse, false, false, null);
		//	rowid_object = searchPartyDAO.getPartyRowidObject(partyXrefType.getXREF().get(0).getSRCPKEY(), partyXrefType.getXREF().get(0).getSRCSYSTEM());
		//	sapUpsertPartyDAO.upsertUCNStampProcess(partyXrefType, upsertPartyResponse, false, false, rowid_object);
			insertedPartyData = getPartyDAO.fetchPartyXrefTypeFromORS("SAP","account704SAP");
		} catch (ServiceProcessingException e1) {
			e1.printStackTrace();
		}
		SiperianClient siperianClient = null;
		UserTransaction transaction = null;
		siperianClient = sapUpsertPartyDAO.checkOut();
		System.out.println("sipserian client : " + siperianClient);
		transaction = ((EjbSiperianClient) siperianClient).createTX(300000);
		transaction.begin();
		System.out.println("transaction began");
		Method method = null;
		try {
			method = sapUpsertPartyDAO.getClass().getDeclaredMethod("matchParty", PartyXrefType.class, SiperianClient.class);
		} catch (NoSuchMethodException | SecurityException e) {
			e.printStackTrace();
		}
		method.setAccessible(true);
		List searchRecords = null;
		try {
			searchRecords = (List) method.invoke(sapUpsertPartyDAO, insertedPartyData, siperianClient);
		} catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
			e.printStackTrace();
		}
		int size = searchRecords.size();
		assertTrue("true", (size>=1));
		System.out.println("completed : " + searchRecords.size());
	}
	
	@Test
	public void testResellerMatch() throws Exception{
		//Creating FNO data 39277422 UCN: 112958466430
		MdmUpsertPartyResponse upsertPartyResponse1 = new MdmUpsertPartyResponse();
		upsertPartyResponse1.setUpsertStatus(new StatusType());
		PartyXrefType request=createRequest("fno6001sap","Reseller","Akansha Pandey","Jerome Street","Second Lane");
		fnoUpsertPartyDao.processCleansePutRequest(request, upsertPartyResponse1, false, false, null);
		fnoUpsertPartyDao.upsertTokenize(request, upsertPartyResponse1, false, false, null);
		fnoUpsertPartyDao.upsertUCNStampProcess(request, upsertPartyResponse1, false, false, null);
		PartyXrefType partyXrefType = new PartyXrefType();
		PartyXrefType insertedPartyData = new PartyXrefType();
		MdmUpsertPartyResponse upsertPartyResponse = new MdmUpsertPartyResponse();
		String rowid_object = null;
		// Testing rule No. 1
		System.out.println("TESTING rule No. 1. MATCH RULE Set 'Party Deduplication Match Rule Set'");
		System.out.println("===============================================================================================================================================================");
		partyXrefType = createSAPRequest("account803SAP","SAP","Reseller","Organization","Delick","Delick Street","Delick Lane","Roswell","NM","US","678457","Active","11295436341", "Caroline_Irvy@asi-securitypartners.com");
		partyXrefType.setUCN("112958466430");
		//callMatchRule(partyXrefType);
		partyXrefType = new PartyXrefType();
		insertedPartyData = new PartyXrefType();
		upsertPartyResponse = new MdmUpsertPartyResponse();
		System.out.println("===============================================================================================================================================================");
		// Testing rule No. 2
		System.out.println("TESTING rule No. 2. MATCH RULE Set 'Party Deduplication Match Rule Set'");
		System.out.println("===============================================================================================================================================================");
		partyXrefType = createSAPRequest("account804SAP","SAP","Reseller","Organization","Akansha Pandey","Jerome Street","Second Lane","Roswell","New Mexico","US","678457","Active","11295436341", "Caroline_Irvy@asi-securitypartners.com");
		callMatchRule(partyXrefType);
		partyXrefType = new PartyXrefType();
		insertedPartyData = new PartyXrefType();
		upsertPartyResponse = new MdmUpsertPartyResponse();
		System.out.println("===============================================================================================================================================================");
		// Testing rule No. 3
		System.out.println("TESTING rule No. 3. MATCH RULE Set 'Party Deduplication Match Rule Set'");
		System.out.println("===============================================================================================================================================================");
		partyXrefType = createSAPRequest("account805SAP","SAP","Reseller","Organization","Akansha Pandey ","Jerome Street","Second Lane","Roswell","New Mexico","US","678457","Active","11295436341", "Caroline_Irvy@asi-securitypartners.com");
		callMatchRule(partyXrefType);
		partyXrefType = new PartyXrefType();
		insertedPartyData = new PartyXrefType();
		upsertPartyResponse = new MdmUpsertPartyResponse();
		System.out.println("===============================================================================================================================================================");
		// Testing rule No. 4
		System.out.println("TESTING rule No. 4. MATCH RULE Set 'Party Deduplication Match Rule Set'");
		System.out.println("===============================================================================================================================================================");
		partyXrefType = createSAPRequest("account806SAP","SAP","Reseller","Organization","Akansha","Jerome St","Second Lane","Roswell","New Mexico","US","678457","Active","11295436341", "Caroline_Irvy@asi-securitypartners.com");
		callMatchRule(partyXrefType);
		partyXrefType = new PartyXrefType();
		insertedPartyData = new PartyXrefType();
		upsertPartyResponse = new MdmUpsertPartyResponse();
		System.out.println("===============================================================================================================================================================");
		// Testing rule No. 5
		System.out.println("TESTING rule No. 5. MATCH RULE Set 'Party Deduplication Match Rule Set'");
		System.out.println("===============================================================================================================================================================");
		partyXrefType = createSAPRequest("account807SAP","SAP","Reseller","Organization","Akansha Pandey","Jerome Street","Second Lane","Roswell","Texas","US","678457","Active","11295436341", "Caroline_Irvy@asi-securitypartners.com");
		callMatchRule(partyXrefType);
		partyXrefType = new PartyXrefType();
		insertedPartyData = new PartyXrefType();
		upsertPartyResponse = new MdmUpsertPartyResponse();
		System.out.println("===============================================================================================================================================================");
		// Testing rule No. 6
		System.out.println("TESTING rule No. 6. MATCH RULE Set 'Party Deduplication Match Rule Set'");
		System.out.println("===============================================================================================================================================================");
		partyXrefType = createSAPRequest("account808SAP","SAP","Reseller","Organization","Akansha Pandey","Jerome St","Second Lane","Roswell","NM","US","678457","Active","11295436341", "Caroline_Irvy@asi-securitypartners.com");
		callMatchRule(partyXrefType);
		System.out.println("===============================================================================================================================================================");

	}
	
	private void callMatchRule(PartyXrefType insertedPartyData) throws Exception{
		SiperianClient siperianClient = null;
		UserTransaction transaction = null;
		siperianClient = sapUpsertPartyDAO.checkOut();
		System.out.println("sipserian client : " + siperianClient);
		transaction = ((EjbSiperianClient) siperianClient).createTX(300000);
		transaction.begin();
		System.out.println("transaction began");
		Method method = null;
		try {
			method = sapUpsertPartyDAO.getClass().getDeclaredMethod("matchParty", PartyXrefType.class, SiperianClient.class);
		} catch (NoSuchMethodException | SecurityException e) {
			e.printStackTrace();
		}
		method.setAccessible(true);
		List searchRecords = null;
		try {
			searchRecords = (List) method.invoke(sapUpsertPartyDAO, insertedPartyData, siperianClient);
		} catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
			e.printStackTrace();
		}
		int size = 0;
		if(searchRecords != null){ 
		size = searchRecords.size();
		}else{
			System.out.println("No searched records found");
		}
		assertTrue("true", (size >= 1));
		System.out.println("completed : " + searchRecords.size());
		transaction.commit();
		
	}
	
	@Test
	public void testSAPMerge(){
		PartyXrefType partyXrefType = null;
		MdmUpsertPartyResponse upsertPartyResponse = new MdmUpsertPartyResponse();
		PartyXrefType insertedPartyData = new PartyXrefType();
		String rowid_object = null;
		System.out.println("TESTING MERGE OPERATION with 39277458");
		System.out.println("===============================================================================================================================================================");
		partyXrefType = createSAPRequest("account901SAP","SAP","Customer","Organization","Anudeep Durushetty","Haluvai Street","Third Lane","Roswell","NM","US","678457","Active","11299856341", "Roswell@asi-securitypartners.com");
		try {
			sapUpsertPartyDAO.processCleansePutRequest(partyXrefType, upsertPartyResponse, false, false, "0");
			sapUpsertPartyDAO.upsertTokenize(partyXrefType, upsertPartyResponse, false, false, null);
			rowid_object = searchPartyDAO.getPartyRowidObject(partyXrefType.getXREF().get(0).getSRCPKEY(), partyXrefType.getXREF().get(0).getSRCSYSTEM());
			sapUpsertPartyDAO.upsertUCNStampProcess(partyXrefType, upsertPartyResponse, false, false, null);
			insertedPartyData = getPartyDAO.fetchPartyXrefTypeFromORS("SAP","account901SAP");
		} catch (ServiceProcessingException e1) {
			e1.printStackTrace();
		}
		System.out.println("Rowid object 1 : " + rowid_object);
		//Inserting second record for merge process
		PartyXrefType partyXrefType1 = null;
		MdmUpsertPartyResponse upsertPartyResponse1 = new MdmUpsertPartyResponse();
		StatusType statusType = new StatusType();
		upsertPartyResponse1.setUpsertStatus(statusType);
		Random random = new Random();
		int rand_num = random.nextInt(9999);
		String rowid_object2 = null;
		System.out.println("Random number genrated :"+rand_num+":");
		partyXrefType1 = createSAPRequest("account"+rand_num+"SAP","SAP","Customer","Organization","Anudeep Durushetty","Haluvai Street","Third Lane","Roswell","NM","US","678457","Active","11299856341", "Roswell@asi-securitypartners.com");
		try {
			sapUpsertPartyDAO.processCleansePutRequest(partyXrefType1, upsertPartyResponse1, false, false, "0");
			rowid_object2 = searchPartyDAO.getPartyRowidObject(partyXrefType1.getXREF().get(0).getSRCPKEY(), partyXrefType1.getXREF().get(0).getSRCSYSTEM());
			sapUpsertPartyDAO.upsertTokenize(partyXrefType1, upsertPartyResponse1, false, false, null);
			sapUpsertPartyDAO.upsertMatchMergeProcess(partyXrefType1, upsertPartyResponse1, false, false, null);
		} catch (ServiceProcessingException e) {
			e.printStackTrace();
		}
		System.out.println("Rowid object 1 : " + rowid_object2);
		assertFalse("Merge failed", Constant.ERROR_ACC_MERGE_FAIL.equals(upsertPartyResponse1.getUpsertStatus().getErrorCode()));
		System.out.println("===============================================================================================================================================================");
	}
	
	@Test
	public void testSAPLegacyIDMerge(){
		System.out.println("TESTING legacy MERGE OPERATION  with Seibel rowid :5-1Y4PK90");
		System.out.println("===============================================================================================================================================================");
		PartyXrefType partyXrefType = null;
		MdmUpsertPartyResponse upsertPartyResponse = new MdmUpsertPartyResponse();
		StatusType statusType = new StatusType();
		upsertPartyResponse.setUpsertStatus(statusType);
		PartyXrefType insertedPartyData = new PartyXrefType();
		String rowid_object = null;
		PartyXrefType partyXrefType1 = null;
		MdmUpsertPartyResponse upsertPartyResponse1 = new MdmUpsertPartyResponse();
		StatusType statusType1 = new StatusType();
		upsertPartyResponse1.setUpsertStatus(statusType1);
		Random random = new Random();
		int rand_num = random.nextInt(9999);
		System.out.println("Random number genrated :"+rand_num+":");
		partyXrefType1 = createSAPRequest("account4521SAP","SAP","Customer","Organization","Deriyl","Deriyl Street","Deriyl Lane","Roswell","NM","US","678457","X","11299898341", "5-1Y4PK90");
		try {
			sapUpsertPartyDAO.processCleansePutRequest(partyXrefType1, upsertPartyResponse1, false, false, "0");
			sapUpsertPartyDAO.upsertTokenize(partyXrefType1, upsertPartyResponse1, false, false, null);
			rowid_object = searchPartyDAO.getPartyRowidObject(partyXrefType1.getXREF().get(0).getSRCPKEY(), partyXrefType1.getXREF().get(0).getSRCSYSTEM());
			sapUpsertPartyDAO.upsertUCNStampProcess(partyXrefType1, upsertPartyResponse1, false, false, null);
		} catch (ServiceProcessingException e1) {
			e1.printStackTrace();
		}
		System.out.println("Rowid object 1 : " + rowid_object);
		
		System.out.println("TESTING legacy MERGE OPERATION ");
		System.out.println("===============================================================================================================================================================");
		rand_num = random.nextInt(9999);
		String rowid_object2 = null;
		System.out.println("Random number genrated :"+rand_num+":");
		partyXrefType = createSAPRequest("account"+rand_num+"SAP","SAP","Customer","Organization","Cisco Inc","Cisco Street","Cisco Lane","Roswell","NM","US","678457","X","11288776341", "5-1Y4PK90");
		try {
			sapUpsertPartyDAO.processCleansePutRequest(partyXrefType, upsertPartyResponse, false, false, "0");
			sapUpsertPartyDAO.upsertTokenize(partyXrefType, upsertPartyResponse, false, false, null);
			sapUpsertPartyDAO.upsertMatchMergeProcess(partyXrefType, upsertPartyResponse, false, false, null);
			rowid_object2 = searchPartyDAO.getPartyRowidObject(partyXrefType.getXREF().get(0).getSRCPKEY(), partyXrefType.getXREF().get(0).getSRCSYSTEM());
		} catch (ServiceProcessingException e1) {
			e1.printStackTrace();
		}
		System.out.println("Rowid object 2 : " + rowid_object2);
		assertEquals(rowid_object.trim(), rowid_object2.trim());
		assertFalse("Merge failed", Constant.ERROR_ACC_MERGE_FAIL.equals(upsertPartyResponse.getUpsertStatus().getErrorCode()));
		System.out.println("===============================================================================================================================================================");
	}
	
	private PartyXrefType createSAPRequest(String srcPkey,String srcSystem, String partyType, String boclasscode, String partyName, String addressLine1, String addressLine2, String city, String stateCd, String countryCd, String msgTrkId, String statusCd,String ucn, String seibel_rowid){
		PartyXrefType request = new PartyXrefType();

		request.setLASTUPDATEDATE("28-02-2018 03:00:43");
		request.setSRCCREATEDT("28-02-2018 03:00:43");
		request.setUPDATEBY("admin");
		request.setPARTYTYPE(partyType);
		request.setPARTYNAME(partyName);
		request.setSTATUSCD(statusCd);
		request.setBOCLASSCODE(boclasscode);
		request.setMSGTRKNID(msgTrkId);

		XREFType xref = new XREFType();
		xref.setSRCPKEY(srcPkey);
		xref.setSRCSYSTEM(srcSystem);
		request.getXREF().add(xref);

		AddressXrefType address = new AddressXrefType();
		address.setSRCPKEY(srcPkey);
		address.setSRCSYSTEM(srcSystem);
		address.setADDRLN1(addressLine1);
		address.setADDRLN2(addressLine2);
		address.setADDRLN3(null);
		address.setCITY(city);
		address.setSTATECD(stateCd);
		address.setCOUNTRYCD(countryCd);
		address.setADDRSTATUS(statusCd);
		request.getAddress().add(address);

		AccountXrefType acc = new AccountXrefType();
		acc.setSRCPKEY(srcPkey);
		acc.setSRCSYSTEM(srcSystem);
		acc.setACCTNAME(partyName);
		acc.setACCTSTATUS(statusCd);
		acc.setCUSTGROUP("Payer");
		acc.setDATASRCSYSTEM(srcSystem);
		acc.setMDMLEGACYID(null);
		acc.setSIEBELROWID(seibel_rowid);
		request.getAccount().add(acc);

		CommunicationXrefType commXrefTypePhone = new CommunicationXrefType();
		commXrefTypePhone.setSRCPKEY(srcPkey);
		commXrefTypePhone.setSRCSYSTEM(srcSystem);
		commXrefTypePhone.setCOMMTYPE("Fax");
		commXrefTypePhone.setCOMMVALUE("9876987654");
		commXrefTypePhone.setCOMMSTATUS(statusCd);
		request.getCommunication().add(commXrefTypePhone);
		
		return request;
	}
	
	private PartyXrefType createRequest(String srcPkey, String partyType, String partyName, String addrLn1, String addrLn2) {
		PartyXrefType request = new PartyXrefType();

		request.setLASTUPDATEDATE("28-02-2018 03:00:43");
		request.setSRCCREATEDT("28-02-2018 03:00:43");
		request.setUPDATEBY("admin");
		request.setPARTYTYPE(partyType);
		request.setPARTYNAME(partyName);
		request.setSTATUSCD("Active");
		request.setBOCLASSCODE("Organization");
		request.setMSGTRKNID("893573");

		XREFType xref = new XREFType();
		xref.setSRCPKEY(srcPkey);
		xref.setSRCSYSTEM("FNO");
		request.getXREF().add(xref);

		AddressXrefType address = new AddressXrefType();
		address.setSRCPKEY(srcPkey);
		address.setSRCSYSTEM("FNO");
		address.setADDRLN1(addrLn1);
		address.setADDRLN2(addrLn2);
		address.setADDRLN3("");
		address.setCITY("Roswell");
		address.setSTATECD("New Mexico");
		address.setCOUNTRYCD("US");
		address.setADDRSTATUS("Active");
		request.getAddress().add(address);

		AccountXrefType acc = new AccountXrefType();
		acc.setSRCPKEY(srcPkey);
		acc.setSRCSYSTEM("FNO");
		acc.setACCTNAME(partyName);
		acc.setACCTSTATUS("Active");
		acc.setCUSTGROUP("Payer");
		acc.setDATASRCSYSTEM("FNO");
		request.getAccount().add(acc);

		return request;
	}
}
