package com.mcafee.mdm.testing.junit;

import java.util.HashMap;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.mcafee.mdm.dao.ProspectPartyDAO;
import com.mcafee.mdm.dao.UpsertMarketingDAO;
import com.mcafee.mdm.dao.pojo.HighestScoreRecordHolder;
import com.mcafee.mdm.generated.PartyXrefType;
import com.mcafee.mdm.generated.XREFType;
import com.siperian.sif.client.SiperianClient;

@RunWith(SpringJUnit4ClassRunner.class)
public class TestM4MEmailByContactPkey extends TestM4MBase{
	@Autowired
	private ProspectPartyDAO prospectPartyDAO;
	
	@Test
	public void testgetContactEmailByContactPkey() throws Exception {
		assertTrue("prospectPartyDAO is NULL!!", prospectPartyDAO != null);
		List<String> commPkeyEmlList = prospectPartyDAO.getContactEmailByContactPkey("CMAFS000000000036");//CMAFS000000000034
	//	LOG.debug("Email Value is-->" + emlValue );//+ "\nError Message::"	+ upsertResponse.getParty().get(0).getErrorMsg());
	//	assertFalse("isValid::" + isValid, isValid);
	//	assertTrue("Incorrect Error Message::"+ upsertResponse.getParty().get(0).getErrorMsg(),"SRC Pkey not found for account with UCN".equals(upsertResponse.getParty().get(0).getErrorMsg()));
	}
}
