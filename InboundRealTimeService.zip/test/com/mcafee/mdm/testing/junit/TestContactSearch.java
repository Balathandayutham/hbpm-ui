package com.mcafee.mdm.testing.junit;

import java.util.List;

import javax.xml.bind.JAXBException;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.mcafee.mdm.delegator.ServiceDelegator;
import com.mcafee.mdm.exception.ServiceProcessingException;
import com.mcafee.mdm.generated.ContactProfileType;
import com.mcafee.mdm.generated.ContactSearchCriteriaType;
import com.mcafee.mdm.generated.ContactType;
import com.mcafee.mdm.generated.SearchContactRequest;
import com.mcafee.mdm.generated.SearchContactResponse;


@RunWith(SpringJUnit4ClassRunner.class)
public class TestContactSearch extends TestM4MBase{
	
	@Autowired
	private ServiceDelegator serviceDelegator;
	
	@Test
	public void testContactSearch() throws ServiceProcessingException,
			JAXBException {
		
		SearchContactRequest request= new SearchContactRequest();
		ContactSearchCriteriaType contactSearchCriteriaType= new ContactSearchCriteriaType();
		contactSearchCriteriaType.setEMAILADDRESS("003o000000vkdidaaq@example.com");
		request.setContactSearchCriteria(contactSearchCriteriaType);
		assertTrue("serviceDelegator is NULL!!", serviceDelegator != null);
		SearchContactResponse res= serviceDelegator.searchContact(request);
		ContactProfileType cPT=res.getContactProfiles();
		List<ContactType> cList= cPT.getContact();
		for(ContactType c:cList){
			System.out.println(c.getFIRSTNAME());
			System.out.println(c.getLASTNAME());
			System.out.println(c.getACCOUNTNAME());
			System.out.println(c.getACCOUNTUCN());
			System.out.println(c.getMDMCONTACTID());
			System.out.println(c.getEMAILADDRESS());
		}
		
		
	}

}
