package com.mcafee.mdm.testing.junit;

import java.util.Properties;

import javax.annotation.Resource;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.mcafee.mdm.dao.MergeProspectPartyDAO;
import com.mcafee.mdm.exception.ServiceProcessingException;
import com.siperian.sif.message.mrm.UnmergeResponse;

@RunWith(SpringJUnit4ClassRunner.class)
public class TestM4MUnMergeProspect extends TestM4MBase {
	@Autowired
	private MergeProspectPartyDAO mergeProspectPartyDAO;
	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Resource(name = "m4mQueryProp")
	private Properties queryProp;

	@Test
	public void testUnmergeProspectParties() throws ServiceProcessingException {
		assertTrue("mergeProspectPartyDAO is NULL!!",
				mergeProspectPartyDAO != null);
		UnmergeResponse response = mergeProspectPartyDAO
				.unMergeProspectParties("PROSPECT-CMAFP000002034579", "ELQ");
		assertFalse("UnMerge Response is NULL", response == null);
		assertFalse("Unmerge Record Key is NULL", response.getRecordKey() == null);
		LOG.debug("Unmerge Record Src Key::" + response.getRecordKey().getSourceKey());
		LOG.debug("Unmerge Record RowID::" + response.getRecordKey().getRowid());
	}
	
	@Test
	public void testUnmergeRootProspectParties() throws ServiceProcessingException {
		assertTrue("mergeProspectPartyDAO is NULL!!",
				mergeProspectPartyDAO != null);
		UnmergeResponse response = mergeProspectPartyDAO
				.unMergeProspectParties("PROSPECT-CMAFP000002457631", "ELQ");
		assertFalse("UnMerge Response is NULL", response == null);
		assertFalse("Unmerge Record Key is NULL", response.getRecordKey() == null);
		LOG.debug("Unmerge Record Src Key::" + response.getRecordKey().getSourceKey());
		LOG.debug("Unmerge Record RowID::" + response.getRecordKey().getRowid());
	}
}
