package com.mcafee.mdm.testing.junit;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.mcafee.mdm.dao.UpsertMarketingDAO;
import com.mcafee.mdm.generated.AddressXrefType;
import com.mcafee.mdm.generated.PartyXrefType;
import com.mcafee.mdm.generated.UpsertPartyResponse;
import com.mcafee.mdm.generated.XREFType;

@RunWith(SpringJUnit4ClassRunner.class)
public class TestM4MValidateAccount extends TestM4MBase {
	@Autowired
	private UpsertMarketingDAO upsertMarketingDao;
	
	@Test
	public void testValidateAccountUCNWithoutPkey() {
		assertTrue("upsertMarketingDao is NULL!!", upsertMarketingDao != null);
		PartyXrefType partyXrefType = new PartyXrefType();
		partyXrefType.getXREF().add(new XREFType());
		partyXrefType.setUCN("TestUCN");
		UpsertPartyResponse upsertResponse = new UpsertPartyResponse();
		Boolean isValid = upsertMarketingDao.validateAccountRequest(
				partyXrefType, upsertResponse);
		LOG.debug("isValid::" + isValid + "\nError Message::"
				+ upsertResponse.getParty().get(0).getErrorMsg());
		assertFalse("isValid::" + isValid, isValid);
		assertTrue(
				"Incorrect Error Message::"
						+ upsertResponse.getParty().get(0).getErrorMsg(),
				"SRC Pkey not found for account with UCN".equals(upsertResponse.getParty()
						.get(0).getErrorMsg()));
	}

	@Test
	public void testValidateAccountNoName() {
		assertTrue("upsertMarketingDao is NULL!!", upsertMarketingDao != null);
		PartyXrefType partyXrefType = new PartyXrefType();
		partyXrefType.getXREF().add(new XREFType());
		UpsertPartyResponse upsertResponse = new UpsertPartyResponse();
		Boolean isValid = upsertMarketingDao.validateAccountRequest(
				partyXrefType, upsertResponse);
		LOG.debug("isValid::" + isValid + "\nError Message::"
				+ upsertResponse.getParty().get(0).getErrorMsg());
		assertFalse("isValid::" + isValid, isValid);
		assertTrue(
				"Incorrect Error Message::"
						+ upsertResponse.getParty().get(0).getErrorMsg(),
				"Account name not found".equals(upsertResponse.getParty()
						.get(0).getErrorMsg()));
	}

	@Test
	public void testValidateAccountNoAddress() {
		assertTrue("upsertMarketingDao is NULL!!", upsertMarketingDao != null);
		PartyXrefType partyXrefType = new PartyXrefType();
		partyXrefType.getXREF().add(new XREFType());
		partyXrefType.setPARTYNAME("Test");
		UpsertPartyResponse upsertResponse = new UpsertPartyResponse();
		Boolean isValid = upsertMarketingDao.validateAccountRequest(
				partyXrefType, upsertResponse);
		LOG.debug("isValid::" + isValid + "\nError Message::"
				+ upsertResponse.getParty().get(0).getErrorMsg());
		assertFalse("isValid::" + isValid, isValid);
		assertTrue(
				"Incorrect Error Message::"
						+ upsertResponse.getParty().get(0).getErrorMsg(),
				"Address / Country not found".equals(upsertResponse.getParty()
						.get(0).getErrorMsg()));
	}
	
	@Test
	public void testValidateAccountNoCountry() {
		assertTrue("upsertMarketingDao is NULL!!", upsertMarketingDao != null);
		PartyXrefType partyXrefType = new PartyXrefType();
		partyXrefType.getXREF().add(new XREFType());
		partyXrefType.setPARTYNAME("Test");
		partyXrefType.getAddress().add(new AddressXrefType());
		UpsertPartyResponse upsertResponse = new UpsertPartyResponse();
		Boolean isValid = upsertMarketingDao.validateAccountRequest(
				partyXrefType, upsertResponse);
		LOG.debug("isValid::" + isValid + "\nError Message::"
				+ upsertResponse.getParty().get(0).getErrorMsg());
		assertFalse("isValid::" + isValid, isValid);
		assertTrue(
				"Incorrect Error Message::"
						+ upsertResponse.getParty().get(0).getErrorMsg(),
				"Address / Country not found".equals(upsertResponse.getParty()
						.get(0).getErrorMsg()));
	}
	
	@Test
	public void testValidateAccountValidWithoutUCN() {
		assertTrue("upsertMarketingDao is NULL!!", upsertMarketingDao != null);
		PartyXrefType partyXrefType = new PartyXrefType();
		AddressXrefType addr = new AddressXrefType();
		addr.setCOUNTRYCD("US");
		partyXrefType.getXREF().add(new XREFType());
		partyXrefType.setPARTYNAME("Test");
		partyXrefType.getAddress().add(addr);
		UpsertPartyResponse upsertResponse = new UpsertPartyResponse();
		Boolean isValid = upsertMarketingDao.validateAccountRequest(
				partyXrefType, upsertResponse);
		assertTrue("isValid::" + isValid, isValid);
	}
	
	@Test
	public void testValidateAccountValidWithUCN() {
		assertTrue("upsertMarketingDao is NULL!!", upsertMarketingDao != null);
		PartyXrefType partyXrefType = new PartyXrefType();
		AddressXrefType addr = new AddressXrefType();
		XREFType xref = new XREFType();
		partyXrefType.setPARTYNAME("Test");
		partyXrefType.setUCN("TestUCN");
		xref.setSRCPKEY("TestPKEY");
		partyXrefType.getXREF().add(xref);
		addr.setCOUNTRYCD("US");
		partyXrefType.getAddress().add(addr);
		UpsertPartyResponse upsertResponse = new UpsertPartyResponse();
		Boolean isValid = upsertMarketingDao.validateAccountRequest(
				partyXrefType, upsertResponse);
		assertTrue("isValid::" + isValid, isValid);
	}
}
