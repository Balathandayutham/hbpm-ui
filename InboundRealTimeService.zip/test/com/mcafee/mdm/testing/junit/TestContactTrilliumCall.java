package com.mcafee.mdm.testing.junit;

import java.io.File;
import java.io.StringWriter;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.mcafee.mdm.dao.TrilliumContactCleanserDAO;
import com.mcafee.mdm.delegator.ServiceDelegator;
import com.mcafee.mdm.exception.ServiceProcessingException;
import com.mcafee.mdm.generated.UpsertPartyRequest;
import com.mcafee.mdm.generated.UpsertPartyResponse;

@RunWith(SpringJUnit4ClassRunner.class)
public class TestContactTrilliumCall extends TestM4MBase {
	@Autowired
	private TrilliumContactCleanserDAO trilContactDao;

	@Test
	public void testUpsertProspectParties() throws ServiceProcessingException,
			JAXBException {
		UpsertPartyRequest request = createRequest();
		assertTrue("serviceDelegator is NULL!!", trilContactDao != null);
		assertFalse("request is NULL!!", request == null);
		Boolean response = trilContactDao.trilliumContactCleanser(request.getParty().get(0));
		assertTrue("response is FALSE!!", response);
	}

	private UpsertPartyRequest createRequest() throws JAXBException {
		UpsertPartyRequest request = null;
		JAXBContext jaxbContext = JAXBContext
				.newInstance(UpsertPartyRequest.class);
		Unmarshaller jaxbUnMarshaller = jaxbContext.createUnmarshaller();
		request = (UpsertPartyRequest) jaxbUnMarshaller.unmarshal(new File(
				"D:\\McAfee\\Projects\\Scrum\\TestXML\\ContactTrilTest_QA.xml"));
		return request;
	}
}
