package com.mcafee.mdm.testing.junit;

import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.mcafee.mdm.dao.FNOUpsertPartyDAO;
import com.mcafee.mdm.exception.ServiceProcessingException;
import com.mcafee.mdm.generated.AccountXrefType;
import com.mcafee.mdm.generated.AddressXrefType;
import com.mcafee.mdm.generated.MdmUpsertPartyResponse;
import com.mcafee.mdm.generated.PartyXrefType;
import com.mcafee.mdm.generated.StatusType;
import com.mcafee.mdm.generated.XREFType;

@RunWith(SpringJUnit4ClassRunner.class)
public class TestFNOCleansePutRequest extends TestM4MBase{
	
	
	@Autowired
	private FNOUpsertPartyDAO fnoUpsertPartyDAO;

	@Test
	public void testcleanseputParty() throws ServiceProcessingException,
	JAXBException {
		MdmUpsertPartyResponse upsertPartyResponse = new MdmUpsertPartyResponse();
		upsertPartyResponse.setUpsertStatus(new StatusType());
		
		String name="Dell";
		String srcpKey = generateSrcPkeyWithDate();
		System.out.println(srcpKey);
		PartyXrefType request=createRequest(name,srcpKey);

		fnoUpsertPartyDAO.processCleansePutRequest(request, upsertPartyResponse, false, false, null);
		fnoUpsertPartyDAO.upsertTokenize(request, upsertPartyResponse, false, false, null);
		printObjectTreeInXML(MdmUpsertPartyResponse.class,upsertPartyResponse);
		
	}
	private String generateSrcPkeyWithDate() {
		
		Date date = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("YYYYMMddHHmmss");
		String str = sdf.format(date);
		return str;
	}
	private PartyXrefType createRequest(String name,String srcpKey){
		PartyXrefType request = new PartyXrefType();
		
		request.setLASTUPDATEDATE("28-02-2018 03:00:43");
		request.setSRCCREATEDT("28-02-2018 03:00:43");
		request.setUPDATEBY("admin");
		request.setPARTYTYPE("Reseller");
		request.setPARTYNAME(name);
		request.setSTATUSCD("Active");
		request.setBOCLASSCODE("Organization");
		request.setMSGTRKNID("9876001235");
		request.setUCN("12345678");
		
		XREFType xref = new XREFType();
		xref.setSRCPKEY(srcpKey);
		xref.setSRCSYSTEM("FNO");
		
		
		AccountXrefType acc = new AccountXrefType();
		acc.setSRCPKEY(srcpKey);
		acc.setSRCSYSTEM("FNO");
		acc.setACCTNAME(name);
		acc.setACCTSTATUS("Active");
		acc.setCUSTGROUP("Payer");
		acc.setDATASRCSYSTEM("FNO");
		
		AddressXrefType address = new AddressXrefType();
		address.setSRCPKEY(srcpKey);
		address.setSRCSYSTEM("FNO");
		address.setADDRLN1("009, 10th Main St");
		address.setADDRLN2("");
		address.setADDRLN3("");
		address.setCITY("Sacramento");
		address.setSTATECD("California");
		address.setPOSTALCD("95811");
		address.setCOUNTRYCD("USA");
		address.setADDRTYPE("Billing");
		address.setADDRSTATUS("Active");
		
		
		request.getXREF().add(xref);
		request.getAddress().add(address);
		request.getAccount().add(acc);
		
		return request;
	}
	
	public static void printObjectTreeInXML(Class<?> objectClass, Object classObject) {
        try {
              JAXBContext jaxbContext = JAXBContext.newInstance(objectClass);
              Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
                     jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);

                    StringWriter strWriter = new StringWriter();
                     jaxbMarshaller.marshal(classObject, strWriter);
                     String msgTxt = strWriter.getBuffer().toString();
                     LOG.debug(objectClass.getName() + " object tree :\n" + msgTxt);
                     System.out.println("Response: \n"+msgTxt);
        } catch (JAXBException jaxEx) {
              LOG.error("Failed to create JAXBContext/Marshaller for " + objectClass.getName() + ": " + jaxEx);
              jaxEx.printStackTrace();
        } catch (Exception excp) {
              LOG.error("Failed to convert " + objectClass.getName() + " object into XML: " + excp);
              excp.printStackTrace();
        }
    }
}
