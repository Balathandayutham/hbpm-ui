package com.mcafee.mdm.testing.junit;

import static org.junit.Assert.*;

import java.io.StringWriter;
import java.sql.SQLException;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.mcafee.mdm.dao.AdobeUpsertPartyDAO;
import com.mcafee.mdm.dao.FNOUpsertPartyDAO;
import com.mcafee.mdm.dao.TrilliumLookUpDAO;
import com.mcafee.mdm.exception.ServiceProcessingException;
import com.mcafee.mdm.generated.AccountXrefType;
import com.mcafee.mdm.generated.AddressXrefType;
import com.mcafee.mdm.generated.MdmUpsertPartyResponse;
import com.mcafee.mdm.generated.PartySearchCriteriaType;
import com.mcafee.mdm.generated.PartyXrefType;
import com.mcafee.mdm.generated.XREFType;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:com/mcafee/mdm/testing/config/beans.xml" })
public class TestTrilliumLookUpDAO extends TestM4MBase {

	@Autowired
	private FNOUpsertPartyDAO fnoUpsertPartyDAO;
	
	@Autowired
	private AdobeUpsertPartyDAO adobeUpsertPartyDAO;
	
	@Autowired
	TrilliumLookUpDAO trilliumLookUpDao;

	
	@Test
	public void testTrillum() throws ServiceProcessingException{
		
		MdmUpsertPartyResponse response = new MdmUpsertPartyResponse();
		PartyXrefType party = new PartyXrefType();
		party.setMSGTRKNID(null);
		party.setPARTYTYPE("Prospect Customer");
		party.setPARTYNAME("ABB ltd");
		XREFType xref = new XREFType();
		xref.setSRCSYSTEM("ADB");

		AccountXrefType acc = new AccountXrefType();
		acc.setCLEANSEIND("Y");
		
		AddressXrefType addXrefType = new AddressXrefType();
		
		addXrefType.setSRCPKEY("001q000000kauvAAAQ");
		addXrefType.setADDRLN1("Address Line 1");
		addXrefType.setADDRLN2("Address Line 2");
		addXrefType.setADDRLN3("");
		addXrefType.setCITY("Dallas");
		addXrefType.setPOSTALCD("200000");
		addXrefType.setCOUNTRYCD("US");
		addXrefType.setSTATECD("Texas");
		addXrefType.setADDRSTATUS("Active");
		
		party.getXREF().add(xref);
		party.getAddress().add(addXrefType);
		party.getAccount().add(acc);
		//fnoUpsertPartyDAO.upsertTrilliumProcessing(party, response, false, false, null);
		adobeUpsertPartyDAO.upsertTrilliumProcessing(party, response, false, false, null);
		printObjectTreeInXML(MdmUpsertPartyResponse.class,response);
		
	}
	
	
	/*@Test
	public void testConvertSRCToMDMDataUpsertWithValidCountryCode() {
		PartyXrefType curParty = new PartyXrefType();
		String[] expectedMdmStateCountryArr = { "TX", "US" };
		String[] actualMdmStateCountryArr = null;
		AddressXrefType addXrefType = new AddressXrefType();
		addXrefType.setCOUNTRYCD("US");
		addXrefType.setSTATECD("TX");
		
		XREFType xef = new XREFType();
		xef.setSRCSYSTEM("FNO");
		
		

		try {
			curParty.getAddress().add(addXrefType);
			curParty.getXREF().add(xef);
			actualMdmStateCountryArr = trilliumLookUpDao.convertSRCToMDMDataUpsert(curParty,
					curParty.getXREF().get(0).getSRCSYSTEM());

		} catch (SQLException | ServiceProcessingException e) {
			e.printStackTrace();
		}
		assertArrayEquals(expectedMdmStateCountryArr, actualMdmStateCountryArr);
	}*/

	
	public static void printObjectTreeInXML(Class<?> objectClass, Object classObject) {
        try {
              JAXBContext jaxbContext = JAXBContext.newInstance(objectClass);
              Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
                     jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);

                    StringWriter strWriter = new StringWriter();
                     jaxbMarshaller.marshal(classObject, strWriter);
                     String msgTxt = strWriter.getBuffer().toString();
                     LOG.debug(objectClass.getName() + " object tree :\n" + msgTxt);
                     System.out.println("Response: \n"+msgTxt);
        } catch (JAXBException jaxEx) {
              LOG.error("Failed to create JAXBContext/Marshaller for " + objectClass.getName() + ": " + jaxEx);
              jaxEx.printStackTrace();
        } catch (Exception excp) {
              LOG.error("Failed to convert " + objectClass.getName() + " object into XML: " + excp);
              excp.printStackTrace();
        }
    }
	
	/*@Test
	public void testConvertSRCToMDMDataUpsertWithInvalidCountryCode() {
		PartyXrefType curParty = new PartyXrefType();
		XREFType xef = new XREFType();
		xef.setSRCSYSTEM("FNO");
		
		String[] expectedMdmStateCountryArr = null;
		String[] actualMdmStateCountryArr = null;
		
		AddressXrefType addXrefType = new AddressXrefType();
		addXrefType.setCOUNTRYCD("ME");
		addXrefType.setSTATECD("TEXAS");

		try {
			curParty.getAddress().add(addXrefType);
			curParty.getXREF().add(xef);
			actualMdmStateCountryArr = trilliumLookUpDao.convertSRCToMDMDataUpsert(curParty,curParty.getXREF().get(0).getSRCSYSTEM());

		} catch (SQLException | ServiceProcessingException e) {
			e.printStackTrace();
		}
		assertArrayEquals(expectedMdmStateCountryArr, actualMdmStateCountryArr);
	}
	
	@Test
	public void testConvertSRCToMDMDataUpsertWithNullCountryCode() {
		PartyXrefType curParty = new PartyXrefType();
		String[] expectedMdmStateCountryArr = null;
		String[] actualMdmStateCountryArr = null;
		AddressXrefType addXrefType = new AddressXrefType();
		addXrefType.setCOUNTRYCD(null);
		addXrefType.setSTATECD("TEXAS");

		try {
			curParty.getAddress().add(addXrefType);
			actualMdmStateCountryArr = trilliumLookUpDao.convertSRCToMDMDataUpsert(curParty,
					curParty.getXREF().get(0).getSRCSYSTEM());

		} catch (SQLException | ServiceProcessingException e) {
			e.printStackTrace();
		}
		assertArrayEquals(expectedMdmStateCountryArr, actualMdmStateCountryArr);
	}

	
	@Test
	public void testCheckInTrilliumCountryProjectMapWithValidCountryCode() {

		PartySearchCriteriaType partySearchCriteriaType = new PartySearchCriteriaType();
		partySearchCriteriaType.setCOUNTRYCD("US");
		boolean b = false;
		try {
			b = trilliumLookUpDao.checkInTrilliumCountryProjectMap(partySearchCriteriaType);
		} catch (SQLException | ServiceProcessingException e) {
			e.printStackTrace();
		}
		assertTrue(b);

	}

	@Test
	public void testCheckInTrilliumCountryProjectMapWithInvalidCountryCode() {

		PartySearchCriteriaType partySearchCriteriaType = new PartySearchCriteriaType();
		partySearchCriteriaType.setCOUNTRYCD("ZQ");
		boolean b = false;
		try {
			b = trilliumLookUpDao.checkInTrilliumCountryProjectMap(partySearchCriteriaType);
		} catch (SQLException | ServiceProcessingException e) {
			e.printStackTrace();
		}
		assertFalse(b);

	}
	
	@Test
	public void testCheckInTrilliumCountryProjectMapWithNullCountryCode() {

		PartySearchCriteriaType partySearchCriteriaType = new PartySearchCriteriaType();
		partySearchCriteriaType.setCOUNTRYCD(null);
		boolean b = false;
		try {
			b = trilliumLookUpDao.checkInTrilliumCountryProjectMap(partySearchCriteriaType);
		} catch (SQLException | ServiceProcessingException e) {
			e.printStackTrace();
		}
		assertFalse(b);

	}*/
	
}
