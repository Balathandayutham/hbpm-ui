package com.mcafee.mdm.testing.junit;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.mcafee.mdm.constants.Constant;
import com.mcafee.mdm.dao.FNOUpsertPartyDAO;
import com.mcafee.mdm.exception.ServiceProcessingException;
import com.mcafee.mdm.generated.AddressXrefType;
import com.mcafee.mdm.generated.MdmUpsertPartyResponse;
import com.mcafee.mdm.generated.PartyXrefType;
import com.mcafee.mdm.generated.StatusType;
import com.mcafee.mdm.generated.XREFType;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:com/mcafee/mdm/testing/config/beans.xml" })
public class TestFNOCheckDataQualityUpsert extends TestM4MBase {
	
	@Autowired
	private FNOUpsertPartyDAO fnoUpsertPartyDAO;
	
	@Test
	public void testValidateAccountNameWithNULL(){
		PartyXrefType upsertParty = new PartyXrefType();
		XREFType xref = new XREFType();
		xref.setSRCPKEY("001q000000lvgXKAAY");
		upsertParty.getXREF().add(xref);
		upsertParty.setPARTYNAME(null);
		MdmUpsertPartyResponse upsertPartyResponse = new MdmUpsertPartyResponse();
		StatusType statusType = new StatusType();
		upsertPartyResponse.setUpsertStatus(statusType);
		boolean retry = false;
		boolean executeNextStep = false;
		String rowidObject = null;
		try {
			fnoUpsertPartyDAO.checkDataQualityUpsert(upsertParty, upsertPartyResponse, retry, executeNextStep, rowidObject);
		} catch (ServiceProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		assertTrue("Account name is either null", Constant.ERROR_ACCOUNT_NAME_UNKWN.equals(upsertPartyResponse.getUpsertStatus().getErrorCode()));
	}
	
	@Test
	public void testValidateAccountNameWithEmpty(){
		PartyXrefType upsertParty = new PartyXrefType();
		XREFType xref = new XREFType();
		xref.setSRCPKEY("001q000000lvgXKAAY");
		upsertParty.getXREF().add(xref);
		upsertParty.setPARTYNAME("");
		MdmUpsertPartyResponse upsertPartyResponse = new MdmUpsertPartyResponse();
		StatusType statusType = new StatusType();
		upsertPartyResponse.setUpsertStatus(statusType);
		boolean retry = false;
		boolean executeNextStep = false;
		String rowidObject = null;
		try {
			fnoUpsertPartyDAO.checkDataQualityUpsert(upsertParty, upsertPartyResponse, retry, executeNextStep, rowidObject);
		} catch (ServiceProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		assertTrue("Account name is empty", Constant.ERROR_ACCOUNT_NAME_UNKWN.equals(upsertPartyResponse.getUpsertStatus().getErrorCode()));
	}
	
	@Test
	public void testValidateAccountNameWithUnknownValue(){
		PartyXrefType upsertParty = new PartyXrefType();
		XREFType xref = new XREFType();
		xref.setSRCPKEY("001q000000lvgXKAAY");
		upsertParty.getXREF().add(xref);
		upsertParty.setPARTYNAME("Unknown");
		MdmUpsertPartyResponse upsertPartyResponse = new MdmUpsertPartyResponse();
		StatusType statusType = new StatusType();
		upsertPartyResponse.setUpsertStatus(statusType);
		boolean retry = false;
		boolean executeNextStep = false;
		String rowidObject = null;
		try {
			fnoUpsertPartyDAO.checkDataQualityUpsert(upsertParty, upsertPartyResponse, retry, executeNextStep, rowidObject);
		} catch (ServiceProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		assertTrue("Account name is unknown", Constant.ERROR_ACCOUNT_NAME_UNKWN.equals(upsertPartyResponse.getUpsertStatus().getErrorCode()));
	}
	
	@Test
	public void testValidateAccountNameWithJunkValue(){
		PartyXrefType upsertParty = new PartyXrefType();
		XREFType xref = new XREFType();
		xref.setSRCPKEY("001q000000lvgXKAAY");
		upsertParty.getXREF().add(xref);
		upsertParty.setPARTYNAME("fdfdf");
		MdmUpsertPartyResponse upsertPartyResponse = new MdmUpsertPartyResponse();
		StatusType statusType = new StatusType();
		upsertPartyResponse.setUpsertStatus(statusType);
		boolean retry = false;
		boolean executeNextStep = false;
		String rowidObject = null;
		try {
			fnoUpsertPartyDAO.checkDataQualityUpsert(upsertParty, upsertPartyResponse, retry, executeNextStep, rowidObject);
		} catch (ServiceProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		assertTrue("Account name is junk", Constant.ERROR_ACCOUNT_NAME_UNKWN.equals(upsertPartyResponse.getErrorCd()));
	}

	/**
	 * Checks whether addressline1 is null (which also checks empty and unknown)
	 */
	@Test
	public void testValidateAccountAddressLine1Null(){
		PartyXrefType upsertParty = new PartyXrefType();
		XREFType xref = new XREFType();
		xref.setSRCPKEY("001q000000lvgXKAAY");
		upsertParty.getXREF().add(xref);
		upsertParty.setPARTYNAME("raj");
		AddressXrefType address = new AddressXrefType();
		upsertParty.getAddress().add(address);
		upsertParty.getAddress().get(0).setADDRLN1(null);
		MdmUpsertPartyResponse upsertPartyResponse = new MdmUpsertPartyResponse();
		StatusType statusType = new StatusType();
		upsertPartyResponse.setUpsertStatus(statusType);
		boolean retry = false;
		boolean executeNextStep = false;
		String rowidObject = null;
		try {
			fnoUpsertPartyDAO.checkDataQualityUpsert(upsertParty, upsertPartyResponse, retry, executeNextStep, rowidObject);
		} catch (ServiceProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		assertTrue("Account address line1 is either null or empty or unknown", Constant.ERROR_ACCOUNT_ADDR_INVALID.equals(upsertPartyResponse.getErrorCd()));
	
	}
	
	@Test
	public void testValidateAccountAddressCityNull(){
		PartyXrefType upsertParty = new PartyXrefType();
		XREFType xref = new XREFType();
		xref.setSRCPKEY("001q000000lvgXKAAY");
		upsertParty.getXREF().add(xref);
		upsertParty.setPARTYNAME("raj");
		AddressXrefType address = new AddressXrefType();
		upsertParty.getAddress().add(address);
		upsertParty.getAddress().get(0).setADDRLN1("Bussy Street");
		upsertParty.getAddress().get(0).setCITY(null);
		MdmUpsertPartyResponse upsertPartyResponse = new MdmUpsertPartyResponse();
		StatusType statusType = new StatusType();
		upsertPartyResponse.setUpsertStatus(statusType);
		boolean retry = false;
		boolean executeNextStep = false;
		String rowidObject = null;
		try {
			fnoUpsertPartyDAO.checkDataQualityUpsert(upsertParty, upsertPartyResponse, retry, executeNextStep, rowidObject);
		} catch (ServiceProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		assertTrue("Account address city is either null or empty or unknown", Constant.ERROR_ACCOUNT_ADDR_INVALID.equals(upsertPartyResponse.getErrorCd()));
	
	}
	
	@Test
	public void testValidateAccountAddressStateNull(){
		PartyXrefType upsertParty = new PartyXrefType();
		XREFType xref = new XREFType();
		xref.setSRCPKEY("001q000000lvgXKAAY");
		upsertParty.getXREF().add(xref);
		upsertParty.setPARTYNAME("raj");
		AddressXrefType address = new AddressXrefType();
		upsertParty.getAddress().add(address);
		upsertParty.getAddress().get(0).setADDRLN1("Bussy Street");
		upsertParty.getAddress().get(0).setCITY("Chennai");
		upsertParty.getAddress().get(0).setSTATECD(null);
		MdmUpsertPartyResponse upsertPartyResponse = new MdmUpsertPartyResponse();
		StatusType statusType = new StatusType();
		upsertPartyResponse.setUpsertStatus(statusType);
		boolean retry = false;
		boolean executeNextStep = false;
		String rowidObject = null;
		try {
			fnoUpsertPartyDAO.checkDataQualityUpsert(upsertParty, upsertPartyResponse, retry, executeNextStep, rowidObject);
		} catch (ServiceProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		assertTrue("Account address state is either null or empty or unknown", Constant.ERROR_ACCOUNT_ADDR_INVALID.equals(upsertPartyResponse.getErrorCd()));
	
	}
	
	@Test
	public void testValidateAccountAddressCountryNull(){
		PartyXrefType upsertParty = new PartyXrefType();
		XREFType xref = new XREFType();
		xref.setSRCPKEY("001q000000lvgXKAAY");
		upsertParty.getXREF().add(xref);
		upsertParty.setPARTYNAME("raj");
		AddressXrefType address = new AddressXrefType();
		upsertParty.getAddress().add(address);
		upsertParty.getAddress().get(0).setADDRLN1("Bussy Street");
		upsertParty.getAddress().get(0).setCITY("Chennai");
		upsertParty.getAddress().get(0).setSTATECD("TamilNadu");
		upsertParty.getAddress().get(0).setCOUNTRYCD(null);
		MdmUpsertPartyResponse upsertPartyResponse = new MdmUpsertPartyResponse();
		StatusType statusType = new StatusType();
		upsertPartyResponse.setUpsertStatus(statusType);
		boolean retry = false;
		boolean executeNextStep = false;
		String rowidObject = null;
		try {
			fnoUpsertPartyDAO.checkDataQualityUpsert(upsertParty, upsertPartyResponse, retry, executeNextStep, rowidObject);
		} catch (ServiceProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		assertTrue("Account address country is either null or empty or unknown", Constant.ERROR_ACCOUNT_ADDR_INVALID.equals(upsertPartyResponse.getErrorCd()));
	
	}
	
	@Test
	public void testValidateAccountAddressPostalCodeNull(){
		PartyXrefType upsertParty = new PartyXrefType();
		XREFType xref = new XREFType();
		xref.setSRCPKEY("001q000000lvgXKAAY");
		upsertParty.getXREF().add(xref);
		upsertParty.setPARTYNAME("raj");
		AddressXrefType address = new AddressXrefType();
		upsertParty.getAddress().add(address);
		upsertParty.getAddress().get(0).setADDRLN1("Bussy Street");
		upsertParty.getAddress().get(0).setCITY("Chennai");
		upsertParty.getAddress().get(0).setSTATECD("TamilNadu");
		upsertParty.getAddress().get(0).setCOUNTRYCD("India");
		upsertParty.getAddress().get(0).setPOSTALCD(null);
		MdmUpsertPartyResponse upsertPartyResponse = new MdmUpsertPartyResponse();
		StatusType statusType = new StatusType();
		upsertPartyResponse.setUpsertStatus(statusType);
		boolean retry = false;
		boolean executeNextStep = false;
		String rowidObject = null;
		try {
			fnoUpsertPartyDAO.checkDataQualityUpsert(upsertParty, upsertPartyResponse, retry, executeNextStep, rowidObject);
		} catch (ServiceProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		assertTrue("Account address postal code is either null or empty or unknown", Constant.ERROR_ACCOUNT_ADDR_INVALID.equals(upsertPartyResponse.getErrorCd()));
	
	}
	
	@Test
	public void testValidateAccountAddressAddressLine1Junk(){
		PartyXrefType upsertParty = new PartyXrefType();
		XREFType xref = new XREFType();
		xref.setSRCPKEY("001q000000lvgXKAAY");
		upsertParty.getXREF().add(xref);
		upsertParty.setPARTYNAME("raj");
		AddressXrefType address = new AddressXrefType();
		upsertParty.getAddress().add(address);
		upsertParty.getAddress().get(0).setADDRLN1("*");
		upsertParty.getAddress().get(0).setCITY("Chennai");
		upsertParty.getAddress().get(0).setSTATECD("TamilNadu");
		upsertParty.getAddress().get(0).setCOUNTRYCD("India");
		upsertParty.getAddress().get(0).setPOSTALCD("142 32");
		MdmUpsertPartyResponse upsertPartyResponse = new MdmUpsertPartyResponse();
		StatusType statusType = new StatusType();
		upsertPartyResponse.setUpsertStatus(statusType);
		boolean retry = false;
		boolean executeNextStep = false;
		String rowidObject = null;
		try {
			fnoUpsertPartyDAO.checkDataQualityUpsert(upsertParty, upsertPartyResponse, retry, executeNextStep, rowidObject);
		} catch (ServiceProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		assertTrue("Account address line1 is junk", Constant.ERROR_ACCOUNT_ADDR_LN1_UNKWN.equals(upsertPartyResponse.getErrorCd()));
	
	}
	
	@Test
	public void testValidateAccountAddressCityJunk(){
		PartyXrefType upsertParty = new PartyXrefType();
		XREFType xref = new XREFType();
		xref.setSRCPKEY("001q000000lvgXKAAY");
		upsertParty.getXREF().add(xref);
		upsertParty.setPARTYNAME("raj");
		AddressXrefType address = new AddressXrefType();
		upsertParty.getAddress().add(address);
		upsertParty.getAddress().get(0).setADDRLN1("Bussy Street");
		upsertParty.getAddress().get(0).setCITY("???");
		upsertParty.getAddress().get(0).setSTATECD("TamilNadu");
		upsertParty.getAddress().get(0).setCOUNTRYCD("India");
		upsertParty.getAddress().get(0).setPOSTALCD("142 32");
		MdmUpsertPartyResponse upsertPartyResponse = new MdmUpsertPartyResponse();
		StatusType statusType = new StatusType();
		upsertPartyResponse.setUpsertStatus(statusType);
		boolean retry = false;
		boolean executeNextStep = false;
		String rowidObject = null;
		try {
			fnoUpsertPartyDAO.checkDataQualityUpsert(upsertParty, upsertPartyResponse, retry, executeNextStep, rowidObject);
		} catch (ServiceProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		assertTrue("Account adrress city is either junk", Constant.ERROR_ACCOUNT_CITY_UNKWN.equals(upsertPartyResponse.getErrorCd()));
	
	}
	
}
