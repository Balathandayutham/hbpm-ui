package com.mcafee.mdm.testing.junit;

import org.apache.log4j.Logger;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.mcafee.mdm.util.PerformanceLoggerUtil;

@RunWith(SpringJUnit4ClassRunner.class)
public class TestPerfLog extends TestM4MBase{
	
	private static final Logger LOG = Logger.getLogger(TestPerfLog.class);
		
	@Test
	public void testPerfLog() {
		PerformanceLoggerUtil perfLog = new PerformanceLoggerUtil();
		LOG.debug("General Log");
		perfLog.printLog("Test", null, null, "Performance Log");
	}
}
