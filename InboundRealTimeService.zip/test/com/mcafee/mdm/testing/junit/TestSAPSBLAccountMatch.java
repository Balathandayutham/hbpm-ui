package com.mcafee.mdm.testing.junit;

import java.io.File;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;

import javax.annotation.Resource;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.mcafee.mdm.dao.ProspectPartyDAO;
import com.mcafee.mdm.dao.TrilliumCleanserDAO;
import com.mcafee.mdm.dao.TrilliumLookUpDAO;
import com.mcafee.mdm.dao.pojo.HighestScoreRecordHolder;
import com.mcafee.mdm.exception.ServiceProcessingException;
import com.mcafee.mdm.generated.PartyXrefType;
import com.mcafee.mdm.generated.UpsertPartyRequest;
import com.mcafee.mdm.util.CreateSIFClient;
import com.mcafee.mdm.util.JDBCConnectionProvider;
import com.mcafee.mdm.util.Util;
import com.siperian.sif.client.SiperianClient;
import com.siperian.sif.message.Field;
import com.siperian.sif.message.MatchType;
import com.siperian.sif.message.Record;
import com.siperian.sif.message.SiperianObjectType;
import com.siperian.sif.message.mrm.SearchMatchRequest;
import com.siperian.sif.message.mrm.SearchMatchResponse;

@RunWith(SpringJUnit4ClassRunner.class)
public class TestSAPSBLAccountMatch extends TestM4MBase {
	@Autowired
	private TrilliumCleanserDAO trilliumCleanserDAO;
	@Autowired
	private TrilliumLookUpDAO trilliumLookUpDAO;
	@Autowired
	private ProspectPartyDAO prospectPartyDAO;
	@Autowired
	private JdbcTemplate jdbcTemplate;
	@Resource(name = "configProp")
	private Properties configProps;

	@Test
	public void testUS585() throws ServiceProcessingException, JAXBException, SQLException {

		String mdmStateCountryArr[] = new String[10];
		boolean setTrilliumValue = false;
		boolean isInTrilliumList = false;

		UpsertPartyRequest request = createRequest();

		for (PartyXrefType curParty : request.getParty()) {
			if (!Util.isNullOrEmpty(curParty.getXREF().get(0).getSRCSYSTEM())) {
				try {
					isInTrilliumList = trilliumLookUpDAO.checkInTrilliumCountryProjectMap(curParty);
					if (isInTrilliumList) {
						LOG.info("Going For TRILLIUM Procedure");
						mdmStateCountryArr = trilliumLookUpDAO.convertSRCToMDMDataUpsert(curParty,
								curParty.getXREF().get(0).getSRCSYSTEM());
						if (!Util.isNullOrEmpty(mdmStateCountryArr[1])) {
							curParty.getAddress().get(0).setSTATECD(mdmStateCountryArr[0]);
						}
						LOG.info("Trillium Call is being made.");
						setTrilliumValue = trilliumCleanserDAO.callTrilliumCleanser(curParty, Boolean.FALSE);
						trilliumLookUpDAO.convertTrilliumToSRCData(setTrilliumValue, curParty,
								curParty.getXREF().get(0).getSRCSYSTEM());
						trilliumLookUpDAO.convertTrilliumToSRCCountry(curParty, curParty.getXREF().get(0).getSRCSYSTEM());
					} else {
						LOG.info("Input Country not within list of 71 Countries, So No TRILLIUM Call.");
					}
				}catch(Exception e) {
					LOG.error("Error in Trillium", e);
				}
			} else {
				LOG.info("BY Passing TRILLIUM Call Since No SRC_SYSTEM");
			}
			curParty.getAddress().get(0).setCOUNTRYCD(CF_SBL_COUNTRY(curParty.getAddress().get(0).getCOUNTRYCD()));
			int matchScoreThres = Integer.parseInt(configProps.getProperty("matchScore-Threshold"));
			HighestScoreRecordHolder highestScoreRecordHoldertgt = new HighestScoreRecordHolder();
			SiperianClient siperianClient = CreateSIFClient.getSIFClientObject().getSIFClient();
			processMatchAndMergeParty("7880389", curParty, matchScoreThres, highestScoreRecordHoldertgt, siperianClient);
		}
	}

	private UpsertPartyRequest createRequest() throws JAXBException {
		UpsertPartyRequest request = null;
		JAXBContext jaxbContext = JAXBContext.newInstance(UpsertPartyRequest.class);
		Unmarshaller jaxbUnMarshaller = jaxbContext.createUnmarshaller();
		request = (UpsertPartyRequest) jaxbUnMarshaller
				.unmarshal(new File("D:\\McAfee\\Projects\\Scrum\\TestXML\\4-7U8NRS3.xml"));
		return request;
	}

	private HashMap<Integer, HighestScoreRecordHolder> processMatchAndMergeParty(
			String rowidObject, PartyXrefType partyTypeParam, int matchScoreThres,
			HighestScoreRecordHolder highestScoreRecordHoldertgt, SiperianClient siperianClient)
			throws ServiceProcessingException, SQLException {

		LOG.info("Executing processMatchAndMergeParty()");
		String ruleSetName = configProps.getProperty("matchRuleSet");
		String ruleSetJPN = configProps.getProperty("matchRuleSetCustomerJPN");
		String sorceRowidObject = null;
		boolean isError = false;
		boolean matchInd = false;

		int matchCountOfRetry = Integer.parseInt(configProps.getProperty("NoOfRetries"));
		boolean isMatchRetrySuccess = false;
		List searchRecords = new ArrayList();
		HighestScoreRecordHolder highestScoreRecordHolder = null;

		HashMap<Integer, HighestScoreRecordHolder> highestScoreRecordHolderMap = new HashMap<Integer, HighestScoreRecordHolder>();
		SearchMatchRequest searchMatchRequest = new SearchMatchRequest();
		SearchMatchResponse searchMatchResponse = null;
		List<Object> tempkeyList = new ArrayList<Object>();

		searchRecords = matchParty(partyTypeParam, siperianClient);
		LOG.debug("Party SearchMatch is successful !!");

		// Store Match Score
		HashMap<Integer, Integer> matchScoreMap = new HashMap<Integer, Integer>();
		List<Integer> resultMatchScoreList = null;

		// Store Duns Number
		HashMap<Integer, Integer> dunsNbrMap = new HashMap<Integer, Integer>();
		List<Integer> dunsNbrMapList = null;

		HashMap<Integer, Integer> sapCustNumMap = new HashMap<Integer, Integer>();
		List<Integer> sapCustNumMapList = null;

		List<Integer> rowidList = null;
		// CommunicationType comm = null;
		// ClassificationType classif = null;

		if (searchRecords != null && searchRecords.size() > 0) {
			for (Iterator iter = searchRecords.iterator(); iter.hasNext();) {
				Record record = (Record) iter.next();
				highestScoreRecordHolder = null;
				String recRowid = record.getField("ROWID_OBJECT").getStringValue().trim();
				LOG.debug("line:1995:recRowid: " + recRowid);
				LOG.debug("line:1996:putRespDataHolder.getRowidObject()" + rowidObject);

				if (!recRowid.equals(rowidObject)) {
					LOG.debug("line:1998:Matching recRowid: " + recRowid);
					int rowidKey = Integer.parseInt(recRowid);

					if (!highestScoreRecordHolderMap.containsKey(rowidKey)) {

						LOG.debug("Populate highestScoreRecordHolderMap for new PARTY_ROWID " + recRowid);
						highestScoreRecordHolderMap.put(rowidKey, new HighestScoreRecordHolder());
					}

					highestScoreRecordHolder = highestScoreRecordHolderMap.get(rowidKey);

					if (record.getField("ROWID_OBJECT").getStringValue() != null) {
						highestScoreRecordHolder
								.setPartyRowIDObject(record.getField("ROWID_OBJECT").getStringValue().trim());
					}
					if (record.getField("PARTY_TYPE").getStringValue() != null) {
						highestScoreRecordHolder.setPartyType(record.getField("PARTY_TYPE").getStringValue().trim());
					}
					if (record.getField("SAP_CUST_NUMBER").getStringValue() != null) {
						highestScoreRecordHolder
								.setSapCustNumber(record.getField("SAP_CUST_NUMBER").getStringValue().trim());
					}
					if (record.getField("ORG_DUNS_NBR").getStringValue() != null) {
						highestScoreRecordHolder.setOrgDunsNbr(record.getField("ORG_DUNS_NBR").getStringValue().trim());
					}
					if (record.getField("ROWID_ORG_EXTN").getStringValue() != null) {
						highestScoreRecordHolder
								.setRowidOrgExtn(record.getField("ROWID_ORG_EXTN").getStringValue().trim());
					}
					if (record.getField("ROWID_PRSN_EXTN").getStringValue() != null) {
						highestScoreRecordHolder
								.setRowidPrsnExtn(record.getField("ROWID_PRSN_EXTN").getStringValue().trim());
					}
					if (record.getField("ROWID_CLASSIFCTN").getStringValue() != null) {
						// highestScoreRecordHolder.setRowidCLASSIFCTN(record.getField("ROWID_CLASSIFCTN").getStringValue().trim());
						// classif = new ClassificationType();
						// classif.setCLASSIFICTNTYPE(record.getField("CLASSIFCTN_TYPE").getStringValue());
						highestScoreRecordHolder.getClassMap().put(
								record.getField("ROWID_CLASSIFCTN").getStringValue().trim(),
								record.getField("CLASSIFCTN_TYPE").getStringValue());

					}
					if (record.getField("ROWID_COMMUNICATION").getStringValue() != null) {
						// highestScoreRecordHolder.setRowidCommunication(record.getField("ROWID_COMMUNICATION").getStringValue().trim());
						// comm = new CommunicationType();
						// comm.setCOMMTYPE(record.getField("COMM_TYPE").getStringValue());
						highestScoreRecordHolder.getCommMap().put(
								record.getField("ROWID_COMMUNICATION").getStringValue().trim(),
								record.getField("COMM_TYPE").getStringValue());
					}
					if (record.getField("ROWID_ADDRESS").getStringValue() != null) {
						highestScoreRecordHolder.getAddrMap().put(
								record.getField("ROWID_ADDRESS").getStringValue().trim(),
								record.getField("ADDR_TYPE").getStringValue());
						// highestScoreRecordHolder.setRowidAddress(record.getField("ROWID_ADDRESS").getStringValue().trim());
					}
					if (record.getField("ROWID_ACCOUNT").getStringValue() != null) {
						highestScoreRecordHolder
								.setRowidAccount(record.getField("ROWID_ACCOUNT").getStringValue().trim());
					}

					// Populate Match Score Map
					String mtchScore = record.getField("MATCH_SCORE").getValue().toString().trim();
					int mtchValue = Integer.parseInt(mtchScore);
					LOG.info("MatchScoreMap rowid_object :" + rowidKey + " scoreValue :" + mtchValue);
					matchScoreMap.put(rowidKey, mtchValue);

					// highestScoreRecordHolderMap.put(rowidKey,highestScoreRecordHolder);
				} else if (recRowid.equals(rowidObject)) {

					// highestScoreRecordHoldertgt = new
					// HighestScoreRecordHolder();
					LOG.debug("Self Matching record found with rowidOb: " + rowidObject);
					highestScoreRecordHoldertgt
							.setPartyRowIDObject(record.getField("ROWID_OBJECT").getStringValue().trim());
					if (record.getField("ROWID_CLASSIFCTN").getStringValue() != null) {

						highestScoreRecordHoldertgt.getClassMap().put(
								record.getField("ROWID_CLASSIFCTN").getStringValue().trim(),
								record.getField("CLASSIFCTN_TYPE").getStringValue());

					}
					if (record.getField("ROWID_COMMUNICATION").getStringValue() != null) {

						highestScoreRecordHoldertgt.getCommMap().put(
								record.getField("ROWID_COMMUNICATION").getStringValue().trim(),
								record.getField("COMM_TYPE").getStringValue());
					}
					if (record.getField("ROWID_ADDRESS").getStringValue() != null) {

						highestScoreRecordHoldertgt.getAddrMap().put(
								record.getField("ROWID_ADDRESS").getStringValue().trim(),
								record.getField("ADDR_TYPE").getStringValue());
					}
				}
			}

			int highestScore = 0;
			if (matchScoreMap != null && matchScoreMap.size() > 0) {
				highestScore = highestMatchScore(matchScoreMap);

				int matchScoreThreshold = matchScoreThres;
				if (matchScoreThreshold > highestScore) {
					LOG.info(" Highest Match Score of MatchedRecords is smaller than ThresholdValue");
					return null;
				} else {
					matchInd = true;

					// Method invocation for fetching Records with
					// Highest Match Score
					if (matchScoreMap != null && matchScoreMap.size() > 0) {
						resultMatchScoreList = maxMatchScore(matchScoreMap);
					}
					// If Multiple Records have Highest Match Score
					if ((resultMatchScoreList != null && resultMatchScoreList.size() > 1)
							&& (highestScoreRecordHolderMap.size() > 1)) {

						HighestScoreRecordHolder highestScoreRecordHolder2 = new HighestScoreRecordHolder();

						// Removing Lower MatchScore Records
						for (Entry entry : highestScoreRecordHolderMap.entrySet()) {
							if (!resultMatchScoreList.contains(entry.getKey())) {
								LOG.info("Removing Record with RowID: " + entry.getKey());
								tempkeyList.add(entry.getKey());
							}
						}
						for (Object obj : tempkeyList) {
							highestScoreRecordHolderMap.remove(obj);
						}
						tempkeyList.clear();

						// If Multiple Records in HolderMap after
						// Removing Lower MatchScores
						if (highestScoreRecordHolderMap.size() > 1) {

							for (Entry entry : highestScoreRecordHolderMap.entrySet()) {
								highestScoreRecordHolder2 = (HighestScoreRecordHolder) entry.getValue();

								// Populate DunsNBR Map
								int rowidKey = Integer.parseInt(highestScoreRecordHolder2.getPartyRowIDObject());
								if (highestScoreRecordHolder2.getOrgDunsNbr() != null
										&& highestScoreRecordHolder2.getOrgDunsNbr().length() > 0) {
									int dunsValue = Integer.parseInt(highestScoreRecordHolder2.getOrgDunsNbr());
									LOG.info("DunsNoMap rowid_object :" + rowidKey + " scoreValue :" + dunsValue);
									dunsNbrMap.put(rowidKey, dunsValue);
								} else {
									LOG.info(" Null DunsValue is: " + highestScoreRecordHolder2.getOrgDunsNbr());
								}
							}

							// Method invocation for fetching Records
							// with Lowest Duns Number
							if (dunsNbrMap != null && dunsNbrMap.size() > 0)
								dunsNbrMapList = minDunsNbr(dunsNbrMap);

							HighestScoreRecordHolder highestScoreRecordHolder3 = null;

							// Removing Higher DunsNumber Records
							if (dunsNbrMapList != null && dunsNbrMapList.size() > 0) {
								for (Entry entry : highestScoreRecordHolderMap.entrySet()) {
									if (!dunsNbrMapList.contains(entry.getKey())) {
										LOG.info("Removing Record with RowID: " + entry.getKey());
										tempkeyList.add(entry.getKey());
									}
								}
								for (Object obj : tempkeyList) {
									highestScoreRecordHolderMap.remove(obj);
								}
								tempkeyList.clear();
							}

							// If Multiple Records in HolderMap after
							// Removing Higher DunsNumbers
							if (highestScoreRecordHolderMap.size() > 1) {

								// Checking if present in Hierarchy
								if (dunsNbrMapList != null && dunsNbrMapList.size() > 0) {
									rowidList = searchHierarchy(dunsNbrMapList);
									LOG.info(" RowIDSet: " + rowidList);

									if (rowidList != null && rowidList.size() > 0) {
										// Removing Non-Hierarchy
										// Records
										for (Entry entry : highestScoreRecordHolderMap.entrySet()) {
											if (!rowidList.contains(entry.getKey())) {
												LOG.info("Removing Record with RowID: " + entry.getKey());
												tempkeyList.add(entry.getKey());
											}
										}
										for (Object obj : tempkeyList) {
											highestScoreRecordHolderMap.remove(obj);
										}
										tempkeyList.clear();
									}
								}
								// If Multiple Records in HolderMap
								// after Removing Non-Hierarchy Records
								if (highestScoreRecordHolderMap.size() > 1) {

									for (Entry entry : highestScoreRecordHolderMap.entrySet()) {
										highestScoreRecordHolder3 = (HighestScoreRecordHolder) entry.getValue();
										// Populate SapCustNBR Map
										if (highestScoreRecordHolder3.getSapCustNumber() != null
												&& highestScoreRecordHolder3.getSapCustNumber().length() > 0) {
											int rowidKey = Integer
													.parseInt(highestScoreRecordHolder3.getPartyRowIDObject());
											int sapValue = Integer
													.parseInt(highestScoreRecordHolder3.getSapCustNumber());
											LOG.info("SapCustMap rowid_object :" + rowidKey + " scoreValue :"
													+ sapValue);
											sapCustNumMap.put(rowidKey, sapValue);
										} else {
											LOG.info("Null SapCustNum is: "
													+ highestScoreRecordHolder3.getSapCustNumber());
										}
									}

									// Method invocation for fetching
									// Records with Lowest SapCustNum
									if (sapCustNumMap != null && sapCustNumMap.size() > 0)
										sapCustNumMapList = minSapCustNum(sapCustNumMap);

									// Removing Higher SapCustNumber
									// Records
									if (sapCustNumMapList != null && sapCustNumMapList.size() > 0) {
										for (Entry entry : highestScoreRecordHolderMap.entrySet()) {
											if (!sapCustNumMapList.contains(entry.getKey())) {
												LOG.info("Removing Record with RowID: " + entry.getKey());
												tempkeyList.add(entry.getKey());
											}
										}
										for (Object obj : tempkeyList) {
											highestScoreRecordHolderMap.remove(obj);
										}
										tempkeyList.clear();
									}
								}
							}
						}
					}
				}

				LOG.info("Final Map Size: " + highestScoreRecordHolderMap.size());
				LOG.info("Source RecordKey is found: " + ((Set) highestScoreRecordHolderMap.entrySet()));
			} else {
				LOG.info("No matching record found after searchMatch resultset processing");
				return null;
			}

		} else {
			LOG.info("No matching record found by searchMatch");
			return null;
		}
		while (highestScoreRecordHolderMap.size() > 1) {
			Integer keyToRemove = null;
			Set<Integer> hgScrKeySet = highestScoreRecordHolderMap.keySet();
			while (hgScrKeySet.iterator().hasNext()) {
				keyToRemove = hgScrKeySet.iterator().next();
				break;
			}
			highestScoreRecordHolderMap.remove(keyToRemove);
		}

		for (HighestScoreRecordHolder hsrh : highestScoreRecordHolderMap.values()) {
			sorceRowidObject = hsrh.getPartyRowIDObject();
		}
		LOG.info("Target party rowid_object for merge: " + sorceRowidObject);

		int countOfRetry = Integer.parseInt(configProps.getProperty("NoOfRetries"));
		boolean isMergeRetrySuccess = false;
		if (!Util.isNullOrEmpty(sorceRowidObject)) {
			LOG.debug("Party Merge:: SourceROWID::" + rowidObject + ", TGTROWID::"
					+ sorceRowidObject);
		} else {
			LOG.info("No Matching Target record key found. Merge Operation not done !!");
		}

		LOG.info("Executed processMatchAndMergeParty()");
		return highestScoreRecordHolderMap;
	}

	private List matchParty(PartyXrefType partyTypeParam, SiperianClient siperianClient)
			throws ServiceProcessingException {

		LOG.info("Executing matchParty()...");

		String ruleSetName = configProps.getProperty("matchRuleSet");
		String ruleSetJPN = configProps.getProperty("matchRuleSetCustomerJPN");
		String getPkgName = configProps.getProperty("pkgName");

		List searchRecords = new ArrayList();
		SearchMatchRequest searchMatchRequest = new SearchMatchRequest();
		SearchMatchResponse searchMatchResponse = null;

		searchMatchRequest.setRecordsToReturn(100);
		searchMatchRequest.setSiperianObjectUid(getPkgName);

		if (partyTypeParam.getAddress().get(0).getCOUNTRYCD().equalsIgnoreCase("Japan")
				|| partyTypeParam.getAddress().get(0).getCOUNTRYCD().equalsIgnoreCase("JPN")
				|| partyTypeParam.getAddress().get(0).getCOUNTRYCD().equalsIgnoreCase("JP")) {
			searchMatchRequest.setMatchRuleSetUid(SiperianObjectType.MATCH_RULE_SET.makeUid(ruleSetJPN));
		} else {
			searchMatchRequest.setMatchRuleSetUid(SiperianObjectType.MATCH_RULE_SET.makeUid(ruleSetName));
		}
		searchMatchRequest.setMatchType(MatchType.AUTO);

		LOG.info("Match Rule Set: " + searchMatchRequest.getMatchRuleSetUid());
		LOG.info("Match Type :" + searchMatchRequest.getMatchType());

		Field field_name = new Field("Organization_Name");
		if (!Util.isNullOrEmpty(partyTypeParam.getPARTYNAME())) {
			field_name.setStringValue(partyTypeParam.getPARTYNAME());
			LOG.info("Field to search for :" + field_name.getName() + ':' + field_name.getStringValue());
			searchMatchRequest.addMatchColumnField(field_name);
		}

		Field field_addr1 = new Field("Address_Part1");
		StringBuilder addrLn1Ln2Concat = new StringBuilder();
		if (!Util.isNullOrEmpty(partyTypeParam.getAddress().get(0).getADDRLN1())) {
			addrLn1Ln2Concat.append(partyTypeParam.getAddress().get(0).getADDRLN1());
		}
		if (!Util.isNullOrEmpty(partyTypeParam.getAddress().get(0).getADDRLN2())) {
			addrLn1Ln2Concat.append(" ");
			addrLn1Ln2Concat.append(partyTypeParam.getAddress().get(0).getADDRLN2());
		}
		if (addrLn1Ln2Concat != null && addrLn1Ln2Concat.length() > 1) {
			field_addr1.setStringValue(addrLn1Ln2Concat.toString());
			searchMatchRequest.addMatchColumnField(field_addr1);
		}
		LOG.info("Field to search for :" + field_addr1.getName() + ':' + field_addr1.getStringValue());

		Field field_SIPPOP = new Field("SIP_POP");
		field_SIPPOP
				.setStringValue(prospectPartyDAO.getSipPopCountry(partyTypeParam.getAddress().get(0).getCOUNTRYCD()));
		searchMatchRequest.addMatchColumnField(field_SIPPOP);
		LOG.info("Field to match for :" + field_SIPPOP.getName() + ':' + field_SIPPOP.getStringValue());

		StringBuffer criteria = new StringBuffer();
		boolean firstParam = true;

		if (!Util.isNullOrEmpty(partyTypeParam.getPARTYTYPE())
				&& (partyTypeParam.getPARTYTYPE().equalsIgnoreCase("Customer")
						|| partyTypeParam.getPARTYTYPE().equalsIgnoreCase("Partner")
						|| partyTypeParam.getPARTYTYPE().equalsIgnoreCase("Reseller")
						|| partyTypeParam.getPARTYTYPE().equalsIgnoreCase("Distributor"))) {

			criteria.append(" ( PARTY_TYPE = '" + partyTypeParam.getPARTYTYPE() + "' OR PARTY_TYPE IS NULL ) ");
			firstParam = false;
		} else {
			criteria.append(" ( PARTY_TYPE in ('" + "Customer'," + "'Partner'," + "'Reseller'," + "'Distributor"
					+ "') OR PARTY_TYPE IS NULL )");
			firstParam = false;
		}

		if (!Util.isNullOrEmpty(partyTypeParam.getAddress().get(0).getCITY())) {
			if (firstParam) {
				criteria.append(" upper(CITY) = upper(q'$" + partyTypeParam.getAddress().get(0).getCITY() + "$')");
				firstParam = false;
			} else {
				criteria.append(" AND upper(CITY) = upper(q'$" + partyTypeParam.getAddress().get(0).getCITY() + "$')");
			}
		}

		if (!Util.isNullOrEmpty(partyTypeParam.getAddress().get(0).getSTATECD())) {
			if (firstParam) {
				criteria.append(" (upper(STATE_CD) = upper(q'$" + partyTypeParam.getAddress().get(0).getSTATECD()
						+ "$') OR STATE_CD IS NULL)");
				firstParam = false;
			} else {
				criteria.append(" AND (upper(STATE_CD) = upper(q'$" + partyTypeParam.getAddress().get(0).getSTATECD()
						+ "$') OR STATE_CD IS NULL)");
			}
		}

		if (!Util.isNullOrEmpty(partyTypeParam.getAddress().get(0).getCOUNTRYCD())) {
			if (firstParam) {
				criteria.append(
						" upper(COUNTRY_CD) = upper('" + partyTypeParam.getAddress().get(0).getCOUNTRYCD() + "')");
				firstParam = false;
			} else {
				criteria.append(
						" AND upper(COUNTRY_CD) = upper('" + partyTypeParam.getAddress().get(0).getCOUNTRYCD() + "')");
			}
		}

		if (!Util.isNullOrEmpty(partyTypeParam.getAddress().get(0).getADDRTYPE())) {
			if (firstParam) {
				criteria.append(" ADDR_TYPE = '" + partyTypeParam.getAddress().get(0).getADDRTYPE() + "'");
				firstParam = false;
			} else {
				criteria.append(" AND ADDR_TYPE = '" + partyTypeParam.getAddress().get(0).getADDRTYPE() + "'");
			}
		}

		if (firstParam) {
			criteria.append(" BO_CLASS_CODE = '" + "Organization" + "'");
			firstParam = false;
		} else {
			criteria.append(" AND BO_CLASS_CODE = '" + "Organization" + "'");
		}

		if (firstParam) {
			criteria.append(" CONSOLIDATION_IND <> 9 ");
			firstParam = false;
		} else {
			criteria.append(" AND CONSOLIDATION_IND <> 9 ");
		}

		LOG.info("Filter Criteria: " + criteria.toString());

		searchMatchRequest.setFilterCriteria(criteria.toString());

		LOG.info("processing SearchMatchRequest");
		searchMatchResponse = (SearchMatchResponse) siperianClient.process(searchMatchRequest);

		searchRecords = searchMatchResponse.getRecords();

		LOG.info("Completed matchParty()...");
		return searchRecords;
	}

	private Integer highestMatchScore(Map<Integer, Integer> matchScoreMap) {
		Collection<Integer> collVal = matchScoreMap.values();
		List<Integer> scoreList = new ArrayList<Integer>(collVal);
		Integer maxScore = Collections.max(scoreList);
		LOG.debug("Highest Match score " + maxScore);
		return maxScore;
	}

	private List<Integer> maxMatchScore(Map<Integer, Integer> matchScoreMap) {
		Collection<Integer> collVal = matchScoreMap.values();
		List<Integer> scoreList = new ArrayList<Integer>(collVal);
		List rowidObjs = new ArrayList(); //
		Integer maxScore = Collections.max(scoreList);
		int cnt = 0;
		for (Entry entry : matchScoreMap.entrySet()) {
			if (maxScore.equals(entry.getValue())) {
				cnt++;
				rowidObjs.add(entry.getKey());
			}
		}
		LOG.debug("No of records having highest match score " + maxScore + ": " + cnt);
		return rowidObjs;
	}

	private List<Integer> minDunsNbr(Map<Integer, Integer> dunsNbrMap) {
		Collection<Integer> collVal = dunsNbrMap.values();
		List<Integer> dunsList = new ArrayList<Integer>(collVal);
		List rowidObjs = new ArrayList(); //
		Integer minDuns = Collections.min(dunsList);
		LOG.debug("Lowest Duns Num: " + minDuns);
		int cnt = 0;
		for (Entry entry : dunsNbrMap.entrySet()) {
			if (minDuns.equals(entry.getValue())) {
				cnt++;
				rowidObjs.add(entry.getKey());
			}
		}
		LOG.debug("No of records having highest match score :" + cnt);
		return rowidObjs;
	}

	private List<Integer> minSapCustNum(Map<Integer, Integer> sapCustNumMap) {
		Collection<Integer> collVal = sapCustNumMap.values();
		List<Integer> sapList = new ArrayList<Integer>(collVal);
		List rowidObjs = new ArrayList(); //
		Integer minSap = Collections.min(sapList);
		LOG.debug("Lowest SapCustNo: " + minSap);
		int cnt = 0;
		for (Entry entry : sapCustNumMap.entrySet()) {
			if (minSap.equals(entry.getValue())) {
				cnt++;
				rowidObjs.add(entry.getKey());
			}
		}
		LOG.debug("No of records having lowest SapCustNo :" + cnt);
		return rowidObjs;
	}

	private List<Integer> searchHierarchy(List<Integer> dunsNbrMapList)
			throws SQLException, ServiceProcessingException {
		Connection jdbcConn = null;
		Statement statement = null;
		ResultSet resultSet = null;
		JDBCConnectionProvider jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
		jdbcConn = jDBCConnectionProvider.getJdbcConnectionFromDS();

		Set<Integer> rowidSet = new HashSet<Integer>();
		StringBuilder sql = new StringBuilder();
		try {
			sql.append("select ROWID_PARTY,ROWID_PARTY_2 from C_B_PARTY_REL where TRIM(ROWID_PARTY) in (");
			for (Integer inVal : dunsNbrMapList) {
				sql.append(inVal + ",");
			}
			sql.deleteCharAt(sql.length() - 1).toString();
			sql.append(") or TRIM(ROWID_PARTY_2) in (");
			for (Integer inVal : dunsNbrMapList) {
				sql.append(inVal + ",");
			}
			sql.deleteCharAt(sql.length() - 1).toString();
			sql.append(")");
			LOG.info("SQL-->" + sql);
			statement = jdbcConn.createStatement();
			resultSet = statement.executeQuery(sql.toString());
			while (resultSet.next()) {

				rowidSet.add(Integer.parseInt(resultSet.getString("ROWID_PARTY").trim()));
				rowidSet.add(Integer.parseInt(resultSet.getString("ROWID_PARTY_2").trim()));
			}
		} finally {
			try {
				// Closing connections
				if (resultSet != null)
					resultSet.close();
				if (statement != null)
					statement.close();
				if (jdbcConn != null)
					jdbcConn.close();
			} catch (SQLException sqlEx) {
				LOG.error("Error in closing resultSet/statement: " + sqlEx);
			}
		}

		List<Integer> rowidList = new ArrayList<Integer>(rowidSet);

		return rowidList;
	}
	
	private String CF_SBL_COUNTRY(String sblCountryNm) {
		return jdbcTemplate.queryForObject("select Country_Cd from MDM_COUNTRY where SIEBEL_COUNTRY_NM=?", String.class, sblCountryNm);
	}
}
