package com.mcafee.mdm.testing.junit;

import junit.framework.TestCase;

import org.apache.log4j.Logger;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:com/mcafee/mdm/testing/config/beans.xml" })
public class TestM4MBase extends TestCase{
	protected static final Logger LOG = Logger
			.getLogger(TestM4MValidateAccount.class.getName());
	static {
		System.setProperty("server.env", "DEV");
		//System.setProperty("server.env", "QA");
		//System.setProperty("server.env", "STG");
		//System.setProperty("server.env", "STG");
		//System.setProperty("server.env", "PROD");
		System.out.println("Testing in " + System.getProperty("server.env") + " Environment");
	}
	
	@Test
	public void testBase() {
	}
}
