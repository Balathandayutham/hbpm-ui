package com.mcafee.mdm.testing.junit;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.mcafee.mdm.dao.ProspectPartyDAO;
import com.mcafee.mdm.dao.pojo.PartyChildRowIdData;

@RunWith(SpringJUnit4ClassRunner.class)
public class TestM4MPropectPartyDao extends TestM4MBase {
	
	@Autowired
	private ProspectPartyDAO prospectPartyDAO;

	public void testGetMrktRecordCountWithoutDNB() {
		fail("Not yet implemented");
	}

	public void testGetPartyRowIdBySrcPkey() {
		fail("Not yet implemented");
	}

	public void testIsRootUnmerge() {
		fail("Not yet implemented");
	}
	
	@Test
	public void testGetPartyChildRowId() {
		assertTrue("prospectPartyDAO is NULL!!",
				prospectPartyDAO != null);
		Set<String> matchedRowIdList = new HashSet<String>();
		matchedRowIdList.add("18735934");
		matchedRowIdList.add("18735774");
		List<PartyChildRowIdData> partyChildRowIdDataList = prospectPartyDAO.getPartyChildRowId(matchedRowIdList);
		System.out.println("partyChildRowIdDataList::" + partyChildRowIdDataList);
	}

	public void testGetContactRowIdsFromPkeys() {
		fail("Not yet implemented");
	}

	public void testGetSipPopCountry() {
		fail("Not yet implemented");
	}

	public void testInsertPkeysInTempTable() {
		fail("Not yet implemented");
	}

	public void testDeletePkeysFromTempTable() {
		fail("Not yet implemented");
	}

	public void testCheckifUCNExists() {
		fail("Not yet implemented");
	}

	public void testGetNextUCNValue() {
		fail("Not yet implemented");
	}

	public void testGetPendingAcntCntctRel() {
		fail("Not yet implemented");
	}
	
	@Test
	public void testGetRowIdsProspectAccountWithDuns() {
		assertTrue("prospectPartyDAO is NULL!!",
				prospectPartyDAO != null);
		List<String> matchedRowIdList = new ArrayList<String>();
		matchedRowIdList.add("18735773");
		matchedRowIdList.add("18735774");
		List<String> rowIdList = prospectPartyDAO.getRowIdsProspectAccountWithDuns(matchedRowIdList);
		System.out.println("rowIdList::" + rowIdList);
	}
	
	@Test
	public void testGetRowIdsDnbSingletonAccounts() {
		assertTrue("searchProspectPartyDAO is NULL!!",
				prospectPartyDAO != null);
		List<String> matchedRowIdList = new ArrayList<String>();
		matchedRowIdList.add("18735773");
		matchedRowIdList.add("18735774");
		List<String> rowIdList = prospectPartyDAO.getRowIdsDnbSingletonAccounts(matchedRowIdList);
		System.out.println("rowIdList::" + rowIdList);
	}

	public void testGetContactsByAccountRowId() {
		fail("Not yet implemented");
	}
	
	@Test
	public void testCheckifCntctRelExists() {
		assertTrue("prospectPartyDAO is NULL!!",
				prospectPartyDAO != null);
		String relRowid = prospectPartyDAO.checkifCntctRelExists("26782954");
		System.out.println("relRowid::" + relRowid);
	}
	
	@Test
	public void testGetNameExclusionList() {
		assertTrue("prospectPartyDAO is NULL!!",
				prospectPartyDAO != null);
		Boolean isFound = prospectPartyDAO.isNameExclusionExists("Advokatfirmaet Schebye &".toUpperCase());
		System.out.println("isFound::" + isFound);
	}

}
