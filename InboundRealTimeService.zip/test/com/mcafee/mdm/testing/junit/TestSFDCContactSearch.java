package com.mcafee.mdm.testing.junit;

import java.util.HashMap;
import java.util.List;

import javax.xml.bind.JAXBException;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.mcafee.mdm.dao.ProspectPartyDAO;
import com.mcafee.mdm.dao.TrilliumCleanserDAO;
import com.mcafee.mdm.dao.TrilliumLookUpDAO;
import com.mcafee.mdm.dao.UpsertMarketingDAO;
import com.mcafee.mdm.dao.pojo.HighestScoreRecordHolder;
import com.mcafee.mdm.delegator.ServiceDelegator;
import com.mcafee.mdm.exception.ServiceProcessingException;
import com.mcafee.mdm.generated.AddressXrefType;
import com.mcafee.mdm.generated.PartySearchCriteriaType;
import com.mcafee.mdm.generated.PartyXrefType;
import com.mcafee.mdm.generated.SearchPartyRequest;
import com.mcafee.mdm.generated.SearchPartyResponse;
import com.mcafee.mdm.generated.UpsertPartyRequest;
import com.mcafee.mdm.generated.UpsertPartyResponse;
import com.mcafee.mdm.generated.XREFType;
import com.siperian.sif.client.SiperianClient;

@RunWith(SpringJUnit4ClassRunner.class)
public class TestSFDCContactSearch extends TestM4MBase{
	@Autowired
	private ServiceDelegator serviceDelegator;
	
	@Test
	public void testM4MTrilliumAccount() throws ServiceProcessingException,
			JAXBException {
		SearchPartyRequest parameters = new SearchPartyRequest();
		PartySearchCriteriaType pSearch = new PartySearchCriteriaType();
	//	parameters.setMatchScoreThresold("150");
		
		
		pSearch.setFIRSTNAME("Evan");
		pSearch.setLASTNAME("Joshi");
		pSearch.setEMAILADDRESS("evan.joshi@gmail.com");
		pSearch.setCOUNTRYCD("IN");
		
//		pSearch.setFIRSTNAME("Tie");
//		pSearch.setLASTNAME("Soumen");
//		pSearch.setEMAILADDRESS("trycatch@hotmail.com");
//		pSearch.setCOUNTRYCD("IN");
		
//		pSearch.setCONTACTSOURCEID("CMAFS000000323749");
//		pSearch.setCONTACTSOURCESYSTEM("ELQ");
		
//		pSearch.setMDMCONTACTID("112956152377");
		pSearch.setACCOUNTSOURCEID("PROSPECT-CMAFS000000323749");
		parameters.setPartySearchCriteria(pSearch);
		
		assertTrue("serviceDelegator is NULL!!", serviceDelegator != null);
		
		SearchPartyResponse response = serviceDelegator.searchPartyProfile(parameters);
		assertFalse("response is NULL!!", response == null);
	}
}
