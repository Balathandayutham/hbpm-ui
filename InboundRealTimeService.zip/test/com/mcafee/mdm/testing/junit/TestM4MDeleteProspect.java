package com.mcafee.mdm.testing.junit;

import java.util.List;
import java.util.Properties;

import javax.annotation.Resource;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.util.CollectionUtils;

import com.mcafee.mdm.constants.Constant;
import com.mcafee.mdm.dao.DeleteProspectPartyDAO;
import com.mcafee.mdm.exception.ServiceProcessingException;
import com.siperian.sif.message.RecordResult;
import com.siperian.sif.message.mrm.DeleteResponse;

@RunWith(SpringJUnit4ClassRunner.class)
public class TestM4MDeleteProspect extends TestM4MBase {
	@Autowired
	private DeleteProspectPartyDAO deleteProspectPartyDAO;
	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Resource(name = "m4mQueryProp")
	private Properties queryProp;

	@SuppressWarnings("unchecked")
	@Test
	public void testDeleteContactRel() throws ServiceProcessingException {
		assertTrue("deleteProspectPartyDAO is NULL!!",
				deleteProspectPartyDAO != null);
		String rowIdAccount = "8349651";
		List<String> originalRowIdList = jdbcTemplate
				.queryForList(queryProp
						.getProperty(Constant.QUERY_ACCOUNT_CONTACT_REL_QUERY),
						String.class, rowIdAccount);
		DeleteResponse response = deleteProspectPartyDAO
				.deleteContactRel(originalRowIdList);
		assertFalse("Delete Response is NULL", response == null);
		assertFalse("Delete Result is NULL",
				response.getDeleteResults() == null);
		assertTrue("Delete Result size not same as original", response
				.getDeleteResults().size() == originalRowIdList.size());
		if(!CollectionUtils.isEmpty(response.getDeleteResults())) {
			for(RecordResult record:(List<RecordResult>)response.getDeleteResults()) {
				assertTrue("Deletion not success for Record::" + record.getRecordKey().getRowid(), record.isSuccess());
			}
		}
	}
}
