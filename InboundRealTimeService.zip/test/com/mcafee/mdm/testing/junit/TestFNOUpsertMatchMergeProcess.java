package com.mcafee.mdm.testing.junit;

import java.io.File;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import javax.transaction.UserTransaction;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.mcafee.mdm.constants.Constant;
import com.mcafee.mdm.dao.FNOUpsertPartyDAO;
import com.mcafee.mdm.dao.GetPartyDAO;
import com.mcafee.mdm.dao.UpsertMarketingDAO;
import com.mcafee.mdm.dao.UpsertPartyDAO;
import com.mcafee.mdm.exception.ServiceProcessingException;
import com.mcafee.mdm.generated.AccountXrefType;
import com.mcafee.mdm.generated.AddressXrefType;
import com.mcafee.mdm.generated.MdmUpsertPartyRequest;
import com.mcafee.mdm.generated.MdmUpsertPartyResponse;
import com.mcafee.mdm.generated.PartyXrefType;
import com.mcafee.mdm.generated.StatusType;
import com.mcafee.mdm.generated.UpsertPartyResponse;
import com.mcafee.mdm.generated.XREFType;
import com.siperian.sif.client.EjbSiperianClient;
import com.siperian.sif.client.SiperianClient;
import com.siperian.sif.message.Field;
import com.siperian.sif.message.Record;

@RunWith(SpringJUnit4ClassRunner.class)
public class TestFNOUpsertMatchMergeProcess extends TestM4MBase{

	@Autowired
	private UpsertMarketingDAO upsertMarketingDao;
	@Autowired
	private UpsertPartyDAO upsertPartyDao;
	@Autowired
	private GetPartyDAO getPartyDAO;
	@Autowired
	private FNOUpsertPartyDAO fnoUpsertPartyDao;
	
	
	@Test
	public void testIsMatchExclusionPatternExists(){
		MdmUpsertPartyResponse upsertPartyResponse1 = new MdmUpsertPartyResponse();
		upsertPartyResponse1.setUpsertStatus(new StatusType());
		PartyXrefType request=createRequest("abcd5353abcd");
		request.setUCN("111250917162");
		try {
			fnoUpsertPartyDao.processCleansePutRequest(request, upsertPartyResponse1, false, false, null);
		} catch (ServiceProcessingException e2) {
			e2.printStackTrace();
		}
		PartyXrefType insertedPartyData = new PartyXrefType();
		boolean exclusionPatternExists = false;
		String rowidObject = null;
		try {
			insertedPartyData = getPartyDAO.fetchPartyXrefTypeFromORS(request.getXREF().get(0).getSRCSYSTEM(),
					request.getXREF().get(0).getSRCPKEY());
		} catch (ServiceProcessingException e) {
			e.printStackTrace();
		}
		rowidObject = insertedPartyData.getROWIDOBJECT();
		Method method = null;
		try {
			method = fnoUpsertPartyDao.getClass().getDeclaredMethod("isMatchExclusionPatternExists", String.class);
		} catch (NoSuchMethodException e1) {
			e1.printStackTrace();
		} catch (SecurityException e1) {
			e1.printStackTrace();
		}
		method.setAccessible(true);
		try {
			exclusionPatternExists = (Boolean) method.invoke(fnoUpsertPartyDao, rowidObject);
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			e.printStackTrace();
		}
		System.out.println("Pattern exists: " + exclusionPatternExists);
		assertTrue("true", exclusionPatternExists);
	}
	
	@Test
	public void testSearchMatch() throws Exception{
		MdmUpsertPartyResponse upsertPartyResponse1 = new MdmUpsertPartyResponse();
		upsertPartyResponse1.setUpsertStatus(new StatusType());
		PartyXrefType request=createRequest("abcd6363abcd");
		fnoUpsertPartyDao.processCleansePutRequest(request, upsertPartyResponse1, false, false, null);
		fnoUpsertPartyDao.upsertTokenize(request, upsertPartyResponse1, false, false, null);
		MdmUpsertPartyResponse upsertPartyResponse3 = new MdmUpsertPartyResponse();
		upsertPartyResponse3.setUpsertStatus(new StatusType());
		PartyXrefType request3=createRequest("abcd6565abcd");
		fnoUpsertPartyDao.processCleansePutRequest(request3, upsertPartyResponse3, false, false, null);
		fnoUpsertPartyDao.upsertTokenize(request3, upsertPartyResponse3, false, false, null);
		MdmUpsertPartyResponse upsertPartyResponse2 = new MdmUpsertPartyResponse();
		upsertPartyResponse2.setUpsertStatus(new StatusType());
		PartyXrefType request2=createRequest("abcd6464abcd");
		fnoUpsertPartyDao.processCleansePutRequest(request2, upsertPartyResponse2, false, false, null);
		fnoUpsertPartyDao.upsertTokenize(request2, upsertPartyResponse2, false, false, null);
		PartyXrefType insertedPartyData = new PartyXrefType();
		System.out.println("going to get inserted data ");
		insertedPartyData = getPartyDAO.fetchPartyXrefTypeFromORS("FNO","abcd6464abcd");
		System.out.println("inserted party datat : " + insertedPartyData);
		PartyXrefType partyXrefType = insertedPartyData;
		SiperianClient siperianClient = null;
		UserTransaction transaction = null;
		siperianClient = fnoUpsertPartyDao.checkOut();
		System.out.println("sipserian client : " + siperianClient);
		transaction = ((EjbSiperianClient) siperianClient).createTX(300000);
		transaction.begin();
		System.out.println("transactiton began");
		Method method = fnoUpsertPartyDao.getClass().getDeclaredMethod("matchParty", PartyXrefType.class, SiperianClient.class);
		method.setAccessible(true);
		System.out.println("method match party set visible ");
		List searchRecords = (List) method.invoke(fnoUpsertPartyDao, partyXrefType, siperianClient);
		int size = searchRecords.size();
		System.out.println("completed : " + searchRecords.size());
		/*for(int i =0 ; i< searchRecords.size();i++){
			Record record = (Record) searchRecords.get(i);
			record.getFields();
			Collection<String> fields = record.getFields();
			Iterator iterator = fields.iterator();
			 
	        // while loop
	        while (iterator.hasNext()) {
	        	Field f = (Field)iterator.next();
	        LOG.info("feildd value : " + f.getName() + " value : " + f.getValue());
	        }
		}*/
		assertTrue("true", (size>1));
	}

	@Test
	public void  testUpsertMatchAndMergeProcess() throws ServiceProcessingException, JAXBException{
		MdmUpsertPartyResponse upsertPartyResponse1 = new MdmUpsertPartyResponse();
		upsertPartyResponse1.setUpsertStatus(new StatusType());
		PartyXrefType request1=createRequest("abcd5151abcd");
		fnoUpsertPartyDao.processCleansePutRequest(request1, upsertPartyResponse1, false, false, null);
		MdmUpsertPartyResponse upsertPartyResponse2 = new MdmUpsertPartyResponse();
		upsertPartyResponse2.setUpsertStatus(new StatusType());
		PartyXrefType request2=createRequest("abcd5252abcd");
		fnoUpsertPartyDao.processCleansePutRequest(request2, upsertPartyResponse2, false, false, null);
		fnoUpsertPartyDao.upsertTokenize(request2, upsertPartyResponse2, false, false, null);
		fnoUpsertPartyDao.upsertMatchMergeProcess(request2, upsertPartyResponse2, false, false, null);
		/*MdmUpsertPartyRequest request = createRequest();
		PartyXrefType upsertParty = request.getParty().get(0);
		assertTrue("fnoUpsertPartyDao is NULL!!", fnoUpsertPartyDao != null);
		MdmUpsertPartyResponse upsertPartyResponse = new MdmUpsertPartyResponse();
		System.out.println("fnoUpsertPartyDao : " + fnoUpsertPartyDao);
		String rowidObject = null;
		fnoUpsertPartyDao.upsertMatchMergeProcess(upsertParty, upsertPartyResponse, false, false, rowidObject);*/
	}
		
	private PartyXrefType createRequest(String srcPkey){
		PartyXrefType request = new PartyXrefType();
		
		request.setLASTUPDATEDATE("28-02-2018 03:00:43");
		request.setSRCCREATEDT("28-02-2018 03:00:43");
		request.setUPDATEBY("admin");
		request.setPARTYTYPE("Customer");
		request.setPARTYNAME("Rajalakshmi S");
		request.setSTATUSCD("Active");
		request.setBOCLASSCODE("Organization");
		request.setMSGTRKNID("893573");
		
		XREFType xref = new XREFType();
		xref.setSRCPKEY(srcPkey);
		xref.setSRCSYSTEM("FNO");
		request.getXREF().add(xref);
		
		
		AddressXrefType address = new AddressXrefType();
		address.setSRCPKEY(srcPkey);
		address.setSRCSYSTEM("FNO");
		address.setADDRLN1("ad 1 st street");
		address.setADDRLN2("ad 2 nd street");
		address.setADDRLN3("");
		address.setCITY("Richardson");
		address.setSTATECD("SHANXI");
		address.setCOUNTRYCD("USA");
		address.setADDRSTATUS("Active");
		request.getAddress().add(address);
		
		
		AccountXrefType acc = new AccountXrefType();
		acc.setSRCPKEY(srcPkey);
		acc.setSRCSYSTEM("FNO");
		acc.setACCTNAME("Rajalakshmi S");
		acc.setACCTSTATUS("Active");
		acc.setCUSTGROUP("Payer");
		acc.setDATASRCSYSTEM("FNO");
		request.getAccount().add(acc);
		
		return request;
	}
	
	@Test
	public void testprocessMatchAndMerge() throws Exception {
		
		
//		assertTrue("upsertResponse is NULL!!", upsertResponse != null);
		assertTrue("upsertPartyDao is NULL!!", upsertPartyDao != null);
		UpsertPartyResponse upsertResponse = new UpsertPartyResponse();
		System.out.println("upsertpartyDao : " + upsertPartyDao);
	//	SiperianClient siperianClient = (SiperianClient) upsertPartyDao.checkOut();
		
		/*PartyType survivingPartyProfileFromBO = new PartyType();
		survivingPartyProfileFromBO = getPartyDAO.getBOParty("18972479");
		upsertPartyDao.mergeProcessMultipleChild(survivingPartyProfileFromBO, null);*/
		
	//	UpsertPartyResponse upsertResponse = new UpsertPartyResponse();
		//+ "\nError Message::"	+ upsertResponse.getParty().get(0).getErrorMsg());
	//	assertFalse("isValid::" + isValid, isValid);
	//	assertTrue("Incorrect Error Message::"+ upsertResponse.getParty().get(0).getErrorMsg(),"SRC Pkey not found for account with UCN".equals(upsertResponse.getParty().get(0).getErrorMsg()));
	}
}
