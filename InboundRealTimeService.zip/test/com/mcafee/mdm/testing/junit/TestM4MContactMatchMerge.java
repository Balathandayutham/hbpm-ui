package com.mcafee.mdm.testing.junit;

import java.util.HashMap;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.mcafee.mdm.dao.UpsertMarketingDAO;
import com.mcafee.mdm.dao.pojo.HighestScoreRecordHolder;
import com.mcafee.mdm.generated.PartyXrefType;
import com.mcafee.mdm.generated.XREFType;
import com.siperian.sif.client.SiperianClient;

@RunWith(SpringJUnit4ClassRunner.class)
public class TestM4MContactMatchMerge extends TestM4MBase{
	@Autowired
	private UpsertMarketingDAO upsertMarketingDao;
	
	@Test
	public void testprocessMatchAndMergeContact() throws Exception {
		assertTrue("upsertMarketingDao is NULL!!", upsertMarketingDao != null);
		SiperianClient siperianClient = (SiperianClient) upsertMarketingDao.checkOut();
		PartyXrefType partyXrefType = new PartyXrefType();
		partyXrefType.getXREF().add(new XREFType());
		partyXrefType.setPARTYNAME("Taylor DePuma");
	//	UpsertPartyResponse upsertResponse = new UpsertPartyResponse();
		String newRowid = "17738113";
		HashMap<Integer, HighestScoreRecordHolder> tempMap = upsertMarketingDao.processMatchAndMergeContact(newRowid,
				partyXrefType, siperianClient);
		LOG.debug("tempMap KeySet-->" + tempMap.keySet() );//+ "\nError Message::"	+ upsertResponse.getParty().get(0).getErrorMsg());
	//	assertFalse("isValid::" + isValid, isValid);
	//	assertTrue("Incorrect Error Message::"+ upsertResponse.getParty().get(0).getErrorMsg(),"SRC Pkey not found for account with UCN".equals(upsertResponse.getParty().get(0).getErrorMsg()));
	}
}
