package com.mcafee.mdm.testing.junit;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.mcafee.mdm.constants.Constant;
import com.mcafee.mdm.dao.AdobeUpsertPartyDAO;
import com.mcafee.mdm.exception.ServiceProcessingException;
import com.mcafee.mdm.generated.AccountXrefType;
import com.mcafee.mdm.generated.AddressXrefType;
import com.mcafee.mdm.generated.MdmUpsertPartyResponse;
import com.mcafee.mdm.generated.PartyXrefType;
import com.mcafee.mdm.generated.StatusType;
import com.mcafee.mdm.generated.XREFType;
import com.mcafee.mdm.util.ValidatorUtil;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:com/mcafee/mdm/testing/config/beans.xml" })
public class TestAdobeCheckDataQualityUpsert extends TestM4MBase {

	@Autowired
	private AdobeUpsertPartyDAO adobeUpsertPartyDAO;

	@Autowired
	private ValidatorUtil validatorUtil;
	
	@Test
	public void testValidateMsgTrackingIDWithNull() {
		MdmUpsertPartyResponse response = new MdmUpsertPartyResponse();
		PartyXrefType party = new PartyXrefType();
		party.setMSGTRKNID(null);
		XREFType xref = new XREFType();
		xref.setSRCSYSTEM("ADB");
		try {
			validatorUtil.validateMsgTrackingId(party, response,false);
		} catch (ServiceProcessingException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
		}
		assertEquals(Constant.ERROR_ACCOUNT_MSG_TRKN_ID_VALIDATION, response.getUpsertStatus().getErrorCode());
	}

	@Test
	public void testupsertDataValidationWithInvalidBOCLASSCODE() {
		MdmUpsertPartyResponse response = new MdmUpsertPartyResponse();
		PartyXrefType party = new PartyXrefType();
		party.setBOCLASSCODE("Party");
		party.setMSGTRKNID("a0Lq0000006pbPBEAY");
		XREFType xref = new XREFType();
		xref.setSRCSYSTEM("ADB");
		StatusType upsertStatus = new StatusType();
		response.setUpsertStatus(upsertStatus);
		try {
			adobeUpsertPartyDAO.upsertDataValidation(party, response, false, false, "0");
		} catch (ServiceProcessingException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
		}
		assertEquals(Constant.ERROR_ACCOUNT_WRONG_ORG, response.getUpsertStatus().getErrorCode());
	}

	@Test
	public void testupsertDataValidationWithvalidBOCLASSCODE() throws ServiceProcessingException {
		MdmUpsertPartyResponse response = new MdmUpsertPartyResponse();
		PartyXrefType party = new PartyXrefType();
		party.setBOCLASSCODE("Organization");
		party.setPARTYTYPE("Reseller");
		StatusType upsertStatus = new StatusType();
		response.setUpsertStatus(upsertStatus);
		try {
		adobeUpsertPartyDAO.upsertDataValidation(party, response, false, false, "0");
		} catch (ServiceProcessingException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
		}
		System.out.println("actual error code : " + response.getUpsertStatus().getErrorCode());
		System.out.println("expected  error code  : " + Constant.ERROR_ACCOUNT_WRONG_ORG);
		assertFalse("Valid BO class code",
				Constant.ERROR_ACCOUNT_WRONG_ORG.equals(response.getUpsertStatus().getErrorCode()));
	}
	
	@Test
	public void testupsertDataValidationWithValidPartyType() throws ServiceProcessingException {
		MdmUpsertPartyResponse response = new MdmUpsertPartyResponse();
		PartyXrefType party = new PartyXrefType();
		party.setBOCLASSCODE("Organization");
		party.setPARTYTYPE("Prospect Customer");
		StatusType upsertStatus = new StatusType();
		response.setUpsertStatus(upsertStatus);
		adobeUpsertPartyDAO.upsertDataValidation(party, response, false, false, "0");
		System.out.println("actual error code : " + response.getUpsertStatus().getErrorCode());
		System.out.println("expected  error code  : " + Constant.ERROR_ACCOUNT_INVALID_PTY_TYP);
		assertFalse("Valid Customer group",
				Constant.ERROR_ACCOUNT_INVALID_PTY_TYP.equals(response.getUpsertStatus().getErrorCode()));
	}

	@Test
	public void testupsertDataValidationWithInvalidPartyType() {
		MdmUpsertPartyResponse response = new MdmUpsertPartyResponse();
		PartyXrefType party = new PartyXrefType();
		party.setBOCLASSCODE("Organization");
		party.setPARTYTYPE("Self-Registered User");
		StatusType upsertStatus = new StatusType();
		response.setUpsertStatus(upsertStatus);
		try {
			adobeUpsertPartyDAO.upsertDataValidation(party, response, false, false, "0");
		} catch (ServiceProcessingException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
		}
		assertTrue("Valid Customer group",
				Constant.ERROR_ACCOUNT_INVALID_PTY_TYP.equals(response.getUpsertStatus().getErrorCode()));
	}
	
	@Test
	public void testValidateAccountNameWithNULL() {
		PartyXrefType upsertParty = new PartyXrefType();
		XREFType xref = new XREFType();
		xref.setSRCPKEY("001q000000lvgXKAAY");
		upsertParty.getXREF().add(xref);
		upsertParty.setPARTYNAME(null);
		MdmUpsertPartyResponse upsertPartyResponse = new MdmUpsertPartyResponse();
		StatusType statusType = new StatusType();
		MdmUpsertPartyResponse upsertPartyProspectResponse = new MdmUpsertPartyResponse();
		upsertPartyResponse.setUpsertStatus(statusType);
		upsertPartyProspectResponse.setUpsertStatus(statusType);
		boolean retry = false;
		boolean executeNextStep = false;
		String rowidObject = null;
		try {
			adobeUpsertPartyDAO.checkDataQualityUpsert(upsertParty, upsertPartyResponse, retry, executeNextStep,
					rowidObject);
			/*adobeProspectCustomerDAO.checkDataQualityUpsert(upsertParty, upsertPartyProspectResponse, retry,
					executeNextStep, rowidObject);*/
		} catch (ServiceProcessingException e) {
			e.printStackTrace();
		}
		assertTrue("Account name is null",
				Constant.ERROR_ACCOUNT_NAME_UNKWN.equals(upsertPartyResponse.getUpsertStatus().getErrorCode()));
	}

	@Test
	public void testValidateAccountNameWithEmpty() {
		PartyXrefType upsertParty = new PartyXrefType();
		XREFType xref = new XREFType();
		xref.setSRCPKEY("001q000000lvgXKAAY");
		upsertParty.getXREF().add(xref);
		upsertParty.setPARTYNAME("");
		MdmUpsertPartyResponse upsertPartyResponse = new MdmUpsertPartyResponse();
		StatusType statusType = new StatusType();
		upsertPartyResponse.setUpsertStatus(statusType);
		boolean retry = false;
		boolean executeNextStep = false;
		String rowidObject = null;
		try {
			adobeUpsertPartyDAO.checkDataQualityUpsert(upsertParty, upsertPartyResponse, retry, executeNextStep,
					rowidObject);
		} catch (ServiceProcessingException e) {
			e.printStackTrace();
		}
		assertTrue("Account name is empty",
				Constant.ERROR_ACCOUNT_NAME_UNKWN.equals(upsertPartyResponse.getUpsertStatus().getErrorCode()));
	}

	@Test
	public void testValidateAccountNameWithUnknownValue() {
		PartyXrefType upsertParty = new PartyXrefType();
		XREFType xref = new XREFType();
		xref.setSRCPKEY("001q000000lvgXKAAY");
		upsertParty.getXREF().add(xref);
		upsertParty.setPARTYNAME("Unknown");
		MdmUpsertPartyResponse upsertPartyResponse = new MdmUpsertPartyResponse();
		StatusType statusType = new StatusType();
		upsertPartyResponse.setUpsertStatus(statusType);
		boolean retry = false;
		boolean executeNextStep = false;
		String rowidObject = null;
		try {
			adobeUpsertPartyDAO.checkDataQualityUpsert(upsertParty, upsertPartyResponse, retry, executeNextStep,
					rowidObject);
		} catch (ServiceProcessingException e) {
			e.printStackTrace();
		}
		assertTrue("Account name is unknown",
				Constant.ERROR_ACCOUNT_NAME_UNKWN.equals(upsertPartyResponse.getUpsertStatus().getErrorCode()));
	}

	@Test
	public void testValidateAccountNameWithJunkValue() {
		PartyXrefType upsertParty = new PartyXrefType();
		XREFType xref = new XREFType();
		xref.setSRCPKEY("001q000000lvgXKAAY");
		upsertParty.getXREF().add(xref);
		upsertParty.setPARTYNAME("fdfdf");
		MdmUpsertPartyResponse upsertPartyResponse = new MdmUpsertPartyResponse();
		StatusType statusType = new StatusType();
		MdmUpsertPartyResponse upsertPartyProspectResponse = new MdmUpsertPartyResponse();
		upsertPartyProspectResponse.setUpsertStatus(statusType);
		upsertPartyResponse.setUpsertStatus(statusType);
		boolean retry = false;
		boolean executeNextStep = false;
		String rowidObject = null;
		try {
			adobeUpsertPartyDAO.checkDataQualityUpsert(upsertParty, upsertPartyResponse, retry, executeNextStep,
					rowidObject);
			//adobeProspectCustomerDAO.checkDataQualityUpsert(upsertParty, upsertPartyProspectResponse, retry,executeNextStep, rowidObject);
		} catch (ServiceProcessingException e) {
			e.printStackTrace();
		}
		assertTrue("Account name is junk", Constant.ERROR_ACCOUNT_NAME_UNKWN.equals(upsertPartyResponse.getErrorCd()));
	}

	/**
	 * Checks whether addressline1 is null (which also checks empty and unknown)
	 */
	@Test
	public void testValidateAccountAddressLine1Null() {
		PartyXrefType upsertParty = new PartyXrefType();
		XREFType xref = new XREFType();
		xref.setSRCPKEY("001q000000lvgXKAAY");
		upsertParty.getXREF().add(xref);
		upsertParty.setPARTYNAME("raj");
		AddressXrefType address = new AddressXrefType();
		upsertParty.getAddress().add(address);
		upsertParty.getAddress().get(0).setADDRLN1(null);
		MdmUpsertPartyResponse upsertPartyResponse = new MdmUpsertPartyResponse();
		StatusType statusType = new StatusType();
		MdmUpsertPartyResponse upsertPartyProspectResponse = new MdmUpsertPartyResponse();
		upsertPartyProspectResponse.setUpsertStatus(statusType);
		upsertPartyResponse.setUpsertStatus(statusType);
		boolean retry = false;
		boolean executeNextStep = false;
		String rowidObject = null;
		try {
			adobeUpsertPartyDAO.checkDataQualityUpsert(upsertParty, upsertPartyResponse, retry, executeNextStep,
					rowidObject);
			//adobeProspectCustomerDAO.checkDataQualityUpsert(upsertParty, upsertPartyProspectResponse, retry, executeNextStep, rowidObject);
		} catch (ServiceProcessingException e) {
			e.printStackTrace();
		}
		assertTrue("Account address line1 is either null or empty or unknown",
				Constant.ERROR_ACCOUNT_ADDR_INVALID.equals(upsertPartyResponse.getErrorCd()));

	}

	@Test
	public void testValidateAccountAddressCityNull() {
		PartyXrefType upsertParty = new PartyXrefType();
		XREFType xref = new XREFType();
		xref.setSRCPKEY("001q000000lvgXKAAY");
		upsertParty.getXREF().add(xref);
		upsertParty.setPARTYNAME("raj");
		AddressXrefType address = new AddressXrefType();
		upsertParty.getAddress().add(address);
		upsertParty.getAddress().get(0).setADDRLN1("Bussy Street");
		upsertParty.getAddress().get(0).setCITY(null);
		MdmUpsertPartyResponse upsertPartyResponse = new MdmUpsertPartyResponse();
		StatusType statusType = new StatusType();
		MdmUpsertPartyResponse upsertPartyProspectResponse = new MdmUpsertPartyResponse();
		upsertPartyProspectResponse.setUpsertStatus(statusType);
		upsertPartyResponse.setUpsertStatus(statusType);
		boolean retry = false;
		boolean executeNextStep = false;
		String rowidObject = null;
		try {
			adobeUpsertPartyDAO.checkDataQualityUpsert(upsertParty, upsertPartyResponse, retry, executeNextStep,
					rowidObject);
			//adobeProspectCustomerDAO.checkDataQualityUpsert(upsertParty, upsertPartyProspectResponse, retry, executeNextStep, rowidObject);
		} catch (ServiceProcessingException e) {
			e.printStackTrace();
		}
		assertTrue("Account address city is either null or empty or unknown",
				Constant.ERROR_ACCOUNT_ADDR_INVALID.equals(upsertPartyResponse.getErrorCd()));

	}

	/*@Test
	public void testValidateAccountAddressStateNull() {
		PartyXrefType upsertParty = new PartyXrefType();
		XREFType xref = new XREFType();
		xref.setSRCPKEY("001q000000lvgXKAAY");
		upsertParty.getXREF().add(xref);
		upsertParty.setPARTYNAME("raj");
		AddressXrefType address = new AddressXrefType();
		upsertParty.getAddress().add(address);
		upsertParty.getAddress().get(0).setADDRLN1("Bussy Street");
		upsertParty.getAddress().get(0).setCITY("Chennai");
		upsertParty.getAddress().get(0).setSTATECD(null);
		MdmUpsertPartyResponse upsertPartyResponse = new MdmUpsertPartyResponse();
		StatusType statusType = new StatusType();
		upsertPartyResponse.setUpsertStatus(statusType);
		boolean retry = false;
		boolean executeNextStep = false;
		String rowidObject = null;
		try {
			adobeUpsertPartyDAO.checkDataQualityUpsert(upsertParty, upsertPartyResponse, retry, executeNextStep,
					rowidObject);
		} catch (ServiceProcessingException e) {
			e.printStackTrace();
		}
		assertTrue("Account address state is either null or empty or unknown",
				Constant.ERROR_ACCOUNT_ADDR_INVALID.equals(upsertPartyResponse.getErrorCd()));

	}
*/
/*	@Test
	public void testValidateAccountAddressCountryNull() {
		PartyXrefType upsertParty = new PartyXrefType();
		XREFType xref = new XREFType();
		xref.setSRCPKEY("001q000000lvgXKAAY");
		upsertParty.getXREF().add(xref);
		upsertParty.setPARTYNAME("raj");
		AddressXrefType address = new AddressXrefType();
		upsertParty.getAddress().add(address);
		upsertParty.getAddress().get(0).setADDRLN1("Bussy Street");
		upsertParty.getAddress().get(0).setCITY("Chennai");
		upsertParty.getAddress().get(0).setSTATECD("TamilNadu");
		upsertParty.getAddress().get(0).setCOUNTRYCD(null);
		MdmUpsertPartyResponse upsertPartyResponse = new MdmUpsertPartyResponse();
		StatusType statusType = new StatusType();
		upsertPartyResponse.setUpsertStatus(statusType);
		boolean retry = false;
		boolean executeNextStep = false;
		String rowidObject = null;
		try {
			adobeUpsertPartyDAO.checkDataQualityUpsert(upsertParty, upsertPartyResponse, retry, executeNextStep,
					rowidObject);
		} catch (ServiceProcessingException e) {
			e.printStackTrace();
		}
		assertTrue("Account address country is either null or empty or unknown",
				Constant.ERROR_ACCOUNT_ADDR_INVALID.equals(upsertPartyResponse.getErrorCd()));

	}*/

	/*@Test
	public void testValidateAccountAddressPostalCodeNull() {
		PartyXrefType upsertParty = new PartyXrefType();
		XREFType xref = new XREFType();
		xref.setSRCPKEY("001q000000lvgXKAAY");
		upsertParty.getXREF().add(xref);
		upsertParty.setPARTYNAME("raj");
		AddressXrefType address = new AddressXrefType();
		upsertParty.getAddress().add(address);
		upsertParty.getAddress().get(0).setADDRLN1("Bussy Street");
		upsertParty.getAddress().get(0).setCITY("Chennai");
		upsertParty.getAddress().get(0).setSTATECD("TamilNadu");
		upsertParty.getAddress().get(0).setCOUNTRYCD("India");
		upsertParty.getAddress().get(0).setPOSTALCD(null);
		MdmUpsertPartyResponse upsertPartyResponse = new MdmUpsertPartyResponse();
		StatusType statusType = new StatusType();
		upsertPartyResponse.setUpsertStatus(statusType);
		boolean retry = false;
		boolean executeNextStep = false;
		String rowidObject = null;
		try {
			adobeUpsertPartyDAO.checkDataQualityUpsert(upsertParty, upsertPartyResponse, retry, executeNextStep,
					rowidObject);
		} catch (ServiceProcessingException e) {
			e.printStackTrace();
		}
		assertTrue("Account address postal code is either null or empty or unknown",
				Constant.ERROR_ACCOUNT_ADDR_INVALID.equals(upsertPartyResponse.getErrorCd()));

	}*/

	@Test
	public void testValidateAccountAddressAddressLine1Junk() {
		PartyXrefType upsertParty = new PartyXrefType();
		XREFType xref = new XREFType();
		xref.setSRCPKEY("001q000000lvgXKAAY");
		upsertParty.getXREF().add(xref);
		upsertParty.setPARTYNAME("raj");
		AddressXrefType address = new AddressXrefType();
		upsertParty.getAddress().add(address);
		upsertParty.getAddress().get(0).setADDRLN1("*");
		upsertParty.getAddress().get(0).setCITY("Chennai");
		upsertParty.getAddress().get(0).setSTATECD("TamilNadu");
		upsertParty.getAddress().get(0).setCOUNTRYCD("India");
		upsertParty.getAddress().get(0).setPOSTALCD("142 32");
		MdmUpsertPartyResponse upsertPartyResponse = new MdmUpsertPartyResponse();
		StatusType statusType = new StatusType();
		MdmUpsertPartyResponse upsertPartyProspectResponse = new MdmUpsertPartyResponse();
		upsertPartyProspectResponse.setUpsertStatus(statusType);
		upsertPartyResponse.setUpsertStatus(statusType);
		boolean retry = false;
		boolean executeNextStep = false;
		String rowidObject = null;
		try {
			adobeUpsertPartyDAO.checkDataQualityUpsert(upsertParty, upsertPartyResponse, retry, executeNextStep,
					rowidObject);
			//adobeProspectCustomerDAO.checkDataQualityUpsert(upsertParty, upsertPartyProspectResponse, retry, executeNextStep, rowidObject);
		} catch (ServiceProcessingException e) {
			e.printStackTrace();
		}
		assertTrue("Account address line1 is junk",
				Constant.ERROR_ACCOUNT_ADDR_LN1_UNKWN.equals(upsertPartyResponse.getErrorCd()));

	}

	@Test
	public void testValidateAccountAddressCityJunk() {
		PartyXrefType upsertParty = new PartyXrefType();
		XREFType xref = new XREFType();
		xref.setSRCPKEY("001q000000lvgXKAAY");
		upsertParty.getXREF().add(xref);
		upsertParty.setPARTYNAME("raj");
		AddressXrefType address = new AddressXrefType();
		upsertParty.getAddress().add(address);
		upsertParty.getAddress().get(0).setADDRLN1("Bussy Street");
		upsertParty.getAddress().get(0).setCITY("???");
		upsertParty.getAddress().get(0).setSTATECD("TamilNadu");
		upsertParty.getAddress().get(0).setCOUNTRYCD("India");
		upsertParty.getAddress().get(0).setPOSTALCD("142 32");
		MdmUpsertPartyResponse upsertPartyResponse = new MdmUpsertPartyResponse();
		StatusType statusType = new StatusType();
		MdmUpsertPartyResponse upsertPartyProspectResponse = new MdmUpsertPartyResponse();
		upsertPartyProspectResponse.setUpsertStatus(statusType);
		upsertPartyResponse.setUpsertStatus(statusType);
		boolean retry = false;
		boolean executeNextStep = false;
		String rowidObject = null;
		try {
			adobeUpsertPartyDAO.checkDataQualityUpsert(upsertParty, upsertPartyResponse, retry, executeNextStep,
					rowidObject);
			//adobeProspectCustomerDAO.checkDataQualityUpsert(upsertParty, upsertPartyProspectResponse, retry, executeNextStep, rowidObject);
		} catch (ServiceProcessingException e) {
			e.printStackTrace();
		}
		assertTrue("Account adrress city is either junk",
				Constant.ERROR_ACCOUNT_CITY_UNKWN.equals(upsertPartyResponse.getErrorCd()));

	}

}
