package com.mcafee.mdm.testing.junit;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.xml.bind.JAXBException;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.mcafee.mdm.constants.Constant;
import com.mcafee.mdm.dao.AdobeUpsertPartyDAO;
import com.mcafee.mdm.dao.FNOUpsertPartyDAO;
import com.mcafee.mdm.dao.SearchPartyDAO;
import com.mcafee.mdm.dao.SearchProspectPartyDAO;
import com.mcafee.mdm.exception.ServiceProcessingException;
import com.mcafee.mdm.generated.AccountXrefType;
import com.mcafee.mdm.generated.AddressXrefType;
import com.mcafee.mdm.generated.MdmUpsertPartyResponse;
import com.mcafee.mdm.generated.PartyXrefType;
import com.mcafee.mdm.generated.StatusType;
import com.mcafee.mdm.generated.XREFType;

public class TestAdobeSearchMatch extends TestM4MBase{

	@Autowired
	AdobeUpsertPartyDAO adobeUpsertPartyDAO;
	
	@Autowired
	SearchPartyDAO searchPartyDAO;
	
	@Autowired
	private SearchProspectPartyDAO searchProspectPartyDAO;
	
	@Autowired
	private FNOUpsertPartyDAO fnoUpsertPartyDao;
	
	//CUSTOMER DEDUPLICATION RULESET with rowid 39077453
	@Test
	public void testAdodeProspectMatch(){
		String rowid = getNewlyInsertedRowId();
		PartyXrefType partyXrefType = new PartyXrefType();
		System.out.println("rowid : " + rowid);
		
		// Testing rule No. 2
		System.out.println("TESTING MATCH RULE 2 CUSTOMER DEDUPLICATION RULESET");
		System.out.println("===============================================================================================================================================================");
		partyXrefType = createADBRequest("sear54321adob","ADB","Prospect Customer","Organization","Mridhulla","Mridhulla Street","Eleventh Street","New York","New York","US","678457","Active","65876");
		Set<String> rowIdMap = new HashSet<String>();
		try {
			rowIdMap = searchProspectPartyDAO.findStrictMatchProspect(partyXrefType,"123");
		} catch (ServiceProcessingException e) {
			e.printStackTrace();
		}
		assertSearchMatch(rowIdMap,"2");
		System.out.println("===============================================================================================================================================================");

		// Testing rule No. 3
		System.out.println("TESTING MATCH RULE 3 CUSTOMER DEDUPLICATION RULESET");
		System.out.println("===============================================================================================================================================================");
		partyXrefType = createADBRequest("sear54321adob","ADB","Prospect Customer","Organization","Mridhulla","Mridhulla Street","Eleventh Street","New York",null,"US","678457","Active","65876");
		rowIdMap = new HashSet<String>();
		try {
			rowIdMap = searchProspectPartyDAO.findStrictMatchProspect(partyXrefType,"123");
		} catch (ServiceProcessingException e) {
			e.printStackTrace();
		}
		assertSearchMatch(rowIdMap,"3");
		System.out.println("===============================================================================================================================================================");

		// Testing rule No. 4
		System.out.println("TESTING MATCH RULE 4 CUSTOMER DEDUPLICATION RULESET");
		System.out.println("===============================================================================================================================================================");
		partyXrefType = createADBRequest("sear54321adob","ADB","Prospect Customer","Organization","Mridhullaa","Mridhulla Street","Eleventh Street","New York","New York","US","678457","Active","65876");
		rowIdMap = new HashSet<String>();
		try {
			rowIdMap = searchProspectPartyDAO.findStrictMatchProspect(partyXrefType,"123");
		} catch (ServiceProcessingException e) {
			e.printStackTrace();
		}
		assertSearchMatch(rowIdMap,"4");
		System.out.println("===============================================================================================================================================================");
		
		// Testing rule No. 5
		System.out.println("TESTING MATCH RULE 5 CUSTOMER DEDUPLICATION RULESET");
		System.out.println("===============================================================================================================================================================");
		partyXrefType = createADBRequest("sear54321adob","ADB","Prospect Customer","Organization","Mridhulla","Mridhulla Street","Eleventh Stree","New York","New York","US","678457","Active","65876");
		rowIdMap = new HashSet<String>();
		try {
			rowIdMap = searchProspectPartyDAO.findStrictMatchProspect(partyXrefType,"123");
		} catch (ServiceProcessingException e) {
			e.printStackTrace();
		}
		assertSearchMatch(rowIdMap,"5");
		System.out.println("===============================================================================================================================================================");

		// Testing rule No. 6
		System.out.println("TESTING MATCH RULE 6 CUSTOMER DEDUPLICATION RULESET");
		System.out.println("===============================================================================================================================================================");
		partyXrefType = createADBRequest("sear54321adob","ADB","Prospect Customer","Organization","Mridhullas","Mridhulla Street","Eleventh Street","New York",null,"US","678457","Active","65876");
		rowIdMap = new HashSet<String>();
		try {
			rowIdMap = searchProspectPartyDAO.findStrictMatchProspect(partyXrefType,"123");
		} catch (ServiceProcessingException e) {
			e.printStackTrace();
		}
		assertSearchMatch(rowIdMap, "6");
		System.out.println("===============================================================================================================================================================");

		// Testing rule No. 7
		System.out.println("TESTING MATCH RULE 7 CUSTOMER DEDUPLICATION RULESET");
		System.out.println("===============================================================================================================================================================");
		partyXrefType = createADBRequest("sear54321adob","ADB","Prospect Customer","Organization","Mridhullaa","Mridhulla Street","Eleventh St",null,"New York","US","678457","Active","65876");
		rowIdMap = new HashSet<String>();
		try {
			rowIdMap = searchProspectPartyDAO.findStrictMatchProspect(partyXrefType,"123");
		} catch (ServiceProcessingException e) {
			e.printStackTrace();
		}
		assertSearchMatch(rowIdMap, "7");
		System.out.println("===============================================================================================================================================================");

		// Testing rule No. 1
		System.out.println("TESTING MATCH RULE 1 CUSTOMER DEDUPLICATION RULESET");
		System.out.println("===============================================================================================================================================================");
		partyXrefType = createADBRequest("sear54321adob","ADB","Prospect Customer","Organization","Meruniya","Meruniya Street","Tenth Street","East Coast","East Coast","US","678457","Active","112958466341");
		rowIdMap = new HashSet<String>();
		try {
			rowIdMap = searchProspectPartyDAO.findStrictMatchProspect(partyXrefType,"123");
		} catch (ServiceProcessingException e) {
			e.printStackTrace();
		}
		assertSearchMatch(rowIdMap, "1");
		System.out.println("===============================================================================================================================================================");
	}
	
	private void assertSearchMatch(Set<String> rowIdMap, String ruleNo){
		if(rowIdMap != null){
			assertTrue("true", (rowIdMap.size() == 1));
			System.out.println("rowid :"+rowIdMap.size());
			System.out.println("rowid matched for rule No. : "+ ruleNo + " for : "+ rowIdMap.toString()+":");
			assertTrue("Searched record found for rule No. : "+ruleNo, (rowIdMap.size()==1));
			}else{
				assertTrue("No searched record found for ruleNo :"+ ruleNo, (rowIdMap != null));
			}
	}
	
	public String getNewlyInsertedRowId(){
		PartyXrefType partyXrefType = new PartyXrefType();
		MdmUpsertPartyResponse upsertPartyResponse = new MdmUpsertPartyResponse();
		String rowid_object = null;
		upsertPartyResponse.setUpsertStatus(new StatusType());
		partyXrefType = createADBRequest("sear54321adob","ADB","Prospect Customer","Organization","Mridhulla","Mridhulla Street","Eleventh Street","New York","New York","US","678457","Active","65876");
		Method method = null;
		try {
			try {
				method = adobeUpsertPartyDAO.getClass().getDeclaredMethod("processCleansePutRequest", PartyXrefType.class, MdmUpsertPartyResponse.class, boolean.class, boolean.class, String.class);
			} catch (NoSuchMethodException | SecurityException e) {
				e.printStackTrace();
			}
			method.setAccessible(true);
			try {
				method.invoke(adobeUpsertPartyDAO, partyXrefType, upsertPartyResponse, false, false, null);
			} catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
				e.printStackTrace();
			}
			rowid_object = searchPartyDAO.getPartyRowidObject(partyXrefType.getXREF().get(0).getSRCPKEY(), partyXrefType.getXREF().get(0).getSRCSYSTEM());
		} catch (ServiceProcessingException e) {
			e.printStackTrace();
		}
		return rowid_object;
	}
	
	private PartyXrefType createADBRequest(String srcPkey,String srcSystem, String partyType, String boclasscode, String partyName, String addressLine1, String addressLine2, String city, String stateCd, String countryCd, String msgTrkId, String statusCd,String ucn) {
		PartyXrefType request = new PartyXrefType();
		request.setLASTUPDATEDATE("28-02-2018 03:00:43");
		request.setSRCCREATEDT("28-02-2018 03:00:43");
		request.setUPDATEBY("admin");
		request.setPARTYTYPE(partyType);
		request.setPARTYNAME(partyName);
		request.setSTATUSCD(statusCd);
		request.setBOCLASSCODE(boclasscode);
		request.setMSGTRKNID(msgTrkId);
		request.setUCN(ucn);

		XREFType xref = new XREFType();
		xref.setSRCPKEY(srcPkey);
		xref.setSRCSYSTEM(srcSystem);
		request.getXREF().add(xref);

		AddressXrefType address = new AddressXrefType();
		address.setSRCSYSTEM(srcSystem);
		address.setADDRLN1(addressLine1);
		address.setADDRLN2(addressLine2);
		address.setADDRLN3(null);
		address.setCITY(city);
		address.setSTATECD(stateCd);
		address.setCOUNTRYCD(countryCd);
		address.setADDRSTATUS(statusCd);
		if("Customer".equalsIgnoreCase(partyType))
			address.setADDRTYPE("Billing");
		else
			address.setADDRTYPE("Mailing");
		request.getAddress().add(address);

		AccountXrefType acc = new AccountXrefType();
		acc.setSRCSYSTEM(srcSystem);
		acc.setACCTNAME(partyName);
		request.getAccount().add(acc);

		return request;
	}
	
	
	//PROSPECT WIDE MATCH RULE SET with 39077470
	@Test
	public void testAdobeMultiGeoMatch() throws ServiceProcessingException, JAXBException {
		MdmUpsertPartyResponse upsertPartyResponse1 = new MdmUpsertPartyResponse();
		upsertPartyResponse1.setUpsertStatus(new StatusType());
		String rowid_object = null;
		PartyXrefType request = createFNORequest("adob5151fno");
		//fnoUpsertPartyDao.processCleansePutRequest(request, upsertPartyResponse1, false, false, null);
		//fnoUpsertPartyDao.upsertTokenize(request, upsertPartyResponse1, false, false, null);
		//fnoUpsertPartyDao.upsertUCNStampProcess(request, upsertPartyResponse1, false, false, null);
		rowid_object = searchPartyDAO.getPartyRowidObject(request.getXREF().get(0).getSRCPKEY(), request.getXREF().get(0).getSRCSYSTEM());
		System.out.println("newly inserted rowid_object : " + rowid_object);
		PartyXrefType partyXrefType = new PartyXrefType();
		Map<String, List<String>> rowIdMap = null;
		
		// Testing Dnb SINGLETON         4569204
		System.out.println("TESTING DNB SINGLETON");
		System.out.println("===============================================================================================================================================================");
		partyXrefType = createADBRequest("sear54321adob","ADB",null,"Organization","Van Nu Technology Inc","2155 Highway 1187",null,"Mansfield","Texas","US","678457","Active","65876");
		rowIdMap = new HashMap<String, List<String>>();
		rowIdMap = searchProspectPartyDAO.findMultiGeoMatch(partyXrefType); 
		System.out.println("rowid map size" + rowIdMap.size());
		assertTrue("true", (rowIdMap.size() == 1));
		System.out.println("rowIdMap rowid : :" + rowIdMap.get(Constant.CURRENT_SINGLETON_OR_PROSPECT_DUNS_PARTY).get(0)+":");
		assertTrue("true", (rowIdMap.get(Constant.CURRENT_SINGLETON_OR_PROSPECT_DUNS_PARTY).get(0).trim().equals("4569204")));
		System.out.println("===============================================================================================================================================================");

		
		// Testing rule No. 1
		System.out.println("TESTING MATCH RULE 1 PROSPECT WIDE MATCH RULE SET");
		System.out.println("===============================================================================================================================================================");
		partyXrefType = createADBRequest("sear54321adob","ADB","Prospect Customer","Organization","SherlockDen","ad 1 st street","ad 2 nd street","New York","New York","US","678457","Active","65876");
		rowIdMap = new HashMap<String, List<String>>();
		rowIdMap = searchProspectPartyDAO.findMultiGeoMatch(partyXrefType);
		assertTrue("true", (rowIdMap.size() == 1));
		System.out.println("rowIdMap rowid : :" + rowIdMap.get(Constant.CURRENT_ACTIVE_PARTY).get(0)+":");
		assertTrue("true", (rowIdMap.get(Constant.CURRENT_ACTIVE_PARTY).get(0).trim().equals(rowid_object.trim())));
		System.out.println("===============================================================================================================================================================");
	
		// Testing rule No. 2
		System.out.println("TESTING MATCH RULE 2 PROSPECT WIDE MATCH RULE SET");
		System.out.println("===============================================================================================================================================================");
		partyXrefType = createADBRequest("sear54321adob","ADB","Prospect Customer","Organization","SherlockDen","ad 1 st street","ad 2 nd street","New York",null,"US","678457","Active","65876");
		rowIdMap = new HashMap<String, List<String>>();
		rowIdMap = searchProspectPartyDAO.findMultiGeoMatch(partyXrefType);
		assertTrue("true", (rowIdMap.size() == 1));
		System.out.println("rowIdMap rowid : :" + rowIdMap.get(Constant.CURRENT_ACTIVE_PARTY).get(0)+":");
		assertTrue("true", (rowIdMap.get(Constant.CURRENT_ACTIVE_PARTY).get(0).trim().equals(rowid_object.trim())));
		System.out.println("===============================================================================================================================================================");
		
		// Testing rule No. 3
		System.out.println("TESTING MATCH RULE 3 PROSPECT WIDE MATCH RULE SET");
		System.out.println("===============================================================================================================================================================");
		partyXrefType = createADBRequest("sear54321adob","ADB","Prospect Customer","Organization","SherlockDens","ad 1 st street","ad 2 nd street","New York",null,"US","678457","Active","65876");
		rowIdMap = new HashMap<String, List<String>>();
		rowIdMap = searchProspectPartyDAO.findMultiGeoMatch(partyXrefType);
		assertTrue("true", (rowIdMap.size() == 1));
		System.out.println("rowIdMap rowid : :" + rowIdMap.get(Constant.CURRENT_ACTIVE_PARTY).get(0)+":");
		assertTrue("true", (rowIdMap.get(Constant.CURRENT_ACTIVE_PARTY).get(0).trim().equals(rowid_object.trim())));
		System.out.println("===============================================================================================================================================================");

		// Testing rule No. 4
		System.out.println("TESTING MATCH RULE 4 PROSPECT WIDE MATCH RULE SET");
		System.out.println("===============================================================================================================================================================");
		partyXrefType = createADBRequest("sear54321adob","ADB","Prospect Customer","Organization","SherlockDens","ad 1 st street","ad 2 nd st","New York",null,"US","678457","Active","65876");
		rowIdMap = new HashMap<String, List<String>>();
		rowIdMap = searchProspectPartyDAO.findMultiGeoMatch(partyXrefType);
		assertTrue("true", (rowIdMap.size() == 1));
		System.out.println("rowIdMap rowid : :" + rowIdMap.get(Constant.CURRENT_ACTIVE_PARTY).get(0)+":");
		assertTrue("true", (rowIdMap.get(Constant.CURRENT_ACTIVE_PARTY).get(0).trim().equals(rowid_object.trim())));
		System.out.println("===============================================================================================================================================================");


		// Testing rule No. 5
		System.out.println("TESTING MATCH RULE 5 PROSPECT WIDE MATCH RULE SET");
		System.out.println("===============================================================================================================================================================");
		partyXrefType = createADBRequest("sear54321adob","ADB","Prospect Customer","Organization","SherlockDens","ad 1 st street","ad 2 nd st","NY","New York","US","678457","Active","65876");
		rowIdMap = new HashMap<String, List<String>>();
		rowIdMap = searchProspectPartyDAO.findMultiGeoMatch(partyXrefType);
		assertTrue("true", (rowIdMap.size() == 1));
		System.out.println("rowIdMap.get(Constant.CURRENT_ACTIVE_PARTY) " + rowIdMap.get(Constant.CURRENT_ACTIVE_PARTY));
		System.out.println("rowIdMap rowid : :" + rowIdMap.get(Constant.CURRENT_ACTIVE_PARTY).get(0)+":");
		assertTrue("true", (rowIdMap.get(Constant.CURRENT_ACTIVE_PARTY).get(0).trim().equals(rowid_object.trim())));
		System.out.println("===============================================================================================================================================================");

		// Testing rule No. 6
		System.out.println("TESTING MATCH RULE 6 PROSPECT WIDE MATCH RULE SET");
		System.out.println("===============================================================================================================================================================");
		partyXrefType = createADBRequest("sear54321adob","ADB","Prospect Customer","Organization","SherlockDens","Check street","check second street","New York","New York","US","678457","Active","65876");
		rowIdMap = new HashMap<String, List<String>>();
		rowIdMap = searchProspectPartyDAO.findMultiGeoMatch(partyXrefType);
		System.out.println("rowid map size : " + rowIdMap + " : " + rowIdMap.size());
		assertTrue("true", (rowIdMap.size() == 1));
		System.out.println("rowIdMap.get(Constant.CURRENT_ACTIVE_PARTY) " + rowIdMap.get(Constant.CURRENT_ACTIVE_PARTY));
		System.out.println("rowIdMap rowid : :" + rowIdMap.get(Constant.CURRENT_ACTIVE_PARTY).get(0)+":");
		assertTrue("true", (rowIdMap.get(Constant.CURRENT_ACTIVE_PARTY).get(0).trim().equals(rowid_object.trim())));
		System.out.println("===============================================================================================================================================================");

		}

	private PartyXrefType createFNORequest(String srcPkey) {
		PartyXrefType request = new PartyXrefType();

		request.setLASTUPDATEDATE("28-02-2018 03:00:43");
		request.setSRCCREATEDT("28-02-2018 03:00:43");
		request.setUPDATEBY("admin");
		request.setPARTYTYPE("Customer");
		request.setPARTYNAME("SherlockDen");
		request.setSTATUSCD("Active");
		request.setBOCLASSCODE("Organization");
		request.setMSGTRKNID("893573");

		XREFType xref = new XREFType();
		xref.setSRCPKEY(srcPkey);
		xref.setSRCSYSTEM("FNO");
		request.getXREF().add(xref);

		AddressXrefType address = new AddressXrefType();
		address.setSRCPKEY(srcPkey);
		address.setSRCSYSTEM("FNO");
		address.setADDRLN1("ad 1 st street");
		address.setADDRLN2("ad 2 nd street");
		address.setADDRLN3("");
		address.setCITY("New York");
		address.setSTATECD("New York");
		address.setCOUNTRYCD("US");
		address.setADDRSTATUS("Active");
		request.getAddress().add(address);

		AccountXrefType acc = new AccountXrefType();
		acc.setSRCPKEY(srcPkey);
		acc.setSRCSYSTEM("FNO");
		acc.setACCTNAME("SherlockDen");
		acc.setACCTSTATUS("Active");
		acc.setCUSTGROUP("Payer");
		acc.setDATASRCSYSTEM("FNO");
		request.getAccount().add(acc);

		return request;
	}

	
}
