package com.mcafee.mdm.testing.junit;

import java.io.File;
import java.io.StringWriter;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.mcafee.mdm.delegator.ServiceDelegator;
import com.mcafee.mdm.exception.ServiceProcessingException;
import com.mcafee.mdm.generated.UpsertPartyRequest;
import com.mcafee.mdm.generated.UpsertPartyResponse;

@RunWith(SpringJUnit4ClassRunner.class)
public class TestM4MUpsertProspect extends TestM4MBase {
	@Autowired
	private ServiceDelegator serviceDelegator;

	@Test
	public void testUpsertProspectParties() throws ServiceProcessingException,
			JAXBException {
		UpsertPartyRequest request = createRequest();
		assertTrue("serviceDelegator is NULL!!", serviceDelegator != null);
		assertFalse("request is NULL!!", request == null);
		UpsertPartyResponse response = serviceDelegator.upsertPartyProfile(request);
		assertFalse("response is NULL!!", response == null);
		printObjectTreeInXML(UpsertPartyResponse.class, response);
	}

	private UpsertPartyRequest createRequest() throws JAXBException {
		UpsertPartyRequest request = null;
		JAXBContext jaxbContext = JAXBContext
				.newInstance(UpsertPartyRequest.class);
		Unmarshaller jaxbUnMarshaller = jaxbContext.createUnmarshaller();
		request = (UpsertPartyRequest) jaxbUnMarshaller.unmarshal(new File(
				"D:\\McAfee\\Projects\\SWAT\\ErrorCode\\TestXMLs\\UpsertTest_QA.xml"));
		return request;
	}
	
	public static void printObjectTreeInXML(Class<?> objectClass, Object classObject) {
        try {
              JAXBContext jaxbContext = JAXBContext.newInstance(objectClass);
              Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
                     jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);

                    StringWriter strWriter = new StringWriter();
                     jaxbMarshaller.marshal(classObject, strWriter);
                     String msgTxt = strWriter.getBuffer().toString();
                     LOG.debug(objectClass.getName() + " object tree :\n" + msgTxt);
        } catch (JAXBException jaxEx) {
              LOG.error("Failed to create JAXBContext/Marshaller for " + objectClass.getName() + ": " + jaxEx);
              jaxEx.printStackTrace();
        } catch (Exception excp) {
              LOG.error("Failed to convert " + objectClass.getName() + " object into XML: " + excp);
              excp.printStackTrace();
        }
    }
}
