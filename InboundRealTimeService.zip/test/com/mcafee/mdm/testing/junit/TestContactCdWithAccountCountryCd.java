package com.mcafee.mdm.testing.junit;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.mcafee.mdm.dao.ProspectPartyDAO;
import com.mcafee.mdm.dao.UpsertMarketingDAO;
import com.mcafee.mdm.generated.AddressXrefType;
import com.mcafee.mdm.generated.CommunicationXrefType;
import com.mcafee.mdm.generated.PartyPersonXrefType;
import com.mcafee.mdm.generated.PartyXrefType;
import com.mcafee.mdm.generated.UpsertPartyRequest;
import com.mcafee.mdm.generated.UpsertPartyResponse;
import com.mcafee.mdm.generated.XREFType;
import com.mcafee.mdm.util.Util;

@RunWith(SpringJUnit4ClassRunner.class)
public class TestContactCdWithAccountCountryCd extends TestM4MBase{
	@Autowired
	private ProspectPartyDAO prospectPartyDAO;
	@Autowired
	UpsertMarketingDAO upsertMarketingDao;
	
	@Test
	public void testContactCountryCdWithAcctCountryCd() throws Exception {
		assertTrue("upsertMarketingDao is NULL!!", upsertMarketingDao != null);
		UpsertPartyRequest upsertPartyRequest = new UpsertPartyRequest();
		PartyXrefType party = new PartyXrefType();
		party.setBOCLASSCODE("Person");;
		
		XREFType xREFType = new XREFType();
		xREFType.setSRCPKEY("CMAFS000002457560");
		xREFType.setSRCSYSTEM("ELQ");
		party.getXREF().add(xREFType);
		
		PartyPersonXrefType partyPerson = new PartyPersonXrefType();
		partyPerson.setREPORTEDCOMPANYNAME("ADM Cop Ltd");
		partyPerson.setFIRSTNAME("Blake");
		partyPerson.setLASTNAME("Smith");
		party.getPartyPerson().add(partyPerson);
		
		CommunicationXrefType commXrefType = new CommunicationXrefType();
		commXrefType.setCOMMTYPE("Email");
		commXrefType.setCOMMVALUE("blake.smith@asi-securitypartners.com");
		party.getCommunication().add(commXrefType);
		
		AddressXrefType addrXrefType = new AddressXrefType();
		addrXrefType.setCOUNTRYCD("GB");
		party.getAddress().add(addrXrefType);

		upsertPartyRequest.getParty().add(party);
		LOG.debug("Printing service request:-");
		Util.printObjectTreeInXML(UpsertPartyRequest.class, upsertPartyRequest);
		
		UpsertPartyResponse upsertPartyResponse = upsertMarketingDao.processMarketingUpsertRequest(upsertPartyRequest);
		LOG.debug("Printing service Response:-");
		Util.printObjectTreeInXML(UpsertPartyResponse.class, upsertPartyResponse);
	//	LOG.debug("Email Value is-->" + emlValue );//+ "\nError Message::"	+ upsertResponse.getParty().get(0).getErrorMsg());
	//	assertFalse("isValid::" + isValid, isValid);
	//	assertTrue("Incorrect Error Message::"+ upsertResponse.getParty().get(0).getErrorMsg(),"SRC Pkey not found for account with UCN".equals(upsertResponse.getParty().get(0).getErrorMsg()));
	}
}
