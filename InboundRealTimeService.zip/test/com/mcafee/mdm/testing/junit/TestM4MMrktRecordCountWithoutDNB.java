package com.mcafee.mdm.testing.junit;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.mcafee.mdm.dao.ProspectPartyDAO;
import com.mcafee.mdm.dao.UpsertMarketingDAO;

@RunWith(SpringJUnit4ClassRunner.class)
public class TestM4MMrktRecordCountWithoutDNB extends TestM4MBase {
	@Autowired
	private UpsertMarketingDAO upsertMarketingDao;
	@Autowired
	ProspectPartyDAO prospectPartyDAO;

	/*@Test
	public void testMrktRecordCountWithoutDNBMultiELQNoOtherSrc() {
		assertTrue("upsertMarketingDao is NULL!!", upsertMarketingDao != null);
		Integer rowCount = prospectPartyDAO.getExistingRowIdAndProspectRecordCount(
				"PROSPECT-CMAFP000002462080", "ELQ");
		LOG.debug("rowCount::" + rowCount);
		assertTrue("Expecting more than 1 ROW::" + rowCount, rowCount > 1);
	}
	
	@Test
	public void testMrktRecordCountWithoutDNBSingleELQWithOtherSrc() {
		assertTrue("upsertMarketingDao is NULL!!", upsertMarketingDao != null);
		Integer rowCount = prospectPartyDAO.getExistingRowIdAndProspectRecordCount(
				"PROSPECT-CMAFP000002034579", "ELQ");
		LOG.debug("rowCount::" + rowCount);
		assertTrue("Expecting exactly 1 ROW::" + rowCount, rowCount == 1);
	}
	
	@Test
	public void testMrktRecordCountWithoutDNBSingleELQNoOtherSrc() {
		assertTrue("upsertMarketingDao is NULL!!", upsertMarketingDao != null);
		Integer rowCount = prospectPartyDAO.getExistingRowIdAndProspectRecordCount(
				"PROSPECT-CMAFP000002458464", "ELQ");
		LOG.debug("rowCount::" + rowCount);
		assertTrue("Expecting exactly 1 ROW::" + rowCount, rowCount == 1);
	}
	
	@Test
	public void testMrktRecordCountWithoutDNBFalseWithOtherSrc() {
		assertTrue("upsertMarketingDao is NULL!!", upsertMarketingDao != null);
		Integer rowCount = prospectPartyDAO.getExistingRowIdAndProspectRecordCount(
				"PROSPECT-CMAFP000002501028", "ELQ");
		LOG.debug("rowCount::" + rowCount);
		assertTrue("Expecting no ROW::" + rowCount, rowCount == 0);
	}
	
	@Test
	public void testMrktRecordCountWithoutDNBFalseMultiELQWithOtherSrc() {
		assertTrue("upsertMarketingDao is NULL!!", upsertMarketingDao != null);
		Integer rowCount = prospectPartyDAO.getExistingRowIdAndProspectRecordCount(
				"PROSPECT-CMAFP000000463343", "ELQ");
		LOG.debug("rowCount::" + rowCount);
		assertTrue("Expecting no ROW::" + rowCount, rowCount == 0);
	}*/
}
