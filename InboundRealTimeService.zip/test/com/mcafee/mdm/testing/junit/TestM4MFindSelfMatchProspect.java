package com.mcafee.mdm.testing.junit;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.mcafee.mdm.dao.SearchProspectPartyDAO;
import com.mcafee.mdm.exception.ServiceProcessingException;
import com.mcafee.mdm.generated.AddressXrefType;
import com.mcafee.mdm.generated.PartyXrefType;

@RunWith(SpringJUnit4ClassRunner.class)
public class TestM4MFindSelfMatchProspect extends TestM4MBase {
	@Autowired
	private SearchProspectPartyDAO searchProspectPartyDAO;

	@Test
	public void testFindSelfMatchFoundSelfMatch() throws ServiceProcessingException {
		assertTrue("searchProspectPartyDAO is NULL!!", searchProspectPartyDAO != null);
		PartyXrefType partyXrefType = new PartyXrefType();
		AddressXrefType addr = new AddressXrefType();
		partyXrefType.setPARTYNAME("AON SINGAPORE PTE LTD");
		addr.setADDRLN1("60 Anson Road    08 01 Maple Tree Anson");
		addr.setADDRLN2("No 08 01 Maple Tree Anson");
		addr.setCITY("SINGAPORE");
		addr.setCOUNTRYCD("SG");
		addr.setSTATECD(null);
		partyXrefType.getAddress().add(addr);
		Boolean isFound = searchProspectPartyDAO.findSelfMatchProspect(partyXrefType, "8346435");
		LOG.debug("isFound::" + isFound);
		assertTrue("isFound is NOT TRUE::" + isFound, isFound);
	}
	
	@Test
	public void testFindSelfMatchFoundMatchNotSelf() throws ServiceProcessingException {
		assertTrue("searchProspectPartyDAO is NULL!!", searchProspectPartyDAO != null);
		PartyXrefType partyXrefType = new PartyXrefType();
		AddressXrefType addr = new AddressXrefType();
		partyXrefType.setPARTYNAME("AON SINGAPORE PTE LTD");
		addr.setADDRLN1("60 Anson Road    08 01 Maple Tree Anson");
		addr.setADDRLN2("No 08 01 Maple Tree Anson");
		addr.setCITY("SINGAPORE");
		addr.setCOUNTRYCD("SG");
		addr.setSTATECD(null);
		partyXrefType.getAddress().add(addr);
		Boolean isFound = searchProspectPartyDAO.findSelfMatchProspect(partyXrefType, "8349651");
		LOG.debug("isFound::" + isFound);
		assertFalse("isFound is NOT FALSE::" + isFound, isFound);
	}
	
	@Test
	public void testFindSelfMatchNoMatch() throws ServiceProcessingException {
		assertTrue("searchProspectPartyDAO is NULL!!", searchProspectPartyDAO != null);
		PartyXrefType partyXrefType = new PartyXrefType();
		AddressXrefType addr = new AddressXrefType();
		partyXrefType.setPARTYNAME("AON SINGAPORE PTE LTD");
		addr.setADDRLN1("60 Anson Road    08 01 Maple Tree Anson");
		addr.setADDRLN2("No 08 01 Maple Tree Anson");
		addr.setCOUNTRYCD("SG");
		addr.setSTATECD(null);
		partyXrefType.getAddress().add(addr);
		Boolean isFound = searchProspectPartyDAO.findSelfMatchProspect(partyXrefType, "8349651");
		LOG.debug("isFound::" + isFound);
		assertFalse("isFound is NOT FALSE::" + isFound, isFound);
	}
}
