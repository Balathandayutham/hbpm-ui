package com.mcafee.mdm.testing.junit;

import java.util.Enumeration;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;
import java.util.Random;

import javax.transaction.NotSupportedException;
import javax.transaction.SystemException;
import javax.transaction.UserTransaction;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.mcafee.mdm.constants.Constant;
import com.mcafee.mdm.dao.AdobeUpsertPartyContactDAO;
import com.mcafee.mdm.dao.SearchPartyDAO;
import com.mcafee.mdm.dao.SearchProspectPartyDAO;
import com.mcafee.mdm.dao.pojo.HighestScoreRecordHolder;
import com.mcafee.mdm.exception.ServiceProcessingException;
import com.mcafee.mdm.generated.AddressXrefType;
import com.mcafee.mdm.generated.CommunicationXrefType;
import com.mcafee.mdm.generated.MdmUpsertPartyResponse;
import com.mcafee.mdm.generated.PartyPersonXrefType;
import com.mcafee.mdm.generated.PartyXrefType;
import com.mcafee.mdm.generated.StatusType;
import com.mcafee.mdm.generated.XREFType;
import com.mcafee.mdm.util.CreateSIFClient;
import com.siperian.sif.client.EjbSiperianClient;
import com.siperian.sif.client.SiperianClient;

public class TestAdobeContactMatchMergeProcess extends TestM4MBase {
	@Autowired
	private SearchProspectPartyDAO searchProspectPartyDAO;
	
	@Autowired
	SearchPartyDAO searchPartyDAO;
	
	@Autowired
	private AdobeUpsertPartyContactDAO adobeUpsertPartyContactDAO;
	
	private static Hashtable<SiperianClient, Integer> locked = new Hashtable<SiperianClient, Integer>();
	private static Hashtable<SiperianClient, Integer> unlocked = new Hashtable<SiperianClient, Integer>();

	@Test
	public void testAdodeProspectMatch(){
		PartyXrefType partyXrefType = new PartyXrefType();
		String rowid_object = null;
		UserTransaction transaction = null;
		SiperianClient siperianClient = null;
		MdmUpsertPartyResponse upsertResponse = new MdmUpsertPartyResponse();
		StatusType upsertStatus = new StatusType();
		upsertResponse.setUpsertStatus(upsertStatus);
		// Testing rule No. 1
		System.out.println("TESTING MATCH RULE 1 Party Person Fuzzy Rule Set New");
		System.out.println("===============================================================================================================================================================");
		partyXrefType = createADBContactRequest("contct54322adob","ADB","Person","Person","Chekos","Chekos Street","tent Street","East Orange","Louisiana","US","678457","Active","112958466341", "blake.smith@asi-securitypartners.com");
		try {
			adobeUpsertPartyContactDAO.processCleansePutRequest(partyXrefType, upsertResponse, false, false, "0");
			adobeUpsertPartyContactDAO.upsertTokenize(partyXrefType, upsertResponse, false, false, null);
			rowid_object = searchPartyDAO.getPartyRowidObject(partyXrefType.getXREF().get(0).getSRCPKEY(), partyXrefType.getXREF().get(0).getSRCSYSTEM());
			adobeUpsertPartyContactDAO.upsertUCNStampProcess(partyXrefType, upsertResponse, false, false, rowid_object);
		} catch (ServiceProcessingException e1) {
			e1.printStackTrace();
		}
		System.out.println("rowid object of newly inserted request : "+ rowid_object);
		partyXrefType = createADBContactRequest("contct54323adob","ADB","Person","Person","Chekos","Chekos Street","tent Street","East Orange","Louisiana","US","678457","Active","112958466341", "blake.smith@asi-securitypartners.com");
		try {
			adobeUpsertPartyContactDAO.processCleansePutRequest(partyXrefType, upsertResponse, false, false, "0");
			adobeUpsertPartyContactDAO.upsertTokenize(partyXrefType, upsertResponse, false, false, null);
			rowid_object = searchPartyDAO.getPartyRowidObject(partyXrefType.getXREF().get(0).getSRCPKEY(), partyXrefType.getXREF().get(0).getSRCSYSTEM());
			adobeUpsertPartyContactDAO.upsertUCNStampProcess(partyXrefType, upsertResponse, false, false, rowid_object);
		} catch (ServiceProcessingException e1) {
			e1.printStackTrace();
		}
		System.out.println("rowid object of newly inserted request : "+ rowid_object);
		partyXrefType = createADBContactRequest("contct54324adob","ADB","Person","Person","Chekos","Fernan Street","Louis Street","East Orange","Louisiana","US","678457","Active","112958466341", "blake.smith@asi-securitypartners.com");
		try {
			adobeUpsertPartyContactDAO.processCleansePutRequest(partyXrefType, upsertResponse, false, false, "0");
			adobeUpsertPartyContactDAO.upsertTokenize(partyXrefType, upsertResponse, false, false, null);
			rowid_object = searchPartyDAO.getPartyRowidObject(partyXrefType.getXREF().get(0).getSRCPKEY(), partyXrefType.getXREF().get(0).getSRCSYSTEM());
			adobeUpsertPartyContactDAO.upsertUCNStampProcess(partyXrefType, upsertResponse, false, false, rowid_object);
		} catch (ServiceProcessingException e1) {
			e1.printStackTrace();
		}
		System.out.println("rowid object of newly inserted request : "+ rowid_object);
		Map<Integer, HighestScoreRecordHolder> rowIdMap = new HashMap<Integer, HighestScoreRecordHolder>();
		try {
			siperianClient = checkOut();
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		transaction = ((EjbSiperianClient) siperianClient).createTX(300000);
		try {
			transaction.begin();
		} catch (NotSupportedException | SystemException e1) {
			e1.printStackTrace();
		}
		try {
			rowIdMap = adobeUpsertPartyContactDAO.processMatchAndMergeContact(rowid_object, partyXrefType, siperianClient);
		} catch (ServiceProcessingException e) {
			e.printStackTrace();
		}
		assertSearchMatch(rowIdMap, "1");
		System.out.println("===============================================================================================================================================================");
	}
	
	@Test
	public void testAdobeContactMergeProcess(){
		PartyXrefType partyXrefType = new PartyXrefType();
		String src_rowid_object = null;
		String target_rowid = null;
		UserTransaction transaction = null;
		SiperianClient siperianClient = null;
		MdmUpsertPartyResponse upsertResponse = new MdmUpsertPartyResponse();
		StatusType upsertStatus = new StatusType();
		upsertResponse.setUpsertStatus(upsertStatus);
		// Testing Merge
		System.out.println("TESTING MERGE");
		System.out.println("===============================================================================================================================================================");
		partyXrefType = createADBContactRequest("contct77889adob","ADB","Person","Person","Caroline Irvy","Caroline Irvy Street","Irvy Street","East Orange","Louisiana","US","678457","Active","112958466341", "Caroline_Irvy@asi-securitypartners.com");
		try {
			adobeUpsertPartyContactDAO.processCleansePutRequest(partyXrefType, upsertResponse, false, false, "0");
			adobeUpsertPartyContactDAO.upsertTokenize(partyXrefType, upsertResponse, false, false, null);
			src_rowid_object = searchPartyDAO.getPartyRowidObject(partyXrefType.getXREF().get(0).getSRCPKEY(), partyXrefType.getXREF().get(0).getSRCSYSTEM());
			adobeUpsertPartyContactDAO.upsertUCNStampProcess(partyXrefType, upsertResponse, false, false, src_rowid_object);
		} catch (ServiceProcessingException e1) {
			e1.printStackTrace();
		}
		target_rowid = src_rowid_object;
		System.out.println("rowid object of newly inserted request : "+ src_rowid_object);
		Random random = new Random();
		int rand_num = random.nextInt(9999);
		System.out.println("Random number genrated :"+rand_num+":");
		partyXrefType = createADBContactRequest("contct"+rand_num+"adob","ADB","Person","Person","Caroline Irvy","Caroline Irvy Street","Irvy Street","East Orange","Louisiana","US","678457","Active","112958466341", "Caroline_Irvy@asi-securitypartners.com");
		try {
			adobeUpsertPartyContactDAO.processCleansePutRequest(partyXrefType, upsertResponse, false, false, "0");
			adobeUpsertPartyContactDAO.upsertTokenize(partyXrefType, upsertResponse, false, false, null);
			src_rowid_object = searchPartyDAO.getPartyRowidObject(partyXrefType.getXREF().get(0).getSRCPKEY(), partyXrefType.getXREF().get(0).getSRCSYSTEM());
			adobeUpsertPartyContactDAO.upsertUCNStampProcess(partyXrefType, upsertResponse, false, false, src_rowid_object);
		} catch (ServiceProcessingException e1) {
			e1.printStackTrace();	
		}
		System.out.println("rowid object of newly inserted request : "+ src_rowid_object);
		try {
			adobeUpsertPartyContactDAO.upsertMatchMergeProcess(partyXrefType, upsertResponse, false, false, null);
			src_rowid_object = upsertResponse.getParty().get(0).getROWIDOBJECT();
			System.out.println("src_rowid_object after merge: " + src_rowid_object);
			System.out.println("target_rowid_object : " + target_rowid);
			assertTrue("Merge successful", (src_rowid_object.trim()).equals(target_rowid.trim()));
			assertFalse("Merge failed",
					Constant.ERROR_ACC_MERGE_FAIL.equals(upsertResponse.getUpsertStatus().getErrorCode()));
		} catch (ServiceProcessingException e2) {
			e2.printStackTrace();
		}
		System.out.println("===============================================================================================================================================================");
	}
	
	//checks for ucn creation.
	@Test
	public void testUCNStatmping(){
		PartyXrefType partyXrefType = null;
		String rowid_object = null;
		MdmUpsertPartyResponse upsertResponse = new MdmUpsertPartyResponse();
		StatusType upsertStatus = new StatusType();
		upsertResponse.setUpsertStatus(upsertStatus);
		Random random = new Random();
		int rand_num = random.nextInt(9999);
		System.out.println("Random number genrated :"+rand_num+":");
		partyXrefType = createADBContactRequest("contct"+rand_num+"adob","ADB","Person","Person","Chekos","Chekos Street","tent Street","East Orange","Louisiana","US","678457","Active","112958466341", "blake.smith@asi-securitypartners.com");
		try {
			adobeUpsertPartyContactDAO.processCleansePutRequest(partyXrefType, upsertResponse, false, false, "0");
			adobeUpsertPartyContactDAO.upsertTokenize(partyXrefType, upsertResponse, false, false, null);
			rowid_object = searchPartyDAO.getPartyRowidObject(partyXrefType.getXREF().get(0).getSRCPKEY(), partyXrefType.getXREF().get(0).getSRCSYSTEM());
			adobeUpsertPartyContactDAO.upsertUCNStampProcess(partyXrefType, upsertResponse, false, false, rowid_object);
		} catch (ServiceProcessingException e1) {
			e1.printStackTrace();
		}
		System.out.println("rowid object of newly inserted request : "+ rowid_object);
		assertTrue("UCN not assigned successfully",upsertResponse.getStatus().contains("UCN value assigned successfully."));
	}
	
	//create adobe contact request
	private PartyXrefType createADBContactRequest(String srcPkey,String srcSystem, String partyType, String boclasscode, String partyName, String addressLine1, String addressLine2, String city, String stateCd, String countryCd, String msgTrkId, String statusCd,String ucn, String email) {
		PartyXrefType request = new PartyXrefType();
		request.setLASTUPDATEDATE("28-02-2018 03:00:43");
		request.setSRCCREATEDT("28-02-2018 03:00:43");
		request.setPARTYTYPE(partyType);
		request.setPARTYNAME(partyName);
		request.setSTATUSCD(statusCd);
		request.setBOCLASSCODE(boclasscode);
		request.setMSGTRKNID(msgTrkId);
		request.setUCN(ucn);

		XREFType xref = new XREFType();
		xref.setSRCPKEY(srcPkey);
		xref.setSRCSYSTEM(srcSystem);
		request.getXREF().add(xref);

		AddressXrefType address = new AddressXrefType();
		address.setSRCSYSTEM(srcSystem);
		address.setSRCPKEY(srcPkey);
		address.setADDRLN1(addressLine1);
		address.setADDRLN2(addressLine2);
		address.setADDRLN3(null);
		address.setCITY(city);
		address.setSTATECD(stateCd);
		address.setCOUNTRYCD(countryCd);
		address.setADDRSTATUS(statusCd);
		address.setADDRTYPE("Mailing");
		request.getAddress().add(address);

		PartyPersonXrefType partyPerson = new PartyPersonXrefType();
		partyPerson.setSRCPKEY(srcPkey);
		partyPerson.setSRCSYSTEM(srcSystem);
		partyPerson.setREPORTEDCOMPANYNAME("ADM Cop Ltd");
		partyPerson.setFIRSTNAME("Blake");
		partyPerson.setLASTNAME("Smith");
		partyPerson.setJOBLEVEL("C-Level");
		partyPerson.setJOBROLE("IT - Network / Security");
		partyPerson.setJOBTITLE("Chief Information Security Ofr");
		partyPerson.setPREFLANGUAGE("English - American");
		partyPerson.setPERSONSTATUS("Active");
		partyPerson.setPERSONTYPE("Person");
		request.getPartyPerson().add(partyPerson);
	
		CommunicationXrefType commXrefTypePhone = new CommunicationXrefType();
		commXrefTypePhone.setSRCPKEY(srcPkey);
		commXrefTypePhone.setSRCSYSTEM(srcSystem);
		commXrefTypePhone.setCOMMTYPE("Telephone");
		commXrefTypePhone.setCOMMVALUE("9876987654");
		commXrefTypePhone.setCOMMSTATUS(statusCd);
		request.getCommunication().add(commXrefTypePhone);
		
		CommunicationXrefType commXrefType = new CommunicationXrefType();
		commXrefType.setSRCPKEY(srcPkey);
		commXrefType.setSRCSYSTEM(srcSystem);
		commXrefType.setCOMMTYPE("Email");
		commXrefType.setCOMMVALUE(email);
		commXrefType.setCOMMSTATUS(statusCd);
		request.getCommunication().add(commXrefType);
		
		return request;
	}
	
	private void assertSearchMatch(Map<Integer, HighestScoreRecordHolder> rowIdMap, String ruleNo){
		if(rowIdMap != null){
			assertTrue("true", (rowIdMap.size() == 1));
			System.out.println("rowid :"+rowIdMap.size());
			System.out.println("rowid matched for rule No. : "+ ruleNo + " for : "+ rowIdMap.toString()+":");
			assertTrue("Searched record found for rule No. : "+ruleNo, (rowIdMap.size()==1));
		}else{
				assertTrue("No searched record found for ruleNo :"+ ruleNo, (rowIdMap != null));
		}
	}
	
	public synchronized SiperianClient checkOut() throws Exception {
		SiperianClient siperianClient;

		if (unlocked.size() > 0) {
			Enumeration<SiperianClient> clientsObjects = unlocked.keys();
			siperianClient = clientsObjects.nextElement();
			unlocked.remove(siperianClient);
			locked.put(siperianClient, locked.size() + 1);
			return (siperianClient);
		}
		// no objects available, create a new one
		siperianClient = CreateSIFClient.getSIFClientObject().getSIFClient();
		locked.put(siperianClient, locked.size() + 1);
		return (siperianClient);
	}
}
