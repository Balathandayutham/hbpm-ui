package com.mcafee.mdm.testing.junit;

import javax.xml.bind.JAXBException;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.mcafee.mdm.delegator.ServiceDelegator;
import com.mcafee.mdm.exception.ServiceProcessingException;
import com.mcafee.mdm.generated.PartySearchCriteriaType;
import com.mcafee.mdm.generated.SearchPartyRequest;
import com.mcafee.mdm.generated.SearchPartyResponse;

@RunWith(SpringJUnit4ClassRunner.class)
public class TestAccountSearch extends TestM4MBase{
	@Autowired
	private ServiceDelegator serviceDelegator;
	
	@Test
	public void testM4MTrilliumAccount() throws ServiceProcessingException,
			JAXBException {
		SearchPartyRequest parameters = new SearchPartyRequest();
		PartySearchCriteriaType pSearch = new PartySearchCriteriaType();
		
		/*pSearch.setPARTYNAME("Ercros S.A.");
		pSearch.setADDRLN1("Avda. Diagonal, 595 1");
		pSearch.setCITY("Barcelona");
		pSearch.setSTATECD("Barcelona");
		pSearch.setCOUNTRYCD("ES");
		pSearch.setPOSTALCD("08014");*/
		
		pSearch.setPARTYNAME("Nettitude Ltd");
		pSearch.setADDRLN1("1 Jephson Court");
		pSearch.setADDRLN2("Tancred Close");
		pSearch.setADDRLN3("Tancred Close");
		pSearch.setCITY("Leamington Spa");
		pSearch.setSTATECD("Warwickshire");
		pSearch.setCOUNTRYCD("GB");
		pSearch.setPOSTALCD("CV31 3RZ");
		
		parameters.setPartySearchCriteria(pSearch);

		assertTrue("serviceDelegator is NULL!!", serviceDelegator != null);
		
		SearchPartyResponse response = serviceDelegator.searchPartyProfile(parameters);
		assertFalse("response is NULL!!", response == null);
	}
}

