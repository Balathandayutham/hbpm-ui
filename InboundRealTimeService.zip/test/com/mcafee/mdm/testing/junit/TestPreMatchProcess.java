package com.mcafee.mdm.testing.junit;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.mcafee.mdm.constants.Constant;
import com.mcafee.mdm.dao.FNOUpsertPartyDAO;
import com.mcafee.mdm.exception.ServiceProcessingException;
import com.mcafee.mdm.generated.AccountXrefType;
import com.mcafee.mdm.generated.AddressXrefType;
import com.mcafee.mdm.generated.MdmUpsertPartyResponse;
import com.mcafee.mdm.generated.PartyXrefType;
import com.mcafee.mdm.generated.StatusType;
import com.mcafee.mdm.generated.XREFType;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:com/mcafee/mdm/testing/config/beans.xml" })
public class TestPreMatchProcess extends TestM4MBase {
	
	@Autowired
	private FNOUpsertPartyDAO fnoUpsertPartyDAO;
	
	
	//Accounts will not be updated if the PARTY_TYPE does not match with any existing PARTY_TYPE
	@Test
	public void testPartyTypeCheck(){
		MdmUpsertPartyResponse upsertPartyResponse = new MdmUpsertPartyResponse();
		upsertPartyResponse.setUpsertStatus(new StatusType());
		try {
			fnoUpsertPartyDAO.preUpsertMatchProcess(createRequest("name","srcPkey"), upsertPartyResponse, false, false, null);
		} catch (ServiceProcessingException e) {
			e.printStackTrace();
		}
		assertTrue("Party type does not match with existing party", Constant.ERROR_ACCOUNT_WRONG_ACC_TYP.equals(upsertPartyResponse.getUpsertStatus().getErrorCode()));
	}
	
	//If the party does not exist ,then update the Flag  SEND_FOR_DNB in �PROCESS_STATE_IND� in xref for next DNB run and process with cleanseput
	@Test
	public void testPreCheckForPartyNotExist(){
		MdmUpsertPartyResponse upsertPartyResponse = new MdmUpsertPartyResponse();
		upsertPartyResponse.setUpsertStatus(new StatusType());
		try {
			
			
			PartyXrefType req = createRequest("Moto G4","20180312130811");
			
			fnoUpsertPartyDAO.upsertTokenize(req, upsertPartyResponse, false, false, null);
			//Process_State_IND column will be update as SEND_FOR_DNB in party object
			fnoUpsertPartyDAO.preUpsertMatchProcess(req, upsertPartyResponse, false, false, null);
			
		} catch (ServiceProcessingException e) {
			e.printStackTrace();
		}
		
		
	}
	

	private PartyXrefType createRequest(String name,String srcpKey){
		PartyXrefType request = new PartyXrefType();
		
		request.setLASTUPDATEDATE("28-02-2018 03:00:43");
		request.setSRCCREATEDT("28-02-2018 03:00:43");
		request.setUPDATEBY("admin");
		request.setPARTYTYPE("Reseller");
		request.setPARTYNAME(name);
		request.setSTATUSCD("Active");
		request.setBOCLASSCODE("Organization");
		request.setMSGTRKNID("9876001235");
		request.setUCN("12345678");
		
		XREFType xref = new XREFType();
		xref.setSRCPKEY(srcpKey);
		xref.setSRCSYSTEM("FNO");
		
		
		AccountXrefType acc = new AccountXrefType();
		acc.setSRCPKEY(srcpKey);
		acc.setSRCSYSTEM("FNO");
		acc.setACCTNAME(name);
		acc.setACCTSTATUS("Active");
		acc.setCUSTGROUP("Payer");
		acc.setDATASRCSYSTEM("FNO");
		
		AddressXrefType address = new AddressXrefType();
		address.setSRCPKEY(srcpKey);
		address.setSRCSYSTEM("FNO");
		address.setADDRLN1("009, 10th Main St");
		address.setADDRLN2("");
		address.setADDRLN3("");
		address.setCITY("Sacramento");
		address.setSTATECD("California");
		address.setPOSTALCD("95811");
		address.setCOUNTRYCD("USA");
		address.setADDRTYPE("Billing");
		address.setADDRSTATUS("Active");
		
		
		request.getXREF().add(xref);
		request.getAddress().add(address);
		request.getAccount().add(acc);
		
		return request;
	}
	
	
}
