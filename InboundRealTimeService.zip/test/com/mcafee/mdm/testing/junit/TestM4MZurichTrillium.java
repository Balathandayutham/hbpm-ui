package com.mcafee.mdm.testing.junit;

import java.util.HashMap;
import java.util.List;

import javax.xml.bind.JAXBException;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.mcafee.mdm.dao.ProspectPartyDAO;
import com.mcafee.mdm.dao.TrilliumCleanserDAO;
import com.mcafee.mdm.dao.TrilliumLookUpDAO;
import com.mcafee.mdm.dao.UpsertMarketingDAO;
import com.mcafee.mdm.dao.pojo.HighestScoreRecordHolder;
import com.mcafee.mdm.delegator.ServiceDelegator;
import com.mcafee.mdm.exception.ServiceProcessingException;
import com.mcafee.mdm.generated.AddressXrefType;
import com.mcafee.mdm.generated.PartyXrefType;
import com.mcafee.mdm.generated.UpsertPartyRequest;
import com.mcafee.mdm.generated.UpsertPartyResponse;
import com.mcafee.mdm.generated.XREFType;
import com.siperian.sif.client.SiperianClient;

@RunWith(SpringJUnit4ClassRunner.class)
public class TestM4MZurichTrillium extends TestM4MBase{
	@Autowired
	private ServiceDelegator serviceDelegator;
	
	@Test
	public void testM4MTrilliumAccount() throws ServiceProcessingException,
			JAXBException {
		UpsertPartyRequest parameters = new UpsertPartyRequest();
		PartyXrefType pXref = new PartyXrefType();
		pXref.setBOCLASSCODE("Organization");
		XREFType xtype = new XREFType();
		xtype.setSRCSYSTEM("ELQ");
		pXref.getXREF().add(xtype);
		pXref.setPARTYNAME("ABB Ltd");
		AddressXrefType aXref = new AddressXrefType();
		aXref.setADDRLN1("Affolternstrasse");
		aXref.setCITY("Z�rich");
		aXref.setSTATECD("ZH");
		aXref.setPOSTALCD("0000");
		aXref.setCOUNTRYCD("CH");
		pXref.getAddress().add(aXref);
		
		parameters.getParty().add(pXref);
		
		assertTrue("serviceDelegator is NULL!!", serviceDelegator != null);
		
		UpsertPartyResponse response = serviceDelegator.upsertPartyProfile(parameters);
	//	assertFalse("response is NULL!!", response == null);
	}
}
