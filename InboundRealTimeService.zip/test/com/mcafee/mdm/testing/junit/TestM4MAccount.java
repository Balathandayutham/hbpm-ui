package com.mcafee.mdm.testing.junit;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
public class TestM4MAccount extends TestM4MBase{
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Test
	public void testJDBCTemplate() {
		assertTrue("jdbcTemplate is NULL!!", jdbcTemplate != null);
		String sql = "select 1 from dual";
		Integer queryInt = jdbcTemplate.queryForObject(sql, Integer.class);
		assertTrue("Invalid return value from query::" + queryInt,
				queryInt == 1);
	}
}
