package com.mcafee.mdm.testing.junit;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.mcafee.mdm.constants.Constant;
import com.mcafee.mdm.dao.FNOUpsertPartyDAO;
import com.mcafee.mdm.exception.ServiceProcessingException;
import com.mcafee.mdm.generated.AccountXrefType;
import com.mcafee.mdm.generated.MdmUpsertPartyResponse;
import com.mcafee.mdm.generated.PartyXrefType;
import com.mcafee.mdm.generated.StatusType;
import com.mcafee.mdm.generated.XREFType;
import com.mcafee.mdm.util.ValidatorUtil;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:com/mcafee/mdm/testing/config/beans.xml" })
public class TestFNOUpsertDataValidation extends TestM4MBase {

	@Autowired
	private FNOUpsertPartyDAO fnoUpsertPartyDAO;

	@Autowired
	private ValidatorUtil validatorUtil;

	@Test
	public void testValidateMsgTrackingIDWithNull() {
		MdmUpsertPartyResponse response = new MdmUpsertPartyResponse();
		PartyXrefType party = new PartyXrefType();
		party.setMSGTRKNID(null);
		XREFType xref = new XREFType();
		xref.setSRCSYSTEM("FNO");
		try {
			validatorUtil.validateMsgTrackingId(party, response,false);
		} catch (ServiceProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		assertEquals(Constant.ERROR_ACCOUNT_MSG_TRKN_ID_VALIDATION, response.getUpsertStatus().getErrorCode());
	}

	@Test
	public void testValidateMsgTrackingIDWithoutNull() throws ServiceProcessingException {
		MdmUpsertPartyResponse response = new MdmUpsertPartyResponse();
		PartyXrefType party = new PartyXrefType();
		party.setMSGTRKNID("a0Lq0000006pbPBEAY");
		XREFType xref = new XREFType();
		xref.setSRCSYSTEM("FNO");
		StatusType upsertStatus = new StatusType();
		response.setUpsertStatus(upsertStatus);
		validatorUtil.validateMsgTrackingId(party, response,false);
		assertFalse("Valid message tracking id",
				Constant.ERROR_ACCOUNT_MSG_TRKN_ID_VALIDATION.equals(response.getUpsertStatus().getErrorCode()));
	}

	@Test
	public void testValidateMsgTrackingIDWithEmptyID() {
		MdmUpsertPartyResponse response = new MdmUpsertPartyResponse();
		PartyXrefType party = new PartyXrefType();
		party.setMSGTRKNID("");
		XREFType xref = new XREFType();
		xref.setSRCSYSTEM("FNO");
		try {
			validatorUtil.validateMsgTrackingId(party, response,false);
		} catch (ServiceProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		assertEquals(Constant.ERROR_ACCOUNT_MSG_TRKN_ID_VALIDATION, response.getUpsertStatus().getErrorCode());
	}

	@Test
	public void testupsertDataValidationWithInvalidBOCLASSCODE() {
		MdmUpsertPartyResponse response = new MdmUpsertPartyResponse();
		PartyXrefType party = new PartyXrefType();
		party.setBOCLASSCODE("Party");
		AccountXrefType account = new AccountXrefType();
		party.getAccount().add(account);
		party.getAccount().get(0).setCUSTGROUP("Customer");
		party.setMSGTRKNID("a0Lq0000006pbPBEAY");
		XREFType xref = new XREFType();
		xref.setSRCSYSTEM("FNO");
		StatusType upsertStatus = new StatusType();
		response.setUpsertStatus(upsertStatus);
		try {
			fnoUpsertPartyDAO.upsertDataValidation(party, response, false, false, "0");
		} catch (ServiceProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		assertEquals(Constant.ERROR_ACCOUNT_WRONG_ORG, response.getUpsertStatus().getErrorCode());
	}

	@Test
	public void testupsertDataValidationWithvalidBOCLASSCODE() throws ServiceProcessingException {
		MdmUpsertPartyResponse response = new MdmUpsertPartyResponse();
		PartyXrefType party = new PartyXrefType();
		party.setBOCLASSCODE("Organization");
		AccountXrefType account = new AccountXrefType();
		party.getAccount().add(account);
		party.getAccount().get(0).setCUSTGROUP("Customer");
		party.setPARTYTYPE("Reseller");
		StatusType upsertStatus = new StatusType();
		response.setUpsertStatus(upsertStatus);
		fnoUpsertPartyDAO.upsertDataValidation(party, response, false, false, "0");
		/*System.out.println("actual error code : " + response.getUpsertStatus().getErrorCode());
		System.out.println("expected  error code  : " + Constant.ERROR_ACCOUNT_WRONG_ORG);*/
		assertFalse("Valid BO class code",
				Constant.ERROR_ACCOUNT_WRONG_ORG.equals(response.getUpsertStatus().getErrorCode()));
	}

	/*@Test
	public void testupsertDataValidationWithValidCustGroup() {
		MdmUpsertPartyResponse response = new MdmUpsertPartyResponse();
		PartyXrefType party = new PartyXrefType();
		AccountXrefType account = new AccountXrefType();
		party.getAccount().add(account);
		party.getAccount().get(0).setCUSTGROUP("Customer");
		StatusType upsertStatus = new StatusType();
		response.setUpsertStatus(upsertStatus);
		try {
			fnoUpsertPartyDAO.upsertDataValidation(party, response, false, false, "0");
		} catch (ServiceProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		assertFalse("Valid Customer group",
				Constant.ERROR_ACCOUNT_CUST_GROUP_INVALID.equals(response.getUpsertStatus().getErrorCode()));
	}
*/
	/*@Test
	public void testupsertDataValidationWithInvalidCustGroup() {
		MdmUpsertPartyResponse response = new MdmUpsertPartyResponse();
		PartyXrefType party = new PartyXrefType();
		AccountXrefType account = new AccountXrefType();
		party.getAccount().add(account);
		party.getAccount().get(0).setCUSTGROUP("ZREP");
		StatusType upsertStatus = new StatusType();
		response.setUpsertStatus(upsertStatus);
		try {
			fnoUpsertPartyDAO.upsertDataValidation(party, response, false, false, "0");
		} catch (ServiceProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		assertTrue("Invalid Customer group",
				Constant.ERROR_ACCOUNT_CUST_GROUP_INVALID.equals(response.getUpsertStatus().getErrorCode()));
	}*/

	@Test
	public void testupsertDataValidationWithValidPartyType() throws ServiceProcessingException {
		MdmUpsertPartyResponse response = new MdmUpsertPartyResponse();
		PartyXrefType party = new PartyXrefType();
		party.setBOCLASSCODE("Organization");
		party.setPARTYTYPE("Reseller");
		AccountXrefType account = new AccountXrefType();
		party.getAccount().add(account);
		party.getAccount().get(0).setCUSTGROUP("Customer");
		StatusType upsertStatus = new StatusType();
		response.setUpsertStatus(upsertStatus);
		fnoUpsertPartyDAO.upsertDataValidation(party, response, false, false, "0");
		System.out.println("actual error code : " + response.getUpsertStatus().getErrorCode());
		System.out.println("expected  error code  : " + Constant.ERROR_ACCOUNT_INVALID_PTY_TYP);
		assertFalse("Valid Customer group",
				Constant.ERROR_ACCOUNT_INVALID_PTY_TYP.equals(response.getUpsertStatus().getErrorCode()));
	}

	@Test
	public void testupsertDataValidationWithInvalidPartyType() {
		MdmUpsertPartyResponse response = new MdmUpsertPartyResponse();
		PartyXrefType party = new PartyXrefType();
		party.setBOCLASSCODE("Organization");
		party.setPARTYTYPE("Self-Registered User");
		AccountXrefType account = new AccountXrefType();
		party.getAccount().add(account);
		party.getAccount().get(0).setCUSTGROUP("Customer");
		StatusType upsertStatus = new StatusType();
		response.setUpsertStatus(upsertStatus);
		try {
			fnoUpsertPartyDAO.upsertDataValidation(party, response, false, false, "0");
		} catch (ServiceProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		assertTrue("Valid Customer group",
				Constant.ERROR_ACCOUNT_INVALID_PTY_TYP.equals(response.getUpsertStatus().getErrorCode()));
	}

	@Test
	public void testupsertDataValidationWithEmptyPartyType(){
		MdmUpsertPartyResponse response = new MdmUpsertPartyResponse();
		PartyXrefType party = new PartyXrefType();
		party.setBOCLASSCODE("Organization");
		party.setPARTYTYPE("");
		AccountXrefType account = new AccountXrefType();
		party.getAccount().add(account);
		party.getAccount().get(0).setCUSTGROUP("Customer");
		StatusType upsertStatus = new StatusType();
		response.setUpsertStatus(upsertStatus);
		try {
			fnoUpsertPartyDAO.upsertDataValidation(party, response, false, false, "0");
		} catch (ServiceProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		assertTrue("Valid Customer group",
				Constant.ERROR_ACCOUNT_INVALID_PTY_TYP.equals(response.getUpsertStatus().getErrorCode()));
	}

	@Test
	public void testupsertDataValidationWithRandomPartyType() {
		MdmUpsertPartyResponse response = new MdmUpsertPartyResponse();
		PartyXrefType party = new PartyXrefType();
		party.setBOCLASSCODE("Organization");
		party.setPARTYTYPE("AVSDF");
		AccountXrefType account = new AccountXrefType();
		party.getAccount().add(account);
		party.getAccount().get(0).setCUSTGROUP("Customer");
		StatusType upsertStatus = new StatusType();
		response.setUpsertStatus(upsertStatus);
		try {
			fnoUpsertPartyDAO.upsertDataValidation(party, response, false, false, "0");
		} catch (ServiceProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		assertTrue("Valid Customer group",
				Constant.ERROR_ACCOUNT_INVALID_PTY_TYP.equals(response.getUpsertStatus().getErrorCode()));
	}

}
