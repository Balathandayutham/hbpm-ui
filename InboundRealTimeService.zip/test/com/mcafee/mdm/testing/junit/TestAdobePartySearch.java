package com.mcafee.mdm.testing.junit;

import java.io.StringWriter;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.mcafee.mdm.delegator.ServiceDelegator;
import com.mcafee.mdm.exception.ServiceProcessingException;
import com.mcafee.mdm.generated.PartySearchCriteriaType;
import com.mcafee.mdm.generated.SearchPartyRequest;
import com.mcafee.mdm.generated.SearchPartyResponse;

@RunWith(SpringJUnit4ClassRunner.class)
public class TestAdobePartySearch extends TestM4MBase{
	@Autowired
	private ServiceDelegator serviceDelegator;
	
	
	@Test
	public void testPartySearch() throws ServiceProcessingException,
			JAXBException {
		SearchPartyRequest parameters = new SearchPartyRequest();
		PartySearchCriteriaType searchCriteria = new PartySearchCriteriaType();
		
		parameters.setSearchType("Best");
		parameters.setMatchScoreThresold("95");
		searchCriteria.setPARTYNAME("DELL EMC");
		searchCriteria.setADDRLN1("No 1234 1st St");
		searchCriteria.setSTATECD("New York");
		searchCriteria.setCITY("New York");
		searchCriteria.setCOUNTRYCD("US");
		searchCriteria.setSRCSYSTEM("ADB");
		
		parameters.setPartySearchCriteria(searchCriteria);
		
		SearchPartyResponse response = serviceDelegator.searchPartyProfile(parameters);
		
		printObjectTreeInXML(SearchPartyResponse.class,response);
		//assertFalse("response is NULL!!", response == null);
	}
	
	
	public static void printObjectTreeInXML(Class<?> objectClass, Object classObject) {
        try {
              JAXBContext jaxbContext = JAXBContext.newInstance(objectClass);
              Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
                     jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);

                    StringWriter strWriter = new StringWriter();
                     jaxbMarshaller.marshal(classObject, strWriter);
                     String msgTxt = strWriter.getBuffer().toString();
                     LOG.debug(objectClass.getName() + " object tree :\n" + msgTxt);
                     System.out.println("Response: \n"+msgTxt);
        } catch (JAXBException jaxEx) {
              LOG.error("Failed to create JAXBContext/Marshaller for " + objectClass.getName() + ": " + jaxEx);
              jaxEx.printStackTrace();
        } catch (Exception excp) {
              LOG.error("Failed to convert " + objectClass.getName() + " object into XML: " + excp);
              excp.printStackTrace();
        }
    }
}
