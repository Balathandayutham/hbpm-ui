package com.mcafee.mdm.testing.junit;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.mcafee.mdm.constants.Constant;
import com.mcafee.mdm.dao.AdobeUpsertPartyDAO;
import com.mcafee.mdm.dao.SearchPartyDAO;
import com.mcafee.mdm.exception.ServiceProcessingException;
import com.mcafee.mdm.generated.AccountXrefType;
import com.mcafee.mdm.generated.AddressXrefType;
import com.mcafee.mdm.generated.MdmUpsertPartyResponse;
import com.mcafee.mdm.generated.PartyXrefType;
import com.mcafee.mdm.generated.StatusType;
import com.mcafee.mdm.generated.XREFType;

public class TestAdobeMergeProcess extends TestM4MBase{
	
	@Autowired
	AdobeUpsertPartyDAO adobeUpsertPartyDAO;
	
	@Autowired
	SearchPartyDAO searchPartyDAO;
	
	@Test
	public void testMerge(){
		String rowid = getNewlyInsertedRowId();
		System.out.println("rowid object : " + rowid);
		PartyXrefType partyXrefType = new PartyXrefType();
		MdmUpsertPartyResponse upsertPartyResponse = new MdmUpsertPartyResponse();
		String rowid_object = null;
		upsertPartyResponse.setUpsertStatus(new StatusType());
		partyXrefType = createADBRequest("ado54327adob","ADB","Prospect Customer","Organization","Pradhunya Corp","Pradhunya Street","Second Street","New York","New York","US","678457","Active","4321");
		Method method = null;
		try {
			try {
				method = adobeUpsertPartyDAO.getClass().getDeclaredMethod("processCleansePutRequest", PartyXrefType.class, MdmUpsertPartyResponse.class, boolean.class, boolean.class, String.class);
			} catch (NoSuchMethodException | SecurityException e) {
				e.printStackTrace();
			}
			method.setAccessible(true);
			try {
				method.invoke(adobeUpsertPartyDAO, partyXrefType, upsertPartyResponse, false, false, null);
			} catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
				e.printStackTrace();
			}
			rowid_object = searchPartyDAO.getPartyRowidObject(partyXrefType.getXREF().get(0).getSRCPKEY(), partyXrefType.getXREF().get(0).getSRCSYSTEM());
			System.out.println("rowid object 2 : " + rowid_object);
			assertTrue("Merge successful", rowid.equals(rowid_object));
			assertFalse("Merge failed",
					Constant.ERROR_ACC_MERGE_FAIL.equals(upsertPartyResponse.getUpsertStatus().getErrorCode()));
		} catch (ServiceProcessingException e) {
			e.printStackTrace();
		}
	}
	
	public String getNewlyInsertedRowId(){
		PartyXrefType partyXrefType = new PartyXrefType();
		MdmUpsertPartyResponse upsertPartyResponse = new MdmUpsertPartyResponse();
		String rowid_object = null;
		upsertPartyResponse.setUpsertStatus(new StatusType());
		partyXrefType = createADBRequest("ado54326adob","ADB","Prospect Customer","Organization","Pradhunya Corp","Pradhunya Street","Second Street","New York","New York","US","678457","Active","1234");
		Method method = null;
		try {
			try {
				method = adobeUpsertPartyDAO.getClass().getDeclaredMethod("processCleansePutRequest", PartyXrefType.class, MdmUpsertPartyResponse.class, boolean.class, boolean.class, String.class);
			} catch (NoSuchMethodException | SecurityException e) {
				e.printStackTrace();
			}
			method.setAccessible(true);
			try {
				method.invoke(adobeUpsertPartyDAO, partyXrefType, upsertPartyResponse, false, false, null);
			} catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
				e.printStackTrace();
			}
			rowid_object = searchPartyDAO.getPartyRowidObject(partyXrefType.getXREF().get(0).getSRCPKEY(), partyXrefType.getXREF().get(0).getSRCSYSTEM());
		} catch (ServiceProcessingException e) {
			e.printStackTrace();
		}
		return rowid_object;
	}
	
	private PartyXrefType createADBRequest(String srcPkey,String srcSystem, String partyType, String boclasscode, String partyName, String addressLine1, String addressLine2, String city, String stateCd, String countryCd, String msgTrkId, String statusCd,String ucn) {
		PartyXrefType request = new PartyXrefType();
		request.setLASTUPDATEDATE("28-02-2018 03:00:43");
		request.setSRCCREATEDT("28-02-2018 03:00:43");
		request.setUPDATEBY("admin");
		request.setPARTYTYPE(partyType);
		request.setPARTYNAME(partyName);
		request.setSTATUSCD(statusCd);
		request.setBOCLASSCODE(boclasscode);
		request.setMSGTRKNID(msgTrkId);
		request.setUCN(ucn);

		XREFType xref = new XREFType();
		xref.setSRCPKEY(srcPkey);
		xref.setSRCSYSTEM(srcSystem);
		request.getXREF().add(xref);

		AddressXrefType address = new AddressXrefType();
		address.setSRCSYSTEM(srcSystem);
		address.setADDRLN1(addressLine1);
		address.setADDRLN2(addressLine2);
		address.setADDRLN3(null);
		address.setCITY(city);
		address.setSTATECD(stateCd);
		address.setCOUNTRYCD(countryCd);
		address.setADDRSTATUS(statusCd);
		if("Customer".equalsIgnoreCase(partyType))
			address.setADDRTYPE("Billing");
		else
			address.setADDRTYPE("Mailing");
		request.getAddress().add(address);

		AccountXrefType acc = new AccountXrefType();
		acc.setSRCSYSTEM(srcSystem);
		acc.setACCTNAME(partyName);
		request.getAccount().add(acc);

		return request;
	}
	
	private PartyXrefType createFNORequest(String srcPkey,String srcSystem, String partyType, String boclasscode, String partyName, String addressLine1, String addressLine2, String city, String stateCd, String countryCd, String msgTrkId, String statusCd) {
		PartyXrefType request = new PartyXrefType();

		request.setLASTUPDATEDATE("28-02-2018 03:00:43");
		request.setSRCCREATEDT("28-02-2018 03:00:43");
		request.setUPDATEBY("admin");
		request.setPARTYTYPE(partyType);
		request.setPARTYNAME(partyName);
		request.setSTATUSCD(statusCd);
		request.setBOCLASSCODE(boclasscode);
		request.setMSGTRKNID(msgTrkId);

		XREFType xref = new XREFType();
		xref.setSRCPKEY(srcPkey);
		xref.setSRCSYSTEM(srcSystem);
		request.getXREF().add(xref);

		AddressXrefType address = new AddressXrefType();
		address.setSRCPKEY(srcPkey);
		address.setSRCSYSTEM(srcSystem);
		address.setADDRLN1(addressLine1);
		address.setADDRLN2(addressLine2);
		address.setADDRLN3(null);
		address.setCITY(city);
		address.setSTATECD(stateCd);
		address.setCOUNTRYCD(countryCd);
		address.setADDRSTATUS(statusCd);
		request.getAddress().add(address);

		AccountXrefType acc = new AccountXrefType();
		acc.setSRCPKEY(srcPkey);
		acc.setSRCSYSTEM(srcSystem);
		acc.setACCTNAME(partyName);
		acc.setACCTSTATUS(statusCd);
		acc.setCUSTGROUP("Payer");
		acc.setDATASRCSYSTEM(srcSystem);
		request.getAccount().add(acc);

		return request;
	}

	
}
