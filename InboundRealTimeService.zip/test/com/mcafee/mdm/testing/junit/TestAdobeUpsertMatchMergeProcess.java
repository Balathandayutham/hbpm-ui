package com.mcafee.mdm.testing.junit;

import java.io.File;
import java.io.StringWriter;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.mcafee.mdm.constants.Constant;
import com.mcafee.mdm.dao.AdobeUpsertPartyDAO;
import com.mcafee.mdm.dao.FNOUpsertPartyDAO;
import com.mcafee.mdm.dao.GetPartyDAO;
import com.mcafee.mdm.dao.SFDCUpsertPartyDAO;
import com.mcafee.mdm.dao.SearchProspectPartyDAO;
import com.mcafee.mdm.delegator.ServiceDelegator;
import com.mcafee.mdm.exception.ServiceProcessingException;
import com.mcafee.mdm.generated.AccountXrefType;
import com.mcafee.mdm.generated.AddressXrefType;
import com.mcafee.mdm.generated.CommunicationXrefType;
import com.mcafee.mdm.generated.MdmUpsertPartyRequest;
import com.mcafee.mdm.generated.MdmUpsertPartyResponse;
import com.mcafee.mdm.generated.PartyXrefType;
import com.mcafee.mdm.generated.StatusType;
import com.mcafee.mdm.generated.XREFType;
import com.mcafee.mdm.util.Util;

public class TestAdobeUpsertMatchMergeProcess  extends TestM4MBase{
	
	@Autowired
	AdobeUpsertPartyDAO adobeUpsertPartyDAO;
	
	@Autowired
	private GetPartyDAO getPartyDAO;
	
	@Autowired
	private SearchProspectPartyDAO searchProspectPartyDAO;
	
	@Autowired
	private ServiceDelegator serviceDelegator;
	
	@Autowired
	private SFDCUpsertPartyDAO sfdcUpsertPartyDAO;
	
	private Util util = new Util();
	
	@Autowired
	private FNOUpsertPartyDAO fnoUpsertPartyDao;
	
	@Test
	public void testDate(){
		System.out.println("datet " + util.getCurrentTimeZone()); 
	}
	
	@Test
	public void testIsMatchExclusionPatternExists() {
		MdmUpsertPartyResponse upsertPartyResponse1 = new MdmUpsertPartyResponse();
		upsertPartyResponse1.setUpsertStatus(new StatusType());
		PartyXrefType request = createRequest("abcd5353abcd");
		request.setUCN("111250917162");
		/*try {
			adobeUpsertPartyDAO.processCleansePut(request, upsertPartyResponse1, true);
		} catch (ServiceProcessingException e2) {
			e2.printStackTrace();
		}*/
		PartyXrefType insertedPartyData = new PartyXrefType();
		boolean exclusionPatternExists = false;
		String rowidObject = null;
		try {
			insertedPartyData = getPartyDAO.fetchPartyXrefTypeFromORS(request.getXREF().get(0).getSRCSYSTEM(),
					request.getXREF().get(0).getSRCPKEY());
		} catch (ServiceProcessingException e) {
			e.printStackTrace();
		}
		rowidObject = insertedPartyData.getROWIDOBJECT();
		Method method = null;
		try {
			method = adobeUpsertPartyDAO.getClass().getDeclaredMethod("isMatchExclusionPatternExists", String.class);
		} catch (NoSuchMethodException e1) {
			e1.printStackTrace();
		} catch (SecurityException e1) {
			e1.printStackTrace();
		}
		method.setAccessible(true);
		try {
			exclusionPatternExists = (Boolean) method.invoke(adobeUpsertPartyDAO, rowidObject);
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			e.printStackTrace();
		}
		System.out.println("Pattern exists: " + exclusionPatternExists);
		assertTrue("true", exclusionPatternExists);
	}
	
	@Test
	public void testSearchProspect() throws ServiceProcessingException{
		PartyXrefType partyXrefType = new PartyXrefType();
		partyXrefType = createADBRequest("adob3006adob","ADB","Customer","Organization","Judiciary Courts of The State of Minnesota","Louis Branus Street",null,"Saint Paul",null,"US","877876","Active");
		MdmUpsertPartyResponse upsertPartyResponse = new MdmUpsertPartyResponse();
		upsertPartyResponse.setUpsertStatus(new StatusType());
		Map<String, List<String>> rowIdMap = searchProspectPartyDAO.findMultiGeoMatch(partyXrefType);
		assertTrue("true", (rowIdMap.size() == 1));
		System.out.println("rowid : :" + rowIdMap.get(Constant.CURRENT_SINGLETON_OR_PROSPECT_DUNS_PARTY).get(0)+":");
		//assertTrue("true", (rowIdMap.get(Constant.CURRENT_ACTIVE_PARTY).get(0).trim().equals("571363")));
	}
	
	@Test
	public void testSearchMatchRuleTwo() throws Exception {
		//MdmUpsertPartyRequest partyRequest=createSFCRequest("");Connecticut
		PartyXrefType partyXrefType = new PartyXrefType();
		//partyXrefType = createSFCRequest("adob3002ssfc","SFC","Customer","Organization","Kathryn Day","7705 Orchard Village Dr",null,"Indianapolis","Indiana","US","457354","Active");
		//partyXrefType = createSFCRequest("adob3002ssfc","SFC","Customer","Organization","Chenyl","Louis Branus Street",null,"Brookfield","Wisconsin","US","678457","Active");
		//insertSFCRequest(partyXrefType);
		partyXrefType = createSFCRequest("adob3003ssfc","SFC","Prospect Customer","Organization","Chenyl","Louis Branus Street",null,"Harrow","Wisconsin","GB","678457","Active");
		System.out.println("created SFC request");
		insertSFCRequest(partyXrefType);
		System.out.println("inserted SFC request");
		partyXrefType = createSFCRequest("adob3004ssfc","SFC","Prospect Customer","Organization","Chenyl","Louis Branus Street",null,"Harrow","Wisconsin","GB","678457","Active");
		insertSFCRequest(partyXrefType);
		partyXrefType = createADBRequest("adob3005adob","ADB","Customer","Organization","Chenyl","Louis Branus Street",null,"Harrow","Wisconsin","GB","678457","Active");
		MdmUpsertPartyResponse upsertPartyResponse = new MdmUpsertPartyResponse();
		upsertPartyResponse.setUpsertStatus(new StatusType());
		Map<String, List<String>> rowIdMap = searchProspectPartyDAO.findMultiGeoMatch(partyXrefType);
		assertTrue("true", (rowIdMap.size() == 1));
		//System.out.println("rowid : :" + rowIdMap.get(Constant.CURRENT_ACTIVE_PARTY).get(0)+":");
		assertTrue("true", (rowIdMap.get(Constant.CURRENT_ACTIVE_PARTY).get(0).trim().equals("571363")));
	}
	
	@Test
	public void testMultiGeoMatchRuleSetAdobe() throws JAXBException{
		String fileName="Rule_No_1_SrcRecord.xml";
		try {
			testSearchMatchRuleOne(fileName);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	@Test
	public void testMultiGeoMatchRuleSetAdobeProspect() throws JAXBException{
		String fileName="testSearchProspect2.xml";
		try {
			testSearchMatchRuleThree(fileName);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	//Test Prospect Match Rule Set New adobe rule no 1 with target record 38817461
	@Test
	public void testMultiGeoMatchRuleSetAdobeRuleOne() throws JAXBException{
		String fileName="Rule_No_1_SrcRecord_US.xml";
		try {
			testSearchMatchRuleOne(fileName);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	//Test Prospect Match Rule Set New adobe rule no 2 with target record 38817461
		@Test
		public void testMultiGeoMatchRuleSetAdobeRuleTwo() throws JAXBException{
			String fileName="mult_geo_adobe_rul2.xml";
			try {
				testSearchMatchRuleOne(fileName);
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}
		
	//Test Prospect Match Rule Set New adobe rule no 3 with target record 38817461
			@Test
			public void testMultiGeoMatchRuleSetAdobeRuleThree() throws JAXBException{
				String fileName="mult_geo_adobe_rul3.xml";
				try {
					testSearchMatchRuleOne(fileName);
				} catch (Exception e) {
					e.printStackTrace();
				}
				
			}
			
	//Test Prospect Match Rule Set New adobe rule no 4 with target record 38817461
	@Test
	public void testMultiGeoMatchRuleSetAdobeRuleFour() throws JAXBException{
		String fileName="mult_geo_adobe_rul4.xml";
		try {
			testSearchMatchRuleOne(fileName);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	//Test Prospect Match Rule Set New adobe rule no 5 with target record 38817461
		@Test
		public void testMultiGeoMatchRuleSetAdobeRuleFive() throws JAXBException{
			String fileName="mult_geo_adobe_rul5.xml";
			try {
				testSearchMatchRuleOne(fileName);
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}
		
	//Test Prospect Match Rule Set New adobe rule no 6 with target record 38817461
			@Test
			public void testMultiGeoMatchRuleSetAdobeRuleSix() throws JAXBException{
				String fileName="mult_geo_adobe_rul6.xml";
				try {
					testSearchMatchRuleOne(fileName);
				} catch (Exception e) {
					e.printStackTrace();
				}
				
			}
	//Test Prospect Match Rule Set New adobe rule no 7 with target record 38817461
	@Test
	public void testMultiGeoMatchRuleSetAdobeRuleSeven() throws JAXBException{
		String fileName="mult_geo_adobe_rul7.xml";
		try {
			testSearchMatchRuleOne(fileName);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	//Test Prospect Match Rule Set New adobe rule no 8 with target record 38817461
		@Test
		public void testMultiGeoMatchRuleSetAdobeRuleEight() throws JAXBException{
			String fileName="mult_geo_adobe_rul8.xml";
			try {
				testSearchMatchRuleOne(fileName);
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}
		
		//Test Prospect Match Rule Set New adobe rule no 9 with target record 38817461
		@Test
		public void testMultiGeoMatchRuleSetAdobeRuleNine() throws JAXBException{
			String fileName="mult_geo_adobe_rul9.xml";
			try {
				testSearchMatchRuleOne(fileName);
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}
	
	// Matches with Party Batch Rule Set Rule NO.1
	@Test
	public void testPartyBatchRuleSetOne(){
		//String fileName="req_pbr1.xml";
		String fileName="req_pbr1.xml";
		try {
			testProspectSearchMatchRule(fileName);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	// Matches with Party Batch Rule Set Rule NO.2
		@Test
		public void testPartyBatchRuleSetTwo(){
			String fileName="req_pbr2.xml";
			//String fileName="req_pbr2.xml";
			try {
				testProspectSearchMatchRule(fileName);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		// Matches with Party Batch Rule Set Rule NO.3
		@Test
		public void testPartyBatchRuleSetThree(){
			String fileName="req_pbr3.xml";
			//String fileName="req_pbr2.xml";
			try {
				testProspectSearchMatchRule(fileName);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}	

		// Matches with Party Batch Rule Set Rule NO.4
		@Test
		public void testPartyBatchRuleSetFour(){
			String fileName="req_pbr4.xml";
			//String fileName="req_pbr2.xml";
			try {
				testProspectSearchMatchRule(fileName);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		// Matches with Party Batch Rule Set Rule NO.5
		@Test
		public void testPartyBatchRuleSetFive(){
			String fileName="req_pbr5.xml";
			//String fileName="req_pbr2.xml";
			try {
				testProspectSearchMatchRule(fileName);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	
				
/*	public void testPartyBatchRuleTwo(){
//		MdmUpsertPartyResponse upsertPartyResponse1 = new MdmUpsertPartyResponse();
//		upsertPartyResponse1.setUpsertStatus(new StatusType());
//		PartyXrefType fnoPartyXrefType = new PartyXrefType();
//		fnoPartyXrefType = createFNORequest("fno3003fno","FNO","Customer","Organization","Bharat Dynamics","Hyder Street",null,"Hyderabad","Telangana","IN","786543","Active");
//		try {
//			fnoUpsertPartyDao.processCleansePutRequest(fnoPartyXrefType, upsertPartyResponse1, false, false, null);
//			fnoUpsertPartyDao.upsertTokenize(fnoPartyXrefType, upsertPartyResponse1, false, false, null);
//			fnoUpsertPartyDao.upsertUCNStampProcess(fnoPartyXrefType, upsertPartyResponse1, false, false, null);
//		} catch (ServiceProcessingException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		PartyXrefType adobPartyXrefType = new PartyXrefType();
//		adobPartyXrefType = createADBRequest("adob3005adob","ADB","Customer","Organization","Bharat Dynamics","Louis Branus Street",null,"Harrow","Wisconsin","GB","678457","Active");
		
	}*/
	
	/*@Test
	public void testAdobePartyBatchRuleSet(){
		try {
			testPartyBatchRuleSet();
			testMultiGeoMatchRuleSetAdobeRuleOne();
		} catch (JAXBException e) {
			e.printStackTrace();
		}
	}*/
	
	public void testSearchMatchRuleOne(String fileName) throws Exception {
		MdmUpsertPartyRequest partyRequest=createMatchRequest(fileName);
		PartyXrefType partyXrefType = partyRequest.getParty().get(0);
		MdmUpsertPartyResponse upsertPartyResponse = new MdmUpsertPartyResponse();
		upsertPartyResponse.setUpsertStatus(new StatusType());
		Map<String, List<String>> rowIdMap = searchProspectPartyDAO.findMultiGeoMatch(partyXrefType);
		assertTrue("true", (rowIdMap.size() == 1));
		//System.out.println("rowid : :" + rowIdMap.get(Constant.CURRENT_ACTIVE_PARTY).get(0)+":");
		if("Rule_No_1_SrcRecord.xml".equalsIgnoreCase(fileName)){
		assertTrue("true", (rowIdMap.get(Constant.CURRENT_ACTIVE_PARTY).get(0).trim().equals("571363")));
		}
	}
	
	public void testSearchMatchRuleThree(String fileName) throws Exception {
		MdmUpsertPartyRequest partyRequest=createMatchRequest(fileName);
		PartyXrefType partyXrefType = partyRequest.getParty().get(0);
		MdmUpsertPartyResponse upsertPartyResponse = new MdmUpsertPartyResponse();
		upsertPartyResponse.setUpsertStatus(new StatusType());
		Map<String, List<String>> rowIdMap = searchProspectPartyDAO.findMultiGeoMatch(partyXrefType);
		assertTrue("true", (rowIdMap.size() == 1));
		System.out.println("rowid :"+rowIdMap.size());
		//System.out.println("rowid : :" + rowIdMap.get(Constant.CURRENT_SINGLETON_OR_PROSPECT_DUNS_PARTY).get(0)+":");
		assertTrue("true", (rowIdMap.get(Constant.CURRENT_SINGLETON_OR_PROSPECT_DUNS_PARTY).get(0).trim().equals("8322604")));
	}
	
	public void testProspectSearchMatchRule(String fileName) throws Exception {
		MdmUpsertPartyRequest partyRequest=createMatchRequest(fileName);
		PartyXrefType partyXrefType = partyRequest.getParty().get(0);
		MdmUpsertPartyResponse upsertPartyResponse = new MdmUpsertPartyResponse();
		upsertPartyResponse.setUpsertStatus(new StatusType());
		Set<String> rowIdMap = searchProspectPartyDAO.findStrictMatchProspect(partyXrefType,"17627406");
		if(rowIdMap != null){
		assertTrue("true", (rowIdMap.size() == 1));
		System.out.println("rowid :"+rowIdMap.size());
		System.out.println("rowid matched :"+ rowIdMap.toString()+":");
		//System.out.println("rowid : :" + rowIdMap.get(Constant.CURRENT_SINGLETON_OR_PROSPECT_DUNS_PARTY).get(0)+":");
		assertTrue("Searched record found", (rowIdMap.size()==1));
		}else
		{
			assertTrue("No searched record found", (rowIdMap != null));
		}
	}
	
	public void runEnd2End(String fileName) throws JAXBException{
		MdmUpsertPartyRequest request=createMatchRequest(fileName);
		PartyXrefType partyRequest = request.getParty().get(0);
		/*int no = 3001+1;
		partyRequest.getXREF().get(0).setSRCPKEY("RULESET"+no+"CUST");*/
		System.out.println("party name " + partyRequest.getPARTYNAME());
//		MdmUpsertPartyResponse response=serviceDelegator.mdmUpsertPartyProfile(request,request.getParty().get(0).getXREF().get(0).getSRCSYSTEM());
		MdmUpsertPartyResponse response=serviceDelegator.mdmUpsertPartyProfile(request);
		assertFalse("response is NULL!!", response == null);
		printObjectTreeInXML(MdmUpsertPartyResponse.class, response);
		if(response != null && response.getParty() != null && response.getParty().size()>0){
			System.out.println("Inserted row_id object : " + response.getParty().get(0).getROWIDOBJECT());
		}
	}
	
	private MdmUpsertPartyRequest createMatchRequest(String fileName) throws JAXBException {
		MdmUpsertPartyRequest request = null;
		JAXBContext jaxbContext = JAXBContext
				.newInstance(MdmUpsertPartyRequest.class);
		Unmarshaller jaxbUnMarshaller = jaxbContext.createUnmarshaller();
		File ft=new File(
				"D:\\McAfee\\Adobe\\data\\RuleSetTest\\"+fileName);
		System.out.println(ft.isFile());
		request = (MdmUpsertPartyRequest) jaxbUnMarshaller.unmarshal(new File(
				"D:\\McAfee\\Adobe\\data\\RuleSetTest\\"+fileName));
		return request;
	}
	
	private void insertSFCRequest(PartyXrefType partyXrefType){
		MdmUpsertPartyResponse upsertPartyResponse = new MdmUpsertPartyResponse();
		upsertPartyResponse.setUpsertStatus(new StatusType());
		try {
			sfdcUpsertPartyDAO.processCleansePutRequest(partyXrefType, upsertPartyResponse, false, false, null);
			sfdcUpsertPartyDAO.upsertTokenize(partyXrefType, null, false, false, null);
		} catch (ServiceProcessingException e) {
			e.printStackTrace();
		}
	}
	
	
	public static void printObjectTreeInXML(Class<?> objectClass, Object classObject) {
        try {
              JAXBContext jaxbContext = JAXBContext.newInstance(objectClass);
              Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
                     jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);

                    StringWriter strWriter = new StringWriter();
                     jaxbMarshaller.marshal(classObject, strWriter);
                     String msgTxt = strWriter.getBuffer().toString();
                     LOG.debug(objectClass.getName() + " object tree :\n" + msgTxt);
        } catch (JAXBException jaxEx) {
              LOG.error("Failed to create JAXBContext/Marshaller for " + objectClass.getName() + ": " + jaxEx);
              jaxEx.printStackTrace();
        } catch (Exception excp) {
              LOG.error("Failed to convert " + objectClass.getName() + " object into XML: " + excp);
              excp.printStackTrace();
        }
    }

	private PartyXrefType createSFCRequest(String srcPkey,String srcSystem, String partyType, String boclasscode, String partyName, String addressLine1, String addressLine2, String city, String stateCd, String countryCd, String msgTrkId, String statusCd) {
		PartyXrefType request = new PartyXrefType();

		request.setLASTUPDATEDATE("28-02-2018 03:00:43");
		request.setSRCCREATEDT("28-02-2018 03:00:43");
		request.setUPDATEBY("admin");
		request.setPARTYTYPE(partyType);
		request.setPARTYNAME(partyName);
		request.setSTATUSCD(statusCd);
		request.setBOCLASSCODE(boclasscode);
		request.setMSGTRKNID(msgTrkId);

		XREFType xref = new XREFType();
		xref.setSRCPKEY(srcPkey);
		xref.setSRCSYSTEM(srcSystem);
		request.getXREF().add(xref);
		AddressXrefType address = new AddressXrefType();
		address.setSRCPKEY(srcPkey);
		address.setSRCSYSTEM(srcSystem);
		address.setADDRLN1(addressLine1);
		address.setADDRLN2(addressLine2);
		address.setADDRLN3("");
		address.setCITY(city);
		address.setSTATECD(stateCd);
		address.setCOUNTRYCD(countryCd);
		address.setADDRSTATUS(statusCd);
		request.getAddress().add(address);

		AccountXrefType acc = new AccountXrefType();
		acc.setSRCPKEY(srcPkey);
		acc.setSRCSYSTEM(srcSystem);
		acc.setACCTNAME(partyName);
		acc.setACCTSTATUS(statusCd);
		acc.setCUSTGROUP("Payer");
		acc.setDATASRCSYSTEM("Salesforce");
		request.getAccount().add(acc);
		
		CommunicationXrefType comm = new CommunicationXrefType();
		comm.setSRCSYSTEM(srcSystem);
		comm.setSRCPKEY(srcPkey);
		comm.setCOMMTYPE("Web_URL");
		comm.setCOMMSTATUS("Active");
		comm.setCOMMVALUE("test.salesforce.com");

		return request;
	}

	private PartyXrefType createADBRequest(String srcPkey,String srcSystem, String partyType, String boclasscode, String partyName, String addressLine1, String addressLine2, String city, String stateCd, String countryCd, String msgTrkId, String statusCd) {
		PartyXrefType request = new PartyXrefType();
		request.setLASTUPDATEDATE("28-02-2018 03:00:43");
		request.setSRCCREATEDT("28-02-2018 03:00:43");
		request.setUPDATEBY("admin");
		request.setPARTYTYPE(partyType);
		request.setPARTYNAME(partyName);
		request.setSTATUSCD(statusCd);
		request.setBOCLASSCODE(boclasscode);
		request.setMSGTRKNID(msgTrkId);

		XREFType xref = new XREFType();
		xref.setSRCPKEY(srcPkey);
		xref.setSRCSYSTEM(srcSystem);
		request.getXREF().add(xref);

		AddressXrefType address = new AddressXrefType();
		address.setSRCPKEY(srcPkey);
		address.setSRCSYSTEM(srcSystem);
		address.setADDRLN1(addressLine1);
		address.setADDRLN2(addressLine2);
		address.setADDRLN3(null);
		address.setCITY(city);
		address.setSTATECD(stateCd);
		address.setCOUNTRYCD(countryCd);
		address.setADDRSTATUS(statusCd);
		request.getAddress().add(address);

		AccountXrefType acc = new AccountXrefType();
		acc.setSRCPKEY(srcPkey);
		acc.setSRCSYSTEM(srcSystem);
		acc.setACCTNAME(partyName);
		acc.setACCTSTATUS(statusCd);
		acc.setCUSTGROUP("Payer");
		acc.setDATASRCSYSTEM("ADB");
		request.getAccount().add(acc);

		return request;
	}
	
	private PartyXrefType createFNORequest(String srcPkey,String srcSystem, String partyType, String boclasscode, String partyName, String addressLine1, String addressLine2, String city, String stateCd, String countryCd, String msgTrkId, String statusCd) {
		PartyXrefType request = new PartyXrefType();

		request.setLASTUPDATEDATE("28-02-2018 03:00:43");
		request.setSRCCREATEDT("28-02-2018 03:00:43");
		request.setUPDATEBY("admin");
		request.setPARTYTYPE(partyType);
		request.setPARTYNAME(partyName);
		request.setSTATUSCD(statusCd);
		request.setBOCLASSCODE(boclasscode);
		request.setMSGTRKNID(msgTrkId);

		XREFType xref = new XREFType();
		xref.setSRCPKEY(srcPkey);
		xref.setSRCSYSTEM(srcSystem);
		request.getXREF().add(xref);

		AddressXrefType address = new AddressXrefType();
		address.setSRCPKEY(srcPkey);
		address.setSRCSYSTEM(srcSystem);
		address.setADDRLN1(addressLine1);
		address.setADDRLN2(addressLine2);
		address.setADDRLN3(null);
		address.setCITY(city);
		address.setSTATECD(stateCd);
		address.setCOUNTRYCD(countryCd);
		address.setADDRSTATUS(statusCd);
		request.getAddress().add(address);

		AccountXrefType acc = new AccountXrefType();
		acc.setSRCPKEY(srcPkey);
		acc.setSRCSYSTEM(srcSystem);
		acc.setACCTNAME(partyName);
		acc.setACCTSTATUS(statusCd);
		acc.setCUSTGROUP("Payer");
		acc.setDATASRCSYSTEM(srcSystem);
		request.getAccount().add(acc);

		return request;
	}

	
	private PartyXrefType createRequest(String srcPkey) {
		PartyXrefType request = new PartyXrefType();

		request.setLASTUPDATEDATE("28-02-2018 03:00:43");
		request.setSRCCREATEDT("28-02-2018 03:00:43");
		request.setUPDATEBY("admin");
		request.setPARTYTYPE("Customer");
		request.setPARTYNAME("Rajalakshmi S");
		request.setSTATUSCD("Active");
		request.setBOCLASSCODE("Organization");
		request.setMSGTRKNID("893573");

		XREFType xref = new XREFType();
		xref.setSRCPKEY(srcPkey);
		xref.setSRCSYSTEM("ADB");
		request.getXREF().add(xref);

		AddressXrefType address = new AddressXrefType();
		address.setSRCPKEY(srcPkey);
		address.setSRCSYSTEM("ADB");
		address.setADDRLN1("ad 1 st street");
		address.setADDRLN2("ad 2 nd street");
		address.setADDRLN3("");
		address.setCITY("Richardson");
		address.setSTATECD("SHANXI");
		address.setCOUNTRYCD("USA");
		address.setADDRSTATUS("Active");
		request.getAddress().add(address);

		AccountXrefType acc = new AccountXrefType();
		acc.setSRCPKEY(srcPkey);
		acc.setSRCSYSTEM("ADB");
		acc.setACCTNAME("Rajalakshmi S");
		acc.setACCTSTATUS("Active");
		acc.setCUSTGROUP("Payer");
		acc.setDATASRCSYSTEM("ADB");
		request.getAccount().add(acc);

		return request;
	}

}
