package com.mcafee.mdm.testing.junit;

import javax.xml.bind.JAXBException;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.mcafee.mdm.delegator.ServiceDelegator;
import com.mcafee.mdm.exception.ServiceProcessingException;
import com.mcafee.mdm.generated.PartySearchCriteriaType;
import com.mcafee.mdm.generated.SearchPartyHierarchyRequest;
import com.mcafee.mdm.generated.SearchPartyHierarchyResponse;

@RunWith(SpringJUnit4ClassRunner.class)
public class TestHierarchySearch extends TestM4MBase{
	@Autowired
	private ServiceDelegator serviceDelegator;
	
	@Test
	public void testSearchHierarchyUCN() throws ServiceProcessingException,
			JAXBException {
		SearchPartyHierarchyRequest parameters = new SearchPartyHierarchyRequest();
		PartySearchCriteriaType pSearch = new PartySearchCriteriaType();
		pSearch.setUCN("102800305274");
		parameters.setPartySearchCriteria(pSearch);
		parameters.setHierarchyType("McAfee");
		assertTrue("serviceDelegator is NULL!!", serviceDelegator != null);
		SearchPartyHierarchyResponse response = serviceDelegator.searchPartyHierarchyProfile(parameters);
		assertFalse("response is NULL!!", response == null);
	}
}
