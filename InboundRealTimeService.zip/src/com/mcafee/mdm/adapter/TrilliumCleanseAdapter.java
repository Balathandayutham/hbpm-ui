package com.mcafee.mdm.adapter;

import java.io.StringWriter;
import java.io.Writer;
import java.net.MalformedURLException;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.soap.MessageFactory;
import javax.xml.soap.MimeHeaders;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPConnection;
import javax.xml.soap.SOAPConnectionFactory;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.methods.RequestEntity;
import org.apache.commons.httpclient.methods.StringRequestEntity;
import org.apache.log4j.Logger;

import com.mcafee.mdm.exception.DirectorServiceException;

public class TrilliumCleanseAdapter {
	private static final Logger LOG = Logger.getLogger(TrilliumCleanseAdapter.class.getName());
	private String webServURL;

	public TrilliumCleanseAdapter(String webServURL) {
		this.webServURL = webServURL;
	}

	public String[] cleanse(String[] inputData, String[] trillName, String[] updtRule) throws DirectorServiceException {
		LOG.debug("[cleanse]:: ENTER");
		String[] outputData = new String[9];
		try {
			Map<String, String> returnValues = cleanseAddress(webServURL, inputData, trillName, updtRule);

			outputData[0] = returnValues.get(updtRule[0]);
			outputData[1] = returnValues.get(updtRule[1]);
			outputData[2] = returnValues.get(updtRule[2]);
			outputData[3] = returnValues.get(updtRule[3]);
			outputData[4] = returnValues.get(updtRule[4]);
			outputData[5] = returnValues.get(updtRule[5]);
			outputData[6] = returnValues.get(updtRule[6]);
			outputData[7] = returnValues.get(updtRule[7]);
			outputData[8] = returnValues.get(updtRule[8]);
		} catch (Exception e) {
			throw new DirectorServiceException(e);
		}
		LOG.debug("[cleanse]:: EXIT");
		return outputData;
	}

	private Map<String, String> cleanseAddress(String endPointURL, String[] inputData, String[] trillName,
			String[] reqdElementsList) throws Exception {
		LOG.debug("[cleanseAddress]:: ENTER::endPointURL::" + endPointURL);
		Map<String, String> returnValues = new HashMap<String, String>();
		try {
			SOAPConnectionFactory soapConnectionFactory = SOAPConnectionFactory.newInstance();
			SOAPConnection soapConnection = soapConnectionFactory.createConnection();
			String soapRequestStr = createSOAPRequest(endPointURL, inputData, trillName, reqdElementsList);
			PostMethod post = new PostMethod(endPointURL);
			RequestEntity entity = new StringRequestEntity(soapRequestStr, "text/xml", "UTF-8");
			post.setRequestEntity(entity);
			HttpClient httpclient = new HttpClient();
			try {
				LOG.debug("[cleanseAddress] Trillium Account Request: " + soapRequestStr);
				int result = httpclient.executeMethod(post);
				String responseStr = new String(post.getResponseBody(),"UTF-8");
				LOG.debug("[cleanseAddress] Response status code: " + result);
				LOG.debug("[cleanseAddress] Trillium Account Response: \n" + responseStr);
				returnValues = buildResponseMap(responseStr, reqdElementsList, endPointURL);
				soapConnection.close();
			} finally {
				post.releaseConnection();
			}
		} catch (MalformedURLException e) {
			LOG.error("MalformedURLException in cleanseAddress", e);
			throw e;
		} catch (UnsupportedOperationException e) {
			LOG.error("UnsupportedOperationException in cleanseAddress", e);
			throw e;
		} catch (SOAPException e) {
			LOG.error("SOAPException in cleanseAddress", e);
			throw e;
		} catch (Exception e) {
			LOG.error("Exception in cleanseAddress", e);
			throw e;
		}
		LOG.debug("[cleanseAddress]:: EXIT::returnValues::" + returnValues);
		return returnValues;
	}

	private String createSOAPRequest(String endPoint, String[] address, String[] trillName,
			String reqdElementsList[]) throws SOAPException {
		MessageFactory messageFactory = MessageFactory.newInstance();
		SOAPMessage soapMessage = messageFactory.createMessage();
		SOAPPart soapPart = soapMessage.getSOAPPart();

		SOAPEnvelope envelope = soapPart.getEnvelope();
		envelope.addNamespaceDeclaration("xsi", "http://www.w3.org/2001/XMLSchema-instance");
		envelope.addNamespaceDeclaration("xsd", "http://www.w3.org/2001/XMLSchema");
		envelope.addNamespaceDeclaration("soapenv", "http://schemas.xmlsoap.org/soap/envelope/");
		envelope.addNamespaceDeclaration("ejb", "http://ejb.j2ee.director.trilliumsoftware.com");
		envelope.addNamespaceDeclaration("soapenc", "http://schemas.xmlsoap.org/soap/encoding/");

		SOAPBody soapBody = envelope.getBody();

		SOAPElement cleanse = soapBody.addChildElement("cleanse", "ejb");
		cleanse.setAttribute("soapenv:encodingStyle", "http://schemas.xmlsoap.org/soap/encoding/");

		SOAPElement cleanserInput = cleanse.addChildElement("cleanserInput");
		cleanserInput.setAttribute("xsi:type", "java:CleanserInput");
		cleanserInput.setAttribute("xmlns:java", "java:com.trilliumsoftware.director.j2ee.transfer");

		SOAPElement inputData = cleanserInput.addChildElement("inputData");
		inputData.setAttribute("xsi:type", "java1:ArrayOfString");
		inputData.setAttribute("soapenc:arrayType", "xsd:string[]");
		inputData.setAttribute("xmlns:java1", "java:language_builtins.lang");

		SOAPElement accountName = inputData.addChildElement("string");
		if (address[0] != null) {
			accountName.addTextNode(address[0]);
		} else {
			accountName.addTextNode("");
		}

		SOAPElement address1 = inputData.addChildElement("string");
		if (address[1] != null) {
			address1.addTextNode(address[1]);
		} else {
			address1.addTextNode("");
		}

		SOAPElement address2 = inputData.addChildElement("string");
		if (address[2] != null) {
			address2.addTextNode(address[2]);
		} else {
			address2.addTextNode("");
		}

		SOAPElement address3 = inputData.addChildElement("string");
		if (address[3] != null) {
			address3.addTextNode(address[3]);
		} else {
			address3.addTextNode("");
		}

		SOAPElement city = inputData.addChildElement("string");
		if (address[4] != null) {
			city.addTextNode(address[4]);
		} else {
			city.addTextNode("");
		}

		SOAPElement state = inputData.addChildElement("string");
		if (address[5] != null) {
			state.addTextNode(address[5]);
		} else {
			state.addTextNode("");
		}

		SOAPElement postalCode = inputData.addChildElement("string");
		if (address[6] != null) {
			postalCode.addTextNode(address[6]);
		} else {
			postalCode.addTextNode("");
		}

		SOAPElement country = inputData.addChildElement("string");
		if (address[7] != null) {
			country.addTextNode(address[7]);
		} else {
			country.addTextNode("");
		}

		SOAPElement trilName = cleanserInput.addChildElement("trilName");
		trilName.setAttribute("xsi:type", "java1:ArrayOfString");
		trilName.setAttribute("soapenc:arrayType", "xsd:string[]");
		trilName.setAttribute("xmlns:java1", "java:language_builtins.lang");

		SOAPElement Account_Name = trilName.addChildElement("string");
		Account_Name.addTextNode(trillName[0]);
		SOAPElement Address1 = trilName.addChildElement("string");
		Address1.addTextNode(trillName[1]);
		SOAPElement Address2 = trilName.addChildElement("string");
		Address2.addTextNode(trillName[2]);
		SOAPElement Address3 = trilName.addChildElement("string");
		Address3.addTextNode(trillName[3]);
		SOAPElement City = trilName.addChildElement("string");
		City.addTextNode(trillName[4]);
		SOAPElement State = trilName.addChildElement("string");
		State.addTextNode(trillName[5]);
		SOAPElement PostalCode = trilName.addChildElement("string");
		PostalCode.addTextNode(trillName[6]);
		SOAPElement Country = trilName.addChildElement("string");
		Country.addTextNode(trillName[7]);

		SOAPElement updateRule = cleanserInput.addChildElement("updateRule");
		updateRule.setAttribute("xsi:type", "java1:ArrayOfString");
		updateRule.setAttribute("soapenc:arrayType", "xsd:string[]");
		updateRule.setAttribute("xmlns:java1", "java:language_builtins.lang");

		SOAPElement NEW_DR_NAME = updateRule.addChildElement("string");
		NEW_DR_NAME.addTextNode(reqdElementsList[0]);
		SOAPElement NEW_DR_ADDRESS1 = updateRule.addChildElement("string");
		NEW_DR_ADDRESS1.addTextNode(reqdElementsList[1]);
		SOAPElement NEW_DR_ADDRESS2 = updateRule.addChildElement("string");
		NEW_DR_ADDRESS2.addTextNode(reqdElementsList[2]);
		SOAPElement NEW_DR_ADDRESS3 = updateRule.addChildElement("string");
		NEW_DR_ADDRESS3.addTextNode(reqdElementsList[3]);
		SOAPElement NEW_DR_CITY_NAME = updateRule.addChildElement("string");
		NEW_DR_CITY_NAME.addTextNode(reqdElementsList[4]);
		SOAPElement NEW_DR_STATE = updateRule.addChildElement("string");
		NEW_DR_STATE.addTextNode(reqdElementsList[5]);
		SOAPElement NEW_DR_POSTAL_CODE = updateRule.addChildElement("string");
		NEW_DR_POSTAL_CODE.addTextNode(reqdElementsList[6]);
		SOAPElement DR_COUNTRY = updateRule.addChildElement("string");
		DR_COUNTRY.addTextNode(reqdElementsList[7]);
		SOAPElement US_GOUT_MATCH_LEVEL = updateRule.addChildElement("string");
		US_GOUT_MATCH_LEVEL.addTextNode(reqdElementsList[8]);

		MimeHeaders headers = soapMessage.getMimeHeaders();
		headers.addHeader("SOAPAction", endPoint);
		soapMessage.saveChanges();
		String soapMessageStr=getSOAPMessageString(soapMessage);
		return soapMessageStr;
	}

	private Map<String, String> buildResponseMap(String cleansedAddress, String reqdElementsList[], String endPoint)
			throws Exception {
		Map<String, String> resultMap = new HashMap<String, String>();
		cleansedAddress = cleansedAddress.replaceAll("<string xsi:type=\"xsd:string\">", "<string>");
		cleansedAddress = cleansedAddress.replaceAll("<string xsi:type=\"xsd:string\"/>", "<string></string>");
		Pattern regex = Pattern.compile("<string>(.*?)</string>", 32);
		Matcher matcher = regex.matcher(cleansedAddress);
		for (int i = 0; matcher.find(); i++)
			resultMap.put(reqdElementsList[i], matcher.group(1));

		return resultMap;
	}

	private String getSOAPMessageString(SOAPMessage soapMessage) {
		StringBuffer sb = new StringBuffer();
		try {
			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			Source sourceContent = soapMessage.getSOAPPart().getContent();
			Writer outWriter = new StringWriter();
			StreamResult result = new StreamResult(outWriter);
			transformer.transform(sourceContent, result);
			sb = new StringBuffer(outWriter.toString());
			LOG.debug("SOAP Message::" + sb.toString());
		} catch (Exception e) {
			LOG.error("Exception in printSOAPMessage", e);
		}
		return sb.toString();
	}
}