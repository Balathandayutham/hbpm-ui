package com.mcafee.mdm.delegator;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.DependsOn;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.mcafee.mdm.constants.Constant;
import com.mcafee.mdm.dao.AdobeUpsertPartyContactDAO;
import com.mcafee.mdm.dao.AdobeUpsertPartyDAO;
import com.mcafee.mdm.dao.DeletePartyDAO;
import com.mcafee.mdm.dao.FNOUpsertPartyDAO;
import com.mcafee.mdm.dao.GenericDAO;
import com.mcafee.mdm.dao.ProspectPartyDAO;
import com.mcafee.mdm.dao.SAPUpsertPartyDAO;
import com.mcafee.mdm.dao.SFDCUpsertPartyDAO;
import com.mcafee.mdm.dao.SearchContactDAO;
import com.mcafee.mdm.dao.SearchPartyDAO;
import com.mcafee.mdm.dao.TrilliumCleanserDAO;
import com.mcafee.mdm.dao.TrilliumContactCleanserDAO;
import com.mcafee.mdm.dao.TrilliumLookUpDAO;
import com.mcafee.mdm.dao.UpsertMarketingDAO;
import com.mcafee.mdm.dao.UpsertPartyContactDAO;
import com.mcafee.mdm.dao.UpsertPartyDAO;
import com.mcafee.mdm.exception.ServiceProcessingException;
import com.mcafee.mdm.generated.DeletePartyRequest;
import com.mcafee.mdm.generated.DeletePartyResponse;
import com.mcafee.mdm.generated.HierarchySearchRequest;
import com.mcafee.mdm.generated.HierarchySearchResponse;
import com.mcafee.mdm.generated.MdmUpsertPartyRequest;
import com.mcafee.mdm.generated.MdmUpsertPartyResponse;
import com.mcafee.mdm.generated.PartyUpsertRespType;
import com.mcafee.mdm.generated.PartyXrefType;
import com.mcafee.mdm.generated.SearchContactRequest;
import com.mcafee.mdm.generated.SearchContactResponse;
import com.mcafee.mdm.generated.SearchPartyHierarchyRequest;
import com.mcafee.mdm.generated.SearchPartyHierarchyResponse;
import com.mcafee.mdm.generated.SearchPartyRequest;
import com.mcafee.mdm.generated.SearchPartyResponse;
import com.mcafee.mdm.generated.StatusType;
import com.mcafee.mdm.generated.UpsertPartyGroupRequest;
import com.mcafee.mdm.generated.UpsertPartyGroupResponse;
import com.mcafee.mdm.generated.UpsertPartyOrgExtnRequest;
import com.mcafee.mdm.generated.UpsertPartyOrgExtnResponse;
import com.mcafee.mdm.generated.UpsertPartyRequest;
import com.mcafee.mdm.generated.UpsertPartyResponse;
import com.mcafee.mdm.util.PerformanceLoggerUtil;
import com.mcafee.mdm.util.Util;

@Component
@Scope("prototype")
@DependsOn("propertyUtil")
public class ServiceDelegator {
	private static final Logger LOG = Logger.getLogger(ServiceDelegator.class);	
	
	@Autowired
	SearchPartyDAO searchPartyDAO;
	@Autowired
	private DeletePartyDAO deletePartyDAO;
	@Autowired
	private TrilliumCleanserDAO trilliumCleanserDAO;
	@Autowired
	private TrilliumLookUpDAO trilliumLookUpDAO;
	@Autowired
	private UpsertPartyDAO upsertPartyDAO;
	@Autowired
	private SFDCUpsertPartyDAO SFDCupsertPartyDAO;
	@Autowired
	private UpsertMarketingDAO upsertMarketingDao;
	@Autowired
	private UpsertPartyContactDAO upsertPartyContactDAO;
	/*Change for MDMP-2885 :: START*/
	@Autowired
	private GenericDAO genericDAO;
	/*Change for MDMP-2885 :: END*/
	
	@Autowired
	private FNOUpsertPartyDAO fnoUpsertPartyDAO;
	
	@Autowired
	private AdobeUpsertPartyDAO adobeUpsertPartyDAO;
	
	@Autowired
	private AdobeUpsertPartyContactDAO adobeUpsertPartyContactDAO;
	
	@Autowired
	SearchContactDAO searchContactDAO;
	
	@Autowired
	private SAPUpsertPartyDAO sapUpsertPartyDAO;
	
	@Resource(name = "configProp")
	private Properties configProps;
	
	/*Added for M4M START*/		
	private final Map<String, String> marketingSrcSystemMap = new HashMap<String, String>();	
	@Autowired
	private TrilliumContactCleanserDAO trilcontactCleanserDAO;
    /*Added for M4M END*/
	
	/** Modified for US449 START*/
	@Autowired
	private ProspectPartyDAO prospectPartyDAO;
	@Resource(name = "m4mMessagesProp")
	private Properties messagesProp;
	/** Modified for US449 END*/
	
	@PostConstruct
	private void init() {
		LOG.debug("[init] ENTER");
		marketingSrcSystemMap.clear();
		String marketingSrcSystems = configProps.getProperty(Constant.MARKETING_SRC_SYSTEMS);
		LOG.debug("[init] marketingSrcSystems (From Property)::" + marketingSrcSystems);
		String[] marketingSrcSystemArray = new String[]{};
		if(!Util.isNullOrEmpty(marketingSrcSystems)) {
			marketingSrcSystemArray = marketingSrcSystems.split(Constant.STR_COMMA);
			LOG.debug("[init] marketingSrcSystemArray::" + marketingSrcSystemArray);
			for(String marketingSrcSystem:marketingSrcSystemArray) {
				marketingSrcSystemMap.put(marketingSrcSystem, Constant.STR_BLANK);
			}
		}
		LOG.debug("[init] marketingSrcSystemMap::" + marketingSrcSystemMap);
		LOG.debug("[init] EXIT");
	}
	
	/* Fuzzy Search service */
	public SearchPartyResponse searchPartyProfile(SearchPartyRequest parameters) {
		LOG.info("Executing searchPartyProfile()");
		String mdmStateCountryArr [] = new String[10] ;
		SearchPartyResponse searchPartyResponse = new SearchPartyResponse();
		boolean reqParamValid = false;
		boolean setTrilliumValue = false;
		boolean isInTrilliumList = false;
		boolean ismdmStateCdConverted = false;
		String srcSystemId = null;
		
		try {
			
			//Logging SearchPartyRequest details
			LOG.debug("Printing service request:-");
			Util.printObjectTreeInXML(SearchPartyRequest.class,parameters);
			if(parameters.getPartySearchCriteria()!=null && ((!Util.isNullOrEmpty(parameters.getPartySearchCriteria().getACCOUNTSOURCESYSTEM()) && parameters.getPartySearchCriteria().getACCOUNTSOURCESYSTEM().equalsIgnoreCase(Constant.SRC_SYSTEM_ADB)) || (!Util.isNullOrEmpty(parameters.getPartySearchCriteria().getCONTACTSOURCESYSTEM()) && parameters.getPartySearchCriteria().getCONTACTSOURCESYSTEM().equalsIgnoreCase(Constant.SRC_SYSTEM_ADB)) || (!Util.isNullOrEmpty(parameters.getPartySearchCriteria().getSRCSYSTEM()) && parameters.getPartySearchCriteria().getSRCSYSTEM().equalsIgnoreCase(Constant.SRC_SYSTEM_ADB)))){
				LOG.info("Inside ADB Check in ServiceDelegator");
				searchPartyResponse=searchContactDAO.processAdobeContactFuzzySearch(parameters);
			}else{
			if(!Util.isNullOrEmpty(parameters.getPartySearchCriteria().getFIRSTNAME()) || !Util.isNullOrEmpty(parameters.getPartySearchCriteria().getLASTNAME())
					|| !Util.isNullOrEmpty(parameters.getPartySearchCriteria().getEMAILADDRESS()) ){
				LOG.debug("Calling Contact Fuzzy Search");
				/*Calling Contact Fuzzy Search*/
				searchPartyResponse = searchContactDAO.processFuzzySearchRequest(parameters);
			}else if(	(!Util.isNullOrEmpty(parameters.getPartySearchCriteria().getCONTACTSOURCEID()) 
					&& !Util.isNullOrEmpty(parameters.getPartySearchCriteria().getCONTACTSOURCESYSTEM()))
					|| !Util.isNullOrEmpty(parameters.getPartySearchCriteria().getMDMCONTACTID())	) {
				/*Calling Contact Exact Search*/
				searchPartyResponse = searchContactDAO.processExactSearchRequest(parameters);
			}else {
			
			//call request data validation process
			reqParamValid = Util.searchRequestValidation(parameters);
			try{
			
				if(reqParamValid) {
					if (!Util.isNullOrEmpty(parameters.getPartySearchCriteria().getSRCSYSTEM()))	{
						//Converting Cust_Group From SRC to MDM Data.
						trilliumLookUpDAO.convertCustGrpToMdmLov(parameters.getPartySearchCriteria(), parameters.getPartySearchCriteria().getSRCSYSTEM());
						
						isInTrilliumList = trilliumLookUpDAO.checkInTrilliumCountryProjectMap(parameters.getPartySearchCriteria());
						if(isInTrilliumList)	{
							LOG.info("Going For TRILLIUM Procedure");
							//.NET to MDMData Conversion
							mdmStateCountryArr = trilliumLookUpDAO.fetchMDMData(parameters.getPartySearchCriteria());
							//Before Trillium LookUP Process
							if(Util.isNullOrEmpty(mdmStateCountryArr[1]))	{
								mdmStateCountryArr = trilliumLookUpDAO.convertSRCToMDMDataSearch(parameters.getPartySearchCriteria(), parameters.getPartySearchCriteria().getSRCSYSTEM());
							}
							//call Trillium Cleanser service to cleanse Name and Address attributes in request
							if (!Util.isNullOrEmpty(mdmStateCountryArr[1]))	{
								parameters.getPartySearchCriteria().setSTATECD(mdmStateCountryArr[0]);
						//		parameters.getPartySearchCriteria().setCOUNTRYCD(mdmStateCountryArr[1]);
								LOG.info("Trillium Call is being made.");
								setTrilliumValue = trilliumCleanserDAO.callTrilliumCleanser(parameters.getPartySearchCriteria());
								//After Trillium LookUP Process
								trilliumLookUpDAO.convertTrilliumToMDMData(setTrilliumValue, parameters.getPartySearchCriteria());	
								ismdmStateCdConverted = true;
							}
						} else {
							LOG.info("Input Country not within list of 71 Countries, So No TRILLIUM Call.");
							LOG.debug("Converting Input StateCd to MDM StateCd");
							trilliumLookUpDAO.convertTrilliumToMDMData(setTrilliumValue, parameters.getPartySearchCriteria());
							ismdmStateCdConverted = true;
						}
						
					} else {
						LOG.info("Directly Calling TRILLIUM Cleanser With Source Inputs Since No SRC_SYSTEM");
						isInTrilliumList = trilliumLookUpDAO.checkInTrilliumCountryProjectMap(parameters.getPartySearchCriteria());
						if(isInTrilliumList)	{	
							LOG.info("Trillium Call is being made.");
							setTrilliumValue = trilliumCleanserDAO.callTrilliumCleanser(parameters.getPartySearchCriteria());
							//After Trillium LookUP Process
							trilliumLookUpDAO.convertTrilliumToMDMData(setTrilliumValue, parameters.getPartySearchCriteria());
							ismdmStateCdConverted = true;
						} else {
							LOG.info("Input Country not within list of 71 Countries, So No TRILLIUM Call.");
							LOG.debug("Converting Input StateCd to MDM StateCd");
							trilliumLookUpDAO.convertTrilliumToMDMData(setTrilliumValue, parameters.getPartySearchCriteria());
							ismdmStateCdConverted = true;
						}	
					}
				}
			} catch(Exception excp) {
				searchPartyResponse = new SearchPartyResponse();
	        	searchPartyResponse.setErrorMsg("Trillim cleanse failed: " + excp.getMessage());
	        	LOG.error("Trillim cleanse failed while processing searchPartyProfile Request: " , excp);
	        	LOG.error("Consuming exception & continuing with fuzzySearchProcess");
	           
	        //	PartyProfileType partyResp = new PartyProfileType();
	        //    partyResp.getGoldenCopy().getParty().setROWIDOBJECT("0");
			}
			
			if (!ismdmStateCdConverted )	{
				LOG.debug("Converting Input StateCd to MDM StateCd");
				trilliumLookUpDAO.convertTrilliumToMDMData(setTrilliumValue, parameters.getPartySearchCriteria());
			}
			
			/** Modified for M4M START */
			
			if(Util.isNullOrEmpty(parameters.getPartySearchCriteria().getSRCSYSTEMID()))	{
				//call Fuzzy search operation using SIF
				searchPartyResponse = searchPartyDAO.processFuzzySearchRequest(parameters);
			}	else {
				//call ID based search operation using SIF
				srcSystemId = parameters.getPartySearchCriteria().getSRCSYSTEMID();
				searchPartyResponse = searchPartyDAO.processFuzzySearchRequest(parameters, srcSystemId);
			}
			
			/** Modified for M4M END */
					
		}
			//Logging SearchPartyRequest details
			
			
			} 
			LOG.info("Printing service response:-");
			Util.printObjectTreeInXML(SearchPartyResponse.class,searchPartyResponse);
        } catch(Exception Excp)	{
        	searchPartyResponse = new SearchPartyResponse();
        	LOG.error("Caught exception while processing searchPartyProfile Request: " , Excp);
        	searchPartyResponse.setErrorMsg(Excp.getMessage());
        //	searchPartyResponse = new SearchPartyResponse();
        //	searchPartyResponse.setErrorMsg("Trillim cleanse failed: " + Excp.getMessage());
           
      //  	PartyProfileType partyResp = new PartyProfileType();
      //      partyResp.getGoldenCopy().getParty().setROWIDOBJECT("0");
      //    searchPartyResponse.getParty().add(partyResp);
      //      return searchPartyResponse;
    	}
		LOG.info("Executed searchPartyProfile()");
		return searchPartyResponse;
	}
	
	/* Upsert - Update & Insert service */
	/* Added for M4M START */
	/**
	 * Splits upsert party request into Marketing and Non-Marketing data and
	 * continue corresponding upsert operation
	 * 
	 * @since M4M
	 * @param parameters
	 * @return upsertPartyResponse
	 */
	public UpsertPartyResponse upsertPartyProfile(UpsertPartyRequest parameters) {
		LOG.debug("[upsertPartyProfile] ENTER::" + marketingSrcSystemMap);
		List<PartyXrefType> marketingPartyList = new ArrayList<PartyXrefType>();
		List<PartyXrefType> nonMarketingPartyList = new ArrayList<PartyXrefType>();
		UpsertPartyResponse upsertPartyResponse = null;
		UpsertPartyResponse marketingResponse = null;
		// Logging UpsertPartyRequest details
		LOG.debug("Printing service request:-");
		Util.printObjectTreeInXML(UpsertPartyRequest.class, parameters);

		for (PartyXrefType curParty : parameters.getParty()) {
			//Contact Trillium Call
	//		trilcontactCleanserDAO.trilliumContactCleanser(curParty);
			String srcSystem = curParty.getXREF().get(0).getSRCSYSTEM();
			if (!Util.isNullOrEmpty(srcSystem)) {
				if (marketingSrcSystemMap.containsKey(srcSystem)) {
					marketingPartyList.add(curParty);
				} else {
					nonMarketingPartyList.add(curParty);
				}
			} else {
				nonMarketingPartyList.add(curParty);
			}
		}

		LOG.debug("[upsertPartyProfile] nonMarketingPartyList::"
				+ nonMarketingPartyList);
		LOG.debug("[upsertPartyProfile] marketingPartyList::"
				+ marketingPartyList);

		// Calling for Non-Marketing Party Src Systems
		if (!CollectionUtils.isEmpty(nonMarketingPartyList)) {
			UpsertPartyRequest nonMarketingRequest = new UpsertPartyRequest();
			nonMarketingRequest.getParty().addAll(nonMarketingPartyList);
			LOG.debug("[upsertPartyProfile] ******** Start Processing Non Marketing Parties *********");
			upsertPartyResponse = upsertPartyProfileForNonMarketing(nonMarketingRequest);
			LOG.debug("[upsertPartyProfile] ******** Processing Non Marketing Parties completed *********");
			LOG.debug("[upsertPartyProfile] upsertPartyResponse Error::"
					+ upsertPartyResponse.getErrorMsg());
		}

		LOG.debug("[upsertPartyProfile] upsertPartyResponse::"
				+ upsertPartyResponse);

		// Calling for Marketing Party Src Systems
		if ((upsertPartyResponse == null || (upsertPartyResponse != null && !Util
				.isNullOrEmpty(upsertPartyResponse.getErrorMsg())))
				&& !CollectionUtils.isEmpty(marketingPartyList)) {
			UpsertPartyRequest marketingRequest = new UpsertPartyRequest();
			marketingRequest.getParty().addAll(marketingPartyList);
			LOG.debug("[upsertPartyProfile] ******** Start Processing Marketing Parties *********");
			marketingResponse = upsertPartyProfileForMarketing(marketingRequest);
			if (!Util.isNullOrEmpty(marketingResponse.getErrorMsg())
					|| upsertPartyResponse == null) {
				upsertPartyResponse = marketingResponse;
			} else if (!CollectionUtils.isEmpty(marketingResponse.getParty())) {
				upsertPartyResponse.getParty().addAll(
						marketingResponse.getParty());
			}
			LOG.debug("[upsertPartyProfile] ******** Processing Marketing Parties completed *********");
		}

		return upsertPartyResponse;

	}

	/* Added for M4M END */
	
	private UpsertPartyResponse upsertPartyProfileForNonMarketing(
			UpsertPartyRequest parameters) {
		LOG.info("Executing upsertPartyProfile()");
		UpsertPartyResponse upsertPartyResponse = null;
		String mdmStateCountryArr[] = new String[10];
		boolean setTrilliumValue = false;
		boolean isInTrilliumList = false;
		String custGRP = configProps.getProperty("custGRP");
		PerformanceLoggerUtil perfLog = new PerformanceLoggerUtil();
		try {
			LOG.debug("custGRP from config.props: " + custGRP + ".");

			// Call UpsertParty only if CUST_GROUP is not
			// ZREP,DEBI,ZMCA,5000,0001.
			if (!custGRP.contains(parameters.getParty().get(0).getAccount()
					.get(0).getCUSTGROUP())
					|| Util.isNullOrEmpty(parameters.getParty().get(0)
							.getAccount().get(0).getCUSTGROUP())) {
				// call request data validation process
				LOG.info("Calling upsertRequestValidation()");
				try {
					// call Trillium Cleanser service to cleanse Name and
					// Address attributes in request.
					// original request attributes will be overwritten by the
					// cleansed values
					for (PartyXrefType curParty : parameters.getParty()) {
						if (!Util.isNullOrEmpty(curParty.getXREF().get(0)
								.getSRCSYSTEM())) {
							// Checking if Country_CD within list of 71
							// Countries.
							isInTrilliumList = trilliumLookUpDAO
									.checkInTrilliumCountryProjectMap(curParty);
							if (isInTrilliumList) {
								LOG.info("Going For TRILLIUM Procedure");
								// Before Trillium LookUP Process
								mdmStateCountryArr = trilliumLookUpDAO
										.convertSRCToMDMDataUpsert(curParty,
												curParty.getXREF().get(0)
														.getSRCSYSTEM());
								// call Trillium Cleanser service to cleanse
								// Name and Address attributes in request
								if (!Util.isNullOrEmpty(mdmStateCountryArr[1])) {
									curParty.getAddress().get(0)
											.setSTATECD(mdmStateCountryArr[0]);
									// parameters.getParty().get(index).getAddress().get(index).setCOUNTRYCD(mdmStateCountryArr[1]);
								}
								LOG.info("Trillium Call is being made.");
								/* Change for US427 START */
								setTrilliumValue = trilliumCleanserDAO
										.callTrilliumCleanser(curParty, Boolean.FALSE);
								perfLog.printLog(Constant.PERF_LOG_FLOW_UPSERT_SAP_SBL, curParty.getXREF().get(0).getSRCPKEY(), "STEP 1", "Trillium Call done");
								/* Change for US427 END */
								// After Trillium LookUP Process
								trilliumLookUpDAO.convertTrilliumToSRCData(
										setTrilliumValue, curParty, curParty
												.getXREF().get(0)
												.getSRCSYSTEM());
								trilliumLookUpDAO.convertTrilliumToSRCCountry(
										curParty, curParty.getXREF().get(0)
												.getSRCSYSTEM());
								perfLog.printLog(Constant.PERF_LOG_FLOW_UPSERT_SAP_SBL, curParty.getXREF().get(0).getSRCPKEY()
										, "STEP 2", "Transformation after trillium call to source state and country value");
								// }
							} else {
								LOG.info("Input Country not within list of 71 Countries, So No TRILLIUM Call.");
								perfLog.printLog(Constant.PERF_LOG_FLOW_UPSERT_SAP_SBL, curParty.getXREF().get(0).getSRCPKEY()
										, "STEP 1-2", "Trillium call Skipped");
							}
						} else {
							LOG.info("BY Passing TRILLIUM Call Since No SRC_SYSTEM");
							perfLog.printLog(Constant.PERF_LOG_FLOW_UPSERT_SAP_SBL, curParty.getXREF().get(0).getSRCPKEY()
									, "STEP 1-2", "Trillium call Skipped");
						}
					}
				} catch (Exception excp) {
					LOG.error("Trillim cleanse failed: " + excp.getMessage());
					upsertPartyResponse = new UpsertPartyResponse();
					upsertPartyResponse.setErrorMsg("Trillim cleanse failed: "
							+ excp.getMessage());

					PartyUpsertRespType partyResp = new PartyUpsertRespType();
					partyResp.setROWIDOBJECT("0");
					upsertPartyResponse.getParty().add(partyResp);
				}
				
				/*Change for MDMP-2885 :: START*/
				genericDAO.callIsDeniedPartyService(parameters);
				/*Change for MDMP-2885 :: END*/

				/* process to create/update request using SIF */
				
					upsertPartyResponse = upsertPartyDAO.processUpsertPartyRequest(
							parameters, isInTrilliumList);
				
			} else {
				upsertPartyResponse = new UpsertPartyResponse();
				upsertPartyResponse
						.setStatus("Account blocking successful. Account with cust_grp "
								+ parameters.getParty().get(0).getAccount()
										.get(0).getCUSTGROUP()
								+ " not created in MDM");

				PartyUpsertRespType partyResp = new PartyUpsertRespType();
				partyResp.setROWIDOBJECT("0");
				upsertPartyResponse.getParty().add(partyResp);
			}
			// Logging UpsertPartyResponse details
			LOG.debug("Printing service response:-");
			Util.printObjectTreeInXML(UpsertPartyResponse.class,
					upsertPartyResponse);

		} catch (Exception ex) {
			LOG.error(
					"Exception occurred while processing upsertPartyProfile in Delegator. ",
					ex);
			// throw new RuntimeException(ex);
		}
		LOG.info("Executed upsertPartyProfile()");
		return upsertPartyResponse;
	}
	
	/* Account Merge Delete service */
	public DeletePartyResponse deletePartyProfile(DeletePartyRequest parameters) { 
        LOG.info("Executing deletePartyProfile()");
        DeletePartyResponse deletePartyResponse = null;
        try {
        	//Logging DeletePartyRequest details
        	LOG.debug("Printing service request:-");
        	Util.printObjectTreeInXML(DeletePartyRequest.class,parameters);
        	
        	//process create/update request using SIF
			deletePartyResponse = deletePartyDAO.processDeletePartyRequest(parameters);
			
			//Logging DeletePartyResponse details
			LOG.debug("Printing service response:-");
        	Util.printObjectTreeInXML(DeletePartyResponse.class,deletePartyResponse);
        	
        } catch (Exception ex) {
        	deletePartyResponse.setStatus(ex.getMessage());
        	ex.getCause();
            ex.printStackTrace();
            throw new RuntimeException(ex);
        }
        LOG.info("Executed deletePartyProfile()");
        return deletePartyResponse;
    }
	
	/* Added for M4M START */
	/**
	 * This method upsert party for Marketing data
	 * 
	 * @since M4M
	 * @param parameters
	 * @return upsertPartyResponse
	 */
	private UpsertPartyResponse upsertPartyProfileForMarketing(
			UpsertPartyRequest parameters) {
		LOG.debug("[processMarketingUpsertRequest] START");
		UpsertPartyResponse upsertPartyResponse = null;
		boolean setTrilliumValue = false;
		boolean isInTrilliumList = false;
		PerformanceLoggerUtil perfLog = new PerformanceLoggerUtil();
		// call Trillium Cleanser service to cleanse Name and
		// Address attributes in request.
		// original request attributes will be overwritten by the
		// cleansed values
		for (PartyXrefType curParty : parameters.getParty()) {
			try {
				/** Modified for US449 START*/
				if(!(CollectionUtils.isEmpty(curParty.getAddress()) || curParty.getAddress().get(0) == null
						|| Util.isNullOrEmpty(curParty.getAddress().get(0).getCOUNTRYCD())
						|| Util.isNullOrEmpty(curParty.getAddress().get(0).getSTATECD()))) {
					if(!prospectPartyDAO.isCountryStateComboValid(curParty.getAddress().get(0).getCOUNTRYCD(), 
							curParty.getAddress().get(0).getSTATECD(),false)) {
						String respMsg=messagesProp.getProperty(Constant.INFO_COUNTRY_STATE_MISMATCH);
						upsertPartyResponse = new UpsertPartyResponse();
						upsertPartyResponse.setStatus("Processing completed for 0 Party(ies).\n" + 
								respMsg + Constant.STR_SPACE
								+ curParty.getAddress().get(0).getCOUNTRYCD() + "-" 
								+ curParty.getAddress().get(0).getSTATECD());
						upsertPartyResponse.setErrorCd(prospectPartyDAO.getErrorCodeByDescription(respMsg));
						Util.printObjectTreeInXML(UpsertPartyResponse.class,
								upsertPartyResponse);
						return upsertPartyResponse;
					}
				}
				/** Modified for US449 END*/
				String boClassCode = curParty.getBOCLASSCODE();
				if (Constant.BO_CLASS_CODE_PERSON.equalsIgnoreCase(boClassCode)) {
					/* Trillium Cleansing for Contact */
					trilcontactCleanserDAO.trilliumContactCleanser(curParty);
					/* Trillium Cleansing for Account */
					isInTrilliumList = trilliumLookUpDAO
							.checkInTrilliumCountryProjectMapForProspect(curParty,null);
					LOG.debug("isInTrilliumList::" + isInTrilliumList);
					// Convert from ELQ to Trillium format
					trilliumLookUpDAO.convertToTrilliumUpsert(curParty,isInTrilliumList,null);
					if (isInTrilliumList) {
						// Trillium Cleansing for Contact Physical Address
						/* Change for US427 START */
						setTrilliumValue = trilliumCleanserDAO
								.callTrilliumCleanser(curParty, Boolean.TRUE);
						perfLog.printLog(Constant.PERF_LOG_FLOW_UPSERT_ELQ_CONTACT, 
								curParty.getXREF().get(0).getSRCPKEY(), "STEP 1", "Trillium Call done");
						/* Change for US427 END */
						LOG.debug("setTrilliumValue -->" + setTrilliumValue);
						// After Trillium LookUP Process
						trilliumLookUpDAO.convertTrilliumToSRCStateProspect(
								setTrilliumValue, curParty, curParty.getXREF()
										.get(0).getSRCSYSTEM());
					} else {
						perfLog.printLog(Constant.PERF_LOG_FLOW_UPSERT_ELQ_CONTACT, 
								curParty.getXREF().get(0).getSRCPKEY(), "STEP 1", "Trillium Call done");
					}
					perfLog.printLog(Constant.PERF_LOG_FLOW_UPSERT_ELQ_CONTACT, curParty.getXREF().get(0).getSRCPKEY()
							, "STEP 2", "Transformation after trillium call to source state and country value");

				} else if (Constant.BO_CLASS_CODE_ORG
						.equalsIgnoreCase(boClassCode)) {
					String pkey=curParty.getXREF().get(0).getSRCPKEY();
					if(pkey==null) {
						pkey="";
					}
					// Trillium Cleansing for Prospect
					isInTrilliumList = trilliumLookUpDAO
							.checkInTrilliumCountryProjectMapForProspect(curParty,null);
					LOG.debug("isInTrilliumList::" + isInTrilliumList);
					// Before Trillium LookUP Process
					trilliumLookUpDAO.convertToTrilliumUpsert(curParty,isInTrilliumList,null);
					if (isInTrilliumList) {
						LOG.info("Going For TRILLIUM Procedure");
						// call Trillium Cleanser service to cleanse
						// Name and Address attributes in request
						LOG.info("Trillium Call is being made.");
						
						/* Change for US427 START */
						setTrilliumValue = trilliumCleanserDAO
								.callTrilliumCleanser(curParty, Boolean.FALSE);
						perfLog.printLog(Constant.PERF_LOG_FLOW_UPSERT_ELQ_ACCOUNT, pkey, 
								"STEP 1", "Trillium Call done");
						/* Change for US427 END */
						
						// After Trillium LookUP Process
						trilliumLookUpDAO.convertTrilliumToSRCStateProspect(
								setTrilliumValue, curParty, curParty.getXREF()
										.get(0).getSRCSYSTEM());
						perfLog.printLog(Constant.PERF_LOG_FLOW_UPSERT_ELQ_ACCOUNT, pkey, 
								"STEP 2", "Transformation after trillium call to source state and country value");
					} else {
						perfLog.printLog(Constant.PERF_LOG_FLOW_UPSERT_ELQ_ACCOUNT, pkey, 
								"STEP 1-2", "Trillium Call skipped");
					}
					/*Change for MDMP-2885 :: START*/
					genericDAO.callIsDeniedPartyService(parameters);
					/*Change for MDMP-2885 :: END*/
				}
			} catch (Exception excp) {
				LOG.error("Trillim cleanse failed: ", excp);
				upsertPartyResponse = new UpsertPartyResponse();
				upsertPartyResponse.setErrorMsg("Trillim cleanse failed: "
						+ excp.getMessage());

				PartyUpsertRespType partyResp = new PartyUpsertRespType();
				partyResp.setROWIDOBJECT("0");
				upsertPartyResponse.getParty().add(partyResp);
				try {
					// Convert from ELQ to Trillium format
					trilliumLookUpDAO.convertToTrilliumUpsert(curParty,Boolean.FALSE,null);
				} catch (Exception e) {
					LOG.error(
							"convertELQToTrilliumUpsert failed after Trillim cleanse failure:: ",
							e);
				}
			}
		}
		
	

		try {

			upsertPartyResponse = upsertMarketingDao
					.processMarketingUpsertRequest(parameters);
			Util.printObjectTreeInXML(UpsertPartyResponse.class,
					upsertPartyResponse);
		} catch (Exception ex) {
			LOG.error(
					"Exception occurred while processing upsertPartyProfile in Delegator. ",
					ex);

		}

		LOG.debug("[processMarketingUpsertRequest] EXIT");
		return upsertPartyResponse;
	}
	/* Added for M4M END */
	
	/* changes for Sales Force Integration -Start */
	public MdmUpsertPartyResponse mdmUpsertPartyProfile(MdmUpsertPartyRequest parameters) {
		LOG.info("Executing mdmUpsertPartyProfile()");
		MdmUpsertPartyResponse upsertPartyResponse = null;
		//PerformanceLoggerUtil perfLog = new PerformanceLoggerUtil();
		try {
			LOG.debug("Printing SFDC service request:-");
			Util.printObjectTreeInXML(MdmUpsertPartyRequest.class, parameters);
			//StatusType upsertCurrentStatus = parameters.getUpsertStatus();
			/* process to create/update request using SIF */
			String boClassCode = parameters.getParty().get(0).getBOCLASSCODE();
			
			List<PartyXrefType> party= parameters.getParty();
        	String srcSystem = "";
        	
        	if(party!=null&&party.size()>0){
        		srcSystem = (party.get(0).getXREF())!=null?party.get(0).getXREF().get(0).getSRCSYSTEM():"";
        	}
			
			if(Constant.SRC_SYSTEM_FNO.equalsIgnoreCase(srcSystem)){
				upsertPartyResponse = fnoUpsertPartyDAO.processUpsertPartyRequest(parameters);
			}else if(Constant.SRC_SYSTEM_ADB.equalsIgnoreCase(srcSystem)){
				
				if ((!Util.isNullOrEmpty(boClassCode))
						&& (Constant.BO_CLASS_CODE_PERSON.equalsIgnoreCase(boClassCode))) {
					upsertPartyResponse = adobeUpsertPartyContactDAO.processUpsertContactRequest(parameters);
				} else if ((!Util.isNullOrEmpty(boClassCode))
						&& (Constant.BO_CLASS_CODE_ORG.equalsIgnoreCase(boClassCode))) {
					upsertPartyResponse = adobeUpsertPartyDAO.processUpsertPartyRequest(parameters);
				} else {
					upsertPartyResponse = new MdmUpsertPartyResponse();
					upsertPartyResponse.setStatus("Invalid BO Class Code");
					upsertPartyResponse.setErrorMsg("Invalid BO Class Code");
					upsertPartyResponse.setUpsertStatus(new StatusType());
					upsertPartyResponse.getUpsertStatus().setErrorCode(Constant.ERROR_ACCOUNT_EMPTY_BO_CODE);
					upsertPartyResponse.getUpsertStatus().setErrorMsg(upsertPartyResponse.getStatus());
					upsertPartyResponse.getUpsertStatus().setCURRENTPROCESSSTEP(configProps.getProperty(Constant.ERROR_ACCOUNT_EMPTY_BO_CODE + "_RETRY"));
					PartyUpsertRespType partyResp = new PartyUpsertRespType();
					partyResp.setROWIDOBJECT("0");
					//partyResp.setMSGTRKNID("");
					upsertPartyResponse.getParty().add(partyResp);
					LOG.info("Invalid BO Class Code");
				}
				
				
			} else if(Constant.SRC_SYSTEM_SAP.equalsIgnoreCase(srcSystem)){
				upsertPartyResponse = sapUpsertPartyDAO.processUpsertPartyRequest(parameters);
			}
			else {
				if ((!Util.isNullOrEmpty(boClassCode)) && (Constant.BO_CLASS_CODE_PERSON.equalsIgnoreCase(boClassCode))) {
					upsertPartyResponse = upsertPartyContactDAO.processUpsertContactRequest(parameters);
				} else if ((!Util.isNullOrEmpty(boClassCode)) && (Constant.BO_CLASS_CODE_ORG.equalsIgnoreCase(boClassCode))) {
					upsertPartyResponse = SFDCupsertPartyDAO.processUpsertPartyRequest(parameters);
				} else {
					LOG.info("Account blocking successful for invalid PARTY_TYPE. Account with PARTY_TYPE = '"
							+ boClassCode + "' not created in MDM");
				}
			}
			/* changes for Sales Force Integration -End */
			// Logging UpsertPartyResponse details
			LOG.debug("Printing service response:-");
			Util.printObjectTreeInXML(MdmUpsertPartyResponse.class,
					upsertPartyResponse);

		} catch (Exception ex) {
			LOG.error(
					"Exception occurred while processing mdmUpsertPartyProfile in Delegator. ",
					ex);
			// throw new RuntimeException(ex);
		}
		LOG.info("Executed mdmUpsertPartyProfile()");
		return upsertPartyResponse;
	}
	/* changes for Sales Force Integration -End */
	//searchPartyHierarchyProfile
	/* changes for Hierarchy - Track2 -Start */
	public SearchPartyHierarchyResponse searchPartyHierarchyProfile(SearchPartyHierarchyRequest parameters) {
		
		LOG.info("Executing searchPartyProfile()");
		String mdmStateCountryArr [] = new String[10] ;
		SearchPartyHierarchyResponse searchPartyResponse = new SearchPartyHierarchyResponse();
		boolean reqParamValid = false;
		boolean setTrilliumValue = false;
		boolean isInTrilliumList = false;
		boolean ismdmStateCdConverted = false;
		//String srcSystemId = null;
		
		try {
			//Logging SearchPartyRequest details
			LOG.debug("Printing service request:-");
			Util.printObjectTreeInXML(SearchPartyHierarchyRequest.class,parameters);
			
			if(!Util.isNullOrEmpty(parameters.getPartySearchCriteria().getFIRSTNAME()) || !Util.isNullOrEmpty(parameters.getPartySearchCriteria().getLASTNAME())
					|| !Util.isNullOrEmpty(parameters.getPartySearchCriteria().getEMAILADDRESS()) ){
				LOG.debug("Calling Contact Fuzzy Search");
				/*Calling Contact Fuzzy Search*/
				//searchPartyResponse = searchContactDAO.processFuzzySearchRequest(parameters);
			}else if(	(!Util.isNullOrEmpty(parameters.getPartySearchCriteria().getCONTACTSOURCEID()) 
					&& !Util.isNullOrEmpty(parameters.getPartySearchCriteria().getCONTACTSOURCESYSTEM()))
					|| !Util.isNullOrEmpty(parameters.getPartySearchCriteria().getMDMCONTACTID())	) {
				/*Calling Contact Exact Search*/
				//searchPartyResponse = searchContactDAO.processExactSearchRequest(parameters);
			}else {
			
			//call request data validation process
			reqParamValid = Util.searchRequestValidation(parameters);
			try{
			
				if(reqParamValid) {
					if (!Util.isNullOrEmpty(parameters.getPartySearchCriteria().getSRCSYSTEM()))	{
						//Converting Cust_Group From SRC to MDM Data.
						trilliumLookUpDAO.convertCustGrpToMdmLov(parameters.getPartySearchCriteria(), parameters.getPartySearchCriteria().getSRCSYSTEM());
						
						isInTrilliumList = trilliumLookUpDAO.checkInTrilliumCountryProjectMap(parameters.getPartySearchCriteria());
						if(isInTrilliumList)	{
							LOG.info("Going For TRILLIUM Procedure");
							//.NET to MDMData Conversion
							mdmStateCountryArr = trilliumLookUpDAO.fetchMDMData(parameters.getPartySearchCriteria());
							//Before Trillium LookUP Process
							if(Util.isNullOrEmpty(mdmStateCountryArr[1]))	{
								mdmStateCountryArr = trilliumLookUpDAO.convertSRCToMDMDataSearch(parameters.getPartySearchCriteria(), parameters.getPartySearchCriteria().getSRCSYSTEM());
							}
							//call Trillium Cleanser service to cleanse Name and Address attributes in request
							if (!Util.isNullOrEmpty(mdmStateCountryArr[1]))	{
								parameters.getPartySearchCriteria().setSTATECD(mdmStateCountryArr[0]);
						//		parameters.getPartySearchCriteria().setCOUNTRYCD(mdmStateCountryArr[1]);
								LOG.info("Trillium Call is being made.");
								setTrilliumValue = trilliumCleanserDAO.callTrilliumCleanser(parameters.getPartySearchCriteria());
								//After Trillium LookUP Process
								trilliumLookUpDAO.convertTrilliumToMDMData(setTrilliumValue, parameters.getPartySearchCriteria());	
								ismdmStateCdConverted = true;
							}
						} else {
							LOG.info("Input Country not within list of 71 Countries, So No TRILLIUM Call.");
							LOG.debug("Converting Input StateCd to MDM StateCd");
							trilliumLookUpDAO.convertTrilliumToMDMData(setTrilliumValue, parameters.getPartySearchCriteria());
							ismdmStateCdConverted = true;
						}
						
					} else {
						LOG.info("Directly Calling TRILLIUM Cleanser With Source Inputs Since No SRC_SYSTEM");
						isInTrilliumList = trilliumLookUpDAO.checkInTrilliumCountryProjectMap(parameters.getPartySearchCriteria());
						if(isInTrilliumList)	{	
							LOG.info("Trillium Call is being made.");
							setTrilliumValue = trilliumCleanserDAO.callTrilliumCleanser(parameters.getPartySearchCriteria());
							//After Trillium LookUP Process
							trilliumLookUpDAO.convertTrilliumToMDMData(setTrilliumValue, parameters.getPartySearchCriteria());
							ismdmStateCdConverted = true;
						} else {
							LOG.info("Input Country not within list of 71 Countries, So No TRILLIUM Call.");
							LOG.debug("Converting Input StateCd to MDM StateCd");
							trilliumLookUpDAO.convertTrilliumToMDMData(setTrilliumValue, parameters.getPartySearchCriteria());
							ismdmStateCdConverted = true;
						}	
					}
				}
			} catch(Exception excp) {
				searchPartyResponse = new SearchPartyHierarchyResponse();
	        	searchPartyResponse.setErrorMsg("Trillim cleanse failed: " + excp.getMessage());
	        	LOG.error("Trillim cleanse failed while processing searchPartyProfile Request: " , excp);
	        	LOG.error("Consuming exception & continuing with fuzzySearchProcess");
	           
	        //	PartyProfileType partyResp = new PartyProfileType();
	        //    partyResp.getGoldenCopy().getParty().setROWIDOBJECT("0");
			}
			
			if (!ismdmStateCdConverted )	{
				LOG.debug("Converting Input StateCd to MDM StateCd");
				trilliumLookUpDAO.convertTrilliumToMDMData(setTrilliumValue, parameters.getPartySearchCriteria());
			}
			
			/** Modified for M4M START */			
			//set McAfee Hierarchy by default
			if(Util.isNullOrEmpty(parameters.getHierarchyType()))	{
				//call Fuzzy search operation using SIF
				parameters.setHierarchyType(Constant.McAfee_Hierarchy);
			}
			long startTime=System.currentTimeMillis();
			searchPartyResponse = searchPartyDAO.processHierarchyFuzzySearchRequest(parameters);	
			long endTime=System.currentTimeMillis();
			LOG.info("Total Time in Hierarchy seacrh response End -------:"+(endTime-startTime) ); 
		
					
		}
			//Logging SearchPartyRequest details
			LOG.debug("Printing service response:-");
			Util.printObjectTreeInXML(SearchPartyHierarchyResponse.class,searchPartyResponse);
            
        } catch(Exception Excp)	{
        	searchPartyResponse = new SearchPartyHierarchyResponse();
        	LOG.error("Caught exception while processing searchPartyProfile Request: " , Excp);
        	searchPartyResponse.setErrorMsg(Excp.getMessage());
        //	searchPartyResponse = new SearchPartyResponse();
        //	searchPartyResponse.setErrorMsg("Trillim cleanse failed: " + Excp.getMessage());
           
      //  	PartyProfileType partyResp = new PartyProfileType();
      //      partyResp.getGoldenCopy().getParty().setROWIDOBJECT("0");
      //    searchPartyResponse.getParty().add(partyResp);
      //      return searchPartyResponse;
    	}
		LOG.info("Executed searchPartyProfile()");
		return searchPartyResponse;
	}
	
	/* changes for Hierarchy - Track2 -End */
	public UpsertPartyOrgExtnResponse upsertPartyOrgExtn(
			UpsertPartyOrgExtnRequest parameters) {
		LOG.info("Executing upsertPartyOrgExtn()");
		UpsertPartyOrgExtnResponse upsertPartyOrgExtnResponse = null;
		//PerformanceLoggerUtil perfLog = new PerformanceLoggerUtil();
		try {
			LOG.debug("Printing upsertPartyOrgExtn service request:-");
			Util.printObjectTreeInXML(UpsertPartyOrgExtnRequest.class, parameters);
			upsertPartyOrgExtnResponse = genericDAO.processUpsertPartyOrgExtn(parameters);
			LOG.debug("Printing service response:-");
			Util.printObjectTreeInXML(UpsertPartyOrgExtnResponse.class, upsertPartyOrgExtnResponse);

		} catch (Exception ex) {
			LOG.error("Exception occurred while processing upsertPartyOrgExtn in Delegator. ", ex);
		}
		LOG.info("Executed upsertPartyOrgExtn()");
		return upsertPartyOrgExtnResponse;
	}
	public UpsertPartyGroupResponse upsertPartyGroup(
			UpsertPartyGroupRequest parameters) {
		LOG.info("Executing upsertPartyGroup()");
		UpsertPartyGroupResponse upsertPartyGroupResponse = null;
		//PerformanceLoggerUtil perfLog = new PerformanceLoggerUtil();
		try {
			LOG.debug("Printing upsertPartyGroup service request:-");
			Util.printObjectTreeInXML(UpsertPartyGroupRequest.class, parameters);
			upsertPartyGroupResponse = genericDAO.processUpsertPartyGroup(parameters);
			LOG.debug("Printing service response:-");
			Util.printObjectTreeInXML(UpsertPartyGroupRequest.class, upsertPartyGroupResponse);

		} catch (Exception ex) {
			LOG.error("Exception occurred while processing upsertPartyGroup in Delegator. ", ex);
		}
		LOG.info("Executed upsertPartyGroup()");
		return upsertPartyGroupResponse;
	}
	
	/* changes for contactSearch - Track4 -Start */
	public SearchContactResponse searchContact(SearchContactRequest parameters) {
		LOG.info("Executing searchContact()");
		SearchContactResponse searchContactResponse = new SearchContactResponse();
		boolean isParamValid= false;
		try {
			isParamValid= Util.searchContactRequestValidation(parameters,searchContactResponse);
			LOG.info("isParamValid :: "+ isParamValid);
			if(isParamValid){
				LOG.debug("Printing SearchContactRequest request:-");
				Util.printObjectTreeInXML(SearchContactRequest.class,parameters);
				long startTime=System.currentTimeMillis();
				searchContactResponse=	searchContactDAO.searchContact(parameters);
				long endTime=System.currentTimeMillis();
				LOG.info("Total Time in Contact seacrh response End -------:"+(endTime-startTime) ); 
				
			}/*else{
				searchContactResponse.setErrorMsg(Constant.SearchContactRequestCantBeNull);
				searchContactResponse.setStatus(Constant.ERROR);
			}*/
	
		} catch (ServiceProcessingException e) {
			LOG.error("Exception occurred while processing searchContact in Delegator. ", e);
			searchContactResponse.setErrorMsg(Constant.noRecordFound);
			
		}
		
		return searchContactResponse;
	}
	/* changes for contactSearch - Track4 -End */
	
	
	public HierarchySearchResponse hierarchySearch(HierarchySearchRequest parameters){
		
		HierarchySearchResponse hierarchySearchResponse= new HierarchySearchResponse();
		try {
			long startTime=System.currentTimeMillis();
			Util.printObjectTreeInXML(HierarchySearchRequest.class,parameters);
			hierarchySearchResponse=searchPartyDAO.hierarchySearch(parameters);
			Util.printObjectTreeInXML(HierarchySearchResponse.class,hierarchySearchResponse);
			long endTime=System.currentTimeMillis();
			LOG.info("Total Time in hierarchySearch response End -------:"+(endTime-startTime) ); 
		} catch (ServiceProcessingException e) {
			// TODO Auto-generated catch block
			LOG.error("Exception occurred while processing hierarchySearch in Delegator. ", e);
			
		}
		
		
		return hierarchySearchResponse;
	}
}
