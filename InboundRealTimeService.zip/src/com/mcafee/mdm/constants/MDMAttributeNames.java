package com.mcafee.mdm.constants;

public class MDMAttributeNames {
	//Constants for Base Object/Landing table field names
	
	public static final String ROWID_OBJECT = "ROWID_OBJECT";
	public static final String LAST_UPDATE_DATE = "LAST_UPDATE_DATE";
	public static final String SRC_CREATE_DT = "SRC_CREATE_DT";
	public static final String SRC_UPDT_BY = "SRC_UPDT_BY";
	public static final String SRC_SYSTEM = "SRC_SYSTEM";
	public static final String SRC_SYS_KEY = "SRC_SYS_KEY";
	public static final String	PARTY_SRC_SYS_KEY = "PARTY_SRC_SYS_KEY";
	/** Modified for M4M START */
	public static final String ROWID_PARTY = "ROWID_PARTY";
	public static final String ROWID_PARTY_2 = "ROWID_PARTY_2";
	public static final String ROWID_HIERARCHY = "ROWID_HIERARCHY";
	public static final String ROWID_REL_TYPE = "ROWID_REL_TYPE";
	public static final String PARENT_ID = "PARENT_ID";
	public static final String CHILD_ID = "CHILD_ID";
	public static final String HIERARCHY_CODE = "HIERARCHY_CODE";
	public static final String REL_TYPE_CODE = "REL_TYPE_CODE";
	public static final String LOAD_DT = "LOAD_DT";
	/** Modified for M4M END */	
	//Constants for source system names
	public static final String SRC_SYS_SAP = "SAP";
	public static final String SRC_SYS_SIEBEL = "SBL";
	
	//Constants for Entity Names (used in Mappings)
	public static final String PARTY_BO = "C_B_PARTY";
	public static final String ACCOUNT_BO = "C_B_ACCOUNT";
	public static final String ADDRESS_BO = "C_B_ADDRESS";
	public static final String COMM_BO = "C_B_PARTY_COMM";
	public static final String CLASS_BO = "C_B_PARTY_CLASSIFCTN";
	public static final String PARTY_ORG_BO = "C_B_PARTY_ORG_EXTN";
	public static final String PARTY_PRSN_BO = "C_B_PARTY_PRSN_EXTN";
	public static final String PARTY_GROUP_BO = "C_B_PARTY_GROUP";
	/** Modified for M4M START */
	public static final String PARTY_PROSPECT_BO = "C_B_PARTY_PROSPECT";
	public static final String PARTY_REL_BO = "C_B_PARTY_REL";
	/** Modified for M4M END */
	public static final String ENTITY_PARTY = "PARTY";
	public static final String ENTITY_ADDRESS = "ADDRESS";
	public static final String ENTITY_ACCOUNT = "ACCOUNT";
	/** Modified for M4M START */
	public static final String ENTITY_PROSPECT = "PARTY_PROSPECT";
	/** Modified for M4M END */
	public static final String ENTITY_CLASSIF = "PARTY_CLASSIFCTN";
	public static final String ENTITY_COMM = "PARTY_COMM";
	public static final String ENTITY_PARTY_PRSN = "PARTY_PERSON";
	public static final String ENTITY_ORG_EXT = "PARTY_ORG_EXTN";
	public static final String ENTITY_PRSN_EXT = "PARTY_PRSN_EXTN";
	public static final String ENTITY_RELATION = "PARTY_REL";
	public static final String ENTITY_PARTY_GROUP = "PARTY_GROUP";
	//Constants for Put Packages.
	public static final String PARTY_PKG ="PKG_PARTY_IDD";
	public static final String ACCOUNT_PKG = "PKG_ACCOUNT_FOR_IDD";
	public static final String ADDRESS_PKG = "PKG_ADDRESS_FOR_JMS_MQ_PUT";
	public static final String COMM_PKG = "PKG_PARTY_COMM";
	public static final String CLASS_PKG = "PKG_PARTY_CLASSIFCTN";
	public static final String  PARTY_ORG_EXTN_PKG = "PKG_PARTY_ORG_EXTN";
	public static final String  PARTY_PRSN_EXTN_PKG = "";
	/** Modified for SFDC -Track4 START */
	public static final String PERSON_BO = "C_B_PARTY_PERSON";
	/** Modified for SFDC -Track4 END */
}
