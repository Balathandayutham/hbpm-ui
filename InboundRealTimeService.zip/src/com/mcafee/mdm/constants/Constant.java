package com.mcafee.mdm.constants;

public interface Constant {
	
	final String[] partyIndividualList = new String[] {"MULTIPLE DOCTORS","ANONYMOUS","UNK","UNKNOWN","ANON","RESTRICTED","CURRENT RESIDENT"};
   	final String[] partyIndvFSTNMList = new String[] {"CURRENT RESIDENT"};
   	final String[] partyIndvLASTNMList = new String[] {"MULTIPLE DOCTORS","ANONYMOUS","UNK","UNKNOWN","ANON","RESTRICTED"};
   	final String[] partyAccountList = new String[] {"MULTIPLE DOCTORS"};
   	final String specialIndvChar = "Special Character Exists in the Name field for the party type Individual";
   	final String specialAccntChar = "Special Character Exists in the Name field for the Party Type Account";
   	final String bothpartyAccntIndvRecord = "Both Party Individual and Party Account record can't be inserted in a single transaction";
   	final String partyInsertionFailed = "Falied to Insert Party";
   	final String indvInsertionFailed = "Failed to Insert Individual Data";
   	final String accntInsertionFailed = "Failed to Insert Account Data";
   	final String provideAccountData = "Please provide Account Data as the Party Type is Account";
   	final String provideindvData = "Please provide INDIVIDUAL Data as the Party Type is INDIVIDUAL";
   	final String RequiredPartyFieldEmpty = "Required Filed for the Party can't be Null. Please provide proper data for the Party.";
	final String RequiredAccntFieldEmpty = "Required Filed for Party Account can't be Null. Please provide proper data for the Party Account.";
	final String RequiredIndvFieldEmpty = "Required Filed for Party Individual can't be Null. Please provide proper data for the Party Individaul.";
	final String inValidIndvName = " can't be Inserted for Individual";
	final String inValidAccntName = " can't be Inserted for Account";
	
	//For getService 
	final String[] idTypeList = new String[] {"ERP_AP","AXIS","ASR","MDMID"};
	final String noConsolidatedRecordFound = "No consolidated data found in the Data base for the MDMID";
	final String bothIdTypeandIDisNull = "Both Input ID Type or Input ID can't be NULL";
	final String inValidIdType = "Provided IdType is not valid";
	final String inValidIdSrcSysName = "Source System is not valid";
	
	//For all Service Unexpected error
	final String unExpectedError = "Unexpected error has occurred. Please contact system administrator:::::";
	
	
	// for getCustomerTimeLineValidation
	final String inValidIdTypeMDMID = "Input ID Type should be always MDMID";
	
	//For Fuzzy Search Service
	final String bothAccntIndvCantbeNull = "Both Individual or Account Search Criteria can't be NULL";
	final String bothAccntIndvSearchCantbedone = "Both Individual or Account Search can't be done";
	final String allIndvSearchParameterNull = "All search Parameters for Individual can't be null";
	final String allAccntSearchParameterNull = "All search Parameters for Account can't be null";
	final String noRecordFound = "No record Found";
	final String noHierarchySearchUCNInput ="UCN cannot be empty";
	final String partynameCantbeNull = "Party Name Cannot be Null";
	final String addrLine1CantbeNull = "Address Line1 Cannot be Null";
	final String ucnCantbeNull = "UCN Cannot be Null";
	final String isXrefRequiredCantbeNull = "IS Xref Required Cannot be Null";
	final String bothCustGrpAndPartyTypeCantbeGiven = "Either Customer_Group OR Party_Type may be provided at a time, not both simultaneously!";
	final String invalidPartyType = "The provided PARTY_TYPE is not within valid range. Please provide any PARTY_TYPE value from -> ('Customer','Partner','Reseller','Distributor')" ; 

	//for Create/Update service
	final String partyCantBeEmpty = "Party profile cannot be empty";
	final String boClassCode = "Bo Class Code cannot be empty";
	final String partyType = "Party Type cannot be empty";
	final String statusCode = "Status Code cannot be empty";
	final String srcPkey = "Source Pkey cannot be empty";
	final String srcSYS = "Source System cannot be empty";
	
	final String accountCantBeEmpty = "Account profile cannot be empty";
	final String accountStatusCantbeEmpty = "Account Status cannot be empty";
	final String accountTypeCantbeEmpty = "Account Type cannot be empty";
	final String custGRPCantbeEmpty = "Cust Group cannot be empty";
	final String priceGRPCantbeEmpty = "Price Group cannot be empty";
	final String companyCodeCantbeEmpty = "Company Code cannot be empty";
	final String dataSrcSysCantbeEmpty = "Data Source System cannot be empty";
	
	final String addressCantBeEmpty = "Address profile cannot be empty";
	final String addressTypeCantBeEmpty = "Address Type cannot be empty";
	final String addressStatusCantBeEmpty = "Address Status cannot be empty";
	
	final String commCantBeEmpty = "Communication profile cannot be empty";
	final String commTypeCantBeEmpty = "Communication Type cannot be empty";
	
	final String classTypeCantBeEmpty = "Classification Type cannot be empty";
	//Change for JP
	//final String COUNT_FROM_PKG_PARTY_JMS_MQ_PUB = "SELECT count(1) from PKG_PARTY_JMS_MQ_PUB WHERE ROWID_OBJECT = ";
	final String COUNT_FROM_PKG_PARTY_JMS_MQ_PUB = "SELECT count(1) from PKG_PARTY_JMS_MQ_PUB a WHERE ROWID_OBJECT = ";
	final String COUNT_FROM_C_B_PARTY = "SELECT count(1) from C_B_PARTY a WHERE ROWID_OBJECT = ";
	//Change for US905 -- MDMP-2482
	final String UPDATE_PARTY_CONSOLIDATION_IND = "{call PROC_UPDATE_CONS_IND_BO(?,?,?,?,?)}";
	final String SELECT_FROM_MATCH_MERGE_EXCLUSION_COND = "SELECT CONDITION_PARAMETER from MATCH_MERGE_EXCLUSION_COND";
	final String SELECT_FROM_MATCH_MERGE_EXCLSN_COND_PROS = "SELECT CONDITION_PARAMETER from MATCH_MERGE_EXCLSN_COND_PROS";
	
	/*Added for M4M START*/
	final String MARKETING_SRC_SYSTEMS="Marketing_Src_Systems";
	final String PROSPECT_ACCOUNT_PKEY_PREFIX="PROSPECT";
	final String PKG_MRKT_ACTN_DETAILS_NAME="MRKT_ACTN_DETAILS_PKG_NM";
	
	final String STR_COMMA=",";
	final String STR_SINGLE_QUOTE="'";
	final String STR_BLANK="";
	final String STR_SPACE=" ";
	final String STR_DASH="-";
	final String STR_OPEN_BRACKET="(";
	final String STR_CLOSE_BRACKET=")";
	final String STR_UNKNOWN="Unknown";
	
	final String BO_CLASS_CODE_PERSON = "Person";
	final String BO_CLASS_CODE_ORG = "Organization";
	
	final String ROWID_CONTACT_REL_TYPE="is Contact of";
	final String ROWID_CONTACT_HIERARCHY_TYPE="Contact Hierarchy";
	
	final String PARTY_TYPE_CUSTOMER="Customer";
	final String PARTY_TYPE_PARTNER="Partner";
	final String PARTY_TYPE_RESELLER="Reseller";
	final String PARTY_TYPE_DISTRIBUTOR="Distributor";
	final String PARTY_TYPE_PROSPECT_ACCOUNT="Prospect Customer";
	
	final String ADDRESS_TYPE_MAILING="Mailing";
	final String ADDRESS_TYPE_BILLING="Billing";
	final String CURRENT_ACTIVE_PARTY="currentActiveParty";
	final String CURRENT_SINGLETON_OR_PROSPECT_DUNS_PARTY="currentSingletonOrProspectDunsParty";
	
	final String MATCH_RULE_SET_PROPECT_ACCOUNT = "ProspectReatimeMatchRuleSet";
	final String MATCH_RULE_SET_MULTI_GEO_TILL_CITY = "MultiGeoMatchRuleSet";
	
	final String FUZZY_SEARCH_DFLT_REC_THRES_COUNT_PROP = "recToReturnCount";
	final String FUZZY_SEARCH_DFLT_MATCH_SCORE_THRES_PROP = "matchScore-Threshold";
	
	final String MFE_GET_UCN_BY_PARTY_TYPE = "MFE_GET_UCN_BY_PARTY_TYPE";
	
	final String QUERY_CONTACT_ASSOCIATION_CHECK = "CONTACT_ASSOCIATION_CHECK";
	final String QUERY_ACCOUNT_DELETED_CHECK = "ACCOUNT_DELETED_CHECK";
	final String QUERY_ACCOUNT_DNB_CHECK = "ACCOUNT_DNB_CHECK";
	final String QUERY_ACCOUNT_XREF_COUNT_CHECK = "ACCOUNT_XREF_COUNT_CHECK";
	final String QUERY_ACNT_CNTCT_PENDING_REL_BY_ACNT = "ACNT_CNTCT_PENDING_REL_BY_ACNT";
	final String QUERY_ACNT_CNTCT_PENDING_REL_BY_CNTCT = "ACNT_CNTCT_PENDING_REL_BY_CNTCT";
	final String QUERY_ROWID_PARTY_BY_SRC_PKEY = "ROWID_PARTY_BY_SRC_PKEY";
	final String QUERY_ROWID_PERSON_BY_SRC_PKEY = "ROWID_PERSON_BY_SRC_PKEY";
//	final String QUERY_ROWID_PROSPECT_BY_SRC_PKEY = "ROWID_PROSPECT_BY_SRC_PKEY";
	final String QUERY_ACNT_CNTCT_PENDING_REL_INSERT = "ACNT_CNTCT_PENDING_REL_INSERT";
	final String QUERY_ACNT_CNTCT_PENDING_REL_DELETE = "ACNT_CNTCT_PENDING_REL_DELETE";
	final String QUERY_CNTCT_ACNT_PENDING_REL_DELETE = "CNTCT_ACNT_PENDING_REL_DELETE";
	final String QUERY_ACCOUNT_PROSPECT_DNB_QUERY="ACCOUNT_PROSPECT_DNB_QUERY";
	final String QUERY_DNB_SINGLETON_QUERY = "DNB_SINGLETON_QUERY";
	final String QUERY_ACCOUNT_CONTACT_REL_QUERY = "ACCOUNT_CONTACT_REL_QUERY";
	final String QUERY_SIP_POP_QUERY = "SIP_POP_QUERY";
	final String QUERY_ROOT_UNMERGE_CHECK_QUERY = "ROOT_UNMERGE_CHECK_QUERY"; 
	final String QUERY_PARTY_CHILD_TABLE_ROWID_QUERY = "PARTY_CHILD_TABLE_ROWID_QUERY";
	final String QUERY_CNTCT_EML_BY_CNTCT_PKEY = "CNTCT_EML_BY_CNTCT_PKEY";
	final String QUERY_CNTCT_RELATIONSHIP_EXISTS = "CNTCT_RELATIONSHIP_EXISTS";
	/*US33- Sprint# 4 Code Change*/
	final String QUERY_UNKNWN_PROSPECT_NAME_EXCLUSION = "UNKNWN_PROSPECT_NAME_EXCLUSION";
	/*US55- Sprint# 5 Code Change*/
	final String QUERY_ACCT_ROWID_COUNTRY_CD = "QUERY_ACCT_ROWID_COUNTRY_CD";
	final String QUERY_IS_MERGED_WITH_SBL_CONTACT = "QUERY_IS_MERGED_WITH_SBL_CONTACT";
	final String QUERY_SBL_ACCT_ROWID_COUNTRY_CD = "QUERY_SBL_ACCT_ROWID_COUNTRY_CD";
	
	final String COLUMN_ROWID_OBJECT = "ROWID_OBJECT";
	final String COLUMN_ROWID_OBJECT_COUNT = "ROWID_OBJECT_COUNT";
	
	final String ERROR_ACCOUNT_EMPTY_NAME = "ERROR_ACCOUNT_EMPTY_NAME";
	final String ERROR_ACCOUNT_EMPTY_COUNTRY = "ERROR_ACCOUNT_EMPTY_COUNTRY";
	final String ERROR_ACCOUNT_EMPTY_BO_CODE = "ERROR_ACCOUNT_EMPTY_BO_CODE";
	final String ERROR_CREATE_ACCOUNT_PKEY_NO_CONTACT = "ERROR_CREATE_ACCOUNT_PKEY_NO_CONTACT";
	final String ERROR_ACCOUNT_EXISTING_NON_MARKETING_ACCOUNT = "ERROR_ACCOUNT_EXISTING_NON_MARKETING_ACCOUNT";
	final String ERROR_ACCOUNT_EMPTY_PKEY = "ERROR_ACCOUNT_EMPTY_PKEY";
	final String ERROR_UPSERT_ACCOUNT_EXCEPTION="ERROR_UPSERT_ACCOUNT_EXCEPTION";
	
	final String INFO_CONTACT_ASSOCIATED = "INFO_CONTACT_ASSOCIATED";
	final String INFO_ACCOUNT_EMPTY_PKEY = "INFO_ACCOUNT_EMPTY_PKEY";
	final String INFO_ACCOUNT_EXISTING_NON_MARKETING_ACCOUNT = "INFO_ACCOUNT_EXISTING_NON_MARKETING_ACCOUNT";
	final String INFO_ACCOUNT_EXISTING_DUNS_CLUSTER = "INFO_ACCOUNT_EXISTING_DUNS_CLUSTER";
	final String INFO_ACCOUNT_EXISTING_DELETED_CLUSTER = "INFO_ACCOUNT_EXISTING_DELETED_CLUSTER";
	
	final String DEAFULT_PROSPECT_STATUS = "A";
	
	final String INFO_CONTACT_EMPTY_FNAME_LNAME = "INFO_CONTACT_EMPTY_FNAME_LANME";
	final String INFO_CONTACT_EMPTY_REPTD_COMP_NAME = "INFO_CONTACT_EMPTY_REPTD_COMP_NAME";
	final String INFO_CONTACT_EMPTY_COUNTRY = "INFO_CONTACT_EMPTY_COUNTRY";
	final String INFO_CONTACT_EMPTY_EMAIL_ADDR = "INFO_CONTACT_EMPTY_EMAIL_ADDR";
	final String INFO_CONTACT_EMPTY_SRC_ACCOUNT_ID = "INFO_CONTACT_EMPTY_SRC_ACCOUNT_ID";
	
	/*Added for M4M END*/
	
	/*Added for SFDC START*/
	final String STR_N="N";
	final String STR_Y="Y";
	final String noRecordFoundSFDC = "No record Found Matching with input ACCOUNT_SOURCE_ID: ";
	/*Added for SFDC END*/
	
	/* Modified for US68-Throughput Tracker START */
	public static final String INFO_MSG_TRKN_ID_VALIDATION = "INFO_MSG_TRKN_ID_VALIDATION";
	/* Modified for US68-Throughput Tracker END */
	
	/* Added for US33-"UNKNOWN Prospect" Tracker START */
	final String INFO_CONTACT_REPTD_COMP_NAME_UNKWN = "INFO_CONTACT_REPTD_COMP_NAME_UNKWN";
	final String INFO_PROSPECT_ACCOUNT_NAME_UNKWN = "INFO_PROSPECT_ACCOUNT_NAME_UNKWN";
	/* Added for US33-"UNKNOWN Prospect" Tracker END */
	
	/*US55- Sprint# 5 Code Change*/
	final String INFO_CONTACT_COUNTRY_DIFF_ACCT_COUNTRY = "INFO_CONTACT_COUNTRY_DIFF_ACCT_COUNTRY";
	final String INFO_CONTACT_COUNTRY_DIFF_ACCT_COUNTRY_CREATE = "INFO_CONTACT_COUNTRY_DIFF_ACCT_COUNTRY_CREATE";
	
	/*Added for US449 START*/
	final String INFO_COUNTRY_STATE_MISMATCH = "INFO_COUNTRY_STATE_MISMATCH";
	final String QUERY_CHECK_PROSPECT_COUNTRY_STATE="QUERY_CHECK_PROSPECT_COUNTRY_STATE";
	final String QUERY_ERROR_CD_BY_ERROR_DESC="QUERY_ERROR_CD_BY_ERROR_DESC";
	/*Added for US449 END*/
	/*Added for US523 START*/
	final String INFO_ADDRESS_UNKNOWN_JUNK = "INFO_ADDRESS_UNKNOWN_JUNK";
	final String QUERY_ADDRESSlN1_EXCLUSION = "UNKNWN_ADDRESSLN1_EXCLUSION";
	final String QUERY_CITY_EXCLUSION = "UNKNWN_CITY_EXCLUSION";
	/*Added for US523 END*/
	
	final String PERF_LOG_FLOW_UPSERT_SAP_SBL="Upsert-SAP/SBL";
	final String PERF_LOG_FLOW_UPSERT_ELQ_ACCOUNT="Upsert-ELQ-Account";
	final String PERF_LOG_FLOW_UPSERT_ELQ_CONTACT="Upsert-ELQ-Contact";
	final String PERF_LOG_FLOW_FUZZY_SEARCH="FUZZY-SEARCH";
	final String QUERY_ELQCNT_ASSOCIATED_JAPAN = "QUERY_ELQCNT_ASSOCIATED_JAPAN";
	/** changes for Sales Force Integration -Start */
	final String SRC_SYSTEM_SFDC = "SFC";
	final String PERF_LOG_FLOW_UPSERT_SFDC="Upsert-SFDC";
	final String INFO_ACCOUNT_NAME_UNKWN = "INFO_ACCOUNT_NAME_UNKWN";
	final String INFO_CONTACT_NAME_UNKWN = "INFO_CONTACT_NAME_UNKWN";
	final String COUNT_FROM_PARTY_XREF="SELECT ROWID_XREF FROM C_B_PARTY_XREF WHERE party_type = 'Prospect Customer' and rowid_system = 'ELQ' and hub_state_ind = 1 and status_cd = 'A' and rowid_object =";
	final String QUERY_GET_CLSFN_ROWID_QUERY = "SELECT PKEY_SRC_OBJECT FROM C_B_PARTY_CLASSIFCTN_XREF where HUB_STATE_IND = 1 and rowid_system = 'MFE' and ROWID_PARTY IN (";
	final String QUERY_GET_PARTY_ROWID_QUERY="SELECT PKEY_SRC_OBJECT FROM C_B_PARTY_XREF WHERE party_type = 'Prospect Customer' and rowid_system = 'ELQ' and hub_state_ind = 1 and status_cd = 'A' and rowid_xref IN (";
	final String QUERY_GET_ORGEXTN_ROWID_QUERY = "SELECT PKEY_SRC_OBJECT FROM C_B_PARTY_ORG_EXTN_XREF where HUB_STATE_IND = 1 and rowid_system = 'MFE' and ROWID_PARTY IN (";
	final String QUERY_GET_ADDR_ROWID_QUERY = "SELECT PKEY_SRC_OBJECT FROM C_B_ADDRESS_XREF where HUB_STATE_IND = 1 and rowid_system = 'ELQ' and ROWID_PARTY IN (";
	final String QUERY_GET_COMM_ROWID_QUERY = "SELECT PKEY_SRC_OBJECT FROM C_B_PARTY_COMM_XREF where HUB_STATE_IND = 1 and rowid_system = 'ELQ' and ROWID_PARTY IN (";
	final String QUERY_GET_PROSPECT_ROWID_QUERY = "SELECT PKEY_SRC_OBJECT FROM c_b_party_prospect_XREF where HUB_STATE_IND = 1 and rowid_system = 'ELQ' and ROWID_PARTY IN (";
	public static String QUERY_GET_SYSTEMS_IN_PARTY_BY_ROWID="SELECT 1 FROM C_B_PARTY_XREF WHERE ROWID_SYSTEM='DNB' AND HUB_STATE_IND = 1 AND ROWID_OBJECT=";
	public static String DRAFT_ACCOUNT = "Draft_Account";
	public static String END_CUSTOMER_ACCOUNT = "End_Customer_Account";
	public static String PARTNER_ACCOUNT  = "Partner_Account";
	public static String END_USER = "End User";
	public static String SEND_FOR_DS = "SEND_FOR_DS";
	public static String SEND_FOR_DNB = "SEND_FOR_DNB";
	public static String QUERY_UPDATE_MQ_SENT_STATE="update C_REPOS_MQ_DATA_CHANGE set SENT_STATE_ID = 1, LAST_UPDATE_DATE=SYSTIMESTAMP where ROWID_MQ_DATA_CHANGE = ?";
	public static String QUERY_GET_LINE_OF_BUS = "select LINE_OF_BUS from SIC_LOB_MAPPING where PRIM_SIC = ";
	/*public static String CHECK_IF_USER_IN_DS_ROLE = "select usr.FULL_NAME from C_REPOS_USER usr,C_REPOS_SAM_ROLE_USER_REL rel,C_REPOS_SAM_ROLE srole where usr.ROWID_USER=rel.ROWID_USER and rel.ROWID_SAM_ROLE=srole.ROWID_SAM_ROLE and srole.ROLE_NAME like '%Data Steward%' and usr.USER_NAME=?";
	public static String UNMERGE_SRC_UPDATE_BY ="SELECT updated_by FROM c_b_party_hmrg,dsu_users where src_rowid_object = '||in_rowid_object||'  and tgt_rowid_object = '||in_rowid_object_matched||'  and unmerge_date is not null ";
	public static String UNMERGE_MTCH_UPDATE_BY ="SELECT updated_by   FROM c_b_party_hmrg,dsu_users where src_rowid_object = '||in_rowid_object_matched ||' and tgt_rowid_object = '||in_rowid_object||' and unmerge_date is not null";*/
	// Added for SFDC - MDM account integration Error Handling
	    final String ERROR_ACCOUNT_MSG_TRKN_ID_VALIDATION = "ERROR_ACCOUNT_MSG_TRKN_ID_VALIDATION";
	    final String ERROR_ACCOUNT_ADDR_INVALID="ERROR_ACCOUNT_ADDR_INVALID";
		final String ERROR_ACCOUNT_INVALID_PTY_TYP = "ERROR_ACCOUNT_INVALID_PTY_TYP";
		final String ERROR_ACCOUNT_NAME_UNKWN="ERROR_ACCOUNT_NAME_UNKWN";
		final String ERROR_ACCOUNT_ADDR_LN1_UNKWN="ERROR_ACCOUNT_ADDR_LN1_UNKWN";
		final String ERROR_ACCOUNT_CITY_UNKWN="ERROR_ACCOUNT_CITY_UNKWN";
		final String ERROR_DRAFT_ACCOUNT_UPD="ERROR_DRAFT_ACCOUNT_UPD";
		final String ERROR_ACCOUNT_WRONG_ORG="ERROR_ACCOUNT_WRONG_ORG";
		final String ERROR_ACCOUNT_WRONG_ACC_TYP="ERROR_ACCOUNT_WRONG_ACC_TYP";
		final String ERROR_ACCOUNT_INVALID_TRL_NM_IND="ERROR_ACCOUNT_INVALID_TRL_NM_IND";
		final String ERROR_ACCOUNT_INVALID_TRL_ADDR_IND="ERROR_ACCOUNT_INVALID_TRL_ADDR_IND";
		final String ERROR_ACCOUNT_DQ_CHECK_FAIL="ERROR_ACCOUNT_DQ_CHECK_FAIL";
		final String ERROR_ACCOUNT_DATA_VALID_FAIL="ERROR_ACCOUNT_DATA_VALID_FAIL";
		final String ERROR_ACC_EXT_ACC_SLF_MTCH_FAIL="ERROR_ACC_EXT_ACC_SLF_MTCH_FAIL";
		final String ERROR_ACC_NEW_ACC_UCN_MTCH_FAIL="ERROR_ACC_NEW_ACC_UCN_MTCH_FAIL";
		final String ERROR_ACC_EXT_ACC_PUT_W_DNB_FAIL="ERROR_ACC_EXT_ACC_PUT_W_DNB_FAIL";
		final String ERROR_ACC_EXT_ACC_PUT_FAIL="ERROR_ACC_EXT_ACC_PUT_FAIL";
		final String ERROR_ACC_NEW_ACC_PUT_W_ROWID_FAIL="ERROR_ACC_NEW_ACC_PUT_W_ROWID_FAIL";
		final String ERROR_ACC_NEW_ACC_PUT_FAIL="ERROR_ACC_NEW_ACC_PUT_FAIL";
		final String ERROR_ACC_TOKENIZE_FAIL="ERROR_ACC_TOKENIZE_FAIL";
		final String ERROR_ACC_MATCH_EXCLUSION="ERROR_ACC_MATCH_EXCLUSION";
		final String ERROR_ACC_MATCH_FAIL="ERROR_ACC_MATCH_FAIL";
		final String ERROR_ACC_MERGE_EXCLUSION_FAIL ="ERROR_ACC_MERGE_EXCLUSION_FAIL";
		final String ERROR_ACC_MERGE_FAIL="ERROR_ACC_MERGE_FAIL";
		final String ERROR_ACC_P2C_FAIL="ERROR_ACC_P2C_FAIL";
		final String ERROR_ACC_UCN_STAMP_FAIL="ERROR_ACC_UCN_STAMP_FAIL";
		final String ERROR_ACC_XREF_UPDATE_FAIL="ERROR_ACC_XREF_UPDATE_FAIL";
		final String ERROR_ACC_NEW_ACC_SEG_FAIL="ERROR_ACC_NEW_ACC_SEG_FAIL";
		final String ERROR_WRONG_ACCOUNT_DRAFT_FLAG="ERROR_WRONG_ACCOUNT_DRAFT_FLAG";
		final String ERROR_ACCOUNT_WRONG_PARTNER_TYPE="ERROR_ACCOUNT_WRONG_PARTNER_TYPE";
		final String ERROR_ACCOUNT_DUPLICATE_CLASFCTN="ERROR_ACCOUNT_DUPLICATE_CLASFCTN";
		final String ERROR_ACCOUNT_DUPLICATE_ORGEXTN="ERROR_ACCOUNT_DUPLICATE_ORGEXTN";
		final String ERROR_ACCOUNT_DUPLICATE_RELSHIP="ERROR_ACCOUNT_DUPLICATE_RELSHIP";
		//Error codes for Contact

		final String ERROR_CONTACT_COUNTRY_STATE_MISMATCH = "ERROR_CONTACT_COUNTRY_STATE_MISMATCH";
		final String ERROR_CONTACT_EMPTY_FNAME_LANME = "ERROR_CONTACT_EMPTY_FNAME_LANME";
		final String ERROR_CONTACT_EMPTY_COUNTRY = "ERROR_CONTACT_EMPTY_COUNTRY";
		final String ERROR_CONTACT_EMPTY_EMAIL_ADDR = "ERROR_CONTACT_EMPTY_EMAIL_ADDR";
		final String ERROR_CONTACT_MSG_TRKN_ID_VALIDATION = "ERROR_CONTACT_MSG_TRKN_ID_VALIDATION";
		final String ERROR_CONTACT_EMPTY_SRC_CONTACT_ID = "ERROR_CONTACT_EMPTY_SRC_CONTACT_ID";
		final String ERROR_CONTACT_INVALID_PTY_TYP = "ERROR_CONTACT_INVALID_PTY_TYP";
		final String ERROR_CONTACT_DATA_VALID_FAIL = "ERROR_CONTACT_DATA_VALID_FAIL";
		final String ERROR_CONTACT_NAME_UNKWN="ERROR_CONTACT_NAME_UNKWN";
		final String ERROR_CONTACT_ADDR_LN1_UNKWN = "ERROR_CONTACT_ADDR_LN1_UNKWN";
		final String ERROR_CONTACT_CITY_UNKWN = "ERROR_CONTACT_CITY_UNKWN";
		final String ERROR_CONTACT_DQ_CHECK_FAIL ="ERROR_CONTACT_DQ_CHECK_FAIL" ;
		final String ERROR_CONTACT_CLEANSE_PUT_FAIL ="ERROR_CONTACT_CLEANSE_PUT_FAIL"; 
		final String ERROR_CONTACT_TOKENIZE_FAIL = "ERROR_CONTACT_TOKENIZE_FAIL";
		final String ERROR_CONTACT_MATCH_FAIL = "ERROR_CONTACT_MATCH_FAIL";
		final String ERROR_CONTACT_MERGE_FAIL = "ERROR_CONTACT_MERGE_FAIL";
		final String ERROR_CONTACT_UCN_STAMP_FAIL ="ERROR_CONTACT_UCN_STAMP_FAIL";
		final String ERROR_CONTACT_XREF_UPDATE_FAIL ="ERROR_CONTACT_XREF_UPDATE_FAIL";
		final String ERROR_CONTACT_PREPARE_RESPONSE_FAIL ="ERROR_CONTACT_PREPARE_RESPONSE_FAIL";
		final String ERROR_CONTACT_WRONG_CONTACT_TYP="ERROR_CONTACT_WRONG_CONTACT_TYP";
		final String ERROR_CONTACT_ADDR_INVALID="ERROR_CONTACT_ADDR_INVALID";
		final String ERROR_ACTCNTREL_CLEANSE_PUT_FAIL="ERROR_ACTCNTREL_CLEANSE_PUT_FAIL";
	/** changes for Sales Force Integration -End */
		final String PERF_LOG_FLOW_HIERARCHY_FUZZY_SEARCH="HIERARCHY_FUZZY-SEARCH";
	    final String McAfee_Hierarchy = "McAfee Hierarchy";
	    final String Partner_Hierarchy = "Partner Reseller Hierarchy";
	    final String Subsidiary_Hierarchy = "Subsidiary Hierarchy";
	    final String srcSysCantbeNull = "Source system name also as a mandatory field, when source system id is present";
	    final String allAccntSearchParameterNotNull = "Party Name ,Address Line 1, UCN and Source system id should not be present in same request.";
	    final String PERF_LOG_FLOW_CONTACT_FUZZY_SEARCH="CONNTACT_FUZZY-SEARCH";
	/*Added for MDMP-2885 START*/
	final String RESTRICTED_PARTY_WS_URL = "RestrictedParty-WS.URL";
	/*Added for MDMP-2885 END*/
	final String isPartnerParentOf = "is PTNR parent of";
	    final String countryCantbeNull = "Country is a mandatory field, when Party Name is present in same request";
		//for Contact Fuzzy Search service Track 4
		final String contactSearchCriteriaTypeCantBeNull  = "Contact Search Criteria Type Cant Be Null";
		final String SearchContactRequestCantBeNull = "Search Contact Request Cant Be Null";
		final String ERROR = "ERROR";
		final String SUCCESS = "SUCCESS";
		final String QUERY_ACNT_CNTCT_PENDING_REL_BY_ACNT_SFC="ACNT_CNTCT_PENDING_REL_BY_ACNT_SFC";
		final String QUERY_ACNT_CNTCT_PENDING_REL_INSERT_SFC= "ACNT_CNTCT_PENDING_REL_INSERT_SFC";
		final String QUERY_ACNT_CNTCT_PENDING_REL_DELETE_SFC= "ACNT_CNTCT_PENDING_REL_DELETE_SFC";
		final String QUERY_CNTCT_ACNT_PENDING_REL_DELETE_SFC= "CNTCT_ACNT_PENDING_REL_DELETE_SFC";
		final String QUERY_ACNT_CNTCT_PENDING_REL_BY_CNTCT_SFC="ACNT_CNTCT_PENDING_REL_BY_CNTCT_SFC";
		final String QUERY_ROWID_PERSON_BY_SRC_PKEY_SFC = "ROWID_PERSON_BY_SRC_PKEY_SFC";
		final String QUERY_ROWID_PERSON_BY_SRC_PKEY_ADB = "ROWID_PERSON_BY_SRC_PKEY_ADB";
		public static String QUERY_GET_ID_IN_PARTY_BY_PKEY="SELECT 1 FROM C_B_PARTY_XREF WHERE BO_CLASS_CODE = 'Organization' AND ROWID_SYSTEM='SFC' AND HUB_STATE_IND = 1 AND PKEY_SRC_OBJECT=";
		public static String QUERY_GET_ID_IN_PARTY_BY_PKEY_ADB="SELECT 1 FROM C_B_PARTY_XREF WHERE BO_CLASS_CODE = 'Organization' AND ROWID_SYSTEM='ADB' AND HUB_STATE_IND = 1 AND PKEY_SRC_OBJECT=";
		public static String QUERY_GET_REL_IN_TEMP="select 1 from MDM_RTS_MRKT_ACC_CONTACT_REL where ACNT_ROWID_OBJECT = ";
		public static String QUERY_CNTCT_RELATIONSHIP_EXISTS_SFC = "CNTCT_RELATIONSHIP_EXISTS_SFC";
		public static String QUERY_DELETE_JUNK_TOKEN = "delete from  c_b_party_strp where ssa_key like 'K$$$$$$%' and rowid_object=?";
		public static String  QUERY_CHECK_SFDC_COUNTRY_STATE = "QUERY_CHECK_SFDC_COUNTRY_STATE";
		public static String QUERY_GET_ACT_SFC_EXIST="SELECT 1 FROM C_B_PARTY_XREF WHERE BO_CLASS_CODE = 'Person' AND  ROWID_SYSTEM='SFC' AND STATUS_CD = 'A' AND ROWID_OBJECT=";
		public static String QUERY_GET_ACT_HIER_EXIST= "SELECT COUNT(1) FROM C_B_PARTY_REL WHERE ROWID_REL_TYPE  = '3' AND ROWID_HIERARCHY = '3' AND HUB_STATE_IND  <>-1 AND ROWID_PARTY_2   =";
		public static String QUERY_GET_DUPLICATE_HIER_EXIST= "SELECT COUNT(1) FROM C_B_PARTY_REL WHERE ROWID_REL_TYPE  = '2' AND ROWID_HIERARCHY = '2' AND HUB_STATE_IND  <>-1 AND ROWID_PARTY_2   =";
		public static String QUERY_GET_DUPLICATE_ORGEXTN_EXIST=  "SELECT COUNT(1) FROM C_B_PARTY_ORG_EXTN WHERE HUB_STATE_IND  <>-1 AND ROWID_PARTY   =";
		public static String QUERY_GET_DUPLICATE_CLASFCTN_EXIST= "Select count(1) from c_b_party_classifctn where HUB_STATE_IND =1 and rowid_party  = ? group by classifctn_type, end_date having count(*)>1";
		public static String QUERY_GET_DUPLICATE_CLASFCTN_XREF_EXIST= "Select count(1) from c_b_party_classifctn_xref where HUB_STATE_IND =1 and  rowid_object in (select rowid_object from c_b_party_classifctn where rowid_party  = ? ) group by classifctn_type, end_date having count(*)>1";
		
		public static String QUERY_GET_ACTIVE_CLASFCTN_EXIST= "Select count(1) from c_b_party_classifctn where HUB_STATE_IND =1 and rowid_party  = ?";
		public static String QUERY_GET_ACTIVE_CLASFCTN_XREF_EXIST= "Select count(1) from c_b_party_classifctn_xref where HUB_STATE_IND =1 and  rowid_object in (select rowid_object from c_b_party_classifctn where rowid_party  in (select rowid_object from c_b_party_xref where pkey_src_object = ?) )";
		public static String QUERY_GET_ACTIVE_ORGEXTN_XREF_EXIST=  "Select count(1) from C_B_PARTY_ORG_EXTN_XREF where HUB_STATE_IND =1 and  rowid_object in (select rowid_object from C_B_PARTY_ORG_EXTN where rowid_party  in (select rowid_object from c_b_party_xref where pkey_src_object = ?))";
		
		public static String QUERY_GET_ACTIVE_CLASFCTN_XREF_EXIST_BY_PTYID= "Select count(1) from c_b_party_classifctn_xref where HUB_STATE_IND =1 and  rowid_object in (select rowid_object from c_b_party_classifctn where rowid_party = ? )";
		public static String QUERY_GET_ACTIVE_ORGEXTN_XREF_EXIST_BY_PTYID=  "Select count(1) from C_B_PARTY_ORG_EXTN_XREF where HUB_STATE_IND =1 and  rowid_object in (select rowid_object from C_B_PARTY_ORG_EXTN where rowid_party = ?)";
	
		public static String QUERY_GET_ACTIVE_SALES_SEGMENT_EXIST_BY_PTYID = "Select count(1) from c_b_party_classifctn_xref where HUB_STATE_IND =1 and  rowid_object in (select rowid_object from c_b_party_classifctn where rowid_party = ?  and  upper(CLASSIFCTN_TYPE) = upper('Sales_Segment') AND CLASSIFCTN_VALUE = ?  and TRUNC(END_DATE)= '31-DEC-9999' and hub_state_ind =1)";
		
		// FNO Integration
		final String ERROR_ACCOUNT_STATE_UNKWN="ERROR_ACCOUNT_STATE_UNKWN";
		final String ERROR_ACCOUNT_COUNTRY_UNKWN="ERROR_ACCOUNT_COUNTRY_UNKWN";
		final String ERROR_ACCOUNT_POSTALCODE_UNKWN="ERROR_ACCOUNT_POSTALCODE_UNKWN";
	    final String ERROR_ACCOUNT_CUST_GROUP_INVALID = "ERROR_ACCOUNT_CUST_GROUP_INVALID";
	    final String ERROR_LOV_LOOKUP_FAILED = "ERROR_MDM_LOV_LOOKUP_FAILED";
	    final String ERROR_ACCOUNT_JP_COUNTRY_FAILED = "ERROR_ACCOUNT_JP_COUNTRY_FAILED";
	    final String SRC_SYSTEM_FNO = "FNO";
	    final String PERF_LOG_FLOW_UPSERT_FNO="Upsert-FNO";
		
	    
	    final String SRC_SYSTEM_ADB = "ADB";
	    final String PERF_LOG_FLOW_UPSERT_ADB="Upsert-ADB";
	    final String ADOBE_SEARCH_BEST_MATCH="Best Match";
	    
	    final String PERF_LOG_FLOW_UPSERT_ADB_PROSPECT_ACCOUNT="Upsert-ADB-Prospect-Account";
	    
	    final String QUERY_ACCOUNT_ASSOCIATION_CHECK = "ACCOUNT_ASSOCIATION_CHECK";
		final String QUERY_ADOBE_ACCOUNT_XREF_COUNT_CHECK = "ADOBE_ACCOUNT_XREF_COUNT_CHECK";
		final String MATCH_RULE_SET_ADOBE_MULTI_GEO_TILL_CITY = "AdobeMultiGeoMatchRuleSet";
		final String QUERY_ROWID_ADOBE_PERSON_BY_SRC_PKEY = "ROWID_ADOBE_PERSON_BY_SRC_PKEY";
		
		final String PERF_LOG_FLOW_UPSERT_ADB_CONTACT="Upsert-ADB-Contact";
		final String QUERY_FETCH_CONTACT_ROWID_BY_ACCT_PKEY = "FETCH_CONTACT_ROWID_BY_ACCT_PKEY";
		final String QUERY_MATCH_RECORD_INSERT = "MATCH_RECORD_INSERT";

		
		final String SRC_SYSTEM_SAP = "SAP";
		final String PERF_LOG_FLOW_UPSERT_SAP="Upsert-SAP";
		final String ADOBE_QUERY_GET_ORGEXTN_ROWID_QUERY = "SELECT PKEY_SRC_OBJECT FROM C_B_PARTY_ORG_EXTN_XREF a INNER JOIN C_B_PARTY_ORG_EXTN b ON a.ROWID_OBJECT=b.ROWID_OBJECT where a.HUB_STATE_IND = 1 and a.rowid_system = 'MFE' and b.ROWID_PARTY=";
		final String ADOBE_QUERY_GET_CLSFN_ROWID_QUERY = "SELECT PKEY_SRC_OBJECT FROM C_B_PARTY_CLASSIFCTN_XREF a INNER JOIN C_B_PARTY_CLASSIFCTN b ON a.ROWID_OBJECT = b.ROWID_OBJECT where a.HUB_STATE_IND = 1 and a.rowid_system = 'MFE' and b.ROWID_PARTY =";
		final String ADOBE_QUERY_GET_PROSPECT_ROWID_QUERY = "SELECT PKEY_SRC_OBJECT FROM c_b_party_prospect_xref a inner join c_b_party_prospect b on a.ROWID_OBJECT = b.ROWID_OBJECT where  a.HUB_STATE_IND = 1 and a.rowid_system = 'ADB' and b.ROWID_PARTY=";
		final String ADOBE_COUNT_FROM_PARTY_XREF="SELECT PKEY_SRC_OBJECT FROM C_B_PARTY_XREF WHERE party_type = 'Prospect Customer' and rowid_system = 'ADB' and hub_state_ind = 1 and status_cd = 'A' and rowid_object =";
		final String PARTY_TYPE_PERSON="Person";
		final String STATUS_ACTIVE="Active";
		final String ADB_ACT_PREFIX="ACT-";
		final String ADB_CNT_PREFIX="CNT-";
		final String DB_CONN_FAILURE="ERROR_DB_CONNECTION_FAILURE";
		final String CUSTOM_PROCESS_ERROR="ERROR_CUSTOM_PROCESSING";
}

