package com.mcafee.mdm.constants;

/**
 * The interface contains field names of ACCOUNT Landing table/Base Object 
 *
 */
public interface AccountAttributes {
	
	
	public static final String ACCT_NAME = "ACCT_NAME";
	public static final String ALIAS_NAME = "ALIAS_NAME";
	public static final String ACCOUNT_REGION = "REGION";
	public static final String ACCOUNT_GEO = "GEO";
	public static final String MARKET = "MARKET";
	public static final String ACCT_STATUS = "ACCT_STATUS";
	public static final String ACCT_TYPE = "ACCT_TYPE";
	public static final String CUST_GROUP = "CUST_GROUP";
	public static final String PRICE_GROUP = "PRICE_GROUP";
	public static final String COMPANY_CD = "COMPANY_CD";
	public static final String ACCOUNT_VAT_REG_NBR = "VAT_REG_NBR";
	public static final String TAX_TYPE = "TAX_TYPE";
	public static final String ACCOUNT_TAX_JURSDCTN_CD = "TAX_JURSDCTN_CD";
	public static final String BILL_BLOCK_CD = "BILL_BLOCK_CD";
	public static final String ORDR_BLOCK_CD = "ORDR_BLOCK_CD";
	public static final String DLVRY_BLOCK_CD = "DLVRY_BLOCK_CD";
	public static final String POST_BLOCK_CD = "POST_BLOCK_CD";
	public static final String SALE_BLOCK_CD = "SALE_BLOCK_CD";
	public static final String CHANNEL_ID = "CHANNEL_ID";
	public static final String PARTNER_TYPE = "PARTNER_TYPE";
	public static final String VENDOR_NBR = "VENDOR_NBR";
	public static final String DIRECT_IND = "DIRECT_IND";
	public static final String NAMED_ACCT_IND = "NAMED_ACCT_IND";
	public static final String NON_VAL_ACCT_IND = "NON_VAL_ACCT_IND";
	public static final String PARTNER_IND = "PARTNER_IND";
	public static final String SIEBEL_ROWID = "SIEBEL_ROWID";
	public static final String SAP_CUST_NUMBER = "SAP_CUST_NUMBER";
	public static final String MDM_LEGACY_ID = "MDM_LEGACY_ID";
	public static final String DATA_SRC_SYSTEM = "DATA_SRC_SYSTEM";
	public static final String ENGLISH_NAME = "ENGLISH_NAME";
	public static final String SAP_NAME_1 = "SAP_NAME_1";
	public static final String SAP_NAME_2 = "SAP_NAME_2";
	public static final String SAP_NAME_3 = "SAP_NAME_3";
	public static final String SAP_NAME_4 = "SAP_NAME_4";
	public static final String NAME_QUALITY_IDENTIFIER = "NAME_QUALITY_IDENTIFIER";
	
	/** Modified for SFDC START */
	public static final String SFID = "SFID";
	public static final String DRAFT_FLG = "DRAFT_FLG";
	/** Modified for SFDC END */
	/** changes for Sales Force Integration -Start */
	public static final String LOCAL_NAME = "LOCAL_NAME";
	public static final String CURRENCY_CD = "CURRENCY_CODE";
	public static final String TAX_ID = "TAX_ID";
	public static final String PRICING_BAND_AGRMNT = "PRICING_BAND_AGRMNT";
	/** changes for Sales Force Integration -End */
	/** changes for Track-2 -Start */
	public static final String SITE_DESIGNATION = "SITE_DESIGNATION";
	/** changes for Track-2 -End */
	/*Change for MDMP-2885 :: START*/
	public static final String IS_DENIED_FLG = "IS_DENIED_FLG";
	/*Change for MDMP-2885 :: END*/
	/** changes for Track-3 -Start */
	public static final String CLEANSE_IND = "CLEANSE_IND";
	public static final String RESELL_LEVEL = "RESELL_LEVEL";
	public static final String PARTNERSHIP_STATUS = "PARTNERSHIP_STATUS";
	/** changes for Track-3 -End */
}
