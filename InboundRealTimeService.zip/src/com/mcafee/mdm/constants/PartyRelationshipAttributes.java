package com.mcafee.mdm.constants;

/**
 * The interface contains field names of PARTY_REL Landing table/Base Object 
 *
 */
public interface PartyRelationshipAttributes {
	
	public static final String PARENT_ROWID_PARTY = "PARENT_ID";
	public static final String HIERARCHY_TYPE = "HIERARCHY_CODE";
	public static final String REL_TYPE = "REL_TYPE_CODE";
	public static final String GLOBAL_PARENT_ROWID_PARTY = "";

}
