package com.mcafee.mdm.constants;

/**
 * The interface contains field names of PARTY_ORG_EXTN Landing table/Base Object 
 *
 */
public interface PartyOrgExtAttributes {
	
	public static final String ORG_DUNS_NBR = "ORG_DUNS_NBR";
	public static final String TRADE_NAME = "TRADE_NAME";
	public static final String TRADE_NAME_2 = "TRADE_NAME_2";
	public static final String SITE_EMPL_CNT = "SITE_EMPL_CNT";
	public static final String GLBL_EMPL_CNT = "GLBL_EMPL_CNT";
	public static final String VERTICAL = "VERTICAL";
	public static final String REVENUE = "REVENUE";
	public static final String LINE_OF_BUS = "LINE_OF_BUS";
	public static final String PRIM_SIC = "PRIM_SIC";
	public static final String SEC_SIC = "SEC_SIC";
	public static final String SALES_VOLUME = "SALES_VOLUME";
	public static final String SALES_AMOUNT = "SALES_AMOUNT";
	public static final String CURRENCY_CD = "CURRENCY_CD";
	public static final String OUT_OF_BUS_IND = "OUT_OF_BUS_IND";
	public static final String GLBL_ULT_IND = "GLBL_ULT_IND";
	public static final String FORTUNE_INFO = "FORTUNE_INFO";
	public static final String HIERARCHY_LEVEL = "HIERARCHY_LEVEL";
	public static final String ORG_HQ_PARENT_DUNS = "ORG_HQ_PARENT_DUNS";
	public static final String ORG_DOM_ULT_DUNS = "ORG_DOM_ULT_DUNS";
	public static final String ORG_GLB_ULT_DUNS = "ORG_GLB_ULT_DUNS";
	public static final String MFE_PRTNR_PARENT_ORG = "MFE_PRTNR_PARENT_ORG";
	public static final String MFE_WW_PARENT_PRTN_NM = "MFE_WW_PARENT_PRTN_NM";
	public static final String MFE_SUBSDRY_PARENT_PRTN_NM = "MFE_SUBSDRY_PARENT_PRTN_NM";
	public static final String PTR_PARENT_UCN = "PTR_PARENT_UCN";
	public static final String PTR_PARENT_NM = "PTR_PARENT_NM";
	public static final String PTR_GLBL_PARENT_UCN = "PTR_GLBL_PARENT_UCN";

}
