package com.mcafee.mdm.constants;

public interface PartyPersonAttributes {
	
	public static final String FIRST_NAME = "FIRST_NAME";
	public static final String MIDDLE_NAME = "MIDDLE_NAME";
	public static final String LAST_NAME = "LAST_NAME";
	public static final String PREFIX = "PREFIX";
	public static final String SUFFIX = "SUFFIX";
	public static final String JOB_TITLE = "JOB_TITLE";
	public static final String JOB_FUNCTION= "JOB_FUNCTION";
	public static final String PERSON_STATUS = "PERSON_STATUS";
	public static final String SAP_INTEGRATION_ID = "SAP_INTEGRATION_ID";
	public static final String PERSON_TYPE = "PERSON_TYPE";
	public static final String PREF_LANGUAGE = "PREF_LANGUAGE";
	public static final String LIST_SOURCE = "LIST_SOURCE";
	public static final String DATA_SRC_SYS = "DATA_SRC_SYS";
	public static final String LATTICE_SCORE = "LATTICE_SCORE";
	public static final String REPTD_COMP_NAME = "REPTD_COMP_NAME";
	public static final String JOB_LEVEL = "JOB_LEVEL";
	public static final String SRC_UPD_BY = "SRC_UPD_BY";
	/** Added for SFDC - Track4 - Start */
	public static final String SRC_ACCOUNT_ID = "SRC_ACCOUNT_ID";
	public static final String JOB_ROLE = "JOB_ROLE";
	public static final String PARTNER_CONTACT_FLG = "PARTNER_CONTACT_FLG";
	public static final String CLEANSE_IND = "CLEANSE_IND";
	/** Added for SFDC - Track4 - End */
}
