package com.mcafee.mdm.constants;


public interface SearchMatchAttributes {
	final String EX_ADDRESS_LN1 = "Ex_Address_Ln1";
	final String EX_ADDRESS_LN2 = "Ex_Address_Ln2";
	final String EX_ADDRESS_TYPE = "Ex_Address_Type";
	final String EX_ADDR_PART1 = "Ex_Address_Part1";
	final String ADDR_PART1 = "Address_Part1";
	final String ADDR_PART2 = "Address_Part2";
	final String EX_CITY = "Ex_City";
	final String EX_COUNTRY_CD = "Ex_Country_Cd";
	final String EX_STATE = "Ex_State";
	final String EX_PARTY_TYPE = "Ex_Party_Type";
	final String EX_ENTITY_TYPE = "Ex_Entity_Type";
	final String EX_ORGANIZATION_NAME = "Ex_Organization_Name";
	final String ORGANIZATION_NAME = "Organization_Name";
	final String ATTRIBUTE2 = "Attribute2";
	final String CREATE_DATE="CREATE_DATE";
	final String MATCH_SCORE="MATCH_SCORE";
	final String EX_UCN = "Ex_UCN";
	final String Ex_Partner_Type = "Ex_Partner_Type";
}
