package com.mcafee.mdm.constants;

/**
 * The interface contains field names of PARTY XREF table 
 *
 */
public interface PartyXREFAttributes {
	
	public static final String SRC_SYSTEM = "SRC_SYSTEM";
	public static final String SRC_PKEY = "SRC_PKEY";

}
