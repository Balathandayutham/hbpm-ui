package com.mcafee.mdm.constants;

/**
 * The interface contains field names of PARTY_COMM Landing table/Base Object 
 *
 */
public interface CommunicationAttributes {
	
	public static final String COMM_TYPE = "COMM_TYPE";
	public static final String COMM_VALUE = "COMM_VALUE";
	public static final String COMM_STATUS = "COMM_STATUS";
	public static final String PRFRD_COMM_IND = "PRFRD_COMM_IND";
	public static final String WEB_DOMAIN = "WEB_DOMAIN";
	public static final String COMM_MKTG_PREF= "COMM_MKTG_PREF";
	public static final String COMM_EXTN = "COMM_EXTN";
	/** Added for SFDC - Start */
	public static final String COMM_DRAFT_FLAG ="DRAFT_FLAG";
	/** Added for SFDC - End */
	/** Added for SFDC - Track4 - Start */
	public static final String COMM_SALES_PREF = "COMM_SALES_PREF";
	/** Added for SFDC - Track4 - End */
}
