package com.mcafee.mdm.constants;

/**
 * The interface contains field names of PARTY_PROSPECT Landing table/Base Object 
 *
 */
public interface ProspectAttributes {
	public static final String PROSPECT_NAME = "PROSPECT_NAME";
	public static final String ALIAS_NAME = "ALIAS_NAME";
	public static final String PROSPECT_REGION = "PROSPECT_REGION";
	public static final String PROSPECT_GEO = "PROSPECT_GEO";
	public static final String PROSPECT_STATUS = "PROSPECT_STATUS";
	public static final String PROSPECT_GROUP = "PROSPECT_GROUP";
	public static final String PROSPECT_TYPE = "PROSPECT_TYPE";
	public static final String NON_VAL_ACCT_IND = "NON_VAL_ACCT_IND";
	public static final String DATA_SRC_SYSTEM = "DATA_SRC_SYSTEM";
	public static final String SRC_UPD_BY = "SRC_UPD_BY";
	public static final String NAME_QUALITY_IDENTIFIER = "NAME_QUALITY_IDENTIFIER";
	
	/*Change for MDMP-2885 :: START*/
	public static final String IS_DENIED_FLG = "IS_DENIED_FLG";
	/*Change for MDMP-2885 :: END*/
}
