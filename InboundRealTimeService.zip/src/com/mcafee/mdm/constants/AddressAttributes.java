package com.mcafee.mdm.constants;

/**
 * The interface contains field names of ADDRESS Landing table/Base Object 
 *
 */
public interface AddressAttributes {
	
	public static final String ROWID_ADDRESS_XREF = "ROWID_XREF";
	public static final String ADDR_LN1 = "ADDR_LN1";
	public static final String ADDR_LN2 = "ADDR_LN2";
	public static final String ADDR_LN3 = "ADDR_LN3";
	public static final String ADDR_LN4 = "ADDR_LN4";
	public static final String CITY = "CITY";
	public static final String COUNTY = "COUNTY";
	public static final String DISTRICT = "DISTRICT";
	public static final String STATE_CD = "STATE_CD";
	public static final String POSTAL_CD = "POSTAL_CD";
	public static final String COUNTRY_CD = "COUNTRY_CD";
	public static final String LANG_CD = "LANG_CD";
	public static final String LONGITUDE = "LONGITUDE";
	public static final String LATITUDE = "LATITUDE";
	public static final String ADDR_TYPE = "ADDR_TYPE";
	public static final String ADDR_STATUS = "ADDR_STATUS";
	public static final String ADDR_MKTG_PREF ="ADDR_MKTG_PREF";
	public static final String ADDRESS_QUALITY_IDENTIFIER ="ADDRESS_QUALITY_IDENTIFIER";
	/** Added for SFDC - Start */
	public static final String ADDRESS_DRAFT_FLAG ="DRAFT_FLAG";
	/** Added for SFDC - End */

}
