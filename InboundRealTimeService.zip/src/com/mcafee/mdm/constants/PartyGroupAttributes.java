package com.mcafee.mdm.constants;

/**
 * The interface contains field names of PARTY GROUP Landing table/Base Object 
 *
 */
public interface PartyGroupAttributes {
	
			
	public static final String ENTITY_TYPE = "ENTITY_TYPE";
	public static final String ENTITY_TYPE_DESC = "ENTITY_TYPE_DESC";
	public static final String PARTY_GROUP_NAME = "PARTY_GROUP_NAME";
	public static final String LEVEL_1 = "LEVEL_1";
	public static final String GLBL_PAR_NAME = "GLBL_PAR_NAME";
	public static final String GLBL_PAR_NUMBER = "GLBL_PAR_NUMBER";
	public static final String GLBL_PAR_METHOD = "GLBL_PAR_METHOD";
	public static final String GLBL_PAR_NAME_OVRIDE = "GLBL_PAR_NAME_OVRIDE";
	public static final String GLBL_PAR_NAME_OVRIDE_METH = "GLBL_PAR_NAME_OVRIDE_METH";
	public static final String GLB_EMP_CNT_OVERRIDE = "GLB_EMP_CNT_OVERRIDE";
	public static final String GLB_EMP_CNT_OVERIDE_METH = "GLB_EMP_CNT_OVERIDE_METH";
	public static final String G2K_FLG = "G2K_FLG";
	public static final String GLB_VERTICAL = "GLB_VERTICAL";
	public static final String GLB_VERTICAL_OVERRIDE = "GLB_VERTICAL_OVERRIDE";
	public static final String GLB_VERTICAL_OVERRIDE_METH = "GLB_VERTICAL_OVERRIDE_METH";
	public static final String GLB_SALES_REVNU = "GLB_SALES_REVNU";
	public static final String GLB_SALES_REVNU_OVRID = "GLB_SALES_REVNU_OVRID";
	
}
