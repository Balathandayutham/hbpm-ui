package com.mcafee.mdm.constants;

/**
 * The interface contains field names of PARTY_PRSN_EXTN Landing table/Base Object 
 *
 */
public interface PartyPersonExtAttributes {
	
	public static final String PREFIX = "PREFIX";
	public static final String FIRST_NAME = "FIRST_NAME";
	public static final String MIDDLE_NAME = "MIDDLE_NAME";
	public static final String LAST_NAME = "LAST_NAME";
	public static final String SUFFIX = "SUFFIX";
	public static final String PERSON_TYPE = "PERSON_TYPE";

}
