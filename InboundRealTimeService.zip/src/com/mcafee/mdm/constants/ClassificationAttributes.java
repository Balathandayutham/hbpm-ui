package com.mcafee.mdm.constants;

/**
 * The interface contains field names of PARTY_CLASSIFICTN Landing table/Base Object 
 *
 */
public interface ClassificationAttributes {
	
	public static final String CLASSIFICTN_TYPE = "CLASSIFCTN_TYPE";
	public static final String CLASSIFICTN_VALUE = "CLASSIFCTN_VALUE";
	public static final String START_DATE = "START_DATE";
	public static final String END_DATE = "END_DATE";
	public static final String CLASSIFCTN_METH = "CLASSIFCTN_METH";
	public static final String ROWID_PARTY = "ROWID_PARTY";

}
