package com.mcafee.mdm.constants;

/**
 * The interface contains field names of PARTY Landing table/Base Object 
 *
 */
public interface PartyAttributes {
	
	public static final String ENTITY_TYPE = "ENTITY_TYPE";
	public static final String BO_CLASS_CODE = "BO_CLASS_CODE";
	public static final String PARTY_TYPE = "PARTY_TYPE";
	public static final String PARTY_NAME = "PARTY_NAME";
	public static final String GEO = "GEO";
	public static final String LEGACY_UCN = "LEGACY_UCN";
	public static final String DNB_DBA_NAME = "DNB_DBA_NAME";
	public static final String DNB_SECOND_TRADE_STYLE = "DNB_SECOND_TRADE_STYLE";
	public static final String DNB_REG_NAME = "DNB_REG_NAME";
	public static final String REGION = "REGION";
	public static final String STATUS_CD = "STATUS_CD";
	public static final String VAT_REG_NBR = "VAT_REG_NBR";
	public static final String TAX_JURSDCTN_CD = "TAX_JURSDCTN_CD";
	public static final String SALES_BLOCK_CD = "SALES_BLOCK_CD";
	public static final String UCN = "UCN";
	public static final String COUNTRY_CD = "COUNTRY_CD";
	public static final String ENGLISH_NAME = "ENGLISH_NAME";
	public static final String SIP_POP = "SIP_POP";
	
	/** Modified for US68-Throughput Tracker START */
	public static final String MSG_TRKN_ID = "MSG_TRKN_ID";
	/** Modified for US68-Throughput Tracker END */
	/** changes for Sales Force Integration -Start */
	public static final String PHYSICAL_GEO = "PHYSICAL_GEO";
	public static final String PHYSICAL_REGION = "PHYSICAL_REGION";
	public static final String PROCESS_STATE_IND = "PROCESS_STATE_IND";
	public static final String DRAFT_FLG = "DRAFT_FLAG";
	public static final String MDM_LEGACY_ID = "MDM_LEGACY_ID";
	public static final String DO_NOT_MERGE = "DO_NO_MERGE";
	/** changes for Sales Force Integration -End */
}
