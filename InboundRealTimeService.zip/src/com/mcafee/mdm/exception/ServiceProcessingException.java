package com.mcafee.mdm.exception;

public class ServiceProcessingException extends Exception{
	
	private static final long serialVersionUID = 1L;
	private String message;
	private String rootExceptionMsg;

	public ServiceProcessingException(String msg) {
		super(msg);
		this.message = msg;
	}
	
	public ServiceProcessingException(Exception excp) {
		super(excp);
		this.rootExceptionMsg = excp.getMessage();
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getRootExceptionMsg() {
		return rootExceptionMsg;
	}

	public void setRootExceptionMsg(String originalExceptionMsg) {
		this.rootExceptionMsg = originalExceptionMsg;
	}

}
