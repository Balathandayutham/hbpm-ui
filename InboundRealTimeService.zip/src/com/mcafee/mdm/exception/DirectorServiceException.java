package com.mcafee.mdm.exception;

public class DirectorServiceException extends java.lang.Exception {

	private static final long serialVersionUID = -2613356979569675398L;

	public DirectorServiceException() {
		super();
	}

	public DirectorServiceException(String message, Throwable cause) {
		super(message, cause);
	}

	public DirectorServiceException(String message) {
		super(message);
	}

	public DirectorServiceException(Throwable cause) {
		super(cause);
	}
}
