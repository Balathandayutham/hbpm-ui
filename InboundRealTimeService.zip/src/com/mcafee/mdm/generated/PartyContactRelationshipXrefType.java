
package com.mcafee.mdm.generated;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for PartyContactRelationshipXrefType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="PartyContactRelationshipXrefType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="SRC_SYSTEM" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="SRC_PKEY" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="LAST_UPDATE_DATE" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="UPDATE_BY" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="PARENT_ID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="CHILD_ID" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="HIERARCHY_TYPE" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="REL_TYPE" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PartyContactRelationshipXrefType", propOrder = {
    "srcsystem",
    "srcpkey",
    "lastupdatedate",
    "updateby",
    "parentid",
    "childid",
    "hierarchytype",
    "reltype"
})
public class PartyContactRelationshipXrefType {

    @XmlElement(name = "SRC_SYSTEM", required = true)
    protected String srcsystem;
    @XmlElement(name = "SRC_PKEY", required = true)
    protected String srcpkey;
    @XmlElement(name = "LAST_UPDATE_DATE", required = true)
    protected String lastupdatedate;
    @XmlElement(name = "UPDATE_BY", required = true)
    protected String updateby;
    @XmlElement(name = "PARENT_ID", required = true)
    protected String parentid;
    @XmlElement(name = "CHILD_ID")
    protected List<String> childid;
    @XmlElement(name = "HIERARCHY_TYPE", required = true)
    protected String hierarchytype;
    @XmlElement(name = "REL_TYPE", required = true)
    protected String reltype;

    /**
     * Gets the value of the srcsystem property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSRCSYSTEM() {
        return srcsystem;
    }

    /**
     * Sets the value of the srcsystem property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSRCSYSTEM(String value) {
        this.srcsystem = value;
    }

    /**
     * Gets the value of the srcpkey property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSRCPKEY() {
        return srcpkey;
    }

    /**
     * Sets the value of the srcpkey property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSRCPKEY(String value) {
        this.srcpkey = value;
    }

    /**
     * Gets the value of the lastupdatedate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLASTUPDATEDATE() {
        return lastupdatedate;
    }

    /**
     * Sets the value of the lastupdatedate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLASTUPDATEDATE(String value) {
        this.lastupdatedate = value;
    }

    /**
     * Gets the value of the updateby property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUPDATEBY() {
        return updateby;
    }

    /**
     * Sets the value of the updateby property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUPDATEBY(String value) {
        this.updateby = value;
    }

    /**
     * Gets the value of the parentid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPARENTID() {
        return parentid;
    }

    /**
     * Sets the value of the parentid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPARENTID(String value) {
        this.parentid = value;
    }

    /**
     * Gets the value of the childid property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the childid property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCHILDID().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getCHILDID() {
        if (childid == null) {
            childid = new ArrayList<String>();
        }
        return this.childid;
    }

    /**
     * Gets the value of the hierarchytype property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHIERARCHYTYPE() {
        return hierarchytype;
    }

    /**
     * Sets the value of the hierarchytype property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHIERARCHYTYPE(String value) {
        this.hierarchytype = value;
    }

    /**
     * Gets the value of the reltype property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRELTYPE() {
        return reltype;
    }

    /**
     * Sets the value of the reltype property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRELTYPE(String value) {
        this.reltype = value;
    }

}
