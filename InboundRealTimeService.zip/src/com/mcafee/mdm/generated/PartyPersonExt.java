
package com.mcafee.mdm.generated;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for PartyPersonExt complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="PartyPersonExt">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ROWID_PRSN_EXTN" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="SRC_SYSTEM" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="SRC_SYSTEM_ID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PartyPersonExt", propOrder = {
    "rowidprsnextn",
    "srcsystem",
    "srcsystemid"
})
public class PartyPersonExt {

    @XmlElement(name = "ROWID_PRSN_EXTN", required = true)
    protected String rowidprsnextn;
    @XmlElement(name = "SRC_SYSTEM", required = true)
    protected String srcsystem;
    @XmlElement(name = "SRC_SYSTEM_ID", required = true)
    protected String srcsystemid;

    /**
     * Gets the value of the rowidprsnextn property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getROWIDPRSNEXTN() {
        return rowidprsnextn;
    }

    /**
     * Sets the value of the rowidprsnextn property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setROWIDPRSNEXTN(String value) {
        this.rowidprsnextn = value;
    }

    /**
     * Gets the value of the srcsystem property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSRCSYSTEM() {
        return srcsystem;
    }

    /**
     * Sets the value of the srcsystem property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSRCSYSTEM(String value) {
        this.srcsystem = value;
    }

    /**
     * Gets the value of the srcsystemid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSRCSYSTEMID() {
        return srcsystemid;
    }

    /**
     * Sets the value of the srcsystemid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSRCSYSTEMID(String value) {
        this.srcsystemid = value;
    }

}
