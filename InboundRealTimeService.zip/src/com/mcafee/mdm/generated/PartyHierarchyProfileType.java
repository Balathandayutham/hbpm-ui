
package com.mcafee.mdm.generated;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for PartyHierarchyProfileType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="PartyHierarchyProfileType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="MDMGlobalParentUCN" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="MDMGlobalParentName" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="HierarchyProfile" type="{http://mdm.mcafee.com/searchUpsertDelParty/}HierarchyProfile" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="PartyProfile" type="{http://mdm.mcafee.com/searchUpsertDelParty/}PartyProfileType" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PartyHierarchyProfileType", propOrder = {
    "mdmGlobalParentUCN",
    "mdmGlobalParentName",
    "hierarchyProfile",
    "partyProfile"
})
public class PartyHierarchyProfileType {

    @XmlElement(name = "MDMGlobalParentUCN", required = true)
    protected String mdmGlobalParentUCN;
    @XmlElement(name = "MDMGlobalParentName", required = true)
    protected String mdmGlobalParentName;
    @XmlElement(name = "HierarchyProfile")
    protected List<HierarchyProfile> hierarchyProfile;
    @XmlElement(name = "PartyProfile")
    protected List<PartyProfileType> partyProfile;

    /**
     * Gets the value of the mdmGlobalParentUCN property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMDMGlobalParentUCN() {
        return mdmGlobalParentUCN;
    }

    /**
     * Sets the value of the mdmGlobalParentUCN property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMDMGlobalParentUCN(String value) {
        this.mdmGlobalParentUCN = value;
    }

    /**
     * Gets the value of the mdmGlobalParentName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMDMGlobalParentName() {
        return mdmGlobalParentName;
    }

    /**
     * Sets the value of the mdmGlobalParentName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMDMGlobalParentName(String value) {
        this.mdmGlobalParentName = value;
    }

    /**
     * Gets the value of the hierarchyProfile property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the hierarchyProfile property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getHierarchyProfile().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link HierarchyProfile }
     * 
     * 
     */
    public List<HierarchyProfile> getHierarchyProfile() {
        if (hierarchyProfile == null) {
            hierarchyProfile = new ArrayList<HierarchyProfile>();
        }
        return this.hierarchyProfile;
    }

    /**
     * Gets the value of the partyProfile property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the partyProfile property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPartyProfile().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PartyProfileType }
     * 
     * 
     */
    public List<PartyProfileType> getPartyProfile() {
        if (partyProfile == null) {
            partyProfile = new ArrayList<PartyProfileType>();
        }
        return this.partyProfile;
    }

}
