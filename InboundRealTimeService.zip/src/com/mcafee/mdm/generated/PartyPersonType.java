
package com.mcafee.mdm.generated;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for PartyPersonType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="PartyPersonType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ErrorMsg" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ROWID_OBJECT" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="PREFIX" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="FIRST_NAME" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="MIDDLE_NAME" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="LAST_NAME" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="SUFFIX" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="JOB_TITLE" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="JOB_LEVEL" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="JOB_FUNCTION" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="PREF_LANGUAGE" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="PERSON_STATUS" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="PERSON_TYPE" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="LIST_SOURCE" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="DATA_SOURCE_SYSTEM" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="LATTICE_SCORE" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="REPORTED_COMPANY_NAME" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Sales_Force_ID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="SRC_ACCOUNT_ID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="JOB_ROLE" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="PARTNER_CONTACT_FLG" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="CLEANSE_IND" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PartyPersonType", propOrder = {
    "errorMsg",
    "rowidobject",
    "prefix",
    "firstname",
    "middlename",
    "lastname",
    "suffix",
    "jobtitle",
    "joblevel",
    "jobfunction",
    "preflanguage",
    "personstatus",
    "persontype",
    "listsource",
    "datasourcesystem",
    "latticescore",
    "reportedcompanyname",
    "salesForceID",
    "srcaccountid",
    "jobrole",
    "partnercontactflg",
    "cleanseind"
})
public class PartyPersonType {

    @XmlElement(name = "ErrorMsg", required = true)
    protected String errorMsg;
    @XmlElement(name = "ROWID_OBJECT", required = true)
    protected String rowidobject;
    @XmlElement(name = "PREFIX", required = true)
    protected String prefix;
    @XmlElement(name = "FIRST_NAME", required = true)
    protected String firstname;
    @XmlElement(name = "MIDDLE_NAME", required = true)
    protected String middlename;
    @XmlElement(name = "LAST_NAME", required = true)
    protected String lastname;
    @XmlElement(name = "SUFFIX", required = true)
    protected String suffix;
    @XmlElement(name = "JOB_TITLE", required = true)
    protected String jobtitle;
    @XmlElement(name = "JOB_LEVEL", required = true)
    protected String joblevel;
    @XmlElement(name = "JOB_FUNCTION", required = true)
    protected String jobfunction;
    @XmlElement(name = "PREF_LANGUAGE", required = true)
    protected String preflanguage;
    @XmlElement(name = "PERSON_STATUS", required = true)
    protected String personstatus;
    @XmlElement(name = "PERSON_TYPE", required = true)
    protected String persontype;
    @XmlElement(name = "LIST_SOURCE", required = true)
    protected String listsource;
    @XmlElement(name = "DATA_SOURCE_SYSTEM", required = true)
    protected String datasourcesystem;
    @XmlElement(name = "LATTICE_SCORE", required = true)
    protected String latticescore;
    @XmlElement(name = "REPORTED_COMPANY_NAME", required = true)
    protected String reportedcompanyname;
    @XmlElement(name = "Sales_Force_ID", required = true)
    protected String salesForceID;
    @XmlElement(name = "SRC_ACCOUNT_ID", required = true)
    protected String srcaccountid;
    @XmlElement(name = "JOB_ROLE", required = true)
    protected String jobrole;
    @XmlElement(name = "PARTNER_CONTACT_FLG", required = true)
    protected String partnercontactflg;
    @XmlElement(name = "CLEANSE_IND", required = true)
    protected String cleanseind;

    /**
     * Gets the value of the errorMsg property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getErrorMsg() {
        return errorMsg;
    }

    /**
     * Sets the value of the errorMsg property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setErrorMsg(String value) {
        this.errorMsg = value;
    }

    /**
     * Gets the value of the rowidobject property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getROWIDOBJECT() {
        return rowidobject;
    }

    /**
     * Sets the value of the rowidobject property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setROWIDOBJECT(String value) {
        this.rowidobject = value;
    }

    /**
     * Gets the value of the prefix property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPREFIX() {
        return prefix;
    }

    /**
     * Sets the value of the prefix property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPREFIX(String value) {
        this.prefix = value;
    }

    /**
     * Gets the value of the firstname property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFIRSTNAME() {
        return firstname;
    }

    /**
     * Sets the value of the firstname property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFIRSTNAME(String value) {
        this.firstname = value;
    }

    /**
     * Gets the value of the middlename property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMIDDLENAME() {
        return middlename;
    }

    /**
     * Sets the value of the middlename property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMIDDLENAME(String value) {
        this.middlename = value;
    }

    /**
     * Gets the value of the lastname property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLASTNAME() {
        return lastname;
    }

    /**
     * Sets the value of the lastname property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLASTNAME(String value) {
        this.lastname = value;
    }

    /**
     * Gets the value of the suffix property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSUFFIX() {
        return suffix;
    }

    /**
     * Sets the value of the suffix property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSUFFIX(String value) {
        this.suffix = value;
    }

    /**
     * Gets the value of the jobtitle property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getJOBTITLE() {
        return jobtitle;
    }

    /**
     * Sets the value of the jobtitle property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setJOBTITLE(String value) {
        this.jobtitle = value;
    }

    /**
     * Gets the value of the joblevel property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getJOBLEVEL() {
        return joblevel;
    }

    /**
     * Sets the value of the joblevel property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setJOBLEVEL(String value) {
        this.joblevel = value;
    }

    /**
     * Gets the value of the jobfunction property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getJOBFUNCTION() {
        return jobfunction;
    }

    /**
     * Sets the value of the jobfunction property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setJOBFUNCTION(String value) {
        this.jobfunction = value;
    }

    /**
     * Gets the value of the preflanguage property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPREFLANGUAGE() {
        return preflanguage;
    }

    /**
     * Sets the value of the preflanguage property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPREFLANGUAGE(String value) {
        this.preflanguage = value;
    }

    /**
     * Gets the value of the personstatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPERSONSTATUS() {
        return personstatus;
    }

    /**
     * Sets the value of the personstatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPERSONSTATUS(String value) {
        this.personstatus = value;
    }

    /**
     * Gets the value of the persontype property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPERSONTYPE() {
        return persontype;
    }

    /**
     * Sets the value of the persontype property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPERSONTYPE(String value) {
        this.persontype = value;
    }

    /**
     * Gets the value of the listsource property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLISTSOURCE() {
        return listsource;
    }

    /**
     * Sets the value of the listsource property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLISTSOURCE(String value) {
        this.listsource = value;
    }

    /**
     * Gets the value of the datasourcesystem property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDATASOURCESYSTEM() {
        return datasourcesystem;
    }

    /**
     * Sets the value of the datasourcesystem property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDATASOURCESYSTEM(String value) {
        this.datasourcesystem = value;
    }

    /**
     * Gets the value of the latticescore property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLATTICESCORE() {
        return latticescore;
    }

    /**
     * Sets the value of the latticescore property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLATTICESCORE(String value) {
        this.latticescore = value;
    }

    /**
     * Gets the value of the reportedcompanyname property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getREPORTEDCOMPANYNAME() {
        return reportedcompanyname;
    }

    /**
     * Sets the value of the reportedcompanyname property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setREPORTEDCOMPANYNAME(String value) {
        this.reportedcompanyname = value;
    }

    /**
     * Gets the value of the salesForceID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSalesForceID() {
        return salesForceID;
    }

    /**
     * Sets the value of the salesForceID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSalesForceID(String value) {
        this.salesForceID = value;
    }

    /**
     * Gets the value of the srcaccountid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSRCACCOUNTID() {
        return srcaccountid;
    }

    /**
     * Sets the value of the srcaccountid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSRCACCOUNTID(String value) {
        this.srcaccountid = value;
    }

    /**
     * Gets the value of the jobrole property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getJOBROLE() {
        return jobrole;
    }

    /**
     * Sets the value of the jobrole property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setJOBROLE(String value) {
        this.jobrole = value;
    }

    /**
     * Gets the value of the partnercontactflg property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPARTNERCONTACTFLG() {
        return partnercontactflg;
    }

    /**
     * Sets the value of the partnercontactflg property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPARTNERCONTACTFLG(String value) {
        this.partnercontactflg = value;
    }

    /**
     * Gets the value of the cleanseind property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCLEANSEIND() {
        return cleanseind;
    }

    /**
     * Sets the value of the cleanseind property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCLEANSEIND(String value) {
        this.cleanseind = value;
    }

}
