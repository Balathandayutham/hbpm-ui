
package com.mcafee.mdm.generated;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for PartyContactRelationshipType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="PartyContactRelationshipType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="PARENT_ID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="CHILD_ID" type="{http://mdm.mcafee.com/searchUpsertDelParty/}PartyPersonRelationshipType" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="HIERARCHY_TYPE" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="REL_TYPE" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PartyContactRelationshipType", propOrder = {
    "parentid",
    "childid",
    "hierarchytype",
    "reltype"
})
public class PartyContactRelationshipType {

    @XmlElement(name = "PARENT_ID", required = true)
    protected String parentid;
    @XmlElement(name = "CHILD_ID")
    protected List<PartyPersonRelationshipType> childid;
    @XmlElement(name = "HIERARCHY_TYPE", required = true)
    protected String hierarchytype;
    @XmlElement(name = "REL_TYPE", required = true)
    protected String reltype;

    /**
     * Gets the value of the parentid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPARENTID() {
        return parentid;
    }

    /**
     * Sets the value of the parentid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPARENTID(String value) {
        this.parentid = value;
    }

    /**
     * Gets the value of the childid property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the childid property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCHILDID().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PartyPersonRelationshipType }
     * 
     * 
     */
    public List<PartyPersonRelationshipType> getCHILDID() {
        if (childid == null) {
            childid = new ArrayList<PartyPersonRelationshipType>();
        }
        return this.childid;
    }

    /**
     * Gets the value of the hierarchytype property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHIERARCHYTYPE() {
        return hierarchytype;
    }

    /**
     * Sets the value of the hierarchytype property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHIERARCHYTYPE(String value) {
        this.hierarchytype = value;
    }

    /**
     * Gets the value of the reltype property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRELTYPE() {
        return reltype;
    }

    /**
     * Sets the value of the reltype property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRELTYPE(String value) {
        this.reltype = value;
    }

}
