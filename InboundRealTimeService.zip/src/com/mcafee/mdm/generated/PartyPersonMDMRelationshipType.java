
package com.mcafee.mdm.generated;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for PartyPersonMDMRelationshipType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="PartyPersonMDMRelationshipType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="MDM_UCN" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="PARTY_TYPE" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="XREF" type="{http://mdm.mcafee.com/searchUpsertDelParty/}XREFType" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PartyPersonMDMRelationshipType", propOrder = {
    "id",
    "mdmucn",
    "partytype",
    "xref"
})
public class PartyPersonMDMRelationshipType {

    @XmlElement(name = "ID", required = true)
    protected String id;
    @XmlElement(name = "MDM_UCN", required = true)
    protected String mdmucn;
    @XmlElement(name = "PARTY_TYPE", required = true)
    protected String partytype;
    @XmlElement(name = "XREF")
    protected List<XREFType> xref;

    /**
     * Gets the value of the id property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getID() {
        return id;
    }

    /**
     * Sets the value of the id property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setID(String value) {
        this.id = value;
    }

    /**
     * Gets the value of the mdmucn property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMDMUCN() {
        return mdmucn;
    }

    /**
     * Sets the value of the mdmucn property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMDMUCN(String value) {
        this.mdmucn = value;
    }

    /**
     * Gets the value of the partytype property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPARTYTYPE() {
        return partytype;
    }

    /**
     * Sets the value of the partytype property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPARTYTYPE(String value) {
        this.partytype = value;
    }

    /**
     * Gets the value of the xref property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the xref property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getXREF().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link XREFType }
     * 
     * 
     */
    public List<XREFType> getXREF() {
        if (xref == null) {
            xref = new ArrayList<XREFType>();
        }
        return this.xref;
    }

}
