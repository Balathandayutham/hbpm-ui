
package com.mcafee.mdm.generated;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for PartyPersonExtXrefType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="PartyPersonExtXrefType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="SRC_SYSTEM" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="SRC_PKEY" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="LAST_UPDATE_DATE" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="UPDATE_BY" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ROWID_PRSN_EXTN" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="PREFIX" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="FIRST_NAME" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="MIDDLE_NAME" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="LAST_NAME" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="SUFFIX" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="PERSON_TYPE" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PartyPersonExtXrefType", propOrder = {
    "srcsystem",
    "srcpkey",
    "lastupdatedate",
    "updateby",
    "rowidprsnextn",
    "prefix",
    "firstname",
    "middlename",
    "lastname",
    "suffix",
    "persontype"
})
public class PartyPersonExtXrefType {

    @XmlElement(name = "SRC_SYSTEM", required = true)
    protected String srcsystem;
    @XmlElement(name = "SRC_PKEY", required = true)
    protected String srcpkey;
    @XmlElement(name = "LAST_UPDATE_DATE", required = true)
    protected String lastupdatedate;
    @XmlElement(name = "UPDATE_BY", required = true)
    protected String updateby;
    @XmlElement(name = "ROWID_PRSN_EXTN", required = true)
    protected String rowidprsnextn;
    @XmlElement(name = "PREFIX", required = true)
    protected String prefix;
    @XmlElement(name = "FIRST_NAME", required = true)
    protected String firstname;
    @XmlElement(name = "MIDDLE_NAME", required = true)
    protected String middlename;
    @XmlElement(name = "LAST_NAME", required = true)
    protected String lastname;
    @XmlElement(name = "SUFFIX", required = true)
    protected String suffix;
    @XmlElement(name = "PERSON_TYPE", required = true)
    protected String persontype;

    /**
     * Gets the value of the srcsystem property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSRCSYSTEM() {
        return srcsystem;
    }

    /**
     * Sets the value of the srcsystem property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSRCSYSTEM(String value) {
        this.srcsystem = value;
    }

    /**
     * Gets the value of the srcpkey property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSRCPKEY() {
        return srcpkey;
    }

    /**
     * Sets the value of the srcpkey property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSRCPKEY(String value) {
        this.srcpkey = value;
    }

    /**
     * Gets the value of the lastupdatedate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLASTUPDATEDATE() {
        return lastupdatedate;
    }

    /**
     * Sets the value of the lastupdatedate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLASTUPDATEDATE(String value) {
        this.lastupdatedate = value;
    }

    /**
     * Gets the value of the updateby property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUPDATEBY() {
        return updateby;
    }

    /**
     * Sets the value of the updateby property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUPDATEBY(String value) {
        this.updateby = value;
    }

    /**
     * Gets the value of the rowidprsnextn property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getROWIDPRSNEXTN() {
        return rowidprsnextn;
    }

    /**
     * Sets the value of the rowidprsnextn property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setROWIDPRSNEXTN(String value) {
        this.rowidprsnextn = value;
    }

    /**
     * Gets the value of the prefix property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPREFIX() {
        return prefix;
    }

    /**
     * Sets the value of the prefix property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPREFIX(String value) {
        this.prefix = value;
    }

    /**
     * Gets the value of the firstname property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFIRSTNAME() {
        return firstname;
    }

    /**
     * Sets the value of the firstname property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFIRSTNAME(String value) {
        this.firstname = value;
    }

    /**
     * Gets the value of the middlename property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMIDDLENAME() {
        return middlename;
    }

    /**
     * Sets the value of the middlename property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMIDDLENAME(String value) {
        this.middlename = value;
    }

    /**
     * Gets the value of the lastname property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLASTNAME() {
        return lastname;
    }

    /**
     * Sets the value of the lastname property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLASTNAME(String value) {
        this.lastname = value;
    }

    /**
     * Gets the value of the suffix property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSUFFIX() {
        return suffix;
    }

    /**
     * Sets the value of the suffix property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSUFFIX(String value) {
        this.suffix = value;
    }

    /**
     * Gets the value of the persontype property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPERSONTYPE() {
        return persontype;
    }

    /**
     * Sets the value of the persontype property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPERSONTYPE(String value) {
        this.persontype = value;
    }

}
