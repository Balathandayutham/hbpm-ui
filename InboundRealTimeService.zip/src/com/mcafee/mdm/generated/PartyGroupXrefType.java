
package com.mcafee.mdm.generated;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for PartyGroupXrefType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="PartyGroupXrefType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="SRC_SYSTEM" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="SRC_PKEY" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="LAST_UPDATE_DATE" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="UPDATED_BY" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="PARTY_GROUP_NAME" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ENTITY_TYPE" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ENTITY_TYPE_DESC" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="LEVEL_1" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="GLBL_PAR_NAME" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="GLBL_PAR_NUMBER" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="GLBL_PAR_METHOD" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="GLBL_PAR_NAME_OVRIDE" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="GLBL_PAR_NAME_OVRIDE_METH" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="UCN" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="GLB_EMP_CNT_OVERRIDE" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="GLB_EMP_CNT_OVERIDE_METH" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="G2K_FLG" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="GLB_VERTICAL" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="GLB_VERTICAL_OVERRIDE" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="GLB_VERTICAL_OVERRIDE_METH" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="GLB_SALES_REVNU" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="GLB_SALES_REVNU_OVRID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="GLB_SALES_REVNU_OVRID_METH" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PartyGroupXrefType", propOrder = {
    "srcsystem",
    "srcpkey",
    "lastupdatedate",
    "updatedby",
    "partygroupname",
    "entitytype",
    "entitytypedesc",
    "level1",
    "glblparname",
    "glblparnumber",
    "glblparmethod",
    "glblparnameovride",
    "glblparnameovridemeth",
    "ucn",
    "glbempcntoverride",
    "glbempcntoveridemeth",
    "g2KFLG",
    "glbvertical",
    "glbverticaloverride",
    "glbverticaloverridemeth",
    "glbsalesrevnu",
    "glbsalesrevnuovrid",
    "glbsalesrevnuovridmeth"
})
public class PartyGroupXrefType {

    @XmlElement(name = "SRC_SYSTEM", required = true)
    protected String srcsystem;
    @XmlElement(name = "SRC_PKEY", required = true)
    protected String srcpkey;
    @XmlElement(name = "LAST_UPDATE_DATE", required = true)
    protected String lastupdatedate;
    @XmlElement(name = "UPDATED_BY", required = true)
    protected String updatedby;
    @XmlElement(name = "PARTY_GROUP_NAME", required = true)
    protected String partygroupname;
    @XmlElement(name = "ENTITY_TYPE", required = true)
    protected String entitytype;
    @XmlElement(name = "ENTITY_TYPE_DESC", required = true)
    protected String entitytypedesc;
    @XmlElement(name = "LEVEL_1", required = true)
    protected String level1;
    @XmlElement(name = "GLBL_PAR_NAME", required = true)
    protected String glblparname;
    @XmlElement(name = "GLBL_PAR_NUMBER", required = true)
    protected String glblparnumber;
    @XmlElement(name = "GLBL_PAR_METHOD", required = true)
    protected String glblparmethod;
    @XmlElement(name = "GLBL_PAR_NAME_OVRIDE", required = true)
    protected String glblparnameovride;
    @XmlElement(name = "GLBL_PAR_NAME_OVRIDE_METH", required = true)
    protected String glblparnameovridemeth;
    @XmlElement(name = "UCN", required = true)
    protected String ucn;
    @XmlElement(name = "GLB_EMP_CNT_OVERRIDE", required = true)
    protected String glbempcntoverride;
    @XmlElement(name = "GLB_EMP_CNT_OVERIDE_METH", required = true)
    protected String glbempcntoveridemeth;
    @XmlElement(name = "G2K_FLG", required = true)
    protected String g2KFLG;
    @XmlElement(name = "GLB_VERTICAL", required = true)
    protected String glbvertical;
    @XmlElement(name = "GLB_VERTICAL_OVERRIDE", required = true)
    protected String glbverticaloverride;
    @XmlElement(name = "GLB_VERTICAL_OVERRIDE_METH", required = true)
    protected String glbverticaloverridemeth;
    @XmlElement(name = "GLB_SALES_REVNU", required = true)
    protected String glbsalesrevnu;
    @XmlElement(name = "GLB_SALES_REVNU_OVRID", required = true)
    protected String glbsalesrevnuovrid;
    @XmlElement(name = "GLB_SALES_REVNU_OVRID_METH", required = true)
    protected String glbsalesrevnuovridmeth;

    /**
     * Gets the value of the srcsystem property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSRCSYSTEM() {
        return srcsystem;
    }

    /**
     * Sets the value of the srcsystem property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSRCSYSTEM(String value) {
        this.srcsystem = value;
    }

    /**
     * Gets the value of the srcpkey property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSRCPKEY() {
        return srcpkey;
    }

    /**
     * Sets the value of the srcpkey property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSRCPKEY(String value) {
        this.srcpkey = value;
    }

    /**
     * Gets the value of the lastupdatedate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLASTUPDATEDATE() {
        return lastupdatedate;
    }

    /**
     * Sets the value of the lastupdatedate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLASTUPDATEDATE(String value) {
        this.lastupdatedate = value;
    }

    /**
     * Gets the value of the updatedby property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUPDATEDBY() {
        return updatedby;
    }

    /**
     * Sets the value of the updatedby property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUPDATEDBY(String value) {
        this.updatedby = value;
    }

    /**
     * Gets the value of the partygroupname property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPARTYGROUPNAME() {
        return partygroupname;
    }

    /**
     * Sets the value of the partygroupname property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPARTYGROUPNAME(String value) {
        this.partygroupname = value;
    }

    /**
     * Gets the value of the entitytype property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getENTITYTYPE() {
        return entitytype;
    }

    /**
     * Sets the value of the entitytype property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setENTITYTYPE(String value) {
        this.entitytype = value;
    }

    /**
     * Gets the value of the entitytypedesc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getENTITYTYPEDESC() {
        return entitytypedesc;
    }

    /**
     * Sets the value of the entitytypedesc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setENTITYTYPEDESC(String value) {
        this.entitytypedesc = value;
    }

    /**
     * Gets the value of the level1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLEVEL1() {
        return level1;
    }

    /**
     * Sets the value of the level1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLEVEL1(String value) {
        this.level1 = value;
    }

    /**
     * Gets the value of the glblparname property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGLBLPARNAME() {
        return glblparname;
    }

    /**
     * Sets the value of the glblparname property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGLBLPARNAME(String value) {
        this.glblparname = value;
    }

    /**
     * Gets the value of the glblparnumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGLBLPARNUMBER() {
        return glblparnumber;
    }

    /**
     * Sets the value of the glblparnumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGLBLPARNUMBER(String value) {
        this.glblparnumber = value;
    }

    /**
     * Gets the value of the glblparmethod property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGLBLPARMETHOD() {
        return glblparmethod;
    }

    /**
     * Sets the value of the glblparmethod property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGLBLPARMETHOD(String value) {
        this.glblparmethod = value;
    }

    /**
     * Gets the value of the glblparnameovride property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGLBLPARNAMEOVRIDE() {
        return glblparnameovride;
    }

    /**
     * Sets the value of the glblparnameovride property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGLBLPARNAMEOVRIDE(String value) {
        this.glblparnameovride = value;
    }

    /**
     * Gets the value of the glblparnameovridemeth property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGLBLPARNAMEOVRIDEMETH() {
        return glblparnameovridemeth;
    }

    /**
     * Sets the value of the glblparnameovridemeth property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGLBLPARNAMEOVRIDEMETH(String value) {
        this.glblparnameovridemeth = value;
    }

    /**
     * Gets the value of the ucn property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUCN() {
        return ucn;
    }

    /**
     * Sets the value of the ucn property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUCN(String value) {
        this.ucn = value;
    }

    /**
     * Gets the value of the glbempcntoverride property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGLBEMPCNTOVERRIDE() {
        return glbempcntoverride;
    }

    /**
     * Sets the value of the glbempcntoverride property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGLBEMPCNTOVERRIDE(String value) {
        this.glbempcntoverride = value;
    }

    /**
     * Gets the value of the glbempcntoveridemeth property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGLBEMPCNTOVERIDEMETH() {
        return glbempcntoveridemeth;
    }

    /**
     * Sets the value of the glbempcntoveridemeth property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGLBEMPCNTOVERIDEMETH(String value) {
        this.glbempcntoveridemeth = value;
    }

    /**
     * Gets the value of the g2KFLG property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getG2KFLG() {
        return g2KFLG;
    }

    /**
     * Sets the value of the g2KFLG property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setG2KFLG(String value) {
        this.g2KFLG = value;
    }

    /**
     * Gets the value of the glbvertical property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGLBVERTICAL() {
        return glbvertical;
    }

    /**
     * Sets the value of the glbvertical property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGLBVERTICAL(String value) {
        this.glbvertical = value;
    }

    /**
     * Gets the value of the glbverticaloverride property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGLBVERTICALOVERRIDE() {
        return glbverticaloverride;
    }

    /**
     * Sets the value of the glbverticaloverride property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGLBVERTICALOVERRIDE(String value) {
        this.glbverticaloverride = value;
    }

    /**
     * Gets the value of the glbverticaloverridemeth property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGLBVERTICALOVERRIDEMETH() {
        return glbverticaloverridemeth;
    }

    /**
     * Sets the value of the glbverticaloverridemeth property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGLBVERTICALOVERRIDEMETH(String value) {
        this.glbverticaloverridemeth = value;
    }

    /**
     * Gets the value of the glbsalesrevnu property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGLBSALESREVNU() {
        return glbsalesrevnu;
    }

    /**
     * Sets the value of the glbsalesrevnu property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGLBSALESREVNU(String value) {
        this.glbsalesrevnu = value;
    }

    /**
     * Gets the value of the glbsalesrevnuovrid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGLBSALESREVNUOVRID() {
        return glbsalesrevnuovrid;
    }

    /**
     * Sets the value of the glbsalesrevnuovrid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGLBSALESREVNUOVRID(String value) {
        this.glbsalesrevnuovrid = value;
    }

    /**
     * Gets the value of the glbsalesrevnuovridmeth property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGLBSALESREVNUOVRIDMETH() {
        return glbsalesrevnuovridmeth;
    }

    /**
     * Sets the value of the glbsalesrevnuovridmeth property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGLBSALESREVNUOVRIDMETH(String value) {
        this.glbsalesrevnuovridmeth = value;
    }

}
