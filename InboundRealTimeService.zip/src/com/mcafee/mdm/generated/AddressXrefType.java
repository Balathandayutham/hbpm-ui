
package com.mcafee.mdm.generated;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for AddressXrefType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="AddressXrefType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="SRC_SYSTEM" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="SRC_PKEY" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="LAST_UPDATE_DATE" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="UPDATE_BY" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ROWID_ADDRESS" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ROWID_ADDRESS_XREF" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ADDR_LN1" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ADDR_LN2" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ADDR_LN3" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ADDR_LN4" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="CITY" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="COUNTY" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="DISTRICT" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="STATE_CD" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="POSTAL_CD" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="COUNTRY_CD" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="LANG_CD" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="LONGITUDE" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="LATITUDE" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ADDR_TYPE" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ADDR_STATUS" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ADDR_MKTG_PREF" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ADDRESS_QUALITY_IDENTIFIER" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="PARTNERSHIP_STATUS" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AddressXrefType", propOrder = {
    "srcsystem",
    "srcpkey",
    "lastupdatedate",
    "updateby",
    "rowidaddress",
    "rowidaddressxref",
    "addrln1",
    "addrln2",
    "addrln3",
    "addrln4",
    "city",
    "county",
    "district",
    "statecd",
    "postalcd",
    "countrycd",
    "langcd",
    "longitude",
    "latitude",
    "addrtype",
    "addrstatus",
    "addrmktgpref",
    "addressqualityidentifier",
    "partnershipstatus"
})
public class AddressXrefType {

    @XmlElement(name = "SRC_SYSTEM", required = true)
    protected String srcsystem;
    @XmlElement(name = "SRC_PKEY", required = true)
    protected String srcpkey;
    @XmlElement(name = "LAST_UPDATE_DATE", required = true)
    protected String lastupdatedate;
    @XmlElement(name = "UPDATE_BY", required = true)
    protected String updateby;
    @XmlElement(name = "ROWID_ADDRESS", required = true)
    protected String rowidaddress;
    @XmlElement(name = "ROWID_ADDRESS_XREF", required = true)
    protected String rowidaddressxref;
    @XmlElement(name = "ADDR_LN1", required = true)
    protected String addrln1;
    @XmlElement(name = "ADDR_LN2", required = true)
    protected String addrln2;
    @XmlElement(name = "ADDR_LN3", required = true)
    protected String addrln3;
    @XmlElement(name = "ADDR_LN4", required = true)
    protected String addrln4;
    @XmlElement(name = "CITY", required = true)
    protected String city;
    @XmlElement(name = "COUNTY", required = true)
    protected String county;
    @XmlElement(name = "DISTRICT", required = true)
    protected String district;
    @XmlElement(name = "STATE_CD", required = true)
    protected String statecd;
    @XmlElement(name = "POSTAL_CD", required = true)
    protected String postalcd;
    @XmlElement(name = "COUNTRY_CD", required = true)
    protected String countrycd;
    @XmlElement(name = "LANG_CD", required = true)
    protected String langcd;
    @XmlElement(name = "LONGITUDE", required = true)
    protected String longitude;
    @XmlElement(name = "LATITUDE", required = true)
    protected String latitude;
    @XmlElement(name = "ADDR_TYPE", required = true)
    protected String addrtype;
    @XmlElement(name = "ADDR_STATUS", required = true)
    protected String addrstatus;
    @XmlElement(name = "ADDR_MKTG_PREF", required = true)
    protected String addrmktgpref;
    @XmlElement(name = "ADDRESS_QUALITY_IDENTIFIER", required = true)
    protected String addressqualityidentifier;
    @XmlElement(name = "PARTNERSHIP_STATUS", required = true)
    protected String partnershipstatus;

    /**
     * Gets the value of the srcsystem property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSRCSYSTEM() {
        return srcsystem;
    }

    /**
     * Sets the value of the srcsystem property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSRCSYSTEM(String value) {
        this.srcsystem = value;
    }

    /**
     * Gets the value of the srcpkey property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSRCPKEY() {
        return srcpkey;
    }

    /**
     * Sets the value of the srcpkey property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSRCPKEY(String value) {
        this.srcpkey = value;
    }

    /**
     * Gets the value of the lastupdatedate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLASTUPDATEDATE() {
        return lastupdatedate;
    }

    /**
     * Sets the value of the lastupdatedate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLASTUPDATEDATE(String value) {
        this.lastupdatedate = value;
    }

    /**
     * Gets the value of the updateby property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUPDATEBY() {
        return updateby;
    }

    /**
     * Sets the value of the updateby property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUPDATEBY(String value) {
        this.updateby = value;
    }

    /**
     * Gets the value of the rowidaddress property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getROWIDADDRESS() {
        return rowidaddress;
    }

    /**
     * Sets the value of the rowidaddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setROWIDADDRESS(String value) {
        this.rowidaddress = value;
    }

    /**
     * Gets the value of the rowidaddressxref property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getROWIDADDRESSXREF() {
        return rowidaddressxref;
    }

    /**
     * Sets the value of the rowidaddressxref property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setROWIDADDRESSXREF(String value) {
        this.rowidaddressxref = value;
    }

    /**
     * Gets the value of the addrln1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getADDRLN1() {
        return addrln1;
    }

    /**
     * Sets the value of the addrln1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setADDRLN1(String value) {
        this.addrln1 = value;
    }

    /**
     * Gets the value of the addrln2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getADDRLN2() {
        return addrln2;
    }

    /**
     * Sets the value of the addrln2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setADDRLN2(String value) {
        this.addrln2 = value;
    }

    /**
     * Gets the value of the addrln3 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getADDRLN3() {
        return addrln3;
    }

    /**
     * Sets the value of the addrln3 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setADDRLN3(String value) {
        this.addrln3 = value;
    }

    /**
     * Gets the value of the addrln4 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getADDRLN4() {
        return addrln4;
    }

    /**
     * Sets the value of the addrln4 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setADDRLN4(String value) {
        this.addrln4 = value;
    }

    /**
     * Gets the value of the city property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCITY() {
        return city;
    }

    /**
     * Sets the value of the city property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCITY(String value) {
        this.city = value;
    }

    /**
     * Gets the value of the county property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCOUNTY() {
        return county;
    }

    /**
     * Sets the value of the county property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCOUNTY(String value) {
        this.county = value;
    }

    /**
     * Gets the value of the district property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDISTRICT() {
        return district;
    }

    /**
     * Sets the value of the district property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDISTRICT(String value) {
        this.district = value;
    }

    /**
     * Gets the value of the statecd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSTATECD() {
        return statecd;
    }

    /**
     * Sets the value of the statecd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSTATECD(String value) {
        this.statecd = value;
    }

    /**
     * Gets the value of the postalcd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPOSTALCD() {
        return postalcd;
    }

    /**
     * Sets the value of the postalcd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPOSTALCD(String value) {
        this.postalcd = value;
    }

    /**
     * Gets the value of the countrycd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCOUNTRYCD() {
        return countrycd;
    }

    /**
     * Sets the value of the countrycd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCOUNTRYCD(String value) {
        this.countrycd = value;
    }

    /**
     * Gets the value of the langcd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLANGCD() {
        return langcd;
    }

    /**
     * Sets the value of the langcd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLANGCD(String value) {
        this.langcd = value;
    }

    /**
     * Gets the value of the longitude property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLONGITUDE() {
        return longitude;
    }

    /**
     * Sets the value of the longitude property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLONGITUDE(String value) {
        this.longitude = value;
    }

    /**
     * Gets the value of the latitude property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLATITUDE() {
        return latitude;
    }

    /**
     * Sets the value of the latitude property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLATITUDE(String value) {
        this.latitude = value;
    }

    /**
     * Gets the value of the addrtype property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getADDRTYPE() {
        return addrtype;
    }

    /**
     * Sets the value of the addrtype property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setADDRTYPE(String value) {
        this.addrtype = value;
    }

    /**
     * Gets the value of the addrstatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getADDRSTATUS() {
        return addrstatus;
    }

    /**
     * Sets the value of the addrstatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setADDRSTATUS(String value) {
        this.addrstatus = value;
    }

    /**
     * Gets the value of the addrmktgpref property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getADDRMKTGPREF() {
        return addrmktgpref;
    }

    /**
     * Sets the value of the addrmktgpref property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setADDRMKTGPREF(String value) {
        this.addrmktgpref = value;
    }

    /**
     * Gets the value of the addressqualityidentifier property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getADDRESSQUALITYIDENTIFIER() {
        return addressqualityidentifier;
    }

    /**
     * Sets the value of the addressqualityidentifier property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setADDRESSQUALITYIDENTIFIER(String value) {
        this.addressqualityidentifier = value;
    }

    /**
     * Gets the value of the partnershipstatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPARTNERSHIPSTATUS() {
        return partnershipstatus;
    }

    /**
     * Sets the value of the partnershipstatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPARTNERSHIPSTATUS(String value) {
        this.partnershipstatus = value;
    }

}
