
package com.mcafee.mdm.generated;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Search_Type" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RecordCountThresold" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Match_score_thresold" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ContactSearchCriteria" type="{http://mdm.mcafee.com/searchUpsertDelParty/}ContactSearchCriteriaType"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "searchType",
    "recordCountThresold",
    "matchScoreThresold",
    "contactSearchCriteria"
})
@XmlRootElement(name = "searchContactRequest")
public class SearchContactRequest {

    @XmlElement(name = "Search_Type")
    protected String searchType;
    @XmlElement(name = "RecordCountThresold")
    protected String recordCountThresold;
    @XmlElement(name = "Match_score_thresold")
    protected String matchScoreThresold;
    @XmlElement(name = "ContactSearchCriteria", required = true)
    protected ContactSearchCriteriaType contactSearchCriteria;

    /**
     * Gets the value of the searchType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSearchType() {
        return searchType;
    }

    /**
     * Sets the value of the searchType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSearchType(String value) {
        this.searchType = value;
    }

    /**
     * Gets the value of the recordCountThresold property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRecordCountThresold() {
        return recordCountThresold;
    }

    /**
     * Sets the value of the recordCountThresold property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRecordCountThresold(String value) {
        this.recordCountThresold = value;
    }

    /**
     * Gets the value of the matchScoreThresold property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMatchScoreThresold() {
        return matchScoreThresold;
    }

    /**
     * Sets the value of the matchScoreThresold property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMatchScoreThresold(String value) {
        this.matchScoreThresold = value;
    }

    /**
     * Gets the value of the contactSearchCriteria property.
     * 
     * @return
     *     possible object is
     *     {@link ContactSearchCriteriaType }
     *     
     */
    public ContactSearchCriteriaType getContactSearchCriteria() {
        return contactSearchCriteria;
    }

    /**
     * Sets the value of the contactSearchCriteria property.
     * 
     * @param value
     *     allowed object is
     *     {@link ContactSearchCriteriaType }
     *     
     */
    public void setContactSearchCriteria(ContactSearchCriteriaType value) {
        this.contactSearchCriteria = value;
    }

}
