@javax.xml.bind.annotation.XmlSchema(namespace = "http://mdm.mcafee.com/searchUpsertDelParty/")
package com.mcafee.mdm.generated;
