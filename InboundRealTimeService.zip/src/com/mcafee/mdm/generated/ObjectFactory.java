
package com.mcafee.mdm.generated;

import javax.xml.bind.annotation.XmlRegistry;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.mcafee.mdm.searchupsertdelparty package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {


    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.mcafee.mdm.searchupsertdelparty
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link UpsertPartyRequest }
     * 
     */
    public UpsertPartyRequest createUpsertPartyRequest() {
        return new UpsertPartyRequest();
    }

    /**
     * Create an instance of {@link PartyXrefType }
     * 
     */
    public PartyXrefType createPartyXrefType() {
        return new PartyXrefType();
    }

    /**
     * Create an instance of {@link SearchPartyRequest }
     * 
     */
    public SearchPartyRequest createSearchPartyRequest() {
        return new SearchPartyRequest();
    }

    /**
     * Create an instance of {@link PartySearchCriteriaType }
     * 
     */
    public PartySearchCriteriaType createPartySearchCriteriaType() {
        return new PartySearchCriteriaType();
    }

    /**
     * Create an instance of {@link DeletePartyRequest }
     * 
     */
    public DeletePartyRequest createDeletePartyRequest() {
        return new DeletePartyRequest();
    }

    /**
     * Create an instance of {@link DeleteRecordType }
     * 
     */
    public DeleteRecordType createDeleteRecordType() {
        return new DeleteRecordType();
    }

    /**
     * Create an instance of {@link SearchPartyResponse }
     * 
     */
    public SearchPartyResponse createSearchPartyResponse() {
        return new SearchPartyResponse();
    }

    /**
     * Create an instance of {@link PartyProfileType }
     * 
     */
    public PartyProfileType createPartyProfileType() {
        return new PartyProfileType();
    }

    /**
     * Create an instance of {@link DeletePartyResponse }
     * 
     */
    public DeletePartyResponse createDeletePartyResponse() {
        return new DeletePartyResponse();
    }

    /**
     * Create an instance of {@link UpsertPartyResponse }
     * 
     */
    public UpsertPartyResponse createUpsertPartyResponse() {
        return new UpsertPartyResponse();
    }

    /**
     * Create an instance of {@link PartyUpsertRespType }
     * 
     */
    public PartyUpsertRespType createPartyUpsertRespType() {
        return new PartyUpsertRespType();
    }

    /**
     * Create an instance of {@link PartyPersonXrefType }
     * 
     */
    public PartyPersonXrefType createPartyPersonXrefType() {
        return new PartyPersonXrefType();
    }

    /**
     * Create an instance of {@link PartyPersonExtXrefType }
     * 
     */
    public PartyPersonExtXrefType createPartyPersonExtXrefType() {
        return new PartyPersonExtXrefType();
    }

    /**
     * Create an instance of {@link PartyPersonRelationshipType }
     * 
     */
    public PartyPersonRelationshipType createPartyPersonRelationshipType() {
        return new PartyPersonRelationshipType();
    }

    /**
     * Create an instance of {@link AddressXrefType }
     * 
     */
    public AddressXrefType createAddressXrefType() {
        return new AddressXrefType();
    }

    /**
     * Create an instance of {@link PartyPersonType }
     * 
     */
    public PartyPersonType createPartyPersonType() {
        return new PartyPersonType();
    }

    /**
     * Create an instance of {@link Communication }
     * 
     */
    public Communication createCommunication() {
        return new Communication();
    }

    /**
     * Create an instance of {@link Account }
     * 
     */
    public Account createAccount() {
        return new Account();
    }

    /**
     * Create an instance of {@link CommunicationType }
     * 
     */
    public CommunicationType createCommunicationType() {
        return new CommunicationType();
    }

    /**
     * Create an instance of {@link PartyPersonExt }
     * 
     */
    public PartyPersonExt createPartyPersonExt() {
        return new PartyPersonExt();
    }

    /**
     * Create an instance of {@link PartyPersonExtType }
     * 
     */
    public PartyPersonExtType createPartyPersonExtType() {
        return new PartyPersonExtType();
    }

    /**
     * Create an instance of {@link PartyOrgExtXrefType }
     * 
     */
    public PartyOrgExtXrefType createPartyOrgExtXrefType() {
        return new PartyOrgExtXrefType();
    }

    /**
     * Create an instance of {@link XREFType }
     * 
     */
    public XREFType createXREFType() {
        return new XREFType();
    }

    /**
     * Create an instance of {@link Classification }
     * 
     */
    public Classification createClassification() {
        return new Classification();
    }

    /**
     * Create an instance of {@link CommunicationXrefType }
     * 
     */
    public CommunicationXrefType createCommunicationXrefType() {
        return new CommunicationXrefType();
    }

    /**
     * Create an instance of {@link PartyRelationshipXrefType }
     * 
     */
    public PartyRelationshipXrefType createPartyRelationshipXrefType() {
        return new PartyRelationshipXrefType();
    }

    /**
     * Create an instance of {@link PartyPerson }
     * 
     */
    public PartyPerson createPartyPerson() {
        return new PartyPerson();
    }

    /**
     * Create an instance of {@link PartyAccountRelationshipType }
     * 
     */
    public PartyAccountRelationshipType createPartyAccountRelationshipType() {
        return new PartyAccountRelationshipType();
    }

    /**
     * Create an instance of {@link AccountType }
     * 
     */
    public AccountType createAccountType() {
        return new AccountType();
    }

    /**
     * Create an instance of {@link PartyType }
     * 
     */
    public PartyType createPartyType() {
        return new PartyType();
    }

    

    /**
     * Create an instance of {@link PartyOrgExtType }
     * 
     */
    public PartyOrgExtType createPartyOrgExtType() {
        return new PartyOrgExtType();
    }

    /**
     * Create an instance of {@link PartyContactRelationshipType }
     * 
     */
    public PartyContactRelationshipType createPartyContactRelationshipType() {
        return new PartyContactRelationshipType();
    }

    /**
     * Create an instance of {@link ClassificationXrefType }
     * 
     */
    public ClassificationXrefType createClassificationXrefType() {
        return new ClassificationXrefType();
    }

    /**
     * Create an instance of {@link AccountXrefType }
     * 
     */
    public AccountXrefType createAccountXrefType() {
        return new AccountXrefType();
    }

    /**
     * Create an instance of {@link XREFCopy }
     * 
     */
    public XREFCopy createXREFCopy() {
        return new XREFCopy();
    }

    /**
     * Create an instance of {@link PartyOrgExt }
     * 
     */
    public PartyOrgExt createPartyOrgExt() {
        return new PartyOrgExt();
    }

    /**
     * Create an instance of {@link PartyRelationshipType }
     * 
     */
    public PartyRelationshipType createPartyRelationshipType() {
        return new PartyRelationshipType();
    }

    /**
     * Create an instance of {@link ClassificationType }
     * 
     */
    public ClassificationType createClassificationType() {
        return new ClassificationType();
    }

    /**
     * Create an instance of {@link PartyAccountRelationshipXrefType }
     * 
     */
    public PartyAccountRelationshipXrefType createPartyAccountRelationshipXrefType() {
        return new PartyAccountRelationshipXrefType();
    }

    /**
     * Create an instance of {@link Address }
     * 
     */
    public Address createAddress() {
        return new Address();
    }

    /**
     * Create an instance of {@link AddressType }
     * 
     */
    public AddressType createAddressType() {
        return new AddressType();
    }

    /**
     * Create an instance of {@link PartyContactRelationshipXrefType }
     * 
     */
    public PartyContactRelationshipXrefType createPartyContactRelationshipXrefType() {
        return new PartyContactRelationshipXrefType();
    }

    /**
     * Create an instance of {@link GoldenCopy }
     * 
     */
    public GoldenCopy createGoldenCopy() {
        return new GoldenCopy();
    }

}
