
package com.mcafee.mdm.generated;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for PartyUpsertRespType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="PartyUpsertRespType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ErrorMsg" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ROWID_OBJECT" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="SRC_SYSTEM" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="SRC_SYSTEM_ID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="BO_CLASS_CODE" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="PARTY_TYPE" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="PARTY_NAME" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="GEO" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="REGION" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="STATUS_CD" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="VAT_REG_NBR" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="TAX_JURSDCTN_CD" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="SALES_BLOCK_CD" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="UCN" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="LEGACY_UCN" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ENGLISH_NAME" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="MSG_TRKN_ID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="SRC_UPDT_BY" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="LAST_UPDATE_DATE" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="PHYSICAL_GEO" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="PHYSICAL_REGION" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Account" type="{http://mdm.mcafee.com/searchUpsertDelParty/}Account" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="Address" type="{http://mdm.mcafee.com/searchUpsertDelParty/}Address" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="Communication" type="{http://mdm.mcafee.com/searchUpsertDelParty/}Communication" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="Classification" type="{http://mdm.mcafee.com/searchUpsertDelParty/}Classification" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="PartyOrgExt" type="{http://mdm.mcafee.com/searchUpsertDelParty/}PartyOrgExt" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="PartyPersonExt" type="{http://mdm.mcafee.com/searchUpsertDelParty/}PartyPersonExt" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="PartyPerson" type="{http://mdm.mcafee.com/searchUpsertDelParty/}PartyPerson" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="PartyRel" type="{http://mdm.mcafee.com/searchUpsertDelParty/}PartyRel" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PartyUpsertRespType", propOrder = {
    "errorMsg",
    "rowidobject",
    "srcsystem",
    "srcsystemid",
    "boclasscode",
    "partytype",
    "partyname",
    "geo",
    "region",
    "statuscd",
    "vatregnbr",
    "taxjursdctncd",
    "salesblockcd",
    "ucn",
    "legacyucn",
    "englishname",
    "msgtrknid",
    "srcupdtby",
    "lastupdatedate",
    "physicalgeo",
    "physicalregion",
    "account",
    "address",
    "communication",
    "classification",
    "partyOrgExt",
    "partyPersonExt",
    "partyPerson",
    "partyRel"
})
public class PartyUpsertRespType {

    @XmlElement(name = "ErrorMsg", required = true)
    protected String errorMsg;
    @XmlElement(name = "ROWID_OBJECT", required = true)
    protected String rowidobject;
    @XmlElement(name = "SRC_SYSTEM", required = true)
    protected String srcsystem;
    @XmlElement(name = "SRC_SYSTEM_ID", required = true)
    protected String srcsystemid;
    @XmlElement(name = "BO_CLASS_CODE", required = true)
    protected String boclasscode;
    @XmlElement(name = "PARTY_TYPE", required = true)
    protected String partytype;
    @XmlElement(name = "PARTY_NAME", required = true)
    protected String partyname;
    @XmlElement(name = "GEO", required = true)
    protected String geo;
    @XmlElement(name = "REGION", required = true)
    protected String region;
    @XmlElement(name = "STATUS_CD", required = true)
    protected String statuscd;
    @XmlElement(name = "VAT_REG_NBR", required = true)
    protected String vatregnbr;
    @XmlElement(name = "TAX_JURSDCTN_CD", required = true)
    protected String taxjursdctncd;
    @XmlElement(name = "SALES_BLOCK_CD", required = true)
    protected String salesblockcd;
    @XmlElement(name = "UCN", required = true)
    protected String ucn;
    @XmlElement(name = "LEGACY_UCN", required = true)
    protected String legacyucn;
    @XmlElement(name = "ENGLISH_NAME", required = true)
    protected String englishname;
    @XmlElement(name = "MSG_TRKN_ID", required = true)
    protected String msgtrknid;
    @XmlElement(name = "SRC_UPDT_BY", required = true)
    protected String srcupdtby;
    @XmlElement(name = "LAST_UPDATE_DATE", required = true)
    protected String lastupdatedate;
    @XmlElement(name = "PHYSICAL_GEO", required = true)
    protected String physicalgeo;
    @XmlElement(name = "PHYSICAL_REGION", required = true)
    protected String physicalregion;
    @XmlElement(name = "Account")
    protected List<Account> account;
    @XmlElement(name = "Address")
    protected List<Address> address;
    @XmlElement(name = "Communication")
    protected List<Communication> communication;
    @XmlElement(name = "Classification")
    protected List<Classification> classification;
    @XmlElement(name = "PartyOrgExt")
    protected List<PartyOrgExt> partyOrgExt;
    @XmlElement(name = "PartyPersonExt")
    protected List<PartyPersonExt> partyPersonExt;
    @XmlElement(name = "PartyPerson")
    protected List<PartyPerson> partyPerson;
    @XmlElement(name = "PartyRel")
    protected PartyRel partyRel;

    /**
     * Gets the value of the errorMsg property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getErrorMsg() {
        return errorMsg;
    }

    /**
     * Sets the value of the errorMsg property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setErrorMsg(String value) {
        this.errorMsg = value;
    }

    /**
     * Gets the value of the rowidobject property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getROWIDOBJECT() {
        return rowidobject;
    }

    /**
     * Sets the value of the rowidobject property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setROWIDOBJECT(String value) {
        this.rowidobject = value;
    }

    /**
     * Gets the value of the srcsystem property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSRCSYSTEM() {
        return srcsystem;
    }

    /**
     * Sets the value of the srcsystem property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSRCSYSTEM(String value) {
        this.srcsystem = value;
    }

    /**
     * Gets the value of the srcsystemid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSRCSYSTEMID() {
        return srcsystemid;
    }

    /**
     * Sets the value of the srcsystemid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSRCSYSTEMID(String value) {
        this.srcsystemid = value;
    }

    /**
     * Gets the value of the boclasscode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBOCLASSCODE() {
        return boclasscode;
    }

    /**
     * Sets the value of the boclasscode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBOCLASSCODE(String value) {
        this.boclasscode = value;
    }

    /**
     * Gets the value of the partytype property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPARTYTYPE() {
        return partytype;
    }

    /**
     * Sets the value of the partytype property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPARTYTYPE(String value) {
        this.partytype = value;
    }

    /**
     * Gets the value of the partyname property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPARTYNAME() {
        return partyname;
    }

    /**
     * Sets the value of the partyname property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPARTYNAME(String value) {
        this.partyname = value;
    }

    /**
     * Gets the value of the geo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGEO() {
        return geo;
    }

    /**
     * Sets the value of the geo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGEO(String value) {
        this.geo = value;
    }

    /**
     * Gets the value of the region property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getREGION() {
        return region;
    }

    /**
     * Sets the value of the region property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setREGION(String value) {
        this.region = value;
    }

    /**
     * Gets the value of the statuscd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSTATUSCD() {
        return statuscd;
    }

    /**
     * Sets the value of the statuscd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSTATUSCD(String value) {
        this.statuscd = value;
    }

    /**
     * Gets the value of the vatregnbr property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVATREGNBR() {
        return vatregnbr;
    }

    /**
     * Sets the value of the vatregnbr property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVATREGNBR(String value) {
        this.vatregnbr = value;
    }

    /**
     * Gets the value of the taxjursdctncd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTAXJURSDCTNCD() {
        return taxjursdctncd;
    }

    /**
     * Sets the value of the taxjursdctncd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTAXJURSDCTNCD(String value) {
        this.taxjursdctncd = value;
    }

    /**
     * Gets the value of the salesblockcd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSALESBLOCKCD() {
        return salesblockcd;
    }

    /**
     * Sets the value of the salesblockcd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSALESBLOCKCD(String value) {
        this.salesblockcd = value;
    }

    /**
     * Gets the value of the ucn property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUCN() {
        return ucn;
    }

    /**
     * Sets the value of the ucn property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUCN(String value) {
        this.ucn = value;
    }

    /**
     * Gets the value of the legacyucn property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLEGACYUCN() {
        return legacyucn;
    }

    /**
     * Sets the value of the legacyucn property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLEGACYUCN(String value) {
        this.legacyucn = value;
    }

    /**
     * Gets the value of the englishname property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getENGLISHNAME() {
        return englishname;
    }

    /**
     * Sets the value of the englishname property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setENGLISHNAME(String value) {
        this.englishname = value;
    }

    /**
     * Gets the value of the msgtrknid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMSGTRKNID() {
        return msgtrknid;
    }

    /**
     * Sets the value of the msgtrknid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMSGTRKNID(String value) {
        this.msgtrknid = value;
    }

    /**
     * Gets the value of the srcupdtby property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSRCUPDTBY() {
        return srcupdtby;
    }

    /**
     * Sets the value of the srcupdtby property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSRCUPDTBY(String value) {
        this.srcupdtby = value;
    }

    /**
     * Gets the value of the lastupdatedate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLASTUPDATEDATE() {
        return lastupdatedate;
    }

    /**
     * Sets the value of the lastupdatedate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLASTUPDATEDATE(String value) {
        this.lastupdatedate = value;
    }

    /**
     * Gets the value of the physicalgeo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPHYSICALGEO() {
        return physicalgeo;
    }

    /**
     * Sets the value of the physicalgeo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPHYSICALGEO(String value) {
        this.physicalgeo = value;
    }

    /**
     * Gets the value of the physicalregion property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPHYSICALREGION() {
        return physicalregion;
    }

    /**
     * Sets the value of the physicalregion property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPHYSICALREGION(String value) {
        this.physicalregion = value;
    }

    /**
     * Gets the value of the account property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the account property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAccount().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Account }
     * 
     * 
     */
    public List<Account> getAccount() {
        if (account == null) {
            account = new ArrayList<Account>();
        }
        return this.account;
    }

    /**
     * Gets the value of the address property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the address property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAddress().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Address }
     * 
     * 
     */
    public List<Address> getAddress() {
        if (address == null) {
            address = new ArrayList<Address>();
        }
        return this.address;
    }

    /**
     * Gets the value of the communication property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the communication property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCommunication().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Communication }
     * 
     * 
     */
    public List<Communication> getCommunication() {
        if (communication == null) {
            communication = new ArrayList<Communication>();
        }
        return this.communication;
    }

    /**
     * Gets the value of the classification property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the classification property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getClassification().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Classification }
     * 
     * 
     */
    public List<Classification> getClassification() {
        if (classification == null) {
            classification = new ArrayList<Classification>();
        }
        return this.classification;
    }

    /**
     * Gets the value of the partyOrgExt property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the partyOrgExt property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPartyOrgExt().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PartyOrgExt }
     * 
     * 
     */
    public List<PartyOrgExt> getPartyOrgExt() {
        if (partyOrgExt == null) {
            partyOrgExt = new ArrayList<PartyOrgExt>();
        }
        return this.partyOrgExt;
    }

    /**
     * Gets the value of the partyPersonExt property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the partyPersonExt property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPartyPersonExt().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PartyPersonExt }
     * 
     * 
     */
    public List<PartyPersonExt> getPartyPersonExt() {
        if (partyPersonExt == null) {
            partyPersonExt = new ArrayList<PartyPersonExt>();
        }
        return this.partyPersonExt;
    }

    /**
     * Gets the value of the partyPerson property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the partyPerson property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPartyPerson().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PartyPerson }
     * 
     * 
     */
    public List<PartyPerson> getPartyPerson() {
        if (partyPerson == null) {
            partyPerson = new ArrayList<PartyPerson>();
        }
        return this.partyPerson;
    }

    /**
     * Gets the value of the partyRel property.
     * 
     * @return
     *     possible object is
     *     {@link PartyRel }
     *     
     */
    public PartyRel getPartyRel() {
        return partyRel;
    }

    /**
     * Sets the value of the partyRel property.
     * 
     * @param value
     *     allowed object is
     *     {@link PartyRel }
     *     
     */
    public void setPartyRel(PartyRel value) {
        this.partyRel = value;
    }

}
