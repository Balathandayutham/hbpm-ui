
package com.mcafee.mdm.generated;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ClassificationXrefType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ClassificationXrefType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="SRC_SYSTEM" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="SRC_PKEY" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="LAST_UPDATE_DATE" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="UPDATE_BY" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ROWID_CLASSIFICTN" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="CLASSIFICTN_TYPE" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="CLASSIFICTN_VALUE" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="CLASSIFICTN_METH" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="START_DATE" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="END_DATE" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ClassificationXrefType", propOrder = {
    "srcsystem",
    "srcpkey",
    "lastupdatedate",
    "updateby",
    "rowidclassifictn",
    "classifictntype",
    "classifictnvalue",
    "classifictnmeth",
    "startdate",
    "enddate"
})
public class ClassificationXrefType {

    @XmlElement(name = "SRC_SYSTEM", required = true)
    protected String srcsystem;
    @XmlElement(name = "SRC_PKEY", required = true)
    protected String srcpkey;
    @XmlElement(name = "LAST_UPDATE_DATE", required = true)
    protected String lastupdatedate;
    @XmlElement(name = "UPDATE_BY", required = true)
    protected String updateby;
    @XmlElement(name = "ROWID_CLASSIFICTN", required = true)
    protected String rowidclassifictn;
    @XmlElement(name = "CLASSIFICTN_TYPE", required = true)
    protected String classifictntype;
    @XmlElement(name = "CLASSIFICTN_VALUE", required = true)
    protected String classifictnvalue;
    @XmlElement(name = "CLASSIFICTN_METH", required = true)
    protected String classifictnmeth;
    @XmlElement(name = "START_DATE", required = true)
    protected String startdate;
    @XmlElement(name = "END_DATE", required = true)
    protected String enddate;

    /**
     * Gets the value of the srcsystem property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSRCSYSTEM() {
        return srcsystem;
    }

    /**
     * Sets the value of the srcsystem property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSRCSYSTEM(String value) {
        this.srcsystem = value;
    }

    /**
     * Gets the value of the srcpkey property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSRCPKEY() {
        return srcpkey;
    }

    /**
     * Sets the value of the srcpkey property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSRCPKEY(String value) {
        this.srcpkey = value;
    }

    /**
     * Gets the value of the lastupdatedate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLASTUPDATEDATE() {
        return lastupdatedate;
    }

    /**
     * Sets the value of the lastupdatedate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLASTUPDATEDATE(String value) {
        this.lastupdatedate = value;
    }

    /**
     * Gets the value of the updateby property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUPDATEBY() {
        return updateby;
    }

    /**
     * Sets the value of the updateby property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUPDATEBY(String value) {
        this.updateby = value;
    }

    /**
     * Gets the value of the rowidclassifictn property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getROWIDCLASSIFICTN() {
        return rowidclassifictn;
    }

    /**
     * Sets the value of the rowidclassifictn property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setROWIDCLASSIFICTN(String value) {
        this.rowidclassifictn = value;
    }

    /**
     * Gets the value of the classifictntype property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCLASSIFICTNTYPE() {
        return classifictntype;
    }

    /**
     * Sets the value of the classifictntype property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCLASSIFICTNTYPE(String value) {
        this.classifictntype = value;
    }

    /**
     * Gets the value of the classifictnvalue property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCLASSIFICTNVALUE() {
        return classifictnvalue;
    }

    /**
     * Sets the value of the classifictnvalue property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCLASSIFICTNVALUE(String value) {
        this.classifictnvalue = value;
    }

    /**
     * Gets the value of the classifictnmeth property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCLASSIFICTNMETH() {
        return classifictnmeth;
    }

    /**
     * Sets the value of the classifictnmeth property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCLASSIFICTNMETH(String value) {
        this.classifictnmeth = value;
    }

    /**
     * Gets the value of the startdate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSTARTDATE() {
        return startdate;
    }

    /**
     * Sets the value of the startdate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSTARTDATE(String value) {
        this.startdate = value;
    }

    /**
     * Gets the value of the enddate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getENDDATE() {
        return enddate;
    }

    /**
     * Sets the value of the enddate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setENDDATE(String value) {
        this.enddate = value;
    }

}
