
package com.mcafee.mdm.generated;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for AccountXrefType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="AccountXrefType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="SRC_SYSTEM" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="SRC_PKEY" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="LAST_UPDATE_DATE" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="UPDATE_BY" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ROWID_ACCOUNT" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ACCT_NAME" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ALIAS_NAME" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ACCOUNT_REGION" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ACCOUNT_GEO" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="MARKET" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ACCT_STATUS" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ACCT_TYPE" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="CUST_GROUP" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="PRICE_GROUP" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="COMPANY_CD" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ACCOUNT_VAT_REG_NBR" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="TAX_TYPE" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ACCOUNT_TAX_JURSDCTN_CD" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="BILL_BLOCK_CD" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ORDR_BLOCK_CD" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="DLVRY_BLOCK_CD" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="POST_BLOCK_CD" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="SALE_BLOCK_CD" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="CHANNEL_ID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="PARTNER_TYPE" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="VENDOR_NBR" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="DIRECT_IND" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="NAMED_ACCT_IND" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="NON_VAL_ACCT_IND" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="PARTNER_IND" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="SIEBEL_ROWID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="SAP_CUST_NUMBER" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="MDM_LEGACY_ID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="DATA_SRC_SYSTEM" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="SAP_NAME_1" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="SAP_NAME_2" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="SAP_NAME_3" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="SAP_NAME_4" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Sales_Force_ID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Draft_Account_Flag" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="MDM_ACCOUNT_UCN" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ACCOUNT_NAME" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ACCOUNT_PARTY_TYPE" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ACCOUNT_ADDRESS_1" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ACCOUNT_ADDRESS_2" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ACCOUNT_CITY" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ACCOUNT_STATE" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ACCOUNT_POSTAL_CODE" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ACCOUNT_COUNTRY" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="NAME_QUALITY_IDENTIFIER" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="LOCAL_NAME" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="CURRENCY_CD" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="TAX_ID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="PRICE_BAND_AGGREMENT" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="SITE_DESIGNATION" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="IS_DENIED_FLG" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="CLEANSE_IND" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="RESELL_LEVEL" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="PARTNERSHIP_STATUS" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="TOP_1000_FLG" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="TOP_250_FLG" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AccountXrefType", propOrder = {
    "srcsystem",
    "srcpkey",
    "lastupdatedate",
    "updateby",
    "rowidaccount",
    "acctname",
    "aliasname",
    "accountregion",
    "accountgeo",
    "market",
    "acctstatus",
    "accttype",
    "custgroup",
    "pricegroup",
    "companycd",
    "accountvatregnbr",
    "taxtype",
    "accounttaxjursdctncd",
    "billblockcd",
    "ordrblockcd",
    "dlvryblockcd",
    "postblockcd",
    "saleblockcd",
    "channelid",
    "partnertype",
    "vendornbr",
    "directind",
    "namedacctind",
    "nonvalacctind",
    "partnerind",
    "siebelrowid",
    "sapcustnumber",
    "mdmlegacyid",
    "datasrcsystem",
    "sapname1",
    "sapname2",
    "sapname3",
    "sapname4",
    "salesForceID",
    "draftAccountFlag",
    "mdmaccountucn",
    "accountname",
    "accountpartytype",
    "accountaddress1",
    "accountaddress2",
    "accountcity",
    "accountstate",
    "accountpostalcode",
    "accountcountry",
    "namequalityidentifier",
    "localname",
    "currencycd",
    "taxid",
    "pricebandaggrement",
    "sitedesignation",
    "isdeniedflg",
    "cleanseind",
    "reselllevel",
    "partnershipstatus",
    "top1000FLG",
    "top250FLG"
})
public class AccountXrefType {

    @XmlElement(name = "SRC_SYSTEM", required = true)
    protected String srcsystem;
    @XmlElement(name = "SRC_PKEY", required = true)
    protected String srcpkey;
    @XmlElement(name = "LAST_UPDATE_DATE", required = true)
    protected String lastupdatedate;
    @XmlElement(name = "UPDATE_BY", required = true)
    protected String updateby;
    @XmlElement(name = "ROWID_ACCOUNT", required = true)
    protected String rowidaccount;
    @XmlElement(name = "ACCT_NAME", required = true)
    protected String acctname;
    @XmlElement(name = "ALIAS_NAME", required = true)
    protected String aliasname;
    @XmlElement(name = "ACCOUNT_REGION", required = true)
    protected String accountregion;
    @XmlElement(name = "ACCOUNT_GEO", required = true)
    protected String accountgeo;
    @XmlElement(name = "MARKET", required = true)
    protected String market;
    @XmlElement(name = "ACCT_STATUS", required = true)
    protected String acctstatus;
    @XmlElement(name = "ACCT_TYPE", required = true)
    protected String accttype;
    @XmlElement(name = "CUST_GROUP", required = true)
    protected String custgroup;
    @XmlElement(name = "PRICE_GROUP", required = true)
    protected String pricegroup;
    @XmlElement(name = "COMPANY_CD", required = true)
    protected String companycd;
    @XmlElement(name = "ACCOUNT_VAT_REG_NBR", required = true)
    protected String accountvatregnbr;
    @XmlElement(name = "TAX_TYPE", required = true)
    protected String taxtype;
    @XmlElement(name = "ACCOUNT_TAX_JURSDCTN_CD", required = true)
    protected String accounttaxjursdctncd;
    @XmlElement(name = "BILL_BLOCK_CD", required = true)
    protected String billblockcd;
    @XmlElement(name = "ORDR_BLOCK_CD", required = true)
    protected String ordrblockcd;
    @XmlElement(name = "DLVRY_BLOCK_CD", required = true)
    protected String dlvryblockcd;
    @XmlElement(name = "POST_BLOCK_CD", required = true)
    protected String postblockcd;
    @XmlElement(name = "SALE_BLOCK_CD", required = true)
    protected String saleblockcd;
    @XmlElement(name = "CHANNEL_ID", required = true)
    protected String channelid;
    @XmlElement(name = "PARTNER_TYPE", required = true)
    protected String partnertype;
    @XmlElement(name = "VENDOR_NBR", required = true)
    protected String vendornbr;
    @XmlElement(name = "DIRECT_IND", required = true)
    protected String directind;
    @XmlElement(name = "NAMED_ACCT_IND", required = true)
    protected String namedacctind;
    @XmlElement(name = "NON_VAL_ACCT_IND", required = true)
    protected String nonvalacctind;
    @XmlElement(name = "PARTNER_IND", required = true)
    protected String partnerind;
    @XmlElement(name = "SIEBEL_ROWID", required = true)
    protected String siebelrowid;
    @XmlElement(name = "SAP_CUST_NUMBER", required = true)
    protected String sapcustnumber;
    @XmlElement(name = "MDM_LEGACY_ID", required = true)
    protected String mdmlegacyid;
    @XmlElement(name = "DATA_SRC_SYSTEM", required = true)
    protected String datasrcsystem;
    @XmlElement(name = "SAP_NAME_1", required = true)
    protected String sapname1;
    @XmlElement(name = "SAP_NAME_2", required = true)
    protected String sapname2;
    @XmlElement(name = "SAP_NAME_3", required = true)
    protected String sapname3;
    @XmlElement(name = "SAP_NAME_4", required = true)
    protected String sapname4;
    @XmlElement(name = "Sales_Force_ID", required = true, defaultValue = "")
    protected String salesForceID;
    @XmlElement(name = "Draft_Account_Flag", required = true, defaultValue = "")
    protected String draftAccountFlag;
    @XmlElement(name = "MDM_ACCOUNT_UCN", required = true)
    protected String mdmaccountucn;
    @XmlElement(name = "ACCOUNT_NAME", required = true)
    protected String accountname;
    @XmlElement(name = "ACCOUNT_PARTY_TYPE", required = true)
    protected String accountpartytype;
    @XmlElement(name = "ACCOUNT_ADDRESS_1", required = true)
    protected String accountaddress1;
    @XmlElement(name = "ACCOUNT_ADDRESS_2", required = true)
    protected String accountaddress2;
    @XmlElement(name = "ACCOUNT_CITY", required = true)
    protected String accountcity;
    @XmlElement(name = "ACCOUNT_STATE", required = true)
    protected String accountstate;
    @XmlElement(name = "ACCOUNT_POSTAL_CODE", required = true)
    protected String accountpostalcode;
    @XmlElement(name = "ACCOUNT_COUNTRY", required = true)
    protected String accountcountry;
    @XmlElement(name = "NAME_QUALITY_IDENTIFIER", required = true)
    protected String namequalityidentifier;
    @XmlElement(name = "LOCAL_NAME", required = true)
    protected String localname;
    @XmlElement(name = "CURRENCY_CD", required = true)
    protected String currencycd;
    @XmlElement(name = "TAX_ID", required = true)
    protected String taxid;
    @XmlElement(name = "PRICE_BAND_AGGREMENT", required = true)
    protected String pricebandaggrement;
    @XmlElement(name = "SITE_DESIGNATION", required = true)
    protected String sitedesignation;
    @XmlElement(name = "IS_DENIED_FLG", required = true)
    protected String isdeniedflg;
    @XmlElement(name = "CLEANSE_IND", required = true)
    protected String cleanseind;
    @XmlElement(name = "RESELL_LEVEL", required = true)
    protected String reselllevel;
    @XmlElement(name = "PARTNERSHIP_STATUS", required = true)
    protected String partnershipstatus;
    @XmlElement(name = "TOP_1000_FLG", required = true)
    protected String top1000FLG;
    @XmlElement(name = "TOP_250_FLG", required = true)
    protected String top250FLG;

    /**
     * Gets the value of the srcsystem property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSRCSYSTEM() {
        return srcsystem;
    }

    /**
     * Sets the value of the srcsystem property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSRCSYSTEM(String value) {
        this.srcsystem = value;
    }

    /**
     * Gets the value of the srcpkey property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSRCPKEY() {
        return srcpkey;
    }

    /**
     * Sets the value of the srcpkey property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSRCPKEY(String value) {
        this.srcpkey = value;
    }

    /**
     * Gets the value of the lastupdatedate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLASTUPDATEDATE() {
        return lastupdatedate;
    }

    /**
     * Sets the value of the lastupdatedate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLASTUPDATEDATE(String value) {
        this.lastupdatedate = value;
    }

    /**
     * Gets the value of the updateby property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUPDATEBY() {
        return updateby;
    }

    /**
     * Sets the value of the updateby property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUPDATEBY(String value) {
        this.updateby = value;
    }

    /**
     * Gets the value of the rowidaccount property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getROWIDACCOUNT() {
        return rowidaccount;
    }

    /**
     * Sets the value of the rowidaccount property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setROWIDACCOUNT(String value) {
        this.rowidaccount = value;
    }

    /**
     * Gets the value of the acctname property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getACCTNAME() {
        return acctname;
    }

    /**
     * Sets the value of the acctname property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setACCTNAME(String value) {
        this.acctname = value;
    }

    /**
     * Gets the value of the aliasname property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getALIASNAME() {
        return aliasname;
    }

    /**
     * Sets the value of the aliasname property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setALIASNAME(String value) {
        this.aliasname = value;
    }

    /**
     * Gets the value of the accountregion property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getACCOUNTREGION() {
        return accountregion;
    }

    /**
     * Sets the value of the accountregion property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setACCOUNTREGION(String value) {
        this.accountregion = value;
    }

    /**
     * Gets the value of the accountgeo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getACCOUNTGEO() {
        return accountgeo;
    }

    /**
     * Sets the value of the accountgeo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setACCOUNTGEO(String value) {
        this.accountgeo = value;
    }

    /**
     * Gets the value of the market property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMARKET() {
        return market;
    }

    /**
     * Sets the value of the market property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMARKET(String value) {
        this.market = value;
    }

    /**
     * Gets the value of the acctstatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getACCTSTATUS() {
        return acctstatus;
    }

    /**
     * Sets the value of the acctstatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setACCTSTATUS(String value) {
        this.acctstatus = value;
    }

    /**
     * Gets the value of the accttype property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getACCTTYPE() {
        return accttype;
    }

    /**
     * Sets the value of the accttype property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setACCTTYPE(String value) {
        this.accttype = value;
    }

    /**
     * Gets the value of the custgroup property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCUSTGROUP() {
        return custgroup;
    }

    /**
     * Sets the value of the custgroup property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCUSTGROUP(String value) {
        this.custgroup = value;
    }

    /**
     * Gets the value of the pricegroup property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPRICEGROUP() {
        return pricegroup;
    }

    /**
     * Sets the value of the pricegroup property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPRICEGROUP(String value) {
        this.pricegroup = value;
    }

    /**
     * Gets the value of the companycd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCOMPANYCD() {
        return companycd;
    }

    /**
     * Sets the value of the companycd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCOMPANYCD(String value) {
        this.companycd = value;
    }

    /**
     * Gets the value of the accountvatregnbr property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getACCOUNTVATREGNBR() {
        return accountvatregnbr;
    }

    /**
     * Sets the value of the accountvatregnbr property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setACCOUNTVATREGNBR(String value) {
        this.accountvatregnbr = value;
    }

    /**
     * Gets the value of the taxtype property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTAXTYPE() {
        return taxtype;
    }

    /**
     * Sets the value of the taxtype property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTAXTYPE(String value) {
        this.taxtype = value;
    }

    /**
     * Gets the value of the accounttaxjursdctncd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getACCOUNTTAXJURSDCTNCD() {
        return accounttaxjursdctncd;
    }

    /**
     * Sets the value of the accounttaxjursdctncd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setACCOUNTTAXJURSDCTNCD(String value) {
        this.accounttaxjursdctncd = value;
    }

    /**
     * Gets the value of the billblockcd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBILLBLOCKCD() {
        return billblockcd;
    }

    /**
     * Sets the value of the billblockcd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBILLBLOCKCD(String value) {
        this.billblockcd = value;
    }

    /**
     * Gets the value of the ordrblockcd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getORDRBLOCKCD() {
        return ordrblockcd;
    }

    /**
     * Sets the value of the ordrblockcd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setORDRBLOCKCD(String value) {
        this.ordrblockcd = value;
    }

    /**
     * Gets the value of the dlvryblockcd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDLVRYBLOCKCD() {
        return dlvryblockcd;
    }

    /**
     * Sets the value of the dlvryblockcd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDLVRYBLOCKCD(String value) {
        this.dlvryblockcd = value;
    }

    /**
     * Gets the value of the postblockcd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPOSTBLOCKCD() {
        return postblockcd;
    }

    /**
     * Sets the value of the postblockcd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPOSTBLOCKCD(String value) {
        this.postblockcd = value;
    }

    /**
     * Gets the value of the saleblockcd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSALEBLOCKCD() {
        return saleblockcd;
    }

    /**
     * Sets the value of the saleblockcd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSALEBLOCKCD(String value) {
        this.saleblockcd = value;
    }

    /**
     * Gets the value of the channelid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCHANNELID() {
        return channelid;
    }

    /**
     * Sets the value of the channelid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCHANNELID(String value) {
        this.channelid = value;
    }

    /**
     * Gets the value of the partnertype property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPARTNERTYPE() {
        return partnertype;
    }

    /**
     * Sets the value of the partnertype property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPARTNERTYPE(String value) {
        this.partnertype = value;
    }

    /**
     * Gets the value of the vendornbr property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVENDORNBR() {
        return vendornbr;
    }

    /**
     * Sets the value of the vendornbr property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVENDORNBR(String value) {
        this.vendornbr = value;
    }

    /**
     * Gets the value of the directind property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDIRECTIND() {
        return directind;
    }

    /**
     * Sets the value of the directind property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDIRECTIND(String value) {
        this.directind = value;
    }

    /**
     * Gets the value of the namedacctind property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNAMEDACCTIND() {
        return namedacctind;
    }

    /**
     * Sets the value of the namedacctind property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNAMEDACCTIND(String value) {
        this.namedacctind = value;
    }

    /**
     * Gets the value of the nonvalacctind property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNONVALACCTIND() {
        return nonvalacctind;
    }

    /**
     * Sets the value of the nonvalacctind property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNONVALACCTIND(String value) {
        this.nonvalacctind = value;
    }

    /**
     * Gets the value of the partnerind property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPARTNERIND() {
        return partnerind;
    }

    /**
     * Sets the value of the partnerind property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPARTNERIND(String value) {
        this.partnerind = value;
    }

    /**
     * Gets the value of the siebelrowid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSIEBELROWID() {
        return siebelrowid;
    }

    /**
     * Sets the value of the siebelrowid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSIEBELROWID(String value) {
        this.siebelrowid = value;
    }

    /**
     * Gets the value of the sapcustnumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSAPCUSTNUMBER() {
        return sapcustnumber;
    }

    /**
     * Sets the value of the sapcustnumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSAPCUSTNUMBER(String value) {
        this.sapcustnumber = value;
    }

    /**
     * Gets the value of the mdmlegacyid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMDMLEGACYID() {
        return mdmlegacyid;
    }

    /**
     * Sets the value of the mdmlegacyid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMDMLEGACYID(String value) {
        this.mdmlegacyid = value;
    }

    /**
     * Gets the value of the datasrcsystem property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDATASRCSYSTEM() {
        return datasrcsystem;
    }

    /**
     * Sets the value of the datasrcsystem property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDATASRCSYSTEM(String value) {
        this.datasrcsystem = value;
    }

    /**
     * Gets the value of the sapname1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSAPNAME1() {
        return sapname1;
    }

    /**
     * Sets the value of the sapname1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSAPNAME1(String value) {
        this.sapname1 = value;
    }

    /**
     * Gets the value of the sapname2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSAPNAME2() {
        return sapname2;
    }

    /**
     * Sets the value of the sapname2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSAPNAME2(String value) {
        this.sapname2 = value;
    }

    /**
     * Gets the value of the sapname3 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSAPNAME3() {
        return sapname3;
    }

    /**
     * Sets the value of the sapname3 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSAPNAME3(String value) {
        this.sapname3 = value;
    }

    /**
     * Gets the value of the sapname4 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSAPNAME4() {
        return sapname4;
    }

    /**
     * Sets the value of the sapname4 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSAPNAME4(String value) {
        this.sapname4 = value;
    }

    /**
     * Gets the value of the salesForceID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSalesForceID() {
        return salesForceID;
    }

    /**
     * Sets the value of the salesForceID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSalesForceID(String value) {
        this.salesForceID = value;
    }

    /**
     * Gets the value of the draftAccountFlag property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDraftAccountFlag() {
        return draftAccountFlag;
    }

    /**
     * Sets the value of the draftAccountFlag property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDraftAccountFlag(String value) {
        this.draftAccountFlag = value;
    }

    /**
     * Gets the value of the mdmaccountucn property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMDMACCOUNTUCN() {
        return mdmaccountucn;
    }

    /**
     * Sets the value of the mdmaccountucn property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMDMACCOUNTUCN(String value) {
        this.mdmaccountucn = value;
    }

    /**
     * Gets the value of the accountname property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getACCOUNTNAME() {
        return accountname;
    }

    /**
     * Sets the value of the accountname property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setACCOUNTNAME(String value) {
        this.accountname = value;
    }

    /**
     * Gets the value of the accountpartytype property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getACCOUNTPARTYTYPE() {
        return accountpartytype;
    }

    /**
     * Sets the value of the accountpartytype property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setACCOUNTPARTYTYPE(String value) {
        this.accountpartytype = value;
    }

    /**
     * Gets the value of the accountaddress1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getACCOUNTADDRESS1() {
        return accountaddress1;
    }

    /**
     * Sets the value of the accountaddress1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setACCOUNTADDRESS1(String value) {
        this.accountaddress1 = value;
    }

    /**
     * Gets the value of the accountaddress2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getACCOUNTADDRESS2() {
        return accountaddress2;
    }

    /**
     * Sets the value of the accountaddress2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setACCOUNTADDRESS2(String value) {
        this.accountaddress2 = value;
    }

    /**
     * Gets the value of the accountcity property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getACCOUNTCITY() {
        return accountcity;
    }

    /**
     * Sets the value of the accountcity property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setACCOUNTCITY(String value) {
        this.accountcity = value;
    }

    /**
     * Gets the value of the accountstate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getACCOUNTSTATE() {
        return accountstate;
    }

    /**
     * Sets the value of the accountstate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setACCOUNTSTATE(String value) {
        this.accountstate = value;
    }

    /**
     * Gets the value of the accountpostalcode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getACCOUNTPOSTALCODE() {
        return accountpostalcode;
    }

    /**
     * Sets the value of the accountpostalcode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setACCOUNTPOSTALCODE(String value) {
        this.accountpostalcode = value;
    }

    /**
     * Gets the value of the accountcountry property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getACCOUNTCOUNTRY() {
        return accountcountry;
    }

    /**
     * Sets the value of the accountcountry property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setACCOUNTCOUNTRY(String value) {
        this.accountcountry = value;
    }

    /**
     * Gets the value of the namequalityidentifier property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNAMEQUALITYIDENTIFIER() {
        return namequalityidentifier;
    }

    /**
     * Sets the value of the namequalityidentifier property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNAMEQUALITYIDENTIFIER(String value) {
        this.namequalityidentifier = value;
    }

    /**
     * Gets the value of the localname property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLOCALNAME() {
        return localname;
    }

    /**
     * Sets the value of the localname property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLOCALNAME(String value) {
        this.localname = value;
    }

    /**
     * Gets the value of the currencycd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCURRENCYCD() {
        return currencycd;
    }

    /**
     * Sets the value of the currencycd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCURRENCYCD(String value) {
        this.currencycd = value;
    }

    /**
     * Gets the value of the taxid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTAXID() {
        return taxid;
    }

    /**
     * Sets the value of the taxid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTAXID(String value) {
        this.taxid = value;
    }

    /**
     * Gets the value of the pricebandaggrement property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPRICEBANDAGGREMENT() {
        return pricebandaggrement;
    }

    /**
     * Sets the value of the pricebandaggrement property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPRICEBANDAGGREMENT(String value) {
        this.pricebandaggrement = value;
    }

    /**
     * Gets the value of the sitedesignation property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSITEDESIGNATION() {
        return sitedesignation;
    }

    /**
     * Sets the value of the sitedesignation property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSITEDESIGNATION(String value) {
        this.sitedesignation = value;
    }

    /**
     * Gets the value of the isdeniedflg property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getISDENIEDFLG() {
        return isdeniedflg;
    }

    /**
     * Sets the value of the isdeniedflg property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setISDENIEDFLG(String value) {
        this.isdeniedflg = value;
    }

    /**
     * Gets the value of the cleanseind property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCLEANSEIND() {
        return cleanseind;
    }

    /**
     * Sets the value of the cleanseind property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCLEANSEIND(String value) {
        this.cleanseind = value;
    }

    /**
     * Gets the value of the reselllevel property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRESELLLEVEL() {
        return reselllevel;
    }

    /**
     * Sets the value of the reselllevel property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRESELLLEVEL(String value) {
        this.reselllevel = value;
    }

    /**
     * Gets the value of the partnershipstatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPARTNERSHIPSTATUS() {
        return partnershipstatus;
    }

    /**
     * Sets the value of the partnershipstatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPARTNERSHIPSTATUS(String value) {
        this.partnershipstatus = value;
    }

    /**
     * Gets the value of the top1000FLG property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTOP1000FLG() {
        return top1000FLG;
    }

    /**
     * Sets the value of the top1000FLG property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTOP1000FLG(String value) {
        this.top1000FLG = value;
    }

    /**
     * Gets the value of the top250FLG property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTOP250FLG() {
        return top250FLG;
    }

    /**
     * Sets the value of the top250FLG property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTOP250FLG(String value) {
        this.top250FLG = value;
    }

}
