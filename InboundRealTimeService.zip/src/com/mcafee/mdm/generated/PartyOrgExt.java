
package com.mcafee.mdm.generated;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for PartyOrgExt complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="PartyOrgExt">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ROWID_ORG_EXTN" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="SRC_SYSTEM" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="SRC_SYSTEM_ID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ORG_DUNS_NBR" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="TRADE_NAME" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="TRADE_NAME_2" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="SITE_EMPL_CNT" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="GLBL_EMPL_CNT" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="VERTICAL" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="REVENUE" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="LINE_OF_BUS" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="PRIM_SIC" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="SEC_SIC" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="SALES_VOLUME" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="SALES_AMOUNT" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="CURRENCY_CD" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="OUT_OF_BUS_IND" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="GLBL_ULT_IND" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="FORTUNE_INFO" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="HIERARCHY_LEVEL" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ORG_HQ_PARENT_DUNS" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ORG_DOM_ULT_DUNS" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ORG_GLB_ULT_DUNS" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="MFE_GLBL_PARENT_NM" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="MFE_PARENT_NM" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="MFE_WW_PARENT_NM" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="MFE_SUBSDRY_PARENT_NM" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="MFE_PRTNR_PARENT_ORG" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="MFE_GLBL_PARENT_UCN" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="MFE_GLOBAL_PAR_NM_OVRIDE" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="SALES_REVNU_OVRID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="MFE_EMP_CNT_OVERIDE" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="SIC_CD_OVRIDE" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="MFE_WW_PARENT_PRTN_NM" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="MFE_SUBSDRY_PARENT_PRTN_NM" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="SIC_CD_OVRIDE_DESC" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="MFE_SUBS_PARENT_UCN" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="MFE_SUBS_PARENT_NM_OVRIDE" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="SUBSIDIARY_IND" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="CUSTOM_PARENT_UCN" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="CUSTOM_PARENT_NAME" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="MFE_COUNTRY_ULT_UCN" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="COUNTRY_ULT_IND" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="MFE_NEXT_LVL_SUBS_PAR_UCN" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="MFE_NEXT_LVL_SUBS_PAR_NM" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="GLB_FLG" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="CUST_FLG" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="PARTNER_FLG" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ACTIVE_TXN_FLG" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="PARENT_FLG" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="GLB_EMP_CNT_OVERRIDE" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="TXN_5_YR_FLG" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="TXN_7_YR_FLG" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="MFE_TXN_5_YR_FLG" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="MFE_TXN_7_YR_FLG" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="G2K_FLG" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="MDM_PARENT_UCN" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="CUSTOMER_PARENT_FLAG" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="GLB_SALES_REVNU_OVRID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="PTR_PARENT_UCN" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="PTR_PARENT_NM" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="PTR_GLBL_PARENT_UCN" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PartyOrgExt", propOrder = {
    "rowidorgextn",
    "srcsystem",
    "srcsystemid",
    "orgdunsnbr",
    "tradename",
    "tradename2",
    "siteemplcnt",
    "glblemplcnt",
    "vertical",
    "revenue",
    "lineofbus",
    "primsic",
    "secsic",
    "salesvolume",
    "salesamount",
    "currencycd",
    "outofbusind",
    "glblultind",
    "fortuneinfo",
    "hierarchylevel",
    "orghqparentduns",
    "orgdomultduns",
    "orgglbultduns",
    "mfeglblparentnm",
    "mfeparentnm",
    "mfewwparentnm",
    "mfesubsdryparentnm",
    "mfeprtnrparentorg",
    "mfeglblparentucn",
    "mfeglobalparnmovride",
    "salesrevnuovrid",
    "mfeempcntoveride",
    "siccdovride",
    "mfewwparentprtnnm",
    "mfesubsdryparentprtnnm",
    "siccdovridedesc",
    "mfesubsparentucn",
    "mfesubsparentnmovride",
    "subsidiaryind",
    "customparentucn",
    "customparentname",
    "mfecountryultucn",
    "countryultind",
    "mfenextlvlsubsparucn",
    "mfenextlvlsubsparnm",
    "glbflg",
    "custflg",
    "partnerflg",
    "activetxnflg",
    "parentflg",
    "glbempcntoverride",
    "txn5YRFLG",
    "txn7YRFLG",
    "mfetxn5YRFLG",
    "mfetxn7YRFLG",
    "g2KFLG",
    "mdmparentucn",
    "customerparentflag",
    "glbsalesrevnuovrid",
    "ptrparentucn",
    "ptrparentnm",
    "ptrglblparentucn"
})
public class PartyOrgExt {

    @XmlElement(name = "ROWID_ORG_EXTN", required = true)
    protected String rowidorgextn;
    @XmlElement(name = "SRC_SYSTEM", required = true)
    protected String srcsystem;
    @XmlElement(name = "SRC_SYSTEM_ID", required = true)
    protected String srcsystemid;
    @XmlElement(name = "ORG_DUNS_NBR", required = true)
    protected String orgdunsnbr;
    @XmlElement(name = "TRADE_NAME", required = true)
    protected String tradename;
    @XmlElement(name = "TRADE_NAME_2", required = true)
    protected String tradename2;
    @XmlElement(name = "SITE_EMPL_CNT", required = true)
    protected String siteemplcnt;
    @XmlElement(name = "GLBL_EMPL_CNT", required = true)
    protected String glblemplcnt;
    @XmlElement(name = "VERTICAL", required = true)
    protected String vertical;
    @XmlElement(name = "REVENUE", required = true)
    protected String revenue;
    @XmlElement(name = "LINE_OF_BUS", required = true)
    protected String lineofbus;
    @XmlElement(name = "PRIM_SIC", required = true)
    protected String primsic;
    @XmlElement(name = "SEC_SIC", required = true)
    protected String secsic;
    @XmlElement(name = "SALES_VOLUME", required = true)
    protected String salesvolume;
    @XmlElement(name = "SALES_AMOUNT", required = true)
    protected String salesamount;
    @XmlElement(name = "CURRENCY_CD", required = true)
    protected String currencycd;
    @XmlElement(name = "OUT_OF_BUS_IND", required = true)
    protected String outofbusind;
    @XmlElement(name = "GLBL_ULT_IND", required = true)
    protected String glblultind;
    @XmlElement(name = "FORTUNE_INFO", required = true)
    protected String fortuneinfo;
    @XmlElement(name = "HIERARCHY_LEVEL", required = true)
    protected String hierarchylevel;
    @XmlElement(name = "ORG_HQ_PARENT_DUNS", required = true)
    protected String orghqparentduns;
    @XmlElement(name = "ORG_DOM_ULT_DUNS", required = true)
    protected String orgdomultduns;
    @XmlElement(name = "ORG_GLB_ULT_DUNS", required = true)
    protected String orgglbultduns;
    @XmlElement(name = "MFE_GLBL_PARENT_NM", required = true)
    protected String mfeglblparentnm;
    @XmlElement(name = "MFE_PARENT_NM", required = true)
    protected String mfeparentnm;
    @XmlElement(name = "MFE_WW_PARENT_NM", required = true)
    protected String mfewwparentnm;
    @XmlElement(name = "MFE_SUBSDRY_PARENT_NM", required = true)
    protected String mfesubsdryparentnm;
    @XmlElement(name = "MFE_PRTNR_PARENT_ORG", required = true)
    protected String mfeprtnrparentorg;
    @XmlElement(name = "MFE_GLBL_PARENT_UCN", required = true)
    protected String mfeglblparentucn;
    @XmlElement(name = "MFE_GLOBAL_PAR_NM_OVRIDE", required = true)
    protected String mfeglobalparnmovride;
    @XmlElement(name = "SALES_REVNU_OVRID", required = true)
    protected String salesrevnuovrid;
    @XmlElement(name = "MFE_EMP_CNT_OVERIDE", required = true)
    protected String mfeempcntoveride;
    @XmlElement(name = "SIC_CD_OVRIDE", required = true)
    protected String siccdovride;
    @XmlElement(name = "MFE_WW_PARENT_PRTN_NM", required = true)
    protected String mfewwparentprtnnm;
    @XmlElement(name = "MFE_SUBSDRY_PARENT_PRTN_NM", required = true)
    protected String mfesubsdryparentprtnnm;
    @XmlElement(name = "SIC_CD_OVRIDE_DESC", required = true)
    protected String siccdovridedesc;
    @XmlElement(name = "MFE_SUBS_PARENT_UCN", required = true)
    protected String mfesubsparentucn;
    @XmlElement(name = "MFE_SUBS_PARENT_NM_OVRIDE", required = true)
    protected String mfesubsparentnmovride;
    @XmlElement(name = "SUBSIDIARY_IND", required = true)
    protected String subsidiaryind;
    @XmlElement(name = "CUSTOM_PARENT_UCN", required = true)
    protected String customparentucn;
    @XmlElement(name = "CUSTOM_PARENT_NAME", required = true)
    protected String customparentname;
    @XmlElement(name = "MFE_COUNTRY_ULT_UCN", required = true)
    protected String mfecountryultucn;
    @XmlElement(name = "COUNTRY_ULT_IND", required = true)
    protected String countryultind;
    @XmlElement(name = "MFE_NEXT_LVL_SUBS_PAR_UCN", required = true)
    protected String mfenextlvlsubsparucn;
    @XmlElement(name = "MFE_NEXT_LVL_SUBS_PAR_NM", required = true)
    protected String mfenextlvlsubsparnm;
    @XmlElement(name = "GLB_FLG", required = true)
    protected String glbflg;
    @XmlElement(name = "CUST_FLG", required = true)
    protected String custflg;
    @XmlElement(name = "PARTNER_FLG", required = true)
    protected String partnerflg;
    @XmlElement(name = "ACTIVE_TXN_FLG", required = true)
    protected String activetxnflg;
    @XmlElement(name = "PARENT_FLG", required = true)
    protected String parentflg;
    @XmlElement(name = "GLB_EMP_CNT_OVERRIDE", required = true)
    protected String glbempcntoverride;
    @XmlElement(name = "TXN_5_YR_FLG", required = true)
    protected String txn5YRFLG;
    @XmlElement(name = "TXN_7_YR_FLG", required = true)
    protected String txn7YRFLG;
    @XmlElement(name = "MFE_TXN_5_YR_FLG", required = true)
    protected String mfetxn5YRFLG;
    @XmlElement(name = "MFE_TXN_7_YR_FLG", required = true)
    protected String mfetxn7YRFLG;
    @XmlElement(name = "G2K_FLG", required = true)
    protected String g2KFLG;
    @XmlElement(name = "MDM_PARENT_UCN", required = true)
    protected String mdmparentucn;
    @XmlElement(name = "CUSTOMER_PARENT_FLAG", required = true)
    protected String customerparentflag;
    @XmlElement(name = "GLB_SALES_REVNU_OVRID", required = true)
    protected String glbsalesrevnuovrid;
    @XmlElement(name = "PTR_PARENT_UCN", required = true)
    protected String ptrparentucn;
    @XmlElement(name = "PTR_PARENT_NM", required = true)
    protected String ptrparentnm;
    @XmlElement(name = "PTR_GLBL_PARENT_UCN", required = true)
    protected String ptrglblparentucn;

    /**
     * Gets the value of the rowidorgextn property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getROWIDORGEXTN() {
        return rowidorgextn;
    }

    /**
     * Sets the value of the rowidorgextn property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setROWIDORGEXTN(String value) {
        this.rowidorgextn = value;
    }

    /**
     * Gets the value of the srcsystem property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSRCSYSTEM() {
        return srcsystem;
    }

    /**
     * Sets the value of the srcsystem property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSRCSYSTEM(String value) {
        this.srcsystem = value;
    }

    /**
     * Gets the value of the srcsystemid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSRCSYSTEMID() {
        return srcsystemid;
    }

    /**
     * Sets the value of the srcsystemid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSRCSYSTEMID(String value) {
        this.srcsystemid = value;
    }

    /**
     * Gets the value of the orgdunsnbr property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getORGDUNSNBR() {
        return orgdunsnbr;
    }

    /**
     * Sets the value of the orgdunsnbr property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setORGDUNSNBR(String value) {
        this.orgdunsnbr = value;
    }

    /**
     * Gets the value of the tradename property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTRADENAME() {
        return tradename;
    }

    /**
     * Sets the value of the tradename property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTRADENAME(String value) {
        this.tradename = value;
    }

    /**
     * Gets the value of the tradename2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTRADENAME2() {
        return tradename2;
    }

    /**
     * Sets the value of the tradename2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTRADENAME2(String value) {
        this.tradename2 = value;
    }

    /**
     * Gets the value of the siteemplcnt property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSITEEMPLCNT() {
        return siteemplcnt;
    }

    /**
     * Sets the value of the siteemplcnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSITEEMPLCNT(String value) {
        this.siteemplcnt = value;
    }

    /**
     * Gets the value of the glblemplcnt property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGLBLEMPLCNT() {
        return glblemplcnt;
    }

    /**
     * Sets the value of the glblemplcnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGLBLEMPLCNT(String value) {
        this.glblemplcnt = value;
    }

    /**
     * Gets the value of the vertical property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVERTICAL() {
        return vertical;
    }

    /**
     * Sets the value of the vertical property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVERTICAL(String value) {
        this.vertical = value;
    }

    /**
     * Gets the value of the revenue property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getREVENUE() {
        return revenue;
    }

    /**
     * Sets the value of the revenue property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setREVENUE(String value) {
        this.revenue = value;
    }

    /**
     * Gets the value of the lineofbus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLINEOFBUS() {
        return lineofbus;
    }

    /**
     * Sets the value of the lineofbus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLINEOFBUS(String value) {
        this.lineofbus = value;
    }

    /**
     * Gets the value of the primsic property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPRIMSIC() {
        return primsic;
    }

    /**
     * Sets the value of the primsic property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPRIMSIC(String value) {
        this.primsic = value;
    }

    /**
     * Gets the value of the secsic property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSECSIC() {
        return secsic;
    }

    /**
     * Sets the value of the secsic property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSECSIC(String value) {
        this.secsic = value;
    }

    /**
     * Gets the value of the salesvolume property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSALESVOLUME() {
        return salesvolume;
    }

    /**
     * Sets the value of the salesvolume property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSALESVOLUME(String value) {
        this.salesvolume = value;
    }

    /**
     * Gets the value of the salesamount property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSALESAMOUNT() {
        return salesamount;
    }

    /**
     * Sets the value of the salesamount property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSALESAMOUNT(String value) {
        this.salesamount = value;
    }

    /**
     * Gets the value of the currencycd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCURRENCYCD() {
        return currencycd;
    }

    /**
     * Sets the value of the currencycd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCURRENCYCD(String value) {
        this.currencycd = value;
    }

    /**
     * Gets the value of the outofbusind property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOUTOFBUSIND() {
        return outofbusind;
    }

    /**
     * Sets the value of the outofbusind property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOUTOFBUSIND(String value) {
        this.outofbusind = value;
    }

    /**
     * Gets the value of the glblultind property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGLBLULTIND() {
        return glblultind;
    }

    /**
     * Sets the value of the glblultind property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGLBLULTIND(String value) {
        this.glblultind = value;
    }

    /**
     * Gets the value of the fortuneinfo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFORTUNEINFO() {
        return fortuneinfo;
    }

    /**
     * Sets the value of the fortuneinfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFORTUNEINFO(String value) {
        this.fortuneinfo = value;
    }

    /**
     * Gets the value of the hierarchylevel property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHIERARCHYLEVEL() {
        return hierarchylevel;
    }

    /**
     * Sets the value of the hierarchylevel property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHIERARCHYLEVEL(String value) {
        this.hierarchylevel = value;
    }

    /**
     * Gets the value of the orghqparentduns property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getORGHQPARENTDUNS() {
        return orghqparentduns;
    }

    /**
     * Sets the value of the orghqparentduns property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setORGHQPARENTDUNS(String value) {
        this.orghqparentduns = value;
    }

    /**
     * Gets the value of the orgdomultduns property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getORGDOMULTDUNS() {
        return orgdomultduns;
    }

    /**
     * Sets the value of the orgdomultduns property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setORGDOMULTDUNS(String value) {
        this.orgdomultduns = value;
    }

    /**
     * Gets the value of the orgglbultduns property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getORGGLBULTDUNS() {
        return orgglbultduns;
    }

    /**
     * Sets the value of the orgglbultduns property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setORGGLBULTDUNS(String value) {
        this.orgglbultduns = value;
    }

    /**
     * Gets the value of the mfeglblparentnm property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMFEGLBLPARENTNM() {
        return mfeglblparentnm;
    }

    /**
     * Sets the value of the mfeglblparentnm property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMFEGLBLPARENTNM(String value) {
        this.mfeglblparentnm = value;
    }

    /**
     * Gets the value of the mfeparentnm property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMFEPARENTNM() {
        return mfeparentnm;
    }

    /**
     * Sets the value of the mfeparentnm property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMFEPARENTNM(String value) {
        this.mfeparentnm = value;
    }

    /**
     * Gets the value of the mfewwparentnm property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMFEWWPARENTNM() {
        return mfewwparentnm;
    }

    /**
     * Sets the value of the mfewwparentnm property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMFEWWPARENTNM(String value) {
        this.mfewwparentnm = value;
    }

    /**
     * Gets the value of the mfesubsdryparentnm property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMFESUBSDRYPARENTNM() {
        return mfesubsdryparentnm;
    }

    /**
     * Sets the value of the mfesubsdryparentnm property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMFESUBSDRYPARENTNM(String value) {
        this.mfesubsdryparentnm = value;
    }

    /**
     * Gets the value of the mfeprtnrparentorg property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMFEPRTNRPARENTORG() {
        return mfeprtnrparentorg;
    }

    /**
     * Sets the value of the mfeprtnrparentorg property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMFEPRTNRPARENTORG(String value) {
        this.mfeprtnrparentorg = value;
    }

    /**
     * Gets the value of the mfeglblparentucn property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMFEGLBLPARENTUCN() {
        return mfeglblparentucn;
    }

    /**
     * Sets the value of the mfeglblparentucn property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMFEGLBLPARENTUCN(String value) {
        this.mfeglblparentucn = value;
    }

    /**
     * Gets the value of the mfeglobalparnmovride property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMFEGLOBALPARNMOVRIDE() {
        return mfeglobalparnmovride;
    }

    /**
     * Sets the value of the mfeglobalparnmovride property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMFEGLOBALPARNMOVRIDE(String value) {
        this.mfeglobalparnmovride = value;
    }

    /**
     * Gets the value of the salesrevnuovrid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSALESREVNUOVRID() {
        return salesrevnuovrid;
    }

    /**
     * Sets the value of the salesrevnuovrid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSALESREVNUOVRID(String value) {
        this.salesrevnuovrid = value;
    }

    /**
     * Gets the value of the mfeempcntoveride property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMFEEMPCNTOVERIDE() {
        return mfeempcntoveride;
    }

    /**
     * Sets the value of the mfeempcntoveride property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMFEEMPCNTOVERIDE(String value) {
        this.mfeempcntoveride = value;
    }

    /**
     * Gets the value of the siccdovride property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSICCDOVRIDE() {
        return siccdovride;
    }

    /**
     * Sets the value of the siccdovride property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSICCDOVRIDE(String value) {
        this.siccdovride = value;
    }

    /**
     * Gets the value of the mfewwparentprtnnm property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMFEWWPARENTPRTNNM() {
        return mfewwparentprtnnm;
    }

    /**
     * Sets the value of the mfewwparentprtnnm property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMFEWWPARENTPRTNNM(String value) {
        this.mfewwparentprtnnm = value;
    }

    /**
     * Gets the value of the mfesubsdryparentprtnnm property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMFESUBSDRYPARENTPRTNNM() {
        return mfesubsdryparentprtnnm;
    }

    /**
     * Sets the value of the mfesubsdryparentprtnnm property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMFESUBSDRYPARENTPRTNNM(String value) {
        this.mfesubsdryparentprtnnm = value;
    }

    /**
     * Gets the value of the siccdovridedesc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSICCDOVRIDEDESC() {
        return siccdovridedesc;
    }

    /**
     * Sets the value of the siccdovridedesc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSICCDOVRIDEDESC(String value) {
        this.siccdovridedesc = value;
    }

    /**
     * Gets the value of the mfesubsparentucn property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMFESUBSPARENTUCN() {
        return mfesubsparentucn;
    }

    /**
     * Sets the value of the mfesubsparentucn property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMFESUBSPARENTUCN(String value) {
        this.mfesubsparentucn = value;
    }

    /**
     * Gets the value of the mfesubsparentnmovride property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMFESUBSPARENTNMOVRIDE() {
        return mfesubsparentnmovride;
    }

    /**
     * Sets the value of the mfesubsparentnmovride property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMFESUBSPARENTNMOVRIDE(String value) {
        this.mfesubsparentnmovride = value;
    }

    /**
     * Gets the value of the subsidiaryind property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSUBSIDIARYIND() {
        return subsidiaryind;
    }

    /**
     * Sets the value of the subsidiaryind property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSUBSIDIARYIND(String value) {
        this.subsidiaryind = value;
    }

    /**
     * Gets the value of the customparentucn property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCUSTOMPARENTUCN() {
        return customparentucn;
    }

    /**
     * Sets the value of the customparentucn property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCUSTOMPARENTUCN(String value) {
        this.customparentucn = value;
    }

    /**
     * Gets the value of the customparentname property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCUSTOMPARENTNAME() {
        return customparentname;
    }

    /**
     * Sets the value of the customparentname property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCUSTOMPARENTNAME(String value) {
        this.customparentname = value;
    }

    /**
     * Gets the value of the mfecountryultucn property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMFECOUNTRYULTUCN() {
        return mfecountryultucn;
    }

    /**
     * Sets the value of the mfecountryultucn property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMFECOUNTRYULTUCN(String value) {
        this.mfecountryultucn = value;
    }

    /**
     * Gets the value of the countryultind property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCOUNTRYULTIND() {
        return countryultind;
    }

    /**
     * Sets the value of the countryultind property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCOUNTRYULTIND(String value) {
        this.countryultind = value;
    }

    /**
     * Gets the value of the mfenextlvlsubsparucn property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMFENEXTLVLSUBSPARUCN() {
        return mfenextlvlsubsparucn;
    }

    /**
     * Sets the value of the mfenextlvlsubsparucn property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMFENEXTLVLSUBSPARUCN(String value) {
        this.mfenextlvlsubsparucn = value;
    }

    /**
     * Gets the value of the mfenextlvlsubsparnm property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMFENEXTLVLSUBSPARNM() {
        return mfenextlvlsubsparnm;
    }

    /**
     * Sets the value of the mfenextlvlsubsparnm property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMFENEXTLVLSUBSPARNM(String value) {
        this.mfenextlvlsubsparnm = value;
    }

    /**
     * Gets the value of the glbflg property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGLBFLG() {
        return glbflg;
    }

    /**
     * Sets the value of the glbflg property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGLBFLG(String value) {
        this.glbflg = value;
    }

    /**
     * Gets the value of the custflg property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCUSTFLG() {
        return custflg;
    }

    /**
     * Sets the value of the custflg property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCUSTFLG(String value) {
        this.custflg = value;
    }

    /**
     * Gets the value of the partnerflg property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPARTNERFLG() {
        return partnerflg;
    }

    /**
     * Sets the value of the partnerflg property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPARTNERFLG(String value) {
        this.partnerflg = value;
    }

    /**
     * Gets the value of the activetxnflg property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getACTIVETXNFLG() {
        return activetxnflg;
    }

    /**
     * Sets the value of the activetxnflg property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setACTIVETXNFLG(String value) {
        this.activetxnflg = value;
    }

    /**
     * Gets the value of the parentflg property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPARENTFLG() {
        return parentflg;
    }

    /**
     * Sets the value of the parentflg property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPARENTFLG(String value) {
        this.parentflg = value;
    }

    /**
     * Gets the value of the glbempcntoverride property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGLBEMPCNTOVERRIDE() {
        return glbempcntoverride;
    }

    /**
     * Sets the value of the glbempcntoverride property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGLBEMPCNTOVERRIDE(String value) {
        this.glbempcntoverride = value;
    }

    /**
     * Gets the value of the txn5YRFLG property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTXN5YRFLG() {
        return txn5YRFLG;
    }

    /**
     * Sets the value of the txn5YRFLG property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTXN5YRFLG(String value) {
        this.txn5YRFLG = value;
    }

    /**
     * Gets the value of the txn7YRFLG property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTXN7YRFLG() {
        return txn7YRFLG;
    }

    /**
     * Sets the value of the txn7YRFLG property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTXN7YRFLG(String value) {
        this.txn7YRFLG = value;
    }

    /**
     * Gets the value of the mfetxn5YRFLG property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMFETXN5YRFLG() {
        return mfetxn5YRFLG;
    }

    /**
     * Sets the value of the mfetxn5YRFLG property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMFETXN5YRFLG(String value) {
        this.mfetxn5YRFLG = value;
    }

    /**
     * Gets the value of the mfetxn7YRFLG property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMFETXN7YRFLG() {
        return mfetxn7YRFLG;
    }

    /**
     * Sets the value of the mfetxn7YRFLG property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMFETXN7YRFLG(String value) {
        this.mfetxn7YRFLG = value;
    }

    /**
     * Gets the value of the g2KFLG property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getG2KFLG() {
        return g2KFLG;
    }

    /**
     * Sets the value of the g2KFLG property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setG2KFLG(String value) {
        this.g2KFLG = value;
    }

    /**
     * Gets the value of the mdmparentucn property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMDMPARENTUCN() {
        return mdmparentucn;
    }

    /**
     * Sets the value of the mdmparentucn property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMDMPARENTUCN(String value) {
        this.mdmparentucn = value;
    }

    /**
     * Gets the value of the customerparentflag property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCUSTOMERPARENTFLAG() {
        return customerparentflag;
    }

    /**
     * Sets the value of the customerparentflag property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCUSTOMERPARENTFLAG(String value) {
        this.customerparentflag = value;
    }

    /**
     * Gets the value of the glbsalesrevnuovrid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGLBSALESREVNUOVRID() {
        return glbsalesrevnuovrid;
    }

    /**
     * Sets the value of the glbsalesrevnuovrid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGLBSALESREVNUOVRID(String value) {
        this.glbsalesrevnuovrid = value;
    }

    /**
     * Gets the value of the ptrparentucn property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPTRPARENTUCN() {
        return ptrparentucn;
    }

    /**
     * Sets the value of the ptrparentucn property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPTRPARENTUCN(String value) {
        this.ptrparentucn = value;
    }

    /**
     * Gets the value of the ptrparentnm property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPTRPARENTNM() {
        return ptrparentnm;
    }

    /**
     * Sets the value of the ptrparentnm property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPTRPARENTNM(String value) {
        this.ptrparentnm = value;
    }

    /**
     * Gets the value of the ptrglblparentucn property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPTRGLBLPARENTUCN() {
        return ptrglblparentucn;
    }

    /**
     * Sets the value of the ptrglblparentucn property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPTRGLBLPARENTUCN(String value) {
        this.ptrglblparentucn = value;
    }

}
