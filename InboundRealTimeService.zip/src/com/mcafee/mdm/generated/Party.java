
package com.mcafee.mdm.generated;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Party complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Party">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ROWID_OBJECT" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="UCN" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="PARTY_NAME" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="MDM_PARENT_UCN" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="GEO" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="REGION" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="COUNTRY_NAME" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="HISTORICAL_UCNs" type="{http://mdm.mcafee.com/searchUpsertDelParty/}HistoricalUCNs"/>
 *         &lt;element name="REQUEST_NODE" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Party", propOrder = {
    "rowidobject",
    "ucn",
    "partyname",
    "mdmparentucn",
    "geo",
    "region",
    "countryname",
    "historicalucNs",
    "requestnode"
})
public class Party {

    @XmlElement(name = "ROWID_OBJECT", required = true)
    protected String rowidobject;
    @XmlElement(name = "UCN", required = true)
    protected String ucn;
    @XmlElement(name = "PARTY_NAME", required = true)
    protected String partyname;
    @XmlElement(name = "MDM_PARENT_UCN", required = true)
    protected String mdmparentucn;
    @XmlElement(name = "GEO", required = true)
    protected String geo;
    @XmlElement(name = "REGION", required = true)
    protected String region;
    @XmlElement(name = "COUNTRY_NAME", required = true)
    protected String countryname;
    @XmlElement(name = "HISTORICAL_UCNs", required = true)
    protected HistoricalUCNs historicalucNs;
    @XmlElement(name = "REQUEST_NODE", required = true)
    protected String requestnode;

    /**
     * Gets the value of the rowidobject property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getROWIDOBJECT() {
        return rowidobject;
    }

    /**
     * Sets the value of the rowidobject property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setROWIDOBJECT(String value) {
        this.rowidobject = value;
    }

    /**
     * Gets the value of the ucn property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUCN() {
        return ucn;
    }

    /**
     * Sets the value of the ucn property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUCN(String value) {
        this.ucn = value;
    }

    /**
     * Gets the value of the partyname property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPARTYNAME() {
        return partyname;
    }

    /**
     * Sets the value of the partyname property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPARTYNAME(String value) {
        this.partyname = value;
    }

    /**
     * Gets the value of the mdmparentucn property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMDMPARENTUCN() {
        return mdmparentucn;
    }

    /**
     * Sets the value of the mdmparentucn property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMDMPARENTUCN(String value) {
        this.mdmparentucn = value;
    }

    /**
     * Gets the value of the geo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGEO() {
        return geo;
    }

    /**
     * Sets the value of the geo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGEO(String value) {
        this.geo = value;
    }

    /**
     * Gets the value of the region property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getREGION() {
        return region;
    }

    /**
     * Sets the value of the region property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setREGION(String value) {
        this.region = value;
    }

    /**
     * Gets the value of the countryname property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCOUNTRYNAME() {
        return countryname;
    }

    /**
     * Sets the value of the countryname property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCOUNTRYNAME(String value) {
        this.countryname = value;
    }

    /**
     * Gets the value of the historicalucNs property.
     * 
     * @return
     *     possible object is
     *     {@link HistoricalUCNs }
     *     
     */
    public HistoricalUCNs getHISTORICALUCNs() {
        return historicalucNs;
    }

    /**
     * Sets the value of the historicalucNs property.
     * 
     * @param value
     *     allowed object is
     *     {@link HistoricalUCNs }
     *     
     */
    public void setHISTORICALUCNs(HistoricalUCNs value) {
        this.historicalucNs = value;
    }

    /**
     * Gets the value of the requestnode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getREQUESTNODE() {
        return requestnode;
    }

    /**
     * Sets the value of the requestnode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setREQUESTNODE(String value) {
        this.requestnode = value;
    }

}
