
package com.mcafee.mdm.generated;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for XREFCopy complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="XREFCopy">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="PartyXref" type="{http://mdm.mcafee.com/searchUpsertDelParty/}PartyXrefType" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "XREFCopy", propOrder = {
    "partyXref"
})
public class XREFCopy {

    @XmlElement(name = "PartyXref")
    protected List<PartyXrefType> partyXref;

    /**
     * Gets the value of the partyXref property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the partyXref property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPartyXref().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PartyXrefType }
     * 
     * 
     */
    public List<PartyXrefType> getPartyXref() {
        if (partyXref == null) {
            partyXref = new ArrayList<PartyXrefType>();
        }
        return this.partyXref;
    }

}
