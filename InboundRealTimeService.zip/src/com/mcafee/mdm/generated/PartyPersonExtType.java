
package com.mcafee.mdm.generated;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for PartyPersonExtType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="PartyPersonExtType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ROWID_PRSN_EXTN" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="PREFIX" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="FIRST_NAME" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="MIDDLE_NAME" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="LAST_NAME" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="SUFFIX" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="PERSON_TYPE" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PartyPersonExtType", propOrder = {
    "rowidprsnextn",
    "prefix",
    "firstname",
    "middlename",
    "lastname",
    "suffix",
    "persontype"
})
public class PartyPersonExtType {

    @XmlElement(name = "ROWID_PRSN_EXTN", required = true)
    protected String rowidprsnextn;
    @XmlElement(name = "PREFIX", required = true)
    protected String prefix;
    @XmlElement(name = "FIRST_NAME", required = true)
    protected String firstname;
    @XmlElement(name = "MIDDLE_NAME", required = true)
    protected String middlename;
    @XmlElement(name = "LAST_NAME", required = true)
    protected String lastname;
    @XmlElement(name = "SUFFIX", required = true)
    protected String suffix;
    @XmlElement(name = "PERSON_TYPE", required = true)
    protected String persontype;

    /**
     * Gets the value of the rowidprsnextn property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getROWIDPRSNEXTN() {
        return rowidprsnextn;
    }

    /**
     * Sets the value of the rowidprsnextn property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setROWIDPRSNEXTN(String value) {
        this.rowidprsnextn = value;
    }

    /**
     * Gets the value of the prefix property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPREFIX() {
        return prefix;
    }

    /**
     * Sets the value of the prefix property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPREFIX(String value) {
        this.prefix = value;
    }

    /**
     * Gets the value of the firstname property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFIRSTNAME() {
        return firstname;
    }

    /**
     * Sets the value of the firstname property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFIRSTNAME(String value) {
        this.firstname = value;
    }

    /**
     * Gets the value of the middlename property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMIDDLENAME() {
        return middlename;
    }

    /**
     * Sets the value of the middlename property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMIDDLENAME(String value) {
        this.middlename = value;
    }

    /**
     * Gets the value of the lastname property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLASTNAME() {
        return lastname;
    }

    /**
     * Sets the value of the lastname property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLASTNAME(String value) {
        this.lastname = value;
    }

    /**
     * Gets the value of the suffix property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSUFFIX() {
        return suffix;
    }

    /**
     * Sets the value of the suffix property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSUFFIX(String value) {
        this.suffix = value;
    }

    /**
     * Gets the value of the persontype property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPERSONTYPE() {
        return persontype;
    }

    /**
     * Sets the value of the persontype property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPERSONTYPE(String value) {
        this.persontype = value;
    }

}
