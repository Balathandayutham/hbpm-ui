
package com.mcafee.mdm.generated;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for GenericUpsertResponse complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="GenericUpsertResponse">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="SRC_PKEY" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ROWID_OBJECT" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Status" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="WarningMsg" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ErrorMsg" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "GenericUpsertResponse", propOrder = {
    "srcpkey",
    "rowidobject",
    "status",
    "warningMsg",
    "errorMsg"
})
public class GenericUpsertResponse {

    @XmlElement(name = "SRC_PKEY", required = true)
    protected String srcpkey;
    @XmlElement(name = "ROWID_OBJECT", required = true)
    protected String rowidobject;
    @XmlElement(name = "Status", required = true)
    protected String status;
    @XmlElement(name = "WarningMsg", required = true)
    protected String warningMsg;
    @XmlElement(name = "ErrorMsg", required = true)
    protected String errorMsg;

    /**
     * Gets the value of the srcpkey property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSRCPKEY() {
        return srcpkey;
    }

    /**
     * Sets the value of the srcpkey property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSRCPKEY(String value) {
        this.srcpkey = value;
    }

    /**
     * Gets the value of the rowidobject property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getROWIDOBJECT() {
        return rowidobject;
    }

    /**
     * Sets the value of the rowidobject property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setROWIDOBJECT(String value) {
        this.rowidobject = value;
    }

    /**
     * Gets the value of the status property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStatus() {
        return status;
    }

    /**
     * Sets the value of the status property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStatus(String value) {
        this.status = value;
    }

    /**
     * Gets the value of the warningMsg property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWarningMsg() {
        return warningMsg;
    }

    /**
     * Sets the value of the warningMsg property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWarningMsg(String value) {
        this.warningMsg = value;
    }

    /**
     * Gets the value of the errorMsg property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getErrorMsg() {
        return errorMsg;
    }

    /**
     * Sets the value of the errorMsg property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setErrorMsg(String value) {
        this.errorMsg = value;
    }

}
