
package com.mcafee.mdm.generated;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for PartySearchCriteriaType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="PartySearchCriteriaType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="PARTY_NAME" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ADDR_LN1" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ADDR_LN2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ADDR_LN3" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CITY" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="COUNTRY_CD" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="STATE_CD" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="POSTAL_CD" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="UCN" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CUST_GROUP" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PARTY_TYPE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SRC_SYSTEM" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="SRC_SYSTEM_ID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="FIRST_NAME" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="LAST_NAME" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="EMAIL_ADDRESS" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CONTACT_SOURCE_ID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="CONTACT_SOURCE_SYSTEM" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="MDM_CONTACT_ID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ACCOUNT_SOURCE_ID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ACCOUNT_SOURCE_SYSTEM" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PartySearchCriteriaType", propOrder = {
    "partyname",
    "addrln1",
    "addrln2",
    "addrln3",
    "city",
    "countrycd",
    "statecd",
    "postalcd",
    "ucn",
    "custgroup",
    "partytype",
    "srcsystem",
    "srcsystemid",
    "firstname",
    "lastname",
    "emailaddress",
    "contactsourceid",
    "contactsourcesystem",
    "mdmcontactid",
    "accountsourceid",
    "accountsourcesystem"
})
public class PartySearchCriteriaType {

    @XmlElement(name = "PARTY_NAME", required = true)
    protected String partyname;
    @XmlElement(name = "ADDR_LN1", required = true)
    protected String addrln1;
    @XmlElement(name = "ADDR_LN2")
    protected String addrln2;
    @XmlElement(name = "ADDR_LN3")
    protected String addrln3;
    @XmlElement(name = "CITY")
    protected String city;
    @XmlElement(name = "COUNTRY_CD")
    protected String countrycd;
    @XmlElement(name = "STATE_CD")
    protected String statecd;
    @XmlElement(name = "POSTAL_CD")
    protected String postalcd;
    @XmlElement(name = "UCN")
    protected String ucn;
    @XmlElement(name = "CUST_GROUP")
    protected String custgroup;
    @XmlElement(name = "PARTY_TYPE")
    protected String partytype;
    @XmlElement(name = "SRC_SYSTEM", required = true)
    protected String srcsystem;
    @XmlElement(name = "SRC_SYSTEM_ID")
    protected String srcsystemid;
    @XmlElement(name = "FIRST_NAME")
    protected String firstname;
    @XmlElement(name = "LAST_NAME")
    protected String lastname;
    @XmlElement(name = "EMAIL_ADDRESS")
    protected String emailaddress;
    @XmlElement(name = "CONTACT_SOURCE_ID", required = true)
    protected String contactsourceid;
    @XmlElement(name = "CONTACT_SOURCE_SYSTEM", required = true)
    protected String contactsourcesystem;
    @XmlElement(name = "MDM_CONTACT_ID", required = true)
    protected String mdmcontactid;
    @XmlElement(name = "ACCOUNT_SOURCE_ID")
    protected String accountsourceid;
    @XmlElement(name = "ACCOUNT_SOURCE_SYSTEM")
    protected String accountsourcesystem;

    /**
     * Gets the value of the partyname property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPARTYNAME() {
        return partyname;
    }

    /**
     * Sets the value of the partyname property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPARTYNAME(String value) {
        this.partyname = value;
    }

    /**
     * Gets the value of the addrln1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getADDRLN1() {
        return addrln1;
    }

    /**
     * Sets the value of the addrln1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setADDRLN1(String value) {
        this.addrln1 = value;
    }

    /**
     * Gets the value of the addrln2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getADDRLN2() {
        return addrln2;
    }

    /**
     * Sets the value of the addrln2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setADDRLN2(String value) {
        this.addrln2 = value;
    }

    /**
     * Gets the value of the addrln3 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getADDRLN3() {
        return addrln3;
    }

    /**
     * Sets the value of the addrln3 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setADDRLN3(String value) {
        this.addrln3 = value;
    }

    /**
     * Gets the value of the city property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCITY() {
        return city;
    }

    /**
     * Sets the value of the city property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCITY(String value) {
        this.city = value;
    }

    /**
     * Gets the value of the countrycd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCOUNTRYCD() {
        return countrycd;
    }

    /**
     * Sets the value of the countrycd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCOUNTRYCD(String value) {
        this.countrycd = value;
    }

    /**
     * Gets the value of the statecd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSTATECD() {
        return statecd;
    }

    /**
     * Sets the value of the statecd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSTATECD(String value) {
        this.statecd = value;
    }

    /**
     * Gets the value of the postalcd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPOSTALCD() {
        return postalcd;
    }

    /**
     * Sets the value of the postalcd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPOSTALCD(String value) {
        this.postalcd = value;
    }

    /**
     * Gets the value of the ucn property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUCN() {
        return ucn;
    }

    /**
     * Sets the value of the ucn property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUCN(String value) {
        this.ucn = value;
    }

    /**
     * Gets the value of the custgroup property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCUSTGROUP() {
        return custgroup;
    }

    /**
     * Sets the value of the custgroup property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCUSTGROUP(String value) {
        this.custgroup = value;
    }

    /**
     * Gets the value of the partytype property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPARTYTYPE() {
        return partytype;
    }

    /**
     * Sets the value of the partytype property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPARTYTYPE(String value) {
        this.partytype = value;
    }

    /**
     * Gets the value of the srcsystem property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSRCSYSTEM() {
        return srcsystem;
    }

    /**
     * Sets the value of the srcsystem property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSRCSYSTEM(String value) {
        this.srcsystem = value;
    }

    /**
     * Gets the value of the srcsystemid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSRCSYSTEMID() {
        return srcsystemid;
    }

    /**
     * Sets the value of the srcsystemid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSRCSYSTEMID(String value) {
        this.srcsystemid = value;
    }

    /**
     * Gets the value of the firstname property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFIRSTNAME() {
        return firstname;
    }

    /**
     * Sets the value of the firstname property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFIRSTNAME(String value) {
        this.firstname = value;
    }

    /**
     * Gets the value of the lastname property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLASTNAME() {
        return lastname;
    }

    /**
     * Sets the value of the lastname property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLASTNAME(String value) {
        this.lastname = value;
    }

    /**
     * Gets the value of the emailaddress property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEMAILADDRESS() {
        return emailaddress;
    }

    /**
     * Sets the value of the emailaddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEMAILADDRESS(String value) {
        this.emailaddress = value;
    }

    /**
     * Gets the value of the contactsourceid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCONTACTSOURCEID() {
        return contactsourceid;
    }

    /**
     * Sets the value of the contactsourceid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCONTACTSOURCEID(String value) {
        this.contactsourceid = value;
    }

    /**
     * Gets the value of the contactsourcesystem property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCONTACTSOURCESYSTEM() {
        return contactsourcesystem;
    }

    /**
     * Sets the value of the contactsourcesystem property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCONTACTSOURCESYSTEM(String value) {
        this.contactsourcesystem = value;
    }

    /**
     * Gets the value of the mdmcontactid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMDMCONTACTID() {
        return mdmcontactid;
    }

    /**
     * Sets the value of the mdmcontactid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMDMCONTACTID(String value) {
        this.mdmcontactid = value;
    }

    /**
     * Gets the value of the accountsourceid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getACCOUNTSOURCEID() {
        return accountsourceid;
    }

    /**
     * Sets the value of the accountsourceid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setACCOUNTSOURCEID(String value) {
        this.accountsourceid = value;
    }

    /**
     * Gets the value of the accountsourcesystem property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getACCOUNTSOURCESYSTEM() {
        return accountsourcesystem;
    }

    /**
     * Sets the value of the accountsourcesystem property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setACCOUNTSOURCESYSTEM(String value) {
        this.accountsourcesystem = value;
    }

}
