
package com.mcafee.mdm.generated;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for PartyProfileType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="PartyProfileType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="GoldenCopy" type="{http://mdm.mcafee.com/searchUpsertDelParty/}GoldenCopy"/>
 *         &lt;element name="XREFCopy" type="{http://mdm.mcafee.com/searchUpsertDelParty/}XREFCopy" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PartyProfileType", propOrder = {
    "goldenCopy",
    "xrefCopy"
})
public class PartyProfileType {

    @XmlElement(name = "GoldenCopy", required = true)
    protected GoldenCopy goldenCopy;
    @XmlElement(name = "XREFCopy")
    protected List<XREFCopy> xrefCopy;

    /**
     * Gets the value of the goldenCopy property.
     * 
     * @return
     *     possible object is
     *     {@link GoldenCopy }
     *     
     */
    public GoldenCopy getGoldenCopy() {
        return goldenCopy;
    }

    /**
     * Sets the value of the goldenCopy property.
     * 
     * @param value
     *     allowed object is
     *     {@link GoldenCopy }
     *     
     */
    public void setGoldenCopy(GoldenCopy value) {
        this.goldenCopy = value;
    }

    /**
     * Gets the value of the xrefCopy property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the xrefCopy property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getXREFCopy().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link XREFCopy }
     * 
     * 
     */
    public List<XREFCopy> getXREFCopy() {
        if (xrefCopy == null) {
            xrefCopy = new ArrayList<XREFCopy>();
        }
        return this.xrefCopy;
    }

}
