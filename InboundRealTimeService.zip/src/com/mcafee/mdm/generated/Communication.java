
package com.mcafee.mdm.generated;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Communication complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Communication">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ROWID_COMMUNICATION" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="SRC_SYSTEM" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="SRC_SYSTEM_ID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="COMM_TYPE" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="COMM_VALUE" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="COMM_STATUS" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="COMM_EXTN" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="COMM_MKTG_PREF" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="PRFRD_COMM_IND" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="WEB_DOMAIN" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="COMM_SALES_PREF" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Communication", propOrder = {
    "rowidcommunication",
    "srcsystem",
    "srcsystemid",
    "commtype",
    "commvalue",
    "commstatus",
    "commextn",
    "commmktgpref",
    "prfrdcommind",
    "webdomain",
    "commsalespref"
})
public class Communication {

    @XmlElement(name = "ROWID_COMMUNICATION", required = true)
    protected String rowidcommunication;
    @XmlElement(name = "SRC_SYSTEM", required = true)
    protected String srcsystem;
    @XmlElement(name = "SRC_SYSTEM_ID", required = true)
    protected String srcsystemid;
    @XmlElement(name = "COMM_TYPE", required = true)
    protected String commtype;
    @XmlElement(name = "COMM_VALUE", required = true)
    protected String commvalue;
    @XmlElement(name = "COMM_STATUS", required = true)
    protected String commstatus;
    @XmlElement(name = "COMM_EXTN", required = true)
    protected String commextn;
    @XmlElement(name = "COMM_MKTG_PREF", required = true)
    protected String commmktgpref;
    @XmlElement(name = "PRFRD_COMM_IND", required = true)
    protected String prfrdcommind;
    @XmlElement(name = "WEB_DOMAIN", required = true)
    protected String webdomain;
    @XmlElement(name = "COMM_SALES_PREF", required = true)
    protected String commsalespref;

    /**
     * Gets the value of the rowidcommunication property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getROWIDCOMMUNICATION() {
        return rowidcommunication;
    }

    /**
     * Sets the value of the rowidcommunication property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setROWIDCOMMUNICATION(String value) {
        this.rowidcommunication = value;
    }

    /**
     * Gets the value of the srcsystem property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSRCSYSTEM() {
        return srcsystem;
    }

    /**
     * Sets the value of the srcsystem property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSRCSYSTEM(String value) {
        this.srcsystem = value;
    }

    /**
     * Gets the value of the srcsystemid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSRCSYSTEMID() {
        return srcsystemid;
    }

    /**
     * Sets the value of the srcsystemid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSRCSYSTEMID(String value) {
        this.srcsystemid = value;
    }

    /**
     * Gets the value of the commtype property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCOMMTYPE() {
        return commtype;
    }

    /**
     * Sets the value of the commtype property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCOMMTYPE(String value) {
        this.commtype = value;
    }

    /**
     * Gets the value of the commvalue property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCOMMVALUE() {
        return commvalue;
    }

    /**
     * Sets the value of the commvalue property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCOMMVALUE(String value) {
        this.commvalue = value;
    }

    /**
     * Gets the value of the commstatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCOMMSTATUS() {
        return commstatus;
    }

    /**
     * Sets the value of the commstatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCOMMSTATUS(String value) {
        this.commstatus = value;
    }

    /**
     * Gets the value of the commextn property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCOMMEXTN() {
        return commextn;
    }

    /**
     * Sets the value of the commextn property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCOMMEXTN(String value) {
        this.commextn = value;
    }

    /**
     * Gets the value of the commmktgpref property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCOMMMKTGPREF() {
        return commmktgpref;
    }

    /**
     * Sets the value of the commmktgpref property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCOMMMKTGPREF(String value) {
        this.commmktgpref = value;
    }

    /**
     * Gets the value of the prfrdcommind property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPRFRDCOMMIND() {
        return prfrdcommind;
    }

    /**
     * Sets the value of the prfrdcommind property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPRFRDCOMMIND(String value) {
        this.prfrdcommind = value;
    }

    /**
     * Gets the value of the webdomain property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWEBDOMAIN() {
        return webdomain;
    }

    /**
     * Sets the value of the webdomain property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWEBDOMAIN(String value) {
        this.webdomain = value;
    }

    /**
     * Gets the value of the commsalespref property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCOMMSALESPREF() {
        return commsalespref;
    }

    /**
     * Sets the value of the commsalespref property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCOMMSALESPREF(String value) {
        this.commsalespref = value;
    }

}
