
package com.mcafee.mdm.generated;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for PartyContactMDMRelationshipType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="PartyContactMDMRelationshipType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="MDM_PARENT_ID" type="{http://mdm.mcafee.com/searchUpsertDelParty/}PartyPersonMDMRelationshipType"/>
 *         &lt;element name="MDM_CHILD_ID" type="{http://mdm.mcafee.com/searchUpsertDelParty/}PartyPersonMDMRelationshipType" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="HIERARCHY_TYPE" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="REL_TYPE" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PartyContactMDMRelationshipType", propOrder = {
    "mdmparentid",
    "mdmchildid",
    "hierarchytype",
    "reltype"
})
public class PartyContactMDMRelationshipType {

    @XmlElement(name = "MDM_PARENT_ID", required = true)
    protected PartyPersonMDMRelationshipType mdmparentid;
    @XmlElement(name = "MDM_CHILD_ID")
    protected List<PartyPersonMDMRelationshipType> mdmchildid;
    @XmlElement(name = "HIERARCHY_TYPE", required = true)
    protected String hierarchytype;
    @XmlElement(name = "REL_TYPE", required = true)
    protected String reltype;

    /**
     * Gets the value of the mdmparentid property.
     * 
     * @return
     *     possible object is
     *     {@link PartyPersonMDMRelationshipType }
     *     
     */
    public PartyPersonMDMRelationshipType getMDMPARENTID() {
        return mdmparentid;
    }

    /**
     * Sets the value of the mdmparentid property.
     * 
     * @param value
     *     allowed object is
     *     {@link PartyPersonMDMRelationshipType }
     *     
     */
    public void setMDMPARENTID(PartyPersonMDMRelationshipType value) {
        this.mdmparentid = value;
    }

    /**
     * Gets the value of the mdmchildid property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the mdmchildid property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getMDMCHILDID().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PartyPersonMDMRelationshipType }
     * 
     * 
     */
    public List<PartyPersonMDMRelationshipType> getMDMCHILDID() {
        if (mdmchildid == null) {
            mdmchildid = new ArrayList<PartyPersonMDMRelationshipType>();
        }
        return this.mdmchildid;
    }

    /**
     * Gets the value of the hierarchytype property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHIERARCHYTYPE() {
        return hierarchytype;
    }

    /**
     * Sets the value of the hierarchytype property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHIERARCHYTYPE(String value) {
        this.hierarchytype = value;
    }

    /**
     * Gets the value of the reltype property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRELTYPE() {
        return reltype;
    }

    /**
     * Sets the value of the reltype property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRELTYPE(String value) {
        this.reltype = value;
    }

}
