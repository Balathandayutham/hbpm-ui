
package com.mcafee.mdm.generated;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for PartyXrefType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="PartyXrefType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ErrorMsg" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="LAST_UPDATE_DATE" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="SRC_CREATE_DT" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="UPDATE_BY" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ROWID_OBJECT" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ORIG_ROWID_OBJECT" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="BO_CLASS_CODE" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="PARTY_TYPE" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="PARTY_NAME" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="GEO" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="REGION" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="STATUS_CD" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="VAT_REG_NBR" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="TAX_JURSDCTN_CD" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="SALES_BLOCK_CD" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="UCN" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="LEGACY_UCN" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ENGLISH_NAME" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="DNB_DBA_NAME" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="DNB_SECOND_TRADE_STYLE" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="DNB_REG_NAME" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="MSG_TRKN_ID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="PROCESS_STATE_IND" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="PHYSICAL_GEO" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="PHYSICAL_REGION" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="PARTNERSHIP_STATUS" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="DO_NOT_MERGR" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="XREF" type="{http://mdm.mcafee.com/searchUpsertDelParty/}XREFType" maxOccurs="unbounded"/>
 *         &lt;element name="Account" type="{http://mdm.mcafee.com/searchUpsertDelParty/}AccountXrefType" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="Address" type="{http://mdm.mcafee.com/searchUpsertDelParty/}AddressXrefType" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="Communication" type="{http://mdm.mcafee.com/searchUpsertDelParty/}CommunicationXrefType" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="Classification" type="{http://mdm.mcafee.com/searchUpsertDelParty/}ClassificationXrefType" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="PartyOrgExt" type="{http://mdm.mcafee.com/searchUpsertDelParty/}PartyOrgExtXrefType" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="PartyPersonExt" type="{http://mdm.mcafee.com/searchUpsertDelParty/}PartyPersonExtXrefType" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="PartyPerson" type="{http://mdm.mcafee.com/searchUpsertDelParty/}PartyPersonXrefType" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="PartyRel" type="{http://mdm.mcafee.com/searchUpsertDelParty/}PartyRelationshipXrefType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PartyXrefType", propOrder = {
    "errorMsg",
    "lastupdatedate",
    "srccreatedt",
    "updateby",
    "rowidobject",
    "origrowidobject",
    "boclasscode",
    "partytype",
    "partyname",
    "geo",
    "region",
    "statuscd",
    "vatregnbr",
    "taxjursdctncd",
    "salesblockcd",
    "ucn",
    "legacyucn",
    "englishname",
    "dnbdbaname",
    "dnbsecondtradestyle",
    "dnbregname",
    "msgtrknid",
    "processstateind",
    "physicalgeo",
    "physicalregion",
    "partnershipstatus",
    "donotmerge",
    "xref",
    "account",
    "address",
    "communication",
    "classification",
    "partyOrgExt",
    "partyPersonExt",
    "partyPerson",
    "partyRel"
})
public class PartyXrefType {

    @XmlElement(name = "ErrorMsg", required = true)
    protected String errorMsg;
    @XmlElement(name = "LAST_UPDATE_DATE", required = true)
    protected String lastupdatedate;
    @XmlElement(name = "SRC_CREATE_DT", required = true)
    protected String srccreatedt;
    @XmlElement(name = "UPDATE_BY", required = true)
    protected String updateby;
    @XmlElement(name = "ROWID_OBJECT", required = true)
    protected String rowidobject;
    @XmlElement(name = "ORIG_ROWID_OBJECT", required = true)
    protected String origrowidobject;
    @XmlElement(name = "BO_CLASS_CODE", required = true)
    protected String boclasscode;
    @XmlElement(name = "PARTY_TYPE", required = true)
    protected String partytype;
    @XmlElement(name = "PARTY_NAME", required = true)
    protected String partyname;
    @XmlElement(name = "GEO", required = true)
    protected String geo;
    @XmlElement(name = "REGION", required = true)
    protected String region;
    @XmlElement(name = "STATUS_CD", required = true)
    protected String statuscd;
    @XmlElement(name = "VAT_REG_NBR", required = true)
    protected String vatregnbr;
    @XmlElement(name = "TAX_JURSDCTN_CD", required = true)
    protected String taxjursdctncd;
    @XmlElement(name = "SALES_BLOCK_CD", required = true)
    protected String salesblockcd;
    @XmlElement(name = "UCN", required = true)
    protected String ucn;
    @XmlElement(name = "LEGACY_UCN", required = true)
    protected String legacyucn;
    @XmlElement(name = "ENGLISH_NAME", required = true)
    protected String englishname;
    @XmlElement(name = "DNB_DBA_NAME", required = true)
    protected String dnbdbaname;
    @XmlElement(name = "DNB_SECOND_TRADE_STYLE", required = true)
    protected String dnbsecondtradestyle;
    @XmlElement(name = "DNB_REG_NAME", required = true)
    protected String dnbregname;
    @XmlElement(name = "MSG_TRKN_ID", required = true)
    protected String msgtrknid;
    @XmlElement(name = "PROCESS_STATE_IND", required = true)
    protected String processstateind;
    @XmlElement(name = "PHYSICAL_GEO", required = true)
    protected String physicalgeo;
    @XmlElement(name = "PHYSICAL_REGION", required = true)
    protected String physicalregion;
    @XmlElement(name = "PARTNERSHIP_STATUS", required = true)
    protected String partnershipstatus;
    @XmlElement(name = "DO_NOT_MERGE", required = true)
    protected String donotmerge;
    @XmlElement(name = "XREF", required = true)
    protected List<XREFType> xref;
    @XmlElement(name = "Account")
    protected List<AccountXrefType> account;
    @XmlElement(name = "Address")
    protected List<AddressXrefType> address;
    @XmlElement(name = "Communication")
    protected List<CommunicationXrefType> communication;
    @XmlElement(name = "Classification")
    protected List<ClassificationXrefType> classification;
    @XmlElement(name = "PartyOrgExt")
    protected List<PartyOrgExtXrefType> partyOrgExt;
    @XmlElement(name = "PartyPersonExt")
    protected List<PartyPersonExtXrefType> partyPersonExt;
    @XmlElement(name = "PartyPerson")
    protected List<PartyPersonXrefType> partyPerson;
    @XmlElement(name = "PartyRel")
    protected PartyRelationshipXrefType partyRel;

    /**
     * Gets the value of the errorMsg property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getErrorMsg() {
        return errorMsg;
    }

    /**
     * Sets the value of the errorMsg property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setErrorMsg(String value) {
        this.errorMsg = value;
    }

    /**
     * Gets the value of the lastupdatedate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLASTUPDATEDATE() {
        return lastupdatedate;
    }

    /**
     * Sets the value of the lastupdatedate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLASTUPDATEDATE(String value) {
        this.lastupdatedate = value;
    }

    /**
     * Gets the value of the srccreatedt property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSRCCREATEDT() {
        return srccreatedt;
    }

    /**
     * Sets the value of the srccreatedt property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSRCCREATEDT(String value) {
        this.srccreatedt = value;
    }

    /**
     * Gets the value of the updateby property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUPDATEBY() {
        return updateby;
    }

    /**
     * Sets the value of the updateby property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUPDATEBY(String value) {
        this.updateby = value;
    }

    /**
     * Gets the value of the rowidobject property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getROWIDOBJECT() {
        return rowidobject;
    }

    /**
     * Sets the value of the rowidobject property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setROWIDOBJECT(String value) {
        this.rowidobject = value;
    }

    /**
     * Gets the value of the origrowidobject property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getORIGROWIDOBJECT() {
        return origrowidobject;
    }

    /**
     * Sets the value of the origrowidobject property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setORIGROWIDOBJECT(String value) {
        this.origrowidobject = value;
    }

    /**
     * Gets the value of the boclasscode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBOCLASSCODE() {
        return boclasscode;
    }

    /**
     * Sets the value of the boclasscode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBOCLASSCODE(String value) {
        this.boclasscode = value;
    }

    /**
     * Gets the value of the partytype property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPARTYTYPE() {
        return partytype;
    }

    /**
     * Sets the value of the partytype property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPARTYTYPE(String value) {
        this.partytype = value;
    }

    /**
     * Gets the value of the partyname property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPARTYNAME() {
        return partyname;
    }

    /**
     * Sets the value of the partyname property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPARTYNAME(String value) {
        this.partyname = value;
    }

    /**
     * Gets the value of the geo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGEO() {
        return geo;
    }

    /**
     * Sets the value of the geo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGEO(String value) {
        this.geo = value;
    }

    /**
     * Gets the value of the region property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getREGION() {
        return region;
    }

    /**
     * Sets the value of the region property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setREGION(String value) {
        this.region = value;
    }

    /**
     * Gets the value of the statuscd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSTATUSCD() {
        return statuscd;
    }

    /**
     * Sets the value of the statuscd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSTATUSCD(String value) {
        this.statuscd = value;
    }

    /**
     * Gets the value of the vatregnbr property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVATREGNBR() {
        return vatregnbr;
    }

    /**
     * Sets the value of the vatregnbr property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVATREGNBR(String value) {
        this.vatregnbr = value;
    }

    /**
     * Gets the value of the taxjursdctncd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTAXJURSDCTNCD() {
        return taxjursdctncd;
    }

    /**
     * Sets the value of the taxjursdctncd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTAXJURSDCTNCD(String value) {
        this.taxjursdctncd = value;
    }

    /**
     * Gets the value of the salesblockcd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSALESBLOCKCD() {
        return salesblockcd;
    }

    /**
     * Sets the value of the salesblockcd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSALESBLOCKCD(String value) {
        this.salesblockcd = value;
    }

    /**
     * Gets the value of the ucn property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUCN() {
        return ucn;
    }

    /**
     * Sets the value of the ucn property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUCN(String value) {
        this.ucn = value;
    }

    /**
     * Gets the value of the legacyucn property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLEGACYUCN() {
        return legacyucn;
    }

    /**
     * Sets the value of the legacyucn property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLEGACYUCN(String value) {
        this.legacyucn = value;
    }

    /**
     * Gets the value of the englishname property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getENGLISHNAME() {
        return englishname;
    }

    /**
     * Sets the value of the englishname property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setENGLISHNAME(String value) {
        this.englishname = value;
    }

    /**
     * Gets the value of the dnbdbaname property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDNBDBANAME() {
        return dnbdbaname;
    }

    /**
     * Sets the value of the dnbdbaname property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDNBDBANAME(String value) {
        this.dnbdbaname = value;
    }

    /**
     * Gets the value of the dnbsecondtradestyle property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDNBSECONDTRADESTYLE() {
        return dnbsecondtradestyle;
    }

    /**
     * Sets the value of the dnbsecondtradestyle property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDNBSECONDTRADESTYLE(String value) {
        this.dnbsecondtradestyle = value;
    }

    /**
     * Gets the value of the dnbregname property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDNBREGNAME() {
        return dnbregname;
    }

    /**
     * Sets the value of the dnbregname property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDNBREGNAME(String value) {
        this.dnbregname = value;
    }

    /**
     * Gets the value of the msgtrknid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMSGTRKNID() {
        return msgtrknid;
    }

    /**
     * Sets the value of the msgtrknid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMSGTRKNID(String value) {
        this.msgtrknid = value;
    }

    /**
     * Gets the value of the processstateind property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPROCESSSTATEIND() {
        return processstateind;
    }

    /**
     * Sets the value of the processstateind property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPROCESSSTATEIND(String value) {
        this.processstateind = value;
    }

    /**
     * Gets the value of the physicalgeo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPHYSICALGEO() {
        return physicalgeo;
    }

    /**
     * Sets the value of the physicalgeo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPHYSICALGEO(String value) {
        this.physicalgeo = value;
    }

    /**
     * Gets the value of the physicalregion property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPHYSICALREGION() {
        return physicalregion;
    }

    /**
     * Sets the value of the physicalregion property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPHYSICALREGION(String value) {
        this.physicalregion = value;
    }

    /**
     * Gets the value of the partnershipstatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPARTNERSHIPSTATUS() {
        return partnershipstatus;
    }

    /**
     * Sets the value of the partnershipstatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPARTNERSHIPSTATUS(String value) {
        this.partnershipstatus = value;
    }
    
    /**
     * Gets the value of the donotmerge property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDONOTMERGE() {
        return donotmerge;
    }

    /**
     * Sets the value of the donotmerge property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDONOTMERGE(String value) {
        this.donotmerge = value;
    }

    /**
     * Gets the value of the xref property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the xref property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getXREF().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link XREFType }
     * 
     * 
     */
    public List<XREFType> getXREF() {
        if (xref == null) {
            xref = new ArrayList<XREFType>();
        }
        return this.xref;
    }

    /**
     * Gets the value of the account property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the account property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAccount().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AccountXrefType }
     * 
     * 
     */
    public List<AccountXrefType> getAccount() {
        if (account == null) {
            account = new ArrayList<AccountXrefType>();
        }
        return this.account;
    }

    /**
     * Gets the value of the address property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the address property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAddress().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AddressXrefType }
     * 
     * 
     */
    public List<AddressXrefType> getAddress() {
        if (address == null) {
            address = new ArrayList<AddressXrefType>();
        }
        return this.address;
    }

    /**
     * Gets the value of the communication property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the communication property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCommunication().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CommunicationXrefType }
     * 
     * 
     */
    public List<CommunicationXrefType> getCommunication() {
        if (communication == null) {
            communication = new ArrayList<CommunicationXrefType>();
        }
        return this.communication;
    }

    /**
     * Gets the value of the classification property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the classification property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getClassification().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ClassificationXrefType }
     * 
     * 
     */
    public List<ClassificationXrefType> getClassification() {
        if (classification == null) {
            classification = new ArrayList<ClassificationXrefType>();
        }
        return this.classification;
    }

    /**
     * Gets the value of the partyOrgExt property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the partyOrgExt property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPartyOrgExt().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PartyOrgExtXrefType }
     * 
     * 
     */
    public List<PartyOrgExtXrefType> getPartyOrgExt() {
        if (partyOrgExt == null) {
            partyOrgExt = new ArrayList<PartyOrgExtXrefType>();
        }
        return this.partyOrgExt;
    }

    /**
     * Gets the value of the partyPersonExt property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the partyPersonExt property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPartyPersonExt().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PartyPersonExtXrefType }
     * 
     * 
     */
    public List<PartyPersonExtXrefType> getPartyPersonExt() {
        if (partyPersonExt == null) {
            partyPersonExt = new ArrayList<PartyPersonExtXrefType>();
        }
        return this.partyPersonExt;
    }

    /**
     * Gets the value of the partyPerson property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the partyPerson property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPartyPerson().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PartyPersonXrefType }
     * 
     * 
     */
    public List<PartyPersonXrefType> getPartyPerson() {
        if (partyPerson == null) {
            partyPerson = new ArrayList<PartyPersonXrefType>();
        }
        return this.partyPerson;
    }

    /**
     * Gets the value of the partyRel property.
     * 
     * @return
     *     possible object is
     *     {@link PartyRelationshipXrefType }
     *     
     */
    public PartyRelationshipXrefType getPartyRel() {
        return partyRel;
    }

    /**
     * Sets the value of the partyRel property.
     * 
     * @param value
     *     allowed object is
     *     {@link PartyRelationshipXrefType }
     *     
     */
    public void setPartyRel(PartyRelationshipXrefType value) {
        this.partyRel = value;
    }

}
