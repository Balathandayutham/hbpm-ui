
package com.mcafee.mdm.generated;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for PartyAccountRelationshipType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="PartyAccountRelationshipType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="MDM_PARENT_UCN" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="MDM_PARENT_NAME" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="MDM_GLB_PARENT_UCN" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="MDM_GLB_PARENT_NAME" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="HIERARCHY_TYPE" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="REL_TYPE" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="SINGLE_SITE_FLAG" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PartyAccountRelationshipType", propOrder = {
    "mdmparentucn",
    "mdmparentname",
    "mdmglbparentucn",
    "mdmglbparentname",
    "hierarchytype",
    "reltype",
    "singlesiteflag"
})
public class PartyAccountRelationshipType {

    @XmlElement(name = "MDM_PARENT_UCN", required = true)
    protected String mdmparentucn;
    @XmlElement(name = "MDM_PARENT_NAME", required = true)
    protected String mdmparentname;
    @XmlElement(name = "MDM_GLB_PARENT_UCN", required = true)
    protected String mdmglbparentucn;
    @XmlElement(name = "MDM_GLB_PARENT_NAME", required = true)
    protected String mdmglbparentname;
    @XmlElement(name = "HIERARCHY_TYPE", required = true)
    protected String hierarchytype;
    @XmlElement(name = "REL_TYPE", required = true)
    protected String reltype;
    @XmlElement(name = "SINGLE_SITE_FLAG", required = true)
    protected String singlesiteflag;

    /**
     * Gets the value of the mdmparentucn property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMDMPARENTUCN() {
        return mdmparentucn;
    }

    /**
     * Sets the value of the mdmparentucn property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMDMPARENTUCN(String value) {
        this.mdmparentucn = value;
    }

    /**
     * Gets the value of the mdmparentname property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMDMPARENTNAME() {
        return mdmparentname;
    }

    /**
     * Sets the value of the mdmparentname property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMDMPARENTNAME(String value) {
        this.mdmparentname = value;
    }

    /**
     * Gets the value of the mdmglbparentucn property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMDMGLBPARENTUCN() {
        return mdmglbparentucn;
    }

    /**
     * Sets the value of the mdmglbparentucn property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMDMGLBPARENTUCN(String value) {
        this.mdmglbparentucn = value;
    }

    /**
     * Gets the value of the mdmglbparentname property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMDMGLBPARENTNAME() {
        return mdmglbparentname;
    }

    /**
     * Sets the value of the mdmglbparentname property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMDMGLBPARENTNAME(String value) {
        this.mdmglbparentname = value;
    }

    /**
     * Gets the value of the hierarchytype property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHIERARCHYTYPE() {
        return hierarchytype;
    }

    /**
     * Sets the value of the hierarchytype property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHIERARCHYTYPE(String value) {
        this.hierarchytype = value;
    }

    /**
     * Gets the value of the reltype property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRELTYPE() {
        return reltype;
    }

    /**
     * Sets the value of the reltype property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRELTYPE(String value) {
        this.reltype = value;
    }

    /**
     * Gets the value of the singlesiteflag property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSINGLESITEFLAG() {
        return singlesiteflag;
    }

    /**
     * Sets the value of the singlesiteflag property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSINGLESITEFLAG(String value) {
        this.singlesiteflag = value;
    }

}
