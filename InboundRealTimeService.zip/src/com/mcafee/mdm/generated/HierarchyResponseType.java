
package com.mcafee.mdm.generated;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for HierarchyResponseType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="HierarchyResponseType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="MDM_GLOBAL_UCN" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="MDM_GLOBAL_PARENT_NAME" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Parties" type="{http://mdm.mcafee.com/searchUpsertDelParty/}Parties" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "HierarchyResponseType", propOrder = {
    "mdmglobalucn",
    "mdmglobalparentname",
    "parties"
})
public class HierarchyResponseType {

    @XmlElement(name = "MDM_GLOBAL_UCN", required = true)
    protected String mdmglobalucn;
    @XmlElement(name = "MDM_GLOBAL_PARENT_NAME", required = true)
    protected String mdmglobalparentname;
    @XmlElement(name = "Parties")
    protected List<Parties> parties;

    /**
     * Gets the value of the mdmglobalucn property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMDMGLOBALUCN() {
        return mdmglobalucn;
    }

    /**
     * Sets the value of the mdmglobalucn property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMDMGLOBALUCN(String value) {
        this.mdmglobalucn = value;
    }

    /**
     * Gets the value of the mdmglobalparentname property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMDMGLOBALPARENTNAME() {
        return mdmglobalparentname;
    }

    /**
     * Sets the value of the mdmglobalparentname property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMDMGLOBALPARENTNAME(String value) {
        this.mdmglobalparentname = value;
    }

    /**
     * Gets the value of the parties property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the parties property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getParties().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Parties }
     * 
     * 
     */
    public List<Parties> getParties() {
        if (parties == null) {
            parties = new ArrayList<Parties>();
        }
        return this.parties;
    }

}
