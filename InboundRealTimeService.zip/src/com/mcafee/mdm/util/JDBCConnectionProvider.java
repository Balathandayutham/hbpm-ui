package com.mcafee.mdm.util;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Hashtable;
import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import org.apache.log4j.Logger;

import com.mcafee.mdm.exception.ServiceProcessingException;

public class JDBCConnectionProvider {

	private static final Logger LOG = Logger.getLogger(JDBCConnectionProvider.class.getName());
	private static JDBCConnectionProvider singleInstance;
	
	private static String queryForPartyProfile = null;
	private static String queryForPartyProfileXref = null;
	private static DataSource dataSource = null;
	File externalFile = null;
	private static Properties properties = new Properties();
	
	public static JDBCConnectionProvider getSingleInstance() throws ServiceProcessingException {
	    if (singleInstance == null) {
	      synchronized (JDBCConnectionProvider.class) {
	        if (singleInstance == null) {
	          singleInstance = new JDBCConnectionProvider();
	        }
	      }
	    }
	    return singleInstance;
	  }

	
	private JDBCConnectionProvider() throws ServiceProcessingException {
		try {
			if (properties.isEmpty()) {
				properties = PropertyUtil.getPropertiesFromFile("jdbcProp");
				Hashtable<String, String> props = new Hashtable<String, String>(2);
				props.put(Context.PROVIDER_URL, properties.getProperty("PROVIDER_URL"));
				props.put(Context.INITIAL_CONTEXT_FACTORY, properties.getProperty("INITIAL_CONTEXT_FACTORY"));
				
				dataSource = (DataSource) (new InitialContext(props)).lookup(properties.getProperty("DataSourceJNDI"));
	
				queryForPartyProfile = properties.getProperty("queryGetPartyProfile");
				queryForPartyProfileXref = properties.getProperty("queryGetPartyProfileXref");
				//LOG.info("DataSourceJNDI:"+properties.getProperty("DataSourceJNDI"));
			}
		} catch (NamingException nmExcp) {
			LOG.error("NamingException occured while look up for datasource " + properties.getProperty("DataSourceJNDI"));
			ServiceProcessingException customException = new ServiceProcessingException(nmExcp);
			customException.setMessage("Can't look up JDBC Datasource. Please call support team.");
			throw customException;
		}
	}
	
	public static String getQueryForPartyProfile() {
		return queryForPartyProfile;
	}

	public static void setQueryForPartyProfile(String queryForPartyProfile) {
		JDBCConnectionProvider.queryForPartyProfile = queryForPartyProfile;
	}

	public static String getQueryForPartyProfileXref() {
		return queryForPartyProfileXref;
	}

	public static void setQueryForPartyProfileXref(String queryForPartyProfileXref) {
		JDBCConnectionProvider.queryForPartyProfileXref = queryForPartyProfileXref;
	}
	
	public Connection getJdbcConnectionFromDS() throws ServiceProcessingException {
	//	LOG.info("Executing getJdbcConnectionFromDS()");
		
		Connection jdbcConnection = null;
		try {
			jdbcConnection = dataSource.getConnection();
		} catch (SQLException sqlEx) {
			LOG.error("Exception: Can't create JDBC connection from datasource: " + sqlEx);
			ServiceProcessingException customException = new ServiceProcessingException(sqlEx);
			customException.setMessage("Failed to create JDBC connection from datasource. Please call support team.");
			throw customException;
		}
	//	LOG.info("Executed getJdbcConnectionFromDS()");
	//	LOG.info("DS connection:"+jdbcConnection);
		return jdbcConnection;
	}

	public Connection createJdbcConnection() throws ServiceProcessingException {
		LOG.info("Executing createJdbcConnection()");
		
		Connection jdbcConnection = null;
		String driverType = "jdbc:oracle:thin";
		String connectorStr = ":@";
		
		try {
			if (jdbcConnection == null || jdbcConnection.isClosed()) {
				Class.forName("oracle.jdbc.driver.OracleDriver");
				
				jdbcConnection = DriverManager.getConnection(driverType + connectorStr + properties.getProperty("url"), 
						properties.getProperty("user"), properties.getProperty("password"));
				//jdbcConnection = DriverManager.getConnection(driverType + connectorStr + dbUrl, dbUser, dbPassword);
				LOG.info("Connected successfully to ORS");
			}
		} catch (ClassNotFoundException cnfEx) {
			LOG.error("Exception: OracleDriver class not found");
			ServiceProcessingException customException = new ServiceProcessingException(cnfEx);
			customException.setMessage("Failed to load Oracle JDBC Driver. Please call support team.");
			throw customException;
		} catch (SQLException sqlEx) {
			LOG.error("Exception: Can't create JDBC connection: " + sqlEx);
			ServiceProcessingException customException = new ServiceProcessingException(sqlEx);
			customException.setMessage("Failed to create JDBC connection to ORS. Please call support team.");
			throw customException;
		}
		LOG.info("Executed createJdbcConnection()");
		
		return jdbcConnection;
	}
	
	public void closeJdbcConnection(Connection connection) throws ServiceProcessingException {
	//	LOG.info("Executing closeJdbcConnection()");
		
		try {
			if (connection != null && !connection.isClosed()) {
				connection.close();
			}
		} catch (SQLException sqlEx) {
			LOG.error("Exception: Can't close JDBC connection: " + sqlEx);
			ServiceProcessingException customException = new ServiceProcessingException(sqlEx);
			customException.setMessage("Failed to close JDBC connection to ORS. Please call support team.");
			throw customException;
		}
	//	LOG.info("Executed closeJdbcConnection()");
	}

}
