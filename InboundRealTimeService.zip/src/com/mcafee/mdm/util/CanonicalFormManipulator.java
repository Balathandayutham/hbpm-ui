package com.mcafee.mdm.util;


import org.apache.log4j.Logger;
import org.springframework.util.CollectionUtils;

import com.mcafee.mdm.generated.AccountType;
import com.mcafee.mdm.generated.AccountXrefType;
import com.mcafee.mdm.generated.AddressType;
import com.mcafee.mdm.generated.AddressXrefType;
import com.mcafee.mdm.generated.ClassificationType;
import com.mcafee.mdm.generated.ClassificationXrefType;
import com.mcafee.mdm.generated.CommunicationType;
import com.mcafee.mdm.generated.CommunicationXrefType;
import com.mcafee.mdm.generated.PartyAccountRelationshipType;
import com.mcafee.mdm.generated.PartyAccountRelationshipXrefType;
import com.mcafee.mdm.generated.PartyOrgExtType;
import com.mcafee.mdm.generated.PartyOrgExtXrefType;
import com.mcafee.mdm.generated.PartyPersonExtType;
import com.mcafee.mdm.generated.PartyPersonExtXrefType;
import com.mcafee.mdm.generated.PartyRelationshipType;
import com.mcafee.mdm.generated.PartyRelationshipXrefType;
import com.mcafee.mdm.generated.PartyType;
import com.mcafee.mdm.generated.PartyXrefType;
import com.mcafee.mdm.generated.XREFType;

public class CanonicalFormManipulator {

	private static final Logger LOG = Logger.getLogger(CanonicalFormManipulator.class);
	/**
	 * Sets default value to all the null attributes in Golden copy.
	 * This is to ensure that an attribute tag with null value be present in the published XML.
	 * @param party
	 */
	public static void setDefaultValueInGoldenAttributes(PartyType party) {


		String defualt = "";

		if (party == null) {
			LOG.info("The provided golden object is null");
			return;
		}

		if (party.getBOCLASSCODE() == null) {
			party.setBOCLASSCODE(defualt);
		}
		if (party.getErrorMsg() == null) {
			party.setErrorMsg(defualt);
		}
		if (party.getGEO() == null) {
			party.setGEO(defualt);
		}
		if (party.getPARTYNAME() == null) {
			party.setPARTYNAME(defualt);
		}
		if (party.getPARTYTYPE() == null) {
			party.setPARTYTYPE(defualt);
		}
		if (party.getREGION() == null) {
			party.setREGION(defualt);
		} if (party.getROWIDOBJECT() == null) {
			party.setROWIDOBJECT(defualt);
		}
		if (party.getSALESBLOCKCD() == null ) {
			party.setSALESBLOCKCD(defualt);
		}
		if (party.getSTATUSCD() == null) {
			party.setSTATUSCD(defualt);
		}
		if (party.getTAXJURSDCTNCD() == null) {
			party.setTAXJURSDCTNCD(defualt);
		}
		if (party.getUCN() == null) {
			party.setUCN(defualt);
		}
		if (party.getVATREGNBR() == null) {
			party.setVATREGNBR(defualt);
		}
		//Change for English Name :: Adding blank English name for NULL value
		if (party.getENGLISHNAME() == null) {
			party.setENGLISHNAME(defualt);
		}

		for (int index = 0; index < party.getXREF().size(); index++) {
			XREFType xref = party.getXREF().get(index);
			if (xref.getSRCPKEY() == null) {
				xref.setSRCPKEY(defualt);
			}
			if (xref.getSRCSYSTEM() == null) {
				xref.setSRCSYSTEM(defualt);
			}
		}

		if (party.getAccount().size() == 0) {
			AccountType account = new AccountType();
			party.getAccount().add(account);
		}

		for (int index = 0; index < party.getAccount().size(); index++) {
			AccountType account = party.getAccount().get(index);

			if (account.getACCOUNTGEO() == null) {
				account.setACCOUNTGEO(defualt);
			}
			if (account.getACCOUNTREGION() == null) {
				account.setACCOUNTREGION(defualt);
			}
			if (account.getACCOUNTTAXJURSDCTNCD() == null) {
				account.setACCOUNTTAXJURSDCTNCD(defualt);
			}
			if (account.getACCOUNTVATREGNBR() == null) {
				account.setACCOUNTVATREGNBR(defualt);
			}
			if (account.getACCTNAME() == null) {
				account.setACCTNAME(defualt);
			}
			if (account.getACCTSTATUS() == null) {
				account.setACCTSTATUS(defualt);
			}
			if (account.getACCTTYPE() == null) {
				account.setACCTTYPE(defualt);
			}
			if (account.getALIASNAME() == null) {
				account.setALIASNAME(defualt);
			}
			if (account.getBILLBLOCKCD() == null) {
				account.setBILLBLOCKCD(defualt);
			}
			if (account.getCHANNELID() == null) {
				account.setCHANNELID(defualt);
			}
			if (account.getCOMPANYCD() == null) {
				account.setCOMPANYCD(defualt);
			}
			if (account.getCUSTGROUP() == null) {
				account.setCUSTGROUP(defualt);
			}
			if (account.getDIRECTIND() == null) {
				account.setDIRECTIND(defualt);
			}
			if (account.getDLVRYBLOCKCD() == null) {
				account.setDLVRYBLOCKCD(defualt);
			}
			if (account.getMARKET() == null) {
				account.setMARKET(defualt);
			}
			if (account.getMDMLEGACYID() == null) {
				account.setMDMLEGACYID(defualt);
			}
			if (account.getNAMEDACCTIND() == null) {
				account.setNAMEDACCTIND(defualt);
			}
			if (account.getNONVALACCTIND() == null) {
				account.setNONVALACCTIND(defualt);
			}
			if (account.getORDRBLOCKCD() == null) {
				account.setORDRBLOCKCD(defualt);
			}
			if (account.getPARTNERIND() == null) {
				account.setPARTNERIND(defualt);
			}
			if (account.getPARTNERTYPE() == null) {
				account.setPARTNERTYPE(defualt);
			}
			if (account.getPOSTBLOCKCD() == null) {
				account.setPOSTBLOCKCD(defualt);
			}
			if (account.getPRICEGROUP() == null) {
				account.setPRICEGROUP(defualt);
			}
			if (account.getROWIDACCOUNT() == null) {
				account.setROWIDACCOUNT(defualt);
			}
			if (account.getSALEBLOCKCD() == null) {
				account.setSALEBLOCKCD(defualt);
			}
			if (account.getSAPCUSTNUMBER() == null) {
				account.setSAPCUSTNUMBER(defualt);
			}
			if (account.getSIEBELROWID() == null) {
				account.setSIEBELROWID(defualt);
			}
			if (account.getTAXTYPE() == null) {
				account.setTAXTYPE(defualt);
			}
			if (account.getVENDORNBR() == null) {
				account.setVENDORNBR(defualt);
			}
			/** Modified for SFDC START */
			if(account.getSalesForceID()==null) {
				account.setSalesForceID(defualt);
			}
			if(account.getDraftAccountFlag()==null) {
				account.setDraftAccountFlag(defualt);
			}
			/** Modified for SFDC END */
			/** changes for Sales Force Integration -Start */
			if(account.getLOCALNAME()==null) {
				account.setLOCALNAME(defualt);
			}
			if(account.getCURRENCYCD()==null) {
				account.setCURRENCYCD(defualt);
			}
			if(account.getTAXID()==null) {
				account.setTAXID(defualt);
			}
			if(account.getPRICEBANDAGGREMENT()==null) {
				account.setPRICEBANDAGGREMENT(defualt);
			}
			if(account.getSITEDESIGNATION()==null) {
				account.setSITEDESIGNATION(defualt);
			}
			if(account.getRESELLLEVEL()==null) {
				account.setRESELLLEVEL(defualt);
			}
			if(account.getPARTNERSHIPSTATUS()==null) {
				account.setPARTNERSHIPSTATUS(defualt);
			}
			if(account.getISDENIEDFLG()==null) {
				account.setISDENIEDFLG(defualt);
			}
			/** changes for Sales Force Integration -End */
		}

		if (party.getAddress().size() == 0) {
			AddressType address = new AddressType();
			party.getAddress().add(address);
		}

		for (int index = 0; index < party.getAddress().size(); index++) {
			AddressType address = party.getAddress().get(index);
			if (address.getADDRLN1() == null) {
				address.setADDRLN1(defualt);
			}
			if (address.getADDRLN2() == null) {
				address.setADDRLN2(defualt);
			}
			if (address.getADDRLN3() == null) {
				address.setADDRLN3(defualt);
			}
			if (address.getADDRLN4() == null) {
				address.setADDRLN4(defualt);
			}
			if (address.getADDRSTATUS() == null) {
				address.setADDRSTATUS(defualt);
			}
			if (address.getADDRTYPE() == null) {
				address.setADDRTYPE(defualt);
			}
			if (address.getCITY() == null) {
				address.setCITY(defualt);
			}
			if (address.getADDRLN1() == null) {
				address.setCOUNTRYCD(defualt);
			}
			if (address.getCOUNTY() == null) {
				address.setCOUNTY(defualt);
			}
			if (address.getDISTRICT() == null) {
				address.setDISTRICT(defualt);
			}
			if (address.getLANGCD() == null) {
				address.setLANGCD(defualt);
			}
			if (address.getLATITUDE() == null) {
				address.setLATITUDE(defualt);
			}
			if (address.getLONGITUDE() == null) {
				address.setLONGITUDE(defualt);
			}
			if (address.getPOSTALCD() == null) {
				address.setPOSTALCD(defualt);
			}
			if (address.getROWIDADDRESS() == null) {
				address.setROWIDADDRESS(defualt);
			}
			if (address.getROWIDADDRESS() == null) {
				address.setROWIDADDRESS(defualt);
			}
			if (address.getSTATECD() == null) {
				address.setSTATECD(defualt);
			}
		}

		if (party.getCommunication().size() == 0) {
			CommunicationType comm = new CommunicationType();
			party.getCommunication().add(comm);
		}

		for (int index = 0; index < party.getCommunication().size(); index++) {
			CommunicationType comm = party.getCommunication().get(index);

			if (comm.getCOMMSTATUS() == null) {
				comm.setCOMMSTATUS(defualt);
			}
			if (comm.getCOMMTYPE() == null) {
				comm.setCOMMTYPE(defualt);
			}
			if (comm.getCOMMVALUE() == null) {
				comm.setCOMMVALUE(defualt);
			}
			if (comm.getPRFRDCOMMIND() == null) {
				comm.setPRFRDCOMMIND(defualt);
			}
			if (comm.getROWIDCOMMUNICATION()== null) {
				comm.setROWIDCOMMUNICATION(defualt);
			}
			if (comm.getWEBDOMAIN() == null) {
				comm.setWEBDOMAIN(defualt);
			}
			if (comm.getCOMMEXTN()== null) {
				comm.setCOMMEXTN(defualt);
			}
			if (comm.getCOMMMKTGPREF() == null) {
				comm.setCOMMMKTGPREF(defualt);
			}
		}

		if (party.getClassification().size() == 0) {
			ClassificationType classif = new ClassificationType();
			party.getClassification().add(classif);
		}

		for (int index = 0; index < party.getClassification().size(); index++) {
			ClassificationType classif = party.getClassification().get(index);

			if (classif.getCLASSIFICTNTYPE() == null) {
				classif.setCLASSIFICTNTYPE(defualt);
			}
			if (classif.getCLASSIFICTNVALUE() == null) {
				classif.setCLASSIFICTNVALUE(defualt);
			}
			if (classif.getENDDATE() == null) {
				classif.setENDDATE(defualt);
			}
			if (classif.getROWIDCLASSIFICTN() == null) {
				classif.setROWIDCLASSIFICTN(defualt);
			}
			if (classif.getSTARTDATE() == null) {
				classif.setSTARTDATE(defualt);
			}
			if (classif.getCLASSIFICTNMETH() == null) {
				classif.setCLASSIFICTNMETH(defualt);
			}
		}


		if (party.getPartyOrgExt().size() == 0) {
			PartyOrgExtType orgExt = new PartyOrgExtType();
			party.getPartyOrgExt().add(orgExt);
		}

		for (int index = 0; index < party.getPartyOrgExt().size(); index++) {
			PartyOrgExtType partyOrgExt = party.getPartyOrgExt().get(index);
			
			if (partyOrgExt.getCURRENCYCD() == null) {
				partyOrgExt.setCURRENCYCD(defualt);
			}
			if (partyOrgExt.getFORTUNEINFO() == null) {
				partyOrgExt.setFORTUNEINFO(defualt);
			}
			if (partyOrgExt.getGLBLEMPLCNT() == null) {
				partyOrgExt.setGLBLEMPLCNT(defualt);
			}
			if (partyOrgExt.getGLBLULTIND() == null) {
				partyOrgExt.setGLBLULTIND(defualt);
			}
			if (partyOrgExt.getHIERARCHYLEVEL() == null) {
				partyOrgExt.setHIERARCHYLEVEL(defualt);
			}
			if (partyOrgExt.getLINEOFBUS() == null) {
				partyOrgExt.setLINEOFBUS(defualt);
			}
			if (partyOrgExt.getORGDOMULTDUNS() == null) {
				partyOrgExt.setORGDOMULTDUNS(defualt);
			}
			if (partyOrgExt.getORGDUNSNBR() == null) {
				partyOrgExt.setORGDUNSNBR(defualt);
			}
			if (partyOrgExt.getORGGLBULTDUNS() == null) {
				partyOrgExt.setORGGLBULTDUNS(defualt);
			}
			if (partyOrgExt.getORGHQPARENTDUNS() == null) {
				partyOrgExt.setORGHQPARENTDUNS(defualt);
			}
			if (partyOrgExt.getOUTOFBUSIND() == null) {
				partyOrgExt.setOUTOFBUSIND(defualt);
			}
			if (partyOrgExt.getPRIMSIC() == null) {
				partyOrgExt.setPRIMSIC(defualt);
			}
			if (partyOrgExt.getREVENUE() == null) {
				partyOrgExt.setREVENUE(defualt);
			}
			if (partyOrgExt.getROWIDORGEXTN() == null) {
				partyOrgExt.setROWIDORGEXTN(defualt);
			}
			if (partyOrgExt.getSALESAMOUNT() == null) {
				partyOrgExt.setSALESAMOUNT(defualt);
			}
			if (partyOrgExt.getSALESVOLUME() == null) {
				partyOrgExt.setSALESVOLUME(defualt);
			}
			if (partyOrgExt.getSECSIC() == null) {
				partyOrgExt.setSECSIC(defualt);
			}
			if (partyOrgExt.getSITEEMPLCNT() == null) {
				partyOrgExt.setSITEEMPLCNT(defualt);
			}
			if (partyOrgExt.getTRADENAME() == null) {
				partyOrgExt.setTRADENAME(defualt);
			}
			if (partyOrgExt.getTRADENAME2() == null) {
				partyOrgExt.setTRADENAME2(defualt);
			}
			if (partyOrgExt.getVERTICAL() == null) {
				partyOrgExt.setVERTICAL(defualt);
			}
			if (partyOrgExt.getGLBSALESREVNUOVRID() == null) {
				partyOrgExt.setGLBSALESREVNUOVRID(defualt);
			}
			if (partyOrgExt.getMFEGLBLPARENTNM() == null) {
				partyOrgExt.setMFEGLBLPARENTNM(defualt);
			}
			if (partyOrgExt.getMFEPARENTNM() == null) {
				partyOrgExt.setMFEPARENTNM(defualt);
			}
			if (partyOrgExt.getMFEWWPARENTNM() == null) {
				partyOrgExt.setMFEWWPARENTNM(defualt);
			}
			if (partyOrgExt.getMFESUBSDRYPARENTNM() == null) {
				partyOrgExt.setMFESUBSDRYPARENTNM(defualt);
			}
			if (partyOrgExt.getMFEPRTNRPARENTORG() == null) {
				partyOrgExt.setMFEPRTNRPARENTORG(defualt);
			}
			if (partyOrgExt.getMFEGLBLPARENTUCN() == null) {
				partyOrgExt.setMFEGLBLPARENTUCN(defualt);
			}
			if (partyOrgExt.getMFEGLOBALPARNMOVRIDE() == null) {
				partyOrgExt.setMFEGLOBALPARNMOVRIDE(defualt);
			}
			if (partyOrgExt.getSALESREVNUOVRID() == null) {
				partyOrgExt.setSALESREVNUOVRID(defualt);
			}
			if (partyOrgExt.getMFEEMPCNTOVERIDE() == null) {
				partyOrgExt.setMFEEMPCNTOVERIDE(defualt);
			}
			if (partyOrgExt.getSICCDOVRIDE() == null) {
				partyOrgExt.setSICCDOVRIDE(defualt);
			}
			if (partyOrgExt.getMFEWWPARENTPRTNNM() == null) {
				partyOrgExt.setMFEWWPARENTPRTNNM(defualt);
			}
			if (partyOrgExt.getMFESUBSDRYPARENTPRTNNM() == null) {
				partyOrgExt.setMFESUBSDRYPARENTPRTNNM(defualt);
			}
			if (partyOrgExt.getSICCDOVRIDEDESC() == null) {
				partyOrgExt.setSICCDOVRIDEDESC(defualt);
			}
			if (partyOrgExt.getMFESUBSPARENTUCN() == null) {
				partyOrgExt.setMFESUBSPARENTUCN(defualt);
			}
			if (partyOrgExt.getMFESUBSPARENTNMOVRIDE() == null) {
				partyOrgExt.setMFESUBSPARENTNMOVRIDE(defualt);
			}
			if (partyOrgExt.getSUBSIDIARYIND() == null) {
				partyOrgExt.setSUBSIDIARYIND(defualt);
			}
			if (partyOrgExt.getCUSTOMPARENTUCN() == null) {
				partyOrgExt.setCUSTOMPARENTUCN(defualt);
			}
			if (partyOrgExt.getCUSTOMPARENTNAME() == null) {
				partyOrgExt.setCUSTOMPARENTNAME(defualt);
			}
			if (partyOrgExt.getMFECOUNTRYULTUCN() == null) {
				partyOrgExt.setMFECOUNTRYULTUCN(defualt);
			}
			if (partyOrgExt.getCOUNTRYULTIND() == null) {
				partyOrgExt.setCOUNTRYULTIND(defualt);
			}
			if (partyOrgExt.getMFENEXTLVLSUBSPARUCN() == null) {
				partyOrgExt.setMFENEXTLVLSUBSPARUCN(defualt);
			}
			
			if (partyOrgExt.getMFENEXTLVLSUBSPARNM() == null) {
				partyOrgExt.setMFENEXTLVLSUBSPARNM(defualt);
			}
			if (partyOrgExt.getGLBFLG() == null) {
				partyOrgExt.setGLBFLG(defualt);
			}
			if (partyOrgExt.getCUSTFLG() == null) {
				partyOrgExt.setCUSTFLG(defualt);
			}
			if (partyOrgExt.getPARTNERFLG() == null) {
				partyOrgExt.setPARTNERFLG(defualt);
			}
			if (partyOrgExt.getACTIVETXNFLG() == null) {
				partyOrgExt.setACTIVETXNFLG(defualt);
			}
			if (partyOrgExt.getPARENTFLG() == null) {
				partyOrgExt.setPARENTFLG(defualt);
			}
			if (partyOrgExt.getGLBEMPCNTOVERRIDE() == null) {
				partyOrgExt.setGLBEMPCNTOVERRIDE(defualt);
			}
			if (partyOrgExt.getTXN5YRFLG() == null) {
				partyOrgExt.setTXN5YRFLG(defualt);
			}
			if (partyOrgExt.getTXN7YRFLG() == null) {
				partyOrgExt.setTXN7YRFLG(defualt);
			}
			if (partyOrgExt.getMFETXN5YRFLG() == null) {
				partyOrgExt.setMFETXN5YRFLG(defualt);
			}
			if (partyOrgExt.getMFETXN7YRFLG() == null) {
				partyOrgExt.setMFETXN7YRFLG(defualt);
			}
			if (partyOrgExt.getG2KFLG() == null) {
				partyOrgExt.setG2KFLG(defualt);
			}
			if (partyOrgExt.getMDMPARENTUCN() == null) {
				partyOrgExt.setMDMPARENTUCN(defualt);
			}
			if (partyOrgExt.getCUSTOMERPARENTFLAG() == null) {
				partyOrgExt.setCUSTOMERPARENTFLAG(defualt);
			}
			if (partyOrgExt.getPTRPARENTNM() == null) {
				partyOrgExt.setPTRPARENTNM(defualt);
			}
			if (partyOrgExt.getPTRPARENTUCN() == null) {
				partyOrgExt.setPTRPARENTUCN(defualt);
			}
			if (partyOrgExt.getPTRGLBLPARENTUCN() == null) {
				partyOrgExt.setPTRGLBLPARENTUCN(defualt);
			}
		}

		if (party.getPartyPersonExt().size() == 0) {
			PartyPersonExtType prsnExt = new PartyPersonExtType();
			party.getPartyPersonExt().add(prsnExt);
		}

		for (int index = 0; index < party.getPartyPersonExt().size(); index++) {
			PartyPersonExtType partyPrsnExt = party.getPartyPersonExt().get(index);

			if (partyPrsnExt.getFIRSTNAME() == null) {
				partyPrsnExt.setFIRSTNAME(defualt);
			}
			if (partyPrsnExt.getLASTNAME() == null) {
				partyPrsnExt.setLASTNAME(defualt);
			}
			if (partyPrsnExt.getMIDDLENAME() == null) {
				partyPrsnExt.setMIDDLENAME(defualt);
			}
			if (partyPrsnExt.getPERSONTYPE() == null) {
				partyPrsnExt.setPERSONTYPE(defualt);
			}
			if (partyPrsnExt.getPREFIX() == null) {
				partyPrsnExt.setPREFIX(defualt);
			}
			if (partyPrsnExt.getROWIDPRSNEXTN() == null) {
				partyPrsnExt.setROWIDPRSNEXTN(defualt);
			}
			if (partyPrsnExt.getSUFFIX() == null) {
				partyPrsnExt.setSUFFIX(defualt);
			}
		}
		
		/** Modified for M4M START */		
		PartyRelationshipType partyRel = party.getPartyRel();
		
		if(partyRel == null) {
			party.setPartyRel(new PartyRelationshipType());
			partyRel = party.getPartyRel();
		}
		
		if(CollectionUtils.isEmpty(partyRel.getPARTYACCOUNTREL())) {
			partyRel.getPARTYACCOUNTREL().add(new PartyAccountRelationshipType());
		}

		/*for (int index = 0; index < party.getPartyRelationship().size(); index++) {
			PartyRelationshipType partyRel = party.getPartyRelationship().get(index);*/
		//Change the structure for Track-2
		for(PartyAccountRelationshipType partyAccountRel:partyRel.getPARTYACCOUNTREL()) {			
			if(partyAccountRel != null) {

				if (partyAccountRel.getHIERARCHYTYPE() == null) {
					partyAccountRel.setHIERARCHYTYPE(defualt);
				}
				if (partyAccountRel.getMDMGLBPARENTUCN() == null) {
					partyAccountRel.setMDMGLBPARENTUCN(defualt);
				}
				if (partyAccountRel.getMDMPARENTUCN() == null) {
					partyAccountRel.setMDMPARENTUCN(defualt);
				}
				if (partyAccountRel.getMDMGLBPARENTNAME() == null) {
					partyAccountRel.setMDMGLBPARENTNAME(defualt);
				}
				if (partyAccountRel.getMDMPARENTNAME() == null) {
					partyAccountRel.setMDMPARENTNAME(defualt);
				}
				if (partyAccountRel.getSINGLESITEFLAG() == null) {
					partyAccountRel.setSINGLESITEFLAG(defualt);
				}
				if (partyAccountRel.getRELTYPE() == null) {
					partyAccountRel.setRELTYPE(defualt);
				}
			}
		}
		
		/** Modified for M4M END */
	}


	/**
	 * Sets default value to all the null attributes in Xref copy.
	 * This is to ensure that an attribute tag with null value be present in the published XML.
	 * @param partyXref
	 */
	public static void setDefaultValueInXrefAttributes(PartyXrefType partyXref) {
		String defualt = "";

		if (partyXref == null) {
			LOG.info("The provided golden object is null");
			return;
		}
		if (partyXref.getBOCLASSCODE() == null) {
			partyXref.setBOCLASSCODE(defualt);
		}
		if (partyXref.getErrorMsg() == null) {
			partyXref.setErrorMsg(defualt);
		}
		if (partyXref.getGEO() == null) {
			partyXref.setGEO(defualt);
		}
		if (partyXref.getPARTYNAME() == null) {
			partyXref.setPARTYNAME(defualt);
		}
		if (partyXref.getPARTYTYPE() == null) {
			partyXref.setPARTYTYPE(defualt);
		}
		if (partyXref.getREGION() == null) {
			partyXref.setREGION(defualt);
		} if (partyXref.getROWIDOBJECT() == null) {
			partyXref.setROWIDOBJECT(defualt);
		}
		if (partyXref.getSALESBLOCKCD() == null ) {
			partyXref.setSALESBLOCKCD(defualt);
		}
		if (partyXref.getSTATUSCD() == null) {
			partyXref.setSTATUSCD(defualt);
		}
		if (partyXref.getTAXJURSDCTNCD() == null) {
			partyXref.setTAXJURSDCTNCD(defualt);
		}
		if (partyXref.getUCN() == null) {
			partyXref.setUCN(defualt);
		}
		if (partyXref.getVATREGNBR() == null) {
			partyXref.setVATREGNBR(defualt);
		}

		for (int index = 0; index < partyXref.getXREF().size(); index++) {
			XREFType xref = partyXref.getXREF().get(index);
			if (xref.getSRCPKEY() == null) {
				xref.setSRCPKEY(defualt);
			}
			if (xref.getSRCSYSTEM() == null) {
				xref.setSRCSYSTEM(defualt);
			}
		}

		if (partyXref.getAccount().size() == 0) {
			AccountXrefType account = new AccountXrefType();
			partyXref.getAccount().add(account);
		}

		for (int index = 0; index < partyXref.getAccount().size(); index++) {
			AccountXrefType accountXref = partyXref.getAccount().get(index);

			if (accountXref.getACCOUNTGEO() == null) {
				accountXref.setACCOUNTGEO(defualt);
			}
			if (accountXref.getACCOUNTREGION() == null) {
				accountXref.setACCOUNTREGION(defualt);
			}
			if (accountXref.getACCOUNTTAXJURSDCTNCD() == null) {
				accountXref.setACCOUNTTAXJURSDCTNCD(defualt);
			}
			if (accountXref.getACCOUNTVATREGNBR() == null) {
				accountXref.setACCOUNTVATREGNBR(defualt);
			}
			if (accountXref.getACCTNAME() == null) {
				accountXref.setACCTNAME(defualt);
			}
			if (accountXref.getACCTSTATUS() == null) {
				accountXref.setACCTSTATUS(defualt);
			}
			if (accountXref.getACCTTYPE() == null) {
				accountXref.setACCTTYPE(defualt);
			}
			if (accountXref.getALIASNAME() == null) {
				accountXref.setALIASNAME(defualt);
			}
			if (accountXref.getBILLBLOCKCD() == null) {
				accountXref.setBILLBLOCKCD(defualt);
			}
			if (accountXref.getCHANNELID() == null) {
				accountXref.setCHANNELID(defualt);
			}
			if (accountXref.getCOMPANYCD() == null) {
				accountXref.setCOMPANYCD(defualt);
			}
			if (accountXref.getCUSTGROUP() == null) {
				accountXref.setCUSTGROUP(defualt);
			}
			if (accountXref.getDIRECTIND() == null) {
				accountXref.setDIRECTIND(defualt);
			}
			if (accountXref.getDLVRYBLOCKCD() == null) {
				accountXref.setDLVRYBLOCKCD(defualt);
			}
			if (accountXref.getMARKET() == null) {
				accountXref.setMARKET(defualt);
			}
			if (accountXref.getMDMLEGACYID() == null) {
				accountXref.setMDMLEGACYID(defualt);
			}
			if (accountXref.getNAMEDACCTIND() == null) {
				accountXref.setNAMEDACCTIND(defualt);
			}
			if (accountXref.getNONVALACCTIND() == null) {
				accountXref.setNONVALACCTIND(defualt);
			}
			if (accountXref.getORDRBLOCKCD() == null) {
				accountXref.setORDRBLOCKCD(defualt);
			}
			if (accountXref.getPARTNERIND() == null) {
				accountXref.setPARTNERIND(defualt);
			}
			if (accountXref.getPARTNERTYPE() == null) {
				accountXref.setPARTNERTYPE(defualt);
			}
			if (accountXref.getPOSTBLOCKCD() == null) {
				accountXref.setPOSTBLOCKCD(defualt);
			}
			if (accountXref.getPRICEGROUP() == null) {
				accountXref.setPRICEGROUP(defualt);
			}
			if (accountXref.getROWIDACCOUNT() == null) {
				accountXref.setROWIDACCOUNT(defualt);
			}
			if (accountXref.getSALEBLOCKCD() == null) {
				accountXref.setSALEBLOCKCD(defualt);
			}
			if (accountXref.getSAPCUSTNUMBER() == null) {
				accountXref.setSAPCUSTNUMBER(defualt);
			}
			if (accountXref.getSIEBELROWID() == null) {
				accountXref.setSIEBELROWID(defualt);
			}
			if (accountXref.getSRCPKEY() == null) {
				accountXref.setSRCPKEY(defualt);
			}
			if (accountXref.getSRCSYSTEM() == null) {
				accountXref.setSRCSYSTEM(defualt);
			}
			if (accountXref.getTAXTYPE() == null) {
				accountXref.setTAXTYPE(defualt);
			}
			if (accountXref.getVENDORNBR() == null) {
				accountXref.setVENDORNBR(defualt);
			}
			
			/** Modified for SFDC START */
			if(accountXref.getSalesForceID()==null) {
				accountXref.setSalesForceID(defualt);
			}
			if(accountXref.getDraftAccountFlag()==null) {
				accountXref.setDraftAccountFlag(defualt);
			}
			/** Modified for SFDC END */
			/** changes for Sales Force Integration -Start */
			if(accountXref.getLOCALNAME()==null) {
				accountXref.setLOCALNAME(defualt);
			}
			if(accountXref.getCURRENCYCD()==null) {
				accountXref.setCURRENCYCD(defualt);
			}
			if(accountXref.getTAXID()==null) {
				accountXref.setTAXID(defualt);
			}
			if(accountXref.getPRICEBANDAGGREMENT()==null) {
				accountXref.setPRICEBANDAGGREMENT(defualt);
			}
			if(accountXref.getSITEDESIGNATION()==null) {
				accountXref.setSITEDESIGNATION(defualt);
			}
			if(accountXref.getRESELLLEVEL()==null) {
				accountXref.setRESELLLEVEL(defualt);
			}
			if(accountXref.getPARTNERSHIPSTATUS()==null) {
				accountXref.setPARTNERSHIPSTATUS(defualt);
			}
			if(accountXref.getISDENIEDFLG()==null) {
				accountXref.setISDENIEDFLG(defualt);
			}
			/** changes for Sales Force Integration -End */
		}

		if (partyXref.getAddress().size() == 0) {
			AddressXrefType address = new AddressXrefType();
			partyXref.getAddress().add(address);
		}

		for (int index = 0; index < partyXref.getAddress().size(); index++) {
			AddressXrefType addressXref = partyXref.getAddress().get(index);
			if (addressXref.getADDRLN1() == null) {
				addressXref.setADDRLN1(defualt);
			}
			if (addressXref.getADDRLN2() == null) {
				addressXref.setADDRLN2(defualt);
			}
			if (addressXref.getADDRLN3() == null) {
				addressXref.setADDRLN3(defualt);
			}
			if (addressXref.getADDRLN4() == null) {
				addressXref.setADDRLN4(defualt);
			}
			if (addressXref.getADDRSTATUS() == null) {
				addressXref.setADDRSTATUS(defualt);
			}
			if (addressXref.getADDRTYPE() == null) {
				addressXref.setADDRTYPE(defualt);
			}
			if (addressXref.getCITY() == null) {
				addressXref.setCITY(defualt);
			}
			if (addressXref.getADDRLN1() == null) {
				addressXref.setCOUNTRYCD(defualt);
			}
			if (addressXref.getCOUNTY() == null) {
				addressXref.setCOUNTY(defualt);
			}
			if (addressXref.getDISTRICT() == null) {
				addressXref.setDISTRICT(defualt);
			}
			if (addressXref.getLANGCD() == null) {
				addressXref.setLANGCD(defualt);
			}
			if (addressXref.getLATITUDE() == null) {
				addressXref.setLATITUDE(defualt);
			}
			if (addressXref.getLONGITUDE() == null) {
				addressXref.setLONGITUDE(defualt);
			}
			if (addressXref.getPOSTALCD() == null) {
				addressXref.setPOSTALCD(defualt);
			}
			if (addressXref.getROWIDADDRESS() == null) {
				addressXref.setROWIDADDRESS(defualt);
			}
			if (addressXref.getROWIDADDRESSXREF() == null) {
				addressXref.setROWIDADDRESSXREF(defualt);
			}
			if (addressXref.getSRCPKEY() == null) {
				addressXref.setSRCPKEY(defualt);
			}
			if (addressXref.getSRCSYSTEM() == null) {
				addressXref.setSRCSYSTEM(defualt);
			}
			if (addressXref.getSTATECD() == null) {
				addressXref.setSTATECD(defualt);
			}
		}

		if (partyXref.getCommunication().size() == 0) {
			CommunicationXrefType comm = new CommunicationXrefType();
			partyXref.getCommunication().add(comm);
		}

		for (int index = 0; index < partyXref.getCommunication().size(); index++) {
			CommunicationXrefType commXref = partyXref.getCommunication().get(index);

			if (commXref.getCOMMSTATUS() == null) {
				commXref.setCOMMSTATUS(defualt);
			}
			if (commXref.getCOMMTYPE() == null) {
				commXref.setCOMMTYPE(defualt);
			}
			if (commXref.getCOMMVALUE() == null) {
				commXref.setCOMMVALUE(defualt);
			}
			if (commXref.getPRFRDCOMMIND() == null) {
				commXref.setPRFRDCOMMIND(defualt);
			}
			if (commXref.getROWIDCOMMUNICATION()== null) {
				commXref.setROWIDCOMMUNICATION(defualt);
			}
			if (commXref.getSRCPKEY() == null) {
				commXref.setSRCPKEY(defualt);
			}
			if (commXref.getSRCSYSTEM() == null) {
				commXref.setSRCSYSTEM(defualt);
			}
			if (commXref.getWEBDOMAIN() == null) {
				commXref.setWEBDOMAIN(defualt);
			}
			if (commXref.getCOMMEXTN()== null) {
				commXref.setCOMMEXTN(defualt);
			}
			if (commXref.getCOMMMKTGPREF() == null) {
				commXref.setCOMMMKTGPREF(defualt);
			}
		}

		if (partyXref.getClassification().size() == 0) {
			ClassificationXrefType classif = new ClassificationXrefType();
			partyXref.getClassification().add(classif);
		}

		for (int index = 0; index < partyXref.getClassification().size(); index++) {
			ClassificationXrefType classifXref = partyXref.getClassification().get(index);

			if (classifXref.getCLASSIFICTNTYPE() == null) {
				classifXref.setCLASSIFICTNTYPE(defualt);
			}
			if (classifXref.getCLASSIFICTNVALUE() == null) {
				classifXref.setCLASSIFICTNVALUE(defualt);
			}
			if (classifXref.getCLASSIFICTNMETH() == null) {
				classifXref.setCLASSIFICTNMETH(defualt);
			}
			if (classifXref.getENDDATE() == null) {
				classifXref.setENDDATE(defualt);
			}
			if (classifXref.getROWIDCLASSIFICTN() == null) {
				classifXref.setROWIDCLASSIFICTN(defualt);
			}
			if (classifXref.getSRCPKEY() == null) {
				classifXref.setSRCPKEY(defualt);
			}
			if (classifXref.getSRCSYSTEM() == null) {
				classifXref.setSRCSYSTEM(defualt);
			}
			if (classifXref.getSTARTDATE() == null) {
				classifXref.setSTARTDATE(defualt);
			}
		}

		if (partyXref.getPartyOrgExt().size() == 0) {
			PartyOrgExtXrefType orgExt = new PartyOrgExtXrefType();
			partyXref.getPartyOrgExt().add(orgExt);
		}

		for (int index = 0; index < partyXref.getPartyOrgExt().size(); index++) {
			PartyOrgExtXrefType partyOrgExtXref = partyXref.getPartyOrgExt().get(index);

			if (partyOrgExtXref.getCURRENCYCD() == null) {
				partyOrgExtXref.setCURRENCYCD(defualt);
			}
			if (partyOrgExtXref.getFORTUNEINFO() == null) {
				partyOrgExtXref.setFORTUNEINFO(defualt);
			}
			if (partyOrgExtXref.getGLBLEMPLCNT() == null) {
				partyOrgExtXref.setGLBLEMPLCNT(defualt);
			}
			if (partyOrgExtXref.getGLBLULTIND() == null) {
				partyOrgExtXref.setGLBLULTIND(defualt);
			}
			if (partyOrgExtXref.getHIERARCHYLEVEL() == null) {
				partyOrgExtXref.setHIERARCHYLEVEL(defualt);
			}
			if (partyOrgExtXref.getLINEOFBUS() == null) {
				partyOrgExtXref.setLINEOFBUS(defualt);
			}
			if (partyOrgExtXref.getORGDOMULTDUNS() == null) {
				partyOrgExtXref.setORGDOMULTDUNS(defualt);
			}
			if (partyOrgExtXref.getORGDUNSNBR() == null) {
				partyOrgExtXref.setORGDUNSNBR(defualt);
			}
			if (partyOrgExtXref.getORGGLBULTDUNS() == null) {
				partyOrgExtXref.setORGGLBULTDUNS(defualt);
			}
			if (partyOrgExtXref.getORGHQPARENTDUNS() == null) {
				partyOrgExtXref.setORGHQPARENTDUNS(defualt);
			}
			if (partyOrgExtXref.getOUTOFBUSIND() == null) {
				partyOrgExtXref.setOUTOFBUSIND(defualt);
			}
			if (partyOrgExtXref.getPRIMSIC() == null) {
				partyOrgExtXref.setPRIMSIC(defualt);
			}
			if (partyOrgExtXref.getREVENUE() == null) {
				partyOrgExtXref.setREVENUE(defualt);
			}
			if (partyOrgExtXref.getROWIDORGEXTN() == null) {
				partyOrgExtXref.setROWIDORGEXTN(defualt);
			}
			if (partyOrgExtXref.getSALESAMOUNT() == null) {
				partyOrgExtXref.setSALESAMOUNT(defualt);
			}
			if (partyOrgExtXref.getSALESVOLUME() == null) {
				partyOrgExtXref.setSALESVOLUME(defualt);
			}
			if (partyOrgExtXref.getSECSIC() == null) {
				partyOrgExtXref.setSECSIC(defualt);
			}
			if (partyOrgExtXref.getSITEEMPLCNT() == null) {
				partyOrgExtXref.setSITEEMPLCNT(defualt);
			}
			if (partyOrgExtXref.getSRCPKEY() == null) {
				partyOrgExtXref.setSRCPKEY(defualt);
			}
			if (partyOrgExtXref.getSRCSYSTEM() == null) {
				partyOrgExtXref.setSRCSYSTEM(defualt);
			}
			if (partyOrgExtXref.getTRADENAME() == null) {
				partyOrgExtXref.setTRADENAME(defualt);
			}
			if (partyOrgExtXref.getTRADENAME2() == null) {
				partyOrgExtXref.setTRADENAME2(defualt);
			}
			if (partyOrgExtXref.getVERTICAL() == null) {
				partyOrgExtXref.setVERTICAL(defualt);
			}
			if (partyOrgExtXref.getGLBSALESREVNUOVRID() == null) {
				partyOrgExtXref.setGLBSALESREVNUOVRID(defualt);
			}
			if (partyOrgExtXref.getMFEGLBLPARENTNM() == null) {
				partyOrgExtXref.setMFEGLBLPARENTNM(defualt);
			}
			if (partyOrgExtXref.getMFEPARENTNM() == null) {
				partyOrgExtXref.setMFEPARENTNM(defualt);
			}
			if (partyOrgExtXref.getMFEWWPARENTNM() == null) {
				partyOrgExtXref.setMFEWWPARENTNM(defualt);
			}
			if (partyOrgExtXref.getMFESUBSDRYPARENTNM() == null) {
				partyOrgExtXref.setMFESUBSDRYPARENTNM(defualt);
			}
			if (partyOrgExtXref.getMFEPRTNRPARENTORG() == null) {
				partyOrgExtXref.setMFEPRTNRPARENTORG(defualt);
			}
			if (partyOrgExtXref.getMFEGLBLPARENTUCN() == null) {
				partyOrgExtXref.setMFEGLBLPARENTUCN(defualt);
			}
			if (partyOrgExtXref.getMFEGLOBALPARNMOVRIDE() == null) {
				partyOrgExtXref.setMFEGLOBALPARNMOVRIDE(defualt);
			}
			if (partyOrgExtXref.getSALESREVNUOVRID() == null) {
				partyOrgExtXref.setSALESREVNUOVRID(defualt);
			}
			if (partyOrgExtXref.getMFEEMPCNTOVERIDE() == null) {
				partyOrgExtXref.setMFEEMPCNTOVERIDE(defualt);
			}
			if (partyOrgExtXref.getSICCDOVRIDE() == null) {
				partyOrgExtXref.setSICCDOVRIDE(defualt);
			}
			if (partyOrgExtXref.getMFEWWPARENTPRTNNM() == null) {
				partyOrgExtXref.setMFEWWPARENTPRTNNM(defualt);
			}
			if (partyOrgExtXref.getMFESUBSDRYPARENTPRTNNM() == null) {
				partyOrgExtXref.setMFESUBSDRYPARENTPRTNNM(defualt);
			}
			if (partyOrgExtXref.getSICCDOVRIDEDESC() == null) {
				partyOrgExtXref.setSICCDOVRIDEDESC(defualt);
			}
			if (partyOrgExtXref.getMFESUBSPARENTUCN() == null) {
				partyOrgExtXref.setMFESUBSPARENTUCN(defualt);
			}
			if (partyOrgExtXref.getMFESUBSPARENTNMOVRIDE() == null) {
				partyOrgExtXref.setMFESUBSPARENTNMOVRIDE(defualt);
			}
			if (partyOrgExtXref.getSUBSIDIARYIND() == null) {
				partyOrgExtXref.setSUBSIDIARYIND(defualt);
			}
			if (partyOrgExtXref.getCUSTOMPARENTUCN() == null) {
				partyOrgExtXref.setCUSTOMPARENTUCN(defualt);
			}
			if (partyOrgExtXref.getCUSTOMPARENTNAME() == null) {
				partyOrgExtXref.setCUSTOMPARENTNAME(defualt);
			}
			if (partyOrgExtXref.getMFECOUNTRYULTUCN() == null) {
				partyOrgExtXref.setMFECOUNTRYULTUCN(defualt);
			}
			if (partyOrgExtXref.getCOUNTRYULTIND() == null) {
				partyOrgExtXref.setCOUNTRYULTIND(defualt);
			}
			if (partyOrgExtXref.getMFENEXTLVLSUBSPARUCN() == null) {
				partyOrgExtXref.setMFENEXTLVLSUBSPARUCN(defualt);
			}
			
			if (partyOrgExtXref.getMFENEXTLVLSUBSPARNM() == null) {
				partyOrgExtXref.setMFENEXTLVLSUBSPARNM(defualt);
			}
			if (partyOrgExtXref.getGLBFLG() == null) {
				partyOrgExtXref.setGLBFLG(defualt);
			}
			if (partyOrgExtXref.getCUSTFLG() == null) {
				partyOrgExtXref.setCUSTFLG(defualt);
			}
			if (partyOrgExtXref.getPARTNERFLG() == null) {
				partyOrgExtXref.setPARTNERFLG(defualt);
			}
			if (partyOrgExtXref.getACTIVETXNFLG() == null) {
				partyOrgExtXref.setACTIVETXNFLG(defualt);
			}
			if (partyOrgExtXref.getPARENTFLG() == null) {
				partyOrgExtXref.setPARENTFLG(defualt);
			}
			if (partyOrgExtXref.getGLBEMPCNTOVERRIDE() == null) {
				partyOrgExtXref.setGLBEMPCNTOVERRIDE(defualt);
			}
			if (partyOrgExtXref.getTXN5YRFLG() == null) {
				partyOrgExtXref.setTXN5YRFLG(defualt);
			}
			if (partyOrgExtXref.getTXN7YRFLG() == null) {
				partyOrgExtXref.setTXN7YRFLG(defualt);
			}
			if (partyOrgExtXref.getMFETXN5YRFLG() == null) {
				partyOrgExtXref.setMFETXN5YRFLG(defualt);
			}
			if (partyOrgExtXref.getMFETXN7YRFLG() == null) {
				partyOrgExtXref.setMFETXN7YRFLG(defualt);
			}
			if (partyOrgExtXref.getG2KFLG() == null) {
				partyOrgExtXref.setG2KFLG(defualt);
			}
			if (partyOrgExtXref.getMDMPARENTUCN() == null) {
				partyOrgExtXref.setMDMPARENTUCN(defualt);
			}
			if (partyOrgExtXref.getCUSTOMERPARENTFLAG() == null) {
				partyOrgExtXref.setCUSTOMERPARENTFLAG(defualt);
			}
			if (partyOrgExtXref.getPTRPARENTNM() == null) {
				partyOrgExtXref.setPTRPARENTNM(defualt);
			}
			if (partyOrgExtXref.getPTRPARENTUCN() == null) {
				partyOrgExtXref.setPTRPARENTUCN(defualt);
			}
			if (partyOrgExtXref.getPTRGLBLPARENTUCN() == null) {
				partyOrgExtXref.setPTRGLBLPARENTUCN(defualt);
			}
			if (partyOrgExtXref.getMFEWWPARENTPRTNNM() == null) {
				partyOrgExtXref.setMFEWWPARENTPRTNNM(defualt);
			}
			if (partyOrgExtXref.getMFEGLBLPARENTUCN() == null) {
				partyOrgExtXref.setMFEGLBLPARENTUCN(defualt);
			}
		}

		if (partyXref.getPartyPersonExt().size() == 0) {
			PartyPersonExtXrefType prsnExt = new PartyPersonExtXrefType();
			partyXref.getPartyPersonExt().add(prsnExt);
		}

		for (int index = 0; index < partyXref.getPartyPersonExt().size(); index++) {
			PartyPersonExtXrefType partyPrsnExtXref = partyXref.getPartyPersonExt().get(index);

			if (partyPrsnExtXref.getFIRSTNAME() == null) {
				partyPrsnExtXref.setFIRSTNAME(defualt);
			}
			if (partyPrsnExtXref.getLASTNAME() == null) {
				partyPrsnExtXref.setLASTNAME(defualt);
			}
			if (partyPrsnExtXref.getMIDDLENAME() == null) {
				partyPrsnExtXref.setMIDDLENAME(defualt);
			}
			if (partyPrsnExtXref.getPERSONTYPE() == null) {
				partyPrsnExtXref.setPERSONTYPE(defualt);
			}
			if (partyPrsnExtXref.getPREFIX() == null) {
				partyPrsnExtXref.setPREFIX(defualt);
			}
			if (partyPrsnExtXref.getROWIDPRSNEXTN() == null) {
				partyPrsnExtXref.setROWIDPRSNEXTN(defualt);
			}
			if (partyPrsnExtXref.getSRCPKEY() == null) {
				partyPrsnExtXref.setSRCPKEY(defualt);
			}
			if (partyPrsnExtXref.getSRCSYSTEM() == null) {
				partyPrsnExtXref.setSRCSYSTEM(defualt);
			}
			if (partyPrsnExtXref.getSUFFIX() == null) {
				partyPrsnExtXref.setSUFFIX(defualt);
			}
		}
		
		/** Modified for M4M START */
		
		PartyRelationshipXrefType partyRel = partyXref.getPartyRel();
		
//		LOG.info("Party Rel::" + partyRel);
		
		if(partyRel == null) {
			partyXref.setPartyRel(new PartyRelationshipXrefType());
			partyRel = partyXref.getPartyRel();
		}

		//if (partyXref.getPartyRelationship().size() == 0) {
		if (CollectionUtils.isEmpty(partyRel.getPARTYACCOUNTREL())) {
			LOG.info("Party Account Rel EMPTY");
			partyRel.getPARTYACCOUNTREL().add(new PartyAccountRelationshipXrefType());
		}

		/*for (int index = 0; index < partyXref.getPartyRelationship().size(); index++) {
			PartyRelationshipXrefType partyRelXref = partyXref.getPartyRelationship().get(index);*/
		//structure change for Track-2
		for(PartyAccountRelationshipXrefType partyAccountRelXref:partyRel.getPARTYACCOUNTREL()) {			
		//	LOG.info("Party Account Rel::" + partyAccountRelXref);

			if (partyAccountRelXref.getHIERARCHYTYPE() == null) {
				partyAccountRelXref.setHIERARCHYTYPE(defualt);
			}
			if (partyAccountRelXref.getMDMGLBPARENTUCN() == null) {
				partyAccountRelXref.setMDMGLBPARENTUCN(defualt);
			}
			if (partyAccountRelXref.getMDMPARENTUCN() == null) {
				partyAccountRelXref.setMDMPARENTUCN(defualt);
			}
			if (partyAccountRelXref.getMDMGLBPARENTNAME() == null) {
				partyAccountRelXref.setMDMGLBPARENTNAME(defualt);
			}
			if (partyAccountRelXref.getMDMPARENTNAME() == null) {
				partyAccountRelXref.setMDMPARENTNAME(defualt);
			}
			if (partyAccountRelXref.getSINGLESITEFLAG() == null) {
				partyAccountRelXref.setSINGLESITEFLAG(defualt);
			}
			if (partyAccountRelXref.getRELTYPE() == null) {
				partyAccountRelXref.setRELTYPE(defualt);
			}
			if (partyAccountRelXref.getSRCPKEY() == null) {
				partyAccountRelXref.setSRCPKEY(defualt);
			}
			if (partyAccountRelXref.getSRCSYSTEM() == null) {
				partyAccountRelXref.setSRCSYSTEM(defualt);
			}
		}
		
		/** Modified for M4M END */
	}
}
