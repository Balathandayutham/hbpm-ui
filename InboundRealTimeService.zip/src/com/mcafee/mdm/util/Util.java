package com.mcafee.mdm.util;

import java.io.StringWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.TimeZone;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.log4j.Logger;

import com.mcafee.mdm.constants.Constant;
import com.mcafee.mdm.dao.UpsertPartyDAO;
import com.mcafee.mdm.exception.ServiceProcessingException;
import com.mcafee.mdm.generated.ContactSearchCriteriaType;
import com.mcafee.mdm.generated.PartySearchCriteriaType;
import com.mcafee.mdm.generated.PartyXrefType;
import com.mcafee.mdm.generated.SearchContactRequest;
import com.mcafee.mdm.generated.SearchContactResponse;
import com.mcafee.mdm.generated.SearchPartyHierarchyRequest;
import com.mcafee.mdm.generated.SearchPartyRequest;
import com.mcafee.mdm.generated.SearchPartyResponse;
import com.mcafee.mdm.generated.UpsertPartyRequest;
import com.mcafee.mdm.generated.UpsertPartyResponse;

public class Util {
	private static final Logger LOG = Logger.getLogger(UpsertPartyDAO.class.getName());
//	CreateAccountMasterResponse createAccountMasterResponse = new CreateAccountMasterResponse();

	public static boolean searchRequestValidation(SearchPartyRequest searchPartyRequest) throws ServiceProcessingException {

		PartySearchCriteriaType partyParam = searchPartyRequest.getPartySearchCriteria();
		SearchPartyResponse searchPartyResponse = new SearchPartyResponse();
		boolean reqParamValid = true;

		if (partyParam == null) {
			reqParamValid = false;
			throw new ServiceProcessingException(Constant.bothAccntIndvCantbeNull);
		}
		if (partyParam != null) {
			LOG.debug("if partyParam is not null ");

			if (isNullOrEmpty(partyParam.getPARTYNAME()) || isNullOrEmpty(partyParam.getADDRLN1())) {

				LOG.debug("PARTY NAME " + partyParam.getPARTYNAME());
				LOG.debug("Address_LN1 " + partyParam.getADDRLN1());
				LOG.debug("Either PARTY NAME or Address_LN1 is NULL.");

				if(isNullOrEmpty(partyParam.getPARTYNAME()))	{

					reqParamValid = false;
					searchPartyResponse.setErrorMsg(searchPartyResponse.getErrorMsg() == null ? "":"\n");
					searchPartyResponse.setErrorMsg(searchPartyResponse.getErrorMsg() + Constant.partynameCantbeNull);
				//	throw new ServiceProcessingException(Constant.partynameCantbeNull);

				} else if (isNullOrEmpty(partyParam.getADDRLN1()))	{

					reqParamValid = false;
					searchPartyResponse.setErrorMsg(searchPartyResponse.getErrorMsg() == null ? "":"\n");
					searchPartyResponse.setErrorMsg(searchPartyResponse.getErrorMsg() + Constant.addrLine1CantbeNull);
				//	throw new ServiceProcessingException(Constant.addrLine1CantbeNull);
				}
		//		throw new SearchFault(Constant.allSearchParameterNull);
			}
		}
		return reqParamValid;
	}
	public static boolean searchRequestValidation(SearchPartyHierarchyRequest searchPartyRequest) throws ServiceProcessingException {

		PartySearchCriteriaType partyParam = searchPartyRequest.getPartySearchCriteria();
		SearchPartyResponse searchPartyResponse = new SearchPartyResponse();
		boolean reqParamValid = true;

		if (partyParam == null) {
			reqParamValid = false;
			throw new ServiceProcessingException(Constant.bothAccntIndvCantbeNull);
		}
		if (partyParam != null) {
			LOG.debug("if partyParam is not null ");

			if (isNullOrEmpty(partyParam.getPARTYNAME()) || isNullOrEmpty(partyParam.getADDRLN1())) {

				LOG.debug("PARTY NAME " + partyParam.getPARTYNAME());
				LOG.debug("Address_LN1 " + partyParam.getADDRLN1());
				LOG.debug("Either PARTY NAME or Address_LN1 is NULL.");

				if(isNullOrEmpty(partyParam.getPARTYNAME()))	{

					reqParamValid = false;
					searchPartyResponse.setErrorMsg(searchPartyResponse.getErrorMsg() == null ? "":"\n");
					searchPartyResponse.setErrorMsg(searchPartyResponse.getErrorMsg() + Constant.partynameCantbeNull);
				//	throw new ServiceProcessingException(Constant.partynameCantbeNull);

				} else if (isNullOrEmpty(partyParam.getADDRLN1()))	{

					reqParamValid = false;
					searchPartyResponse.setErrorMsg(searchPartyResponse.getErrorMsg() == null ? "":"\n");
					searchPartyResponse.setErrorMsg(searchPartyResponse.getErrorMsg() + Constant.addrLine1CantbeNull);
				//	throw new ServiceProcessingException(Constant.addrLine1CantbeNull);
				}
			} else if (isNullOrEmpty(partyParam.getUCN()))	{

				reqParamValid = false;
				searchPartyResponse.setErrorMsg(searchPartyResponse.getErrorMsg() == null ? "":"\n");
				searchPartyResponse.setErrorMsg(searchPartyResponse.getErrorMsg() + Constant.ucnCantbeNull);
			//	throw new ServiceProcessingException(Constant.addrLine1CantbeNull);
			}
		//		throw new SearchFault(Constant.allSearchParameterNull);
			
		}
		return reqParamValid;
	}
	public static boolean upsertRequestValidation(UpsertPartyRequest upsertPartyRequest) throws ServiceProcessingException {

		LOG.info("Inside upsertRequestValidation()");
		List<PartyXrefType> partyParamList = upsertPartyRequest.getParty();
		boolean reqParamValid = true;
		for (int index = 0; index < partyParamList.size(); index++) {

			PartyXrefType partyParam = partyParamList.get(index);
			UpsertPartyResponse upsertPartyResponse = new UpsertPartyResponse();

			if (partyParam == null) {
				reqParamValid = false;
				LOG.info(Constant.partyCantBeEmpty);
			//	throw new ServiceProcessingException(Constant.partyCantBeEmpty);

			} else {
				//Party Mandatory Fields
				if (isNullOrEmpty(partyParam.getBOCLASSCODE())) {
					reqParamValid = false;
					upsertPartyResponse.setErrorMsg(upsertPartyResponse.getErrorMsg() == null ? "":"\n");
					upsertPartyResponse.setErrorMsg(upsertPartyResponse.getErrorMsg() + Constant.boClassCode);
					LOG.info(Constant.boClassCode);
				//	throw new ServiceProcessingException(Constant.boClassCode);
				}
				 if (isNullOrEmpty(partyParam.getPARTYTYPE())) {
					 reqParamValid = false;
					upsertPartyResponse.setErrorMsg(upsertPartyResponse.getErrorMsg() == null ? "":"\n");
					upsertPartyResponse.setErrorMsg(upsertPartyResponse.getErrorMsg() + Constant.partyType);
					LOG.info(Constant.partyType);
				//	throw new ServiceProcessingException(Constant.partyType);
				}
				if (isNullOrEmpty(partyParam.getSTATUSCD())) {
					reqParamValid = false;
					upsertPartyResponse.setErrorMsg(upsertPartyResponse.getErrorMsg() == null ? "":"\n");
					upsertPartyResponse.setErrorMsg(upsertPartyResponse.getErrorMsg() + Constant.statusCode);
					LOG.info(Constant.statusCode);
				//	throw new ServiceProcessingException(Constant.statusCode);
				}
				if (isNullOrEmpty(partyParam.getXREF().get(0).getSRCPKEY())) {
					reqParamValid = false;
					upsertPartyResponse.setErrorMsg(upsertPartyResponse.getErrorMsg() == null ? "":"\n");
					upsertPartyResponse.setErrorMsg(upsertPartyResponse.getErrorMsg() + Constant.srcPkey);
					LOG.info(Constant.srcPkey);
				//	throw new ServiceProcessingException(Constant.srcPkey);
				}
				if (isNullOrEmpty(partyParam.getXREF().get(0).getSRCSYSTEM())) {
					reqParamValid = false;
					upsertPartyResponse.setErrorMsg(upsertPartyResponse.getErrorMsg() == null ? "":"\n");
					upsertPartyResponse.setErrorMsg(upsertPartyResponse.getErrorMsg() + Constant.srcSYS);
					LOG.info(Constant.srcSYS);
				//	throw new ServiceProcessingException(Constant.srcSYS);
				}
				//Account Mandatory Fields
				if (partyParam.getAccount() == null || partyParam.getAccount().size() == 0) {
					reqParamValid = false;
					upsertPartyResponse.setErrorMsg(upsertPartyResponse.getErrorMsg() == null ? "":"\n");
					upsertPartyResponse.setErrorMsg(upsertPartyResponse.getErrorMsg() + Constant.accountCantBeEmpty);
				//	throw new ServiceProcessingException(Constant.accountCantBeEmpty);
				}
				if(isNullOrEmpty(partyParam.getAccount().get(0).getACCTTYPE()))	{
					reqParamValid = false;
					upsertPartyResponse.setErrorMsg(upsertPartyResponse.getErrorMsg() == null ? "":"\n");
					upsertPartyResponse.setErrorMsg(upsertPartyResponse.getErrorMsg() + Constant.accountTypeCantbeEmpty);
				//	throw new ServiceProcessingException(Constant.accountTypeCantbeEmpty);
				}
				if(isNullOrEmpty(partyParam.getAccount().get(0).getACCTSTATUS()))	{
					reqParamValid = false;
					upsertPartyResponse.setErrorMsg(upsertPartyResponse.getErrorMsg() == null ? "":"\n");
					upsertPartyResponse.setErrorMsg(upsertPartyResponse.getErrorMsg() + Constant.accountStatusCantbeEmpty);
				//	throw new ServiceProcessingException(Constant.accountStatusCantbeEmpty);
				}

				//Address Mandatory Fields
				if (partyParam.getAddress() != null && partyParam.getAddress().size() > 0) {

					if(isNullOrEmpty(partyParam.getAddress().get(0).getADDRTYPE()))	{
						reqParamValid = false;
						upsertPartyResponse.setErrorMsg(upsertPartyResponse.getErrorMsg() == null ? "":"\n");
						upsertPartyResponse.setErrorMsg(upsertPartyResponse.getErrorMsg() + Constant.addressTypeCantBeEmpty);
					//	throw new ServiceProcessingException(Constant.addressTypeCantBeEmpty);
					}
					if(isNullOrEmpty(partyParam.getAddress().get(0).getADDRSTATUS()))	{
						reqParamValid = false;
						upsertPartyResponse.setErrorMsg(upsertPartyResponse.getErrorMsg() == null ? "":"\n");
						upsertPartyResponse.setErrorMsg(upsertPartyResponse.getErrorMsg() + Constant.addressStatusCantBeEmpty);
					//	throw new ServiceProcessingException(Constant.addressStatusCantBeEmpty);
					}
					if(isNullOrEmpty(partyParam.getAddress().get(0).getSRCPKEY()))	{
						reqParamValid = false;
						upsertPartyResponse.setErrorMsg(upsertPartyResponse.getErrorMsg() == null ? "":"\n");
						upsertPartyResponse.setErrorMsg(upsertPartyResponse.getErrorMsg() + " Address " + Constant.srcPkey);
					//	throw new ServiceProcessingException(" Address " +Constant.srcPkey);
					}
					if(isNullOrEmpty(partyParam.getAddress().get(0).getSRCSYSTEM()))	{
						reqParamValid = false;
						upsertPartyResponse.setErrorMsg(upsertPartyResponse.getErrorMsg() == null ? "":"\n");
						upsertPartyResponse.setErrorMsg(upsertPartyResponse.getErrorMsg() + " Address " + Constant.srcSYS);
					//	throw new ServiceProcessingException(" Address " +Constant.srcSYS);
					}
				}
				//Communication Mandatory Fields
				if (partyParam.getCommunication() != null && partyParam.getCommunication().size() > 0) {

					if (isNullOrEmpty(partyParam.getCommunication().get(0).getCOMMTYPE()) ) {
						reqParamValid = false;
						upsertPartyResponse.setErrorMsg(upsertPartyResponse.getErrorMsg() == null ? "":"\n");
						upsertPartyResponse.setErrorMsg(upsertPartyResponse.getErrorMsg() + Constant.commTypeCantBeEmpty);
					//	throw new ServiceProcessingException(Constant.commTypeCantBeEmpty);
					}
					if(isNullOrEmpty(partyParam.getCommunication().get(0).getSRCPKEY()))	{
						reqParamValid = false;
						upsertPartyResponse.setErrorMsg(upsertPartyResponse.getErrorMsg() == null ? "":"\n");
						upsertPartyResponse.setErrorMsg(upsertPartyResponse.getErrorMsg() + " Comm " +Constant.srcPkey);
					//	throw new ServiceProcessingException(" Comm " +Constant.srcPkey);
					}
					if(isNullOrEmpty(partyParam.getCommunication().get(0).getSRCSYSTEM()))	{
						reqParamValid = false;
						upsertPartyResponse.setErrorMsg(upsertPartyResponse.getErrorMsg() == null ? "":"\n");
						upsertPartyResponse.setErrorMsg(upsertPartyResponse.getErrorMsg() + " Comm " + Constant.srcSYS);
					//	throw new ServiceProcessingException(" Comm " +Constant.srcSYS);
					}
				}
				//Classification Mandatory Fields
				if (partyParam.getClassification() != null && partyParam.getClassification().size() > 0) {

					if (isNullOrEmpty(partyParam.getClassification().get(0).getCLASSIFICTNTYPE()) ) {
						reqParamValid = false;
						upsertPartyResponse.setErrorMsg(upsertPartyResponse.getErrorMsg() == null ? "":"\n");
						upsertPartyResponse.setErrorMsg(upsertPartyResponse.getErrorMsg() + " Classification " + Constant.classTypeCantBeEmpty);
					//	throw new ServiceProcessingException(Constant.classTypeCantBeEmpty);
					}
					if(isNullOrEmpty(partyParam.getClassification().get(0).getSRCPKEY()))	{
						reqParamValid = false;
						upsertPartyResponse.setErrorMsg(upsertPartyResponse.getErrorMsg() == null ? "":"\n");
						upsertPartyResponse.setErrorMsg(upsertPartyResponse.getErrorMsg() + " Classification " +Constant.srcPkey);
					//	throw new ServiceProcessingException(" Classification " +Constant.srcPkey);
					}
					if(isNullOrEmpty(partyParam.getClassification().get(0).getSRCSYSTEM()))	{
						reqParamValid = false;
						upsertPartyResponse.setErrorMsg(upsertPartyResponse.getErrorMsg() == null ? "":"\n");
						upsertPartyResponse.setErrorMsg(upsertPartyResponse.getErrorMsg() + " Classification " +Constant.srcSYS);
					//	throw new ServiceProcessingException(" Classification " +Constant.srcSYS);
					}
				}
				//PartyOrgExtn Mandatory Fields
				if (partyParam.getPartyOrgExt() != null && partyParam.getPartyOrgExt().size() > 0) {

					if(isNullOrEmpty(partyParam.getPartyOrgExt().get(0).getSRCPKEY()))	{
						reqParamValid = false;
						upsertPartyResponse.setErrorMsg(upsertPartyResponse.getErrorMsg() == null ? "":"\n");
						upsertPartyResponse.setErrorMsg(upsertPartyResponse.getErrorMsg() + " PartyOrgExt " +Constant.srcPkey);
					//	throw new ServiceProcessingException(" PartyOrgExt " +Constant.srcPkey);
					}
					if(isNullOrEmpty(partyParam.getPartyOrgExt().get(0).getSRCSYSTEM()))	{
						reqParamValid = false;
						upsertPartyResponse.setErrorMsg(upsertPartyResponse.getErrorMsg() == null ? "":"\n");
						upsertPartyResponse.setErrorMsg(upsertPartyResponse.getErrorMsg() + " PartyOrgExt " +Constant.srcSYS);
					//	throw new ServiceProcessingException(" PartyOrgExt " +Constant.srcSYS);
					}
				}
			}

		}
		return reqParamValid;
	}
	
	

	public static boolean isNullOrEmpty(String strVal) {
		if (strVal == null || strVal.trim().length() == 0) {
			return true;
		}
		return false;
	}

	public static XMLGregorianCalendar sqldateToGregorianCalendar(
			java.util.Date utilDate)/* throws SearchFault*/ {
		if (utilDate == null) {
			return null;
		} else {
			try {
				java.sql.Date sqlDate = new java.sql.Date(utilDate.getTime());
				GregorianCalendar cal = new GregorianCalendar();
				cal.setTime(sqlDate);
				XMLGregorianCalendar gc = DatatypeFactory.newInstance()
						.newXMLGregorianCalendar(cal);
				return gc;
			} catch (DatatypeConfigurationException dce) {
		//		throw new SearchFault("DatatypeConfigurationException ");
			}
		}
		return null;
	}

	public static String getMappingObjectUid(String sourceSystem, String entity) {
		StringBuilder strB = new StringBuilder("MAPPING.");
		strB.append("MP_").append(sourceSystem).append("_").append(entity);
		LOG.info("MappingObjectUid created: " + strB.toString());
		return strB.toString();
	}

	public java.sql.Date dateConversion(XMLGregorianCalendar xcal) throws Exception{

		if(xcal==null){
			return null;
		}
		else{
		 java.util.Date dt = xcal.toGregorianCalendar().getTime();
		 java.sql.Date sqlDt = new java.sql.Date(dt.getTime());
		 return sqlDt;
		}
	}

	public static String convertDateToMDMTimeZone(String inputDate, String toTimeZone) {
		LOG.debug(" Executing convertDateToMDMTimeZone().");
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
		String convertedDate = null;
		Date lastUpdtDt = null;
		try {
			if (!isNullOrEmpty(inputDate))	{
				LOG.debug("Last_Update_date from request: " + inputDate);
				try {
					lastUpdtDt = sdf.parse(inputDate);
				} catch(Exception excp) {
					LOG.error("Last update date parsing error. Replacing src provided date with database sys date: " + excp);
			//		lastUpdtDt = UpsertPartyDAO.getCurrentTimeZone();
				}
			}
			
			sdf.setTimeZone(TimeZone.getTimeZone(toTimeZone));
			convertedDate = sdf.format(lastUpdtDt);
		} catch(Exception excp) {
			LOG.error("Exception occurred while converting to MDM TimeZone: " + excp);
		}
		LOG.debug(" Converted Date: " + convertedDate);
		LOG.debug(" Executed convertDateToMDMTimeZone().");
		return convertedDate;
	}

	//Print the Request/Response in XML format.
	public static void printObjectTreeInXML(Class objectClass, Object classObject) {
        try {
              JAXBContext jaxbContext = JAXBContext.newInstance(objectClass);
              Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
                     jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);

                    StringWriter strWriter = new StringWriter();
                     jaxbMarshaller.marshal(classObject, strWriter);
                     String msgTxt = strWriter.getBuffer().toString();
                     LOG.debug(objectClass.getName() + " object tree :\n" + msgTxt);
        } catch (JAXBException jaxEx) {
              LOG.error("Failed to create JAXBContext/Marshaller for " + objectClass.getName() + ": " + jaxEx);
              jaxEx.printStackTrace();
        } catch (Exception excp) {
              LOG.error("Failed to convert " + objectClass.getName() + " object into XML: " + excp);
              excp.printStackTrace();
        }
    }

    public static String padSpace(String trimmedStr, int length) {
        StringBuilder resultStr = new StringBuilder(trimmedStr);

        for (int index = trimmedStr.length(); index < length; index++) {
                        resultStr.append(" ");
        }
        LOG.debug("Final string =" + resultStr.toString() + "| length = " + resultStr.length());
        return resultStr.toString();
    }


	//Fetch SYSDATE from Informetica HUB DB.
	public static Date getCurrentTimeZone() {
		JDBCConnectionProvider jDBCConnnectionProvider = null;
		Connection jdbcConn = null;
		Statement statement = null;
		ResultSet resultSet = null;
		StringBuilder sql = new StringBuilder();
		sql.append("SELECT SYSTIMESTAMP FROM DUAL");
		Date sysDate = null;
		
		try{
			jDBCConnnectionProvider = JDBCConnectionProvider.getSingleInstance();
			jdbcConn = jDBCConnnectionProvider.getJdbcConnectionFromDS();
			statement = jdbcConn.createStatement();
			resultSet = statement.executeQuery(sql.toString());

			while(resultSet.next())	{
				sysDate = resultSet.getDate(1);
			}
			
			long time = sysDate.getTime();
			LOG.debug("DATE obj with Timestamp: " + (new Timestamp(time)));
			
			LOG.debug("Current DB date = " + sysDate.toString());
			sysDate=(new Timestamp(time));
			LOG.debug("Current DB Timestamp date = " + sysDate);
		} catch (ServiceProcessingException servExp ){
			servExp.getMessage();
		} catch (SQLException sqlexp) {
			sqlexp.getMessage();
		} finally {
			try {
					if(resultSet != null) resultSet.close();
					if (statement != null) statement.close();
					if(jdbcConn != null) jdbcConn.close();//jDBCConnnectionProvider.closeJdbcConnection(jdbcConn);
				}catch (SQLException e) {
					LOG.error("Caught SQLException in getCurrentTimeZone().");
				}
		}
		return sysDate;
	}
	
	public static String setDefaultValueForNullOrEmptyString(String inStr, String strDefault) {
		String outStr = inStr;
		if(isNullOrEmpty(inStr)) {
			outStr = strDefault;
		}
		
		return outStr;
	}

	public static boolean searchContactRequestValidation(
			SearchContactRequest parameters, SearchContactResponse searchContactResponse) throws ServiceProcessingException {

		LOG.debug("Inside searchContactRequestValidation..");
		boolean isParamValid = false;
		if (parameters == null) {
			LOG.debug(" if parameters is null ");
			isParamValid = false;
			searchContactResponse.setErrorMsg(Constant.SearchContactRequestCantBeNull);
			searchContactResponse.setStatus(Constant.ERROR);
			
		} else {
			ContactSearchCriteriaType contactSearchCriteriaType = parameters
					.getContactSearchCriteria();
			
		 if (contactSearchCriteriaType == null) {
				LOG.debug("if contactSearchCriteriaType is null ");
				isParamValid = false;
				searchContactResponse.setErrorMsg(Constant.contactSearchCriteriaTypeCantBeNull);
				searchContactResponse.setStatus(Constant.ERROR);
			
						
			} else {
				if (!isNullOrEmpty(contactSearchCriteriaType.getLASTNAME())
						|| !isNullOrEmpty(contactSearchCriteriaType
								.getFIRSTNAME())
						|| !isNullOrEmpty(contactSearchCriteriaType
								.getEMAILADDRESS())
						|| !isNullOrEmpty(contactSearchCriteriaType
								.getACCOUNTNAME())) {
					LOG.debug("if contactSearchCriteriaType is not null and one field is present ");
					isParamValid = true;
				}else{
					LOG.info("contactSearchCriteriaType is not present");
					searchContactResponse.setErrorMsg(Constant.contactSearchCriteriaTypeCantBeNull);
					searchContactResponse.setStatus(Constant.ERROR);
				}
				
			/*	if(!isNullOrEmpty(contactSearchCriteriaType.getACCOUNTNAME())){
					if(isNullOrEmpty(contactSearchCriteriaType.getCOUNTRYCD())){
						isParamValid= false;
						searchContactResponse.setErrorMsg("Country is Mandatory for Account Name search");
						searchContactResponse.setStatus(Constant.ERROR);
					}
				}*/
			}
		}
		if (!isNullOrEmpty(parameters.getMatchScoreThresold())) {
			if (parameters.getMatchScoreThresold().matches("[0-9.]+")) {
				if (parameters.getMatchScoreThresold().contains(".")) {
					String str = parameters.getMatchScoreThresold();
					String[] strArray = str.split("\\.");
					parameters.setMatchScoreThresold(strArray[0]);
					LOG.info("Match Score threshold :: "
							+ parameters.getMatchScoreThresold());
				}

			} else {
				isParamValid = false;
				searchContactResponse.setErrorMsg("MatchScoreThresold Should be numeric");
				searchContactResponse.setStatus(Constant.ERROR);
			}
		}
		if (!isNullOrEmpty(parameters.getRecordCountThresold())) {
			if (parameters.getRecordCountThresold().matches("[0-9.]+")) {
				if (parameters.getRecordCountThresold().contains(".")) {
					String str = parameters.getRecordCountThresold();
					String[] strArray = str.split("\\.");
					parameters.setRecordCountThresold(strArray[0]);
					LOG.info("Record count Threshold :: "
							+ parameters.getRecordCountThresold());

				}
			} else {
				isParamValid = false;
				searchContactResponse.setErrorMsg("RecordCountThresold Should be numeric");
				searchContactResponse.setStatus(Constant.ERROR);
			}
		}
		
		
		return isParamValid;

	}
}
