package com.mcafee.mdm.util;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

/**
 * This is util class to create Spring Bean instance
 * 
 * @author Anirbid Roy
 * 
 */
@Component
public class SpringUtil {
	@Autowired
	private ApplicationContext ctx;

	public <T> T getBeanByType(final Class<T> beanClass) {
		return beanClass.cast(ctx.getBean(beanClass));
	}
}