package com.mcafee.mdm.util;

import org.apache.log4j.Logger;
import org.apache.log4j.MDC;
import org.springframework.util.CollectionUtils;

import com.mcafee.mdm.constants.Constant;
import com.mcafee.mdm.generated.MdmUpsertPartyRequest;
import com.mcafee.mdm.generated.MdmUpsertPartyResponse;
import com.mcafee.mdm.generated.PartyXrefType;
import com.mcafee.mdm.generated.UpsertPartyRequest;
import com.mcafee.mdm.generated.UpsertPartyResponse;

public class PerformanceLoggerUtil {
	
	private static final Logger LOG = Logger.getLogger(PerformanceLoggerUtil.class.getName());
	
	private String flowName = "";
	private String pkey = "";
	public void printEntryLog(UpsertPartyRequest request) {
		try {
			PartyXrefType party = request.getParty().get(0);
			if("ELQ".equalsIgnoreCase(party.getXREF().get(0).getSRCSYSTEM())) {
				if(Constant.BO_CLASS_CODE_PERSON.equalsIgnoreCase(party.getBOCLASSCODE())) {
					flowName=Constant.PERF_LOG_FLOW_UPSERT_ELQ_CONTACT;
				} else if(Constant.BO_CLASS_CODE_ORG.equalsIgnoreCase(party.getBOCLASSCODE())) {
					flowName=Constant.PERF_LOG_FLOW_UPSERT_ELQ_ACCOUNT;
				}
			} else {
				flowName=Constant.PERF_LOG_FLOW_UPSERT_SAP_SBL;
			}
			pkey = party.getXREF().get(0).getSRCPKEY();
			if(pkey == null) {
				pkey = "";
			}
			printLog(flowName, pkey, "STEP 0", "Upsert operation started");
		} catch(Exception e) {
			LOG.error(e);
		}
	}
	
	public void printExitLog(UpsertPartyResponse response, long time) {
		try {
			if(Util.isNullOrEmpty(pkey)) {
				if(!CollectionUtils.isEmpty(response.getParty()) && response.getParty().get(0) != null 
						&& !Util.isNullOrEmpty(response.getParty().get(0).getSRCSYSTEMID())) {
					pkey=response.getParty().get(0).getSRCSYSTEMID();
				}
			}
			if(!Util.isNullOrEmpty(response.getStatus())) {
				if(response.getStatus().contains("Update operation successful for Party ")) {
					printLog(flowName, pkey, "STEP EXIT", "Update operation Done in " + time + " mSec");
				} else if(response.getStatus().contains("Insert operation successful for Party ")) {
					printLog(flowName, pkey, "STEP EXIT", "Create operation Done in " + time + " mSec");
				} else {
					printLog(flowName, pkey, "STEP EXIT", "Upsert operation Done in " + time + " mSec");
				}
			} else {
				printLog(flowName, pkey, "STEP EXIT", "Upsert operation Done in " + time + " mSec");
			}
		} catch(Exception e) {
			LOG.error(e);
		}
	}
	
	public void printLog(String flowName, String pkey, String step, String msg) {
		try {
			MDC.put("flowName", convertNullToEmpty(flowName));
			MDC.put("pkey", convertNullToEmpty(pkey));
			MDC.put("step", convertNullToEmpty(step));
			LOG.info(msg);
			MDC.put("flowName", "");
			MDC.put("pkey", "");
			MDC.put("step", "");
		} catch(Exception e) {
			LOG.error(e);
		}
	}
	
	private String convertNullToEmpty(String inStr) {
		if(inStr == null) {
			return Constant.STR_BLANK;
		} else {
			return inStr;
		}
	}
	
	public void printEntryLog(MdmUpsertPartyRequest request) {
		try {
			PartyXrefType party = request.getParty().get(0);
			if("ELQ".equalsIgnoreCase(party.getXREF().get(0).getSRCSYSTEM())) {
				if(Constant.BO_CLASS_CODE_PERSON.equalsIgnoreCase(party.getBOCLASSCODE())) {
					flowName=Constant.PERF_LOG_FLOW_UPSERT_ELQ_CONTACT;
				} else if(Constant.BO_CLASS_CODE_ORG.equalsIgnoreCase(party.getBOCLASSCODE())) {
					flowName=Constant.PERF_LOG_FLOW_UPSERT_ELQ_ACCOUNT;
				}
			} else {
				flowName=Constant.PERF_LOG_FLOW_UPSERT_SFDC;
			}
			pkey = party.getXREF().get(0).getSRCPKEY();
			if(pkey == null) {
				pkey = "";
			}
			printLog(flowName, pkey, "STEP 0", "SFDC Upsert operation started");
		} catch(Exception e) {
			LOG.error(e);
		}
	}
	public void printExitLog(MdmUpsertPartyResponse response, long time) {
		try {
			if(Util.isNullOrEmpty(pkey)) {
				if(!CollectionUtils.isEmpty(response.getParty()) && response.getParty().get(0) != null 
						&& !Util.isNullOrEmpty(response.getParty().get(0).getSRCSYSTEMID())) {
					pkey=response.getParty().get(0).getSRCSYSTEMID();
				}
			}
			if(!Util.isNullOrEmpty(response.getStatus())) {
				if(response.getStatus().contains("Update operation successful for Party ")) {
					printLog(flowName, pkey, "STEP EXIT", "Update operation Done in " + time + " mSec");
				} else if(response.getStatus().contains("Insert operation successful for Party ")) {
					printLog(flowName, pkey, "STEP EXIT", "Create operation Done in " + time + " mSec");
				} else {
					printLog(flowName, pkey, "STEP EXIT", "Upsert operation Done in " + time + " mSec");
				}
			} else {
				printLog(flowName, pkey, "STEP EXIT", "Upsert operation Done in " + time + " mSec");
			}
		} catch(Exception e) {
			LOG.error(e);
		}
	}
}
