package com.mcafee.mdm.util;

import java.util.Enumeration;
import java.util.Hashtable;

import com.siperian.sif.client.SiperianClient;


/**
 * The class creates object pools to store and manage created SIF SiperianClient connections.
 * SIF client connections are reused by maintaining two pools - locked and unlocked.
 * On request, connection is served from the unlock pool or created a new connection if the pool is empty.
 * The provided connection object is put into a locked pool until the connection is released.
 * Once released, the connection object is returned back to the unlock pool.
 */
public abstract class ObjectPool {

	private static Hashtable<SiperianClient, Integer> locked = new Hashtable<SiperianClient, Integer>();
	private static Hashtable<SiperianClient, Integer> unlocked = new Hashtable<SiperianClient, Integer>();

	public ObjectPool() {
		super();
	}

	/**
	 * Checks for a free SiperianClient object in the pool and returns it. 
	 * If there is no free object in the pool then creates a new SiperianClient and returns it.  
	 * @return SiperianClient SIF connection object
	 */
	public synchronized SiperianClient checkOut() throws Exception {
		SiperianClient siperianClient;

		if (unlocked.size() > 0) {
			Enumeration<SiperianClient> clientsObjects = unlocked.keys();
			siperianClient = clientsObjects.nextElement();
			unlocked.remove(siperianClient);
			locked.put(siperianClient, locked.size() + 1);
			return (siperianClient);
		}
		// no objects available, create a new one
		siperianClient = CreateSIFClient.getSIFClientObject().getSIFClient();
		locked.put(siperianClient, locked.size() + 1);
		return (siperianClient);
	}

	/**
	 * Puts the used SiperianClient object in to the free pool 
	 * if the maximum pool size is has not been reached.
	 * @param SiperianClient SIF connection object
	 * 	
	 */
	public synchronized void checkIn(SiperianClient siperianClient) {
		locked.remove(siperianClient);
		if (unlocked.size() < 5) {
			unlocked.put(siperianClient, unlocked.size() + 1);
		}
	}
}
