package com.mcafee.mdm.util;

import java.util.Properties;

import org.apache.log4j.Logger;

import com.mcafee.mdm.exception.ServiceProcessingException;
import com.siperian.sif.client.SiperianClient;

/**
 * The class creates SIF client connection (SiperianClient object) with the Informatica MDM Hub.
 * Properties required to establish the connection needs to be defined in a properties file named, sip-client.properties.
 *
 */
public class CreateSIFClient {

	private static final Logger LOG = Logger.getLogger(CreateSIFClient.class.getName());
	private static CreateSIFClient sifClientObject;
	private static SiperianClient sifClient;

	private CreateSIFClient() {
	
	}
	public static synchronized CreateSIFClient getSIFClientObject() {
		if (sifClientObject == null) {
			sifClientObject = new CreateSIFClient();
		}
		return sifClientObject;
	}
	
	public SiperianClient getSIFClient() throws ServiceProcessingException {
		LOG.info("Executing getSIFClient()");
		Properties properties =null;
		try { 
			properties = PropertyUtil.getPropertiesFromFile("sipProp");	
			LOG.info("Loaded siperian-client.properties file" );			
			//create SIF client
			sifClient = SiperianClient.newSiperianClient(properties);			
			LOG.info("SIF client created successfully");
		} catch (com.siperian.common.SipRuntimeException srExcp) {
			LOG.error("SipRuntimeException occured while creating SIF client connection");
			ServiceProcessingException customException = new ServiceProcessingException(srExcp);
			customException.setMessage("Failed to create SIF connection. Please call support team.");
			throw customException;
		}
		LOG.info("Executed getSIFClient()");
		return sifClient;

	}
}
