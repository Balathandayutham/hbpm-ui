package com.mcafee.mdm.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import org.apache.log4j.Logger;

//import com.mcafee.mdm.partysearch.PartySearchImpl;


	
	public class JdbcConn {
		
		private static  Logger log = Logger.getLogger(JdbcConn.class.getName());
		public static Connection GetJdbcConnObject() {
		//	System.out.println("-------- Oracle JDBC Connection Testing ------");
			try {
				Class.forName("oracle.jdbc.driver.OracleDriver");
			} catch (ClassNotFoundException e) {
				System.out.println(" Can't get Oracle Driver !!");
				e.printStackTrace();
			}
		//	System.out.println("Oracle JDBC Driver Registered!");
			Connection connection = null;
			try {
				connection = DriverManager.getConnection("jdbc:oracle:thin:@mdmdbrac-scan.corp.nai.org:1521:MCFMDMPR_SRV1",  "PROD_ORS","!!cmx!!");
			} catch (SQLException e) {
				System.out.println(" Can't get Connection !");
				e.printStackTrace();
			}
			if (connection != null) {
				log.debug("Connected successfully to PROD_ORS");
				return connection ;
			} else {
				log.debug("Failed to make connection to PROD_ORS!");
				return null;
			}

		}

	}

