package com.mcafee.mdm.util;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.TimeZone;

import javax.transaction.SystemException;
import javax.transaction.UserTransaction;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.mcafee.mdm.constants.Constant;
import com.mcafee.mdm.constants.MDMAttributeNames;
import com.mcafee.mdm.constants.SearchMatchAttributes;
import com.mcafee.mdm.dao.DeleteChildDAO;
import com.mcafee.mdm.dao.GetPartyDAO;
import com.mcafee.mdm.exception.ServiceProcessingException;
import com.mcafee.mdm.generated.AccountType;
import com.mcafee.mdm.generated.AccountXrefType;
import com.mcafee.mdm.generated.Address;
import com.mcafee.mdm.generated.AddressType;
import com.mcafee.mdm.generated.AddressXrefType;
import com.mcafee.mdm.generated.CommunicationType;
import com.mcafee.mdm.generated.CommunicationXrefType;
import com.mcafee.mdm.generated.MdmUpsertPartyResponse;
import com.mcafee.mdm.generated.PartyType;
import com.mcafee.mdm.generated.PartyUpsertRespType;
import com.mcafee.mdm.generated.PartyXrefType;
import com.mcafee.mdm.generated.UpsertPartyResponse;
import com.mcafee.mdm.generated.XREFType;
import com.siperian.sif.client.EjbSiperianClient;
import com.siperian.sif.client.SiperianClient;
import com.siperian.sif.client.SiperianServerException;
import com.siperian.sif.message.Field;
import com.siperian.sif.message.MatchType;
import com.siperian.sif.message.Record;
import com.siperian.sif.message.SiperianObjectType;
import com.siperian.sif.message.mrm.SearchMatchRequest;
import com.siperian.sif.message.mrm.SearchMatchResponse;
import com.siperian.sif.message.mrm.SearchQueryRequest;
import com.siperian.sif.message.mrm.SearchQueryResponse;

import oracle.jdbc.OracleTypes;

@Component
@Scope("prototype")
public class CommonUtil {

	private static final Logger LOG = Logger.getLogger(CommonUtil.class);

	Properties configProps = PropertyUtil.getPropertiesFromFile("configProp");

	@Autowired
	private GetPartyDAO getPartyDAO;

	/* Execute SearchMatch API on Party & Address BO Table */
	@SuppressWarnings("rawtypes")
	public List selfMatchParty(PartyXrefType partyTypeParam, PartyType existingParty, SiperianClient siperianClient)
			throws ServiceProcessingException {

		LOG.info("Executing selfMatchParty()...");

		String ruleSetNonJPN = "";
		String ruleSetJPN = configProps.getProperty("matchRuleSetCustomerJPN");
		List searchRecords = new ArrayList();

		try {
			SearchMatchRequest searchMatchRequest = new SearchMatchRequest();
			SearchMatchResponse searchMatchResponse = null;

			searchMatchRequest.setRecordsToReturn(100);
			searchMatchRequest.setSiperianObjectUid("BASE_OBJECT.C_B_PARTY");

			String countryCode = partyTypeParam.getAddress().get(0).getCOUNTRYCD();
			if ("Japan".equalsIgnoreCase(countryCode) || "JPN".equalsIgnoreCase(countryCode)
					|| "JP".equalsIgnoreCase(countryCode)) {

				searchMatchRequest.setMatchRuleSetUid(SiperianObjectType.MATCH_RULE_SET.makeUid(ruleSetJPN));// Kanji_Org_Name_Mod

			} else {

				String partyType = partyTypeParam.getPARTYTYPE();

				if (Constant.PARTY_TYPE_CUSTOMER.equalsIgnoreCase(partyType)) {
					ruleSetNonJPN = configProps.getProperty("matchRuleSetCustomer");
				} else if (Constant.PARTY_TYPE_RESELLER.equalsIgnoreCase(partyType)) {
					ruleSetNonJPN = configProps.getProperty("matchRuleSetReseller");
				} else if (Constant.PARTY_TYPE_DISTRIBUTOR.equalsIgnoreCase(partyType)) {
					ruleSetNonJPN = configProps.getProperty("matchRuleSetDistributor");
				}
				searchMatchRequest.setMatchRuleSetUid(SiperianObjectType.MATCH_RULE_SET.makeUid(ruleSetNonJPN));

			}

			searchMatchRequest.setMatchType(MatchType.BOTH);

			LOG.info("Match Rule Set: " + searchMatchRequest.getMatchRuleSetUid());
			LOG.info("Match Type :" + searchMatchRequest.getMatchType());

			// setting Ex_Address_Ln1,Ex_Address_Ln2,Ex_City, Ex_State,
			// Ex_Country_Cd,Ex_Entity_Type,Ex_Organization_Name,
			// Ex_Party_Type,Organization_Name
			Field field_name = new Field("Organization_Name");
			if (!Util.isNullOrEmpty(partyTypeParam.getPARTYNAME())) {
				field_name.setStringValue(partyTypeParam.getPARTYNAME());
				LOG.info("Field to search for :" + field_name.getName() + ':' + field_name.getStringValue());
				searchMatchRequest.addMatchColumnField(field_name);
			}
			AddressXrefType addressXref = partyTypeParam.getAddress() == null ? null
					: partyTypeParam.getAddress().get(0);
			if (null != addressXref) {
				// Setting Address_Part1
				Field field_addr1 = new Field("Address_Part1");
				StringBuilder addrLn1Ln2Concat = new StringBuilder();
				if (!Util.isNullOrEmpty(addressXref.getADDRLN1())) {
					addrLn1Ln2Concat.append(addressXref.getADDRLN1());

				}
				if (!Util.isNullOrEmpty(addressXref.getADDRLN2())) {
					addrLn1Ln2Concat.append(" ");
					addrLn1Ln2Concat.append(addressXref.getADDRLN2());

				} else {
					addrLn1Ln2Concat.append(" ");
				}
				if (addrLn1Ln2Concat != null && addrLn1Ln2Concat.length() > 1) {
					field_addr1.setStringValue(addrLn1Ln2Concat.toString());
					searchMatchRequest.addMatchColumnField(field_addr1);
				}
				LOG.info("Field to search for :" + field_addr1.getName() + ':' + field_addr1.getStringValue());

				if (!Util.isNullOrEmpty(addressXref.getADDRLN1()))
					createSearchField(searchMatchRequest, SearchMatchAttributes.EX_ADDRESS_LN1,
							addressXref.getADDRLN1());
				if (!Util.isNullOrEmpty(addressXref.getADDRLN2()))
					createSearchField(searchMatchRequest, SearchMatchAttributes.EX_ADDRESS_LN2,
							addressXref.getADDRLN2());

				if (addrLn1Ln2Concat != null && addrLn1Ln2Concat.length() > 1) {
					createSearchField(searchMatchRequest, SearchMatchAttributes.EX_ADDR_PART1,
							addrLn1Ln2Concat.toString());
				}
				if (!Util.isNullOrEmpty(addressXref.getCITY()))
					createSearchField(searchMatchRequest, SearchMatchAttributes.EX_CITY, addressXref.getCITY());
				if (!Util.isNullOrEmpty(addressXref.getCOUNTRYCD()))
					createSearchField(searchMatchRequest, SearchMatchAttributes.EX_COUNTRY_CD,
							addressXref.getCOUNTRYCD());
				if (!Util.isNullOrEmpty(addressXref.getSTATECD()))
					createSearchField(searchMatchRequest, SearchMatchAttributes.EX_STATE, addressXref.getSTATECD());
				// Setting Address_Part2

				Field addr_part2 = new Field("Address_Part2");
				StringBuilder addrPart2Concat = new StringBuilder();
				if (!Util.isNullOrEmpty(addressXref.getCITY())) {
					addrPart2Concat.append(addressXref.getCITY());
				}
				if (!Util.isNullOrEmpty(addressXref.getSTATECD())) {
					if (addrPart2Concat != null && addrPart2Concat.length() > 1)
						addrPart2Concat.append(" ");
					addrPart2Concat.append(addressXref.getSTATECD());
				}
				if (!Util.isNullOrEmpty(addressXref.getCOUNTRYCD())) {
					if (addrPart2Concat != null && addrPart2Concat.length() > 1)
						addrPart2Concat.append(" ");
					addrPart2Concat.append(addressXref.getCOUNTRYCD());
				}
				if (addrPart2Concat != null && addrPart2Concat.length() > 1) {
					addr_part2.setStringValue(addrPart2Concat.toString());
					LOG.info("Field to search for :" + addr_part2.getName() + ':' + addr_part2.getStringValue());
					searchMatchRequest.addMatchColumnField(addr_part2);
				}

			}

			createSearchField(searchMatchRequest, SearchMatchAttributes.EX_ORGANIZATION_NAME,
					partyTypeParam.getPARTYNAME());
			createSearchField(searchMatchRequest, SearchMatchAttributes.EX_ENTITY_TYPE, Constant.BO_CLASS_CODE_ORG);
			createSearchField(searchMatchRequest, SearchMatchAttributes.EX_PARTY_TYPE, existingParty.getPARTYTYPE());

			// Adding SIP_POP
			Field field_SIPPOP = new Field("SIP_POP");
			field_SIPPOP.setStringValue(existingParty.getSIPPOP());
			searchMatchRequest.addMatchColumnField(field_SIPPOP);
			LOG.info("Field to match for :" + field_SIPPOP.getName() + ':' + field_SIPPOP.getStringValue());

			StringBuffer criteria = new StringBuffer();
			boolean firstParam = true;

			if (firstParam) {
				criteria.append(" CONSOLIDATION_IND <> 9 ");
				firstParam = false;
			} else {
				criteria.append(" AND CONSOLIDATION_IND <> 9 ");
			}
			if (firstParam) {
				criteria.append(" STATUS_CD = 'A' ");
				firstParam = false;
			} else {
				criteria.append(" AND STATUS_CD = 'A' ");
			}
			LOG.info("Filter Criteria: " + criteria.toString());

			searchMatchRequest.setFilterCriteria(criteria.toString());

			LOG.info("processing SearchMatchRequest");
			searchMatchResponse = (SearchMatchResponse) siperianClient.process(searchMatchRequest);

			searchRecords = searchMatchResponse.getRecords();
		} catch (SiperianServerException sifExcp) {
			LOG.error("SiperianServerException occured while processing SearchMatchRequest on PARTY BO: ", sifExcp);
			ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
			customException.setMessage("SIF exception occured while processing SearchMatchRequest on PARTY BO: "
					+ customException.getMessage());
			throw customException;
		} catch (Exception ex) {
			LOG.error("PARTY BO Merge operation failed with exception: ", ex);
			ServiceProcessingException customException = new ServiceProcessingException(ex);
			customException
					.setMessage("Failed to process SearchMatchRequest on PARTY BO: " + customException.getMessage());
			throw customException;
		}

		LOG.info("Completed selfMatchParty()...");
		return searchRecords;
	}

	/* Execute SearchMatch API on Party & Address BO Table */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List matchParty(PartyXrefType partyTypeParam, SiperianClient siperianClient)
			throws ServiceProcessingException {

		LOG.info("Executing matchParty()...");

		String ruleSetJPN = configProps.getProperty("matchRuleSetCustomerJPN");
		String getPkgName = configProps.getProperty("pkgName");
		String sipPopVal = getPartyDAO.getSipPopFromXref();
		LOG.info("sipPopVal from GetPartyDAO: " + sipPopVal);
		List searchRecords = new ArrayList();

		try {
			SearchMatchRequest searchMatchRequest = new SearchMatchRequest();
			SearchMatchResponse searchMatchResponse = null;

			searchMatchRequest.setRecordsToReturn(100); // Required
			// searchMatchRequest.setSiperianObjectUid("BASE_OBJECT.C_B_PARTY");
			// LOG.info("base object set for search match :
			// BASE_OBJECT.C_B_PARTY" );
			searchMatchRequest.setSiperianObjectUid(getPkgName);
			LOG.info("Match Rule Set: before setting " + searchMatchRequest.getMatchRuleSetUid());
			String countryCode = partyTypeParam.getAddress().get(0).getCOUNTRYCD();
			if ("Japan".equalsIgnoreCase(countryCode) || "JPN".equalsIgnoreCase(countryCode)
					|| "JP".equalsIgnoreCase(countryCode)) {
				searchMatchRequest.setMatchRuleSetUid(SiperianObjectType.MATCH_RULE_SET.makeUid(ruleSetJPN));// Kanji_Org_Name_Mod
			} else {
				if (partyTypeParam.getPARTYTYPE().equalsIgnoreCase(Constant.PARTY_TYPE_CUSTOMER)) {
					searchMatchRequest.setMatchRuleSetUid(
							SiperianObjectType.MATCH_RULE_SET.makeUid(configProps.getProperty("matchRuleSetCustomer")));
					// searchMatchRequest.setMatchRuleSetUid("MATCH_RULE_SET.C_B_PARTY|Customer
					// Deduplication Ruleset");
					LOG.info("Match Rule Set: inside customerr :" + searchMatchRequest.getMatchRuleSetUid());
				} else if (partyTypeParam.getPARTYTYPE().equalsIgnoreCase(Constant.PARTY_TYPE_RESELLER)) {
					searchMatchRequest.setMatchRuleSetUid(
							SiperianObjectType.MATCH_RULE_SET.makeUid(configProps.getProperty("matchRuleSetReseller")));
					LOG.info("Match Rule Set: inside customerr :" + searchMatchRequest.getMatchRuleSetUid());
				} else if (partyTypeParam.getPARTYTYPE().equalsIgnoreCase(Constant.PARTY_TYPE_DISTRIBUTOR)) {
					searchMatchRequest.setMatchRuleSetUid(SiperianObjectType.MATCH_RULE_SET
							.makeUid(configProps.getProperty("matchRuleSetDistributor")));
				} else {
					LOG.info(
							"Account is not created since it's PARTY_TYPE is not in ('Customer', 'Reseller', 'Distributor')");
				}
			}

			searchMatchRequest.setMatchType(MatchType.BOTH);

			LOG.info("Match Rule Set: " + searchMatchRequest.getMatchRuleSetUid());
			LOG.info("Match Type :" + searchMatchRequest.getMatchType());

			// setting Ex_Address_Ln1,Ex_Address_Ln2,Ex_City, Ex_State,
			// Ex_Country_Cd,Ex_Entity_Type,Ex_Organization_Name,
			// Ex_Party_Type,Organization_Name
			Field field_name = new Field("Organization_Name");
			if (!Util.isNullOrEmpty(partyTypeParam.getPARTYNAME())) {
				field_name.setStringValue(partyTypeParam.getPARTYNAME());
				LOG.info("Field to search for :" + field_name.getName() + ':' + field_name.getStringValue());
				searchMatchRequest.addMatchColumnField(field_name);
			}

			Field ucnField_name = new Field("Ex_UCN");
			LOG.info("inserted ucn : " + partyTypeParam.getUCN());
			if (!Util.isNullOrEmpty(partyTypeParam.getUCN())) {
				ucnField_name.setStringValue(partyTypeParam.getUCN());
				LOG.info("Field to search for :" + ucnField_name.getName() + ':' + ucnField_name.getStringValue());
				searchMatchRequest.addMatchColumnField(ucnField_name);
			}

			AddressXrefType addressXref = partyTypeParam.getAddress() == null ? null
					: partyTypeParam.getAddress().get(0);
			if (null != addressXref) {
				// Setting Address_Part1
				Field field_addr1 = new Field("Address_Part1");
				StringBuilder addrLn1Ln2Concat = new StringBuilder();
				if (!Util.isNullOrEmpty(addressXref.getADDRLN1())) {
					addrLn1Ln2Concat.append(addressXref.getADDRLN1());

				}
				if (!Util.isNullOrEmpty(addressXref.getADDRLN2())) {
					addrLn1Ln2Concat.append(" ");
					addrLn1Ln2Concat.append(addressXref.getADDRLN2());

				} else {
					addrLn1Ln2Concat.append(" ");
				}
				if (addrLn1Ln2Concat != null && addrLn1Ln2Concat.length() > 1) {
					field_addr1.setStringValue(addrLn1Ln2Concat.toString());
					searchMatchRequest.addMatchColumnField(field_addr1);
				}
				LOG.info("Field to search for :" + field_addr1.getName() + ':' + field_addr1.getStringValue());

				if (!Util.isNullOrEmpty(addressXref.getADDRLN1()))
					createSearchField(searchMatchRequest, SearchMatchAttributes.EX_ADDRESS_LN1,
							addressXref.getADDRLN1());
				if (!Util.isNullOrEmpty(addressXref.getADDRLN2()))
					createSearchField(searchMatchRequest, SearchMatchAttributes.EX_ADDRESS_LN2,
							addressXref.getADDRLN2());

				if (addrLn1Ln2Concat != null && addrLn1Ln2Concat.length() > 1) {
					createSearchField(searchMatchRequest, SearchMatchAttributes.EX_ADDR_PART1,
							addrLn1Ln2Concat.toString());
				}
				if (!Util.isNullOrEmpty(addressXref.getCITY()))
					createSearchField(searchMatchRequest, SearchMatchAttributes.EX_CITY, addressXref.getCITY());
				if (!Util.isNullOrEmpty(addressXref.getCOUNTRYCD()))
					createSearchField(searchMatchRequest, SearchMatchAttributes.EX_COUNTRY_CD,
							addressXref.getCOUNTRYCD());
				if (!Util.isNullOrEmpty(addressXref.getSTATECD()))
					createSearchField(searchMatchRequest, SearchMatchAttributes.EX_STATE, addressXref.getSTATECD());

				LOG.info("State search : " + addressXref.getSTATECD());
				LOG.info("country search : " + addressXref.getCOUNTRYCD());
				LOG.info("addresspart1 search: " + addrLn1Ln2Concat);
				LOG.info("Search organization name : " + partyTypeParam.getPARTYNAME());
				LOG.info("searrch entity type : " + Constant.BO_CLASS_CODE_ORG);
				LOG.info("searrch for UCN : " + partyTypeParam.getUCN());
				LOG.info("searrch for city : " + addressXref.getCITY());
				// Setting Address_Part2

				Field addr_part2 = new Field("Address_Part2");
				StringBuilder addrPart2Concat = new StringBuilder();
				if (!Util.isNullOrEmpty(addressXref.getCITY())) {
					addrPart2Concat.append(addressXref.getCITY());
				}
				if (!Util.isNullOrEmpty(addressXref.getSTATECD())) {
					if (addrPart2Concat != null && addrPart2Concat.length() > 1)
						addrPart2Concat.append(" ");
					addrPart2Concat.append(addressXref.getSTATECD());
				}
				if (!Util.isNullOrEmpty(addressXref.getCOUNTRYCD())) {
					if (addrPart2Concat != null && addrPart2Concat.length() > 1)
						addrPart2Concat.append(" ");
					addrPart2Concat.append(addressXref.getCOUNTRYCD());
				}
				if (addrPart2Concat != null && addrPart2Concat.length() > 1) {
					addr_part2.setStringValue(addrPart2Concat.toString());
					LOG.info("Field to search for :" + addr_part2.getName() + ':' + addr_part2.getStringValue());
					searchMatchRequest.addMatchColumnField(addr_part2);
				}

			}
			AccountXrefType accountXrefType = partyTypeParam.getAccount() == null ? null
					: partyTypeParam.getAccount().get(0);
			if (null != accountXrefType) {
				// Setting Ex_Partner_Type
				if (!Util.isNullOrEmpty(accountXrefType.getPARTNERTYPE()))
					createSearchField(searchMatchRequest, SearchMatchAttributes.Ex_Partner_Type,
							accountXrefType.getPARTNERTYPE());
			}
			createSearchField(searchMatchRequest, SearchMatchAttributes.EX_ORGANIZATION_NAME,
					partyTypeParam.getPARTYNAME());
			/*
			 * createSearchField(searchMatchRequest,
			 * SearchMatchAttributes.ORGANIZATION_NAME,
			 * partyTypeParam.getPARTYNAME());
			 */
			createSearchField(searchMatchRequest, SearchMatchAttributes.EX_ENTITY_TYPE, Constant.BO_CLASS_CODE_ORG);
			if (partyTypeParam.getPARTYTYPE().equalsIgnoreCase(Constant.PARTY_TYPE_CUSTOMER)) {
				createSearchField(searchMatchRequest, SearchMatchAttributes.EX_PARTY_TYPE,
						Constant.PARTY_TYPE_CUSTOMER);
				LOG.info("entering search for customer party type " + Constant.PARTY_TYPE_CUSTOMER);
			} else if (partyTypeParam.getPARTYTYPE().equalsIgnoreCase(Constant.PARTY_TYPE_RESELLER)) {
				createSearchField(searchMatchRequest, SearchMatchAttributes.EX_PARTY_TYPE,
						Constant.PARTY_TYPE_RESELLER);
			} else if (partyTypeParam.getPARTYTYPE().equalsIgnoreCase(Constant.PARTY_TYPE_DISTRIBUTOR)) {
				createSearchField(searchMatchRequest, SearchMatchAttributes.EX_PARTY_TYPE,
						Constant.PARTY_TYPE_DISTRIBUTOR);
			} else {
				LOG.info(
						"Account is not created since it's PARTY_TYPE is not in ('Customer', 'Reseller', 'Distributor')");
			}
			// createSearchField(searchMatchRequest,SearchMatchAttributes.EX_PARTY_TYPE,Constant.PARTY_TYPE_PROSPECT_ACCOUNT);

			// Adding SIP_POP
			Field field_SIPPOP = new Field("SIP_POP");
			field_SIPPOP.setStringValue(sipPopVal);
			searchMatchRequest.addMatchColumnField(field_SIPPOP);
			LOG.info("Field to match for :" + field_SIPPOP.getName() + ':' + field_SIPPOP.getStringValue());

			StringBuffer criteria = new StringBuffer();
			boolean firstParam = true;
			if (firstParam) {
				criteria.append(" CONSOLIDATION_IND <> 9 ");
				firstParam = false;
			} else {
				criteria.append(" AND CONSOLIDATION_IND <> 9 ");
			}
			if (firstParam) {
				criteria.append(" STATUS_CD = 'A' ");
				firstParam = false;
			} else {
				criteria.append(" AND STATUS_CD = 'A' ");
			}
			LOG.info("Filter Criteria: " + criteria.toString());

			searchMatchRequest.setFilterCriteria(criteria.toString());

			LOG.info("processing SearchMatchRequest");
			searchMatchResponse = (SearchMatchResponse) siperianClient.process(searchMatchRequest);

			searchRecords = searchMatchResponse.getRecords();

			for (int i = 0; i < searchRecords.size(); i++) {
				Record record = (Record) searchRecords.get(i);
				record.getFields();
				Collection<String> fields = record.getFields();
				Iterator iterator = fields.iterator();

				// while loop
				while (iterator.hasNext()) {
					Field f = (Field) iterator.next();
					LOG.info("feild name : " + f.getName() + "feild value : " + f.getValue());
				}
			}
		} catch (SiperianServerException sifExcp) {

			LOG.error("SiperianServerException occured while processing SearchMatchRequest on PARTY BO: ", sifExcp);

			ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
			customException.setMessage("SIF exception occured while processing SearchMatchRequest on PARTY BO: "
					+ customException.getMessage());
			throw customException;
		} catch (Exception ex) {

			LOG.error("PARTY BO Merge operation failed with exception: ", ex);

			ServiceProcessingException customException = new ServiceProcessingException(ex);
			customException
					.setMessage("Failed to process SearchMatchRequest on PARTY BO: " + customException.getMessage());
			throw customException;
		}

		LOG.info("Completed matchParty()...");
		return searchRecords;
	}

	@SuppressWarnings("rawtypes")
	public List ucnSearchParty(PartyXrefType partyTypeParam, SiperianClient siperianClient)
			throws ServiceProcessingException {

		LOG.info("Executing ucnSearchParty()...");

		List searchRecords = new ArrayList();
		try {

			// Search query to match UCN and party type to convert patry type
			LOG.info("Executing UCN search Query...");
			SearchQueryRequest request = new SearchQueryRequest();
			request.setRecordsToReturn(5); // Required
			request.setSiperianObjectUid("BASE_OBJECT.C_B_PARTY");
			// Required
			request.setFilterCriteria("UCN = '" + partyTypeParam.getUCN()
					+ "' and CONSOLIDATION_IND <> 9 and STATUS_CD = 'A' and (PARTY_TYPE in ('Customer','Reseller','Distributor') or PARTY_TYPE is null)");
			SearchQueryResponse response = (SearchQueryResponse) siperianClient.process(request);
			LOG.info("search sucessful.");
			searchRecords = response.getRecords();

		} catch (SiperianServerException sifExcp) {
			LOG.error("SiperianServerException occured while processing UCNSearchParty on PARTY BO: ", sifExcp);
			// sifExcp.printStackTrace();
			ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
			customException.setMessage("SIF exception occured while processing UCNSearchParty on PARTY BO: "
					+ customException.getMessage());
			throw customException;
		} catch (Exception ex) {
			LOG.error("UCNSearchParty operation failed with exception: ", ex);
			// ex.printStackTrace();
			ServiceProcessingException customException = new ServiceProcessingException(ex);
			customException.setMessage("Failed to process UCNSearchParty on PARTY BO: " + customException.getMessage());
			throw customException;
		}

		LOG.info("Completed UCNSearchParty()...");
		return searchRecords;

	}

	public void createSearchField(SearchMatchRequest searchMatchRequest, String fieldName, Object fieldValue) {
		LOG.debug("[createSearchField]ENTER::fieldName::" + fieldName + "::fieldValue::" + fieldValue);
		Field field = null;
		if (!Util.isNullOrEmpty(fieldName)) {
			field = new Field(fieldName);
			field.setValue(fieldValue);
		}
		if (field != null) {
			searchMatchRequest.addMatchColumnField(field);
			LOG.debug("[createSearchField]Added Field::" + field.getName() + "::" + field.getStringValue());
		}
		LOG.debug("[createSearchField]EXIT");
	}

	// Fetch Party Pkeys for party-Rowid
	public List<String> getPartyPkeys(String partyID, String srcSystem) throws ServiceProcessingException {
		LOG.debug("Inside getPartyPkeys");
		Connection jdbcConn = null;
		Statement statement = null;
		ResultSet resultSet = null;
		List<String> pkeyList = new ArrayList<String>();

		StringBuilder sql = new StringBuilder();
		sql.append("select PKEY_SRC_OBJECT from C_B_PARTY_XREF where ROWID_OBJECT = (");
		sql.append("'" + partyID.trim() + "'");
		sql.append(") and ROWID_SYSTEM in ('" + srcSystem + "')");

		LOG.debug("Query for getPartyPkeys: " + sql.toString());

		try {
			JDBCConnectionProvider jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
			jdbcConn = jDBCConnectionProvider.getJdbcConnectionFromDS();
			statement = jdbcConn.createStatement();
			resultSet = statement.executeQuery(sql.toString());

			while (resultSet.next()) {
				pkeyList.add(resultSet.getString(1));
			}
		} catch (SQLException sqlex) {
			LOG.error("Caught sql exception in getPartyPkeys()." + sqlex);
		} finally {
			try { // Closing connections
				if (resultSet != null)
					resultSet.close();
				if (statement != null)
					statement.close();
				if (jdbcConn != null)
					jdbcConn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		LOG.debug("Executed getPartyPkeys");
		return pkeyList;
	}

	public void updateErrorStatus(PartyXrefType partyXrefType, MdmUpsertPartyResponse upsertPartyResponse,
			String errorCode, String rowid) {
		LOG.debug("Execute updateErrorStatus-->" + errorCode);
		upsertPartyResponse.getUpsertStatus().setErrorCode(errorCode);
		upsertPartyResponse.getUpsertStatus().setErrorMsg(upsertPartyResponse.getStatus());
		upsertPartyResponse.getUpsertStatus().setCURRENTPROCESSSTEP(configProps.getProperty(errorCode + "_RETRY"));
		PartyUpsertRespType partyResp = new PartyUpsertRespType();
		partyResp.setROWIDOBJECT(rowid);
		partyResp.setMSGTRKNID(partyXrefType.getMSGTRKNID());
		upsertPartyResponse.getParty().add(partyResp);

	}

	public void updateErrorStatus(PartyXrefType partyXrefType, UpsertPartyResponse upsertPartyResponse,
			String errorCode, String rowid) {
		LOG.debug("Execute updateErrorStatus-->" + errorCode);
		upsertPartyResponse.setErrorCd(errorCode);
		upsertPartyResponse.setErrorMsg(upsertPartyResponse.getStatus());
		upsertPartyResponse.setStatus(upsertPartyResponse.getStatus());
		PartyUpsertRespType partyResp = new PartyUpsertRespType();
		partyResp.setROWIDOBJECT(rowid);
		upsertPartyResponse.getParty().add(partyResp);

	}
	
	public void setMsgSentFlagInTable(String rowidobject, String srcSystem) throws ServiceProcessingException {
		LOG.info("Executing setMsgSentFlagInTable()");
		StringBuffer sql = new StringBuffer();
		LOG.debug("Inside setMsgSentFlagInTable()");
		Connection jdbcConn = null;
		Statement statement = null;
		PreparedStatement pstmt = null;
		JDBCConnectionProvider jDBCConnectionProvider = null;
		int rowCnt = 0;
		if (rowidobject != null) {
			rowidobject = rowidobject.trim();

			/*
			 * sql =
			 * "update C_REPOS_MQ_DATA_CHANGE set SENT_STATE_ID = 99 where rowid_object = '"
			 * + rowidobject + "' and src_rowid_system = '"+srcSystem+
			 * "' and tgt_rowid_system IN('SAP','SBL','SFC','FNO','ADB') and SENT_STATE_ID = 0 "
			 * ;
			 */

			sql.append(
					"update c_repos_mq_data_change set sent_state_id = 99,last_update_date=sysdate where sent_state_id = 0 and rowid_mq_data_change in");
			sql.append(
					" ( select rowid_mq_data_change from c_repos_mq_data_change where rowid_table = 'SVR1.HUX' and sent_state_id = 0 and rowid_object = '"
							+ rowidobject + "'");
			sql.append(" union");
			sql.append(
					" select rowid_mq_data_change from c_repos_mq_data_change where rowid_table = 'SVR1.FSI' and sent_state_id = 0 and rowid_object in (select rowid_object from c_b_account where rowid_party = '"
							+ rowidobject + "')");
			sql.append(" union");
			sql.append(
					" select rowid_mq_data_change from c_repos_mq_data_change where rowid_table = 'SVR1.F8B' and sent_state_id = 0 and rowid_object in (select rowid_object from c_b_address where rowid_party = '"
							+ rowidobject + "')");
			sql.append(" union");
			sql.append(
					" select rowid_mq_data_change from c_repos_mq_data_change where rowid_table = 'SVR1.GMV' and sent_state_id = 0 and rowid_object in (select rowid_object from c_b_party_comm where rowid_party = '"
							+ rowidobject + "')");
			sql.append(" union");
			sql.append(
					" select rowid_mq_data_change from c_repos_mq_data_change where rowid_table = 'SVR1.FNH' and sent_state_id = 0 and rowid_object in (select rowid_object from c_b_party_classifctn where rowid_party = '"
							+ rowidobject + "')");
			sql.append(" union");
			sql.append(
					" select rowid_mq_data_change from c_repos_mq_data_change where rowid_table = 'SVR1.GHT' and sent_state_id = 0 and rowid_object in (select rowid_object from c_b_party_org_extn where rowid_party = '"
							+ rowidobject + "')");
			sql.append(" union");
			sql.append(
					" select rowid_mq_data_change from c_repos_mq_data_change where rowid_table = 'SVR1.W7MHU' and sent_state_id = 0 and rowid_object in (select rowid_object from c_b_party_person where rowid_party = '"
							+ rowidobject + "')");
			sql.append(" union");
			sql.append(
					" select rowid_mq_data_change from c_repos_mq_data_change where rowid_table = 'SVR1.W7ME9' and sent_state_id = 0 and rowid_object in (select rowid_object from c_b_party_prospect where rowid_party = '"
							+ rowidobject + "')");
			sql.append(" union");
			sql.append(
					" select rowid_mq_data_change from c_repos_mq_data_change where rowid_table = 'SVR1.G2N' and sent_state_id = 0 and rowid_object in (select rowid_object from c_b_party_rel where rowid_party_2='"
							+ rowidobject + "'))");
		}
		LOG.debug("SQL in setMsgSentFlagInTable()--> " + sql.toString());
		try {
			jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
			jdbcConn = jDBCConnectionProvider.getJdbcConnectionFromDS();

			statement = jdbcConn.createStatement();
			rowCnt = statement.executeUpdate(sql.toString());

			jdbcConn.commit();
			LOG.debug("Commited & No Of Records Updated: " + rowCnt);
			LOG.debug("Flag value updated in C_REPOS_MQ_DATA_CHANGE for party: " + rowidobject);
		} catch (SQLException exp) {
			LOG.error("Caught SQLException in setMsgSentFlagInTable() ", exp);

		} finally {
			try {
				// Closing connections
				// if (resultSet != null) resultSet.close();
				if (pstmt != null)
					pstmt.close();
				if (statement != null)
					statement.close();
				if (jdbcConn != null)
					jdbcConn.close();
			} catch (SQLException exp) {
				LOG.error("SQLexp caught in setMsgSentFlagInTable().");
			}

		}
		LOG.info("Executed setMsgSentFlagInTable()");
	}

	/**
	 * 
	 * @param rowidXrefList
	 * @param BO
	 * @return
	 * @throws ServiceProcessingException
	 */
	public List<String> getRowidsByPartyRowId(List<String> rowidXrefList, String BO) throws ServiceProcessingException {
		LOG.debug("[getRowidsByPartyRowId] ENTER");
		Connection jdbcConn = null;
		Statement statement = null;
		ResultSet resultSet = null;
		List<String> RowIdList = new ArrayList<String>();

		StringBuilder sqlQuery = new StringBuilder();
		if (BO.equalsIgnoreCase(MDMAttributeNames.PARTY_BO)) {
			sqlQuery.append(Constant.QUERY_GET_PARTY_ROWID_QUERY);
		}
		if (BO.equalsIgnoreCase(MDMAttributeNames.PARTY_ORG_BO)) {
			sqlQuery.append(Constant.QUERY_GET_ORGEXTN_ROWID_QUERY);
		} else if (BO.equalsIgnoreCase(MDMAttributeNames.CLASS_BO)) {
			sqlQuery.append(Constant.QUERY_GET_CLSFN_ROWID_QUERY);
		} else if (BO.equalsIgnoreCase(MDMAttributeNames.ADDRESS_BO)) {
			sqlQuery.append(Constant.QUERY_GET_ADDR_ROWID_QUERY);
		} else if (BO.equalsIgnoreCase(MDMAttributeNames.COMM_BO)) {
			sqlQuery.append(Constant.QUERY_GET_COMM_ROWID_QUERY);
		} else if (BO.equalsIgnoreCase(MDMAttributeNames.PARTY_PROSPECT_BO)) {
			sqlQuery.append(Constant.QUERY_GET_PROSPECT_ROWID_QUERY);
		}
		// sqlQuery.append("'" + partyID.trim() + "'" +")");
		for (String rowidXref : rowidXrefList) {
			sqlQuery.append("'" + rowidXref + "',");
		}
		sqlQuery.deleteCharAt(sqlQuery.length() - 1).toString();
		sqlQuery.append(")");

		LOG.debug("Query for getRowidsByPartyRowId: " + sqlQuery.toString());

		try {
			JDBCConnectionProvider jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
			jdbcConn = jDBCConnectionProvider.getJdbcConnectionFromDS();
			statement = jdbcConn.createStatement();
			resultSet = statement.executeQuery(sqlQuery.toString());

			while (resultSet.next()) {
				RowIdList.add(resultSet.getString(1));
			}
		} catch (SQLException sqlex) {
			LOG.error("Caught sql exception in getRowidsByPartyRowId()." + sqlex);
		} finally {
			try { // Closing connections
				if (resultSet != null)
					resultSet.close();
				if (statement != null)
					statement.close();
				if (jdbcConn != null)
					jdbcConn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		LOG.debug("Executed getRowidsByPartyRowId");
		return RowIdList;
	}

	/**
	 * 
	 * @param rowidObject
	 * @return
	 * @throws ServiceProcessingException
	 */
	public List<String> checkAdobeP2CEligible(String rowidObject) throws ServiceProcessingException {
		LOG.info("Executing checkP2CEligible()");

		Statement statement = null;
		StringBuilder sqlQry = new StringBuilder();
		JDBCConnectionProvider jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
		;
		Connection jdbcConnection = null;
		ResultSet resultSet = null;
		int recordCount = 0;
		boolean p2cEligible = false;
		List<String> RowIdXrefList = new ArrayList<String>();

		try {
			sqlQry.append(Constant.ADOBE_COUNT_FROM_PARTY_XREF);
			sqlQry.append("'" + rowidObject + "'");
			jdbcConnection = jDBCConnectionProvider.getJdbcConnectionFromDS();
			// statement =
			// jdbcConnection.prepareStatement(Constant.COUNT_FROM_PARTY_XREF);
			statement = jdbcConnection.createStatement();
			resultSet = statement.executeQuery(sqlQry.toString());
			LOG.info("Query to fetch presence of Adobe record: " + sqlQry);

			while (resultSet.next()) {
				// recordCount = resultSet.getInt(1);
				RowIdXrefList.add(resultSet.getString(1));
				LOG.info("Record  with P2C Eligible = " + resultSet.getString(1));
			}
			// LOG.info("Record with P2C Eligible = " + resultSet.getString(1));
			if (RowIdXrefList != null && RowIdXrefList.size() > 0) {
				p2cEligible = true;
			}

		} catch (SQLException sqlEx) {
			LOG.error("Exception occurred while checking the presence of Adobe Record: ", sqlEx);
			// sqlEx.printStackTrace();
			ServiceProcessingException customException = new ServiceProcessingException(sqlEx);
			customException.setMessage("Failed to check the presence of of Adobe Record: " + sqlEx.getMessage());
			throw customException;
		} finally {
			try {
				if (resultSet != null)
					resultSet.close();
				if (statement != null)
					statement.close();
				if (jdbcConnection != null)
					jdbcConnection.close();
			} catch (SQLException e) {

				e.printStackTrace();
			}
		}

		LOG.info("Executed checkP2CEligible()");

		return RowIdXrefList;
	}

	public String getStatusDesc(String statusCode) {
		String status = "";
		if (statusCode.trim().length() == 1) {
			if ("A".equals(statusCode)) {
				status = "Active";
			} else if ("I".equals(statusCode)) {
				status = "Inactive";
			} else if ("M".equals(statusCode)) {
				status = "Merger";
			} else if ("P".equals(statusCode)) {
				status = "Purge";
			} else if ("D".equals(statusCode)) {
				status = "Denied Party";
			}
		} else {
			if ("Active".equalsIgnoreCase(statusCode)) {
				status = "Active";
			} else if ("Inactive".equalsIgnoreCase(statusCode)) {
				status = "Inactive";
			} else if ("Merger".equalsIgnoreCase(statusCode)) {
				status = "Merger";
			} else if ("Purge".equalsIgnoreCase(statusCode)) {
				status = "Purge";
			} else if ("Denied Party".equalsIgnoreCase(statusCode)) {
				status = "Denied Party";
			}
		}

		return status;
	}

	private String getSystemDate() {

		Date date = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
		String str = sdf.format(date);
		return str;
	}

	public PartyXrefType preparePartyXref(PartyType prtyType, String srcPkey) {

		String currentDate = getSystemDate();

		PartyXrefType partyXrefType = new PartyXrefType();
		partyXrefType.setBOCLASSCODE(prtyType.getBOCLASSCODE());
		partyXrefType.setPARTYTYPE(Constant.PARTY_TYPE_CUSTOMER);
		partyXrefType.setSTATUSCD("Active");
		partyXrefType.setREGION(prtyType.getREGION());
		partyXrefType.setPARTYNAME(prtyType.getPARTYNAME());
		partyXrefType.setSALESBLOCKCD(prtyType.getSALESBLOCKCD());
		partyXrefType.setGEO(prtyType.getGEO());
		partyXrefType.setPHYSICALGEO(prtyType.getPHYSICALGEO());
		partyXrefType.setPHYSICALREGION(prtyType.getPHYSICALREGION());
		partyXrefType.setENGLISHNAME(prtyType.getENGLISHNAME());
		partyXrefType.setUCN(prtyType.getUCN());
		partyXrefType.setLEGACYUCN(prtyType.getLEGACYUCN());
		//partyXrefType.setLASTUPDATEDATE(currentDate);
		partyXrefType.setUPDATEBY("P2C");

		XREFType xrefType = new XREFType();
		xrefType.setSRCPKEY(srcPkey);
		xrefType.setSRCSYSTEM(Constant.SRC_SYSTEM_ADB);
		partyXrefType.getXREF().add(xrefType);

		AccountXrefType xrefAccount = null;
		if (!CollectionUtils.isEmpty(prtyType.getAccount()) && prtyType.getAccount() != null
				&& prtyType.getAccount().size() > 0) {
			xrefAccount = new AccountXrefType();
			AccountType account = prtyType.getAccount().get(0);
			xrefAccount.setSRCPKEY(srcPkey);
			xrefAccount.setSRCSYSTEM(Constant.SRC_SYSTEM_ADB);
			xrefAccount.setACCTNAME(account.getACCTNAME());
			xrefAccount.setACCTSTATUS("Active");
			xrefAccount.setACCTTYPE(account.getACCTTYPE());
			xrefAccount.setCUSTGROUP(account.getCUSTGROUP());
			xrefAccount.setDATASRCSYSTEM(account.getDATASRCSYSTEM());
			xrefAccount.setACCOUNTGEO(account.getACCOUNTGEO());
			xrefAccount.setACCOUNTREGION(account.getACCOUNTREGION());
			//xrefAccount.setLASTUPDATEDATE(currentDate);
			xrefAccount.setUPDATEBY("P2C");
			partyXrefType.getAccount().add(xrefAccount);
		}

		AddressXrefType xrefAddress = null;
		if (!CollectionUtils.isEmpty(prtyType.getAddress()) && prtyType.getAddress() != null
				&& prtyType.getAddress().size() > 0) {
			for (int i = 0; i < prtyType.getAddress().size(); i++) {
				xrefAddress = new AddressXrefType();
				AddressType address = prtyType.getAddress().get(i);
				xrefAddress.setADDRLN1(address.getADDRLN1());
				xrefAddress.setADDRLN2(address.getADDRLN2());
				xrefAddress.setADDRLN3(address.getADDRLN3());
				xrefAddress.setADDRLN4(address.getADDRLN4());
				xrefAddress.setADDRSTATUS("Active");
				xrefAddress.setADDRTYPE(Constant.ADDRESS_TYPE_BILLING);
				xrefAddress.setCITY(address.getCITY());
				String countryName = "";
				if (!Util.isNullOrEmpty(address.getCOUNTRYCD()) && address.getCOUNTRYCD().trim().length() == 2) {
					countryName = getADBCountryName(address.getCOUNTRYCD().trim());
				} else {
					countryName = address.getCOUNTRYCD();
				}
				xrefAddress.setCOUNTRYCD(countryName);

				xrefAddress.setSTATECD(address.getSTATECD());
				xrefAddress.setCOUNTY(address.getCOUNTY());
				xrefAddress.setDISTRICT(address.getDISTRICT());
				xrefAddress.setADDRMKTGPREF(address.getADDRMKTGPREF());
				xrefAddress.setLANGCD(address.getLANGCD());
				xrefAddress.setPOSTALCD(address.getPOSTALCD());
				xrefAddress.setSRCPKEY(srcPkey);
				xrefAddress.setSRCSYSTEM(Constant.SRC_SYSTEM_ADB);
				xrefAddress.setLATITUDE(address.getLATITUDE());
				xrefAddress.setLONGITUDE(address.getLONGITUDE());
				//xrefAddress.setLASTUPDATEDATE(currentDate);
				xrefAddress.setUPDATEBY("P2C");
				partyXrefType.getAddress().add(xrefAddress);
			}
		}

		CommunicationXrefType xrefComm = null;

		if (!CollectionUtils.isEmpty(prtyType.getCommunication()) && prtyType.getCommunication() != null
				&& prtyType.getCommunication().size() > 0) {
			LOG.info("Adding CommunicationXrefType in request");
			for (int i = 0; i < prtyType.getCommunication().size(); i++) {

				CommunicationType commType = prtyType.getCommunication().get(i);
				if (commType != null && !Util.isNullOrEmpty(commType.getCOMMVALUE())) {
					xrefComm = new CommunicationXrefType();
					xrefComm.setWEBDOMAIN(commType.getWEBDOMAIN());
					xrefComm.setCOMMMKTGPREF(commType.getCOMMMKTGPREF());
					xrefComm.setCOMMSALESPREF(commType.getCOMMSALESPREF());
					xrefComm.setCOMMSTATUS("Active");
					xrefComm.setCOMMTYPE(commType.getCOMMTYPE());
					xrefComm.setCOMMVALUE(commType.getCOMMVALUE());
					xrefComm.setPRFRDCOMMIND(commType.getPRFRDCOMMIND());
					xrefComm.setSRCPKEY(srcPkey);
					xrefComm.setSRCSYSTEM(Constant.SRC_SYSTEM_ADB);
					//xrefComm.setLASTUPDATEDATE(currentDate);
					xrefComm.setUPDATEBY("P2C");
					partyXrefType.getCommunication().add(xrefComm);
				}
			}
		}
		return partyXrefType;

	}

	private String getADBCountryName(String countrycd) {
		LOG.debug("Inside getADBCountryName()");
		PreparedStatement statement = null;
		Connection jdbcConn = null;
		ResultSet resultSet = null;
		String countryName = null;
		JDBCConnectionProvider jDBCConnectionProvider = null;
		try {
			jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
			jdbcConn = jDBCConnectionProvider.getJdbcConnectionFromDS();
			LOG.info("getADBCountryName  countrycode : " + countrycd);
			StringBuilder sql = new StringBuilder();
			sql.append("select ADB_COUNTRY_NM from MDM_COUNTRY where ADB_COUNTRY_CD= ?");
			LOG.debug("SQL Generated is : " + sql.toString());
			statement = jdbcConn.prepareStatement(sql.toString());
			statement.setString(1, countrycd);
			resultSet = statement.executeQuery();
			if (resultSet.next()) {
				countryName = resultSet.getString(1);
			}
			LOG.debug("countryName value is: " + countryName);
		} catch (Exception exp) {
			exp.printStackTrace();
		} finally {
			try {
				if (resultSet != null)
					resultSet.close();
				if (statement != null)
					statement.close();
				if (jdbcConn != null)
					jdbcConn.close();
			} catch (SQLException exp) {
				LOG.error("Caught SQLException in getFNOCountryCName().");
			}

		}
		return countryName;
	}

	public List<String> getRowidsByPartyRowId(String rowidParty, String BO) throws ServiceProcessingException {
		LOG.debug("[getRowidsByPartyRowId] ENTER");
		Connection jdbcConn = null;
		Statement statement = null;
		ResultSet resultSet = null;
		List<String> RowIdList = new ArrayList<String>();

		StringBuilder sqlQuery = new StringBuilder();

		if (BO.equalsIgnoreCase(MDMAttributeNames.PARTY_ORG_BO)) {
			sqlQuery.append(Constant.ADOBE_QUERY_GET_ORGEXTN_ROWID_QUERY);
		} else if (BO.equalsIgnoreCase(MDMAttributeNames.CLASS_BO)) {
			sqlQuery.append(Constant.ADOBE_QUERY_GET_CLSFN_ROWID_QUERY);
		} else if (BO.equalsIgnoreCase(MDMAttributeNames.PARTY_PROSPECT_BO)) {
			sqlQuery.append(Constant.ADOBE_QUERY_GET_PROSPECT_ROWID_QUERY);
		}

		sqlQuery.append("'" + rowidParty + "'");
		LOG.debug("Query for getRowidsByPartyRowId: " + sqlQuery.toString());

		try {
			JDBCConnectionProvider jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
			jdbcConn = jDBCConnectionProvider.getJdbcConnectionFromDS();
			statement = jdbcConn.createStatement();
			resultSet = statement.executeQuery(sqlQuery.toString());

			while (resultSet.next()) {
				RowIdList.add(resultSet.getString(1));
			}
		} catch (SQLException sqlex) {
			LOG.error("Caught sql exception in getRowidsByPartyRowId()." + sqlex);
		} finally {
			try { // Closing connections
				if (resultSet != null)
					resultSet.close();
				if (statement != null)
					statement.close();
				if (jdbcConn != null)
					jdbcConn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		LOG.debug("Executed getRowidsByPartyRowId");
		return RowIdList;
	}

	public void updateCI(String rowid, boolean isContact) {
		LOG.debug("Inside updateCI()");
		Connection jdbcConn = null;
		Statement statement = null;
		JDBCConnectionProvider jDBCConnectionProvider = null;

		String party = "UPDATE C_B_PARTY SET CONSOLIDATION_IND='1' WHERE ROWID_OBJECT='" + rowid
				+ "' and CONSOLIDATION_IND='4'";
		String account = "UPDATE C_B_ACCOUNT SET CONSOLIDATION_IND='1' WHERE ROWID_PARTY='" + rowid
				+ "' and CONSOLIDATION_IND='4'";
		String address = "UPDATE C_B_ADDRESS SET CONSOLIDATION_IND='1' WHERE ROWID_PARTY='" + rowid
				+ "' and CONSOLIDATION_IND='4'";
		String person = "UPDATE C_B_PARTY_PERSON SET CONSOLIDATION_IND='1' WHERE ROWID_PARTY='" + rowid
				+ "' and CONSOLIDATION_IND='4'";
		String comm = "UPDATE C_B_PARTY_COMM SET CONSOLIDATION_IND='1' WHERE ROWID_PARTY='" + rowid
				+ "' and CONSOLIDATION_IND='4'";

		try {
			jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
			jdbcConn = jDBCConnectionProvider.getJdbcConnectionFromDS();
			// jdbcConn.setAutoCommit(false);
			statement = jdbcConn.createStatement();
			statement.addBatch(party);
			statement.addBatch(address);
			if (isContact) {
				statement.addBatch(person);
			} else {
				statement.addBatch(account);
			}
			statement.addBatch(comm);
			statement.executeBatch();
			// jdbcConn.commit();
			LOG.debug("CONSOLIDATION_IND Update is completed for rowid:" + rowid);

		} catch (Exception exp) {
			LOG.error("Caught SQLException in updateCI() " + exp.getMessage());

		} finally {
			try {

				if (statement != null)
					statement.close();
			} catch (SQLException exp) {
				LOG.error("Caught SQLException in updateCI() " + exp.getMessage());
			}
			try {
				if (jdbcConn != null)
					jdbcConn.close();
			} catch (SQLException exp) {
				LOG.error("Caught SQLException in updateCI() " + exp.getMessage());
			}
		}

		LOG.debug(" Executed updateCI() successfully ");
	}

	public boolean fetchErrorMsg(String rootExceptionMsg) {
		LOG.debug("Inside fetchErrorMsg");
		boolean isDataError = false;
		String errorMsg = "";
		if (!Util.isNullOrEmpty(rootExceptionMsg)) {
			rootExceptionMsg = rootExceptionMsg.replaceAll("\n", "").replaceAll("\r", "");
			if (rootExceptionMsg.contains("SIP-23015")) {
				isDataError = true;
				/*
				 * String errorArray[] = rootExceptionMsg.split("SIP-23015:");
				 * if(errorArray.length>0){ for(String error : errorArray)
				 * errorMsg = error.replaceAll(
				 * "Review the server log for more details.", "").replaceAll(
				 * "ERROR: Foreign key", "").replaceAll("null",
				 * "empty/null/unknown/junk"); LOG.debug("errorMsg::"+errorMsg);
				 * }
				 */
			}
		}
		return isDataError;
	}

	public void updateMergeExclusionList(String srcpkey, String oprCode) {
		LOG.debug("Inside updateMergeExclusionList()");
		Connection jdbcConn = null;
		Statement statement = null;
		ResultSet resultSet = null;
		JDBCConnectionProvider jDBCConnectionProvider = null;
		int rowCnt = 0;
		StringBuilder sqlQry = new StringBuilder();
		sqlQry.append("select count(1) from MERGE_EXCLUSION_LIST where SAP_CUST_NO='" + srcpkey + "'");

		LOG.debug("SQL in select MERGE_EXCLUSION_LIST --> " + sqlQry);

		try {
			jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
			jdbcConn = jDBCConnectionProvider.getJdbcConnectionFromDS();
			statement = jdbcConn.createStatement();
			resultSet = statement.executeQuery(sqlQry.toString());
			while (resultSet.next()) {
				rowCnt = resultSet.getInt(1);
			}
			String query = "";
			if ("INSERT".equalsIgnoreCase(oprCode) && rowCnt == 0) {
				query = "Insert into MERGE_EXCLUSION_LIST (SAP_CUST_NO,REASON) values ('" + srcpkey + "',null)";
				LOG.debug(query);
				statement.executeUpdate(query);
			}
			if ("DELETE".equalsIgnoreCase(oprCode) && rowCnt > 0) {
				query = "DELETE FROM MERGE_EXCLUSION_LIST where SAP_CUST_NO='" + srcpkey + "'";
				LOG.debug(query);
				statement.executeUpdate(query);
			}

		} catch (ServiceProcessingException exp) {
			LOG.error("Caught SQLException in updateMergeExclusionList() ", exp);

		} catch (SQLException exp) {
			LOG.error("Caught SQLException in updateMergeExclusionList() ", exp);

		} finally {
			try {
				// Closing connections
				if (resultSet != null)
					resultSet.close();
				if (statement != null)
					statement.close();
				if (jdbcConn != null)
					jdbcConn.close();
			} catch (SQLException exp) {
				LOG.error("SQLexp caught in updateMergeExclusionList(): ", exp);
			}

		}

		LOG.debug(" Executed updateMergeExclusionList() successfully ");
	}

	public boolean isPartyBillingAddressExist(List<AddressType> addressList) {
		boolean isBillingExist = false;
		AddressType addrParam = null;
		for (int i = 0; i < addressList.size(); i++) {
			addrParam = addressList.get(i);
			if (addrParam.getADDRTYPE().equalsIgnoreCase(Constant.ADDRESS_TYPE_BILLING)) {
				isBillingExist = true;
				break;
			}

		}

		return isBillingExist;
	}

	public List<Address> popoulateAddress(List<AddressType> addressList, String addrType) {
		List<Address> finalAddressList = new ArrayList<Address>();
		AddressType addrParam = null;
		Address addr = null;
		if (addressList != null && addressList.size() > 0) {
			for (int i = 0; i < addressList.size(); i++) {
				addrParam = addressList.get(i);
				if (addrParam != null && addrParam.getADDRTYPE().equalsIgnoreCase(addrType)) {
					addr = new Address();
					addr.setROWIDADDRESS(addrParam.getROWIDADDRESS().trim());
					addr.setADDRLN1(addrParam.getADDRLN1());
					addr.setADDRLN2(addrParam.getADDRLN2());
					addr.setADDRLN3(addrParam.getADDRLN3());
					addr.setADDRLN4(addrParam.getADDRLN4());
					addr.setCITY(addrParam.getCITY());
					addr.setCOUNTY(addrParam.getCOUNTY());
					addr.setDISTRICT(addrParam.getDISTRICT());
					addr.setSTATECD(addrParam.getSTATECD());
					addr.setPOSTALCD(addrParam.getPOSTALCD());
					addr.setCOUNTRYCD(addrParam.getCOUNTRYCD());
					addr.setLANGCD(addrParam.getLANGCD());
					addr.setLONGITUDE(addrParam.getLONGITUDE());
					addr.setLATITUDE(addrParam.getLATITUDE());
					addr.setADDRTYPE(addrParam.getADDRTYPE());
					addr.setADDRSTATUS(addrParam.getADDRSTATUS());
					if (addr.getADDRSTATUS().equalsIgnoreCase("A") || addr.getADDRSTATUS().equalsIgnoreCase("I")
							|| addr.getADDRSTATUS().equalsIgnoreCase("D")) {
						LOG.info("===Inserting into Address List===");
						finalAddressList.add(addr);
						break;
					}
				}
			}
		}
		return finalAddressList;
	}
	
	public boolean checkActiveOrgExtnExist(String rowidObject) throws ServiceProcessingException {
		LOG.info("Executing checkActiveOrgExtnExist()");

		Statement statement = null;
		StringBuilder sqlQry = new StringBuilder();
		JDBCConnectionProvider jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
		;
		Connection jdbcConnection = null;
		ResultSet resultSet = null;
		int recordCount = 0;
		boolean dupRecordExist = false;

		try {
			sqlQry.append(Constant.QUERY_GET_DUPLICATE_ORGEXTN_EXIST);
			sqlQry.append("'" + rowidObject + "'");
			jdbcConnection = jDBCConnectionProvider.getJdbcConnectionFromDS();
			statement = jdbcConnection.createStatement();
			resultSet = statement.executeQuery(sqlQry.toString());
			LOG.info("Query to fetch presence of Active org extn Active record: " + sqlQry);

			while (resultSet.next()) {
				recordCount = resultSet.getInt(1);

			}
			LOG.info("Record count with duplicate org extn  Active  = " + recordCount);
			if (recordCount > 0) {
				dupRecordExist = true;
			}

		} catch (SQLException sqlEx) {
			LOG.error("Exception occurred while checking the presence of active org extn  of SFC Record: ", sqlEx);
			// sqlEx.printStackTrace();
			ServiceProcessingException customException = new ServiceProcessingException(sqlEx);
			customException.setMessage(
					"Failed to check the presence of active org extn  of SFC Record: " + sqlEx.getMessage());
			throw customException;
		} finally {
			try {
				if (resultSet != null)
					resultSet.close();
				if (statement != null)
					statement.close();
				if (jdbcConnection != null)
					jdbcConnection.close();
			} catch (SQLException e) {

				e.printStackTrace();
			}
		}

		LOG.info("Executed checkActiveOrgExtnExist()");

		return dupRecordExist;
	}
	
	
	public boolean checkActiveClsfncExist(String rowidObject) throws ServiceProcessingException {
		LOG.info("Executing checkActiveClsfncExist()");

		PreparedStatement statement = null;
		StringBuilder sqlQry = new StringBuilder();
		JDBCConnectionProvider jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
		;
		Connection jdbcConnection = null;
		ResultSet resultSet = null;
		int recordCount = 0;
		boolean dupRecordExist = false;

		try {
			sqlQry.append(Constant.QUERY_GET_ACTIVE_CLASFCTN_EXIST);
			// sqlQry.append("'"+rowidObject + "'");
			jdbcConnection = jDBCConnectionProvider.getJdbcConnectionFromDS();
			statement = jdbcConnection.prepareStatement(sqlQry.toString());
			statement.setString(1, rowidObject);
			resultSet = statement.executeQuery();
			// resultSet = statement.executeQuery(sqlQry.toString());
			LOG.info("Query to fetch presence of duplicate classification Active record: " + sqlQry);

			while (resultSet.next()) {

				recordCount = resultSet.getInt(1);
				LOG.info("Query to fetch presence of duplicate classification count for Active record: " + recordCount);
				if (recordCount > 0) {
					dupRecordExist = true;
					break;
				}

			}
			LOG.info("Record count with duplicate classification  Active  = " + recordCount);

		} catch (SQLException sqlEx) {
			LOG.error("Exception occurred while checking the presence of duplicate classification  of SFC Record: ",
					sqlEx);
			// sqlEx.printStackTrace();
			ServiceProcessingException customException = new ServiceProcessingException(sqlEx);
			customException.setMessage(
					"Failed to check the presence of duplicate classification  of SFC Record: " + sqlEx.getMessage());
			throw customException;
		} finally {
			try {
				if (resultSet != null)
					resultSet.close();
				if (statement != null)
					statement.close();
				if (jdbcConnection != null)
					jdbcConnection.close();
			} catch (SQLException e) {

				e.printStackTrace();
			}
		}

		LOG.info("Executed checkActiveClsfncExist()");

		return dupRecordExist;
	}
	public boolean checkActiveOrgExtnXrefExist(String rowidObject) throws ServiceProcessingException {
		LOG.info("Executing checkActiveOrgExtnXrefExist()");

		PreparedStatement statement = null;
		StringBuilder sqlQry = new StringBuilder();
		JDBCConnectionProvider jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
		;
		Connection jdbcConnection = null;
		ResultSet resultSet = null;
		int recordCount = 0;
		boolean dupRecordExist = false;

		try {
			sqlQry.append(Constant.QUERY_GET_ACTIVE_ORGEXTN_XREF_EXIST);
			jdbcConnection = jDBCConnectionProvider.getJdbcConnectionFromDS();
			statement = jdbcConnection.prepareStatement(sqlQry.toString());
			statement.setString(1, rowidObject);
			resultSet = statement.executeQuery();
			LOG.info("Query to fetch presence of Active org extn Active record: " + sqlQry);

			while (resultSet.next()) {
				recordCount = resultSet.getInt(1);

			}
			LOG.info("Record count with duplicate org extn  Active  = " + recordCount);
			if (recordCount > 0) {
				dupRecordExist = true;
			}

		} catch (SQLException sqlEx) {
			LOG.error("Exception occurred while checking the presence of active org extn  of SFC Record: ", sqlEx);
			// sqlEx.printStackTrace();
			ServiceProcessingException customException = new ServiceProcessingException(sqlEx);
			customException.setMessage(
					"Failed to check the presence of active org extn  of SFC Record: " + sqlEx.getMessage());
			throw customException;
		} finally {
			try {
				if (resultSet != null)
					resultSet.close();
				if (statement != null)
					statement.close();
				if (jdbcConnection != null)
					jdbcConnection.close();
			} catch (SQLException e) {

				e.printStackTrace();
			}
		}

		LOG.info("Executed checkActiveOrgExtnXrefExist()");

		return dupRecordExist;
	}
	
	
	public boolean checkActiveClsfnXrefcExist(String rowidObject) throws ServiceProcessingException {
		LOG.info("Executing checkActiveClsfnXrefcExist()");

		PreparedStatement statement = null;
		StringBuilder sqlQry = new StringBuilder();
		JDBCConnectionProvider jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
		;
		Connection jdbcConnection = null;
		ResultSet resultSet = null;
		int recordCount = 0;
		boolean dupRecordExist = false;

		try {
			sqlQry.append(Constant.QUERY_GET_ACTIVE_CLASFCTN_XREF_EXIST);
			// sqlQry.append("'"+rowidObject + "'");
			jdbcConnection = jDBCConnectionProvider.getJdbcConnectionFromDS();
			statement = jdbcConnection.prepareStatement(sqlQry.toString());
			statement.setString(1, rowidObject);
			resultSet = statement.executeQuery();
			// resultSet = statement.executeQuery(sqlQry.toString());
			LOG.info("Query to fetch presence of duplicate classification Active record: " + sqlQry);

			while (resultSet.next()) {

				recordCount = resultSet.getInt(1);
				LOG.info("Query to fetch presence of duplicate classification count for Active record: " + recordCount);
				if (recordCount > 0) {
					dupRecordExist = true;
					break;
				}

			}
			LOG.info("Record count with duplicate classification  Active  = " + recordCount);

		} catch (SQLException sqlEx) {
			LOG.error("Exception occurred while checking the presence of duplicate classification  of SFC Record: ",
					sqlEx);
			// sqlEx.printStackTrace();
			ServiceProcessingException customException = new ServiceProcessingException(sqlEx);
			customException.setMessage(
					"Failed to check the presence of duplicate classification  of SFC Record: " + sqlEx.getMessage());
			throw customException;
		} finally {
			try {
				if (resultSet != null)
					resultSet.close();
				if (statement != null)
					statement.close();
				if (jdbcConnection != null)
					jdbcConnection.close();
			} catch (SQLException e) {

				e.printStackTrace();
			}
		}

		LOG.info("Executed checkActiveClsfnXrefcExist()");

		return dupRecordExist;
	}
	
	public boolean checkActiveOrgExtnXrefExistById(String rowidObject) throws ServiceProcessingException {
		LOG.info("Executing checkActiveOrgExtnXrefExistById()");

		PreparedStatement statement = null;
		StringBuilder sqlQry = new StringBuilder();
		JDBCConnectionProvider jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
		;
		Connection jdbcConnection = null;
		ResultSet resultSet = null;
		int recordCount = 0;
		boolean dupRecordExist = false;

		try {
			sqlQry.append(Constant.QUERY_GET_ACTIVE_ORGEXTN_XREF_EXIST_BY_PTYID);
			jdbcConnection = jDBCConnectionProvider.getJdbcConnectionFromDS();
			statement = jdbcConnection.prepareStatement(sqlQry.toString());
			statement.setString(1, rowidObject);
			resultSet = statement.executeQuery();
			LOG.info("Query to fetch presence of Active org extn Active record: " + sqlQry);

			while (resultSet.next()) {
				recordCount = resultSet.getInt(1);

			}
			LOG.info("Record count with duplicate org extn  Active  = " + recordCount);
			if (recordCount > 0) {
				dupRecordExist = true;
			}

		} catch (SQLException sqlEx) {
			LOG.error("Exception occurred while checking the presence of active org extn  of SFC Record: ", sqlEx);
			// sqlEx.printStackTrace();
			ServiceProcessingException customException = new ServiceProcessingException(sqlEx);
			customException.setMessage(
					"Failed to check the presence of active org extn  of SFC Record: " + sqlEx.getMessage());
			throw customException;
		} finally {
			try {
				if (resultSet != null)
					resultSet.close();
				if (statement != null)
					statement.close();
				if (jdbcConnection != null)
					jdbcConnection.close();
			} catch (SQLException e) {

				e.printStackTrace();
			}
		}

		LOG.info("Executed checkActiveOrgExtnXrefExistById()");

		return dupRecordExist;
	}
	
	
	public boolean checkActiveClsfnXrefcExistById(String rowidObject) throws ServiceProcessingException {
		LOG.info("Executing checkActiveClsfnXrefcExistById()");

		PreparedStatement statement = null;
		StringBuilder sqlQry = new StringBuilder();
		JDBCConnectionProvider jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
		;
		Connection jdbcConnection = null;
		ResultSet resultSet = null;
		int recordCount = 0;
		boolean dupRecordExist = false;

		try {
			sqlQry.append(Constant.QUERY_GET_ACTIVE_CLASFCTN_XREF_EXIST_BY_PTYID);
			// sqlQry.append("'"+rowidObject + "'");
			jdbcConnection = jDBCConnectionProvider.getJdbcConnectionFromDS();
			statement = jdbcConnection.prepareStatement(sqlQry.toString());
			statement.setString(1, rowidObject);
			resultSet = statement.executeQuery();
			// resultSet = statement.executeQuery(sqlQry.toString());
			LOG.info("Query to fetch presence of duplicate classification Active record: " + sqlQry);

			while (resultSet.next()) {

				recordCount = resultSet.getInt(1);
				LOG.info("Query to fetch presence of duplicate classification count for Active record: " + recordCount);
				if (recordCount > 0) {
					dupRecordExist = true;
					break;
				}

			}
			LOG.info("Record count with duplicate classification  Active  = " + recordCount);

		} catch (SQLException sqlEx) {
			LOG.error("Exception occurred while checking the presence of duplicate classification  of SFC Record: ",
					sqlEx);
			// sqlEx.printStackTrace();
			ServiceProcessingException customException = new ServiceProcessingException(sqlEx);
			customException.setMessage(
					"Failed to check the presence of duplicate classification  of SFC Record: " + sqlEx.getMessage());
			throw customException;
		} finally {
			try {
				if (resultSet != null)
					resultSet.close();
				if (statement != null)
					statement.close();
				if (jdbcConnection != null)
					jdbcConnection.close();
			} catch (SQLException e) {

				e.printStackTrace();
			}
		}

		LOG.info("Executed checkActiveClsfnXrefcExistById()");

		return dupRecordExist;
	}
	
	public static Calendar convertStringToCalendar_TZ(String inputDate) {
		LOG.debug(" Executing convertStringToCalendar()." + inputDate);
		String dateformat = null;
		if (!Util.isNullOrEmpty(inputDate) && inputDate.length() == 10) {
			dateformat = "yyyy-MM-dd";
		} else if (!Util.isNullOrEmpty(inputDate) && inputDate.length() > 10) {
			dateformat = "yyyy-MM-dd HH:mm:ss";
		}
		DateFormat sdf = new SimpleDateFormat(dateformat);
		// DateFormat sdf = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
		// String convertedDate = null;
		Calendar cal = Calendar.getInstance();
		Date dateObject = null;

		if (!Util.isNullOrEmpty(inputDate)) {
			LOG.debug("InputDate from request: " + inputDate);
			try {
				dateObject = sdf.parse(inputDate);
				cal.setTime(dateObject);
				// convertedDate = sdf.format(dateObject);
				LOG.debug("Converted dateObject: " + cal.getTime());
			} catch (ParseException pexp) {
				LOG.error("Parse Exception in convertStringToCalendar(): ", pexp);
			}
		}
		cal.setTimeZone(TimeZone.getTimeZone("CST"));
		LOG.info("Date after Timezone conversion"+cal.getTime());
		LOG.debug(" Executed convertStringToCalendar().");
		return cal;
	}
	
	public static StringBuffer checkBothDnbandParentExist(String rowid, String matchedrowid) throws ServiceProcessingException {
		LOG.debug("[checkBothDnbandParentExist] Enter");
		String parentFlag = null;
		String dnbFlag = null;
		Connection jdbcConn = null;
		StringBuffer sBuffer = new StringBuffer(5);
        
		if (rowid != null && matchedrowid != null) {
			CallableStatement callStmt = null;
			try {
				JDBCConnectionProvider jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
				jdbcConn = jDBCConnectionProvider.getJdbcConnectionFromDS();
				callStmt = jdbcConn.prepareCall("{call PROC_CHK_DNB_AND_PARENT_EXIST(?,?,?,?,?)}");
				callStmt.setString(1, rowid);
				callStmt.setString(2, matchedrowid);
				callStmt.registerOutParameter(3, OracleTypes.VARCHAR);
				callStmt.registerOutParameter(4, OracleTypes.VARCHAR);
				callStmt.registerOutParameter(5, OracleTypes.VARCHAR);
				LOG.debug("[checkBothDnbandParentExist] Calling   PROC_CHK_DNB_AND_PARENT_EXIST" + " for ROWID::" + rowid);
				callStmt.execute();
				parentFlag = callStmt.getString(4);
				dnbFlag = callStmt.getString(5);
				sBuffer.append(parentFlag).append(dnbFlag);
				LOG.debug("[checkBothDnbandParentExist] Calling   PROC_CHK_DNB_AND_PARENT_EXIST" + 
				" for parentFlag::" + parentFlag + "  DnB Flag::"+ dnbFlag + "  sBuffer::" + sBuffer);
			} catch (SQLException sqlex) {
				LOG.error("Caught sql exception in checkBothDnbandParentExist()." + sqlex);
			} finally {
				if (callStmt != null) {
					try {
						callStmt.close();
					} catch (SQLException e) {
					}
				}
			}

		}
		LOG.debug("[checkBothDnbandParentExist] Exit");
		return sBuffer;
	}
}
