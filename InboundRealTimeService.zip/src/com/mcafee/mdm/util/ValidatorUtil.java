package com.mcafee.mdm.util;

import java.util.List;
import java.util.Properties;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.mcafee.mdm.constants.Constant;
import com.mcafee.mdm.dao.ProspectPartyDAO;
import com.mcafee.mdm.exception.ServiceProcessingException;
import com.mcafee.mdm.generated.AddressXrefType;
import com.mcafee.mdm.generated.CommunicationXrefType;
import com.mcafee.mdm.generated.MdmUpsertPartyResponse;
import com.mcafee.mdm.generated.PartyUpsertRespType;
import com.mcafee.mdm.generated.PartyXrefType;
import com.mcafee.mdm.generated.StatusType;

@Component
public class ValidatorUtil {

	private static final Logger LOG = Logger.getLogger(ValidatorUtil.class.getName());

	Properties configProps = PropertyUtil.getPropertiesFromFile("configProp");

	@Resource(name = "m4mMessagesProp")
	private Properties messagesProp;

	@Autowired
	private ProspectPartyDAO prospectPartyDAO;

	/**
	 * Validate account address for Junk condition
	 * 
	 * @param curParty
	 * @param upsertResponse
	 * @return
	 * @throws ServiceProcessingException
	 */
	public boolean validateAccountAddressJunk(PartyXrefType curParty, MdmUpsertPartyResponse upsertResponse)
			throws ServiceProcessingException {
		LOG.debug("[validateAccountAddressJunk] START");
		Boolean isValid = Boolean.TRUE;
		boolean junkAddressLn1 = Boolean.FALSE;
		boolean junkCity = Boolean.FALSE;

		try {
			String srcPkey = curParty.getXREF().get(0).getSRCPKEY();
			String addressLn1 = curParty.getAddress().get(0).getADDRLN1();
			String city = curParty.getAddress().get(0).getCITY();
			if (!Util.isNullOrEmpty(addressLn1)) {
				junkAddressLn1 = prospectPartyDAO.isJunkAddressLn1(addressLn1);
				if (junkAddressLn1) {
					isValid = Boolean.FALSE;
					LOG.info(" Junk in AdressLn1 found : " + junkAddressLn1);
					createUpsertInfoMessage(upsertResponse, Constant.INFO_ADDRESS_UNKNOWN_JUNK, srcPkey);
					upsertResponse.setErrorCd(Constant.ERROR_ACCOUNT_ADDR_LN1_UNKWN);

				}
			}
			if (!Util.isNullOrEmpty(city)) {
				junkCity = prospectPartyDAO.isJunkCity(city);
				if (junkCity) {
					isValid = Boolean.FALSE;
					LOG.info("Junk Value in CITY found : " + junkCity);
					createUpsertInfoMessage(upsertResponse, Constant.INFO_ADDRESS_UNKNOWN_JUNK, srcPkey);
					upsertResponse.setErrorCd(Constant.ERROR_ACCOUNT_CITY_UNKWN);
				}

			}
		} catch (Exception sqlEx) {
			LOG.error("Exception occurred in validateAccountAddressJunk: ", sqlEx);
			upsertResponse.setErrorMsg("DQ Check Fail On Address");
			ServiceProcessingException customException = new ServiceProcessingException(sqlEx);
			customException
					.setMessage("Custom Exception occurred in validateAccountAddressJunk: " + sqlEx.getMessage());
			updateErrorStatus(curParty, upsertResponse, Constant.ERROR_ACCOUNT_DQ_CHECK_FAIL, "0");
			throw customException;
		}
		LOG.debug("[validateAccountAddressJunk] EXIT::isValid::" + isValid);
		return isValid;

	}

	/**
	 * validate input ACCOUNT_NAME for Empty, Null, Unknown, Junk Value
	 * 
	 * @param curParty
	 * @param upsertResponse
	 * @throws ServiceProcessingException
	 */
	public boolean validateAccountName(PartyXrefType curParty, MdmUpsertPartyResponse upsertResponse)
			throws ServiceProcessingException {
		LOG.debug("[validateAccountName] START");
		Boolean isValid = Boolean.TRUE;
		boolean nameExclusionCond = Boolean.FALSE;

		try {
			String srcPkey = curParty.getXREF().get(0).getSRCPKEY();
			String partyType = curParty.getPARTYTYPE();
			if (!Util.isNullOrEmpty(curParty.getPARTYNAME())
					&& !(curParty.getPARTYNAME().equalsIgnoreCase("Unknown"))) {
				LOG.info("Given party name : " + curParty.getPARTYNAME()+":");
				String accountName = curParty.getPARTYNAME();
				nameExclusionCond = prospectPartyDAO.isNameExclusionExists(accountName);
				if (nameExclusionCond) {
					isValid = Boolean.FALSE;
					LOG.info("Junk Value in Prospect ACCOUNT_NAME is found :" + nameExclusionCond);
					if(!Util.isNullOrEmpty(curParty.getPARTYTYPE())){
					if((curParty.getPARTYTYPE().equalsIgnoreCase(Constant.PARTY_TYPE_PROSPECT_ACCOUNT))){
						createUpsertInfoMessage(upsertResponse, Constant.INFO_PROSPECT_ACCOUNT_NAME_UNKWN, srcPkey);
					}else{
					createUpsertInfoMessage(upsertResponse, Constant.INFO_ACCOUNT_NAME_UNKWN, srcPkey);
					}
					}
					upsertResponse.setErrorCd(Constant.ERROR_ACCOUNT_NAME_UNKWN);
				}
			} else {
				LOG.info("Given party name : " + curParty.getPARTYNAME()+":");
				isValid = Boolean.FALSE;
				createUpsertInfoMessage(upsertResponse, Constant.ERROR_ACCOUNT_EMPTY_NAME, srcPkey);
			}
		} catch (Exception sqlEx) {
			LOG.error("Exception occurred in validateAccountName: ", sqlEx);
			// sqlEx.printStackTrace();
			upsertResponse.setErrorMsg("DQ Check Fail On Account Name");
			ServiceProcessingException customException = new ServiceProcessingException(sqlEx);
			customException.setMessage("Custom Exception occurred in validateAccountName: " + sqlEx.getMessage());
			updateErrorStatus(curParty, upsertResponse, Constant.ERROR_ACCOUNT_DQ_CHECK_FAIL, "0");
			throw customException;

		}
		LOG.debug("[validateAccountName] EXIT::isValid::" + isValid);
		return isValid;
	}

	/**
	 * Validate Account address for Empty, null, Unknown
	 * 
	 * @param curParty
	 * @param upsertResponse
	 * @param placeID
	 * @return
	 * @throws ServiceProcessingException
	 */
	public boolean validateAccountAddressNullUnknown(PartyXrefType curParty, MdmUpsertPartyResponse upsertResponse,
			String placeID) throws ServiceProcessingException {
		LOG.debug("[validateAccountLocationNullUnknown] START");
		Boolean isValid = Boolean.TRUE;
		try {
			String srcPkey = curParty.getXREF().get(0).getSRCPKEY();

			List<AddressXrefType> addressXrefTypeList = curParty.getAddress();
			if (!CollectionUtils.isEmpty(addressXrefTypeList)) {
				String location = null;
				if (placeID.equalsIgnoreCase("Addressline1")) {
					location = curParty.getAddress().get(0).getADDRLN1();
					LOG.info("address line 1 : " + location );
				} else if (placeID.equalsIgnoreCase("City")) {
					location = curParty.getAddress().get(0).getCITY();
					LOG.info("city : " + location );
				} else if (placeID.equalsIgnoreCase("State")) {
					location = curParty.getAddress().get(0).getSTATECD();
					LOG.info("state : " + location );
				} else if (placeID.equalsIgnoreCase("Country")) {
					location = curParty.getAddress().get(0).getCOUNTRYCD();
					LOG.info("country : " + location );
				} else if (placeID.equalsIgnoreCase("PostalCode")) {
					location = curParty.getAddress().get(0).getPOSTALCD();
					LOG.info("postalcode: " + location );
				}

				if (Util.isNullOrEmpty(location) || location.trim().equalsIgnoreCase("Unknown")) {
					isValid = Boolean.FALSE;
					LOG.info(" Account " + placeID + " null or UnKnown  found :" + isValid);
					createUpsertInfoMessage(upsertResponse, Constant.INFO_ADDRESS_UNKNOWN_JUNK, srcPkey);
					if (Constant.BO_CLASS_CODE_PERSON.equalsIgnoreCase(curParty.getPARTYTYPE())) {
						upsertResponse.setErrorCd(Constant.ERROR_CONTACT_ADDR_INVALID);
					}else{
						upsertResponse.setErrorCd(Constant.ERROR_ACCOUNT_ADDR_INVALID);
					}
				}
			}
		} catch (Exception sqlEx) {
			LOG.error("Exception occurred in validateAccountAddressNullUnknown : ", sqlEx);
			// sqlEx.printStackTrace();
			upsertResponse.setErrorMsg("DQ Check Fail On Address");
			ServiceProcessingException customException = new ServiceProcessingException(sqlEx);
			customException.setMessage(
					"Custom Exception occurred in Account validateAddress for null or UnKnown: " + sqlEx.getMessage());
			if (Constant.BO_CLASS_CODE_PERSON.equalsIgnoreCase(curParty.getPARTYTYPE())) {
				updateErrorStatus(curParty, upsertResponse, Constant.ERROR_CONTACT_DQ_CHECK_FAIL, "0");
			}else{
				updateErrorStatus(curParty, upsertResponse, Constant.ERROR_ACCOUNT_DQ_CHECK_FAIL, "0");
			}
			throw customException;
		}
		LOG.debug("[validateAccountAddressNullUnknown] EXIT::isValid::" + isValid);
		return isValid;

	}

	/**
	 * Create Info messages for upsert
	 * 
	 * @param upsertResponse
	 * @param errorPropId
	 * @param srcPkey
	 */
	public void createUpsertInfoMessage(MdmUpsertPartyResponse upsertResponse, String infoPropId, String srcPkey) {
		LOG.debug("[createUpsertInfoMessage] START::srcPkey::" + srcPkey);
		String respMsg = null;
		if (srcPkey == null) {
			respMsg = messagesProp.getProperty(infoPropId);
		} else {
			respMsg = "SRC PKEY::" + srcPkey + "::" + messagesProp.getProperty(infoPropId);
		}
		if (Util.isNullOrEmpty(upsertResponse.getStatus())) {
			upsertResponse.setStatus(respMsg);
		} else {
			upsertResponse.setStatus(upsertResponse.getStatus() + "\n" + respMsg);
		}
		System.out.println(" in create upsertInfoMessage" + respMsg);
		LOG.debug("[createUpsertInfoMessage] EXIT");
	}

	/**
	 * Validating message tracking id for null or empty
	 * 
	 * @param curParty
	 * @param upsertResponse
	 * @throws ServiceProcessingException
	 */
	public void validateMsgTrackingId(PartyXrefType curParty, MdmUpsertPartyResponse upsertResponse, boolean adobe)
			throws ServiceProcessingException {
		LOG.debug("[validateMsgTrackingId] ENTER");
		try {
			if (Util.isNullOrEmpty(curParty.getMSGTRKNID())) {
				upsertResponse.setUpsertStatus(new StatusType());
				String respMsg = "No Message Tracking ID found";// messagesProp.getProperty(Constant.INFO_MSG_TRKN_ID_VALIDATION);
				if (Util.isNullOrEmpty(upsertResponse.getStatus())) {
					upsertResponse.setStatus(respMsg);
				} else {
					upsertResponse.setStatus(upsertResponse.getStatus() + "\n" + respMsg);
				}
				upsertResponse.setErrorCd(Constant.ERROR_ACCOUNT_MSG_TRKN_ID_VALIDATION);
				upsertResponse.setErrorMsg(respMsg);
				if(adobe){
				upsertResponse.setErrorCd(prospectPartyDAO.getErrorCodeByDescription(messagesProp
						.getProperty(Constant.INFO_MSG_TRKN_ID_VALIDATION)));
				}
				updateErrorStatus(curParty, upsertResponse, Constant.ERROR_ACCOUNT_MSG_TRKN_ID_VALIDATION, "0");
				throw new ServiceProcessingException(Constant.ERROR_ACCOUNT_MSG_TRKN_ID_VALIDATION);
			}
		} catch (Exception exp) {
			if (Constant.ERROR_ACCOUNT_MSG_TRKN_ID_VALIDATION.equals(exp.getMessage())) {
				updateErrorStatus(curParty, upsertResponse, Constant.ERROR_ACCOUNT_MSG_TRKN_ID_VALIDATION, "0");
			}
			throw new ServiceProcessingException(Constant.ERROR_ACCOUNT_MSG_TRKN_ID_VALIDATION);
		}
		LOG.debug("[validateMsgTrackingId] EXIT");

	}

	/**
	 * Updating error status in StatusType
	 * 
	 * @param partyXrefType
	 * @param upsertPartyResponse
	 * @param errorCode
	 * @param rowid
	 */
	public void updateErrorStatus(PartyXrefType partyXrefType, MdmUpsertPartyResponse upsertPartyResponse,
			String errorCode, String rowid) {
		LOG.debug("Execute updateErrorStatus-->" + errorCode);
		upsertPartyResponse.getUpsertStatus().setErrorCode(errorCode);
		upsertPartyResponse.getUpsertStatus().setErrorMsg(upsertPartyResponse.getStatus());
		upsertPartyResponse.getUpsertStatus().setCURRENTPROCESSSTEP(configProps.getProperty(errorCode + "_RETRY"));
		PartyUpsertRespType partyResp = new PartyUpsertRespType();
		partyResp.setROWIDOBJECT(rowid);
		partyResp.setMSGTRKNID(partyXrefType.getMSGTRKNID());
		upsertPartyResponse.getParty().add(partyResp);

	}
	
	/**
	 * validate input REPORTED_COMPANY_NAME
	 * 
	 * @param curParty
	 * @param upsertResponse
	 */
	public boolean validateCompanyName(PartyXrefType curParty, MdmUpsertPartyResponse upsertResponse) {
		LOG.debug("[validateCompanyName] START");
		Boolean isValid = Boolean.TRUE;
		boolean nameExclusionCond = Boolean.FALSE;
		
		try {
			String srcPkey = curParty.getXREF().get(0).getSRCPKEY();
			/*Checking	IF REPORTED_COMPANY_NAME is NOT NULL)	*/
			if (curParty.getPartyPerson() != null) {
				
				String reptdCompName = curParty.getPartyPerson().get(0).getREPORTEDCOMPANYNAME();
				if(Util.isNullOrEmpty(reptdCompName)){
					isValid = Boolean.FALSE;
					createUpsertInfoMessage(upsertResponse, Constant.INFO_CONTACT_EMPTY_REPTD_COMP_NAME, srcPkey);
				}else {
					nameExclusionCond = prospectPartyDAO.isNameExclusionExists(reptdCompName);
					if(nameExclusionCond)	{
						isValid = Boolean.FALSE;
						LOG.info("Junk Value in REPORTED_COMP_NAME is found :"+nameExclusionCond);
						createUpsertInfoMessage(upsertResponse, Constant.INFO_CONTACT_REPTD_COMP_NAME_UNKWN, srcPkey);
						/* Changed for US449 START */
						upsertResponse.setErrorCd(prospectPartyDAO.getErrorCodeByDescription(
								messagesProp.getProperty(Constant.INFO_CONTACT_REPTD_COMP_NAME_UNKWN)));
						/* Changed for US449 END */
					}
				}
			}else {
				isValid = Boolean.FALSE;
				createUpsertInfoMessage(upsertResponse, Constant.INFO_CONTACT_EMPTY_REPTD_COMP_NAME, srcPkey);
			}
		} catch (Exception sqlEx) {
			LOG.error("Exception occurred in validateCompanyName: ", sqlEx);
			//sqlEx.printStackTrace();
			ServiceProcessingException customException = new ServiceProcessingException(sqlEx);
			customException.setMessage("Custom Exception occurred in validateCompanyName: " + sqlEx.getMessage());
		//	throw customException;
		} 
		LOG.debug("[validateCompanyName] EXIT::isValid::" + isValid);
		return isValid;
	}

	/**
	 * Validates input contact data
	 * 
	 * @param partyXrefType
	 * @param upsertResponse
	 * @return isValid
	 */
	public boolean validateContactRequest(PartyXrefType curParty, MdmUpsertPartyResponse upsertResponse) {
		LOG.debug("[validateContactRequest] START");
		Boolean isValid = Boolean.TRUE;
		String srcPkey = curParty.getXREF().get(0).getSRCPKEY();
		
	/*Checking	IF (FIRSTNAME is NOT NULL OR LASTNAME is NOT NULL) AND (REPORTED_COMPANY_NAME is NOT NULL)	*/
		if (curParty.getPartyPerson() != null) {
			
			String fName = curParty.getPartyPerson().get(0).getFIRSTNAME();
			String lName = curParty.getPartyPerson().get(0).getLASTNAME();
			String reptdCompName = curParty.getPartyPerson().get(0).getREPORTEDCOMPANYNAME();
			if ( Util.isNullOrEmpty(fName) && Util.isNullOrEmpty(lName) ){
				isValid = Boolean.FALSE;
				createUpsertInfoMessage(upsertResponse, Constant.INFO_CONTACT_EMPTY_FNAME_LNAME, srcPkey);
			}else if(Util.isNullOrEmpty(reptdCompName)){
				isValid = Boolean.FALSE;
				createUpsertInfoMessage(upsertResponse, Constant.INFO_CONTACT_EMPTY_REPTD_COMP_NAME, srcPkey);
			}
		}else {
			isValid = Boolean.FALSE;
			createUpsertInfoMessage(upsertResponse, Constant.INFO_CONTACT_EMPTY_REPTD_COMP_NAME, srcPkey);
		}
		
//		if (Util.isNullOrEmpty(curParty.getPARTYNAME())) {
		/*Checking if Email_Address from Communication is NULL OR NOT NULL*/
			List<CommunicationXrefType> commXrefTypeList = curParty.getCommunication();
			if (CollectionUtils.isEmpty(commXrefTypeList)) {
				isValid = Boolean.FALSE;
				createUpsertInfoMessage(upsertResponse, Constant.INFO_CONTACT_EMPTY_EMAIL_ADDR, srcPkey);
			} else {
				Boolean isEmailValuePresent = Boolean.FALSE;
				for (CommunicationXrefType commXrefType : commXrefTypeList) {
					if (commXrefType.getCOMMTYPE().equalsIgnoreCase("Email")) {
							if( !Util.isNullOrEmpty(commXrefType.getCOMMVALUE()) ){
							isEmailValuePresent = Boolean.TRUE;
							break;
						}
					}
				}
				if (!isEmailValuePresent) {
					isValid = Boolean.FALSE;
					createUpsertInfoMessage(upsertResponse, Constant.INFO_CONTACT_EMPTY_EMAIL_ADDR, srcPkey);
				}
			}
//		} else {
			/*Checking if Country_Cd from Address is NULL OR NOT NULL*/
			List<AddressXrefType> addressXrefTypeList = curParty.getAddress();
			if (CollectionUtils.isEmpty(addressXrefTypeList)) {
				isValid = Boolean.FALSE;
				createUpsertInfoMessage(upsertResponse, Constant.INFO_CONTACT_EMPTY_COUNTRY, srcPkey);
			} else {
				Boolean isCountryFound = Boolean.FALSE;
				for (AddressXrefType addressXrefType : addressXrefTypeList) {
					if (!Util.isNullOrEmpty(addressXrefType.getCOUNTRYCD())) {
						isCountryFound = Boolean.TRUE;
						break;
					}
				}
				if (!isCountryFound) {
					isValid = Boolean.FALSE;
					createUpsertInfoMessage(upsertResponse, Constant.INFO_CONTACT_EMPTY_COUNTRY, srcPkey);
				}
			}
//		}
		LOG.debug("[validateContactRequest] EXIT::isValid::" + isValid);
		return isValid;
	}

}
