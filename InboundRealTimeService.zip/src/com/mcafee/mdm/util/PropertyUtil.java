package com.mcafee.mdm.util;

import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

/**
 * This is util class to load properties
 * 
 * @author Anirbid Roy
 * 
 */
@Component
public class PropertyUtil {	
	
	private static final Logger LOG = Logger.getLogger(PropertyUtil.class
			.getName());
	
	@Resource(name="jdbcProp")
	private Properties jdbcProp;
	@Resource(name="configProp")
	private Properties configProp;
	@Resource(name="sipProp")
	private Properties sipProp;
	@Resource(name = "m4mQueryProp")
	private Properties queryProp;
	
	private static Map<String, Properties> propMap;
	
	//Private constructor to prevent object creation from code
	private PropertyUtil() {
	}
	
	@PostConstruct
	public void init() {
		propMap = new HashMap<String, Properties>();
		propMap.put("jdbcProp", jdbcProp);
		propMap.put("configProp", configProp);
		propMap.put("sipProp", sipProp);
		propMap.put("m4mQueryProp", queryProp);
		LOG.debug("####### propMap::" + propMap + "#######");
	}

	/**
	 * Util function to return properties of the application
	 * 
	 * @param fileName
	 * @return properties
	 */
	public static Properties getPropertiesFromFile(String propBeanName) {
		return propMap.get(propBeanName);
	}
}
