package com.mcafee.mdm.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.mcafee.mdm.constants.Constant;
import com.mcafee.mdm.constants.SearchMatchAttributes;
import com.mcafee.mdm.dao.pojo.GlobalHierarchyNode;
import com.mcafee.mdm.dao.pojo.HierarchyNode;
import com.mcafee.mdm.dao.pojo.SearchedRecordCollection;
import com.mcafee.mdm.dao.pojo.SearchedXrefRecordCollection;
import com.mcafee.mdm.exception.ServiceProcessingException;
import com.mcafee.mdm.generated.AccountType;
import com.mcafee.mdm.generated.AccountXrefType;
import com.mcafee.mdm.generated.AddressType;
import com.mcafee.mdm.generated.AddressXrefType;
import com.mcafee.mdm.generated.ClassificationType;
import com.mcafee.mdm.generated.ClassificationXrefType;
import com.mcafee.mdm.generated.CommunicationType;
import com.mcafee.mdm.generated.CommunicationXrefType;
import com.mcafee.mdm.generated.GoldenCopy;
import com.mcafee.mdm.generated.HierarchyProfile;
import com.mcafee.mdm.generated.HierarchyRequestType;
import com.mcafee.mdm.generated.HierarchyResponseType;
import com.mcafee.mdm.generated.HierarchySearchRequest;
import com.mcafee.mdm.generated.HierarchySearchResponse;
import com.mcafee.mdm.generated.HistoricalUCNs;
import com.mcafee.mdm.generated.Parties;
import com.mcafee.mdm.generated.Party;
import com.mcafee.mdm.generated.PartyAccountRelationshipType;
import com.mcafee.mdm.generated.PartyAccountRelationshipXrefType;
import com.mcafee.mdm.generated.PartyHierarchyProfileType;
import com.mcafee.mdm.generated.PartyOrgExtType;
import com.mcafee.mdm.generated.PartyOrgExtXrefType;
import com.mcafee.mdm.generated.PartyPersonExtType;
import com.mcafee.mdm.generated.PartyProfileType;
import com.mcafee.mdm.generated.PartyRelationshipType;
import com.mcafee.mdm.generated.PartyRelationshipXrefType;
import com.mcafee.mdm.generated.PartySearchCriteriaType;
import com.mcafee.mdm.generated.PartyType;
import com.mcafee.mdm.generated.PartyXrefType;
import com.mcafee.mdm.generated.SearchPartyHierarchyRequest;
import com.mcafee.mdm.generated.SearchPartyHierarchyResponse;
import com.mcafee.mdm.generated.SearchPartyRequest;
import com.mcafee.mdm.generated.SearchPartyResponse;
import com.mcafee.mdm.generated.XREFCopy;
import com.mcafee.mdm.generated.XREFType;
import com.mcafee.mdm.util.CanonicalFormManipulator;
import com.mcafee.mdm.util.CommonUtil;
import com.mcafee.mdm.util.JDBCConnectionProvider;
import com.mcafee.mdm.util.ObjectPool;
import com.mcafee.mdm.util.PropertyUtil;
import com.mcafee.mdm.util.Util;
import com.siperian.sif.client.SiperianClient;
import com.siperian.sif.client.SiperianServerException;
import com.siperian.sif.message.Field;
import com.siperian.sif.message.MatchType;
import com.siperian.sif.message.Record;
import com.siperian.sif.message.SiperianObjectType;
import com.siperian.sif.message.mrm.SearchMatchRequest;
import com.siperian.sif.message.mrm.SearchMatchResponse;

@Component
@Scope("prototype")
public class SearchPartyDAO extends ObjectPool {
	private static final Logger LOG = Logger.getLogger(SearchPartyDAO.class.getName());
	Properties configProps = PropertyUtil.getPropertiesFromFile("configProp");
	String matchScoreThresDef = configProps.getProperty("matchScore-Threshold");
	String ruleSetName = configProps.getProperty("matchRuleSet");
	String getPkgName = configProps.getProperty("pkgName");
	int recCountThresDef = Integer.parseInt(configProps.getProperty("recToReturnCount"));
	String custGrpPayer = configProps.getProperty("custGrpPayer");
	String custGrpBill = configProps.getProperty("custGrpBill");
	String custGrpSold = configProps.getProperty("custGrpSold");
	String custGrpShip = configProps.getProperty("custGrpShip");
	String custGrpDist = configProps.getProperty("custGrpDist");
	String custGrpEnd = configProps.getProperty("custGrpEnd");
	String custGrpRes = configProps.getProperty("custGrpRes");
	String custGrpOPA = configProps.getProperty("custGrpOPA");
	String custGrpPartner = configProps.getProperty("custGrpPartner");
//	String custGrpProsPartner = configProps.getProperty("custGrpProsPartner");
	String rowid_object = null;
	Map<String, Integer> recordMap = new HashMap<String, Integer>();
	Map<String, String> gucnMatchScore = new HashMap<String, String>();
	boolean HierarchyFuzzySearch = false;
	boolean isAdobeXrefFound = false;
	
	@Autowired
	SearchPartyXrefDAO searchXrefDao;
	@Autowired
	private CommonUtil commonUtil;

	//Method For Fuzzy Match
	public SearchPartyResponse processFuzzySearchRequest(
			SearchPartyRequest parameters) throws ServiceProcessingException {
		LOG.info("Executing processFuzzySearchRequest()");
		String searchType = null;
		String srcSystemName = null;

		if(!Util.isNullOrEmpty(parameters.getSearchType()))	{
			searchType = parameters.getSearchType();
		}
		
		/* changes for Sales Force Integration -Start */
		if( !Util.isNullOrEmpty(parameters.getPartySearchCriteria().getSRCSYSTEM()) )	{
				srcSystemName = parameters.getPartySearchCriteria().getSRCSYSTEM();
				LOG.info("srcSystemName" + srcSystemName);
				if (srcSystemName.equalsIgnoreCase("Salesforce")){
					srcSystemName="SFC";
				}
			}
		/* changes for Sales Force Integration -End */
		PartySearchCriteriaType partyCriteria = parameters.getPartySearchCriteria();
		String matchScoreThresIp = parameters.getMatchScoreThresold();
		int minMatchScoreThres = 0;
		int mtchScoreValue = 0;
		Integer recCountThresIp = 0;
		String countryName = null ;
		String searchPackageName = "PKG_PARTY_FUZZY_SEARCH";
		if(!Util.isNullOrEmpty(partyCriteria.getCOUNTRYCD())){
			if(partyCriteria.getCOUNTRYCD().trim().length()==2){
			countryName = getCL_SIP_POP(partyCriteria.getCOUNTRYCD());
			}else if(partyCriteria.getCOUNTRYCD().trim().length()>2){
				countryName=partyCriteria.getCOUNTRYCD();
			}
		}

		if (parameters.getRecordCountThresold() != null && parameters.getRecordCountThresold().length() > 0) {
			 recCountThresIp = Integer.parseInt(parameters.getRecordCountThresold());
		}
		int recCntThres = 0;
		String searchRuleSet = null;

		//Setting MatchScoreThreshold
		if(matchScoreThresIp != null && matchScoreThresIp.length() > 0)		{
			//Taking User entered value from SearchPartyRequest
			minMatchScoreThres = Integer.parseInt(matchScoreThresIp);
		} else {
			//Taking Default value from Configuration File
			minMatchScoreThres = Integer.parseInt(matchScoreThresDef);
		}

		LOG.debug("Setting MatchScoreThreshold: " + minMatchScoreThres);

		//Setting RecordsToReturnCount
		if(recCountThresIp != null && recCountThresIp.intValue() != 0)	{
			recCntThres = recCountThresIp;
		} else  {
			recCntThres = recCountThresDef;
		}

		LOG.debug("Setting RecordsToReturnCount: " + recCntThres);

		//Automated or Manual RuleSet based on SearchType
		if(Util.isNullOrEmpty(searchType) || searchType.equalsIgnoreCase("Auto"))	{
			searchRuleSet = configProps.getProperty("autoSearchRuleSet");
		} else if(Constant.ADOBE_SEARCH_BEST_MATCH.equalsIgnoreCase(searchType)){
			searchRuleSet = configProps.getProperty("matchRuleSetCustomer");
		}
		else {
			searchRuleSet = configProps.getProperty("manualSearchRuleSet");
		}
		
		SearchPartyResponse searchPartyMasterResponse = new SearchPartyResponse();

		SiperianClient siperianClient = null;

		SearchMatchRequest searchMatchRequest = null;
		SearchMatchResponse searchMatchResponse = null;


		searchMatchRequest = new SearchMatchRequest();
		searchMatchRequest.setRecordsToReturn(recCntThres); // Required
	
		searchMatchRequest.setSiperianObjectUid(searchPackageName);
	
		searchMatchRequest.setMatchRuleSetUid(SiperianObjectType.MATCH_RULE_SET.makeUid(searchRuleSet));//searchRuleSet,ruleSetName
		//searchMatchRequest.setMatchType(matchType);
		searchMatchRequest.setMatchType(MatchType.BOTH);

		LOG.info("Match Rule Set: " + searchMatchRequest.getMatchRuleSetUid());
		LOG.info("Match Type :" + searchMatchRequest.getMatchType());
		if(Constant.ADOBE_SEARCH_BEST_MATCH.equalsIgnoreCase(searchType)){
			if(partyCriteria.getCOUNTRYCD().trim().length()==2){
			countryName=getADBSearchCountryNm(partyCriteria.getCOUNTRYCD().trim());
			}else if(partyCriteria.getCOUNTRYCD().trim().length()>2){
				countryName=partyCriteria.getCOUNTRYCD().trim();
			}
			searchMatchRequest = prepareSearchRequest(partyCriteria,searchMatchRequest,countryName);
		}
		else{
		// Setting Oraganization_Name
		Field field_name = new Field("Organization_Name");
		if (!Util.isNullOrEmpty(partyCriteria.getPARTYNAME())) {
			field_name.setStringValue(partyCriteria.getPARTYNAME());
			LOG.info("Field to search for :" + field_name.getName() + ':' + field_name.getStringValue());
			searchMatchRequest.addMatchColumnField(field_name);
		}

		// Setting Address_Part1
		Field field_addr1 = new Field("Address_Part1");
		StringBuilder addrLn1Ln2Concat = new StringBuilder();
		if (!Util.isNullOrEmpty(partyCriteria.getADDRLN1())) {
			addrLn1Ln2Concat.append(partyCriteria.getADDRLN1());			

		}
		if (!Util.isNullOrEmpty(partyCriteria.getADDRLN2())) {
			addrLn1Ln2Concat.append(" ");
			addrLn1Ln2Concat.append(partyCriteria.getADDRLN2());
		
		}
		if (addrLn1Ln2Concat != null && addrLn1Ln2Concat.length() > 1) {
			field_addr1.setStringValue(addrLn1Ln2Concat.toString());
			searchMatchRequest.addMatchColumnField(field_addr1);
		}
		LOG.info("Field to search for :" + field_addr1.getName() + ':' + field_addr1.getStringValue());



  		// Setting Address_Part2
		Field addr_part2 = new Field("Address_Part2");
		StringBuilder addrCityStateCountryConcat = new StringBuilder();
		if (!(Util.isNullOrEmpty(partyCriteria.getCITY()) || "Unknown".equalsIgnoreCase(partyCriteria.getCITY()))) {
			addrCityStateCountryConcat.append(partyCriteria.getCITY());
			
		}
		if (!Util.isNullOrEmpty(partyCriteria.getSTATECD()))	{
			addrCityStateCountryConcat.append(" ");
			addrCityStateCountryConcat.append(partyCriteria.getSTATECD());
	
		}

		if (!Util.isNullOrEmpty(partyCriteria.getCOUNTRYCD()))	{
			addrCityStateCountryConcat.append(" ");
			addrCityStateCountryConcat.append(partyCriteria.getCOUNTRYCD());
		
		}
		if (addrCityStateCountryConcat != null && addrCityStateCountryConcat.length() > 1) {
			addr_part2.setStringValue(addrCityStateCountryConcat.toString());
			searchMatchRequest.addMatchColumnField(addr_part2);
		}
		LOG.info("Field to search for :" + addr_part2.getName() + ':' + addr_part2.getStringValue());
		}

		StringBuffer criteria = new StringBuffer();
		boolean firstParam = false;


		if (!Util.isNullOrEmpty(partyCriteria.getUCN())) {
			if (firstParam)
				criteria.append(" AND UCN='"+ partyCriteria.getUCN() + "'");
			else {
				firstParam = true;
				criteria.append(" UCN='"+ partyCriteria.getUCN() + "'");
			}
		}



		if (!Util.isNullOrEmpty(partyCriteria.getCOUNTRYCD())) {
			if (firstParam) {
				criteria.append(" AND UPPER(COUNTRY_CD) = UPPER('" + partyCriteria.getCOUNTRYCD() + "')");

			} else {
				firstParam = true;
				criteria.append(" UPPER(COUNTRY_CD) = UPPER('" + partyCriteria.getCOUNTRYCD() + "')");
			}	
			// Adding SIP_POP
			Field field_SIPPOP = new Field("SIP_POP");
			field_SIPPOP.setStringValue(countryName);
			searchMatchRequest.addMatchColumnField(field_SIPPOP);
			LOG.info("Field to match for :" + field_SIPPOP.getName() + ':' + field_SIPPOP.getStringValue());
		}

		//Both Customer_Group & Party_Type Cannot be provided as input
		if(!(Util.isNullOrEmpty(partyCriteria.getCUSTGROUP()) || Util.isNullOrEmpty(partyCriteria.getPARTYTYPE()))) {

			LOG.debug("Both Customer_Group & Party_Type have been provided in FuzzySearch criteria");
			searchPartyMasterResponse.setErrorMsg(Constant.bothCustGrpAndPartyTypeCantbeGiven);
			return searchPartyMasterResponse;

		}

		//Adding CUST_GROUP to filter criteria...
		if (!Util.isNullOrEmpty(partyCriteria.getCUSTGROUP())) {
			if (firstParam)	{
				if(partyCriteria.getCUSTGROUP().equalsIgnoreCase(custGrpPayer) )	{
					criteria.append(" AND (PARTY_TYPE ='"+ configProps.getProperty("Payer") + "'");
				}
				if(partyCriteria.getCUSTGROUP().equalsIgnoreCase(custGrpBill) )	{
					criteria.append(" AND (PARTY_TYPE ='"+ configProps.getProperty("Bill-to_party") + "'");
				}
				if(partyCriteria.getCUSTGROUP().equalsIgnoreCase(custGrpSold) )	{
					criteria.append(" AND (PARTY_TYPE ='"+ configProps.getProperty("Sold-to_party") + "'");
				}
				if(partyCriteria.getCUSTGROUP().equalsIgnoreCase(custGrpShip) )	{
					criteria.append(" AND (PARTY_TYPE ='"+ configProps.getProperty("Ship-to_party") + "'");
				}
				if(partyCriteria.getCUSTGROUP().equalsIgnoreCase(custGrpDist) )	{
					criteria.append(" AND (PARTY_TYPE ='"+ configProps.getProperty("Distributor-SP/SH/BP/PY/ZD/ZE") + "'");
				}
				if(partyCriteria.getCUSTGROUP().equalsIgnoreCase(custGrpEnd) )	{
					criteria.append(" AND (PARTY_TYPE ='"+ configProps.getProperty("End_User") + "'");
				}
				if(partyCriteria.getCUSTGROUP().equalsIgnoreCase(custGrpRes) )	{
					criteria.append(" AND (PARTY_TYPE ='"+ configProps.getProperty("Reseller") + "'");
				}
				if(partyCriteria.getCUSTGROUP().equalsIgnoreCase(custGrpOPA) )	{
					criteria.append(" AND (PARTY_TYPE ='"+ configProps.getProperty("OPA_Created_by_UserId") + "'");
				}
				if(partyCriteria.getCUSTGROUP().equalsIgnoreCase(custGrpPartner) )	{
					criteria.append(" AND (PARTY_TYPE ='"+ configProps.getProperty("Partner") + "'");
				}
		//		if(partyCriteria.getCUSTGROUP().equalsIgnoreCase(custGrpProsPartner) )	{
		//			criteria.append(" AND (PARTY_TYPE ='"+ configProps.getProperty("Prospective_Partner") + "'");
		//		}
				criteria.append(" OR PARTY_TYPE IS NULL)");

			} else {
				firstParam = true;
				if(partyCriteria.getCUSTGROUP().equalsIgnoreCase(custGrpPayer) )	{
					criteria.append(" (PARTY_TYPE ='"+ configProps.getProperty("Payer") + "'");
				}
				if(partyCriteria.getCUSTGROUP().equalsIgnoreCase(custGrpBill) )	{
					criteria.append(" (PARTY_TYPE ='"+ configProps.getProperty("Bill-to_party") + "'");
				}
				if(partyCriteria.getCUSTGROUP().equalsIgnoreCase(custGrpSold) )	{
					criteria.append(" (PARTY_TYPE ='"+ configProps.getProperty("Sold-to_party") + "'");
				}
				if(partyCriteria.getCUSTGROUP().equalsIgnoreCase(custGrpShip) )	{
					criteria.append(" (PARTY_TYPE ='"+ configProps.getProperty("Ship-to_party") + "'");
				}
				if(partyCriteria.getCUSTGROUP().equalsIgnoreCase(custGrpDist) )	{
					criteria.append(" (PARTY_TYPE ='"+ configProps.getProperty("Distributor-SP/SH/BP/PY/ZD/ZE") + "'");
				}
				if(partyCriteria.getCUSTGROUP().equalsIgnoreCase(custGrpEnd) )	{
					criteria.append(" (PARTY_TYPE ='"+ configProps.getProperty("End_User") + "'");
				}
				if(partyCriteria.getCUSTGROUP().equalsIgnoreCase(custGrpRes) )	{
					criteria.append(" (PARTY_TYPE ='"+ configProps.getProperty("Reseller") + "'");
				}
				if(partyCriteria.getCUSTGROUP().equalsIgnoreCase(custGrpOPA) )	{
					criteria.append(" (PARTY_TYPE ='"+ configProps.getProperty("OPA_Created_by_UserId") + "'");
				}
				if(partyCriteria.getCUSTGROUP().equalsIgnoreCase(custGrpPartner) )	{
					criteria.append(" (PARTY_TYPE ='"+ configProps.getProperty("Partner") + "'");
				}
		//		if(partyCriteria.getCUSTGROUP().equalsIgnoreCase(custGrpProsPartner) )	{
		//			criteria.append(" (PARTY_TYPE ='"+ configProps.getProperty("Prospective_Partner") + "'");
		//		}
				criteria.append(" OR PARTY_TYPE IS NULL)");
			}
		}

		//Adding PARTY_TYPE to Filter Criteria...
		if( Util.isNullOrEmpty(partyCriteria.getPARTYTYPE()) && Util.isNullOrEmpty(partyCriteria.getCUSTGROUP()) )	{

			LOG.info("Both PARTY_TYPE & CUSTOMER_GROUP are provided as NULL hence adding filter: PARTY_TYPE in ('Customer','Partner','Reseller','Distributor')");
		//	LOG.info("PARTY_TYPE is provided as NULL hence not adding Party Type.");
			if (firstParam)	{
				criteria.append(" AND PARTY_TYPE in ('Customer','Partner','Reseller','Distributor')");
		//		criteria.append(" AND (PARTY_TYPE = 'Reseller' OR PARTY_TYPE = 'Customer' OR PARTY_TYPE = 'Partner' OR PARTY_TYPE = 'Distributor')");
			} else {
				firstParam = true;
				criteria.append(" PARTY_TYPE in ('Customer','Partner','Reseller','Distributor')");
		//		criteria.append(" (PARTY_TYPE = 'Reseller' OR PARTY_TYPE = 'Customer' OR PARTY_TYPE = 'Partner' OR PARTY_TYPE = 'Distributor')");
			}
		} else if (!Util.isNullOrEmpty(partyCriteria.getPARTYTYPE()) && (partyCriteria.getPARTYTYPE().equalsIgnoreCase("Customer") || partyCriteria.getPARTYTYPE().equalsIgnoreCase("Partner")
				|| partyCriteria.getPARTYTYPE().equalsIgnoreCase("Reseller") || partyCriteria.getPARTYTYPE().equalsIgnoreCase("Distributor")) ) {

			LOG.info("PARTY_TYPE input value is: " + partyCriteria.getPARTYTYPE());
			if (firstParam)	{
				criteria.append(" AND UPPER(PARTY_TYPE) = UPPER('" + partyCriteria.getPARTYTYPE() + "')");
			} else {
				firstParam = true;
				criteria.append(" UPPER(PARTY_TYPE) = UPPER('" + partyCriteria.getPARTYTYPE() + "')");
			}
		} else if ( Util.isNullOrEmpty(partyCriteria.getCUSTGROUP()) )	{
			LOG.info("The supplied PARTY_TYPE is not within range -> ('Customer','Partner','Reseller','Distributor')");
			searchPartyMasterResponse.setErrorMsg(Constant.invalidPartyType);
			return searchPartyMasterResponse;
		}


		if (firstParam)	{
			criteria.append(" AND BO_CLASS_CODE = '" + "Organization" + "'");
		} else {
			firstParam = true;
			criteria.append(" BO_CLASS_CODE = '" + "Organization" + "'");
		}

		//Removing Soft-Deleted Records from Search
		if (firstParam) {
			criteria.append(" AND HUB_STATE_IND !='" + -1 + "'");
		} else {
			firstParam = true;
			criteria.append(" HUB_STATE_IND !='" + -1 + "'");
		}

		//Fetching Active Records from Search
		if (firstParam) {
			criteria.append(" AND STATUS_CD ='" + "A" + "'");
		} else {
			firstParam = true;
			criteria.append(" STATUS_CD ='" + "A" + "'");
		}

		LOG.info("Filter Criteria: " + criteria.toString());

		searchMatchRequest.setFilterCriteria(criteria.toString());
		
	
		
		try {
			siperianClient = (SiperianClient) checkOut();

			LOG.info("processing SearchMatchRequest");
			LOG.info("before request");
			LOG.info("================================================================================================");
			List<Field> searchMatchField = searchMatchRequest.getMatchColumnFields();
			for(int j=0;j<searchMatchField.size();j++){
				Field f = (Field)searchMatchField.get(j);
				LOG.info("Search field name : " + f.getName()+" : Search field value :" + f.getValue()+":");
				
			}
			LOG.info("================================================================================================");
			
			searchMatchResponse = (SearchMatchResponse) siperianClient.process(searchMatchRequest);
			LOG.info("after response");
		} catch (SiperianServerException sifExcp) {
			LOG.error("SiperianServerException occured while processing SearchMatchRequest: " + sifExcp);
			LOG.error("Get Message: "+ sifExcp.getMessage());
			ServiceProcessingException customException = new ServiceProcessingException(sifExcp.getMessage());
			customException.setRootExceptionMsg(sifExcp + " SearchMatch operation failed for Party_Name: "+ partyCriteria.getPARTYNAME());
			searchPartyMasterResponse.setErrorMsg(customException.getRootExceptionMsg());
			customException.setMessage("SIF exception occured while processing SearchMatch request for Party. ");
			throw customException;
		} catch (Exception exp) {
			LOG.error("Exception occured while processing SearchMatchRequest: " + exp);
			LOG.error("SearchMatch Exeption :" + exp.getMessage());
			ServiceProcessingException customException = new ServiceProcessingException(exp);
			customException.setRootExceptionMsg(exp + " SearchMatch operation failed for Party_Name: "+ partyCriteria.getPARTYNAME());
			searchPartyMasterResponse.setErrorMsg(customException.getRootExceptionMsg());
			customException.setMessage("SIF exception occured while processing SearchMatch request for Party.");
			throw customException;
		} finally {
			checkIn(siperianClient);
		}

			if (searchMatchResponse != null
					&& searchMatchResponse.getRecords().size() > 0) {
				LOG.info("SearchMatchResponse rec cnt="	+ searchMatchResponse.getRecords().size());

				List searchRecords = searchMatchResponse.getRecords();
				
				LOG.info("================================================================================================");
				for(int i =0 ; i< searchRecords.size();i++){
					Record record = (Record) searchRecords.get(i);
					record.getFields();
					Collection<String> fields = record.getFields();
					Iterator iterator = fields.iterator();
					 
			        // while loop
			        while (iterator.hasNext()) {
			        Field f = (Field)iterator.next();
			        if(f.getName().equals("BO_CLASS_CODE"))
			        	LOG.info(f.getName() + " : "+ f.getValue());
			        else if(f.getName().equals("PARTY_TYPE"))
			        	LOG.info(f.getName() + " : "+ f.getValue());
			        else if(f.getName().equals("PARTY_NAME"))
			        	LOG.info(f.getName() + " : "+ f.getValue());
			        else if(f.getName().equals("COUNTRY_CD"))
			        	LOG.info(f.getName() + " : "+ f.getValue());
			        else if(f.getName().equals("ROWID_OBJECT"))
			        	LOG.info(f.getName() + " : "+ f.getValue());
			        else if(f.getName().equals("RULE_NUMBER"))
			        	LOG.info(f.getName() + " : "+ f.getValue());
			        else if(f.getName().equals("RULESET_NAME"))
			        	LOG.info(f.getName() + " : "+ f.getValue());
			        else if(f.getName().equals("MATCH_SCORE"))
			        	LOG.info(f.getName() + " : "+ f.getValue());
			        }
			        LOG.info("================================================================================================"); 
				}
				
				if(Constant.ADOBE_SEARCH_BEST_MATCH.equalsIgnoreCase(searchType)){
					recordMap.putAll(fetchAdobeBestMatchRecord(searchRecords));
				}
				else{
				if (searchRecords != null && searchRecords.size() != 0) {
					for (Iterator iter = searchRecords.iterator(); iter.hasNext();) {
						Record record = (Record) iter.next();
						// Calculate Highest Match Score
				//		LOG.debug("Match Score :"+ record.getField("MATCH_SCORE").getValue());
						String mtchScore = record.getField("MATCH_SCORE").getValue().toString().trim();
						String trimmedPartyRowId = record.getField("ROWID_OBJECT").getStringValue().trim();
				//		int key = Integer.parseInt(trimmedKey);
						mtchScoreValue = Integer.parseInt(mtchScore);
						LOG.info("rowid_object :" + trimmedPartyRowId+ " scoreValue :" + mtchScoreValue);
						if(mtchScoreValue >= minMatchScoreThres)	{
							//Process only those records with matchScore > minMatchScoreThres
							recordMap.put(trimmedPartyRowId, mtchScoreValue);
						}else {
							LOG.debug("Match Score value for Party: " + trimmedPartyRowId + " is lesser than MinThreshold Value: " + minMatchScoreThres);
						}
						}//end for loop
					}//end if
				
				}
				
					if(recordMap.size() == 0) {
						searchPartyMasterResponse.setStatus("No Record Found with MatchScore more than Match_score_thresold value.");
						return searchPartyMasterResponse;
					}else {
						try{
						searchPartyMasterResponse = getAllPartyGolden(recordMap.keySet(),srcSystemName);
						}catch(ServiceProcessingException se){
							if(se.getMessage().contains(Constant.DB_CONN_FAILURE)){
								searchPartyMasterResponse.setErrorMsg(se.getMessage());
								searchPartyMasterResponse.setStatus(Constant.DB_CONN_FAILURE);
							}
						}
					//	return searchPartyMasterResponse;
					}
				}	else {
					LOG.info("No record Found");
					searchPartyMasterResponse.setStatus(Constant.noRecordFound);

//					PartyProfileType partyResp = new PartyProfileType();
//		            partyResp.getGoldenCopy().getParty().setROWIDOBJECT("0");
//		            partyResp.getGoldenCopy().getParty().setPARTYNAME(partyCriteria.getPARTYNAME());
//		            partyResp.getGoldenCopy().getParty().getAddress().get(0).setADDRLN1(partyCriteria.getADDRLN1());
//		            partyResp.getGoldenCopy().getParty().getAddress().get(0).setADDRLN2(partyCriteria.getADDRLN2());
//		            partyResp.getGoldenCopy().getParty().getAddress().get(0).setADDRLN3(partyCriteria.getAddrln3());
//		            partyResp.getGoldenCopy().getParty().getAddress().get(0).setCITY(partyCriteria.getCITY());
//		            partyResp.getGoldenCopy().getParty().getAddress().get(0).setSTATECD(partyCriteria.getSTATECD());
//		            partyResp.getGoldenCopy().getParty().getAddress().get(0).setCOUNTRYCD(partyCriteria.getCOUNTRYCD());
//		            partyResp.getGoldenCopy().getParty().getAddress().get(0).setPOSTALCD(partyCriteria.getPOSTALCD());
//
//		            searchPartyMasterResponse.getPartyProfile().add(partyResp);
			}
			LOG.info("Executed processFuzzySearchRequest()");
			return searchPartyMasterResponse;
	}


	private SearchMatchRequest prepareSearchRequest(PartySearchCriteriaType partyTypeParam,SearchMatchRequest searchMatchRequest, String countryName) {
		
		if(!Util.isNullOrEmpty(partyTypeParam.getCOUNTRYCD())){
			if(partyTypeParam.getCOUNTRYCD().trim().length()>2){
				partyTypeParam.setCOUNTRYCD(getCountryCode(partyTypeParam.getCOUNTRYCD()));
			}
		}
		
		Field field_name = new Field("Organization_Name");
		if (!Util.isNullOrEmpty(partyTypeParam.getPARTYNAME())) {
			field_name.setStringValue(partyTypeParam.getPARTYNAME());
			LOG.info("Field to search for :" + field_name.getName() + ':' + field_name.getStringValue());
			searchMatchRequest.addMatchColumnField(field_name);
		}
		
		Field ucnField_name = new Field("Ex_UCN");
		LOG.info("inserted ucn : " + partyTypeParam.getUCN());
		if (!Util.isNullOrEmpty(partyTypeParam.getUCN())) {
			ucnField_name.setStringValue(partyTypeParam.getUCN());
			LOG.info("Field to search for :" + ucnField_name.getName() + ':' + ucnField_name.getStringValue());
			searchMatchRequest.addMatchColumnField(ucnField_name);
		}
		
		
			// Setting Address_Part1
			Field field_addr1 = new Field("Address_Part1");
			StringBuilder addrLn1Ln2Concat = new StringBuilder();
			if (!Util.isNullOrEmpty(partyTypeParam.getADDRLN1())) {
				addrLn1Ln2Concat.append(partyTypeParam.getADDRLN1());
			}
			if (!Util.isNullOrEmpty(partyTypeParam.getADDRLN2())) {
				addrLn1Ln2Concat.append(" ");
				addrLn1Ln2Concat.append(partyTypeParam.getADDRLN2());

			} else {
				addrLn1Ln2Concat.append(" ");
			}
			if (addrLn1Ln2Concat != null && addrLn1Ln2Concat.length() > 1) {
				field_addr1.setStringValue(addrLn1Ln2Concat.toString());
				searchMatchRequest.addMatchColumnField(field_addr1);
			}
			LOG.info("Field to search for :" + field_addr1.getName() + ':' + field_addr1.getStringValue());

			if (!Util.isNullOrEmpty(partyTypeParam.getADDRLN1()))
				createSearchField(searchMatchRequest, SearchMatchAttributes.EX_ADDRESS_LN1,
						partyTypeParam.getADDRLN1());
			if (!Util.isNullOrEmpty(partyTypeParam.getADDRLN2()))
				createSearchField(searchMatchRequest, SearchMatchAttributes.EX_ADDRESS_LN2,
						partyTypeParam.getADDRLN2());

			if (addrLn1Ln2Concat != null && addrLn1Ln2Concat.length() > 1) {
				if (!Util.isNullOrEmpty(partyTypeParam.getADDRLN2())) {
					createSearchField(searchMatchRequest, SearchMatchAttributes.EX_ADDR_PART1,
							addrLn1Ln2Concat.toString()+Constant.STR_SPACE);	
				}else{
					createSearchField(searchMatchRequest, SearchMatchAttributes.EX_ADDR_PART1,
							addrLn1Ln2Concat.toString());
				}
			}
			if (!Util.isNullOrEmpty(partyTypeParam.getCITY()))
				createSearchField(searchMatchRequest, SearchMatchAttributes.EX_CITY, partyTypeParam.getCITY());
			if (!Util.isNullOrEmpty(partyTypeParam.getCOUNTRYCD()))
				createSearchField(searchMatchRequest, SearchMatchAttributes.EX_COUNTRY_CD,
						partyTypeParam.getCOUNTRYCD());
			if (!Util.isNullOrEmpty(partyTypeParam.getSTATECD()))
				createSearchField(searchMatchRequest, SearchMatchAttributes.EX_STATE, partyTypeParam.getSTATECD());
			
			LOG.info("State search : " + partyTypeParam.getSTATECD());
			LOG.info("country search : " + partyTypeParam.getCOUNTRYCD());
			LOG.info("addresspart1 search: " + addrLn1Ln2Concat);
			LOG.info("Search organization name : " + partyTypeParam.getPARTYNAME());
			LOG.info("searrch entity type : " + Constant.BO_CLASS_CODE_ORG);
			LOG.info("searrch for UCN : " + partyTypeParam.getUCN());
			LOG.info("searrch for city : " + partyTypeParam.getCITY());
			// Setting Address_Part2

			Field addr_part2 = new Field("Address_Part2");
			StringBuilder addrPart2Concat = new StringBuilder();
			if (!Util.isNullOrEmpty(partyTypeParam.getCITY())) {
				addrPart2Concat.append(partyTypeParam.getCITY());
			}
			if (!Util.isNullOrEmpty(partyTypeParam.getSTATECD())) {
				if (addrPart2Concat != null && addrPart2Concat.length() > 1)
					addrPart2Concat.append(" ");
				addrPart2Concat.append(partyTypeParam.getSTATECD());
			}
			if (!Util.isNullOrEmpty(partyTypeParam.getCOUNTRYCD())) {
				if (addrPart2Concat != null && addrPart2Concat.length() > 1)
					addrPart2Concat.append(" ");
				addrPart2Concat.append(partyTypeParam.getCOUNTRYCD());
			}
			if (addrPart2Concat != null && addrPart2Concat.length() > 1) {
				addr_part2.setStringValue(addrPart2Concat.toString());
				LOG.info("Field to search for :" + addr_part2.getName() + ':' + addr_part2.getStringValue());
				searchMatchRequest.addMatchColumnField(addr_part2);
			}

		createSearchField(searchMatchRequest, SearchMatchAttributes.EX_ORGANIZATION_NAME,partyTypeParam.getPARTYNAME());
		createSearchField(searchMatchRequest, SearchMatchAttributes.EX_ENTITY_TYPE, Constant.BO_CLASS_CODE_ORG);
		createSearchField(searchMatchRequest, SearchMatchAttributes.EX_PARTY_TYPE,Constant.PARTY_TYPE_CUSTOMER);
		return searchMatchRequest;
	}
	
	private String getCountryCode(String country) {
		LOG.debug("Inside getCountryCode()");
		PreparedStatement statement = null;
		Connection jdbcConn = null;
		ResultSet resultSet = null;
		String countryName = null;
		JDBCConnectionProvider jDBCConnectionProvider = null;
		try {
			jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
			jdbcConn = jDBCConnectionProvider.getJdbcConnectionFromDS();
			LOG.info("Country Name : " + country);
			StringBuilder sql = new StringBuilder();
			sql.append("select COUNTRY_CD from MDM_COUNTRY where COUNTRY_NM= ?");
			LOG.debug("SQL Generated is : " + sql.toString());
			statement = jdbcConn.prepareStatement(sql.toString());
			statement.setString(1, country);
			resultSet = statement.executeQuery();
			if (resultSet.next()) {
				countryName = resultSet.getString(1);
			}
			LOG.debug("Country Code value is: " + countryName);
		} catch (Exception exp) {
			exp.printStackTrace();
		} finally {
			try {
				if (resultSet != null)
					resultSet.close();
				if (statement != null)
					statement.close();
				if (jdbcConn != null)
					jdbcConn.close();
			} catch (SQLException exp) {
				LOG.error("Caught SQLException in getCountryCode().");
			}

		}
		return countryName;
	}


	private void createSearchField(SearchMatchRequest searchMatchRequest, String fieldName, Object fieldValue) {
		LOG.debug("[createSearchField]ENTER::fieldName::" + fieldName + "::fieldValue::" + fieldValue);
		Field field = null;
		if (!Util.isNullOrEmpty(fieldName)) {
			field = new Field(fieldName);
			field.setValue(fieldValue);
		}
		if (field != null) {
			searchMatchRequest.addMatchColumnField(field);
			LOG.debug("[createSearchField]Added Field::" + field.getName() + "::" + field.getStringValue());
		}
		LOG.debug("[createSearchField]EXIT");
	}

	public SearchPartyResponse  getAllPartyGoldenCopyADBSearch(Set<String> rowidObjectSet,String srcSystemName) throws ServiceProcessingException {
		LOG.info("Executing getAllPartyGoldenCopyADBSearch()");

		SearchPartyResponse searchPartyMasterResp = null;
		PreparedStatement pstmt = null;
		Statement statement = null;
		StringBuilder sqlQry = new StringBuilder();
		JDBCConnectionProvider jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
		Connection jdbcConnection = null;
		ResultSet resultSet = null;


		try {
			LOG.info("Fetching Golden copies for rowidObjectSet: " + rowidObjectSet);

			sqlQry.append("SELECT * FROM PKG_PARTY_JMS_MQ_PUB a WHERE ROWID_OBJECT in (");

			for (String partyRowId : rowidObjectSet) {
				sqlQry.append("'" + partyRowId + "',");
			}
			sqlQry.deleteCharAt(sqlQry.length() - 1).toString();
			sqlQry.append(") AND HUB_STATE_IND <> '" + -1 + "'");
			sqlQry.append(" AND STATUS_CD = '" + "A" + "'");
			sqlQry.append(" AND BO_CLASS_CODE = '" + "Organization" + "'");
			sqlQry.append(" AND PARTY_TYPE in ('" + "Customer',"  + "'Prospect Customer" + "')");
			//** Modified for SFDC START *//*
			//sqlQry.append(" AND NVL(DRAFT_FLG,'N')<>'" + "Y" + "'");
			//** Modified for SFDC END *//*
			
			/*Modified for MDMP-3065: Fuzzy Search look up issue:: START*/
			sqlQry.append(" and Exists (select 1 from c_b_party_xref where c_b_party_xref.status_cd = 'A' and c_b_party_xref.ROWID_SYSTEM IN ('SAP','SBL','SFC','FNO','ADB') and c_b_party_xref.rowid_object = a.rowid_object)");
			/*Modified for MDMP-3065: Fuzzy Search look up issue:: END*/
			/*Modified for MDMP-3093: Fuzzy Search look up issue:: START*/
			sqlQry.append("AND nvl(trunc(END_DATE),'31-DEC-9999') = '31-DEC-9999'");
			sqlQry.append(" AND NVL(ADDR_HUB_STATE_IND,1)  = 1");
			
			//Commented as per Venkat's review comment for defect - ODOM-2445
			/*sqlQry.append(" AND NVL(COMM_HUB_STATE_IND,1)  = 1");
			sqlQry.append(" AND NVL(ORG_EXTN_HUB_STATE_IND,1)  = 1");
			sqlQry.append(" AND NVL(CLASSIFCTN_HUB_STATE_IND,1)  = 1");*/
			
			//sqlQry.append(" AND NVL(REL_HUB_STATE_IND,1)  = 1");
			/*Modified for MDMP-3093: Fuzzy Search look up issue:: END*/
	//		sqlQry.append("SELECT * FROM PKG_PARTY_JMS_MQ_PUB WHERE HUB_STATE_IND <> '" + -1 + "' AND STATUS_CD = 'A' AND BO_CLASS_CODE = 'Organization'");
	//		sqlQry.append(" AND PARTY_TYPE in ('Customer','Partner','Reseller','Distributor')");
			/* Modified for SFDC START */
	//		sqlQry.append(" AND EXISTS (SELECT 1 FROM C_B_ACCOUNT_XREF WHERE C_B_ACCOUNT_XREF.ROWID_OBJECT=ROWID_ACCOUNT AND NVL(DRAFT_FLG,'N')='N')");
			/* Modified for SFDC END */
	//		sqlQry.append(" AND ROWID_OBJECT = ? ");
		
			LOG.debug("Query to fetch partyGoldenMap: " + sqlQry);


			jdbcConnection = jDBCConnectionProvider.getJdbcConnectionFromDS();
		//	jdbcConnection = JdbcConn.GetJdbcConnObject();
		//	jdbcConnection.setAutoCommit(false);
			statement = jdbcConnection.createStatement();
			resultSet = statement.executeQuery(sqlQry.toString());
			searchPartyMasterResp = createGoldenCopyFuzzySearch(resultSet,srcSystemName);
			
	/*		pstmt = jdbcConnection.prepareStatement(sqlQry.toString());
			for (String partyRowId : rowidObjectSet) {
				pstmt.setString(1, partyRowId);
				pstmt.addBatch();
			}
			
			resultSet = pstmt.executeQuery();
			searchPartyMasterResp = createGoldenCopyFuzzySearch(resultSet);
	 */
		} catch (SQLException sqlEx) {
			LOG.error("Exception occurred in getAllPartyGolden while fetching Party profile: " + sqlEx);
			sqlEx.printStackTrace();
			ServiceProcessingException customException = new ServiceProcessingException(sqlEx);
			customException.setMessage("Failed to fetch Party profile from ORS." + customException.getMessage());
			throw customException;
		} catch(ServiceProcessingException spe){
			LOG.error("Exception occured in getAllPartyGolden while fetching Party profile: "+spe.getMessage()+" "+spe.getRootExceptionMsg());
			
			throw spe;
			
		}
			finally {
		
				try {
					if( resultSet != null) resultSet.close();
					if( pstmt != null) pstmt.close();
					if( statement != null) statement.close();
					if(jdbcConnection != null) jdbcConnection.close();
				} catch (SQLException e) {
					LOG.error("Sql Exception occurred in getAllPartyGolden : " + e);
					//e.printStackTrace();
				}
		}

		LOG.info("Executed getAllPartyGoldenCopyADBSearch");

		return searchPartyMasterResp;
	}
	
	
	
	
	//Process Fuzzy Search Golden Records
	private SearchPartyResponse createGoldenCopyFuzzySearch(ResultSet resultSet,String srcSystemName)throws ServiceProcessingException {

		LOG.info("Inside createGoldenCopyFuzzySearch()");
		SearchPartyResponse searchPartyMasterResponse = new SearchPartyResponse();
		try {

				PartyProfileType partyProfile = null;
				List<PartyProfileType> partyProfileList = new ArrayList<PartyProfileType>();
				GoldenCopy goldenCpy = null;
				XREFCopy xrefCopy = null;

				PartyType partyResponse = null;

				XREFType xref = null;
				CommunicationType communication = null;
				AccountType accInfo = null;
				AddressType address = null;
				ClassificationType classfction = null;
				PartyOrgExtType partyOrgExt = null;
				PartyPersonExtType partyPersonExt = null;
				//PartyRelationshipType partyRelationship = null;
				
				/** Modified for M4M START */
				PartyAccountRelationshipType partyAccountRelationship = null;				
				/** Modified for M4M END */

		//		List searchRecords = searchMatchResponse.getRecords();

				// Calculate Highest Match Score
		//		Map<Integer, Integer> matchScoreMap = new TreeMap<Integer, Integer>();
		//		Set resultMatchScore = null;
				Map<String, SearchedRecordCollection> searchedRecCollMap = new HashMap<String, SearchedRecordCollection>();
				SearchedRecordCollection searchedRecCollObj;
				boolean bUniqueRec = false;
				String hierarchyGRP = configProps.getProperty("HierGRP");
				String hierarchyCd = null;
				String rowidRelationship = null;
				while (resultSet.next()) {
						
						String isGlobalParent = "N";
						String partyRowId = resultSet.getString("ROWID_OBJECT");
						String trimmedRowid = partyRowId.trim();
						String partyType = resultSet.getString("PARTY_TYPE");

						if (!searchedRecCollMap.containsKey(partyRowId)) {

							LOG.debug("Populate searchedRecCollMap for new PARTY_ROWID " + partyRowId);
							searchedRecCollMap.put(partyRowId, new SearchedRecordCollection());
							bUniqueRec = true;
						}

						searchedRecCollObj = searchedRecCollMap.get(partyRowId);

						if(bUniqueRec)	{

						LOG.debug("============setting GoldenCopy");

						//	partyResponse.setROWIDOBJECT(record.getField("ROWID_OBJECT").getStringValue());
						searchedRecCollObj.setParty_rowid(resultSet.getString("ROWID_OBJECT"));
						//	partyResponse.setBOCLASSCODE(record.getField("BO_CLASS_CODE").getStringValue());
						searchedRecCollObj.setBo_class(resultSet.getString("BO_CLASS_CODE"));
						//	partyResponse.setPARTYTYPE(record.getField("PARTY_TYPE").getStringValue());
						searchedRecCollObj.setParty_type(resultSet.getString("PARTY_TYPE"));
						//	partyResponse.setPARTYNAME(record.getField("PARTY_NAME").getStringValue());
						searchedRecCollObj.setParty_name(resultSet.getString("PARTY_NAME"));
						//	partyResponse.setGEO(record.getField("GEO").getStringValue());
						searchedRecCollObj.setGeo(resultSet.getString("GEO"));
						//	partyResponse.setREGION(record.getField("REGION").getStringValue());
						searchedRecCollObj.setRegion(resultSet.getString("REGION"));
						//	partyResponse.setSTATUSCD(record.getField("STATUS_CD").getStringValue());
						searchedRecCollObj.setStatus_cd(resultSet.getString("STATUS_CD"));
						//	partyResponse.setVATREGNBR(record.getField("VAT_REG_NBR").getStringValue());
						searchedRecCollObj.setVat_regno(resultSet.getString("VAT_REG_NBR"));
						//	partyResponse.setTAXJURSDCTNCD(record.getField("TAX_JURSDCTN_CD").getStringValue());
						searchedRecCollObj.setTax_jd_cd(resultSet.getString("TAX_JURSDCTN_CD"));
						//	partyResponse.setSALESBLOCKCD(record.getField("SALES_BLOCK_CD").getStringValue());
						searchedRecCollObj.setSales_cd(resultSet.getString("SALES_BLOCK_CD"));
						//	partyResponse.setUCN(record.getField("UCN").getStringValue());
						searchedRecCollObj.setUcn(resultSet.getString("UCN"));
						if(!HierarchyFuzzySearch && recordMap != null) {
							/*LOG.info("recordMap "+recordMap);
							LOG.info("HierarchyFuzzySearch "+HierarchyFuzzySearch);*/
							Integer matchScore = recordMap.get(trimmedRowid);
							if(null != matchScore)
								searchedRecCollObj.setMtchScoreValue(matchScore.intValue());							
						}
						//Change for English Name :: Adding English name field to response
						searchedRecCollObj.setEnglish_name(resultSet.getString("ENGLISH_NAME"));
						searchedRecCollObj.setPhysicalGeo(resultSet.getString("PHYSICAL_GEO"));
						searchedRecCollObj.setPhysicalRegion(resultSet.getString("PHYSICAL_REGION"));


				//		LOG.debug("============setting XREFType");
				//		xref = new XREFType();
				//		String partyID = record.getField("ROWID_OBJECT").getStringValue();
				//		getPartyXref(partyID, xref);


				//		LOG.debug("===Inserting into XREFType list===");
				//		listXref = new ArrayList<XREFType>();
				//		listXref.add(xref);
				//		partyResponse.getXREF().addAll(listXref);

						}


					//	LOG.debug("============setting AccountType");
						if (resultSet.getString("ROWID_ACCOUNT") != null &&
								!searchedRecCollObj.getAccountMap().containsKey(resultSet.getString("ROWID_ACCOUNT"))) {

						LOG.debug("============setting AccountType");
						accInfo = new AccountType();


						accInfo.setROWIDACCOUNT(resultSet.getString("ROWID_ACCOUNT"));
						accInfo.setACCTNAME(resultSet.getString("ACCT_NAME"));
						accInfo.setALIASNAME(resultSet.getString("ALIAS_NAME"));
						accInfo.setACCTSTATUS(resultSet.getString("ACCT_STATUS"));
						accInfo.setACCTTYPE(resultSet.getString("ACCT_TYPE"));
						accInfo.setACCOUNTREGION(resultSet.getString("ACCOUNT_REGION"));
						accInfo.setACCOUNTGEO(resultSet.getString("ACCOUNT_GEO"));
						accInfo.setMARKET(resultSet.getString("MARKET"));
						accInfo.setCUSTGROUP(resultSet.getString("CUST_GROUP"));
						accInfo.setPRICEGROUP(resultSet.getString("PRICE_GROUP"));
						accInfo.setCOMPANYCD(resultSet.getString("COMPANY_CD"));
						accInfo.setACCOUNTVATREGNBR(resultSet.getString("ACCOUNT_VAT_REG_NBR"));
						accInfo.setTAXTYPE(resultSet.getString("TAX_TYPE"));
						accInfo.setACCOUNTTAXJURSDCTNCD(resultSet.getString("ACCOUNT_TAX_JURSDCTN_CD"));
						accInfo.setBILLBLOCKCD(resultSet.getString("BILL_BLOCK_CD"));
						accInfo.setORDRBLOCKCD(resultSet.getString("ORDR_BLOCK_CD"));
						accInfo.setDLVRYBLOCKCD(resultSet.getString("DLVRY_BLOCK_CD"));
						accInfo.setPOSTBLOCKCD(resultSet.getString("POST_BLOCK_CD"));
						accInfo.setSALEBLOCKCD(resultSet.getString("SALE_BLOCK_CD"));
						accInfo.setCHANNELID(resultSet.getString("CHANNEL_ID"));
						accInfo.setPARTNERTYPE(resultSet.getString("PARTNER_TYPE"));
						accInfo.setVENDORNBR(resultSet.getString("VENDOR_NBR"));
						accInfo.setDIRECTIND(resultSet.getString("DIRECT_IND"));
						accInfo.setNAMEDACCTIND(resultSet.getString("NAMED_ACCT_IND"));
						accInfo.setNONVALACCTIND(resultSet.getString("NON_VAL_ACCT_IND"));
						accInfo.setPARTNERIND(resultSet.getString("PARTNER_IND"));
						accInfo.setSIEBELROWID(resultSet.getString("SIEBEL_ROWID"));
						accInfo.setSAPCUSTNUMBER(resultSet.getString("SAP_CUST_NUMBER"));
						accInfo.setMDMLEGACYID(resultSet.getString("MDM_LEGACY_ID"));
						
						/** Modified for SFDC START */
						accInfo.setSalesForceID(resultSet.getString("SFID"));
						accInfo.setDraftAccountFlag(resultSet.getString("DRAFT_FLG"));
						/** Modified for SFDC END */
						/** changes for Sales Force Integration -Start */
						accInfo.setLOCALNAME(resultSet.getString("LOCAL_NAME"));
						accInfo.setCURRENCYCD(resultSet.getString("ACCOUNT_CURRENCY_CD"));
						accInfo.setTAXID(resultSet.getString("TAX_ID"));
						accInfo.setPRICEBANDAGGREMENT(resultSet.getString("PRICING_BAND_AGRMNT"));
						/** changes for Sales Force Integration -End */
						/** changes for Track-2 -Start */
						accInfo.setSITEDESIGNATION(resultSet.getString("SITE_DESIGNATION"));
						/** changes for Track-2 -End */
						/** changes for Track-3 -Start */
						accInfo.setRESELLLEVEL(resultSet.getString("RESELL_LEVEL"));
						accInfo.setPARTNERSHIPSTATUS(resultSet.getString("PARTNERSHIP_STATUS"));
						/** changes for Track-3 -End */
						LOG.debug("===Inserting into AccountType Map===");
						searchedRecCollObj.getAccountMap().put(resultSet.getString("ROWID_ACCOUNT"), accInfo);

				}



						if (resultSet.getString("ROWID_ADDRESS") != null &&
								!searchedRecCollObj.getAddressMap().containsKey(resultSet.getString("ROWID_ADDRESS"))) {

						LOG.debug("============setting AddressType");
						address = new AddressType();
						address.setROWIDADDRESS(resultSet.getString("ROWID_ADDRESS"));
						address.setADDRLN1(resultSet.getString("ADDR_LN1"));
						address.setADDRLN2(resultSet.getString("ADDR_LN2"));
						address.setADDRLN3(resultSet.getString("ADDR_LN3"));
						address.setADDRLN4(resultSet.getString("ADDR_LN4"));
						address.setCITY(resultSet.getString("CITY"));
						address.setCOUNTY(resultSet.getString("COUNTY"));
						address.setDISTRICT(resultSet.getString("DISTRICT"));
						address.setSTATECD(resultSet.getString("STATE_CD"));
						address.setPOSTALCD(resultSet.getString("POSTAL_CD"));
						address.setCOUNTRYCD(resultSet.getString("COUNTRY_CD"));
						address.setLANGCD(resultSet.getString("LANG_CD"));
						address.setLONGITUDE(resultSet.getString("LONGITUDE"));
						address.setLATITUDE(resultSet.getString("LATITUDE"));
						address.setADDRTYPE(resultSet.getString("ADDR_TYPE"));
						address.setADDRSTATUS(resultSet.getString("ADDR_STATUS"));


						LOG.debug("===Inserting into Address Map===");
						searchedRecCollObj.getAddressMap().put(resultSet.getString("ROWID_ADDRESS"), address);

				}

						if (resultSet.getString("ROWID_COMMUNICATION") != null &&
								!searchedRecCollObj.getCommMap().containsKey(resultSet.getString("ROWID_COMMUNICATION"))) {
						if(resultSet.getString("COMM_HUB_STATE_IND")!=null && resultSet.getString("COMM_HUB_STATE_IND").equals("1")){
						communication = new CommunicationType();
						LOG.debug("============adding CommunicationType ");

						communication.setROWIDCOMMUNICATION(resultSet.getString("ROWID_COMMUNICATION"));
						communication.setCOMMTYPE(resultSet.getString("COMM_TYPE"));
						communication.setCOMMVALUE(resultSet.getString("COMM_VALUE"));
						communication.setCOMMSTATUS(resultSet.getString("COMM_STATUS"));
						communication.setPRFRDCOMMIND(resultSet.getString("PRFRD_COMM_IND"));
						communication.setWEBDOMAIN(resultSet.getString("WEB_DOMAIN"));
						/* changes for SFDC - Track2 -Start */
						communication.setCOMMEXTN(resultSet.getString("COMM_EXTN"));
						communication.setCOMMMKTGPREF(resultSet.getString("COMM_MKTG_PREF"));
						/* changes for SFDC - Track2 -End */
						
						LOG.debug("===Inserting into Communication Map===");
						searchedRecCollObj.getCommMap().put(resultSet.getString("ROWID_COMMUNICATION"), communication);
						}

				}


						if (resultSet.getString("ROWID_ORG_EXTN") != null &&
								!searchedRecCollObj.getPartyOrgMap().containsKey(resultSet.getString("ROWID_ORG_EXTN"))) {
						
						if(resultSet.getString("ORG_EXTN_HUB_STATE_IND")!=null && resultSet.getString("ORG_EXTN_HUB_STATE_IND").equals("1")){

						partyOrgExt = new PartyOrgExtType();
						LOG.debug("============adding PartyOrgExtType ");


						partyOrgExt.setROWIDORGEXTN(resultSet.getString("ROWID_ORG_EXTN"));
						partyOrgExt.setORGDUNSNBR(resultSet.getString("ORG_DUNS_NBR"));
						partyOrgExt.setTRADENAME(resultSet.getString("TRADE_NAME"));
						partyOrgExt.setTRADENAME2(resultSet.getString("TRADE_NAME_2"));
						partyOrgExt.setSITEEMPLCNT(resultSet.getString("SITE_EMPL_CNT"));
						partyOrgExt.setGLBLEMPLCNT(resultSet.getString("GLBL_EMPL_CNT"));
						partyOrgExt.setVERTICAL(resultSet.getString("VERTICAL"));
						partyOrgExt.setREVENUE(resultSet.getString("REVENUE"));
						partyOrgExt.setLINEOFBUS(resultSet.getString("LINE_OF_BUS"));
						partyOrgExt.setPRIMSIC(resultSet.getString("PRIM_SIC"));
						partyOrgExt.setSECSIC(resultSet.getString("SEC_SIC"));
						partyOrgExt.setSALESVOLUME(resultSet.getString("SALES_VOLUME"));
						partyOrgExt.setSALESAMOUNT(resultSet.getString("SALES_AMOUNT"));
						partyOrgExt.setCURRENCYCD(resultSet.getString("CURRENCY_CD"));
						partyOrgExt.setOUTOFBUSIND(resultSet.getString("OUT_OF_BUS_IND"));
						partyOrgExt.setGLBLULTIND(resultSet.getString("GLBL_ULT_IND"));
						partyOrgExt.setFORTUNEINFO(resultSet.getString("FORTUNE_INFO"));
						partyOrgExt.setHIERARCHYLEVEL(resultSet.getString("HIERARCHY_LEVEL"));
						partyOrgExt.setORGHQPARENTDUNS(resultSet.getString("ORG_HQ_PARENT_DUNS"));
						partyOrgExt.setORGDOMULTDUNS(resultSet.getString("ORG_DOM_ULT_DUNS"));
						partyOrgExt.setORGGLBULTDUNS(resultSet.getString("ORG_GLB_ULT_DUNS"));
						partyOrgExt.setMFEPRTNRPARENTORG(resultSet.getString("MFE_PRTNR_PARENT_ORG"));
						partyOrgExt.setSALESREVNUOVRID(resultSet.getString("SALES_REVNU_OVRID"));
						partyOrgExt.setMFEEMPCNTOVERIDE(resultSet.getString("MFE_EMP_CNT_OVERIDE"));
						partyOrgExt.setSICCDOVRIDE(resultSet.getString("SIC_CD_OVRIDE"));
						/** changes for Track-2 -Start */
						partyOrgExt.setMFECOUNTRYULTUCN(resultSet.getString("MFE_COUNTRY_ULT_UCN"));
						partyOrgExt.setMFEGLBLPARENTUCN(resultSet.getString("MFE_GLBL_PARENT_UCN"));
						partyOrgExt.setMFEGLOBALPARNMOVRIDE(resultSet.getString("MFE_GLOBAL_PAR_NM_OVRIDE"));
						partyOrgExt.setMFENEXTLVLSUBSPARNM(resultSet.getString("MFE_NEXT_LVL_SUBS_PAR_NM"));
						partyOrgExt.setMFENEXTLVLSUBSPARUCN(resultSet.getString("MFE_NEXT_LVL_SUBS_PAR_UCN"));
						partyOrgExt.setMFESUBSDRYPARENTNM(resultSet.getString("MFE_SUBS_PARENT_NM"));
						partyOrgExt.setMFESUBSDRYPARENTPRTNNM(resultSet.getString("MFE_SUBSDRY_PARENT_PRTN_NM"));
						partyOrgExt.setMFESUBSPARENTNMOVRIDE(resultSet.getString("MFE_SUBS_PARENT_NM_OVRIDE"));
						partyOrgExt.setMFESUBSPARENTUCN(resultSet.getString("MFE_SUBS_PARENT_UCN"));
						partyOrgExt.setMFETXN5YRFLG(resultSet.getString("MFE_TXN_5_YR_FLG"));
						partyOrgExt.setMFETXN7YRFLG(resultSet.getString("MFE_TXN_7_YR_FLG"));
						partyOrgExt.setMFEWWPARENTNM(resultSet.getString("MFE_WW_PARENT_NM"));
						partyOrgExt.setMFEWWPARENTPRTNNM(resultSet.getString("MFE_WW_PARENT_PRTN_NM"));
						partyOrgExt.setTXN5YRFLG(resultSet.getString("TXN_5_YR_FLG"));
						partyOrgExt.setTXN7YRFLG(resultSet.getString("TXN_7_YR_FLG"));
						partyOrgExt.setGLBEMPCNTOVERRIDE(resultSet.getString("GLB_EMP_CNT_OVERRIDE"));
						partyOrgExt.setACTIVETXNFLG(resultSet.getString("ACTIVE_TXN_FLAG"));
						partyOrgExt.setPARENTFLG(resultSet.getString("PARENT_FLAG"));
						partyOrgExt.setPARTNERFLG(resultSet.getString("PARTNER_FLAG"));
						partyOrgExt.setCUSTFLG(resultSet.getString("CUST_FLAG"));
						partyOrgExt.setGLBFLG(resultSet.getString("GLB_FLG"));
						partyOrgExt.setCOUNTRYULTIND(resultSet.getString("COUNTRY_ULT_IND"));	
						partyOrgExt.setSUBSIDIARYIND(resultSet.getString("SUBSIDIARY_IND"));
						partyOrgExt.setMDMPARENTUCN(resultSet.getString("MDM_PARENT_UCN"));
						partyOrgExt.setG2KFLG(resultSet.getString("G2K_FLG"));
						partyOrgExt.setGLBSALESREVNUOVRID(resultSet.getString("GLB_SALES_REVNU_OVRID"));
						/** changes for Track-2 -End */
						/** changes for Track-3 -Start */
						partyOrgExt.setPTRPARENTUCN(resultSet.getString("PTR_PARENT_UCN"));
						partyOrgExt.setPTRPARENTNM(resultSet.getString("PTR_PARENT_NM"));
						partyOrgExt.setPTRGLBLPARENTUCN(resultSet.getString("PTR_GLBL_PARENT_UCN"));
						/** changes for Track-3 -End */
						LOG.debug("===Inserting into PartyOrgExtType Map==");
						searchedRecCollObj.getPartyOrgMap().put(resultSet.getString("ROWID_ORG_EXTN"), partyOrgExt);
						}

				}



					if (resultSet.getString("ROWID_PRSN_EXTN") != null &&
							!searchedRecCollObj.getPartyPersonMap().containsKey(resultSet.getString("ROWID_PRSN_EXTN"))) {


					partyPersonExt = new PartyPersonExtType();
					LOG.debug("============adding PartyPersonExtType ");

					partyPersonExt.setROWIDPRSNEXTN(resultSet.getString("ROWID_PRSN_EXTN"));
					partyPersonExt.setPREFIX(resultSet.getString("PREFIX"));
					partyPersonExt.setFIRSTNAME(resultSet.getString("FIRST_NAME"));
					partyPersonExt.setLASTNAME(resultSet.getString("MIDDLE_NAME"));
					partyPersonExt.setLASTNAME(resultSet.getString("LAST_NAME"));
					partyPersonExt.setSUFFIX(resultSet.getString("SUFFIX"));
					partyPersonExt.setPERSONTYPE(resultSet.getString("PERSON_TYPE"));


					LOG.debug("===Inserting into PartyPersonExtType List===");
					searchedRecCollObj.getPartyPersonMap().put(resultSet.getString("ROWID_PRSN_EXTN"), partyPersonExt);
					}


						if (resultSet.getString("ROWID_CLASSIFCTN") != null &&
								!searchedRecCollObj.getClassMap().containsKey(resultSet.getString("ROWID_CLASSIFCTN"))) {

						if(resultSet.getString("CLASSIFCTN_HUB_STATE_IND")!=null && resultSet.getString("CLASSIFCTN_HUB_STATE_IND").equals("1")){
						classfction = new ClassificationType();
						LOG.debug("============adding ClassificationType ");


						classfction.setROWIDCLASSIFICTN(resultSet.getString("ROWID_CLASSIFCTN"));
						classfction.setCLASSIFICTNTYPE(resultSet.getString("CLASSIFCTN_TYPE"));
						classfction.setCLASSIFICTNVALUE(resultSet.getString("CLASSIFCTN_VALUE"));
						classfction.setSTARTDATE(resultSet.getString("START_DATE"));
						classfction.setENDDATE(resultSet.getString("END_DATE"));
						/* changes for SFDC - Track2 -Start */
						classfction.setCLASSIFICTNMETH(resultSet.getString("CLASSIFCTN_METH"));
						/* changes for SFDC - Track2 -End */
						LOG.debug("===Inserting into Classification Map===");
						searchedRecCollObj.getClassMap().put(resultSet.getString("ROWID_CLASSIFCTN"), classfction);
							}

					}
						/* changes for Hierarchy - Track2 -Start */
					if(bUniqueRec)	{
					Map<String,String> ucnMap = getMdmHierarchyView(partyRowId);	
					String wwParentUcn = ucnMap.get("PTR_GLBL_PARENT_UCN");
					LOG.debug("WW Parent UCN "+wwParentUcn);
					isGlobalParent = ucnMap.get("GLB_FLG");
					String globalParentName = ucnMap.get("MFE_GLOBAL_PAR_NM_OVRIDE");
					Map<String,String> partnerResellerUCNMap = null;
					if("Reseller".equalsIgnoreCase(partyType) || "Distributor".equalsIgnoreCase(partyType)){
						partnerResellerUCNMap = getPartnerRellserHierarchyView(partyRowId,partyType);
					}else{
						partnerResellerUCNMap = new HashMap<String,String>();
						partnerResellerUCNMap.put("MDM_PRTNR_ORG_UCN","");
						partnerResellerUCNMap.put("PRTNR_ORG_NM","");
					}
					//Added Geo and ww for Partner in 	partyAccountRelationship				
					 if(partyType.equalsIgnoreCase("Partner")||partyType.equalsIgnoreCase("Reseller")|| partyType.equalsIgnoreCase("Distributor")){
						LOG.debug("============adding Partner partyAccountRelationship ");
						rowidRelationship = "0";  // As there is no party relation so rel rowid is set as 0
						partyAccountRelationship = new PartyAccountRelationshipType();
						if(!Util.isNullOrEmpty(wwParentUcn)){
							LOG.debug("Populating Partner Hierarchy=== ");
							if (partyType.equalsIgnoreCase("Partner")) {
								partyAccountRelationship.setMDMPARENTUCN(ucnMap.get("PTR_PARENT_UCN"));
								partyAccountRelationship.setMDMPARENTNAME(ucnMap.get("PTR_PARENT_NM"));
							} else if (partyType.equalsIgnoreCase("Reseller")|| partyType.equalsIgnoreCase("Distributor")) {
								//Registered partner ucn change
								partyAccountRelationship.setMDMPARENTUCN(partnerResellerUCNMap.get("MDM_PRTNR_ORG_UCN"));
                                partyAccountRelationship.setMDMPARENTNAME(partnerResellerUCNMap.get("PRTNR_ORG_NM"));
							}
							partyAccountRelationship.setMDMGLBPARENTUCN(ucnMap.get("PTR_GLBL_PARENT_UCN"));
							partyAccountRelationship.setMDMGLBPARENTNAME(ucnMap.get("MFE_WW_PARENT_PRTN_NM"));
							partyAccountRelationship.setHIERARCHYTYPE(Constant.Partner_Hierarchy);
						}
						if (partyAccountRelationship.getHIERARCHYTYPE() != null && hierarchyGRP.contains(partyAccountRelationship.getHIERARCHYTYPE())){
							if (!searchedRecCollObj.getPartyAcctRelMap()
									.containsKey(Constant.Partner_Hierarchy+rowidRelationship) ){
							LOG.debug("======Inserting into Partner Relationship Map======");
							searchedRecCollObj.getPartyAcctRelMap().put(partyAccountRelationship.getHIERARCHYTYPE()+rowidRelationship, partyAccountRelationship);
						}
					 }
						
					} else {
					rowidRelationship =  resultSet.getString("ROWID_PARTY_REL");
					if (rowidRelationship != null ){
						if(resultSet.getInt("REL_HUB_STATE_IND") == 1){
						if (!searchedRecCollObj.getPartyAcctRelMap()
								.containsKey(Constant.McAfee_Hierarchy+rowidRelationship) && !searchedRecCollObj.getPartyAcctRelMap()
								.containsKey(Constant.Partner_Hierarchy+rowidRelationship) ){
							partyAccountRelationship = new PartyAccountRelationshipType();
							partyAccountRelationship.setRELTYPE(resultSet.getString("REL_TYPE_CODE"));
							 hierarchyCd = resultSet.getString("HIERARCHY_CODE");
							partyAccountRelationship.setHIERARCHYTYPE(resultSet.getString("HIERARCHY_CODE"));
							partyAccountRelationship.setSINGLESITEFLAG(Constant.STR_N);
							if(null != hierarchyCd){
								if(Constant.McAfee_Hierarchy.equalsIgnoreCase(hierarchyCd)){
								
									partyAccountRelationship.setMDMPARENTUCN(ucnMap.get("MDM_PARENT_UCN"));
									partyAccountRelationship.setMDMPARENTNAME(ucnMap.get("MFE_PARENT_NM"));
									partyAccountRelationship.setMDMGLBPARENTUCN(ucnMap.get("MFE_GLBL_PARENT_UCN"));
									if(Util.isNullOrEmpty(globalParentName))	{
										partyAccountRelationship.setMDMGLBPARENTNAME(ucnMap.get("MFE_GLBL_PARENT_NM"));
										}
										else{
											partyAccountRelationship.setMDMGLBPARENTNAME(ucnMap.get("MFE_GLOBAL_PAR_NM_OVRIDE"));
										}
								}else if(Constant.Partner_Hierarchy.equalsIgnoreCase(hierarchyCd)){
									if("Reseller".equalsIgnoreCase(partyType) || "Distributor".equalsIgnoreCase(partyType)){
										partyAccountRelationship.setMDMPARENTUCN(partnerResellerUCNMap.get("MDM_PRTNR_ORG_UCN"));
										partyAccountRelationship.setMDMPARENTNAME(partnerResellerUCNMap.get("PRTNR_ORG_NM"));
									}else {
										partyAccountRelationship.setMDMPARENTUCN(ucnMap.get("PTR_PARENT_UCN"));
										partyAccountRelationship.setMDMPARENTNAME(ucnMap.get("PTR_PARENT_NM"));
									}
									partyAccountRelationship.setMDMGLBPARENTUCN(ucnMap.get("PTR_GLBL_PARENT_UCN"));
									partyAccountRelationship.setMDMGLBPARENTNAME(ucnMap.get("MFE_WW_PARENT_PRTN_NM"));
									partyAccountRelationship.setHIERARCHYTYPE(Constant.Partner_Hierarchy);
								}
								
								if (partyAccountRelationship.getHIERARCHYTYPE() != null && hierarchyGRP.contains(partyAccountRelationship.getHIERARCHYTYPE())) {
									LOG.debug("===Inserting into Child Relationship Map==="+partyAccountRelationship.getHIERARCHYTYPE()+rowidRelationship);
									searchedRecCollObj.getPartyAcctRelMap().put(partyAccountRelationship.getHIERARCHYTYPE()+rowidRelationship,
											partyAccountRelationship);
								}
							}
							
								
					}
					}	
				}else if ((!Util.isNullOrEmpty(isGlobalParent)) && isGlobalParent.equalsIgnoreCase("Y")) {
					List<GlobalHierarchyNode> globalHierarchyNodeList = getGlobalHierarchy(partyRowId);
					
					for(GlobalHierarchyNode globalHierarchyNode : globalHierarchyNodeList) {
						partyAccountRelationship = new PartyAccountRelationshipType();
						if (globalHierarchyNode.getPartyRelRowid() != null && (!searchedRecCollObj
								.getPartyRelMap().containsKey(Constant.McAfee_Hierarchy+globalHierarchyNode.getPartyRelRowid()) && !searchedRecCollObj
								.getPartyRelMap().containsKey(Constant.Partner_Hierarchy+globalHierarchyNode.getPartyRelRowid()))) {
							LOG.debug("===Inserting into Relationship Map for GLOBAL Parent===" + globalHierarchyNode.getPartyRelRowid());
							partyAccountRelationship.setSINGLESITEFLAG(Constant.STR_N);
							rowidRelationship = globalHierarchyNode.getPartyRelRowid();
							partyAccountRelationship.setRELTYPE(globalHierarchyNode.getRelTypeCode());
							hierarchyCd = globalHierarchyNode.getHierarchyCode();
							partyAccountRelationship.setHIERARCHYTYPE(hierarchyCd);
							if(hierarchyCd != null){
								if (Constant.McAfee_Hierarchy.equalsIgnoreCase(hierarchyCd)) {
	
									partyAccountRelationship.setMDMPARENTUCN(ucnMap.get("MDM_PARENT_UCN"));
									partyAccountRelationship.setMDMPARENTNAME(ucnMap.get("MFE_PARENT_NM"));
									partyAccountRelationship.setMDMGLBPARENTUCN(ucnMap.get("MFE_GLBL_PARENT_UCN"));
									if(Util.isNullOrEmpty(globalParentName))	{
										partyAccountRelationship.setMDMGLBPARENTNAME(ucnMap.get("MFE_GLBL_PARENT_NM"));
										}
										else{
											partyAccountRelationship.setMDMGLBPARENTNAME(ucnMap.get("MFE_GLOBAL_PAR_NM_OVRIDE"));
										}
								} 
								else if(Constant.Partner_Hierarchy.equalsIgnoreCase(hierarchyCd)){
									if("Reseller".equalsIgnoreCase(partyType) || "Distributor".equalsIgnoreCase(partyType)){
										partyAccountRelationship.setMDMPARENTUCN(partnerResellerUCNMap.get("MDM_PRTNR_ORG_UCN"));
										partyAccountRelationship.setMDMPARENTNAME(partnerResellerUCNMap.get("PRTNR_ORG_NM"));
									}else {
										partyAccountRelationship.setMDMPARENTUCN(ucnMap.get("PTR_PARENT_UCN"));
										partyAccountRelationship.setMDMPARENTNAME(ucnMap.get("PTR_PARENT_NM"));
									}
									partyAccountRelationship.setMDMGLBPARENTUCN(ucnMap.get("PTR_GLBL_PARENT_UCN"));
									partyAccountRelationship.setMDMGLBPARENTNAME(ucnMap.get("MFE_WW_PARENT_PRTN_NM"));
									partyAccountRelationship.setHIERARCHYTYPE(Constant.Partner_Hierarchy);
								}
								if (partyAccountRelationship.getHIERARCHYTYPE() != null && hierarchyGRP.contains(partyAccountRelationship.getHIERARCHYTYPE())) {
									LOG.debug("===Inserting into Parent Relationship Map==="+partyAccountRelationship.getHIERARCHYTYPE()+rowidRelationship);
									searchedRecCollObj.getPartyAcctRelMap().put(partyAccountRelationship.getHIERARCHYTYPE()+rowidRelationship,
											partyAccountRelationship);
								}
							}
						
						}
					}
				}	
				else {
					if(searchedRecCollObj.getPartyAcctRelMap().isEmpty()){
						LOG.debug("============adding dummy partyAccountRelationship ");
						rowidRelationship = "0";  // As there is no party relation so rel rowid is set as 0
						partyAccountRelationship = new PartyAccountRelationshipType();
						if(!Util.isNullOrEmpty(wwParentUcn)){
							LOG.debug("Populating Partner Hierarchy=== ");
							if("Reseller".equalsIgnoreCase(partyType) || "Distributor".equalsIgnoreCase(partyType)){
								partyAccountRelationship.setMDMPARENTUCN(partnerResellerUCNMap.get("MDM_PRTNR_ORG_UCN"));
								partyAccountRelationship.setMDMPARENTNAME(partnerResellerUCNMap.get("PRTNR_ORG_NM"));
							}else {
								partyAccountRelationship.setMDMPARENTUCN(ucnMap.get("PTR_PARENT_UCN"));
								partyAccountRelationship.setMDMPARENTNAME(ucnMap.get("PTR_PARENT_NM"));
							}
							partyAccountRelationship.setMDMGLBPARENTUCN(ucnMap.get("PTR_GLBL_PARENT_UCN"));
							partyAccountRelationship.setMDMGLBPARENTNAME(ucnMap.get("MFE_WW_PARENT_PRTN_NM"));
							partyAccountRelationship.setHIERARCHYTYPE(Constant.Partner_Hierarchy);
						}else if(!"Y".equalsIgnoreCase(isGlobalParent)){
							partyAccountRelationship.setMDMPARENTUCN(searchedRecCollObj.getUcn());
							partyAccountRelationship.setMDMPARENTNAME(searchedRecCollObj.getParty_name());
							partyAccountRelationship.setMDMGLBPARENTUCN(searchedRecCollObj.getUcn());
							partyAccountRelationship.setMDMGLBPARENTNAME(searchedRecCollObj.getParty_name());
							partyAccountRelationship.setHIERARCHYTYPE(Constant.McAfee_Hierarchy);
							partyAccountRelationship.setSINGLESITEFLAG(Constant.STR_Y);
						} 						
						if (partyAccountRelationship.getHIERARCHYTYPE() != null && hierarchyGRP.contains(partyAccountRelationship.getHIERARCHYTYPE())){
							LOG.debug("======Inserting into Single Site Relationship Map======");
							searchedRecCollObj.getPartyAcctRelMap().put(rowidRelationship, partyAccountRelationship);
						}
					
					}
				}
				}
					}
					/* changes for Hierarchy - Track2 -End */
					bUniqueRec = false;
			}
				LOG.info("searchedRecCollMap size iss "+searchedRecCollMap.size()+"Keyset "+searchedRecCollMap.keySet()+"SRC_SYSTEM "+srcSystemName);
			if(searchedRecCollMap.size() == 0) {
				searchPartyMasterResponse.setStatus("No Record Found with MatchScore more than Match_score_thresold value.");
				return searchPartyMasterResponse;
			}
			LOG.info("Before Fetching Xref "+searchXrefDao);
			Map<String, List<PartyXrefType>> partyXrefListMap = searchXrefDao.processXrefSearchRequest(searchedRecCollMap.keySet(),srcSystemName);
			for(Entry<String, List<PartyXrefType>> entry : partyXrefListMap.entrySet())	{
				LOG.debug("partyXrefListMap partyRowId: " + entry.getKey() + "| partyXrefListMap Xrefs:" + entry.getValue().size());
				for(PartyXrefType pXref : entry.getValue())	{
					LOG.debug("pXref Orig_RowidObject: " + pXref.getORIGROWIDOBJECT());
				}
			}

			for (Entry<String, SearchedRecordCollection> mapEntry : searchedRecCollMap.entrySet()) {

			//		LOG.debug("====Populating XREFCopyList.");
			//		xrefCopyList = searchXrefDao.processXrefSearchRequest(mapEntry.getKey(), recCntThres);
				//if(partyXrefListMap.containsKey(mapEntry.getKey()))	{

					LOG.debug("====Populating PartyType");

					partyResponse = new PartyType();
					partyResponse.setROWIDOBJECT(mapEntry.getValue().getParty_rowid());
					partyResponse.setBOCLASSCODE(mapEntry.getValue().getBo_class());
					partyResponse.setPARTYTYPE(mapEntry.getValue().getParty_type());
					partyResponse.setPARTYNAME(mapEntry.getValue().getParty_name());
					partyResponse.setGEO(mapEntry.getValue().getGeo());
					partyResponse.setREGION(mapEntry.getValue().getRegion());
					partyResponse.setSALESBLOCKCD(mapEntry.getValue().getSales_cd());
					partyResponse.setSTATUSCD(mapEntry.getValue().getStatus_cd());
					partyResponse.setTAXJURSDCTNCD(mapEntry.getValue().getTax_jd_cd());
					partyResponse.setUCN(mapEntry.getValue().getUcn());
					partyResponse.setVATREGNBR(mapEntry.getValue().getVat_regno());

					//Change for English Name :: Adding English name field to response
					partyResponse.setENGLISHNAME(mapEntry.getValue().getEnglish_name());
					partyResponse.setPHYSICALGEO(mapEntry.getValue().getPhysicalGeo());
					partyResponse.setPHYSICALREGION(mapEntry.getValue().getPhysicalRegion());
					LOG.debug("==Populating party's XREFType==");
					xref = new XREFType();
					String partyID = mapEntry.getValue().getParty_rowid();
					getPartyXref(partyID, xref);
					partyResponse.getXREF().add(xref);
					partyResponse.getAccount().addAll(mapEntry.getValue().getAccountMap().values());
					partyResponse.getAddress().addAll(mapEntry.getValue().getAddressMap().values());
					partyResponse.getCommunication().addAll(mapEntry.getValue().getCommMap().values());
					partyResponse.getPartyOrgExt().addAll(mapEntry.getValue().getPartyOrgMap().values());
					partyResponse.getPartyPersonExt().addAll(mapEntry.getValue().getPartyPersonMap().values());
					partyResponse.getClassification().addAll(mapEntry.getValue().getClassMap().values());
					
					/** Modified for M4M START */
					PartyRelationshipType partyRel = partyResponse.getPartyRel();
					if(partyRel == null) {
						partyRel = new PartyRelationshipType();
					}
					partyRel.getPARTYACCOUNTREL().addAll(mapEntry.getValue().getPartyAcctRelMap().values());
					partyResponse.setPartyRel(partyRel);
					/** Modified for M4M END */

					LOG.debug("====Populating GoldenCopy");
					goldenCpy = new GoldenCopy();
					goldenCpy.setParty(partyResponse);
					goldenCpy.setMatchScore(mapEntry.getValue().getMtchScoreValue());


					LOG.debug("====Populating PartyProfile");
					partyProfile = new PartyProfileType();
					partyProfile.setGoldenCopy(goldenCpy);
					//partyProfile.getXREFCopy().addAll(xrefCopyList);
					/** changes for Sales Force Integration*/
					if(partyXrefListMap.containsKey(partyResponse.getROWIDOBJECT()))	{
					xrefCopy = new XREFCopy();
					LOG.debug("Adding XREF Copies in master response ");
					//if (!partyXrefListMap.isEmpty()){
					xrefCopy.getPartyXref().addAll(partyXrefListMap.get(partyResponse.getROWIDOBJECT()));
				//	xrefCopyList.add(xrefCopy);
					partyProfile.getXREFCopy().add(xrefCopy);
					}
					partyProfileList.add(partyProfile);
				/*} else {
					LOG.debug("Excluding DnB Singleton Rowid: " + mapEntry.getKey());
				}*/

			}

			LOG.debug("Sorting Matched Results in descending order of MatchScore.");
			Collections.sort(partyProfileList, new Comparator<PartyProfileType>()	{
		        public int compare(PartyProfileType p1, PartyProfileType p2)	{
		              // Write your logic here.
		        	int diffMatchScore = 0;
		        	if(p1.getGoldenCopy().getMatchScore() != null && p2.getGoldenCopy().getMatchScore() != null)	{
		        		diffMatchScore = p2.getGoldenCopy().getMatchScore().compareTo(p1.getGoldenCopy().getMatchScore());
		        	}

		        	return diffMatchScore;
		        }}
			);



			//Populating NULL tags in Response Canonical Format
			if (partyProfileList.size() != 0) {
				for(int indx = 0 ; indx < partyProfileList.size(); indx++)	{
					CanonicalFormManipulator.setDefaultValueInGoldenAttributes(partyProfileList.get(indx).getGoldenCopy().getParty());
				}
			}

			
			if (partyProfileList.size() != 0) {
				LOG.debug("finally adding in master response ");
				searchPartyMasterResponse.getPartyProfile().addAll(partyProfileList);
				searchPartyMasterResponse.setStatus(partyProfileList.size() + " Accounts successfully found!");
			}


		} catch (Exception exp) {
			LOG.error(" Caught Exception in searchMatchResponse "+exp.getMessage());
			if(exp.getMessage().contains("Failed to create JDBC connection")){
				searchPartyMasterResponse.setErrorMsg(Constant.DB_CONN_FAILURE+" "+exp.getMessage());
				searchPartyMasterResponse.setStatus("ERROR");
			}else{
			searchPartyMasterResponse.setErrorMsg(searchPartyMasterResponse.getErrorMsg() == null ? "":"\n");
			searchPartyMasterResponse.setErrorMsg(searchPartyMasterResponse.getErrorMsg() + " " + Constant.unExpectedError + exp);
			}
			ServiceProcessingException customException = new ServiceProcessingException(exp);
			customException.setMessage("Failed to process search request." + customException.getMessage());
			throw customException;
		}
		HierarchyFuzzySearch = false;
		LOG.info("Completed createGoldenCopyFuzzySearch()");
		return searchPartyMasterResponse;

	}

	//Fetch GoldenCopy Records from PKG_PARTY_JMS_MQ_PUB for FUZZY SEARCH
	public SearchPartyResponse  getAllPartyGolden(Set<String> rowidObjectSet,String srcSystemName) throws ServiceProcessingException {
		LOG.info("Executing getAllPartyGolden()");

		SearchPartyResponse searchPartyMasterResp = null;
		PreparedStatement pstmt = null;
		Statement statement = null;
		StringBuilder sqlQry = new StringBuilder();
		JDBCConnectionProvider jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
		Connection jdbcConnection = null;
		ResultSet resultSet = null;


		try {
			LOG.info("Fetching Golden copies for rowidObjectSet: " + rowidObjectSet);

			sqlQry.append("SELECT * FROM PKG_PARTY_JMS_MQ_PUB a WHERE ROWID_OBJECT in (");

			for (String partyRowId : rowidObjectSet) {
				sqlQry.append("'" + partyRowId + "',");
			}
			sqlQry.deleteCharAt(sqlQry.length() - 1).toString();
			sqlQry.append(") AND HUB_STATE_IND <> '" + -1 + "'");
			sqlQry.append(" AND STATUS_CD = '" + "A" + "'");
			sqlQry.append(" AND BO_CLASS_CODE = '" + "Organization" + "'");
			sqlQry.append(" AND PARTY_TYPE in ('" + "Customer'," + "'Partner'," + "'Reseller'," + "'Distributor" + "')");
			//** Modified for SFDC START *//*
			//sqlQry.append(" AND NVL(DRAFT_FLG,'N')<>'" + "Y" + "'");
			sqlQry.append(" AND EXISTS (SELECT 1 FROM C_B_ACCOUNT_XREF WHERE C_B_ACCOUNT_XREF.ROWID_OBJECT=ROWID_ACCOUNT AND NVL(DRAFT_FLG,'N')='N')");
			//** Modified for SFDC END *//*
			
			/*Modified for MDMP-3065: Fuzzy Search look up issue:: START*/
			sqlQry.append(" and Exists (select 1 from c_b_party_xref where c_b_party_xref.status_cd = 'A' and c_b_party_xref.ROWID_SYSTEM IN ('SAP','SBL','SFC','FNO','ADB') and c_b_party_xref.rowid_object = a.rowid_object)");
			/*Modified for MDMP-3065: Fuzzy Search look up issue:: END*/
			/*Modified for MDMP-3093: Fuzzy Search look up issue:: START*/
			sqlQry.append("AND nvl(trunc(END_DATE),'31-DEC-9999') = '31-DEC-9999'");
			sqlQry.append(" AND NVL(ADDR_HUB_STATE_IND,1)  = 1");
			
			//Commented as per Venkat's review comment for defect - ODOM-2445
			/*sqlQry.append(" AND NVL(COMM_HUB_STATE_IND,1)  = 1");
			sqlQry.append(" AND NVL(ORG_EXTN_HUB_STATE_IND,1)  = 1");
			sqlQry.append(" AND NVL(CLASSIFCTN_HUB_STATE_IND,1)  = 1");*/
			
			//sqlQry.append(" AND NVL(REL_HUB_STATE_IND,1)  = 1");
			/*Modified for MDMP-3093: Fuzzy Search look up issue:: END*/
	//		sqlQry.append("SELECT * FROM PKG_PARTY_JMS_MQ_PUB WHERE HUB_STATE_IND <> '" + -1 + "' AND STATUS_CD = 'A' AND BO_CLASS_CODE = 'Organization'");
	//		sqlQry.append(" AND PARTY_TYPE in ('Customer','Partner','Reseller','Distributor')");
			/* Modified for SFDC START */
	//		sqlQry.append(" AND EXISTS (SELECT 1 FROM C_B_ACCOUNT_XREF WHERE C_B_ACCOUNT_XREF.ROWID_OBJECT=ROWID_ACCOUNT AND NVL(DRAFT_FLG,'N')='N')");
			/* Modified for SFDC END */
	//		sqlQry.append(" AND ROWID_OBJECT = ? ");
		
			LOG.debug("Query to fetch partyGoldenMap: " + sqlQry);


			jdbcConnection = jDBCConnectionProvider.getJdbcConnectionFromDS();
		//	jdbcConnection = JdbcConn.GetJdbcConnObject();
		//	jdbcConnection.setAutoCommit(false);
			statement = jdbcConnection.createStatement();
			resultSet = statement.executeQuery(sqlQry.toString());
			searchPartyMasterResp = createGoldenCopyFuzzySearch(resultSet,srcSystemName);
			
	/*		pstmt = jdbcConnection.prepareStatement(sqlQry.toString());
			for (String partyRowId : rowidObjectSet) {
				pstmt.setString(1, partyRowId);
				pstmt.addBatch();
			}
			
			resultSet = pstmt.executeQuery();
			searchPartyMasterResp = createGoldenCopyFuzzySearch(resultSet);
	 */
		} catch (SQLException sqlEx) {
			LOG.error("Exception occurred in getAllPartyGolden while fetching Party profile: " + sqlEx);
			sqlEx.printStackTrace();
			ServiceProcessingException customException = new ServiceProcessingException(sqlEx);
			customException.setMessage("Failed to fetch Party profile from ORS." + customException.getMessage());
			throw customException;
		} catch(ServiceProcessingException se){
		
			if(se.getMessage().contains(Constant.DB_CONN_FAILURE)){
				throw se;
			}
			
		}finally {
		
				try {
					if( resultSet != null) resultSet.close();
					if( pstmt != null) pstmt.close();
					if( statement != null) statement.close();
					if(jdbcConnection != null) jdbcConnection.close();
				} catch (SQLException e) {
					LOG.error("Sql Exception occurred in getAllPartyGolden : " + e);
					//e.printStackTrace();
				}
		}

		LOG.info("Executed getAllPartyGolden()");

		return searchPartyMasterResp;
	}
//Track-2 start
	public SearchPartyHierarchyResponse  getAllHierarchyPartyGolden(Map<String, Integer> searchRecords,String srcSystemName) throws ServiceProcessingException {
		LOG.info("Executing getAllPartyGolden()");

		SearchPartyResponse searchPartyMasterResp = null;
		SearchPartyHierarchyResponse searchPartyHierarchyResponse = null;
		PreparedStatement pstmt = null;
		Statement statement = null;
		StringBuilder sqlQry = new StringBuilder();
		JDBCConnectionProvider jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
		Connection jdbcConnection = null;
		ResultSet resultSet = null;


		try {
			Set<String> rowidObjectSet = searchRecords.keySet();
			LOG.info("Fetching Golden copies for rowidObjectSet: " + rowidObjectSet);

			sqlQry.append("SELECT * FROM PKG_PARTY_JMS_MQ_PUB WHERE ROWID_OBJECT in (");

			for (String partyRowId : rowidObjectSet) {
				sqlQry.append("'" + partyRowId + "',");
			}
			sqlQry.deleteCharAt(sqlQry.length() - 1).toString();
			sqlQry.append(") AND HUB_STATE_IND <> '" + -1 + "'");
			sqlQry.append(" AND STATUS_CD = '" + "A" + "'");
			sqlQry.append(" AND BO_CLASS_CODE = '" + "Organization" + "'");
			sqlQry.append(" AND PARTY_TYPE in ('" + "Customer'," + "'Partner'," + "'Reseller'," + "'Distributor" + "')");
			sqlQry.append(" AND EXISTS (SELECT 1 FROM C_B_ACCOUNT_XREF WHERE C_B_ACCOUNT_XREF.ROWID_OBJECT=ROWID_ACCOUNT AND NVL(DRAFT_FLG,'N')='N')");
			sqlQry.append(" and Exists (select 1 from c_b_party_xref where c_b_party_xref.status_cd = 'A' and c_b_party_xref.ROWID_SYSTEM IN ('SAP','SBL','SFC','FNO','ADB') and c_b_party_xref.rowid_object = rowid_object)");
			/*Modified for MDMP-3093: Fuzzy Search look up issue:: START*/
			sqlQry.append("AND nvl(trunc(END_DATE),'31-DEC-9999') = '31-DEC-9999'");
			sqlQry.append(" AND NVL(ADDR_HUB_STATE_IND,1)  = 1");
			sqlQry.append(" AND NVL(COMM_HUB_STATE_IND,1)  = 1");
			sqlQry.append(" AND NVL(ORG_EXTN_HUB_STATE_IND,1)  = 1");
			sqlQry.append(" AND NVL(CLASSIFCTN_HUB_STATE_IND,1)  = 1");
			//sqlQry.append(" AND NVL(REL_HUB_STATE_IND,1)  = 1");
	
		
			LOG.debug("Query to fetch partyGoldenMap: " + sqlQry);


			jdbcConnection = jDBCConnectionProvider.getJdbcConnectionFromDS();
		//	jdbcConnection = JdbcConn.GetJdbcConnObject();
		//	jdbcConnection.setAutoCommit(false);
			statement = jdbcConnection.createStatement();
			resultSet = statement.executeQuery(sqlQry.toString());
			searchPartyMasterResp = createGoldenCopyFuzzySearch(resultSet,srcSystemName);
			
	/*		pstmt = jdbcConnection.prepareStatement(sqlQry.toString());
			for (String partyRowId : rowidObjectSet) {
				pstmt.setString(1, partyRowId);
				pstmt.addBatch();
			}
			
			resultSet = pstmt.executeQuery();
			searchPartyMasterResp = createGoldenCopyFuzzySearch(resultSet);
	 */
		} catch (SQLException sqlEx) {
			LOG.error("Exception occurred in getAllPartyGolden while fetching Party profile: " + sqlEx);
			sqlEx.printStackTrace();
			ServiceProcessingException customException = new ServiceProcessingException(sqlEx);
			customException.setMessage("Failed to fetch Party profile from ORS." + customException.getMessage());
			throw customException;
		} finally {
				try {
					if( resultSet != null) resultSet.close();
					if( pstmt != null) pstmt.close();
					if( statement != null) statement.close();
					if(jdbcConnection != null) jdbcConnection.close();
				} catch (SQLException e) {
					LOG.error("Sql Exception occurred in getAllPartyGolden : " + e);
					//e.printStackTrace();
				}
		}

		LOG.info("Executed getAllPartyGolden()");

		return searchPartyHierarchyResponse;
	}
	
	//ID based Search service
		public SearchPartyResponse processFuzzySearchRequest(SearchPartyRequest parameters, String srcSysID) throws ServiceProcessingException {

			LOG.info("Executing processFuzzySearchRequest() for ID based Search");

			SearchPartyResponse searchPartyMasterResponse = new SearchPartyResponse();
			PartyProfileType partyProfile = null;
			List<PartyProfileType> partyProfileList = new ArrayList<PartyProfileType>();
			GoldenCopy goldenCpy = null;
			XREFCopy xrefCopy = null;
			PartyType partyResponse = null;
			XREFType xref = null;

			Map<String, PartyType> goldenRecMap = null;
			Map<String, List<PartyXrefType>> partyXrefMap = null;
			String srcSystemName = parameters.getPartySearchCriteria().getSRCSYSTEM();
			String survivorRowid = null ;

			try{
			goldenRecMap = getGoldenRecforID(srcSysID, srcSystemName);

			if(goldenRecMap == null) {

				searchPartyMasterResponse.setStatus("The SourceSystemID: " + srcSysID +" does not exist in MDM.");
				return searchPartyMasterResponse;
			}

			survivorRowid = rowid_object;
			
			partyXrefMap = getXrefRecforID(survivorRowid,srcSystemName,null, false);

			for (Entry<String, PartyType> mapEntry : goldenRecMap.entrySet()) {

				//		LOG.debug("====Populating XREFCopyList.");
				//		xrefCopyList = searchXrefDao.processXrefSearchRequest(mapEntry.getKey(), recCntThres);


						LOG.debug("====Populating PartyType");
						partyResponse = mapEntry.getValue();

						LOG.debug("==Populating party's XREFType==");
						xref = new XREFType();
						String partyID = partyResponse.getROWIDOBJECT();
						getPartyXref(partyID, xref);
						partyResponse.getXREF().add(xref);

						LOG.debug("====Populating GoldenCopy");
						goldenCpy = new GoldenCopy();
						goldenCpy.setParty(partyResponse);
						goldenCpy.setMatchScore(100);


						LOG.debug("====Populating PartyProfile");
						partyProfile = new PartyProfileType();
						partyProfile.setGoldenCopy(goldenCpy);

						xrefCopy = new XREFCopy();
						LOG.debug("Adding XREF Copies in master response ");
						xrefCopy.getPartyXref().addAll(partyXrefMap.get(partyResponse.getROWIDOBJECT()));
					//	xrefCopyList.add(xrefCopy);
						partyProfile.getXREFCopy().add(xrefCopy);

						partyProfileList.add(partyProfile);

				}

			//Populating NULL tags in Response Canonical Format
			if (partyProfileList.size() != 0) {
			//	for(int indx = 0 ; indx < partyProfileList.size(); indx++)	{
				for(PartyProfileType ppT: partyProfileList){
				//	CanonicalFormManipulator.setDefaultValueInGoldenAttributes(partyProfileList.get(indx).getGoldenCopy().getParty());
					CanonicalFormManipulator.setDefaultValueInGoldenAttributes(ppT.getGoldenCopy().getParty());
				//	CanonicalFormManipulator.setDefaultValueInXrefAttributes(partyProfileList.get(indx).getXREFCopy().get(indx).getPartyXref().get(indx));
					for(XREFCopy xrefcpy: ppT.getXREFCopy()){
						for(PartyXrefType partyXref: xrefcpy.getPartyXref()){
							CanonicalFormManipulator.setDefaultValueInXrefAttributes(partyXref);
						}
					}
				}
			}
			}catch(ServiceProcessingException se){
				if(se.getMessage().contains(Constant.DB_CONN_FAILURE)){
					searchPartyMasterResponse.setErrorMsg("Database Connection Failure Issue ::"+se.getMessage());
					searchPartyMasterResponse.setStatus("ERROR");
				}
			}
			LOG.debug("finnaly adding in master response ");
			if (partyProfileList.size() != 0) {

				searchPartyMasterResponse.getPartyProfile().addAll(partyProfileList);
				searchPartyMasterResponse.setStatus(partyProfileList.size() + " Accounts successfully found!");
			}

			LOG.info("Executed processFuzzySearchRequest() for ID based Search");

			return searchPartyMasterResponse;
		}
//Modified for Track2
		//Method to get Relationship details from Org extn
	public Map<String,String> getMdmHierarchyView(String rowidParty) throws SQLException, ServiceProcessingException	{
		LOG.debug("getMdmHierarchyView::Inside getMdmHierarchyView" );
		Connection jdbcConn = null;
		PreparedStatement pstatement = null;
		ResultSet resultSet = null;
		JDBCConnectionProvider jDBCConnectionProvider =  null;
	//	jdbcConn = JdbcConn.GetJdbcConnObject();
		Map<String,String> ucnMap = new HashMap<String,String>();
		String sql = "SELECT MDM_PARENT_UCN,MFE_PARENT_NM,MFE_GLBL_PARENT_UCN,MFE_GLBL_PARENT_NM, GLB_FLG,MFE_WW_PARENT_PRTN_NM,MFE_SUBSDRY_PARENT_PRTN_NM,MFE_GLOBAL_PAR_NM_OVRIDE,PTR_PARENT_UCN,PTR_PARENT_NM,PTR_GLBL_PARENT_UCN,MFE_SUBS_PARENT_UCN,MFE_SUBS_PARENT_NM,MFE_NEXT_LVL_SUBS_PAR_UCN,MFE_NEXT_LVL_SUBS_PAR_NM FROM C_B_PARTY_ORG_EXTN where HUB_STATE_IND =1 AND ROWID_PARTY= ?";
		try{
			jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
			jdbcConn = jDBCConnectionProvider.getJdbcConnectionFromDS();
			pstatement = jdbcConn.prepareStatement(sql);
			pstatement.setString(1, rowidParty);
			resultSet = pstatement.executeQuery();
		//	System.out.println(pstatement.getMaxRows());

			while (resultSet.next()) {

				ucnMap.put("MDM_PARENT_UCN",resultSet.getString(1));
				ucnMap.put("MFE_PARENT_NM",resultSet.getString(2));
				ucnMap.put("MFE_GLBL_PARENT_UCN", resultSet.getString(3));
				ucnMap.put("MFE_GLBL_PARENT_NM", resultSet.getString(4));
				ucnMap.put("GLB_FLG", resultSet.getString(5));
				ucnMap.put("MFE_WW_PARENT_PRTN_NM", resultSet.getString(6));
				ucnMap.put("MFE_SUBSDRY_PARENT_PRTN_NM", resultSet.getString(7));
				ucnMap.put("MFE_GLOBAL_PAR_NM_OVRIDE", resultSet.getString(8));
				ucnMap.put("PTR_PARENT_UCN", resultSet.getString(9));
				ucnMap.put("PTR_PARENT_NM", resultSet.getString(10));
				ucnMap.put("PTR_GLBL_PARENT_UCN", resultSet.getString(11));
				ucnMap.put("MFE_SUBS_PARENT_UCN", resultSet.getString(12));
				ucnMap.put("MFE_SUBS_PARENT_NM", resultSet.getString(13));
				ucnMap.put("MFE_NEXT_LVL_SUBS_PAR_UCN", resultSet.getString(14));
				ucnMap.put("MFE_NEXT_LVL_SUBS_PAR_NM", resultSet.getString(15));
				
			}
		} catch(SQLException exp)	{
			LOG.error("Caught exception in getMdmHierarchyView()" + exp.getMessage());
			if(exp.getMessage().contains("Failed to create JDBC connection")){
				ServiceProcessingException customException= new ServiceProcessingException(exp);
				customException.setMessage(Constant.DB_CONN_FAILURE+" Caught exception in getMdmHierarchyView() :: "+exp.getMessage());
				throw customException;
			}
		} catch (ServiceProcessingException e) {

			LOG.error("Caught exception in getMdmHierarchyView()" + e.getMessage());
		}
			finally	{
				//Closing connections
				if (resultSet != null)  resultSet.close();
				if (pstatement != null) pstatement.close();
				if (jdbcConn != null) jdbcConn.close();
			}
		LOG.debug("Executed getMdmHierarchyView");
		return ucnMap;
	}
	
	public Map<String,String> getPartnerRellserHierarchyView(String rowidParty,String partyType) throws SQLException, ServiceProcessingException	{
		LOG.debug("Inside getPartnerRellserHierarchyView" );
		Connection jdbcConn = null;
		PreparedStatement pstatement = null;
		ResultSet resultSet = null;
		JDBCConnectionProvider jDBCConnectionProvider =  null;
		Map<String,String> ucnMap = new HashMap<String,String>();
		String sql = "select DISTINCT MDM_PRTNR_ORG_UCN,PRTNR_ORG_NM from MDM_PRTNR_HIER_DENORM_VIEW where MDM_PRTNR_ACCT_ROWID=? and PARTY_TYPE=?";
		try{
			jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
			jdbcConn = jDBCConnectionProvider.getJdbcConnectionFromDS();
			pstatement = jdbcConn.prepareStatement(sql);
			pstatement.setString(1, rowidParty);
			pstatement.setString(2, partyType);
			resultSet = pstatement.executeQuery();

			while (resultSet.next()) {

				ucnMap.put("MDM_PRTNR_ORG_UCN",resultSet.getString(1));
				ucnMap.put("PRTNR_ORG_NM",resultSet.getString(2));
			}
		} catch(SQLException exp)	{
			LOG.error("Caught exception in getPartnerRellserHierarchyView()" + exp.getMessage());
			if(exp.getMessage().contains("Failed to create JDBC connection")){
				ServiceProcessingException customException= new ServiceProcessingException(exp);
				customException.setMessage(exp.getMessage());
				throw customException;
			}
		} catch (ServiceProcessingException e) {

			LOG.error("Caught exception in getPartnerRellserHierarchyView()" + e.getMessage());
		}
			finally	{
				//Closing connections
				if (resultSet != null)  resultSet.close();
				if (pstatement != null) pstatement.close();
				if (jdbcConn != null) jdbcConn.close();
			}
		LOG.debug("Executed getMdmHierarchyView");
		
		if(ucnMap.size()==0){
			ucnMap.put("MDM_PRTNR_ORG_UCN","");
			ucnMap.put("PRTNR_ORG_NM","");
		}
		return ucnMap;
	}

	//Method To Fetch Party XREFType
	public void getPartyXref(String partyID, XREFType xref) throws ServiceProcessingException	{
		Connection jdbcConn = null;
		PreparedStatement pstatement = null;
		ResultSet resultSet = null;
		JDBCConnectionProvider jDBCConnectionProvider =  JDBCConnectionProvider.getSingleInstance();
		jdbcConn = jDBCConnectionProvider.getJdbcConnectionFromDS();
		/* Added for Sales Force Integration  */
		String sql = null;
		
		
		if(isAdobeXrefFound){
			sql = "select ROWID_SYSTEM,PKEY_SRC_OBJECT from C_B_PARTY_XREF where rowid_object= ? and rowid_system='ADB' and hub_state_ind='1' and status_cd='A' and rownum = 1 order by last_update_date desc";
		}else{
		if(HierarchyFuzzySearch) {
			LOG.info("partyID ==>:: " + partyID);
			 sql = "select ROWID_SYSTEM,PKEY_SRC_OBJECT from C_B_PARTY_XREF where ROWID_OBJECT = ? and ROWID_SYSTEM in ('SAP','SBL','SFC','ELQ','FNO','ADB')"; 
		} else {
			sql = "select ROWID_SYSTEM,PKEY_SRC_OBJECT from C_B_PARTY_XREF where ROWID_OBJECT = ? and ROWID_SYSTEM in ('SAP','SBL','SFC','FNO','ADB')"; 
		}		
		}
		LOG.debug("Query for getPartyXref: "+sql);
		try {
				pstatement = jdbcConn.prepareStatement(sql);
				pstatement.setString(1, partyID);
				resultSet = pstatement.executeQuery();

				while (resultSet.next()) {
					String srcSys = resultSet.getString(1);
					String srcPkey = resultSet.getString(2);
					
					if (!Util.isNullOrEmpty(srcSys)) {
						if(Constant.SRC_SYSTEM_ADB.equalsIgnoreCase(srcSys.trim())){
							srcPkey = srcPkey.replaceAll(Constant.ADB_ACT_PREFIX, Constant.STR_BLANK);
						}
						xref.setSRCSYSTEM(srcSys.trim());
					}
					if (srcPkey != null) {
						xref.setSRCPKEY(srcPkey);
					}
				}
		 } catch(SQLException sqlex) {
			 LOG.error("Caught sql exception in getPartyXref()." + sqlex);
		 } finally {
				try {	//Closing connections
						if (resultSet != null) resultSet.close();
						if (pstatement != null) pstatement.close();
						if (jdbcConn != null) jdbcConn.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
		//	if (jdbcConn != null) jDBCConnectionProvider.closeJdbcConnection(jdbcConn);
		 }
		//return xref;
	}

	//Method To Fetch Party XREFType
	public String getCL_SIP_POP(String countryCd)	{

		LOG.debug("Inside getCL_SIP_POP");
		Connection jdbcConn = null;
		Statement statement = null;
		ResultSet resultSet = null;
		String countryName = null;

		String sql = "SELECT COUNTRY_NAME from CL_SIP_POP where upper(COUNTRY_CD) = upper('" + countryCd + "')";

		try {
			JDBCConnectionProvider jDBCConnectionProvider =  JDBCConnectionProvider.getSingleInstance();
			jdbcConn = jDBCConnectionProvider.getJdbcConnectionFromDS();
			statement = jdbcConn.createStatement();
			resultSet = statement.executeQuery(sql);

				while (resultSet.next()) {
					 countryName = resultSet.getString(1);
				}
				LOG.debug("SIP_POP value: " + countryName);

		 } catch(SQLException sqlex) {
			 LOG.error("Caught SQLException in getCL_SIP_POP()" , sqlex);
		 } catch(ServiceProcessingException servExp) {
			 LOG.error("Caught ServiceProcessingException in getCL_SIP_POP()" , servExp);
		 }
		finally {
			try {
					//Closing connections
					if (resultSet != null) 	resultSet.close();
					if (statement != null) statement.close();
					if (jdbcConn != null) jdbcConn.close();
				} catch (SQLException e) {
					LOG.error("Caught sql exception in getCL_SIP_POP()." + e);
				}

		 }
		LOG.debug("Executed getCL_SIP_POP.");
		return countryName;
	}

		//JDBC call to fetch Golden Record for ID based search
	public Map<String, PartyType> getGoldenRecforID(String srcSysID, String srcSysName) throws ServiceProcessingException	{

		Map<String, PartyType> goldenRecMap = null;
		Statement statement = null;
		StringBuilder sqlQry = new StringBuilder();
	//	String rowid_object = null;
		Connection jdbcConnection = null;
		ResultSet resultSet = null;
		try {

			JDBCConnectionProvider jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();

			rowid_object = getPartyRowidObject(srcSysID, srcSysName);
			if ( !Util.isNullOrEmpty(rowid_object))	{

				LOG.info("Fetching Golden copy for survivorRowID: " + rowid_object);

				sqlQry.append("SELECT * FROM PKG_PARTY_JMS_MQ_PUB WHERE ROWID_OBJECT in ('" + rowid_object + "')");

				sqlQry.append(" AND HUB_STATE_IND <> '" + -1 + "'");
				sqlQry.append(" AND STATUS_CD = '" + "A" + "'");
				sqlQry.append(" AND BO_CLASS_CODE = '" + "Organization" + "'");
				sqlQry.append(" AND PARTY_TYPE in ('" + "Customer'," + "'Partner'," + "'Reseller'," + "'Distributor" + "')");

				LOG.debug("Query to fetch getGoldenRecforID: " + sqlQry);


				jdbcConnection = jDBCConnectionProvider.getJdbcConnectionFromDS();
			//	jdbcConnection = JdbcConn.GetJdbcConnObject();
				statement = jdbcConnection.createStatement();
				resultSet = statement.executeQuery(sqlQry.toString());
				goldenRecMap = createGoldenCopyCanonicalFormMultipleParty(resultSet, srcSysID);
			}

		} catch (SQLException sqlEx) {
			LOG.error("Exception in getGoldenRecforID() for ID based Search: " , sqlEx);
			ServiceProcessingException customException = new ServiceProcessingException(sqlEx);
			customException.setMessage("Failed to fetch Party profile from ORS." + customException.getMessage());
		//	throw customException;
		} catch (ServiceProcessingException sqlEx) {
			LOG.error("Exception in getGoldenRecforID() for ID based Search: " , sqlEx);
			ServiceProcessingException customException = new ServiceProcessingException(sqlEx);
			customException.setMessage("Failed to fetch Party profile from ORS." + customException.getMessage());
			
			if(sqlEx.getMessage().contains(Constant.DB_CONN_FAILURE)){
				throw sqlEx;
			}
		//	throw customException;
		}	finally {
			try {
					if( resultSet != null)	resultSet.close();
					if( statement != null) statement.close();
					if(jdbcConnection != null) jdbcConnection.close();
				} catch (SQLException e) {

					LOG.debug("Caught SQLException in getGoldenRecforID: " , e);
				}
		}
		return goldenRecMap;

	}

	//Method To Fetch Party_ROWID_OBJECT from SrcSystemID
	public String getPartyRowidObject(String partyPkeyID, String srcSystemName) throws ServiceProcessingException	{

		LOG.debug("Executing getPartyRowidObject() ");
		Connection jdbcConn = null;
		PreparedStatement pstatement = null;
		ResultSet resultSet = null;
		StringBuilder sql = new StringBuilder ();
		String rowidObject = null;
//		String srcSystemName = null;

		JDBCConnectionProvider jDBCConnectionProvider =  JDBCConnectionProvider.getSingleInstance();
		jdbcConn = jDBCConnectionProvider.getJdbcConnectionFromDS();

	//	if( !Util.isNullOrEmpty(parameters.getPartySearchCriteria().getSRCSYSTEM()) )	{
	//			srcSystemName = parameters.getPartySearchCriteria().getSRCSYSTEM();
	//		}

		sql.append("select ROWID_OBJECT from C_B_PARTY_XREF where PKEY_SRC_OBJECT = ?");

		if ( !Util.isNullOrEmpty(srcSystemName) ) {
			sql.append(" and ROWID_SYSTEM in ('" + srcSystemName + "')");

		} //else {
		//	sql.append("('SAP','SBL')");
		//	}

		LOG.debug("Query for getPartyRowidObject: " + sql.toString());
		try {
				pstatement = jdbcConn.prepareStatement(sql.toString());
				pstatement.setString(1, partyPkeyID);
				resultSet = pstatement.executeQuery();

				while (resultSet.next()) {
					rowidObject = resultSet.getString(1);
				}
		 } catch(SQLException sqlex) {
			 LOG.error("Caught sql exception in getPartyRowidObject(): " , sqlex);
		 } finally {
			 try {
				 //Closing connections
				 if (resultSet != null)	resultSet.close();
				 if (pstatement != null) pstatement.close();
				 if (jdbcConn != null) jdbcConn.close();//		if (jdbcConn != null) jDBCConnectionProvider.closeJdbcConnection(jdbcConn);
				} catch (SQLException e) {
					 LOG.error("Caught sql exception in getPartyRowidObject(): " , e);
				}
		 }

		LOG.debug("Executed getPartyRowidObject() ");
		return rowidObject;
	}

	//JDBC call to fetch XREF Record for ID based search
	public Map<String, List<PartyXrefType>> getXrefRecforID(String survivorRowid, String srcSystem,String partyType, boolean p2cEligible) throws ServiceProcessingException	{

		Map<String, List<PartyXrefType>> xrefRecMap = null;
		Statement statement = null;
		StringBuilder sqlQry = new StringBuilder();
		Connection jdbcConnection = null;
		ResultSet resultSet = null;
		boolean activeorgExtnExist = false;
		boolean activeclfctnExist = false;

		try {

			activeclfctnExist = commonUtil.checkActiveClsfnXrefcExistById(survivorRowid);
			activeorgExtnExist = commonUtil.checkActiveOrgExtnXrefExistById(survivorRowid);
			
			JDBCConnectionProvider jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();

			LOG.info("Fetching XREF copy for PkeySrcID: " + survivorRowid);
			LOG.info("Fetching XREF copy for srcSystem: " + srcSystem);

			sqlQry.append("SELECT * FROM PKG_XREF_FOR_SEARCH WHERE PARTY_ROWID_OBJECT in ('" + survivorRowid + "')");//AND PARTY_ROWID_SYSTEM in ('SAP','SBL','SFC')

			if (!Util.isNullOrEmpty(srcSystem)) {
				sqlQry.append(" AND PARTY_ROWID_SYSTEM = '" + srcSystem + "'");
			}
			else{
				sqlQry.append(" AND PARTY_ROWID_SYSTEM in ('" + "SAP'," + "'SBL'," + "'SFC'" + ",'ADB','FNO')");
			}
			if (p2cEligible || (!activeclfctnExist) || (!activeorgExtnExist)){
				sqlQry.append(" AND HUB_STATE_IND = '1'");
			}else{
			sqlQry.append(" AND HUB_STATE_IND = '" + 1 + "'" + "AND NVL(ORG_EXTN_HUB_STATE_IND,1) <> '-1' AND NVL(CLASSIFCTN_HUB_STATE_IND,1) <> '-1'");
			
			}
			//sqlQry.append(" AND HUB_STATE_IND = '" + 1 + "'" + "AND NVL(ORG_EXTN_HUB_STATE_IND,1) <> '-1' AND NVL(CLASSIFCTN_HUB_STATE_IND,1) <> '-1'");// Modified in MDM-SFDC integration
			if ((!Util.isNullOrEmpty(partyType)) && (partyType.equalsIgnoreCase(Constant.PARTY_TYPE_PARTNER))) {
				LOG.info("Fetching XREF copy for Party Type: " + partyType);
			sqlQry.append(" AND STATUS_CD in ('" + "A' ,"+ "'I"+ "')");
			  }
			  else{
					sqlQry.append(" AND STATUS_CD = '" + "A" + "'");
			  }
			sqlQry.append(" AND BO_CLASS_CODE = '" + "Organization" + "'");
			sqlQry.append(" AND PARTY_TYPE in ('" + "Customer'," + "'Partner'," + "'Reseller'," + "'Distributor" + "')");
			sqlQry.append(" AND nvl(trunc(END_DATE),'31-DEC-9999') = '31-DEC-9999'");

			LOG.debug("Query to fetch getXrefRecforID: " + sqlQry);


			jdbcConnection = jDBCConnectionProvider.getJdbcConnectionFromDS();
		//	jdbcConnection = JdbcConn.GetJdbcConnObject();
			statement = jdbcConnection.createStatement();
			resultSet = statement.executeQuery(sqlQry.toString());
			xrefRecMap = createXrefCanonicalFormMultipleParty(resultSet);


		} catch (SQLException sqlEx) {
			LOG.error("Exception in getXrefRecforID() for ID based Search: " , sqlEx);
			ServiceProcessingException customException = new ServiceProcessingException(sqlEx);
			customException.setMessage("Failed to fetch Party profile from ORS." + customException.getMessage());
		//	throw customException;
		} catch (ServiceProcessingException sqlEx) {
			LOG.error("Exception in getXrefRecforID() for ID based Search: " , sqlEx);
			ServiceProcessingException customException = new ServiceProcessingException(sqlEx);
			if(sqlEx.getRootExceptionMsg().contains(Constant.DB_CONN_FAILURE)){
				throw sqlEx;
			}else{
			customException.setMessage("Failed to fetch Party profile from ORS." + customException.getMessage());
			}
		//	throw customException;
		}	finally {
			try {
					if( resultSet != null) resultSet.close();
					if( statement != null) statement.close();
					if(jdbcConnection != null) jdbcConnection.close();
				} catch (SQLException e) {

					LOG.debug("Caught SQLException in getXrefRecforID: " , e);
				}
		}
		return xrefRecMap;

	}
	
	public Map<String, List<PartyXrefType>> getXrefRecforAdobeID(String survivorRowid) throws ServiceProcessingException	{

		Map<String, List<PartyXrefType>> xrefRecMap = null;
		Statement statement = null;
		StringBuilder sqlQry = new StringBuilder();
		Connection jdbcConnection = null;
		ResultSet resultSet = null;

		try {

			JDBCConnectionProvider jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();

			LOG.info("Fetching XREF copy for PkeySrcID: " + survivorRowid);
			sqlQry.append("SELECT * FROM PKG_XREF_PROSPECT_FOR_SEARCH WHERE PARTY_ROWID_OBJECT in ('" + survivorRowid + "')");
			//sqlQry.append(" AND PARTY_ROWID_SYSTEM in ('SAP','SBL','SFC','FNO','ADB')");
			sqlQry.append(" AND PARTY_ROWID_SYSTEM in ('ADB')");
			sqlQry.append(" AND HUB_STATE_IND = '" + 1 + "'" + "AND NVL(ORG_EXTN_HUB_STATE_IND,1) <> '-1' AND NVL(CLASSIFCTN_HUB_STATE_IND,1) <> '-1'");// Modified in MDM-SFDC integration
			sqlQry.append(" AND STATUS_CD = 'A'");
			sqlQry.append(" AND BO_CLASS_CODE = 'Organization'");
			sqlQry.append(" AND PARTY_TYPE in ('Customer','Prospect Customer')");
			
			LOG.debug("Query to fetch getXrefRecforID: " + sqlQry);

			jdbcConnection = jDBCConnectionProvider.getJdbcConnectionFromDS();
			statement = jdbcConnection.createStatement();
			resultSet = statement.executeQuery(sqlQry.toString());
			xrefRecMap = createXrefCanonicalFormMultipleParty(resultSet);

		} catch (SQLException sqlEx) {
			LOG.error("Exception in getXrefRecforAdobeID() for ID based Search: " , sqlEx);
			ServiceProcessingException customException = new ServiceProcessingException(sqlEx);
			customException.setMessage("Failed to fetch Party profile from ORS." + customException.getMessage());
		//	throw customException;
		} catch (ServiceProcessingException sqlEx) {
			LOG.error("Exception in getXrefRecforAdobeID() for ID based Search: " , sqlEx);
			if(sqlEx.getRootExceptionMsg().contains(Constant.DB_CONN_FAILURE)){
				throw sqlEx;
			}else{
				ServiceProcessingException customException = new ServiceProcessingException(sqlEx);
			customException.setMessage("Failed to fetch Party profile from ORS." + customException.getMessage());
			}
		//	throw customException;
		}	finally {
			try {
					if( resultSet != null) resultSet.close();
					if( statement != null) statement.close();
					if(jdbcConnection != null) jdbcConnection.close();
				} catch (SQLException e) {

					LOG.debug("Caught SQLException in getXrefRecforID: " , e);
				}
		}
		return xrefRecMap;
	}

//Modified for Track-2
	//Fetch Golden Copy CanonicalForm for ID Based Search
	private Map<String, PartyType> createGoldenCopyCanonicalFormMultipleParty(ResultSet resultSet, String srcSysID) throws ServiceProcessingException {
		LOG.info("Executing createGoldenCopyCanonicalFormMultipleParty()");
		PartyType party = null;
		CommunicationType communication = null;
		AccountType accInfo = null;
		AddressType address = null;
		ClassificationType classfction = null;
		PartyOrgExtType partyOrgExt = null;
		PartyPersonExtType partyPersonExt = null;
		
		/** Modified for M4M START */
		PartyAccountRelationshipType partyAccountRelationship = null;
		/** Modified for M4M END */

		Map<String, PartyType> partyMap = new HashMap<String, PartyType>();
		Map<String, SearchedRecordCollection> searchedRecCollMap = new HashMap<String, SearchedRecordCollection>();
		SearchedRecordCollection searchedRecCollObj = null;
		boolean bUniqueRec = false;
		String hierarchyCd = null;
		String hierarchyGRP = configProps.getProperty("HierGRP");
		
		try {
			LOG.info("Retrieving Party profiles (Gold copy) from result set");
			while (resultSet.next()) {
				String partyRowId = resultSet.getString("ROWID_OBJECT");
				String partyType = resultSet.getString("PARTY_TYPE");
				String isGlobalParent = "N";
				String rowidRelationship = null;
				if (!searchedRecCollMap.containsKey(partyRowId)) {

					LOG.debug("Populate searchedRecCollMap for new PARTY_ROWID " + partyRowId);
					searchedRecCollMap.put(partyRowId, new SearchedRecordCollection());
					bUniqueRec = true;
				}

				searchedRecCollObj = searchedRecCollMap.get(partyRowId);

				if(bUniqueRec)	{

					LOG.debug("============setting Party Gold Copy");
					searchedRecCollObj.setParty_rowid(partyRowId);
					searchedRecCollObj.setBo_class(resultSet.getString("BO_CLASS_CODE"));
					searchedRecCollObj.setParty_type(resultSet.getString("PARTY_TYPE"));
					searchedRecCollObj.setParty_name(resultSet.getString("PARTY_NAME"));
					searchedRecCollObj.setGeo(resultSet.getString("GEO"));
					searchedRecCollObj.setRegion(resultSet.getString("REGION"));
					searchedRecCollObj.setStatus_cd(resultSet.getString("STATUS_CD"));
					searchedRecCollObj.setVat_regno(resultSet.getString("VAT_REG_NBR"));
					searchedRecCollObj.setTax_jd_cd(resultSet.getString("TAX_JURSDCTN_CD"));
					searchedRecCollObj.setSales_cd(resultSet.getString("SALES_BLOCK_CD"));
					searchedRecCollObj.setUcn(resultSet.getString("UCN"));
				//	searchedRecCollObj.setLegacyUcn(resultSet.getString("LEGACY_UCN"));
					searchedRecCollObj.setEnglish_name(resultSet.getString("ENGLISH_NAME"));
					searchedRecCollObj.setPhysicalGeo(resultSet.getString("PHYSICAL_GEO"));
					searchedRecCollObj.setPhysicalRegion(resultSet.getString("PHYSICAL_REGION"));
				}

				String rowidAccount = resultSet.getString("ROWID_ACCOUNT");
				if (rowidAccount != null &&
						!searchedRecCollObj.getAccountMap().containsKey(rowidAccount)) {
					LOG.debug("============setting Account info");
					accInfo = new AccountType();
					accInfo.setROWIDACCOUNT(rowidAccount);
					accInfo.setACCTNAME(resultSet.getString("ACCT_NAME"));
					accInfo.setALIASNAME(resultSet.getString("ALIAS_NAME"));
					accInfo.setACCTSTATUS(resultSet.getString("ACCT_STATUS"));
					accInfo.setACCTTYPE(resultSet.getString("ACCT_TYPE"));
					accInfo.setACCOUNTREGION(resultSet.getString("ACCOUNT_REGION"));
					accInfo.setACCOUNTGEO(resultSet.getString("ACCOUNT_GEO"));
					accInfo.setMARKET(resultSet.getString("MARKET"));
					accInfo.setCUSTGROUP(resultSet.getString("CUST_GROUP"));
					accInfo.setPRICEGROUP(resultSet.getString("PRICE_GROUP"));
					accInfo.setCOMPANYCD(resultSet.getString("COMPANY_CD"));
					accInfo.setACCOUNTVATREGNBR(resultSet.getString("ACCOUNT_VAT_REG_NBR"));
					accInfo.setTAXTYPE(resultSet.getString("TAX_TYPE"));
					accInfo.setACCOUNTTAXJURSDCTNCD(resultSet.getString("ACCOUNT_TAX_JURSDCTN_CD"));
					accInfo.setBILLBLOCKCD(resultSet.getString("BILL_BLOCK_CD"));
					accInfo.setORDRBLOCKCD(resultSet.getString("ORDR_BLOCK_CD"));
					accInfo.setDLVRYBLOCKCD(resultSet.getString("DLVRY_BLOCK_CD"));
					accInfo.setPOSTBLOCKCD(resultSet.getString("POST_BLOCK_CD"));
					accInfo.setSALEBLOCKCD(resultSet.getString("SALE_BLOCK_CD"));
					accInfo.setCHANNELID(resultSet.getString("CHANNEL_ID"));
					accInfo.setPARTNERTYPE(resultSet.getString("PARTNER_TYPE"));
					accInfo.setVENDORNBR(resultSet.getString("VENDOR_NBR"));
					accInfo.setDIRECTIND(resultSet.getString("DIRECT_IND"));
					accInfo.setNAMEDACCTIND(resultSet.getString("NAMED_ACCT_IND"));
					accInfo.setNONVALACCTIND(resultSet.getString("NON_VAL_ACCT_IND"));
					accInfo.setPARTNERIND(resultSet.getString("PARTNER_IND"));
					accInfo.setSIEBELROWID(resultSet.getString("SIEBEL_ROWID"));
					accInfo.setSAPCUSTNUMBER(resultSet.getString("SAP_CUST_NUMBER"));
					accInfo.setMDMLEGACYID(resultSet.getString("MDM_LEGACY_ID"));
					accInfo.setDATASRCSYSTEM(resultSet.getString("DATA_SRC_SYSTEM"));
					if(!Util.isNullOrEmpty(resultSet.getString("ENGLISH_NAME")))	{
						accInfo.setSAPNAME1(resultSet.getString("ENGLISH_NAME"));
					} else {
						accInfo.setSAPNAME1(resultSet.getString("SAP_NAME_1"));
					}
					accInfo.setSAPNAME2(resultSet.getString("SAP_NAME_2"));
					accInfo.setSAPNAME3(resultSet.getString("SAP_NAME_3"));
					accInfo.setSAPNAME4(resultSet.getString("SAP_NAME_4"));
					
					/** Modified for SFDC START */
					accInfo.setSalesForceID(resultSet.getString("SFID"));
					accInfo.setDraftAccountFlag(resultSet.getString("DRAFT_FLG"));
					/** Modified for SFDC END */
					/** changes for Sales Force Integration -Start */
					accInfo.setLOCALNAME(resultSet.getString("LOCAL_NAME"));
					accInfo.setCURRENCYCD(resultSet.getString("ACCOUNT_CURRENCY_CD"));
					accInfo.setTAXID(resultSet.getString("TAX_ID"));
					accInfo.setPRICEBANDAGGREMENT(resultSet.getString("PRICING_BAND_AGRMNT"));
					/** changes for Sales Force Integration -End */
					/** changes for Track-2 -Start */
					accInfo.setSITEDESIGNATION(resultSet.getString("SITE_DESIGNATION"));
					/** changes for Track-2 -End */
					/** changes for Track-3 -Start */
					accInfo.setRESELLLEVEL(resultSet.getString("RESELL_LEVEL"));
					accInfo.setPARTNERSHIPSTATUS(resultSet.getString("PARTNERSHIP_STATUS"));
					/** changes for Track-3 -End */
					LOG.debug("===Inserting into Account Map===");
					searchedRecCollObj.getAccountMap().put(accInfo.getROWIDACCOUNT(), accInfo);
				}

				String rowidAddress = resultSet.getString("ROWID_ADDRESS");
				if (rowidAddress != null &&
						!searchedRecCollObj.getAddressMap().containsKey(rowidAddress)) {
					LOG.debug("============setting Address");

					address = new AddressType();
					address.setROWIDADDRESS(rowidAddress);
					address.setADDRLN1(resultSet.getString("ADDR_LN1"));
					address.setADDRLN2(resultSet.getString("ADDR_LN2"));
					address.setADDRLN3(resultSet.getString("ADDR_LN3"));
					address.setADDRLN4(resultSet.getString("ADDR_LN4"));
					address.setCITY(resultSet.getString("CITY"));
					address.setCOUNTY(resultSet.getString("COUNTY"));
					address.setDISTRICT(resultSet.getString("DISTRICT"));
					address.setSTATECD(resultSet.getString("STATE_CD"));
					address.setPOSTALCD(resultSet.getString("POSTAL_CD"));
					address.setCOUNTRYCD(resultSet.getString("COUNTRY_CD"));
					address.setLANGCD(resultSet.getString("LANG_CD"));
					address.setLONGITUDE(resultSet.getString("LONGITUDE"));
					address.setLATITUDE(resultSet.getString("LATITUDE"));
					address.setADDRTYPE(resultSet.getString("ADDR_TYPE"));
					address.setADDRSTATUS(resultSet.getString("ADDR_STATUS"));

					LOG.debug("===Inserting into Address Map===");
					searchedRecCollObj.getAddressMap().put(address.getROWIDADDRESS(), address);
				}

				String rowidComm = resultSet.getString("ROWID_COMMUNICATION");
				if (rowidComm != null &&
						!searchedRecCollObj.getCommMap().containsKey(rowidComm)) {
					communication = new CommunicationType();
					LOG.debug("============adding Communication");

					communication.setROWIDCOMMUNICATION(rowidComm);
					communication.setCOMMTYPE(resultSet.getString("COMM_TYPE"));
					communication.setCOMMVALUE(resultSet.getString("COMM_VALUE"));
					communication.setCOMMSTATUS(resultSet.getString("COMM_STATUS"));
					communication.setPRFRDCOMMIND(resultSet.getString("PRFRD_COMM_IND"));
					communication.setWEBDOMAIN(resultSet.getString("WEB_DOMAIN"));
					/* changes for SFDC - Track2 -Start */
					communication.setCOMMEXTN(resultSet.getString("COMM_EXTN"));
					communication.setCOMMMKTGPREF(resultSet.getString("COMM_MKTG_PREF"));
					/* changes for SFDC - Track2 -End */
					LOG.debug("===Inserting into Communication Map===");
					searchedRecCollObj.getCommMap().put(communication.getROWIDCOMMUNICATION(), communication);
				}

				String rowidOrgExtn = resultSet.getString("ROWID_ORG_EXTN");
				if (rowidOrgExtn != null &&
						!searchedRecCollObj.getPartyOrgMap().containsKey(rowidOrgExtn)) {
					partyOrgExt = new PartyOrgExtType();
					LOG.debug("============adding PartyOrgExt");

					partyOrgExt.setROWIDORGEXTN(rowidOrgExtn);
					partyOrgExt.setORGDUNSNBR(resultSet.getString("ORG_DUNS_NBR"));
					partyOrgExt.setTRADENAME(resultSet.getString("TRADE_NAME"));
					partyOrgExt.setTRADENAME2(resultSet.getString("TRADE_NAME_2"));
					partyOrgExt.setSITEEMPLCNT(resultSet.getString("SITE_EMPL_CNT"));
					partyOrgExt.setGLBLEMPLCNT(resultSet.getString("GLBL_EMPL_CNT"));
					partyOrgExt.setVERTICAL(resultSet.getString("VERTICAL"));
					partyOrgExt.setREVENUE(resultSet.getString("REVENUE"));
					partyOrgExt.setLINEOFBUS(resultSet.getString("LINE_OF_BUS"));
					partyOrgExt.setPRIMSIC(resultSet.getString("PRIM_SIC"));
					partyOrgExt.setSECSIC(resultSet.getString("SEC_SIC"));
					partyOrgExt.setSALESVOLUME(resultSet.getString("SALES_VOLUME"));
					partyOrgExt.setSALESAMOUNT(resultSet.getString("SALES_AMOUNT"));
					partyOrgExt.setCURRENCYCD(resultSet.getString("CURRENCY_CD"));
					partyOrgExt.setOUTOFBUSIND(resultSet.getString("OUT_OF_BUS_IND"));
					partyOrgExt.setGLBLULTIND(resultSet.getString("GLBL_ULT_IND"));
					partyOrgExt.setFORTUNEINFO(resultSet.getString("FORTUNE_INFO"));
					partyOrgExt.setHIERARCHYLEVEL(resultSet.getString("HIERARCHY_LEVEL"));
					partyOrgExt.setORGHQPARENTDUNS(resultSet.getString("ORG_HQ_PARENT_DUNS"));
					partyOrgExt.setORGDOMULTDUNS(resultSet.getString("ORG_DOM_ULT_DUNS"));
					partyOrgExt.setORGGLBULTDUNS(resultSet.getString("ORG_GLB_ULT_DUNS"));
					partyOrgExt.setMFEGLBLPARENTNM(resultSet.getString("MFE_GLBL_PARENT_NM"));
					partyOrgExt.setMFEPARENTNM(resultSet.getString("MFE_PARENT_NM"));
					partyOrgExt.setMFEWWPARENTNM(resultSet.getString("MFE_WW_PARENT_NM"));
					partyOrgExt.setMFESUBSDRYPARENTNM(resultSet.getString("MFE_SUBSDRY_PARENT_NM"));
					partyOrgExt.setMFEPRTNRPARENTORG(resultSet.getString("MFE_PRTNR_PARENT_ORG"));
					partyOrgExt.setSALESREVNUOVRID(resultSet.getString("SALES_REVNU_OVRID"));
					partyOrgExt.setMFEEMPCNTOVERIDE(resultSet.getString("MFE_EMP_CNT_OVERIDE"));
					partyOrgExt.setSICCDOVRIDE(resultSet.getString("SIC_CD_OVRIDE"));
					/** changes for Track-2 -Start */
					partyOrgExt.setMFECOUNTRYULTUCN(resultSet.getString("MFE_COUNTRY_ULT_UCN"));
					partyOrgExt.setMFEGLBLPARENTUCN(resultSet.getString("MFE_GLBL_PARENT_UCN"));
					partyOrgExt.setMFEGLOBALPARNMOVRIDE(resultSet.getString("MFE_GLOBAL_PAR_NM_OVRIDE"));
					partyOrgExt.setMFENEXTLVLSUBSPARNM(resultSet.getString("MFE_NEXT_LVL_SUBS_PAR_NM"));
					partyOrgExt.setMFENEXTLVLSUBSPARUCN(resultSet.getString("MFE_NEXT_LVL_SUBS_PAR_UCN"));
					partyOrgExt.setMFESUBSDRYPARENTNM(resultSet.getString("MFE_SUBS_PARENT_NM"));
					partyOrgExt.setMFESUBSDRYPARENTPRTNNM(resultSet.getString("MFE_SUBSDRY_PARENT_PRTN_NM"));
					partyOrgExt.setMFESUBSPARENTNMOVRIDE(resultSet.getString("MFE_SUBS_PARENT_NM_OVRIDE"));
					partyOrgExt.setMFESUBSPARENTUCN(resultSet.getString("MFE_SUBS_PARENT_UCN"));
					partyOrgExt.setMFETXN5YRFLG(resultSet.getString("MFE_TXN_5_YR_FLG"));
					partyOrgExt.setMFETXN7YRFLG(resultSet.getString("MFE_TXN_7_YR_FLG"));
					partyOrgExt.setMFEWWPARENTNM(resultSet.getString("MFE_WW_PARENT_NM"));
					partyOrgExt.setMFEWWPARENTPRTNNM(resultSet.getString("MFE_WW_PARENT_PRTN_NM"));
					partyOrgExt.setTXN5YRFLG(resultSet.getString("TXN_5_YR_FLG"));
					partyOrgExt.setTXN7YRFLG(resultSet.getString("TXN_7_YR_FLG"));
					partyOrgExt.setGLBEMPCNTOVERRIDE(resultSet.getString("GLB_EMP_CNT_OVERRIDE"));
					partyOrgExt.setACTIVETXNFLG(resultSet.getString("ACTIVE_TXN_FLAG"));
					partyOrgExt.setPARENTFLG(resultSet.getString("PARENT_FLAG"));
					partyOrgExt.setPARTNERFLG(resultSet.getString("PARTNER_FLAG"));
					partyOrgExt.setCUSTFLG(resultSet.getString("CUST_FLAG"));
					partyOrgExt.setGLBFLG(resultSet.getString("GLB_FLG"));
					partyOrgExt.setCOUNTRYULTIND(resultSet.getString("COUNTRY_ULT_IND"));	
					partyOrgExt.setSUBSIDIARYIND(resultSet.getString("SUBSIDIARY_IND"));
					partyOrgExt.setMDMPARENTUCN(resultSet.getString("MDM_PARENT_UCN"));
					partyOrgExt.setGLBSALESREVNUOVRID(resultSet.getString("GLB_SALES_REVNU_OVRID"));
					/** changes for Track-2 -End */
					/** changes for Track-3 -Start */
					partyOrgExt.setPTRPARENTUCN(resultSet.getString("PTR_PARENT_UCN"));
					partyOrgExt.setPTRPARENTNM(resultSet.getString("PTR_PARENT_NM"));
					partyOrgExt.setPTRGLBLPARENTUCN(resultSet.getString("PTR_GLBL_PARENT_UCN"));
					/** changes for Track-3 -End */
					LOG.debug("===Inserting into PartyOrgExtType Map==");
					searchedRecCollObj.getPartyOrgMap().put(partyOrgExt.getROWIDORGEXTN(), partyOrgExt);
				}

				String rowidPrsnExtn = resultSet.getString("ROWID_PRSN_EXTN");
				if (rowidPrsnExtn != null &&
						!searchedRecCollObj.getPartyPersonMap().containsKey(rowidPrsnExtn)) {

					partyPersonExt = new PartyPersonExtType();
					LOG.debug("============adding PartyPersonExt");

					partyPersonExt.setROWIDPRSNEXTN(rowidPrsnExtn);
					partyPersonExt.setPREFIX(resultSet.getString("PREFIX"));
					partyPersonExt.setFIRSTNAME(resultSet.getString("FIRST_NAME"));
					partyPersonExt.setLASTNAME(resultSet.getString("MIDDLE_NAME"));
					partyPersonExt.setLASTNAME(resultSet.getString("LAST_NAME"));
					partyPersonExt.setSUFFIX(resultSet.getString("SUFFIX"));
					partyPersonExt.setPERSONTYPE(resultSet.getString("PERSON_TYPE"));

					LOG.debug("===Inserting into PartyPersonExtType List===");
					searchedRecCollObj.getPartyPersonMap().put(partyPersonExt.getROWIDPRSNEXTN(), partyPersonExt);
				}

				String rowidClassif = resultSet.getString("ROWID_CLASSIFCTN");
				if (rowidClassif != null &&
						!searchedRecCollObj.getClassMap().containsKey(rowidClassif)) {

					classfction = new ClassificationType();
					LOG.debug("============adding Classification");

					classfction.setROWIDCLASSIFICTN(rowidClassif);
					classfction.setCLASSIFICTNTYPE(resultSet.getString("CLASSIFCTN_TYPE"));
					classfction.setCLASSIFICTNVALUE(resultSet.getString("CLASSIFCTN_VALUE"));
					classfction.setSTARTDATE(resultSet.getString("START_DATE"));
					classfction.setENDDATE(resultSet.getString("END_DATE"));
					/* changes for SFDC - Track2 -Start */
					classfction.setCLASSIFICTNMETH(resultSet.getString("CLASSIFCTN_METH"));
					/* changes for SFDC - Track2 -End */
					LOG.debug("===Inserting into Classification Map===");
					searchedRecCollObj.getClassMap().put(classfction.getROWIDCLASSIFICTN(), classfction);

				}

				if (bUniqueRec) {
					LOG.debug("============adding PartyRelationship");
					/* changes for Hierarchy - Track2 -Start */
					Map<String, String> ucnMap = getMdmHierarchyView(partyRowId);
					Map<String,String> partnerResellerUCNMap = null;
					if("Reseller".equalsIgnoreCase(partyType) || "Distributor".equalsIgnoreCase(partyType)){
						partnerResellerUCNMap = getPartnerRellserHierarchyView(partyRowId,partyType);
					}else{
						partnerResellerUCNMap = new HashMap<String,String>();
						partnerResellerUCNMap.put("MDM_PRTNR_ORG_UCN","");
						partnerResellerUCNMap.put("PRTNR_ORG_NM","");
					}
					isGlobalParent = ucnMap.get("GLB_FLG");
					String globalParentName = ucnMap.get("MFE_GLOBAL_PAR_NM_OVRIDE"); 
					if (resultSet.getString("ROWID_PARTY_CHILD") != null){ 
						if(!searchedRecCollObj.getPartyAcctRelMap().containsKey(resultSet.getString("ROWID_PARTY_REL"))) {

						partyAccountRelationship = new PartyAccountRelationshipType();
						rowidRelationship = resultSet.getString("ROWID_PARTY_REL");
						if (!Util.isNullOrEmpty(rowidRelationship)) {
							partyAccountRelationship.setRELTYPE(resultSet.getString("REL_TYPE_CODE"));
							partyAccountRelationship.setHIERARCHYTYPE(resultSet.getString("HIERARCHY_CODE"));
							hierarchyCd = (partyAccountRelationship.getHIERARCHYTYPE());
							partyAccountRelationship.setSINGLESITEFLAG(Constant.STR_N);
							if (Constant.McAfee_Hierarchy.equalsIgnoreCase(hierarchyCd)) {

								partyAccountRelationship.setMDMPARENTUCN(ucnMap.get("MDM_PARENT_UCN"));
								partyAccountRelationship.setMDMPARENTNAME(ucnMap.get("MFE_PARENT_NM"));
								partyAccountRelationship.setMDMGLBPARENTUCN(ucnMap.get("MFE_GLBL_PARENT_UCN"));
								if(Util.isNullOrEmpty(globalParentName))	{
									partyAccountRelationship.setMDMGLBPARENTNAME(ucnMap.get("MFE_GLBL_PARENT_NM"));
									}
									else{
										partyAccountRelationship.setMDMGLBPARENTNAME(ucnMap.get("MFE_GLOBAL_PAR_NM_OVRIDE"));
									}
							} else if (Constant.Partner_Hierarchy.equalsIgnoreCase(hierarchyCd)) {

								/*partyAccountRelationship.setMDMPARENTUCN(ucnMap.get("MDM_PARENT_UCN"));
								partyAccountRelationship.setMDMPARENTNAME(ucnMap.get("MFE_SUBSDRY_PARENT_PRTN_NM"));
								partyAccountRelationship.setMDMGLBPARENTUCN(ucnMap.get("MFE_GLBL_PARENT_UCN"));*/
								if("Reseller".equalsIgnoreCase(partyType) || "Distributor".equalsIgnoreCase(partyType)){
									partyAccountRelationship.setMDMPARENTUCN(partnerResellerUCNMap.get("MDM_PRTNR_ORG_UCN"));
									partyAccountRelationship.setMDMPARENTNAME(partnerResellerUCNMap.get("PRTNR_ORG_NM"));
								}else {
									partyAccountRelationship.setMDMPARENTUCN(ucnMap.get("PTR_PARENT_UCN"));
									partyAccountRelationship.setMDMPARENTNAME(ucnMap.get("PTR_PARENT_NM"));
								}
								partyAccountRelationship.setMDMGLBPARENTUCN(ucnMap.get("PTR_GLBL_PARENT_UCN"));
								partyAccountRelationship.setMDMGLBPARENTNAME(ucnMap.get("MFE_WW_PARENT_PRTN_NM"));
							}
							if (null != partyAccountRelationship) {
								if (hierarchyGRP.contains(partyAccountRelationship.getHIERARCHYTYPE())) {
									LOG.debug("===Inserting into Relationship Map===");
									searchedRecCollObj.getPartyAcctRelMap().put(rowidRelationship,
											partyAccountRelationship);
								}
							}
						}
					} 
					}else if ((!Util.isNullOrEmpty(isGlobalParent)) && isGlobalParent.equalsIgnoreCase("Y")) {
						List<GlobalHierarchyNode> globalHierarchyNodeList = getGlobalHierarchy(partyRowId);
						
						for (GlobalHierarchyNode globalHierarchyNode : globalHierarchyNodeList) {
							partyAccountRelationship = new PartyAccountRelationshipType();
							if (globalHierarchyNode.getPartyRelRowid() != null && !searchedRecCollObj
									.getPartyRelMap().containsKey(globalHierarchyNode.getPartyRelRowid())) {
								LOG.debug("===Inserting into Relationship Map for GLOBAL Parent==="
										+ globalHierarchyNode.getPartyRelRowid());
								partyAccountRelationship.setSINGLESITEFLAG(Constant.STR_N);
								rowidRelationship = globalHierarchyNode.getPartyRelRowid();
								partyAccountRelationship.setRELTYPE(globalHierarchyNode.getRelTypeCode());
								hierarchyCd = globalHierarchyNode.getHierarchyCode();
								partyAccountRelationship.setHIERARCHYTYPE(hierarchyCd);
								if (Constant.McAfee_Hierarchy.equalsIgnoreCase(hierarchyCd)) {

									partyAccountRelationship.setMDMPARENTUCN(ucnMap.get("MDM_PARENT_UCN"));
									partyAccountRelationship.setMDMPARENTNAME(ucnMap.get("MFE_PARENT_NM"));
									partyAccountRelationship.setMDMGLBPARENTUCN(ucnMap.get("MFE_GLBL_PARENT_UCN"));
									if(Util.isNullOrEmpty(globalParentName))	{
										partyAccountRelationship.setMDMGLBPARENTNAME(ucnMap.get("MFE_GLBL_PARENT_NM"));
										}
										else{
											partyAccountRelationship.setMDMGLBPARENTNAME(ucnMap.get("MFE_GLOBAL_PAR_NM_OVRIDE"));
										}
								} else if (Constant.Partner_Hierarchy.equalsIgnoreCase(hierarchyCd)) {

									/*partyAccountRelationship.setMDMPARENTUCN(ucnMap.get("MDM_PARENT_UCN"));
									partyAccountRelationship
											.setMDMPARENTNAME(ucnMap.get("MFE_SUBSDRY_PARENT_PRTN_NM"));
									partyAccountRelationship.setMDMGLBPARENTUCN(ucnMap.get("MFE_GLBL_PARENT_UCN"));*/
									if("Reseller".equalsIgnoreCase(partyType) || "Distributor".equalsIgnoreCase(partyType)){
										partyAccountRelationship.setMDMPARENTUCN(partnerResellerUCNMap.get("MDM_PRTNR_ORG_UCN"));
										partyAccountRelationship.setMDMPARENTNAME(partnerResellerUCNMap.get("PRTNR_ORG_NM"));
									}else {
										partyAccountRelationship.setMDMPARENTUCN(ucnMap.get("PTR_PARENT_UCN"));
										partyAccountRelationship.setMDMPARENTNAME(ucnMap.get("PTR_PARENT_NM"));
									}
									partyAccountRelationship.setMDMGLBPARENTUCN(ucnMap.get("PTR_GLBL_PARENT_UCN"));
									partyAccountRelationship
											.setMDMGLBPARENTNAME(ucnMap.get("MFE_WW_PARENT_PRTN_NM"));
								}
								LOG.debug("===Inserting into Single Site Relationship Map===");
								if (hierarchyGRP.contains(partyAccountRelationship.getHIERARCHYTYPE())) {
									searchedRecCollObj.getPartyAcctRelMap().put(rowidRelationship, partyAccountRelationship);
								}
							}
						}

					}

					else{	
						rowidRelationship = "0"; // As there is no party
													// relation so rel rowid is
													// set as 0
						LOG.debug("============adding dummy partyAccountRelationship ");

						partyAccountRelationship = new PartyAccountRelationshipType();
						if (!"Y".equalsIgnoreCase(isGlobalParent)) {
							partyAccountRelationship.setMDMPARENTUCN(searchedRecCollObj.getUcn());
							partyAccountRelationship.setMDMPARENTNAME(searchedRecCollObj.getParty_name());
							partyAccountRelationship.setMDMGLBPARENTUCN(searchedRecCollObj.getUcn());
							partyAccountRelationship.setMDMGLBPARENTNAME(searchedRecCollObj.getParty_name());
							partyAccountRelationship.setHIERARCHYTYPE(Constant.McAfee_Hierarchy);
							partyAccountRelationship.setSINGLESITEFLAG(Constant.STR_Y);
						} 

						LOG.debug("===Inserting into Single Site Relationship Map===");
						if (hierarchyGRP.contains(partyAccountRelationship.getHIERARCHYTYPE())) {
							searchedRecCollObj.getPartyAcctRelMap().put(rowidRelationship, partyAccountRelationship);
						}
						/* changes for Hierarchy - Track2 -End */
					}
				}

				bUniqueRec = false;
			}
			LOG.info("Number of retrived party profile = " + searchedRecCollMap.keySet().size());

			LOG.debug("====Populating Party canonical formats");
			for (Entry<String, SearchedRecordCollection> entry : searchedRecCollMap.entrySet()) {
				SearchedRecordCollection fetchedRecCollObj = entry.getValue();
				if (fetchedRecCollObj != null) {
					party = new PartyType();
					party.setBOCLASSCODE(fetchedRecCollObj.getBo_class());
					party.setENGLISHNAME(fetchedRecCollObj.getEnglish_name());
					party.setGEO(fetchedRecCollObj.getGeo());
					party.setPARTYNAME(fetchedRecCollObj.getParty_name());
					party.setPARTYTYPE(fetchedRecCollObj.getParty_type());
					party.setREGION(fetchedRecCollObj.getRegion());
					party.setROWIDOBJECT(fetchedRecCollObj.getParty_rowid());
					party.setSALESBLOCKCD(fetchedRecCollObj.getSales_cd());
					party.setSTATUSCD(fetchedRecCollObj.getStatus_cd());
					party.setTAXJURSDCTNCD(fetchedRecCollObj.getTax_jd_cd());
					party.setUCN(fetchedRecCollObj.getUcn());
			//		party.setLEGACYUCN(fetchedRecCollObj.getLegacyUcn());
					party.setVATREGNBR(fetchedRecCollObj.getVat_regno());

					party.getXREF().addAll(fetchedRecCollObj.getXrefMap().values());
					party.getAccount().addAll(fetchedRecCollObj.getAccountMap().values());
					party.getAddress().addAll(fetchedRecCollObj.getAddressMap().values());
					party.getCommunication().addAll(fetchedRecCollObj.getCommMap().values());
					party.getPartyOrgExt().addAll(fetchedRecCollObj.getPartyOrgMap().values());
					party.getPartyPersonExt().addAll(fetchedRecCollObj.getPartyPersonMap().values());
					party.getClassification().addAll(fetchedRecCollObj.getClassMap().values());
					
					/** Modified for M4M START */
					PartyRelationshipType partyRel = party.getPartyRel();
					if(partyRel == null) {
						partyRel = new PartyRelationshipType();
					}
					partyRel.getPARTYACCOUNTREL().addAll(fetchedRecCollObj.getPartyAcctRelMap().values());
					party.setPartyRel(partyRel);
					/** Modified for M4M END */

					partyMap.put(entry.getKey(), party);
				}
			}
			LOG.info("Number of party canonical format created = " + partyMap.keySet().size());
		} catch (SQLException sqlEx) {
			LOG.error("SQLException occurred while retrieving party details from resultset: ", sqlEx);
			//sqlEx.printStackTrace();
		} catch(ServiceProcessingException se){
			if(se.getMessage().contains(Constant.DB_CONN_FAILURE)){
				throw se;
			}
		}catch (Exception excp) {
			LOG.error("Exception occurred while creating party canonical format from resultset: ", excp);
			//excp.printStackTrace();
			
		}

		LOG.info("Executed createGoldenCopyCanonicalFormMultipleParty()");
		return partyMap;
	}

	public Map<String, List<PartyXrefType>> createXrefCanonicalFormMultipleParty(ResultSet resultSet) throws ServiceProcessingException {
		LOG.info("Executing createXrefCanonicalFormMultipleParty()");
		PartyXrefType party = null;
		XREFType xref = null;
		CommunicationXrefType communication = null;
		AccountXrefType accInfo = null;
		AddressXrefType address = null;
		ClassificationXrefType classfction = null;
		PartyOrgExtXrefType partyOrgExt = null;
		//PartyRelationshipXrefType partyRelationship = null;
		
		/** Modified for M4M START */
		PartyAccountRelationshipXrefType partyAccountRelationship = null;
		/** Modified for M4M END */
		
		List<String> srcSystemIdList = null;

		Map<String, List<PartyXrefType>> partyXrefMap = new HashMap<String, List<PartyXrefType>>();
		List<PartyXrefType> partyXrefList = new ArrayList<PartyXrefType>();
		Map<String, SearchedXrefRecordCollection> searchedRecCollMap = new HashMap<String, SearchedXrefRecordCollection>();
		SearchedXrefRecordCollection searchedRecCollObj = null;
		boolean bUniqueRec = false;
		String hierarchyGRP = configProps.getProperty("HierGRP");
		Map<String, Map<String, SearchedXrefRecordCollection>> searchedRecCollMapAllParties = new HashMap<String, Map<String, SearchedXrefRecordCollection>>();

		try {
			LOG.info("Retrieving Party profiles (Xref) from result set");
			while (resultSet.next()) {
				String isGlobalParent = "N";
				
				String hierarchyCd = null;
				String rowidRelationship = null;
				String partyRowId = resultSet.getString("PARTY_ROWID_OBJECT");
				String partyOrigRowId = resultSet.getString("ORIG_ROWID_OBJECT");
				String partyType = resultSet.getString("PARTY_TYPE");
				if (!searchedRecCollMapAllParties.containsKey(partyRowId)) {
					LOG.debug("Populate searchedRecCollMapAllParties for new PARTY_ROWID " + partyRowId);
					searchedRecCollMapAllParties.put(partyRowId, new HashMap<String, SearchedXrefRecordCollection>());
				}
				searchedRecCollMap = searchedRecCollMapAllParties.get(partyRowId);

				//for each Orig_rowid_object store xref values in canonical form
				if (!searchedRecCollMap.containsKey(partyOrigRowId)) {

					LOG.debug("Populate searchedXrefRecCollMap for new PARTY_ORIG_ROWID " + partyOrigRowId + " for PARTY_ROWID " + partyRowId);
					searchedRecCollMap.put(partyOrigRowId, new SearchedXrefRecordCollection());
					bUniqueRec = true;
				}

				searchedRecCollObj = searchedRecCollMap.get(partyOrigRowId);

				if(bUniqueRec)	{

					LOG.debug("============setting Party Xref Copy");
					searchedRecCollObj.setParty_rowid(partyRowId.trim());
					searchedRecCollObj.setBo_class(resultSet.getString("BO_CLASS_CODE"));
					searchedRecCollObj.setParty_type(resultSet.getString("PARTY_TYPE"));
					searchedRecCollObj.setParty_name(resultSet.getString("PARTY_NAME"));
					searchedRecCollObj.setGeo(resultSet.getString("PARTY_GEO"));
					searchedRecCollObj.setRegion(resultSet.getString("PARTY_REGION"));
					searchedRecCollObj.setStatus_cd(resultSet.getString("STATUS_CD"));
					searchedRecCollObj.setVat_regno(resultSet.getString("PARTY_VAT_REG_NBR"));
					searchedRecCollObj.setTax_jd_cd(resultSet.getString("PARTY_TAX_JURSDCTN_CD"));
					searchedRecCollObj.setSales_cd(resultSet.getString("SALES_BLOCK_CD"));
					searchedRecCollObj.setUcn(resultSet.getString("UCN"));
					searchedRecCollObj.setEnglish_name(resultSet.getString("ENGLISH_NAME"));
					searchedRecCollObj.setPhysicalGeo(resultSet.getString("PHYSICAL_GEO"));
					searchedRecCollObj.setPhysicalRegion(resultSet.getString("PHYSICAL_REGION"));
				}

				if (!searchedRecCollObj.getXrefMap().containsKey(partyOrigRowId)) {
					LOG.debug("============setting XREFType");
					xref = new XREFType();
					xref.setSRCSYSTEM(resultSet.getString("PARTY_ROWID_SYSTEM").trim());
					if(Constant.SRC_SYSTEM_ADB.equals(resultSet.getString("PARTY_ROWID_SYSTEM").trim())){
						xref.setSRCPKEY(resultSet.getString("PARTY_PKEY_SRC_OBJECT").trim().replaceAll(Constant.ADB_ACT_PREFIX, Constant.STR_BLANK));
					}else{
						xref.setSRCPKEY(resultSet.getString("PARTY_PKEY_SRC_OBJECT").trim());
					}
					searchedRecCollObj.getXrefMap().put(partyOrigRowId, xref);
				}

				if (resultSet.getString("ACCOUNT_ROWID_OBJECT") != null &&
						!searchedRecCollObj.getAccountMap().containsKey(resultSet.getString("ACCOUNT_ROWID_OBJECT"))) {
					LOG.debug("============setting Account info");
					accInfo = new AccountXrefType();
					accInfo.setROWIDACCOUNT(resultSet.getString("ACCOUNT_ROWID_OBJECT").trim());
					accInfo.setSRCSYSTEM(resultSet.getString("ACCOUNT_ROWID_SYSTEM").trim());
					if(Constant.SRC_SYSTEM_ADB.equals(resultSet.getString("ACCOUNT_ROWID_SYSTEM").trim())){
						accInfo.setSRCPKEY(resultSet.getString("ACCOUNT_PKEY_SRC_OBJECT").replaceAll(Constant.ADB_ACT_PREFIX, Constant.STR_BLANK));
					}else{
						accInfo.setSRCPKEY(resultSet.getString("ACCOUNT_PKEY_SRC_OBJECT"));
					}
					
					accInfo.setACCTNAME(resultSet.getString("ACCT_NAME"));
					accInfo.setALIASNAME(resultSet.getString("ALIAS_NAME"));
					accInfo.setACCTSTATUS(resultSet.getString("ACCT_STATUS"));
					accInfo.setACCTTYPE(resultSet.getString("ACCT_TYPE"));
					accInfo.setACCOUNTREGION(resultSet.getString("ACCOUNT_REGION"));
					accInfo.setACCOUNTGEO(resultSet.getString("ACCOUNT_GEO"));
					accInfo.setMARKET(resultSet.getString("MARKET"));
					accInfo.setCUSTGROUP(resultSet.getString("CUST_GROUP"));
					accInfo.setPRICEGROUP(resultSet.getString("PRICE_GROUP"));
					accInfo.setCOMPANYCD(resultSet.getString("COMPANY_CD"));
					accInfo.setACCOUNTVATREGNBR(resultSet.getString("ACCOUNT_VAT_REG_NBR"));
					accInfo.setTAXTYPE(resultSet.getString("TAX_TYPE"));
					accInfo.setACCOUNTTAXJURSDCTNCD(resultSet.getString("ACCOUNT_TAX_JURDSCTN_CD"));
					accInfo.setBILLBLOCKCD(resultSet.getString("BILL_BLOCK_CD"));
					accInfo.setORDRBLOCKCD(resultSet.getString("ORDR_BLOCK_CD"));
					accInfo.setDLVRYBLOCKCD(resultSet.getString("DLVRY_BLOCK_CD"));
					accInfo.setPOSTBLOCKCD(resultSet.getString("POST_BLOCK_CD"));
					accInfo.setSALEBLOCKCD(resultSet.getString("SALE_BLOCK_CD"));
					accInfo.setCHANNELID(resultSet.getString("CHANNEL_ID"));
					accInfo.setPARTNERTYPE(resultSet.getString("PARTNER_TYPE"));
					accInfo.setVENDORNBR(resultSet.getString("VENDOR_NBR"));
					accInfo.setDIRECTIND(resultSet.getString("DIRECT_IND"));
					accInfo.setNAMEDACCTIND(resultSet.getString("NAMED_ACCT_IND"));
					accInfo.setNONVALACCTIND(resultSet.getString("NON_VAL_ACCT_IND"));
					accInfo.setPARTNERIND(resultSet.getString("PARTNER_IND"));
					accInfo.setSIEBELROWID(resultSet.getString("SIEBEL_ROWID"));
					accInfo.setSAPCUSTNUMBER(resultSet.getString("SAP_CUST_NUMBER"));
					accInfo.setMDMLEGACYID(resultSet.getString("MDM_LEGACY_ID"));
					accInfo.setDATASRCSYSTEM(resultSet.getString("DATA_SRC_SYSTEM"));
					if(!Util.isNullOrEmpty(resultSet.getString("ENGLISH_NAME")))	{
						accInfo.setSAPNAME1(resultSet.getString("ENGLISH_NAME"));
					} else {
						accInfo.setSAPNAME1(resultSet.getString("SAP_NAME_1"));
					}
					accInfo.setSAPNAME2(resultSet.getString("SAP_NAME_2"));
					accInfo.setSAPNAME3(resultSet.getString("SAP_NAME_3"));
					accInfo.setSAPNAME4(resultSet.getString("SAP_NAME_4"));
					
					/** Modified for SFDC START */
					accInfo.setSalesForceID(resultSet.getString("SFID"));
					accInfo.setDraftAccountFlag(resultSet.getString("DRAFT_FLG"));
					/** Modified for SFDC END */
					/** changes for Sales Force Integration -Start */
					accInfo.setLOCALNAME(resultSet.getString("LOCAL_NAME"));
					accInfo.setCURRENCYCD(resultSet.getString("ACCOUNT_CURRENCY_CD"));
					accInfo.setTAXID(resultSet.getString("TAX_ID"));
					accInfo.setPRICEBANDAGGREMENT(resultSet.getString("PRICING_BAND_AGRMNT"));
					/** changes for Sales Force Integration -End */
					/** changes for Track-2 -Start */
					accInfo.setSITEDESIGNATION(resultSet.getString("SITE_DESIGNATION"));
					/** changes for Track-2 -End */
					/** changes for Track-3 -Start */
					accInfo.setRESELLLEVEL(resultSet.getString("RESELL_LEVEL"));
					accInfo.setPARTNERSHIPSTATUS(resultSet.getString("PARTNERSHIP_STATUS"));
					/** changes for Track-3 -End */
					/** changes for MDMp-2885 -Start */
					accInfo.setISDENIEDFLG(resultSet.getString("IS_DENIED_FLG"));
					/** changes for MDMP-3092 -Start */
					accInfo.setTOP250FLG(resultSet.getString("TOP_250_FLG"));
					accInfo.setTOP1000FLG(resultSet.getString("TOP_1000_FLG"));
					/** changes for MDMP-3092 -End */
					LOG.debug("===Inserting into Account Map===");
					searchedRecCollObj.getAccountMap().put(accInfo.getROWIDACCOUNT(), accInfo);
				}
				if(!Util.isNullOrEmpty(resultSet.getString("PARTY_ROWID_SYSTEM")) && 
						(Constant.SRC_SYSTEM_ADB.equalsIgnoreCase(resultSet.getString("PARTY_ROWID_SYSTEM").trim())) &&
						(Constant.PARTY_TYPE_PROSPECT_ACCOUNT.equalsIgnoreCase(resultSet.getString("PARTY_TYPE")))){
				if (resultSet.getString("PROSPECT_ROWID_OBJECT") != null &&
						!searchedRecCollObj.getAccountMap().containsKey(resultSet.getString("PROSPECT_ROWID_OBJECT"))) {
					accInfo = new AccountXrefType();
					accInfo.setROWIDACCOUNT(resultSet.getString("PROSPECT_ROWID_OBJECT").trim());
					accInfo.setSRCSYSTEM(resultSet.getString("PROSPECT_ROWID_SYSTEM").trim());
					if(Constant.SRC_SYSTEM_ADB.equalsIgnoreCase(resultSet.getString("PROSPECT_ROWID_SYSTEM").trim())){
						accInfo.setSRCPKEY(resultSet.getString("PROSPECT_PKEY_SRC_OBJECT").replaceAll(Constant.ADB_ACT_PREFIX, Constant.STR_BLANK));	
					}else{
						accInfo.setSRCPKEY(resultSet.getString("PROSPECT_PKEY_SRC_OBJECT"));
					}
					accInfo.setACCTNAME(resultSet.getString("PROSPECT_NAME"));
					accInfo.setACCTTYPE(resultSet.getString("PROSPECT_TYPE"));
					accInfo.setCUSTGROUP(resultSet.getString("PROSPECT_GROUP"));
					searchedRecCollObj.getAccountMap().put(accInfo.getROWIDACCOUNT(), accInfo);
				}
				}

				if (resultSet.getString("ADDRESS_ROWID_OBJECT") != null &&
						!searchedRecCollObj.getAddressMap().containsKey(resultSet.getString("ADDRESS_ROWID_OBJECT"))) {
					LOG.debug("============setting Address");

					address = new AddressXrefType();
					address.setROWIDADDRESS(resultSet.getString("ADDRESS_ROWID_OBJECT").trim());
					address.setSRCSYSTEM(resultSet.getString("ADDRESS_ROWID_SYSTEM").trim());
					if(Constant.SRC_SYSTEM_ADB.equals(resultSet.getString("ADDRESS_ROWID_SYSTEM").trim())){
						address.setSRCPKEY(resultSet.getString("ADDRESS_PKEY_SRC_OBJECT").replaceAll(Constant.ADB_ACT_PREFIX, Constant.STR_BLANK));
					}else{
						address.setSRCPKEY(resultSet.getString("ADDRESS_PKEY_SRC_OBJECT"));
					}
					address.setADDRLN1(resultSet.getString("ADDR_LN1"));
					address.setADDRLN2(resultSet.getString("ADDR_LN2"));
					address.setADDRLN3(resultSet.getString("ADDR_LN3"));
					address.setADDRLN4(resultSet.getString("ADDR_LN4"));
					address.setCITY(resultSet.getString("CITY"));
					address.setCOUNTY(resultSet.getString("COUNTY"));
					address.setDISTRICT(resultSet.getString("DISTRICT"));
					address.setSTATECD(resultSet.getString("STATE_CD"));
					address.setPOSTALCD(resultSet.getString("POSTAL_CD"));
					address.setCOUNTRYCD(resultSet.getString("COUNTRY_CD"));
					address.setLANGCD(resultSet.getString("LANG_CD"));
					address.setLONGITUDE(resultSet.getString("LONGITUDE"));
					address.setLATITUDE(resultSet.getString("LATITUDE"));
					address.setADDRTYPE(resultSet.getString("ADDR_TYPE"));
					address.setADDRSTATUS(resultSet.getString("ADDR_STATUS"));

					LOG.debug("===Inserting into Address Map===");
					searchedRecCollObj.getAddressMap().put(address.getROWIDADDRESS(), address);
				}

				if (resultSet.getString("COMMUNICATION_ROWID_OBJECT") != null &&
						!searchedRecCollObj.getCommMap().containsKey(resultSet.getString("COMMUNICATION_ROWID_OBJECT"))) {
					if(resultSet.getString("COMM_HUB_STATE_IND")!=null && resultSet.getString("COMM_HUB_STATE_IND").equals("1")){
					communication = new CommunicationXrefType();
					LOG.debug("============adding Communication");

					communication.setROWIDCOMMUNICATION(resultSet.getString("COMMUNICATION_ROWID_OBJECT").trim());
					communication.setSRCSYSTEM(resultSet.getString("COMMUNICATION_ROWID_SYSTEM").trim());
					if(Constant.SRC_SYSTEM_ADB.equals(resultSet.getString("COMMUNICATION_ROWID_SYSTEM").trim())){
						communication.setSRCPKEY(resultSet.getString("COMMUNICATION_PKEY_SRC_OBJECT").replaceAll(Constant.ADB_ACT_PREFIX, Constant.STR_BLANK));
					}else{
						communication.setSRCPKEY(resultSet.getString("COMMUNICATION_PKEY_SRC_OBJECT"));
					}
					communication.setCOMMTYPE(resultSet.getString("COMM_TYPE"));
					communication.setCOMMVALUE(resultSet.getString("COMM_VALUE"));
					communication.setCOMMSTATUS(resultSet.getString("COMM_STATUS"));
					communication.setPRFRDCOMMIND(resultSet.getString("PRFRD_COMM_IND"));
					communication.setWEBDOMAIN(resultSet.getString("WEB_DOMAIN"));
					/* changes for SFDC - Track2 -Start */
					communication.setCOMMEXTN(resultSet.getString("COMM_EXTN"));
					communication.setCOMMMKTGPREF(resultSet.getString("COMM_MKTG_PREF"));
					/* changes for SFDC - Track2 -End */
					LOG.debug("===Inserting into Communication Map===");
					searchedRecCollObj.getCommMap().put(communication.getROWIDCOMMUNICATION(), communication);
					}
				}

				if (resultSet.getString("PARTY_ORG_ROWID_OBJECT") != null &&
						!searchedRecCollObj.getPartyOrgMap().containsKey(resultSet.getString("PARTY_ORG_ROWID_OBJECT"))) {
					if(resultSet.getInt("ORG_EXTN_HUB_STATE_IND")== 1) {
					partyOrgExt = new PartyOrgExtXrefType();
					LOG.debug("============adding PartyOrgExt");

					partyOrgExt.setROWIDORGEXTN(resultSet.getString("PARTY_ORG_ROWID_OBJECT").trim());
					//partyOrgExt.setSRCSYSTEM(resultSet.getString("PARTY_ORG_ROWID_SYSTEM"));
					//partyOrgExt.setSRCPKEY(resultSet.getString("PARTY_ORG_PKEY_SRC_OBJECT"));
					partyOrgExt.setORGDUNSNBR(resultSet.getString("ORG_DUNS_NBR"));
					partyOrgExt.setTRADENAME(resultSet.getString("TRADE_NAME"));
					partyOrgExt.setTRADENAME2(resultSet.getString("TRADE_NAME_2"));
					partyOrgExt.setSITEEMPLCNT(resultSet.getString("SITE_EMPL_CNT"));
					partyOrgExt.setGLBLEMPLCNT(resultSet.getString("GLBL_EMPL_CNT"));
					partyOrgExt.setVERTICAL(resultSet.getString("VERTICAL"));
					partyOrgExt.setREVENUE(resultSet.getString("REVENUE"));
					partyOrgExt.setLINEOFBUS(resultSet.getString("LINE_OF_BUS"));
					partyOrgExt.setPRIMSIC(resultSet.getString("PRIM_SIC"));
					partyOrgExt.setSECSIC(resultSet.getString("SEC_SIC"));
					partyOrgExt.setSALESVOLUME(resultSet.getString("SALES_VOLUME"));
					partyOrgExt.setSALESAMOUNT(resultSet.getString("SALES_AMOUNT"));
					partyOrgExt.setCURRENCYCD(resultSet.getString("CURRENCY_CD"));
					partyOrgExt.setOUTOFBUSIND(resultSet.getString("OUT_OF_BUS_IND"));
					partyOrgExt.setGLBLULTIND(resultSet.getString("GLBL_ULT_IND"));
					partyOrgExt.setFORTUNEINFO(resultSet.getString("FORTUNE_INFO"));
					partyOrgExt.setHIERARCHYLEVEL(resultSet.getString("HIERARCHY_LEVEL"));
					partyOrgExt.setORGHQPARENTDUNS(resultSet.getString("ORG_HQ_PARENT_DUNS"));
					partyOrgExt.setORGDOMULTDUNS(resultSet.getString("ORG_DOM_ULT_DUNS"));
					partyOrgExt.setORGGLBULTDUNS(resultSet.getString("ORG_GLB_ULT_DUNS"));
					partyOrgExt.setMFEGLBLPARENTNM(resultSet.getString("MFE_GLBL_PARENT_NM"));
					partyOrgExt.setMFEPARENTNM(resultSet.getString("MFE_PARENT_NM"));
					partyOrgExt.setMFEWWPARENTNM(resultSet.getString("MFE_WW_PARENT_NM"));
					partyOrgExt.setMFESUBSDRYPARENTNM(resultSet.getString("MFE_SUBSDRY_PARENT_NM"));
					partyOrgExt.setMFEPRTNRPARENTORG(resultSet.getString("MFE_PRTNR_PARENT_ORG"));
					partyOrgExt.setSALESREVNUOVRID(resultSet.getString("SALES_REVNU_OVRID"));
					partyOrgExt.setMFEEMPCNTOVERIDE(resultSet.getString("MFE_EMP_CNT_OVERIDE"));
					partyOrgExt.setSICCDOVRIDE(resultSet.getString("SIC_CD_OVRIDE"));
					/** changes for Track-2 -Start */
					partyOrgExt.setMFECOUNTRYULTUCN(resultSet.getString("MFE_COUNTRY_ULT_UCN"));
					partyOrgExt.setMFEGLBLPARENTUCN(resultSet.getString("MFE_GLBL_PARENT_UCN"));
					partyOrgExt.setMFEGLOBALPARNMOVRIDE(resultSet.getString("MFE_GLOBAL_PAR_NM_OVRIDE"));
					partyOrgExt.setMFENEXTLVLSUBSPARNM(resultSet.getString("MFE_NEXT_LVL_SUBS_PAR_NM"));
					partyOrgExt.setMFENEXTLVLSUBSPARUCN(resultSet.getString("MFE_NEXT_LVL_SUBS_PAR_UCN"));
					partyOrgExt.setMFESUBSDRYPARENTNM(resultSet.getString("MFE_SUBS_PARENT_NM"));
					partyOrgExt.setMFESUBSDRYPARENTPRTNNM(resultSet.getString("MFE_SUBSDRY_PARENT_PRTN_NM"));
					partyOrgExt.setMFESUBSPARENTNMOVRIDE(resultSet.getString("MFE_SUBS_PARENT_NM_OVRIDE"));
					partyOrgExt.setMFESUBSPARENTUCN(resultSet.getString("MFE_SUBS_PARENT_UCN"));
					partyOrgExt.setMFETXN5YRFLG(resultSet.getString("MFE_TXN_5_YR_FLG"));
					partyOrgExt.setMFETXN7YRFLG(resultSet.getString("MFE_TXN_7_YR_FLG"));
					partyOrgExt.setMFEWWPARENTNM(resultSet.getString("MFE_WW_PARENT_NM"));
					partyOrgExt.setMFEWWPARENTPRTNNM(resultSet.getString("MFE_WW_PARENT_PRTN_NM"));
					partyOrgExt.setTXN5YRFLG(resultSet.getString("TXN_5_YR_FLG"));
					partyOrgExt.setTXN7YRFLG(resultSet.getString("TXN_7_YR_FLG"));
					partyOrgExt.setGLBEMPCNTOVERRIDE(resultSet.getString("GLB_EMP_CNT_OVERRIDE"));
					partyOrgExt.setACTIVETXNFLG(resultSet.getString("ACTIVE_TXN_FLAG"));
					partyOrgExt.setPARENTFLG(resultSet.getString("PARENT_FLAG"));
					partyOrgExt.setPARTNERFLG(resultSet.getString("PARTNER_FLAG"));
					partyOrgExt.setCUSTFLG(resultSet.getString("CUST_FLAG"));
					partyOrgExt.setGLBFLG(resultSet.getString("GLB_FLG"));
					partyOrgExt.setCOUNTRYULTIND(resultSet.getString("COUNTRY_ULT_IND"));	
					partyOrgExt.setSUBSIDIARYIND(resultSet.getString("SUBSIDIARY_IND"));
					partyOrgExt.setMDMPARENTUCN(resultSet.getString("MDM_PARENT_UCN"));
					partyOrgExt.setG2KFLG(resultSet.getString("G2K_FLG"));
					partyOrgExt.setGLBSALESREVNUOVRID(resultSet.getString("GLB_SALES_REVNU_OVRID"));
					/** changes for Track-2 -End */
					/** changes for Track-3 -Start */
					partyOrgExt.setPTRPARENTUCN(resultSet.getString("PTR_PARENT_UCN"));
					partyOrgExt.setPTRPARENTNM(resultSet.getString("PTR_PARENT_NM"));
					partyOrgExt.setPTRGLBLPARENTUCN(resultSet.getString("PTR_GLBL_PARENT_UCN"));
					/** changes for Track-3 -End */
					LOG.debug("===Inserting into PartyOrgExtType Map==");
					searchedRecCollObj.getPartyOrgMap().put(partyOrgExt.getROWIDORGEXTN(), partyOrgExt);
					}
				}

				if (resultSet.getString("PARTY_CLASS_ROWID_OBJECT") != null &&
						!searchedRecCollObj.getClassMap().containsKey(resultSet.getString("PARTY_CLASS_ROWID_OBJECT"))) {
					if(resultSet.getString("CLASSIFCTN_HUB_STATE_IND")!=null && resultSet.getString("CLASSIFCTN_HUB_STATE_IND").equals("1")){
					classfction = new ClassificationXrefType();
					LOG.debug("============adding Classification");

					classfction.setROWIDCLASSIFICTN(resultSet.getString("PARTY_CLASS_ROWID_OBJECT").trim());
					classfction.setSRCSYSTEM(resultSet.getString("PARTY_CLASS_ROWID_SYSTEM").trim());
					if(Constant.SRC_SYSTEM_ADB.equals(resultSet.getString("PARTY_CLASS_ROWID_SYSTEM").trim())){
						classfction.setSRCPKEY(resultSet.getString("PARTY_CLASS_PKEY_SRC_OBJECT").replaceAll(Constant.ADB_ACT_PREFIX, Constant.STR_BLANK));
					}else{
						classfction.setSRCPKEY(resultSet.getString("PARTY_CLASS_PKEY_SRC_OBJECT"));
					}
					classfction.setCLASSIFICTNTYPE(resultSet.getString("CLASSIFCTN_TYPE"));
					classfction.setCLASSIFICTNVALUE(resultSet.getString("CLASSIFCTN_VALUE"));
					classfction.setSTARTDATE(resultSet.getString("START_DATE"));
					classfction.setENDDATE(resultSet.getString("END_DATE"));
					/* changes for SFDC - Track2 -Start */
					classfction.setCLASSIFICTNMETH(resultSet.getString("CLASSIFCTN_METH"));
					/* changes for SFDC - Track2 -End */
					LOG.debug("===Inserting into Classification Map===");
					searchedRecCollObj.getClassMap().put(classfction.getROWIDCLASSIFICTN(), classfction);
					}
				}
				//Modified for Track-2
				if(bUniqueRec)	{
					Map<String,String> ucnMap = getMdmHierarchyView(partyRowId);  // query in orgextn by partyId
					Map<String,String> partnerResellerUCNMap = null;
					if("Reseller".equalsIgnoreCase(partyType) || "Distributor".equalsIgnoreCase(partyType)){
						partnerResellerUCNMap = getPartnerRellserHierarchyView(partyRowId,partyType);
					}else{
						partnerResellerUCNMap = new HashMap<String,String>();
						partnerResellerUCNMap.put("MDM_PRTNR_ORG_UCN","");
						partnerResellerUCNMap.put("PRTNR_ORG_NM","");
					}
					isGlobalParent = Util.isNullOrEmpty(ucnMap.get("GLB_FLG"))?isGlobalParent:ucnMap.get("GLB_FLG");
					String wwParentUcn = ucnMap.get("PTR_GLBL_PARENT_UCN");
					LOG.debug("WW Parent UCN "+wwParentUcn);
					String globalParentName = ucnMap.get("MFE_GLOBAL_PAR_NM_OVRIDE");
					if(partyType.equalsIgnoreCase("Partner")||partyType.equalsIgnoreCase("Reseller")|| partyType.equalsIgnoreCase("Distributor")){
						LOG.debug("============adding Partner partyAccountRelationship ");
						
						if(!Util.isNullOrEmpty(wwParentUcn)){
							
							rowidRelationship = "0";  // As there is no party relation so rel rowid is set as 0
							partyAccountRelationship = new PartyAccountRelationshipXrefType();
							LOG.debug("Populating Partner Hierarchy=== ");
							if (partyType.equalsIgnoreCase("Partner")) {
								partyAccountRelationship.setMDMPARENTUCN(ucnMap.get("PTR_PARENT_UCN"));
								partyAccountRelationship.setMDMPARENTNAME(ucnMap.get("PTR_PARENT_NM"));
							} else if("Reseller".equalsIgnoreCase(partyType) || "Distributor".equalsIgnoreCase(partyType)){
								partyAccountRelationship.setMDMPARENTUCN(partnerResellerUCNMap.get("MDM_PRTNR_ORG_UCN"));
								partyAccountRelationship.setMDMPARENTNAME(partnerResellerUCNMap.get("PRTNR_ORG_NM"));
							}
							partyAccountRelationship.setMDMGLBPARENTUCN(ucnMap.get("PTR_GLBL_PARENT_UCN"));
							partyAccountRelationship.setMDMGLBPARENTNAME(ucnMap.get("MFE_WW_PARENT_PRTN_NM"));
							partyAccountRelationship.setHIERARCHYTYPE(Constant.Partner_Hierarchy);
							
							if (partyAccountRelationship.getHIERARCHYTYPE() != null && hierarchyGRP.contains(partyAccountRelationship.getHIERARCHYTYPE())){
								if (!searchedRecCollObj.getPartyRelMap()
										.containsKey(Constant.Partner_Hierarchy+rowidRelationship) ){
								LOG.debug("======Inserting into Partner Relationship Map======");
								searchedRecCollObj.getPartyRelMap().put(partyAccountRelationship.getHIERARCHYTYPE()+rowidRelationship, partyAccountRelationship);
							}
						 }
						}
						
						
						  if(!Util.isNullOrEmpty(ucnMap.get("MDM_PARENT_UCN"))){
							  rowidRelationship = "1";  // As there is no party relation so rel rowid is set as 1
								partyAccountRelationship = new PartyAccountRelationshipXrefType();
								partyAccountRelationship.setHIERARCHYTYPE(Constant.McAfee_Hierarchy);
								partyAccountRelationship.setMDMPARENTUCN(ucnMap.get("MDM_PARENT_UCN"));
								partyAccountRelationship.setMDMPARENTNAME(ucnMap.get("MFE_PARENT_NM"));
								partyAccountRelationship.setMDMGLBPARENTUCN(ucnMap.get("MFE_GLBL_PARENT_UCN"));
							if (Util.isNullOrEmpty(globalParentName)) {
								partyAccountRelationship.setMDMGLBPARENTNAME(ucnMap.get("MFE_GLBL_PARENT_NM"));
							} else {
								partyAccountRelationship.setMDMGLBPARENTNAME(ucnMap.get("MFE_GLOBAL_PAR_NM_OVRIDE"));
							}
								if (hierarchyGRP.contains(partyAccountRelationship.getHIERARCHYTYPE())) {
									LOG.debug("===Inserting into  McAfee_Hierarchy  Relationship Map==="+partyAccountRelationship.getHIERARCHYTYPE()+rowidRelationship);
									searchedRecCollObj.getPartyRelMap().put(partyAccountRelationship.getHIERARCHYTYPE()+rowidRelationship,
											partyAccountRelationship);
								}
                            }
						  
					} 
					 else if(partyType.equalsIgnoreCase("Customer")){
						 LOG.debug("============adding Mcafee Hierarchy partyAccountRelationship ");
						 
                        if(!Util.isNullOrEmpty(ucnMap.get("MDM_PARENT_UCN"))){
                        	rowidRelationship = "0";  // As there is no party relation so rel rowid is set as 0
							partyAccountRelationship = new PartyAccountRelationshipXrefType();
							partyAccountRelationship.setHIERARCHYTYPE(Constant.McAfee_Hierarchy);
							partyAccountRelationship.setMDMPARENTUCN(ucnMap.get("MDM_PARENT_UCN"));
							partyAccountRelationship.setMDMPARENTNAME(ucnMap.get("MFE_PARENT_NM"));
							partyAccountRelationship.setMDMGLBPARENTUCN(ucnMap.get("MFE_GLBL_PARENT_UCN"));
						if (Util.isNullOrEmpty(globalParentName)) {
							partyAccountRelationship.setMDMGLBPARENTNAME(ucnMap.get("MFE_GLBL_PARENT_NM"));
						} else {
							partyAccountRelationship.setMDMGLBPARENTNAME(ucnMap.get("MFE_GLOBAL_PAR_NM_OVRIDE"));
						}
						if ((!Util.isNullOrEmpty(isGlobalParent)) && isGlobalParent.equalsIgnoreCase("N")) {
							if ((!Util.isNullOrEmpty(partyAccountRelationship.getMDMPARENTUCN())) && (!Util.isNullOrEmpty(partyAccountRelationship.getMDMGLBPARENTUCN()))
									&& (partyAccountRelationship.getMDMPARENTUCN().equals(partyAccountRelationship.getMDMGLBPARENTUCN()))) {
								LOG.debug("============set singlesite flag ");
								partyAccountRelationship.setSINGLESITEFLAG(Constant.STR_Y);
							} else {
								partyAccountRelationship.setSINGLESITEFLAG(Constant.STR_N);
							}
						} else {
							partyAccountRelationship.setSINGLESITEFLAG(Constant.STR_N);
						}
							if (hierarchyGRP.contains(partyAccountRelationship.getHIERARCHYTYPE())) {
								LOG.debug("===Inserting into  McAfee_Hierarchy  Relationship Map==="+partyAccountRelationship.getHIERARCHYTYPE()+rowidRelationship);
								searchedRecCollObj.getPartyRelMap().put(partyAccountRelationship.getHIERARCHYTYPE()+rowidRelationship,
										partyAccountRelationship);
							}
							if(!Util.isNullOrEmpty(wwParentUcn)){
								
								rowidRelationship = "1";  // As there is no party relation so rel rowid is set as 1
								partyAccountRelationship = new PartyAccountRelationshipXrefType();
								LOG.debug("Populating Partner Hierarchy=== ");
								if("Reseller".equalsIgnoreCase(partyType) || "Distributor".equalsIgnoreCase(partyType)){
									partyAccountRelationship.setMDMPARENTUCN(partnerResellerUCNMap.get("MDM_PRTNR_ORG_UCN"));
									partyAccountRelationship.setMDMPARENTNAME(partnerResellerUCNMap.get("PRTNR_ORG_NM"));
								}else {
									partyAccountRelationship.setMDMPARENTUCN(ucnMap.get("PTR_PARENT_UCN"));
									partyAccountRelationship.setMDMPARENTNAME(ucnMap.get("PTR_PARENT_NM"));
								}
								partyAccountRelationship.setMDMGLBPARENTUCN(ucnMap.get("PTR_GLBL_PARENT_UCN"));
								partyAccountRelationship.setMDMGLBPARENTNAME(ucnMap.get("MFE_WW_PARENT_PRTN_NM"));
								partyAccountRelationship.setHIERARCHYTYPE(Constant.Partner_Hierarchy);
								if (partyAccountRelationship.getHIERARCHYTYPE() != null && hierarchyGRP.contains(partyAccountRelationship.getHIERARCHYTYPE())){
									if (!searchedRecCollObj.getPartyRelMap().containsKey(Constant.Partner_Hierarchy+rowidRelationship) ){
									LOG.debug("======Inserting into Partner Relationship Map======");
									searchedRecCollObj.getPartyRelMap().put(partyAccountRelationship.getHIERARCHYTYPE()+rowidRelationship, partyAccountRelationship);
								}
                            }
							}
						
                        }
						else {
							if (searchedRecCollObj.getPartyRelMap().isEmpty()) {
								LOG.debug("============adding dummy partyAccountRelationship ");
								rowidRelationship = "0"; 
								partyAccountRelationship = new PartyAccountRelationshipXrefType();
								if (!"Y".equalsIgnoreCase(isGlobalParent)) {
									partyAccountRelationship.setMDMPARENTUCN(searchedRecCollObj.getUcn());
									partyAccountRelationship.setMDMPARENTNAME(searchedRecCollObj.getParty_name());
									partyAccountRelationship.setMDMGLBPARENTUCN(searchedRecCollObj.getUcn());
									partyAccountRelationship.setMDMGLBPARENTNAME(searchedRecCollObj.getParty_name());
									partyAccountRelationship.setHIERARCHYTYPE(Constant.McAfee_Hierarchy);
									partyAccountRelationship.setSINGLESITEFLAG(Constant.STR_Y);
								}
								if (partyAccountRelationship.getHIERARCHYTYPE() != null
										&& hierarchyGRP.contains(partyAccountRelationship.getHIERARCHYTYPE())) {
									LOG.debug("======Inserting into Single Site Relationship Map======");
									searchedRecCollObj.getPartyRelMap().put(rowidRelationship,
											partyAccountRelationship);
								}

							}
						}
					 }
					
					/*else {
					if (resultSet.getString("PARTY_REL_ROWID_CHILD") != null ){
						if (!searchedRecCollObj.getPartyRelMap()
								.containsKey(resultSet.getString("PARTY_REL_ROWID_OBJECT"))) {

							rowidRelationship = resultSet.getString("PARTY_REL_ROWID_OBJECT");
							*//** Modified for M4M START *//*
							partyAccountRelationship = new PartyAccountRelationshipXrefType();
							partyAccountRelationship.setRELTYPE(resultSet.getString("REL_TYPE_CODE"));
							hierarchyCd = resultSet.getString("HIERARCHY_CODE");
							partyAccountRelationship.setHIERARCHYTYPE(resultSet.getString("HIERARCHY_CODE"));
							partyAccountRelationship.setSINGLESITEFLAG(Constant.STR_N);
							if (Constant.McAfee_Hierarchy.equalsIgnoreCase(hierarchyCd)) {

								partyAccountRelationship.setMDMPARENTUCN(ucnMap.get("MDM_PARENT_UCN"));
								partyAccountRelationship.setMDMPARENTNAME(ucnMap.get("MFE_PARENT_NM"));
								partyAccountRelationship.setMDMGLBPARENTUCN(ucnMap.get("MFE_GLBL_PARENT_UCN"));
								if(Util.isNullOrEmpty(globalParentName))	{
									partyAccountRelationship.setMDMGLBPARENTNAME(ucnMap.get("MFE_GLBL_PARENT_NM"));
									}
									else{
										partyAccountRelationship.setMDMGLBPARENTNAME(ucnMap.get("MFE_GLOBAL_PAR_NM_OVRIDE"));
									}
							} else if (Constant.Partner_Hierarchy.equalsIgnoreCase(hierarchyCd)) {

								partyAccountRelationship.setMDMPARENTUCN(ucnMap.get("MDM_PARENT_UCN"));
								partyAccountRelationship.setMDMPARENTNAME(ucnMap.get("MFE_SUBSDRY_PARENT_PRTN_NM"));
								partyAccountRelationship.setMDMGLBPARENTUCN(ucnMap.get("MFE_GLBL_PARENT_UCN"));
								partyAccountRelationship.setMDMPARENTUCN(ucnMap.get("PTR_PARENT_UCN"));
								partyAccountRelationship.setMDMPARENTNAME(ucnMap.get("PTR_PARENT_NM"));
								partyAccountRelationship.setMDMGLBPARENTUCN(ucnMap.get("PTR_GLBL_PARENT_UCN"));
								partyAccountRelationship.setMDMGLBPARENTNAME(ucnMap.get("MFE_WW_PARENT_PRTN_NM"));
							}
							if ( wwParentUcn!= null) {
								
								partyAccountRelationship.setMDMPARENTUCN(ucnMap.get("PTR_PARENT_UCN"));
								partyAccountRelationship.setMDMPARENTNAME(ucnMap.get("PTR_PARENT_NM"));
								partyAccountRelationship.setMDMGLBPARENTUCN(ucnMap.get("PTR_GLBL_PARENT_UCN"));
								partyAccountRelationship.setMDMGLBPARENTNAME(ucnMap.get("MFE_WW_PARENT_PRTN_NM"));
								partyAccountRelationship.setHIERARCHYTYPE(Constant.Partner_Hierarchy);
								partyAccountRelationship.setRELTYPE(Constant.isPartnerParentOf);
								LOG.debug("inside wwParentUcn!= null exit");
								
							}
							if (hierarchyGRP.contains(partyAccountRelationship.getHIERARCHYTYPE())) {
								LOG.debug("===Inserting into Relationship Map===");
								searchedRecCollObj.getPartyRelMap().put(rowidRelationship, partyAccountRelationship);
							}
							if ( wwParentUcn!= null) {
								LOG.debug("inside wwParentUcn!= null");
								
								partyAccountRelationship.setMDMPARENTUCN(ucnMap.get("MDM_PARENT_UCN"));
								partyAccountRelationship.setMDMPARENTNAME(ucnMap.get("MFE_SUBSDRY_PARENT_PRTN_NM"));
								partyAccountRelationship.setMDMGLBPARENTUCN(ucnMap.get("MFE_GLBL_PARENT_UCN"));
								partyAccountRelationship.setMDMPARENTUCN(ucnMap.get("PTR_PARENT_UCN"));
								partyAccountRelationship.setMDMPARENTNAME(ucnMap.get("PTR_PARENT_NM"));
								partyAccountRelationship.setMDMGLBPARENTUCN(ucnMap.get("PTR_GLBL_PARENT_UCN"));
								partyAccountRelationship.setMDMGLBPARENTNAME(ucnMap.get("MFE_WW_PARENT_PRTN_NM"));
								partyAccountRelationship.setHIERARCHYTYPE(Constant.Partner_Hierarchy);
								partyAccountRelationship.setRELTYPE(Constant.isPartnerParentOf);
								LOG.debug("===Inserting into Child Relationship Map 1===");
								searchedRecCollObj.getPartyRelMap().put(rowidRelationship,
										partyAccountRelationship);
							}
							*//** Modified for M4M END *//*
						}
					} else if ((!Util.isNullOrEmpty(isGlobalParent)) && isGlobalParent.equalsIgnoreCase("Y")) {
						List<GlobalHierarchyNode> globalHierarchyNodeList = getGlobalHierarchy(partyRowId);
						
						for (GlobalHierarchyNode globalHierarchyNode : globalHierarchyNodeList) {
							partyAccountRelationship = new PartyAccountRelationshipXrefType();
							if (globalHierarchyNode.getPartyRelRowid() != null && !searchedRecCollObj.getPartyRelMap()
									.containsKey(globalHierarchyNode.getPartyRelRowid())) {
								LOG.debug("===Inserting into Relationship Map for GLOBAL Parent==="
										+ globalHierarchyNode.getPartyRelRowid());
								partyAccountRelationship.setSINGLESITEFLAG(Constant.STR_N);
								rowidRelationship = globalHierarchyNode.getPartyRelRowid();
								partyAccountRelationship.setRELTYPE(globalHierarchyNode.getRelTypeCode());
								hierarchyCd = globalHierarchyNode.getHierarchyCode();
								partyAccountRelationship.setHIERARCHYTYPE(hierarchyCd);
								if (Constant.McAfee_Hierarchy.equalsIgnoreCase(hierarchyCd)) {

									partyAccountRelationship.setMDMPARENTUCN(ucnMap.get("MDM_PARENT_UCN"));
									partyAccountRelationship.setMDMPARENTNAME(ucnMap.get("MFE_PARENT_NM"));
									partyAccountRelationship.setMDMGLBPARENTUCN(ucnMap.get("MFE_GLBL_PARENT_UCN"));
									if(Util.isNullOrEmpty(globalParentName))	{
										partyAccountRelationship.setMDMGLBPARENTNAME(ucnMap.get("MFE_GLBL_PARENT_NM"));
										}
										else{
											partyAccountRelationship.setMDMGLBPARENTNAME(ucnMap.get("MFE_GLOBAL_PAR_NM_OVRIDE"));
										}
								} else if (Constant.Partner_Hierarchy.equalsIgnoreCase(hierarchyCd)) {

								
									partyAccountRelationship.setMDMPARENTUCN(ucnMap.get("PTR_PARENT_UCN"));
									partyAccountRelationship.setMDMPARENTNAME(ucnMap.get("PTR_PARENT_NM"));
									partyAccountRelationship.setMDMGLBPARENTUCN(ucnMap.get("PTR_GLBL_PARENT_UCN"));
									partyAccountRelationship.setMDMGLBPARENTNAME(ucnMap.get("MFE_WW_PARENT_PRTN_NM"));
									partyAccountRelationship.setRELTYPE(Constant.isPartnerParentOf);
								}
								if (hierarchyGRP.contains(partyAccountRelationship.getHIERARCHYTYPE())) {
									LOG.debug("===Inserting into Relationship Map===");
									searchedRecCollObj.getPartyRelMap().put(rowidRelationship,
											partyAccountRelationship);
								}
								if ( wwParentUcn!= null) {
									LOG.debug("inside wwParentUcn!= null");
									
								
									partyAccountRelationship.setMDMPARENTUCN(ucnMap.get("PTR_PARENT_UCN"));
									partyAccountRelationship.setMDMPARENTNAME(ucnMap.get("PTR_PARENT_NM"));
									partyAccountRelationship.setMDMGLBPARENTUCN(ucnMap.get("PTR_GLBL_PARENT_UCN"));
									partyAccountRelationship.setMDMGLBPARENTNAME(ucnMap.get("MFE_WW_PARENT_PRTN_NM"));
									partyAccountRelationship.setHIERARCHYTYPE(Constant.Partner_Hierarchy);
									partyAccountRelationship.setRELTYPE(Constant.isPartnerParentOf);
									LOG.debug("===Inserting into Child Relationship Map 1===");
									searchedRecCollObj.getPartyRelMap().put(rowidRelationship,
											partyAccountRelationship);
								}
							}
						}

					}*/ else {
						if (searchedRecCollObj.getPartyRelMap().isEmpty()) {
							LOG.debug("============adding dummy partyAccountRelationship ");
							rowidRelationship = "0"; // As there is no party
														// relation so rel rowid
														// is set as 0
							partyAccountRelationship = new PartyAccountRelationshipXrefType();
							if (wwParentUcn != null) {
								LOG.debug("Populating Partner Hierarchy=== ");
								if("Reseller".equalsIgnoreCase(partyType) || "Distributor".equalsIgnoreCase(partyType)){
									partyAccountRelationship.setMDMPARENTUCN(partnerResellerUCNMap.get("MDM_PRTNR_ORG_UCN"));
									partyAccountRelationship.setMDMPARENTNAME(partnerResellerUCNMap.get("PRTNR_ORG_NM"));
								}else {
									partyAccountRelationship.setMDMPARENTUCN(ucnMap.get("PTR_PARENT_UCN"));
									partyAccountRelationship.setMDMPARENTNAME(ucnMap.get("PTR_PARENT_NM"));
								}
								partyAccountRelationship.setMDMGLBPARENTUCN(ucnMap.get("PTR_GLBL_PARENT_UCN"));
								partyAccountRelationship.setMDMGLBPARENTNAME(ucnMap.get("MFE_WW_PARENT_PRTN_NM"));
								partyAccountRelationship.setHIERARCHYTYPE(Constant.Partner_Hierarchy);
								partyAccountRelationship.setRELTYPE(Constant.isPartnerParentOf);
							} else if (!"Y".equalsIgnoreCase(isGlobalParent)) {
								partyAccountRelationship.setMDMPARENTUCN(searchedRecCollObj.getUcn());
								partyAccountRelationship.setMDMPARENTNAME(searchedRecCollObj.getParty_name());
								partyAccountRelationship.setMDMGLBPARENTUCN(searchedRecCollObj.getUcn());
								partyAccountRelationship.setMDMGLBPARENTNAME(searchedRecCollObj.getParty_name());
								partyAccountRelationship.setHIERARCHYTYPE(Constant.McAfee_Hierarchy);
								partyAccountRelationship.setSINGLESITEFLAG(Constant.STR_Y);
							}
							if (partyAccountRelationship.getHIERARCHYTYPE() != null && hierarchyGRP.contains(partyAccountRelationship.getHIERARCHYTYPE())){
								LOG.debug("======Inserting into Single Site Relationship Map======");
								searchedRecCollObj.getPartyRelMap().put(rowidRelationship, partyAccountRelationship);
							}
							/** Modified for SFDC END */
						}
					}
					}
					

				bUniqueRec = false;
			}
			LOG.info("Number of retrived party xref profile = " + searchedRecCollMap.size());

			LOG.debug("====Populating Party xref canonical formats");

			for (Entry<String, Map<String, SearchedXrefRecordCollection>> mapEntry : searchedRecCollMapAllParties.entrySet()) {

				for(Entry<String, SearchedXrefRecordCollection> entry : mapEntry.getValue().entrySet()) {

					SearchedXrefRecordCollection fetchedRecCollObj = entry.getValue();
					if (fetchedRecCollObj != null) {
						String partyRowId = fetchedRecCollObj.getParty_rowid();
						party = new PartyXrefType();
						party.setORIGROWIDOBJECT(fetchedRecCollObj.getOrig_rowid());
						party.setBOCLASSCODE(fetchedRecCollObj.getBo_class());
						party.setENGLISHNAME(fetchedRecCollObj.getEnglish_name());
						party.setGEO(fetchedRecCollObj.getGeo());
						party.setPARTYNAME(fetchedRecCollObj.getParty_name());
						party.setPARTYTYPE(fetchedRecCollObj.getParty_type());
						party.setREGION(fetchedRecCollObj.getRegion());
						party.setROWIDOBJECT(partyRowId);
						party.setSALESBLOCKCD(fetchedRecCollObj.getSales_cd());
						party.setSTATUSCD(fetchedRecCollObj.getStatus_cd());
						party.setTAXJURSDCTNCD(fetchedRecCollObj.getTax_jd_cd());
						party.setUCN(fetchedRecCollObj.getUcn());
				//		party.setLEGACYUCN(fetchedRecCollObj.getLegacyUcn());
						party.setVATREGNBR(fetchedRecCollObj.getVat_regno());
						party.setPHYSICALGEO(fetchedRecCollObj.getPhysicalGeo());
						party.setPHYSICALREGION(fetchedRecCollObj.getPhysicalRegion());
						party.getXREF().addAll(fetchedRecCollObj.getXrefMap().values());
						party.getAccount().addAll(fetchedRecCollObj.getAccountMap().values());
						party.getAddress().addAll(fetchedRecCollObj.getAddressMap().values());
						party.getCommunication().addAll(fetchedRecCollObj.getCommMap().values());
						party.getPartyOrgExt().addAll(fetchedRecCollObj.getPartyOrgMap().values());
						party.getPartyPersonExt().addAll(fetchedRecCollObj.getPartyPersonMap().values());
						party.getClassification().addAll(fetchedRecCollObj.getClassMap().values());
						
						/** Modified for M4M START */
						PartyRelationshipXrefType partyRel = party.getPartyRel();
						if(partyRel == null) {
							partyRel = new PartyRelationshipXrefType();
						}
						partyRel.getPARTYACCOUNTREL().addAll(fetchedRecCollObj.getPartyRelMap().values());
						
						XREFType xrefType = fetchedRecCollObj.getXrefMap()!=null&&fetchedRecCollObj.getXrefMap().size()>0?fetchedRecCollObj.getXrefMap().get(0):null;
						String srcSystem=xrefType!=null?xrefType.getSRCSYSTEM():"";
						LOG.info("================Adding Subsidiary Hierarchy==============");
						LOG.info("srcSystem::"+srcSystem);
						LOG.info("partyRowId::"+partyRowId);
						
						if(Constant.PARTY_TYPE_CUSTOMER.equalsIgnoreCase(fetchedRecCollObj.getParty_type()) || 
								Constant.PARTY_TYPE_PROSPECT_ACCOUNT.equalsIgnoreCase(fetchedRecCollObj.getParty_type())){
							Map<String,String> ucnMap = getMdmHierarchyView(partyRowId.trim());	
							String globalFlag = ucnMap.get("GLB_FLG");
							String singleSiteFlag = "";
							String mdmParentUcn = "";
							String mdmParentName = "";
							String ucn = Util.isNullOrEmpty(fetchedRecCollObj.getUcn())?"":fetchedRecCollObj.getUcn();
							String glbParentUcn = ucnMap.get("MFE_GLBL_PARENT_UCN");
							String subParentUcn = ucnMap.get("MFE_SUBS_PARENT_UCN");
							String nextLvlParentUcn = ucnMap.get("MFE_NEXT_LVL_SUBS_PAR_UCN");
							LOG.info("glbParentUcn::"+glbParentUcn);
							LOG.info("subParentUcn::"+subParentUcn);
							LOG.info("nextLvlParentUcn::"+nextLvlParentUcn);
							if(ucn.equalsIgnoreCase(subParentUcn)){
								mdmParentUcn = nextLvlParentUcn;
								mdmParentName = ucnMap.get("MFE_NEXT_LVL_SUBS_PAR_NM");
							}else{
								mdmParentUcn = subParentUcn;
								mdmParentName = ucnMap.get("MFE_SUBS_PARENT_NM");
							}
							
							if(ucn.equalsIgnoreCase(glbParentUcn) && (Util.isNullOrEmpty(globalFlag)||"N".equalsIgnoreCase(globalFlag))){
								singleSiteFlag = "Y";
							}else{
								singleSiteFlag = "N";
							}
							
							PartyAccountRelationshipXrefType partyAccRelparam = new PartyAccountRelationshipXrefType();
							partyAccRelparam.setHIERARCHYTYPE(Constant.Subsidiary_Hierarchy);
							if(!Util.isNullOrEmpty(subParentUcn) || !Util.isNullOrEmpty(nextLvlParentUcn)){
								partyAccRelparam.setMDMPARENTUCN(mdmParentUcn);
								partyAccRelparam.setMDMPARENTNAME(mdmParentName);
								partyAccRelparam.setMDMGLBPARENTUCN(glbParentUcn);
								partyAccRelparam.setMDMGLBPARENTNAME(ucnMap.get("MFE_GLBL_PARENT_NM"));
								partyAccRelparam.setSINGLESITEFLAG(singleSiteFlag);
							}else{
								partyAccRelparam.setMDMPARENTUCN(ucn);
								partyAccRelparam.setMDMPARENTNAME(searchedRecCollObj.getParty_name());
								partyAccRelparam.setMDMGLBPARENTUCN(ucn);
								partyAccRelparam.setMDMGLBPARENTNAME(searchedRecCollObj.getParty_name());
								partyAccRelparam.setSINGLESITEFLAG("Y");
							}
							partyRel.getPARTYACCOUNTREL().add(partyAccRelparam);
							}
						//Added for as part of Adobe integration - <END>
						party.setPartyRel(partyRel);
						/** Modified for M4M END */
						CanonicalFormManipulator.setDefaultValueInXrefAttributes(party);
						
						if(party.getAccount()!=null && party.getAccount().size()>0){
							if(Util.isNullOrEmpty(party.getAccount().get(0).getACCTNAME())){
								party.getAccount().clear();
							}
						}
						if(party.getAddress()!=null && party.getAddress().size()>0){
							if(Util.isNullOrEmpty(party.getAddress().get(0).getADDRTYPE())){
								party.getAddress().clear();
							}
						}
						if(party.getCommunication()!=null && party.getCommunication().size()>0){
							if(Util.isNullOrEmpty(party.getCommunication().get(0).getCOMMTYPE())){
								party.getCommunication().clear();
							}
						}
						if(party.getClassification()!=null && party.getClassification().size()>0){
							if(Util.isNullOrEmpty(party.getClassification().get(0).getCLASSIFICTNTYPE())){
								party.getClassification().clear();
							}
						}
						if(party.getPartyOrgExt()!=null && party.getPartyOrgExt().size()>0){
							if(Util.isNullOrEmpty(party.getPartyOrgExt().get(0).getROWIDORGEXTN())){
								party.getPartyOrgExt().clear();
							}
						}
						
						if(party.getPartyPersonExt()!=null && party.getPartyPersonExt().size()>0){
							if(Util.isNullOrEmpty(party.getPartyPersonExt().get(0).getPERSONTYPE())){
								party.getPartyPersonExt().clear();
							}
						}
						
						if(party.getPartyPerson()!=null && party.getPartyPerson().size()>0){
							if(Util.isNullOrEmpty(party.getPartyPerson().get(0).getFIRSTNAME())){
								party.getPartyPerson().clear();
							}
						}
						
						/*if(party.getPartyRel()!=null){
							if(party.getPartyRel().getPARTYACCOUNTREL()!=null && party.getPartyRel().getPARTYACCOUNTREL().size()>0){
								if(Util.isNullOrEmpty(party.getPartyRel().getPARTYACCOUNTREL().get(0).getHIERARCHYTYPE())){
									party.getPartyRel().getPARTYACCOUNTREL().clear();
								}
							}
							if(party.getPartyRel().getPARTYPERSONREL()!=null && party.getPartyRel().getPARTYPERSONREL().size()>0){
								if(Util.isNullOrEmpty(party.getPartyRel().getPARTYPERSONREL().get(0).getHIERARCHYTYPE())){
									party.getPartyRel().getPARTYPERSONREL().clear();
								}
							}
						}*/
						
						partyXrefList.add(party);
					}
				}
				partyXrefMap.put(mapEntry.getKey(), partyXrefList);
			}


			LOG.info("Number of party xref canonical format created = " + partyXrefMap.size());
		} catch (SQLException sqlEx) {
			LOG.error("SQLException occurred while retrieving party details from resultset: ", sqlEx);
			//sqlEx.printStackTrace();
		}catch(ServiceProcessingException se){
			
			if(se.getMessage().contains(Constant.DB_CONN_FAILURE)){
				throw se;
			}
			
		}catch (Exception excp) {
			LOG.error("Exception occurred while creating party canonical format from resultset: ", excp);
			//excp.printStackTrace();
		}

		LOG.info("Executed createXrefCanonicalFormMultipleParty()");
		return partyXrefMap;
	}


	//Method to get Relationship details from MDM_HIERARCHY_VIEW
	private List<Map<String,String>> getMdmHierarchyDenormView(List<String> srcSystemList) {
		LOG.debug("Inside getMdmHierarchyDenormView");
		Connection jdbcConn = null;
		Statement statement = null;
		ResultSet resultSet = null;
		JDBCConnectionProvider jDBCConnectionProvider =  null;
		Map<String,String> ucnMap = null;
		List<Map<String,String>> mapList = new ArrayList<Map<String,String>>();
		StringBuilder strList = new StringBuilder();

		String sql = "SELECT MDM_PARENT_UCN, MDM_DOM_PARENT_UCN, MDM_GLOBAL_PARENT_UCN, HIERARCHY_TYPE, RELATIONSHIP_TYPE, ROWID_RELATIONSHIP FROM MDM_HIERARCHY_DENORM_VIEW where SOURCE_SYSTEM_ID in (";
		try{
			jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
			jdbcConn = jDBCConnectionProvider.getJdbcConnectionFromDS();
			statement = jdbcConn.createStatement();
			strList.append(sql);

			for(String str: srcSystemList)	{
				strList.append("'" + str + "',");
			}
			strList.deleteCharAt(strList.length() - 1);
			strList.append(")");

			resultSet = statement.executeQuery(strList.toString());
			LOG.debug("SQL query to execute is: " + strList);

			while (resultSet.next()) {

				ucnMap = new HashMap<String,String>();
				ucnMap.put("MDM_PARENT_UCN",resultSet.getString(1));
				ucnMap.put("MDM_DOM_PARENT_UCN",resultSet.getString(2));
				ucnMap.put("MDM_GLOBAL_PARENT_UCN",resultSet.getString(3));
				ucnMap.put("HIERARCHY_TYPE", resultSet.getString(4));
				ucnMap.put("RELATIONSHIP_TYPE", resultSet.getString(5));
				ucnMap.put("ROWID_RELATIONSHIP", resultSet.getString(6));
		//		LOG.debug("ROWID_RELATIONSHIP" + ucnMap.get("ROWID_RELATIONSHIP"));

				LOG.debug("Adding 1 DenormView Record  to UcnMapList.");
				mapList.add(ucnMap);
			}
		} catch(SQLException exp)	{
			LOG.error("Caught SQLexception in getMdmHierarchyDenormView():" , exp);
		} catch (ServiceProcessingException servexp) {

			LOG.error("Caught ServiceProcessingException in getMdmHierarchyDenormView():" , servexp);
		}
			finally	{
				try {
						//Closing connections
						if (resultSet != null)  resultSet.close();
						if (statement != null) statement.close();
						if (jdbcConn != null) jdbcConn.close();

					} catch (SQLException sqlexp) {
						LOG.error("SQL excpetion in getMdmHierarchyDenormView():" , sqlexp);
					}
			}
		LOG.debug("Executed getMdmHierarchyDenormView()");
		return mapList;
	}

	//Track2 start
	private String validateInput(PartySearchCriteriaType partyCriteria, String hierarchyType ){
		
		String errorrMessage = null;
		
		//All parameters should not be present in same request
		if(!Util.isNullOrEmpty(partyCriteria.getPARTYNAME()) && !Util.isNullOrEmpty(partyCriteria.getADDRLN1()) 
				&& !Util.isNullOrEmpty(partyCriteria.getUCN()) && !Util.isNullOrEmpty(partyCriteria.getSRCSYSTEMID())) {
			LOG.info("Party Name ,Address Line 1, UCN OR Source system id should not be present in same request.");
			errorrMessage = Constant.allAccntSearchParameterNotNull;
		}
				
		//Input parameters empty
		if(Util.isNullOrEmpty(partyCriteria.getUCN()) && Util.isNullOrEmpty(partyCriteria.getSRCSYSTEMID()) && 
				(Util.isNullOrEmpty(partyCriteria.getCOUNTRYCD()) && Util.isNullOrEmpty(partyCriteria.getPARTYNAME()))){
			LOG.debug("No minimum search criteria present");
			errorrMessage = Constant.allAccntSearchParameterNull;
		}
		if (!Util.isNullOrEmpty(partyCriteria.getSRCSYSTEMID())) {
			if (Util.isNullOrEmpty(partyCriteria.getSRCSYSTEM())) {
				LOG.debug("Source system name is required for source system id");
				errorrMessage = Constant.srcSysCantbeNull;
			}
		} 
		if (!Util.isNullOrEmpty(partyCriteria.getPARTYNAME())) {
			if (Util.isNullOrEmpty(partyCriteria.getCOUNTRYCD())) {
				if(!"Partner Reseller Hierarchy".equalsIgnoreCase(hierarchyType)){
					LOG.debug("Country is required for party Name");
					errorrMessage = Constant.countryCantbeNull;
				}
			}
		}
		//Both Customer_Group & Party_Type Cannot be provided as input
		if(!(Util.isNullOrEmpty(partyCriteria.getCUSTGROUP()) || Util.isNullOrEmpty(partyCriteria.getPARTYTYPE()))) {
			LOG.debug("Both Customer_Group & Party_Type have been provided in FuzzySearch criteria");
			errorrMessage = Constant.bothCustGrpAndPartyTypeCantbeGiven;
		}
		if(!Util.isNullOrEmpty(partyCriteria.getPARTYTYPE())){
			LOG.info("Party Type ::"+ partyCriteria.getPARTYTYPE());
			String partyType=partyCriteria.getPARTYTYPE();
		if ( partyType.equalsIgnoreCase("Customer") || partyType.equalsIgnoreCase("Partner")
				|| partyType.equalsIgnoreCase("Reseller") || partyType.equalsIgnoreCase("Distributor")
				|| partyType.equalsIgnoreCase("Prospect Customer") ) {
		
			LOG.info("The supplied PARTY_TYPE is  within range");
		}else{
			
			LOG.info("The supplied PARTY_TYPE is not within range -> ('Customer','Partner','Reseller','Distributor','Prospect Customer')");
			errorrMessage = Constant.invalidPartyType;	
		}
		}
		return errorrMessage;
	}
	
	//Method For Fuzzy Match
	public SearchPartyHierarchyResponse processHierarchyFuzzySearchRequest(
			SearchPartyHierarchyRequest parameters) throws ServiceProcessingException {
		
		LOG.info("Executing processHierarchyFuzzySearchRequest()");
		SearchPartyHierarchyResponse searchPartyMasterResponse = new SearchPartyHierarchyResponse();
		PartySearchCriteriaType partyCriteria = parameters.getPartySearchCriteria();
		int minMatchScoreThres = 0;
		int mtchScoreValue = 0;	
		String searchType = null;
		MatchType matchType = null;
		String srcSystemName = null;
		List<PartyHierarchyProfileType> partyHierarchyProfileTypeList =  new ArrayList<PartyHierarchyProfileType>();
		Map<String, Integer> recordHierarchyMap = new HashMap<String, Integer>();
		Map<String, Map<String,Integer>> recordHierarchyMapWithPtyType = new HashMap<String, Map<String,Integer>> ();
		try{
						
			String message = validateInput(partyCriteria,parameters.getHierarchyType());
			
			if(!Util.isNullOrEmpty(message)){
				searchPartyMasterResponse.setErrorMsg(message);
				return searchPartyMasterResponse;
			}
			String sourceSystemId = parameters.getPartySearchCriteria().getSRCSYSTEMID();
			srcSystemName = parameters.getPartySearchCriteria().getSRCSYSTEM();
			LOG.info("sourceName processHierarchyFuzzySearchRequest" +srcSystemName );
			if(!Util.isNullOrEmpty(parameters.getPartySearchCriteria().getUCN()))
			{	
				if(!Util.isNullOrEmpty(parameters.getPartySearchCriteria().getPARTYNAME()) || !Util.isNullOrEmpty(parameters.getPartySearchCriteria().getADDRLN1()) 
						|| !Util.isNullOrEmpty(parameters.getPartySearchCriteria().getSRCSYSTEMID()) || !Util.isNullOrEmpty(parameters.getPartySearchCriteria().getCOUNTRYCD())) {
					LOG.info("For UCN search base. Name, address, country code OR system id should not be present in same request.");
					
					searchPartyMasterResponse.setErrorMsg("For UCN search , Name, address, country code OR system id should not be present in same request.");
					return searchPartyMasterResponse;
				} else {
					
					recordHierarchyMap = processUCNSearchRequest(parameters.getPartySearchCriteria().getUCN());
					
					if(recordHierarchyMap != null && recordHierarchyMap.size() > 0){
						LOG.info("Adding record in PARTY list ");
						recordHierarchyMapWithPtyType.put("PARTY", recordHierarchyMap);
					}else{
						recordHierarchyMap = processUCNSearchRequestInPtyGrp(parameters.getPartySearchCriteria().getUCN());
						if(recordHierarchyMap != null && recordHierarchyMap.size() > 0){
							LOG.info("Adding record in PARTY GROUP list ");
							recordHierarchyMapWithPtyType.put("PARTY_GROUP", recordHierarchyMap);
						}						
					}
				}				
			}
			else if(!Util.isNullOrEmpty(sourceSystemId))	{
				if(!Util.isNullOrEmpty(parameters.getPartySearchCriteria().getPARTYNAME()) || !Util.isNullOrEmpty(parameters.getPartySearchCriteria().getADDRLN1()) 
						|| !Util.isNullOrEmpty(parameters.getPartySearchCriteria().getCOUNTRYCD())) {
					LOG.info("For Source System Id search base. Name, address, country code OR UCN should not be present in same request.");
					searchPartyMasterResponse.setErrorMsg("For Source System Id search , Name, address, country code OR UCN should not be present in same request.");
					return searchPartyMasterResponse;
				}
				//call Fuzzy search operation using SIF
				recordHierarchyMap = processSourceIdSearchRequest(sourceSystemId, srcSystemName); // src sys Id call
				if(recordHierarchyMap != null && recordHierarchyMap.size() > 0){
					recordHierarchyMapWithPtyType.put("PARTY", recordHierarchyMap);
				}
			}	
			else {
				
				recordHierarchyMap = processAccountFuzzySearch(parameters);   // name and address call
				if(recordHierarchyMap != null && recordHierarchyMap.size() > 0){
					LOG.info("Adding record in PARTY list ");
					recordHierarchyMapWithPtyType.put("PARTY", recordHierarchyMap);
				}else{
					recordHierarchyMap = processParentPartnerAccountFuzzySearch(parameters);
					if(recordHierarchyMap != null && recordHierarchyMap.size() > 0){
						LOG.info("Adding record in PARTY GROUP list ");
						recordHierarchyMapWithPtyType.put("PARTY_GROUP", recordHierarchyMap);
					}						
				}
			}
		}catch(Exception e){
			LOG.info("Exception occured while processing search:"+e.getStackTrace());
			e.printStackTrace();
			
		}
		try{
			String hierarchyType = parameters.getHierarchyType();			
			if(recordHierarchyMapWithPtyType.size() == 0) {				
				searchPartyMasterResponse.setStatus(Constant.noRecordFound);
				return searchPartyMasterResponse;
			}else {
				HierarchyFuzzySearch = true;
				if("McAfee Hierarchy".equalsIgnoreCase(hierarchyType)){
					LOG.info("Executing McAfee Hierarchy search");
					processCustomerHierarchySearch(recordHierarchyMapWithPtyType,srcSystemName,partyHierarchyProfileTypeList);
				}else if("Partner Reseller Hierarchy".equalsIgnoreCase(hierarchyType)){
					LOG.info("Executing Partner Reseller Hierarchy search");
					processPartnerHierarchySearch(recordHierarchyMapWithPtyType,srcSystemName,partyHierarchyProfileTypeList);
				}
				
				Map<String, Integer> partyMapWithScore = recordHierarchyMapWithPtyType.get("PARTY");
				if(partyHierarchyProfileTypeList.size() > 0) {
					Iterator<PartyHierarchyProfileType> partyHierarchyProfileTypeIterator = partyHierarchyProfileTypeList.iterator();
					while(partyHierarchyProfileTypeIterator.hasNext()){
						PartyHierarchyProfileType artyHierarchyProfileType = partyHierarchyProfileTypeIterator.next();
						List<PartyProfileType> partyProfileTypeList = artyHierarchyProfileType.getPartyProfile();
						LOG.info(" Setting the match score :Adding party profile Type form List:: ");
						for(PartyProfileType partyProfileType : partyProfileTypeList){		
							
							LOG.info("partyMapWithScore "+partyMapWithScore);
							if(null != partyMapWithScore){							
								String rowidObject = partyProfileType.getGoldenCopy().getParty().getROWIDOBJECT();										
								Integer maxScore = partyMapWithScore.get(rowidObject.trim());
								LOG.info(" Setting score:: "+maxScore);
								if(maxScore != null && maxScore.intValue() > 0)
									partyProfileType.getGoldenCopy().setMatchScore(maxScore);
							}							
							
						}
						searchPartyMasterResponse.getPartyHierarchyProfile().add(artyHierarchyProfileType);
					}
					LOG.info("SearchPartyHierarchyResponse was Ready :: ");
				}	
			}
			
	
		}catch(Exception e){
			e.printStackTrace();
			LOG.info("Exception occured while processing response:"+e.getMessage());
			
			
		}	
		int partyHierarchyProfileSize = searchPartyMasterResponse.getPartyHierarchyProfile().size();		
		if(partyHierarchyProfileSize != 0) {
			searchPartyMasterResponse.setStatus(partyHierarchyProfileSize + " Hierarchy Profile successfully found!");
			searchPartyMasterResponse.setErrorMsg("");
		}else{
			searchPartyMasterResponse.setStatus(Constant.noRecordFound);
		}
		LOG.info("Executed processHierarchyFuzzySearchRequest()");
		return searchPartyMasterResponse;
	}
	
	
	//end track-2
	
	
	//Start track 3 changes
	private void processCustomerHierarchySearch(Map<String,Map<String, Integer>> recordHierarchyMapWithPtyType, String srcSystemName,List<PartyHierarchyProfileType> partyHierarchyProfileTypeList) throws ServiceProcessingException{
		
		//code (Hierarchy search) starts here:	
		
		
		Map<String, Integer> recordHierarchyMap = recordHierarchyMapWithPtyType.get("PARTY");
		Set<String> rowidObjects =  recordHierarchyMap.keySet();
		List<String> listOfGUCN = null;
		Map<String, List<HierarchyNode>> GucnPartiesMap = null;
		if(rowidObjects.size() > 0) {
			listOfGUCN = getGucn(rowidObjects);
			LOG.info(" Rowid Objects object are found to get GUCNs ::");
		}
		if(listOfGUCN.size() > 0) {
			LOG.info(" get Parties for GUCNs ::"+listOfGUCN.size());
			GucnPartiesMap = getListOfParties(listOfGUCN);
			
		} 	
		LOG.info("Party map size "+GucnPartiesMap.size());
		
		Set<String> keySet = GucnPartiesMap.keySet();
		Iterator<String> gucnPartiesIterator = keySet.iterator();
		while(gucnPartiesIterator.hasNext()) {
			
			List<String> rowidObjectList = new ArrayList<String>();
			PartyHierarchyProfileType partyHierarchyProfileType =  new PartyHierarchyProfileType();
			String Gucnkey = gucnPartiesIterator.next();
			List<HierarchyNode> parties = GucnPartiesMap.get(Gucnkey);
			Iterator<HierarchyNode> partiesIterator = parties.iterator();
			//Set<String> partiesSet = new  TreeSet<String>();
			LOG.info(" GUCN ::" + Gucnkey  +" and it's parties. ");
			String mfeGlblParentName = "";
			String mfeGlblParentUcn = "";
			HierarchyFuzzySearch = true;
			while(partiesIterator.hasNext()) {
				HierarchyNode partiesObjs = partiesIterator.next();
				rowidObjectList.add(partiesObjs.getRowidParty());
				mfeGlblParentName = partiesObjs.getMfeGlblParentName();
				mfeGlblParentUcn = partiesObjs.getMfeGlblParentUcn();
				
			}
			LOG.info(" ==> mfeGlblParentUcn == " + mfeGlblParentUcn + " Global Party Name == " + mfeGlblParentName);
			int iStartIndex = 0;
			int iEndIndex = 0;
			
			int iTotalSize = rowidObjectList.size();
			if(iTotalSize > 100){
				LOG.info("Total party size is more than 100");								
					while((iEndIndex + 1)  < iTotalSize){					
						iStartIndex = iEndIndex ;				
						if(iTotalSize - iEndIndex > 100)
							iEndIndex = iStartIndex + 100 ;
						else
							iEndIndex = iTotalSize;	
						
					List<String> subList = rowidObjectList.subList(iStartIndex, iEndIndex);	
					SearchPartyResponse searchPartyResponse = getAllHierarchyPartyGoldenRecords(subList, srcSystemName);					
					//SearchPartyResponse searchPartyResponse1 = getAllHierarchyPartyGoldenRecords(recordMap.keySet(), srcSystemName);
					if(searchPartyResponse != null && 
							searchPartyResponse.getPartyProfile()!= null &&
							searchPartyResponse.getPartyProfile().size() > 0) {
						LOG.info(" SearchPartyResponse received :: ");
						
						List<PartyProfileType> partyProfileTypeList = searchPartyResponse.getPartyProfile();
						
						partyHierarchyProfileType.setMDMGlobalParentName(mfeGlblParentName);
						partyHierarchyProfileType.setMDMGlobalParentUCN(mfeGlblParentUcn);
						LOG.info(" partyProfileTypeList:: "+ partyProfileTypeList.size());
						LOG.info(" Adding party profile Type form List:: ");
						for(PartyProfileType partyProfileType : partyProfileTypeList){					
							LOG.info("recordHierarchyMap "+recordHierarchyMap);
							if(null != recordHierarchyMap){
							
								String rowidObject = partyProfileType.getGoldenCopy().getParty().getROWIDOBJECT();										
								Integer maxScore = recordHierarchyMap.get(rowidObject.trim());
								LOG.info(" Setting score:: "+maxScore);
								if(maxScore != null && maxScore.intValue() > 0)
									partyProfileType.getGoldenCopy().setMatchScore(maxScore);
							}
							
							partyHierarchyProfileType.getPartyProfile().add(partyProfileType);
						}
						
					}						
				
				}	
													
			}else{
				SearchPartyResponse searchPartyResponse = getAllHierarchyPartyGoldenRecords(rowidObjectList, srcSystemName);					
				//SearchPartyResponse searchPartyResponse1 = getAllHierarchyPartyGoldenRecords(recordMap.keySet(), srcSystemName);
				if(searchPartyResponse != null && 
						searchPartyResponse.getPartyProfile()!= null &&
						searchPartyResponse.getPartyProfile().size() > 0) {
					LOG.info(" SearchPartyResponse received :: ");
					List<PartyProfileType> partyProfileTypeList = searchPartyResponse.getPartyProfile();
					
					partyHierarchyProfileType.setMDMGlobalParentName(mfeGlblParentName);
					partyHierarchyProfileType.setMDMGlobalParentUCN(mfeGlblParentUcn);
					LOG.info(" partyProfileTypeList:: "+ partyProfileTypeList.size());
					LOG.info(" Adding party profile Type form List:: ");
					for(PartyProfileType partyProfileType : partyProfileTypeList){					
						
						if(null != recordHierarchyMap){
						
							String rowidObject = partyProfileType.getGoldenCopy().getParty().getROWIDOBJECT();
							
							Integer maxScore = recordHierarchyMap.get(rowidObject.trim());
							LOG.info(" Setting score:: "+maxScore);
							if(maxScore != null && maxScore.intValue() > 0)
								partyProfileType.getGoldenCopy().setMatchScore(maxScore);
						}
						
						partyHierarchyProfileType.getPartyProfile().add(partyProfileType);
					}
				}						
			
			}
			if(partyHierarchyProfileType.getPartyProfile().size()>0){
				partyHierarchyProfileTypeList.add(partyHierarchyProfileType);
			}
			LOG.info(" Adding in partyHierarchyProfileTypeList size :: "+partyHierarchyProfileTypeList.size());
			LOG.info("partyHierarchyProfileType was build :: ");
		}
		
	}
	
	
	//Start track 3 changes
	private void processPartnerHierarchySearch(Map<String,Map<String, Integer>> recordHierarchyMapWithPtyType, String srcSystemName,List<PartyHierarchyProfileType> partyHierarchyProfileTypeList) throws ServiceProcessingException{
		
		//code (Hierarchy search) starts here:	
		List<String> listOfWWUCN = null;
		List<String> listOfParentWWUCN = null;
		Set<String> listOfUCN = new  TreeSet<String>();
		//List<String> listOfUCN = new ArrayList<String>();
		Map<String, List<HierarchyNode>> GucnPartiesMap = null;
		Map<String, Integer> recordHierarchyMap = recordHierarchyMapWithPtyType.get("PARTY");
		
		if(null != recordHierarchyMap && recordHierarchyMap.size() > 0 ){
			Set<String> rowidObjects =  recordHierarchyMap.keySet();		
			if(rowidObjects.size() > 0) {	
				long startTime=System.currentTimeMillis();
				listOfWWUCN = getWWucnForPartner(rowidObjects);
				long endTime=System.currentTimeMillis();
				LOG.info("Total Time in feteching WW UCN from Geo UCN -------:"+(endTime-startTime) ); 
				LOG.info("processPartnerHierarchySearch:: Rowid Objects object are found to get GUCNs ::");				
				if(listOfWWUCN != null && listOfWWUCN.size() > 0 ){					
					listOfUCN.addAll(listOfWWUCN);
				}
			}
		}
		
		//code (Hierarchy search) starts here:			
		recordHierarchyMap = recordHierarchyMapWithPtyType.get("PARTY_GROUP");
		if(null != recordHierarchyMap && recordHierarchyMap.size() > 0){
			Set<String> rowidObjectPtyGrp  =  recordHierarchyMap.keySet();		
			if(rowidObjectPtyGrp.size() > 0) {
				long startTime=System.currentTimeMillis();
				listOfParentWWUCN = getWWucnForParentPtr(rowidObjectPtyGrp);
				long endTime=System.currentTimeMillis();
				LOG.info("Total Time in feteching  UCN from party group -------:"+(endTime-startTime) ); 
				LOG.info("processPartnerHierarchySearch :: Rowid Objects object are found to get GUCNs for Party Group::");
				
				if(listOfParentWWUCN != null && listOfParentWWUCN.size() > 0 ){
					listOfUCN.addAll(listOfParentWWUCN);
				}
			}
		}
		
		
		if(listOfUCN != null && listOfUCN.size() > 0) {
			LOG.info(" get Parties for GUCNs ::"+listOfUCN.size());
			
			populatePartnerHierarchy(listOfUCN,partyHierarchyProfileTypeList,srcSystemName);		
			
		} 
	}
	
	
	private void populatePartnerHierarchy(Set<String> listOfParentWWUCN, List<PartyHierarchyProfileType> partyHierarchyProfileTypeList,String srsSystemName){
		
		Connection jdbcConnection = null;
		ResultSet resultSet = null;
		Statement statement = null;
	
		List<HierarchyProfile> hierarchyProfileList = new ArrayList<HierarchyProfile>();
		
	//	Iterator<String> wwUcnIterator = listOfParentWWUCN.iterator();
	//	while (wwUcnIterator.hasNext()) {
			/*String ucn = wwUcnIterator.next();			
			if(null == ucn){
				continue;
			}*/
			
			StringBuilder sqlQry = new StringBuilder();		
			sqlQry.append("select PTR_GLBL_PARENT_UCN,MFE_WW_PARENT_PRTN_NM,PTR_PARENT_NM,PTR_PARENT_UCN,ROWID_PARTY from C_B_PARTY_ORG_EXTN ORG,C_B_PARTY PTY where PTY.PARTY_TYPE <> 'Customer' AND PTY.ROWID_OBJECT = ORG.ROWID_PARTY AND PTR_GLBL_PARENT_UCN is not null AND PTR_GLBL_PARENT_UCN in (");
	
			for (String parentWWUCN : listOfParentWWUCN) {
				if (parentWWUCN != null) {
					sqlQry.append("'" + parentWWUCN + "',");
				}
			}
			sqlQry.deleteCharAt(sqlQry.length() - 1).toString();
			sqlQry.append(" )");
			LOG.info(" populatePartnerHierarchy::Query for List of partner UCN is :: " + sqlQry.toString());
			
			try {
				JDBCConnectionProvider jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
				jdbcConnection = jDBCConnectionProvider.getJdbcConnectionFromDS();
				statement = jdbcConnection.createStatement();	
				long startTime=System.currentTimeMillis();
				resultSet = statement.executeQuery(sqlQry.toString());
				long queryendTime=System.currentTimeMillis();
				LOG.info("Total Time in fetching  WW and Geo from Org extsn-------:"+(queryendTime-startTime) ); 
				PartyHierarchyProfileType herarchyProfileType = null;
				List<String> partyList = new ArrayList<String>();
				List<String> geoParentList = new ArrayList<String>();
				List<String> wwParentList = new ArrayList<String>();
				Map<String ,PartyHierarchyProfileType > partyHierarchyProfileTypeMap=new HashMap<String, PartyHierarchyProfileType>();
				Map<String ,List<String>> partyMap= new HashMap<String, List<String>>();
				PartyHierarchyProfileType partyHierarchyProfileType = null;
				
				while (resultSet.next()) {
					String wwUCN = resultSet.getString(1);
					String wwName = resultSet.getString(2);
					String geoName = resultSet.getString(3);
					String geoUcn = resultSet.getString(4);
					String rowidPartnerParty = resultSet.getString(5);
					
					if(!wwParentList.contains(wwUCN)){
						
						
						wwParentList.add(wwUCN);						
						herarchyProfileType = new PartyHierarchyProfileType();
						herarchyProfileType.setMDMGlobalParentName(wwName);
						herarchyProfileType.setMDMGlobalParentUCN(wwUCN);
						HierarchyProfile hierarchyProfileWW = new HierarchyProfile();
						hierarchyProfileWW.setUCN(wwUCN);
						hierarchyProfileWW.setName(wwName);	
						hierarchyProfileWW.setHierarchyLevel("Partner WW Parent");
						//hierarchyProfileList.add(hierarchyProfileWW);					
						herarchyProfileType.getHierarchyProfile().add(hierarchyProfileWW);
					}					
					if(!geoParentList.contains(geoUcn)){
						
						geoParentList.add(geoUcn);
						HierarchyProfile hierarchyProfileGeo= new HierarchyProfile();
						hierarchyProfileGeo.setUCN(geoUcn);
						String countryName = null;
						if(geoName != null){
							String[] arrGeoName = geoName.split("-");
							if(arrGeoName != null && arrGeoName.length > 1)
								countryName = arrGeoName[1];
						}
						hierarchyProfileGeo.setCountry(countryName);
						hierarchyProfileGeo.setName(geoName);	
						hierarchyProfileGeo.setHierarchyLevel("Partner Geo Parent");
						//hierarchyProfileList.add(hierarchyProfileGeo);
						herarchyProfileType.getHierarchyProfile().add(hierarchyProfileGeo);
					}
					if(!partyList.contains(rowidPartnerParty)){
						
						partyList.add(rowidPartnerParty);						
						if(!partyMap.containsKey(wwUCN)){
							LOG.info("Inside partymap create new party list for wwUCN");
							partyMap.put(wwUCN, new ArrayList<String>());
							partyMap.get(wwUCN).add(rowidPartnerParty);
							
						}else{
							LOG.info("Inside partymap update party list for wwUCN");
							partyMap.get(wwUCN).add(rowidPartnerParty);	
						}
					}					
					
					if(!partyHierarchyProfileTypeMap.containsKey(wwUCN)){
						LOG.info("Inside PartyHierarchyProfileTypeMap create new PartyHierarchyProfileType list for wwUCN");
						partyHierarchyProfileTypeMap.put(wwUCN,herarchyProfileType );
						
					}
				
				}
				long endTime=System.currentTimeMillis();
				LOG.info("Total Time in building WW and Geo from Org extsn-------:"+(endTime-startTime) ); 
				/*if(partyList.size() > 0){	
				SearchPartyResponse searchPartyResponse = getAllHierarchyPartyGoldenRecords(partyList, srsSystemName);
				herarchyProfileType.getPartyProfile().addAll(searchPartyResponse.getPartyProfile())  ;
				partyHierarchyProfileTypeList.add(herarchyProfileType);
				}*/
				
				if(partyMap.size()>0){
					Iterator<Map.Entry<String, List<String>>> it = partyMap.entrySet().iterator();
					long startTimePartyProfile=System.currentTimeMillis();
					while (it.hasNext()) {
						Map.Entry<String, List<String>> pair = it.next();
					    String key=pair.getKey();
					    LOG.info("fetech the details for wwUCN :: "+ key);
					    if(pair.getValue().size()>0){
					    	LOG.info("pair.getValue().size()>0 ");
					    SearchPartyResponse searchPartyResponse = getAllHierarchyPartyGoldenRecords(pair.getValue(), srsSystemName);
					    	LOG.info("got searchPartyResponse ");
					    if(partyHierarchyProfileTypeMap.size()>0 && partyHierarchyProfileTypeMap.containsKey(key)){
					    	LOG.info("inside partyHierarchyProfileTypeMap if block ");
					    	partyHierarchyProfileType = new PartyHierarchyProfileType();
					    	partyHierarchyProfileType= partyHierarchyProfileTypeMap.get(key);
					    	partyHierarchyProfileType.getPartyProfile().addAll(searchPartyResponse.getPartyProfile());
					    	partyHierarchyProfileTypeList.add(partyHierarchyProfileType);
					    	LOG.info("inside partyHierarchyProfileTypeMap if block ::end");
					    }
					    }
					}
					long endTimePartyProfile=System.currentTimeMillis();
					LOG.info("Total Time in building party profile for global WW UCN -------:"+(endTimePartyProfile-startTimePartyProfile) ); 
				}
				
			}catch (ServiceProcessingException serviceEx) {
				LOG.error("Exception: Unable to create JDBC connection from datasource: for populatePartnerHierarchy: " + serviceEx);
			} catch (SQLException sqlEx) {
				LOG.error("Exception occurred in populatePartnerHierarchy: "	+ sqlEx);
				sqlEx.printStackTrace();
			} finally {
				try {
					if (resultSet != null)
						resultSet.close();
					if (statement != null)
						statement.close();
					if (jdbcConnection != null)
						jdbcConnection.close();
				} catch (SQLException sqlEx) {
					LOG.error("Sql Exception occurred in populatePartnerHierarchy : " + sqlEx);
				}
			}		
		
		//}		
	
	}
	
	
	public Map<String, Integer>  processAccountFuzzySearch(SearchPartyHierarchyRequest parameters) throws ServiceProcessingException{
		
		SiperianClient siperianClient = null;
		SearchMatchRequest searchMatchRequest = null;
		SearchMatchResponse searchMatchResponse = null;
		String searchType = null;
		MatchType matchType = null;
		String srcSystemName = null;

		if(!Util.isNullOrEmpty(parameters.getSearchType()))	{
			searchType = parameters.getSearchType();
		}
		
		/* changes for Sales Force Integration -Start */
		if( !Util.isNullOrEmpty(parameters.getPartySearchCriteria().getSRCSYSTEM()) )	{
			LOG.info("srcSystemName" + srcSystemName);
			srcSystemName = parameters.getPartySearchCriteria().getSRCSYSTEM();
		}
		
		PartySearchCriteriaType partyCriteria = parameters.getPartySearchCriteria();
		String matchScoreThresIp = parameters.getMatchScoreThresold();
		int minMatchScoreThres = 0;
		int mtchScoreValue = 0;
		Integer recCountThresIp = 0;
		String countryName = null ;

		if(!Util.isNullOrEmpty(partyCriteria.getCOUNTRYCD())){
			countryName = getCL_SIP_POP(partyCriteria.getCOUNTRYCD());
		}

		if (parameters.getRecordCountThresold() != null && parameters.getRecordCountThresold().length() > 0) {
			 recCountThresIp = Integer.parseInt(parameters.getRecordCountThresold());
		}
		int recCntThres = 0;
		String searchRuleSet = null;

		//Setting MatchScoreThreshold
		if(matchScoreThresIp != null && matchScoreThresIp.length() > 0)		{
			//Taking User entered value from SearchPartyRequest
			minMatchScoreThres = Integer.parseInt(matchScoreThresIp);
		} else {
			//Taking Default value from Configuration File
			minMatchScoreThres = Integer.parseInt(matchScoreThresDef);
		}

		LOG.debug("Setting MatchScoreThreshold: " + minMatchScoreThres);

		//Setting RecordsToReturnCount
		if(recCountThresIp != null && recCountThresIp.intValue() != 0)	{
			recCntThres = recCountThresIp;
		} else  {
			recCntThres = recCountThresDef;
		}

		LOG.debug("Setting RecordsToReturnCount: " + recCntThres);

		//Automated or Manual RuleSet based on SearchType
		if(Util.isNullOrEmpty(searchType) || searchType.equalsIgnoreCase("Auto"))	{
			searchRuleSet = configProps.getProperty("autoSearchRuleSet");
			matchType = MatchType.AUTO;
		} else {
			searchRuleSet = configProps.getProperty("manualSearchRuleSet");
			matchType = MatchType.AUTO;
		}

		searchMatchRequest = new SearchMatchRequest();
		searchMatchRequest.setRecordsToReturn(recCntThres); // Required
		searchMatchRequest.setSiperianObjectUid("PKG_PARTY_HIERARCHY_SEARCH");
		//searchMatchRequest.setSiperianObjectUid("PKG_PARTY_FUZZY_SEARCH");

		searchMatchRequest.setMatchRuleSetUid(SiperianObjectType.MATCH_RULE_SET.makeUid(searchRuleSet));
		searchMatchRequest.setMatchType(MatchType.BOTH);

		LOG.info("Match Rule Set: " + searchMatchRequest.getMatchRuleSetUid());
		LOG.info("Match Type :" + searchMatchRequest.getMatchType());

		// Setting Oraganization_Name
		Field field_name = new Field("Organization_Name");
		if (!Util.isNullOrEmpty(partyCriteria.getPARTYNAME())) {
			field_name.setStringValue(partyCriteria.getPARTYNAME());
			LOG.info("Field to search for :" + field_name.getName() + ':' + field_name.getStringValue());
			searchMatchRequest.addMatchColumnField(field_name);
		}		
		

		// Setting Address_Part1
		Field field_addr1 = new Field("Address_Part1");
		StringBuilder addrLn1Ln2Concat = new StringBuilder();
		if (!Util.isNullOrEmpty(partyCriteria.getADDRLN1())) {
			addrLn1Ln2Concat.append(partyCriteria.getADDRLN1());

		}
		if (!Util.isNullOrEmpty(partyCriteria.getADDRLN2())) {
			addrLn1Ln2Concat.append(" ");
			addrLn1Ln2Concat.append(partyCriteria.getADDRLN2());
		}
		if (addrLn1Ln2Concat != null && addrLn1Ln2Concat.length() > 1) {
			field_addr1.setStringValue(addrLn1Ln2Concat.toString());
			searchMatchRequest.addMatchColumnField(field_addr1);
		}
		LOG.info("Field to search for :" + field_addr1.getName() + ':' + field_addr1.getStringValue());

  		// Setting Address_Part2
		Field addr_part2 = new Field("Address_Part2");
		StringBuilder addrCityStateCountryConcat = new StringBuilder();
		if (!(Util.isNullOrEmpty(partyCriteria.getCITY()) || "Unknown".equalsIgnoreCase(partyCriteria.getCITY()))) {
			addrCityStateCountryConcat.append(partyCriteria.getCITY());


		}
		if (!Util.isNullOrEmpty(partyCriteria.getSTATECD()))	{
			addrCityStateCountryConcat.append(" ");
			addrCityStateCountryConcat.append(partyCriteria.getSTATECD());
		}

		if (!Util.isNullOrEmpty(partyCriteria.getCOUNTRYCD()))	{
			addrCityStateCountryConcat.append(" ");
			addrCityStateCountryConcat.append(partyCriteria.getCOUNTRYCD());
			Field field_SIPPOP = new Field("SIP_POP");
			field_SIPPOP.setStringValue(countryName);
			searchMatchRequest.addMatchColumnField(field_SIPPOP);
			LOG.info("Field to match for :" + field_SIPPOP.getName() + ':' + field_SIPPOP.getStringValue());
		}

	
		if (addrCityStateCountryConcat != null && addrCityStateCountryConcat.length() > 1) {
			addr_part2.setStringValue(addrCityStateCountryConcat.toString());
			searchMatchRequest.addMatchColumnField(addr_part2);
		}
		LOG.info("Field to search for :" + addr_part2.getName() + ':' + addr_part2.getStringValue());

		StringBuffer criteria = createFilterCriteria(parameters);
		searchMatchRequest.setFilterCriteria(criteria.toString());
		try {
			siperianClient = (SiperianClient) checkOut();

			LOG.info("processing SearchMatchRequest");
			LOG.info("before request");
			long startTime=System.currentTimeMillis();
			LOG.info("searchMatchRequest FilterCriteria ::" + searchMatchRequest.getFilterCriteria());
			searchMatchResponse = (SearchMatchResponse) siperianClient.process(searchMatchRequest);
			LOG.info("after response");
			long endTime=System.currentTimeMillis();
			LOG.info("Total Time in search match on Party -------:"+(endTime-startTime) ); 
			List searchRecords = searchMatchResponse.getRecords();
			
			LOG.info("searchMatchResponse Message = " + searchMatchResponse.getMessage());
			LOG.info("searchMatchResponse RecordCount = " + searchMatchResponse.getRecordCount());
			if (searchRecords != null && searchRecords.size() != 0) {
				for (Iterator iter = searchRecords.iterator(); iter
						.hasNext();) {
					Record record = (Record) iter.next();
					// Calculate Highest Match Score
					// LOG.debug("Match Score :"+ record.getField("MATCH_SCORE").getValue());
					String mtchScore = record.getField("MATCH_SCORE").getValue().toString().trim();
					String trimmedPartyRowId = record.getField("ROWID_OBJECT").getStringValue().trim();
					// int key = Integer.parseInt(trimmedKey);
					mtchScoreValue = Integer.parseInt(mtchScore);
					LOG.info("rowid_object :" + trimmedPartyRowId+ " scoreValue :" + mtchScoreValue);
					if(mtchScoreValue >= minMatchScoreThres)	{
						//Process only those records with matchScore > minMatchScoreThres
						recordMap.put(trimmedPartyRowId, mtchScoreValue);
					}else {
						LOG.debug("Match Score value for Party: " + trimmedPartyRowId + " is lesser than MinThreshold Value: " + minMatchScoreThres);
					}
				}
			}			
			
		} catch (SiperianServerException sifExcp) {
			
			LOG.error("SiperianServerException occured while processing SearchMatchRequest: " + sifExcp);
			LOG.error("Get Message: "+ sifExcp.getMessage());
			ServiceProcessingException customException = new ServiceProcessingException(sifExcp.getMessage());
			customException.setRootExceptionMsg(sifExcp + " SearchMatch operation failed for Party_Name: "+ partyCriteria.getPARTYNAME());			
			customException.setMessage("SIF exception occured while processing SearchMatch request for Party. ");
			throw customException;
		} catch (Exception exp) {
			
			LOG.error("Exception occured while processing SearchMatchRequest: " + exp);
			LOG.error("SearchMatch Exeption :" + exp.getMessage());
			ServiceProcessingException customException = new ServiceProcessingException(exp);
			customException.setRootExceptionMsg(exp + " SearchMatch operation failed for Party_Name: "+ partyCriteria.getPARTYNAME());			
			customException.setMessage("SIF exception occured while processing SearchMatch request for Party.");
			throw customException;
		} finally {
			checkIn(siperianClient);
		}
		//}
		
		return recordMap;
		
	}
	
	
	public Map<String, Integer>  processParentPartnerAccountFuzzySearch(SearchPartyHierarchyRequest parameters) throws ServiceProcessingException{
		
		
		LOG.debug("========processParentPartnerAccountFuzzySearch======= ");
		SiperianClient siperianClient = null;
		SearchMatchRequest searchMatchRequest = null;
		SearchMatchResponse searchMatchResponse = null;
		String searchType = null;
		MatchType matchType = null;
		String srcSystemName = null;

		if(!Util.isNullOrEmpty(parameters.getSearchType()))	{
			searchType = parameters.getSearchType();
		}
		
		/* changes for Sales Force Integration -Start */
		if( !Util.isNullOrEmpty(parameters.getPartySearchCriteria().getSRCSYSTEM()) )	{
			LOG.info("srcSystemName" + srcSystemName);
			srcSystemName = parameters.getPartySearchCriteria().getSRCSYSTEM();
		}
		
		PartySearchCriteriaType partyCriteria = parameters.getPartySearchCriteria();
		String matchScoreThresIp = parameters.getMatchScoreThresold();
		int minMatchScoreThres = 0;
		int mtchScoreValue = 0;
		Integer recCountThresIp = 0;
		String countryName = null ;

		if(!Util.isNullOrEmpty(partyCriteria.getCOUNTRYCD())){
			countryName = getCL_SIP_POP(partyCriteria.getCOUNTRYCD());
		}

		if (parameters.getRecordCountThresold() != null && parameters.getRecordCountThresold().length() > 0) {
			 recCountThresIp = Integer.parseInt(parameters.getRecordCountThresold());
		}
		int recCntThres = 0;
		String searchRuleSet = null;

		//Setting MatchScoreThreshold
		if(matchScoreThresIp != null && matchScoreThresIp.length() > 0)		{
			//Taking User entered value from SearchPartyRequest
			minMatchScoreThres = Integer.parseInt(matchScoreThresIp);
		} else {
			//Taking Default value from Configuration File
			minMatchScoreThres = Integer.parseInt(matchScoreThresDef);
		}

		LOG.debug("processParentPartnerAccountFuzzySearch::Setting MatchScoreThreshold: " + minMatchScoreThres);

		//Setting RecordsToReturnCount
		if(recCountThresIp != null && recCountThresIp.intValue() != 0)	{
			recCntThres = recCountThresIp;
		} else  {
			recCntThres = recCountThresDef;
		}

		LOG.debug("processParentPartnerAccountFuzzySearch::Setting RecordsToReturnCount: " + recCntThres);

		//Automated or Manual RuleSet based on SearchType
		/*if(Util.isNullOrEmpty(searchType) || searchType.equalsIgnoreCase("Auto"))	{
			searchRuleSet = configProps.getProperty("autoSearchRuleSet");
			matchType = MatchType.AUTO;
		} else {
			searchRuleSet = configProps.getProperty("manualSearchRuleSet");
			matchType = MatchType.BOTH;
		}*/
		
		searchMatchRequest = new SearchMatchRequest();
		
		searchMatchRequest.setRecordsToReturn(recCntThres); // Required
		searchMatchRequest.setSiperianObjectUid("C_B_PARTY_GROUP");
		//searchMatchRequest.setSiperianObjectUid("PKG_PARTY_FUZZY_SEARCH");
		StringBuffer criteria = new StringBuffer();
		criteria.append("HUB_STATE_IND= 1 and BO_CLASS_CODE in ('Partner WW Parent' , 'Partner Geo Parent')");
		searchMatchRequest.setFilterCriteria(criteria.toString());
		searchMatchRequest.setMatchRuleSetUid(SiperianObjectType.MATCH_RULE_SET.makeUid("Party Group Search Ruleset"));
		searchMatchRequest.setMatchType(MatchType.BOTH);

		LOG.info("processParentPartnerAccountFuzzySearch::Match Rule Set: " + searchMatchRequest.getMatchRuleSetUid());
		LOG.info("processParentPartnerAccountFuzzySearch::Match Type :" + searchMatchRequest.getMatchType());


		// Setting Oraganization_Name
		Field field_name = new Field("Organization_Name");
		if (!Util.isNullOrEmpty(partyCriteria.getPARTYNAME())) {
			field_name.setStringValue(partyCriteria.getPARTYNAME());
			LOG.info("Field to search for :" + field_name.getName() + ':' + field_name.getStringValue());
			searchMatchRequest.addMatchColumnField(field_name);
		}		
		try {
			siperianClient = (SiperianClient) checkOut();

			LOG.info("processParentPartnerAccountFuzzySearch::processing SearchMatchRequest");
			LOG.info("processParentPartnerAccountFuzzySearch::before request");
			LOG.info("searchMatchRequest FilterCriteria ::" + searchMatchRequest.getFilterCriteria());
			long startTime=System.currentTimeMillis();
			searchMatchResponse = (SearchMatchResponse) siperianClient.process(searchMatchRequest);
			long endTime=System.currentTimeMillis();
			LOG.info("Total Time in searchMatchResponse party group name-------:"+(endTime-startTime) ); 
			LOG.info("after response");
			List searchRecords = searchMatchResponse.getRecords();
			LOG.info("searchMatchResponse Message = " + searchMatchResponse.getMessage());
			LOG.info("searchMatchResponse RecordCount = " + searchMatchResponse.getRecordCount());
			if (searchRecords != null && searchRecords.size() != 0) {
				for (Iterator iter = searchRecords.iterator(); iter
						.hasNext();) {
					Record record = (Record) iter.next();
					// Calculate Highest Match Score
					// LOG.debug("Match Score :"+ record.getField("MATCH_SCORE").getValue());
					String mtchScore = record.getField("MATCH_SCORE").getValue().toString().trim();
					String trimmedPartyRowId = record.getField("ROWID_OBJECT").getStringValue().trim();
					// int key = Integer.parseInt(trimmedKey);
					mtchScoreValue = Integer.parseInt(mtchScore);
					LOG.info("rowid_object :" + trimmedPartyRowId+ " scoreValue :" + mtchScoreValue);
					if(mtchScoreValue >= minMatchScoreThres)	{
						//Process only those records with matchScore > minMatchScoreThres
						recordMap.put(trimmedPartyRowId, mtchScoreValue);
					}else {
						LOG.debug("processParentPartnerAccountFuzzySearch::Match Score value for Party Group: " + trimmedPartyRowId + " is lesser than MinThreshold Value: " + minMatchScoreThres);
					}
				}
			}
		} catch (SiperianServerException sifExcp) {
			LOG.error("SiperianServerException occured while processing processParentPartnerAccountFuzzySearch: " + sifExcp);
			LOG.error("Get Message: "+ sifExcp.getMessage());
			ServiceProcessingException customException = new ServiceProcessingException(sifExcp.getMessage());
			customException.setRootExceptionMsg(sifExcp + " processParentPartnerAccountFuzzySearch operation failed for Party_Name: "+ partyCriteria.getPARTYNAME());			
			customException.setMessage("SIF exception occured while processing SearchMatch request for Party. ");
			throw customException;
		} catch (Exception exp) {
			LOG.error("Exception occured while processing processParentPartnerAccountFuzzySearch: " + exp);
			LOG.error("SearchMatch Exeption :" + exp.getMessage());
			ServiceProcessingException customException = new ServiceProcessingException(exp);
			customException.setRootExceptionMsg(exp + " SearchMatch operation failed for Party_Name: "+ partyCriteria.getPARTYNAME());			
			customException.setMessage("SIF exception occured while processing SearchMatch request for Party.");
			throw customException;
		} finally {
			checkIn(siperianClient);
		}	
		
		return recordMap;
		
	}
	
	
	private StringBuffer createFilterCriteria(SearchPartyHierarchyRequest parameters){

		String errorMessage = null;
		StringBuffer criteria = new StringBuffer();
		boolean firstParam = false;
		PartySearchCriteriaType partyCriteria = parameters.getPartySearchCriteria();
		LOG.info("Filter Criteria: " + criteria.toString());


		if (!Util.isNullOrEmpty(partyCriteria.getCOUNTRYCD())) {
			if (firstParam) {
				criteria.append(" AND UPPER(COUNTRY_CD) = UPPER('" + partyCriteria.getCOUNTRYCD() + "')");

			} else {
				firstParam = true;
				criteria.append(" UPPER(COUNTRY_CD) = UPPER('" + partyCriteria.getCOUNTRYCD() + "')");
			}		
			
		}

		/*if (!Util.isNullOrEmpty(partyCriteria.getUCN())) {
		if (firstParam)
			criteria.append(" AND UCN='"+ partyCriteria.getUCN() + "'");
		else {
			firstParam = true;
			criteria.append(" UCN='"+ partyCriteria.getUCN() + "'");
		}
		}*/	
		//Adding CUST_GROUP to filter criteria...
		if (!Util.isNullOrEmpty(partyCriteria.getCUSTGROUP())) {
			if (firstParam)	{
				if(partyCriteria.getCUSTGROUP().equalsIgnoreCase(custGrpPayer) )	{
					criteria.append(" AND (PARTY_TYPE ='"+ configProps.getProperty("Payer") + "'");
				}
				if(partyCriteria.getCUSTGROUP().equalsIgnoreCase(custGrpBill) )	{
					criteria.append(" AND (PARTY_TYPE ='"+ configProps.getProperty("Bill-to_party") + "'");
				}
				if(partyCriteria.getCUSTGROUP().equalsIgnoreCase(custGrpSold) )	{
					criteria.append(" AND (PARTY_TYPE ='"+ configProps.getProperty("Sold-to_party") + "'");
				}
				if(partyCriteria.getCUSTGROUP().equalsIgnoreCase(custGrpShip) )	{
					criteria.append(" AND (PARTY_TYPE ='"+ configProps.getProperty("Ship-to_party") + "'");
				}
				if(partyCriteria.getCUSTGROUP().equalsIgnoreCase(custGrpDist) )	{
					criteria.append(" AND (PARTY_TYPE ='"+ configProps.getProperty("Distributor-SP/SH/BP/PY/ZD/ZE") + "'");
				}
				if(partyCriteria.getCUSTGROUP().equalsIgnoreCase(custGrpEnd) )	{
					criteria.append(" AND (PARTY_TYPE ='"+ configProps.getProperty("End_User") + "'");
				}
				if(partyCriteria.getCUSTGROUP().equalsIgnoreCase(custGrpRes) )	{
					criteria.append(" AND (PARTY_TYPE ='"+ configProps.getProperty("Reseller") + "'");
				}
				if(partyCriteria.getCUSTGROUP().equalsIgnoreCase(custGrpOPA) )	{
					criteria.append(" AND (PARTY_TYPE ='"+ configProps.getProperty("OPA_Created_by_UserId") + "'");
				}
				if(partyCriteria.getCUSTGROUP().equalsIgnoreCase(custGrpPartner) )	{
					criteria.append(" AND (PARTY_TYPE ='"+ configProps.getProperty("Partner") + "'");
				}
		//		if(partyCriteria.getCUSTGROUP().equalsIgnoreCase(custGrpProsPartner) )	{
		//			criteria.append(" AND (PARTY_TYPE ='"+ configProps.getProperty("Prospective_Partner") + "'");
		//		}
				criteria.append(" OR PARTY_TYPE IS NULL)");

			} else {
				firstParam = true;
				if(partyCriteria.getCUSTGROUP().equalsIgnoreCase(custGrpPayer) )	{
					criteria.append(" (PARTY_TYPE ='"+ configProps.getProperty("Payer") + "'");
				}
				if(partyCriteria.getCUSTGROUP().equalsIgnoreCase(custGrpBill) )	{
					criteria.append(" (PARTY_TYPE ='"+ configProps.getProperty("Bill-to_party") + "'");
				}
				if(partyCriteria.getCUSTGROUP().equalsIgnoreCase(custGrpSold) )	{
					criteria.append(" (PARTY_TYPE ='"+ configProps.getProperty("Sold-to_party") + "'");
				}
				if(partyCriteria.getCUSTGROUP().equalsIgnoreCase(custGrpShip) )	{
					criteria.append(" (PARTY_TYPE ='"+ configProps.getProperty("Ship-to_party") + "'");
				}
				if(partyCriteria.getCUSTGROUP().equalsIgnoreCase(custGrpDist) )	{
					criteria.append(" (PARTY_TYPE ='"+ configProps.getProperty("Distributor-SP/SH/BP/PY/ZD/ZE") + "'");
				}
				if(partyCriteria.getCUSTGROUP().equalsIgnoreCase(custGrpEnd) )	{
					criteria.append(" (PARTY_TYPE ='"+ configProps.getProperty("End_User") + "'");
				}
				if(partyCriteria.getCUSTGROUP().equalsIgnoreCase(custGrpRes) )	{
					criteria.append(" (PARTY_TYPE ='"+ configProps.getProperty("Reseller") + "'");
				}
				if(partyCriteria.getCUSTGROUP().equalsIgnoreCase(custGrpOPA) )	{
					criteria.append(" (PARTY_TYPE ='"+ configProps.getProperty("OPA_Created_by_UserId") + "'");
				}
				if(partyCriteria.getCUSTGROUP().equalsIgnoreCase(custGrpPartner) )	{
					criteria.append(" (PARTY_TYPE ='"+ configProps.getProperty("Partner") + "'");
				}
		//		if(partyCriteria.getCUSTGROUP().equalsIgnoreCase(custGrpProsPartner) )	{
		//			criteria.append(" (PARTY_TYPE ='"+ configProps.getProperty("Prospective_Partner") + "'");
		//		}
				criteria.append(" OR PARTY_TYPE IS NULL)");
			}
		}

		//Adding PARTY_TYPE to Filter Criteria...
		if( Util.isNullOrEmpty(partyCriteria.getPARTYTYPE()) && Util.isNullOrEmpty(partyCriteria.getCUSTGROUP()) )	{

			LOG.info("Both PARTY_TYPE & CUSTOMER_GROUP are provided as NULL hence adding filter: PARTY_TYPE in ('Customer','Partner','Reseller','Distributor','Prospect Customer')");
		
			if (firstParam)	{
				criteria.append(" AND PARTY_TYPE in ('Customer','Partner','Reseller','Distributor','Prospect Customer')");
	
			} else {
				firstParam = true;
				criteria.append(" PARTY_TYPE in ('Customer','Partner','Reseller','Distributor','Prospect Customer')");
		
			}
		} else if (!Util.isNullOrEmpty(partyCriteria.getPARTYTYPE()) && (partyCriteria.getPARTYTYPE().equalsIgnoreCase("Customer") || partyCriteria.getPARTYTYPE().equalsIgnoreCase("Partner")
				|| partyCriteria.getPARTYTYPE().equalsIgnoreCase("Reseller") || partyCriteria.getPARTYTYPE().equalsIgnoreCase("Distributor")
				|| partyCriteria.getPARTYTYPE().equalsIgnoreCase("Prospect Customer")) ) {

			LOG.info("PARTY_TYPE input value is: " + partyCriteria.getPARTYTYPE());
			if (firstParam)	{
				criteria.append(" AND UPPER(PARTY_TYPE) = UPPER('" + partyCriteria.getPARTYTYPE() + "')");
			} else {
				firstParam = true;
				criteria.append(" UPPER(PARTY_TYPE) = UPPER('" + partyCriteria.getPARTYTYPE() + "')");
			}
		} 


		if (firstParam)	{
			criteria.append(" AND BO_CLASS_CODE = '" + "Organization" + "'");
		} else {
			firstParam = true;
			criteria.append(" BO_CLASS_CODE = '" + "Organization" + "'");
		}

		//Removing Soft-Deleted Records from Search
		if (firstParam) {
			criteria.append(" AND HUB_STATE_IND !='" + -1 + "'");
		} else {
			firstParam = true;
			criteria.append(" HUB_STATE_IND !='" + -1 + "'");
		}

		//Fetching Active Records from Search
		if (firstParam) {
			criteria.append(" AND STATUS_CD ='" + "A" + "'");
		} else {
			firstParam = true;
			criteria.append(" STATUS_CD ='" + "A" + "'");
		}
		
		return criteria;
	 }

	public Map<String, Integer>  processUCNSearchRequest(String ucn) {
		// TODO Auto-generated method stub
	
		Map<String, PartyType> goldenRecMap = null;
		Statement statement = null;
		StringBuilder sqlQry = new StringBuilder();
	//	String rowid_object = null;
		Connection jdbcConnection = null;
		ResultSet resultSet = null;
		String srcSystemName = null;
		SearchPartyHierarchyResponse searchPartyMasterResponse = new SearchPartyHierarchyResponse();
		Map<String, Integer> searchedRecords = new HashMap<String, Integer>();
		
		try {

			JDBCConnectionProvider jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();

			if ( !Util.isNullOrEmpty(ucn))	{

				LOG.info("Fetching Golden copy for survivorRowID: " + ucn);

				sqlQry.append("SELECT ROWID_OBJECT FROM C_B_PARTY WHERE UCN = ('" + ucn + "')");

				sqlQry.append(" AND HUB_STATE_IND = '" + 1 + "'");
				sqlQry.append(" AND STATUS_CD = '" + "A" + "'");
				sqlQry.append(" AND BO_CLASS_CODE = '" + "Organization" + "'");
				sqlQry.append(" AND PARTY_TYPE in ('" + "Customer'," + "'Partner'," + "'Reseller'," + "'Prospect Customer'," + "'Distributor" + "')");

				LOG.debug("Query to fetch getGoldenRecforID: " + sqlQry);


				jdbcConnection = jDBCConnectionProvider.getJdbcConnectionFromDS();
			//	jdbcConnection = JdbcConn.GetJdbcConnObject();
				statement = jdbcConnection.createStatement();
				resultSet = statement.executeQuery(sqlQry.toString());
				
				while(resultSet.next()){
					searchedRecords.put(resultSet.getString(1), 100);
				}
				
			}			

		} catch (SQLException sqlEx) {
			LOG.error("Exception in getGoldenRecforID() for ID based Search: " , sqlEx);
			ServiceProcessingException customException = new ServiceProcessingException(sqlEx);
			customException.setMessage("Failed to fetch Party profile from ORS." + customException.getMessage());
		//	throw customException;
		} catch (ServiceProcessingException sqlEx) {
			LOG.error("Exception in getGoldenRecforID() for ID based Search: " , sqlEx);
			ServiceProcessingException customException = new ServiceProcessingException(sqlEx);
			customException.setMessage("Failed to fetch Party profile from ORS." + customException.getMessage());
		//	throw customException;
		}	finally {
			try {
					if( resultSet != null)	resultSet.close();
					if( statement != null) statement.close();
					if(jdbcConnection != null) jdbcConnection.close();
				} catch (SQLException e) {

					LOG.debug("Caught SQLException in getGoldenRecforID: " , e);
				}
		}

	
		return searchedRecords;
	}
	
	public Map<String, Integer>  processUCNSearchRequestInPtyGrp(String ucn) {
		// TODO Auto-generated method stub	
		Statement statement = null;
		StringBuilder sqlQry = new StringBuilder();
		//String rowid_object = null;
		Connection jdbcConnection = null;
		ResultSet resultSet = null;
	
		Map<String, Integer> searchedRecords = new HashMap<String, Integer>();
		
		try {

			JDBCConnectionProvider jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();

			if ( !Util.isNullOrEmpty(ucn))	{

				LOG.info("Fetching Golden copy for survivorRowID: " + ucn);

				sqlQry.append("SELECT ROWID_OBJECT, ENTITY_TYPE_DESC FROM C_B_PARTY_GROUP WHERE UCN = ('" + ucn + "')");

				sqlQry.append(" AND HUB_STATE_IND = '" + 1 + "'");
				
				sqlQry.append(" AND BO_CLASS_CODE  in ('Partner WW Parent','Partner Geo Parent')");
				

				LOG.debug("Query to fetch getGoldenRecforID: " + sqlQry);
				

				jdbcConnection = jDBCConnectionProvider.getJdbcConnectionFromDS();
				//jdbcConnection = JdbcConn.GetJdbcConnObject();
				statement = jdbcConnection.createStatement();
				resultSet = statement.executeQuery(sqlQry.toString());	
				
				while(resultSet.next()){
					
					searchedRecords.put(resultSet.getString(1), 100);
				}
			}

		} catch (SQLException sqlEx) {
			LOG.error("Exception in getGoldenRecforID() for ID based Search: " , sqlEx);
			ServiceProcessingException customException = new ServiceProcessingException(sqlEx);
			customException.setMessage("Failed to fetch Party profile from ORS." + customException.getMessage());
		//	throw customException;
		} catch (ServiceProcessingException sqlEx) {
			LOG.error("Exception in getGoldenRecforID() for ID based Search: " , sqlEx);
			ServiceProcessingException customException = new ServiceProcessingException(sqlEx);
			customException.setMessage("Failed to fetch Party profile from ORS." + customException.getMessage());
		//	throw customException;
		}	finally {
			try {
					if( resultSet != null)	resultSet.close();
					if( statement != null) statement.close();
					if(jdbcConnection != null) jdbcConnection.close();
				} catch (SQLException e) {

					LOG.debug("Caught SQLException in getGoldenRecforID: " , e);
				}
		}

	
		return searchedRecords;
	}
	
	/**
	 * ::==> added
	 * @param rowidObjectSet
	 * @param srcSystemName
	 * @return
	 * @throws ServiceProcessingException
	 */
	public SearchPartyResponse  getAllHierarchyPartyGoldenRecords(List<String> rowidObjectList,String srcSystemName) throws ServiceProcessingException {
		LOG.info("Executing getAllPartyGolden()");

		SearchPartyResponse searchPartyMasterResp = null;
		if(!rowidObjectList.isEmpty()){
			PreparedStatement pstmt = null;
			Statement statement = null;
			StringBuilder sqlQry = new StringBuilder();
			JDBCConnectionProvider jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
			Connection jdbcConnection = null;
			ResultSet resultSet = null;

			try {
				LOG.info("Fetching Golden copies for rowidObjectSet: " + rowidObjectList);
				jdbcConnection = jDBCConnectionProvider.getJdbcConnectionFromDS();
				//	jdbcConnection = JdbcConn.GetJdbcConnObject();
				//	jdbcConnection.setAutoCommit(false);
				statement = jdbcConnection.createStatement();
				//sqlQry.append("SELECT * FROM PKG_PARTY_JMS_MQ_PUB WHERE ROWID_OBJECT in (");
				sqlQry.append("SELECT * FROM PKG_BO_FOR_HIERARCHY_SEARCH WHERE ROWID_OBJECT in (");

				for (String partyRowId : rowidObjectList) {
					sqlQry.append("'" + partyRowId + "',");
				}
				sqlQry.deleteCharAt(sqlQry.length() - 1).toString();
				sqlQry.append(") AND HUB_STATE_IND <> -1 ");
				sqlQry.append(" AND STATUS_CD = 'A'");
				sqlQry.append(" AND BO_CLASS_CODE = 'Organization'");
				sqlQry.append(" AND PARTY_TYPE in ('Customer','Partner','Reseller','Distributor','Prospect Customer')");
				sqlQry.append(" AND EXISTS (SELECT 1 FROM C_B_ACCOUNT_XREF WHERE C_B_ACCOUNT_XREF.ROWID_OBJECT=ROWID_ACCOUNT AND NVL(DRAFT_FLG,'N')='N')");
				sqlQry.append(" and Exists (select 1 from c_b_party_xref where c_b_party_xref.status_cd = 'A' and c_b_party_xref.ROWID_SYSTEM IN ('SAP','SBL','SFC','FNO','ADB') and c_b_party_xref.rowid_object = rowid_object)");
				/*Modified for MDMP-3093: Fuzzy Search look up issue:: START*/
				sqlQry.append("AND nvl(trunc(END_DATE),'31-DEC-9999') = '31-DEC-9999'");
				sqlQry.append(" AND NVL(ADDR_HUB_STATE_IND,1)  = 1");
				sqlQry.append(" AND NVL(COMM_HUB_STATE_IND,1)  = 1");
				sqlQry.append(" AND NVL(ORG_EXTN_HUB_STATE_IND,1)  = 1");
				sqlQry.append(" AND NVL(CLASSIFCTN_HUB_STATE_IND,1)  = 1");
				//sqlQry.append(" AND NVL(REL_HUB_STATE_IND,1)  = 1");
		
				LOG.debug("Query to fetch partyGoldenMap: " + sqlQry);


				
				resultSet = statement.executeQuery(sqlQry.toString());
				searchPartyMasterResp = createGoldenCopyFuzzySearch(resultSet,srcSystemName);
				
		/*		pstmt = jdbcConnection.prepareStatement(sqlQry.toString());
				for (String partyRowId : rowidObjectSet) {
					pstmt.setString(1, partyRowId);
					pstmt.addBatch();
				}
				
				resultSet = pstmt.executeQuery();
				searchPartyMasterResp = createGoldenCopyFuzzySearch(resultSet);
		 */
			} catch (SQLException sqlEx) {
				LOG.error("Exception occurred in getAllPartyGolden while fetching Party profile: " + sqlEx);
				sqlEx.printStackTrace();
				ServiceProcessingException customException = new ServiceProcessingException(sqlEx);
				customException.setMessage("Failed to fetch Party profile from ORS." + customException.getMessage());
				throw customException;
			} finally {
					try {
						if( resultSet != null) resultSet.close();
						if( pstmt != null) pstmt.close();
						if( statement != null) statement.close();
						if(jdbcConnection != null) jdbcConnection.close();
					} catch (SQLException e) {
						LOG.error("Sql Exception occurred in getAllPartyGolden : " + e);
						//e.printStackTrace();
					}
			}

		}
		
		LOG.info("Executed getAllPartyGolden()");		
		return searchPartyMasterResp;
}
		
		/**
		 * 
		 * @param rowid_object
		 * @return List of GUCN records for party rowID
		 */
	public List<String> getGucn(Set<String> rowidObject) {
		long startTime=System.currentTimeMillis();
		LOG.info(" Fetching the GUCN records for party rowID ::");
		Connection jdbcConnection = null;
		ResultSet resultSet = null;
		Statement statement = null;
		List<String> GUCN = new ArrayList<String>();
		StringBuilder sqlQry = new StringBuilder();
		//sqlQry.append("select MFE_GLBL_PARENT_UCN  from C_B_PARTY_ORG_EXTN where rowid_object in (");
		//sqlQry.append("select MFE_GLBL_PARENT_UCN from C_B_PARTY_ORG_EXTN where rowid_party in (");
		sqlQry.append("select MFE_GLBL_PARENT_UCN, rowid_party from C_B_PARTY_ORG_EXTN where rowid_party in (");
		Iterator<String> rowidIterator = rowidObject.iterator();
		while (rowidIterator.hasNext()) {
			String rowid = rowidIterator.next();
			sqlQry.append("'" + rowid + "',");
		}
		sqlQry.deleteCharAt(sqlQry.length() - 1).toString();
		sqlQry.append(")");
		LOG.info(" Query for List of GUCN is :: " + sqlQry.toString());
		try {
			JDBCConnectionProvider jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
			jdbcConnection = jDBCConnectionProvider.getJdbcConnectionFromDS();
			statement = jdbcConnection.createStatement();
			resultSet = statement.executeQuery(sqlQry.toString());
			while (resultSet.next()) {
				GUCN.add(resultSet.getString(1));
				//gucnMatchScore.put(resultSet.getString(1), resultSet.getString(2));
			}
		} catch (ServiceProcessingException serviceEx) {
			LOG.error("Exception: Unable to create JDBC connection from datasource: for GUCN list. " + serviceEx);
		} catch (SQLException sqlEx) {
			LOG.error("Exception occurred in getGucn(-) while fetching GUCN list: "	+ sqlEx);
			sqlEx.printStackTrace();
		} finally {
			try {
				if (resultSet != null)
					resultSet.close();
				if (statement != null)
					statement.close();
				if (jdbcConnection != null)
					jdbcConnection.close();
			} catch (SQLException sqlEx) {
				LOG.error("Sql Exception occurred in getAllPartyGolden : " + sqlEx);
			}
		}
		LOG.info(" List of GUCN :: " + GUCN);
		LOG.info(" List of GUCN & it't rowid obj for match score. :: " + gucnMatchScore+" "+(System.currentTimeMillis())+" ms");
		return GUCN;
	}
	
	
	
	
	
	private List<String> getGlobalUCN(Set<String> rowidObject) {
		long startTime=System.currentTimeMillis();
		LOG.info(" Fetching the GUCN records for party rowID ::");
		Connection jdbcConnection = null;
		ResultSet resultSet = null;
		Statement statement = null;
		List<String> GUCN = new ArrayList<String>();
		StringBuilder sqlQry = new StringBuilder();
		//sqlQry.append("select MFE_GLBL_PARENT_UCN  from C_B_PARTY_ORG_EXTN where rowid_object in (");
		//sqlQry.append("select MFE_GLBL_PARENT_UCN from C_B_PARTY_ORG_EXTN where rowid_party in (");
		sqlQry.append("select MFE_GLBL_PARENT_UCN, rowid_party from C_B_PARTY_ORG_EXTN where hub_state_ind=1 and rowid_party in (");
		Iterator<String> rowidIterator = rowidObject.iterator();
		while (rowidIterator.hasNext()) {
			String rowid = rowidIterator.next();
			sqlQry.append("'" + rowid + "',");
		}
		sqlQry.deleteCharAt(sqlQry.length() - 1).toString();
		sqlQry.append(")");
		LOG.info(" Query for List of GUCN is :: " + sqlQry.toString());
		try {
			JDBCConnectionProvider jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
			jdbcConnection = jDBCConnectionProvider.getJdbcConnectionFromDS();
			statement = jdbcConnection.createStatement();
			resultSet = statement.executeQuery(sqlQry.toString());
			while (resultSet.next()) {
				GUCN.add(resultSet.getString(1));
				//gucnMatchScore.put(resultSet.getString(1), resultSet.getString(2));
			}
		} catch (ServiceProcessingException serviceEx) {
			LOG.error("Exception: Unable to create JDBC connection from datasource: for GUCN list. " + serviceEx);
		} catch (SQLException sqlEx) {
			LOG.error("Exception occurred in getGucn(-) while fetching GUCN list: "	+ sqlEx);
			sqlEx.printStackTrace();
		} finally {
			try {
				if (resultSet != null)
					resultSet.close();
				if (statement != null)
					statement.close();
				if (jdbcConnection != null)
					jdbcConnection.close();
			} catch (SQLException sqlEx) {
				LOG.error("Sql Exception occurred in getAllPartyGolden : " + sqlEx);
			}
		}
		LOG.info(" List of GUCN :: " + GUCN);
		LOG.info(" List of GUCN & it't rowid obj for match score. :: " + gucnMatchScore+" "+(System.currentTimeMillis())+" ms");
		return GUCN;
	}
	
	
	
	
	
	public List<String> getWWucnForPartner(Set<String> rowidObject) {
		
		LOG.info(" Fetching the WW UCN records for party rowID ::");
		Connection jdbcConnection = null;
		ResultSet resultSet = null;
		Statement statement = null;
		List<String> GUCN = new ArrayList<String>();
		StringBuilder sqlQry = new StringBuilder();
		//sqlQry.append("select MFE_GLBL_PARENT_UCN  from C_B_PARTY_ORG_EXTN where rowid_object in (");
		//sqlQry.append("select MFE_GLBL_PARENT_UCN from C_B_PARTY_ORG_EXTN where rowid_party in (");
		sqlQry.append("select distinct PTR_GLBL_PARENT_UCN from C_B_PARTY_ORG_EXTN where rowid_party in (");
		Iterator<String> rowidIterator = rowidObject.iterator();
		while (rowidIterator.hasNext()) {
			String rowid = rowidIterator.next();
			sqlQry.append("'" + rowid + "',");
		}
		sqlQry.deleteCharAt(sqlQry.length() - 1).toString();
		sqlQry.append(")");
		
		LOG.info(" Query for List of Global WW UCN is :: " + sqlQry.toString());
		try {
			JDBCConnectionProvider jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
			jdbcConnection = jDBCConnectionProvider.getJdbcConnectionFromDS();
			statement = jdbcConnection.createStatement();
			resultSet = statement.executeQuery(sqlQry.toString());
			while (resultSet.next()) {
				if(resultSet.getString(1) != null){
				GUCN.add(resultSet.getString(1));
				}
				//gucnMatchScore.put(resultSet.getString(1), resultSet.getString(2));
			}
		} catch (ServiceProcessingException serviceEx) {
			LOG.error("Exception: Unable to create JDBC connection from datasource: for GUCN list. " + serviceEx);
		} catch (SQLException sqlEx) {
			LOG.error("Exception occurred in getGucn(-) while fetching GUCN list: "	+ sqlEx);
			sqlEx.printStackTrace();
		} finally {
			try {
				if (resultSet != null)
					resultSet.close();
				if (statement != null)
					statement.close();
				if (jdbcConnection != null)
					jdbcConnection.close();
			} catch (SQLException sqlEx) {
				LOG.error("Sql Exception occurred in getAllPartyGolden : " + sqlEx);
			}
		}
		LOG.info(" List of GUCN :: " + GUCN);
		LOG.info(" List of GUCN & it't rowid obj for match score. :: " + gucnMatchScore);
		return GUCN;
	}
	
	
	
	public List<String> getWWucnForParentPtr(Set<String> rowidObject) {
		
		LOG.info(" getWWucnForParentPtr::Fetching the WW UCN records for party group rowID ::");
		Connection jdbcConnection = null;
		ResultSet resultSet = null;
		ResultSet resultSetGeo = null;
		
		Statement statement = null;
		List<String> GUCN = new ArrayList<String>();
		List<String> geoParentList = new ArrayList<String>();
		List<String> wwParentList = new ArrayList<String>();
		
		StringBuilder sqlQry = new StringBuilder();
		//sqlQry.append("select MFE_GLBL_PARENT_UCN  from C_B_PARTY_ORG_EXTN where rowid_object in (");
		//sqlQry.append("select MFE_GLBL_PARENT_UCN from C_B_PARTY_ORG_EXTN where rowid_party in (");
		sqlQry.append("select distinct UCN, ENTITY_TYPE_DESC from C_B_PARTY_GROUP where rowid_object in (");
		Iterator<String> rowidIterator = rowidObject.iterator();
		while (rowidIterator.hasNext()) {
			String rowid = rowidIterator.next();
			sqlQry.append("'" + rowid + "',");
		}
		sqlQry.deleteCharAt(sqlQry.length() - 1).toString();
		sqlQry.append(")");
		LOG.info("getWWucnForParentPtr:: Query for List of Geo/WW UCN is :: " + sqlQry.toString());
		try {
			JDBCConnectionProvider jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
			jdbcConnection = jDBCConnectionProvider.getJdbcConnectionFromDS();
			statement = jdbcConnection.createStatement();
			resultSet = statement.executeQuery(sqlQry.toString());
			LOG.info("getWWucnForParentPtr :: List of WW/Geo UCN retrieved ");
			while (resultSet.next()) {
				String ucn = resultSet.getString(1);
				String entiryTypeDesc = resultSet.getString(2);
				
				if("Partner Geo Parent".equalsIgnoreCase(entiryTypeDesc)){
					geoParentList.add(ucn);
				}else if("Partner WW Parent".equalsIgnoreCase(entiryTypeDesc)){
					wwParentList.add(ucn);
				}				
				//GUCN.add(resultSet.getString(1));
				//gucnMatchScore.put(resultSet.getString(1), resultSet.getString(2));
			}
			
			if(wwParentList.size() > 0){								
				GUCN.addAll(wwParentList);				
			}
			
			if(geoParentList.size() > 0){
				StringBuilder sqlQryGeo = new StringBuilder();
				sqlQryGeo.append("select distinct PTR_GLBL_PARENT_UCN  from C_B_PARTY_ORG_EXTN where PTR_GLBL_PARENT_UCN IS NOT NULL AND PTR_PARENT_UCN in (");
				
				
				Iterator<String> rowidIteratorGeo = geoParentList.iterator();
				while (rowidIteratorGeo.hasNext()) {
					String rowid = rowidIteratorGeo.next();
					sqlQryGeo.append("'" + rowid + "',");
				}
				sqlQryGeo.deleteCharAt(sqlQryGeo.length() - 1).toString();
				sqlQryGeo.append(")");
				LOG.info("getWWucnForParentPtr:: Query for List of Geo :: " + sqlQryGeo.toString());
				long startTime=System.currentTimeMillis();
				resultSetGeo = statement.executeQuery(sqlQryGeo.toString());
				while (resultSetGeo.next()) {					
								
					GUCN.add(resultSetGeo.getString(1));
					//gucnMatchScore.put(resultSet.getString(1), resultSet.getString(2));
				}
				long endTime=System.currentTimeMillis();
				LOG.info("Total Time in Preparing WW UCN list  -------:"+(endTime-startTime )); 
				
			}
			
				
			LOG.info("getWWucnForParentPtr:: Size of WW UCN list :: "+GUCN.size());
		} catch (ServiceProcessingException serviceEx) {
			LOG.error("getWWucnForParentPtr::Exception: Unable to create JDBC connection from datasource: for GUCN list. " + serviceEx);
		} catch (SQLException sqlEx) {
			LOG.error("getWWucnForParentPtr::Exception occurred in getGucn(-) while fetching GUCN list: "	+ sqlEx);
			sqlEx.printStackTrace();
		} finally {
			try {
				if (resultSet != null)
					resultSet.close();
				if (statement != null)
					statement.close();
				if (jdbcConnection != null)
					jdbcConnection.close();
			} catch (SQLException sqlEx) {
				LOG.error("Sql Exception occurred in getAllPartyGolden : " + sqlEx);
			}
		}
		LOG.info(" List of GUCN :: " + GUCN);
		LOG.info(" List of GUCN & it't rowid obj for match score. :: " + gucnMatchScore);
		return GUCN;
	}
	/**
	 * 
	 * @param listOfGUCN
	 * @return GUCN and it's parties list : [[Gucn1, [p1,p2,...]], [Gucn2, [p1,p2,...]],...] as a map.
	 */
	public Map<String, List<HierarchyNode>> getListOfParties(List<String> listOfGUCN) {	
		Iterator<String> GUCNs = listOfGUCN.iterator();		
		Connection jdbcConnection = null;
		ResultSet resultSet = null;
		Statement statement = null;
		List<HierarchyNode> listOfParties = null; 
		Map<String, List<HierarchyNode>> GucnPartiesMap = new HashMap<String, List<HierarchyNode>>();
		try {
			JDBCConnectionProvider jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
			jdbcConnection = jDBCConnectionProvider.getJdbcConnectionFromDS();
			statement = jdbcConnection.createStatement();
			// Query start			
			while (GUCNs.hasNext()) {
				listOfParties = new ArrayList<HierarchyNode>();
				StringBuilder sqlQry = new StringBuilder();
				sqlQry.append("select distinct a.rowid_party,a.MFE_GLBL_PARENT_NM , a.MFE_GLBL_PARENT_UCN from c_b_party_org_extn a where a.MFE_GLBL_PARENT_UCN in (");
				String GUCN = GUCNs.next();
				sqlQry.append("'" + GUCN + "')");
				LOG.info(" Query for List of parties is :: " + sqlQry.toString());
				resultSet = statement.executeQuery(sqlQry.toString());			
				HierarchyNode partiesObj = null;
				while (resultSet.next()) {
					partiesObj = new HierarchyNode();
					partiesObj.setRowidParty(resultSet.getString(1));
					partiesObj.setMfeGlblParentName(resultSet.getString(2));
					partiesObj.setMfeGlblParentUcn(resultSet.getString(3));					
					listOfParties.add(partiesObj);
					partiesObj = null;
				}
				sqlQry = null;						
				GucnPartiesMap.put(GUCN, listOfParties);
				
			}
		} catch (ServiceProcessingException serviceEx) {
			LOG.error("Exception: Unable to create JDBC connection from datasource: for GUCN list. " + serviceEx);
		} catch (SQLException sqlEx) {
			LOG.error("Exception occurred in getGucn(-) while fetching GUCN list: "	+ sqlEx);
			sqlEx.printStackTrace();
		} finally {
			try {
				if (resultSet != null)
					resultSet.close();
				if (statement != null)
					statement.close();
				if (jdbcConnection != null)
					jdbcConnection.close();
			} catch (SQLException sqlEx) {
				LOG.error("Sql Exception occurred in getAllPartyGolden : " + sqlEx);
			}
		}
		return GucnPartiesMap;
	}
	
	public List<GlobalHierarchyNode>  getGlobalHierarchy(String partyRowId)  throws SQLException{
		LOG.debug("Inside getGlobalHierarchy" );
		Connection jdbcConn = null;
		PreparedStatement pstatement = null;
		ResultSet resultSet = null;
		JDBCConnectionProvider jDBCConnectionProvider =  null;
		List<GlobalHierarchyNode> globalHierarchyList = new ArrayList<GlobalHierarchyNode>();
		String sql = "select * from PKG_PARTY_REL where rowid_object = ? and HIERARCHY_CODE IN ('McAfee Hierarchy','Partner Reseller Hierarchy') and REL_HUB_STATE_IND =1 and rownum < 2 ";
		
		try{
			jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
			jdbcConn = jDBCConnectionProvider.getJdbcConnectionFromDS();
			pstatement = jdbcConn.prepareStatement(sql);
			pstatement.setString(1, partyRowId);
			resultSet = pstatement.executeQuery();
			while (resultSet.next()) {
				GlobalHierarchyNode globalHierarchyNode = new GlobalHierarchyNode();
				globalHierarchyNode.setRowidObject(resultSet.getString(3));
				globalHierarchyNode.setPartyRelRowid(resultSet.getString(4));
				globalHierarchyNode.setParentPartyRowid(resultSet.getString(5));
				globalHierarchyNode.setHierarchyCode(resultSet.getString(6));
				globalHierarchyNode.setRelTypeCode(resultSet.getString(7));
				globalHierarchyList.add(globalHierarchyNode);
			}
		} catch(SQLException exp)	{
			LOG.error("Caught exception in getGlobalHierarchy()" + exp.getMessage());
		} catch (ServiceProcessingException e) {

			LOG.error("Caught exception in getGlobalHierarchy()" + e.getMessage());
		}
			finally	{
				//Closing connections
				if (resultSet != null)  resultSet.close();
				if (pstatement != null) pstatement.close();
				if (jdbcConn != null) jdbcConn.close();
			}
		LOG.info("Executed getGlobalHierarchy :: " + globalHierarchyList.size());		
		LOG.debug("Executed getGlobalHierarchy");
		return globalHierarchyList;	
	}
	
	//ID based hierarchy Search service 
		public Map<String, Integer> processSourceIdSearchRequest(String srcSysID, String srcSysName)	{
			LOG.info("Fetching Golden copy for survivorRowID includes Prospect Customer: " );
			Map<String, Integer> goldenRecMap = new HashMap<String, Integer>();
			Statement statement = null;
			StringBuilder sqlQry = new StringBuilder();
		//	String rowid_object = null;
			Connection jdbcConnection = null;
			ResultSet resultSet = null;
			try {

				JDBCConnectionProvider jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();

				rowid_object = getPartyRowidObject(srcSysID, srcSysName);
				if ( !Util.isNullOrEmpty(rowid_object))	{

					LOG.info("Fetching Golden copy for survivorRowID: " + rowid_object);
					sqlQry.append("SELECT ROWID_OBJECT FROM c_b_party WHERE ROWID_OBJECT in ('" + rowid_object + "')");
					//sqlQry.append("SELECT * FROM c_b_party WHERE ROWID_OBJECT in ('" + rowid_object + "')");

					sqlQry.append(" AND HUB_STATE_IND <> '" + -1 + "'");
					sqlQry.append(" AND STATUS_CD = '" + "A" + "'");
					sqlQry.append(" AND BO_CLASS_CODE = '" + "Organization" + "'");
					sqlQry.append(" AND PARTY_TYPE in ('" + "Customer'," + "'Partner'," + "'Reseller'," + "'Prospect Customer',"  + "'Distributor" + "')");

					LOG.debug("Query to fetch processSourceIdSearchRequest :: " + sqlQry);


					jdbcConnection = jDBCConnectionProvider.getJdbcConnectionFromDS();				
					statement = jdbcConnection.createStatement();
					resultSet = statement.executeQuery(sqlQry.toString());
					while(resultSet.next()) {
					String partyId = resultSet.getString("ROWID_OBJECT");
					goldenRecMap.put(partyId, 100);
					LOG.info("Prospect Customer srcSysID search :: " + goldenRecMap);
					}
				}

			} catch (SQLException sqlEx) {
				LOG.error("Exception in processSourceIdSearchRequest() for ID based Search: " , sqlEx);
				ServiceProcessingException customException = new ServiceProcessingException(sqlEx);
				customException.setMessage("Failed to fetch Party profile from ORS." + customException.getMessage());
			//	throw customException;
			} catch (ServiceProcessingException sqlEx) {
				LOG.error("Exception in processSourceIdSearchRequest() for ID based Search: " , sqlEx);
				ServiceProcessingException customException = new ServiceProcessingException(sqlEx);
				customException.setMessage("Failed to fetch Party profile from ORS." + customException.getMessage());
			//	throw customException;
			}	finally {
				try {
						if( resultSet != null)	resultSet.close();
						if( statement != null) statement.close();
						if(jdbcConnection != null) jdbcConnection.close();
					} catch (SQLException e) {

						LOG.debug("Caught SQLException in processSourceIdSearchRequest: " , e);
					}
			}
			return goldenRecMap;

		}
		
		public boolean checkActiveptnrHierExist(String rowidObject) throws ServiceProcessingException {
			LOG.info("Executing checkActiveptnrHierExist()");
			
			
			Statement statement = null;
			StringBuilder sqlQry = new StringBuilder();
			JDBCConnectionProvider jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();;
			Connection jdbcConnection = null;
			ResultSet resultSet = null;		
			int recordCount = 0;
			boolean hierExist = false;
			
			try {
				sqlQry.append(Constant.QUERY_GET_ACT_HIER_EXIST);
				sqlQry.append("'"+rowidObject + "'");
				jdbcConnection = jDBCConnectionProvider.getJdbcConnectionFromDS();
				statement = jdbcConnection.createStatement();
				resultSet = statement.executeQuery(sqlQry.toString());
					LOG.info("Query to fetch presence of partner Hierarchy Active record: " + sqlQry);

				
					while (resultSet.next()) {
						recordCount = resultSet.getInt(1);
						
					}	
					LOG.info("Record count with partner Hierarchy Active  = " + recordCount);
					if (recordCount > 0) {
						hierExist = true;
					}
				
				
			} catch (SQLException sqlEx) {
				LOG.error("Exception occurred while checking the presence of SFC Record: ", sqlEx);
				//sqlEx.printStackTrace();
				ServiceProcessingException customException = new ServiceProcessingException(sqlEx);
				customException.setMessage("Failed to check the presence of of SFC Record: " + sqlEx.getMessage());
				throw customException;
			} finally {
				try {
						if( resultSet != null)	resultSet.close();
						if( statement != null) statement.close();
						if(jdbcConnection != null) jdbcConnection.close();
					} catch (SQLException e) {
						
						e.printStackTrace();
					}
			}
			
			LOG.info("Executed checkActiveptnrHierExist()");
			
			return hierExist;
		}
		
		
		//Start ADB - Added new logic to fetch best matched record for Adobe
		private Map<String,Integer> fetchAdobeBestMatchRecord(List searchRecords) {
			
			LOG.info("calling fetchAdobeBestMatchRecord() method");
			
			Map<String,Integer> adbRecordMap = new HashMap<String,Integer>();
			Map<String,Integer> otherSrcRecordMap = new HashMap<String,Integer>();
			Map<String,Long> ucnRecordMap = new HashMap<String,Long>();
			
			Map<String,Integer> resultMap = new HashMap<String,Integer>();
			
			Map<String,Integer> finalResultMap = new HashMap<String,Integer>();
			
			if(searchRecords!=null && searchRecords.size()>0){
				LOG.info("************List of matched record(s)********************");
				for (Iterator iter = searchRecords.iterator(); iter.hasNext();) {
					Record record = (Record) iter.next();
					int mtchScore = Integer.parseInt(record.getField("MATCH_SCORE").getValue().toString().trim());
					String partyRowId = record.getField("ROWID_OBJECT").getStringValue().trim();
					
					isAdobeXrefFound = checkForAdobeXref(partyRowId);
					String srcSystem = isAdobeXrefFound?Constant.SRC_SYSTEM_ADB:"";
					String strUcn = record.getField("UCN")!=null ? record.getField("UCN").getStringValue() : "";
					long ucn = Util.isNullOrEmpty(strUcn) ? 0 : Long.parseLong(strUcn);
					
					LOG.info("partyRowId:"+partyRowId+", srcSystem:"+srcSystem+", mtchScore:"+mtchScore+", UCN:"+strUcn);
					
					if(searchRecords.size()==1){
						resultMap.put(partyRowId, mtchScore);
						return resultMap;
					}else if(searchRecords.size()>1){
						if(Constant.SRC_SYSTEM_ADB.equals(srcSystem)){
							adbRecordMap.put(partyRowId,mtchScore);
						}else{
							otherSrcRecordMap.put(partyRowId, mtchScore);
						}
						ucnRecordMap.put(partyRowId, ucn);
					}
					
				}
				boolean adbRecord = false;
				if(adbRecordMap!=null && adbRecordMap.size()>0){
					adbRecord = true;
					if(adbRecordMap.size()==1){
						resultMap.putAll(adbRecordMap);
						return resultMap;
					}else{
						resultMap = filterByScore(adbRecordMap);
					}
					
				} 
				
				if(otherSrcRecordMap!=null && otherSrcRecordMap.size()>0 && !adbRecord){
					if(otherSrcRecordMap.size()==1){
						return otherSrcRecordMap;
					}else{
						resultMap = filterByScore(otherSrcRecordMap);
					}
				}
				
				
				if(resultMap!=null && resultMap.size()==1){
					finalResultMap.putAll(resultMap);
				}else{
					finalResultMap.putAll(findLowestUcnRecord(resultMap,ucnRecordMap));
				}
				
			}
			LOG.info("end of fetchAdobeBestMatchRecord() method");
			return finalResultMap;
			
		}

		private boolean checkForAdobeXref(String partyRowId) {
			LOG.debug("Inside checkForAdobeXref()");
			PreparedStatement statement = null;
			Connection jdbcConn = null;
			ResultSet resultSet = null;
			int count = 0;
			JDBCConnectionProvider jDBCConnectionProvider = null;
			try {
				jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
				jdbcConn = jDBCConnectionProvider.getJdbcConnectionFromDS();
				LOG.info("checkForAdobeXref  partyRowId : " + partyRowId);
				StringBuilder sql = new StringBuilder();
				sql.append("select count(1) from C_B_PARTY_XREF where rowid_object='"+partyRowId+"' and rowid_system='ADB' and hub_state_ind='1' and status_cd='A'");
				LOG.debug("SQL Generated is : " + sql.toString());
				statement = jdbcConn.prepareStatement(sql.toString());
				resultSet = statement.executeQuery();
				if (resultSet.next()) {
					count = resultSet.getInt(1);
				}
				LOG.debug("count value is: " + count);
			} catch (Exception exp) {
				LOG.error("Caught SQLException in checkForAdobeXref()::"+exp.getMessage());
			} finally {
				try {
					if (resultSet != null)
						resultSet.close();
					if (statement != null)
						statement.close();
					if (jdbcConn != null)
						jdbcConn.close();
				} catch (SQLException exp) {
					LOG.error("Caught SQLException in checkForAdobeXref().");
				}

			}
			
			return count>0?true:false;

		}


		private Map<String, Integer> findLowestUcnRecord(Map<String, Integer> scoreMap, Map<String, Long> ucnRecordMap) {
			
			Map<String, Long> recordMap = new HashMap<String, Long>();
			
			Map<String, Integer> resultMap = new HashMap<String, Integer>();
			
			for(Entry<String, Integer> entry : scoreMap.entrySet()){
				
				if(ucnRecordMap.containsKey(entry.getKey())){
					recordMap.put(entry.getKey(), ucnRecordMap.get(entry.getKey()));
				}
			}
			String rowid = findMinUcnRowId(recordMap);
			resultMap.put(rowid,scoreMap.get(rowid));
			return resultMap;
			
		}
		
		private String findMinUcnRowId(Map<String, Long> UCNCustNumMap) {
			
			Map<String,Long> resultMap = new HashMap<String,Long>();
			List<Long> ucnList = new ArrayList<Long>(UCNCustNumMap.values());
			Long minUcn = Collections.min(ucnList);
			String rowId="";
			for (Entry<String, Long> entry : UCNCustNumMap.entrySet()) {
				if (minUcn.equals(entry.getValue())) {
					resultMap.put(entry.getKey(), minUcn);
				}
			}
			
			if(resultMap!=null && resultMap.size()>0){
				for(Entry<String, Long> entry : resultMap.entrySet()){
					rowId = entry.getKey();
					break;
				}
			}
	        return rowId;
		}
		
		private Map<String, Integer> filterByScore(Map<String, Integer> recordMap) {

			Map<String,Integer> resultMap = new HashMap<String,Integer>();
			List<Integer> scoreList = new ArrayList<Integer>(recordMap.values());
			Integer maxScore = Collections.max(scoreList);
			
			for (Entry<String, Integer> entry : recordMap.entrySet()) {
				if (maxScore.equals(entry.getValue())) {
					resultMap.put(entry.getKey(), maxScore);
				}
			}
	       
	        return resultMap;
	    }
		//End - ADB logic
		
		
		public HierarchySearchResponse hierarchySearch(HierarchySearchRequest parameters) throws ServiceProcessingException{
			long startTime=System.currentTimeMillis();
			LOG.info("Starting hierarchySearch in SearchPartyDAO ");
			HierarchySearchResponse hierarchySearchResponse= null;
			Set<String> rowIdObjectSet=new HashSet<String>();
			HierarchyRequestType hierarchyRequestType=null;
			Map<String,Set<String>> recordHierarchyMapWithPtyType = new HashMap<String,Set<String>> ();
			HierarchyResponseType hierarchyResponseType=null;
			
			try{
			
			if(parameters!=null && parameters.getUCN()!=null && !parameters.getUCN().isEmpty()){
				LOG.info("UCN from Input request for hierarchySearch "+parameters.getUCN());
				rowIdObjectSet=processHierarchyUCNSearchRequest(parameters.getUCN());
				
				if(rowIdObjectSet.isEmpty()){
					rowIdObjectSet=processHierarchyUCNHistorySearchRequest(parameters.getUCN());
				}
				if(!rowIdObjectSet.isEmpty()){
				recordHierarchyMapWithPtyType.put("PARTY", rowIdObjectSet);
					if(recordHierarchyMapWithPtyType!=null){
						hierarchyResponseType=findGlobalUCNHierarchySearch(recordHierarchyMapWithPtyType,parameters.getUCN());
					}
					
					if(hierarchyResponseType!=null){
						if(hierarchyResponseType.getParties()!=null && hierarchyResponseType.getParties().size()>0){
							hierarchySearchResponse=populateUCNHierarchySearchResponse(parameters, hierarchyResponseType);
						}else{
							hierarchySearchResponse=new HierarchySearchResponse();
							hierarchySearchResponse.setStatus(Constant.noRecordFound);
							hierarchySearchResponse.setErrorMessage("");
							hierarchyRequestType=new HierarchyRequestType();
							hierarchyRequestType.setUCN(parameters.getUCN());
							hierarchySearchResponse.setRequest(hierarchyRequestType);
							hierarchyResponseType=new HierarchyResponseType();
							hierarchyResponseType.setMDMGLOBALPARENTNAME("");
							hierarchyResponseType.setMDMGLOBALUCN("");
							hierarchySearchResponse.setResponse(hierarchyResponseType);
						}
						
					}
				}else{
					hierarchySearchResponse=new HierarchySearchResponse();
					hierarchySearchResponse.setStatus(Constant.noRecordFound);
					hierarchySearchResponse.setErrorMessage("");
					hierarchyRequestType=new HierarchyRequestType();
					hierarchyRequestType.setUCN(parameters.getUCN());
					hierarchySearchResponse.setRequest(hierarchyRequestType);
					hierarchyResponseType=new HierarchyResponseType();
					hierarchyResponseType.setMDMGLOBALPARENTNAME("");
					hierarchyResponseType.setMDMGLOBALUCN("");
					hierarchySearchResponse.setResponse(hierarchyResponseType);
				}
					
			}else if(parameters.getUCN()==null || parameters.getUCN().isEmpty()){
				hierarchySearchResponse=new HierarchySearchResponse();
				hierarchySearchResponse.setErrorMessage(Constant.noHierarchySearchUCNInput);
				hierarchySearchResponse.setStatus("");
				hierarchyRequestType=new HierarchyRequestType();
				hierarchyRequestType.setUCN(parameters.getUCN());
				hierarchySearchResponse.setRequest(hierarchyRequestType);
				hierarchyResponseType=new HierarchyResponseType();
				hierarchyResponseType.setMDMGLOBALPARENTNAME("");
				hierarchyResponseType.setMDMGLOBALUCN("");
				hierarchySearchResponse.setResponse(hierarchyResponseType);
			}

			}catch(Exception e){
				hierarchySearchResponse.setErrorMessage(e.getLocalizedMessage());
				hierarchySearchResponse.setStatus("");
				hierarchyRequestType=new HierarchyRequestType();
				hierarchyRequestType.setUCN(parameters.getUCN());
				hierarchySearchResponse.setRequest(hierarchyRequestType);
				hierarchyResponseType=new HierarchyResponseType();
				hierarchyResponseType.setMDMGLOBALPARENTNAME("");
				hierarchyResponseType.setMDMGLOBALUCN("");
				hierarchySearchResponse.setResponse(hierarchyResponseType);
				
				
			}
			
			LOG.info("Ending  hierarchySearch in SerachPartyDAO "+hierarchySearchResponse);
			LOG.info("Time Taken to complete hierarchySearch"+(System.currentTimeMillis()-startTime)+" ms");
			return hierarchySearchResponse;
			
			
		}
		
		
		public HierarchyResponseType findGlobalUCNHierarchySearch(Map<String,Set<String>> recordHierarchyMapWithPtyType,String requestUCN){
			long startTime=System.currentTimeMillis();
			LOG.info("Starting findGlobalUCNHierarchySearch in SearchPartyDAO");
			HierarchyResponseType hierarchyResponseType=null;
			Set<String> rowIdObjectSet=null;
			List<String> globalUCNList=new ArrayList<String>();
			try{
			rowIdObjectSet=recordHierarchyMapWithPtyType.get("PARTY");
			if(rowIdObjectSet!=null && rowIdObjectSet.size()>0){
				
				globalUCNList=getGlobalUCN(rowIdObjectSet);
				LOG.info("Sizee of globalUCNList "+globalUCNList.size());
				if(globalUCNList!=null && globalUCNList.size()>0){
				hierarchyResponseType=getListOfPartiesForUCNHierarchySearch(globalUCNList,requestUCN);
				}else{
					
					hierarchyResponseType= new HierarchyResponseType();
					
					
				}
				LOG.info("hierarchyResponseType"+hierarchyResponseType);
			}
			}catch(Exception e){
				//e.printStackTrace();
				LOG.info("Exception occurred in findGlobalUCNHierarchySearch "+e.getMessage()+e.getLocalizedMessage());
			}
			LOG.info("Ending findGlobalUCNHierarchySearch in SearchPartyDAO "+hierarchyResponseType +" "+(System.currentTimeMillis()-startTime)+" ms");
				return hierarchyResponseType;
		}
		
		
		public HierarchySearchResponse populateUCNHierarchySearchResponse(HierarchySearchRequest parameters,HierarchyResponseType hierarchyResponseType){
			long startTime=System.currentTimeMillis();
			LOG.info("Starting populateUCNHierarchySearchResponse in SearchPartyDAO");
			HierarchySearchResponse hierarchySearchResponse= new HierarchySearchResponse();
			HierarchyRequestType hierarchyRequestType= new HierarchyRequestType();
			LOG.info("Request UCN is "+parameters.getUCN());
			hierarchyRequestType.setUCN(parameters.getUCN());
			List<Party> finalRespPartyList= new ArrayList<Party>();
			Parties respParties=null;
			hierarchySearchResponse.setRequest(hierarchyRequestType);
			HierarchyResponseType ucnHierarchyResponseType= new HierarchyResponseType();
			
			if(hierarchyResponseType!=null && hierarchyResponseType.getParties()!=null &&  hierarchyResponseType.getParties().size()>0 && hierarchyResponseType.getParties().get(0).getParty()!=null){
			for(Party party:hierarchyResponseType.getParties().get(0).getParty()){
				Party respParty=new Party();
				respParty.setROWIDOBJECT(party.getROWIDOBJECT().trim());
				if(!Util.isNullOrEmpty(party.getUCN())){
				respParty.setUCN(party.getUCN());
				}else{
					respParty.setUCN("");
				}
				if(!Util.isNullOrEmpty(party.getPARTYNAME())){
				respParty.setPARTYNAME(party.getPARTYNAME());
				}else{
					respParty.setPARTYNAME("");
				}
				if(!Util.isNullOrEmpty(party.getMDMPARENTUCN())){
					respParty.setMDMPARENTUCN(party.getMDMPARENTUCN());
				}else{
					respParty.setMDMPARENTUCN("");
				}
				if(!Util.isNullOrEmpty(party.getGEO())){
					respParty.setGEO(party.getGEO());
				}else{
					respParty.setGEO("");
				}
				if(!Util.isNullOrEmpty(party.getREGION())){
					respParty.setREGION(party.getREGION());
				}else{
					respParty.setREGION("");
				}
				if(!Util.isNullOrEmpty(party.getCOUNTRYNAME())){
					respParty.setCOUNTRYNAME(party.getCOUNTRYNAME());
				}else{
					respParty.setCOUNTRYNAME("");
				}
				if(party.getHISTORICALUCNs()!=null && !party.getHISTORICALUCNs().getHISTORICALUCN().isEmpty()){
				LOG.info("Inside History UCN check "+party.getHISTORICALUCNs().getHISTORICALUCN().size());
				HistoricalUCNs historicalUCNs=new HistoricalUCNs();
				historicalUCNs.getHISTORICALUCN().addAll(party.getHISTORICALUCNs().getHISTORICALUCN());
				
				respParty.setHISTORICALUCNs(historicalUCNs);
					
		//respParty.getHISTORICALUCNs().addAll(party.getHISTORICALUCNs());
				}else{
					HistoricalUCNs historicalUCNs=new HistoricalUCNs();
					respParty.setHISTORICALUCNs(historicalUCNs);
				}
				LOG.info("Inside populateUCNHierarchySearchResponse Request_Node is -->"+party.getREQUESTNODE());
				respParty.setREQUESTNODE(party.getREQUESTNODE());
				finalRespPartyList.add(respParty);
			}
			LOG.info("finalRespPartyList sizeee is "+finalRespPartyList.size());
			}
			
	if(finalRespPartyList!=null && finalRespPartyList.size()>0){
		respParties=new Parties();
		respParties.getParty().addAll(finalRespPartyList);
		ucnHierarchyResponseType.getParties().add(respParties);
		if(!Util.isNullOrEmpty(hierarchyResponseType.getMDMGLOBALPARENTNAME())){
			ucnHierarchyResponseType.setMDMGLOBALPARENTNAME(hierarchyResponseType.getMDMGLOBALPARENTNAME());
		}else{
			ucnHierarchyResponseType.setMDMGLOBALPARENTNAME("");
		}
		if(!Util.isNullOrEmpty(hierarchyResponseType.getMDMGLOBALUCN())){
			ucnHierarchyResponseType.setMDMGLOBALUCN(hierarchyResponseType.getMDMGLOBALUCN());
		}else{
			ucnHierarchyResponseType.setMDMGLOBALUCN("");
		}
		
	}
			LOG.info("After adding finalRespPartyList to Response");
			hierarchySearchResponse.setResponse(ucnHierarchyResponseType);
			int partyUCNHierarchySearchProfileSize  = ucnHierarchyResponseType.getParties().get(0).getParty().size();
			LOG.info("partyUCNHierarchySearchProfileSize"+partyUCNHierarchySearchProfileSize);
			if(partyUCNHierarchySearchProfileSize>0){
				hierarchySearchResponse.setStatus(partyUCNHierarchySearchProfileSize+" Hierarchy Profiles successfully found through UCN hierarchySearch!");
				hierarchySearchResponse.setErrorMessage("");
			}else{
				hierarchySearchResponse.setStatus(Constant.noRecordFound);
				hierarchySearchResponse.setErrorMessage("");
			}
			LOG.info("Ending populateUCNHierarchySearchResponse in SearchPartyDAO" + hierarchySearchResponse+" "+(System.currentTimeMillis()-startTime)+" ms");
			return hierarchySearchResponse;
		}
		
		
		public Set<String> processHierarchyUCNHistorySearchRequest(String ucn) {
			// TODO Auto-generated method stub
			long startTime=System.currentTimeMillis();
		LOG.info("Inside processHierarchyUCNSearchRequest "+ucn);
			Set<String> goldenRecSet = null;
			Statement statement = null;
			Statement xrefCheckstmt=null;
			StringBuilder sqlQry = new StringBuilder();
			StringBuilder sqlPartyCheckQry = new StringBuilder();
			StringBuilder sqlPartyXrefCheckQry = new StringBuilder();
			String rowid_object = null;
			Connection jdbcConnection = null;
			ResultSet resultSet = null;
			ResultSet resultBOSet = null;
			ResultSet resultXrfSet = null;
			goldenRecSet = new HashSet<String>();
			
			try {

				JDBCConnectionProvider jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();

				if ( !Util.isNullOrEmpty(ucn))	{

					LOG.info("Fetching Golden copy from party " + ucn);

					sqlQry.append("select rowid_object from ( select hist_create_date,rowid_object from c_b_party_hist where UCN  = ('" + ucn + "')");
					sqlQry.append(" AND BO_CLASS_CODE = '" + "Organization" + "'");
					sqlQry.append(" AND ( PARTY_TYPE in ('" + "Customer" + "','"+"Distributor"+"','"+"Reseller"+"','"+"Partner"+"','"+"Prospect Customer"+"') OR PARTY_TYPE is null)");
					sqlQry.append(" order by 1 desc )");
					sqlQry.append(" where rownum < 2 ");

					LOG.info("Query to fetch getGoldenRecforID: " + sqlQry);


					jdbcConnection = jDBCConnectionProvider.getJdbcConnectionFromDS();
				//	jdbcConnection = JdbcConn.GetJdbcConnObject();
					statement = jdbcConnection.createStatement();
					resultSet = statement.executeQuery(sqlQry.toString());
					
					while(resultSet.next()){
						
						LOG.info("Found RowidObj in HierarchyUCNHistorySearch"+resultSet.getString(1));
						rowid_object=resultSet.getString(1);
						sqlPartyCheckQry.append("select 1 from C_B_PARTY where rowid_object = '" +rowid_object+"'");
						sqlPartyCheckQry.append(" AND BO_CLASS_CODE = '" + "Organization" + "'");
						sqlPartyCheckQry.append(" AND ( PARTY_TYPE in ('" + "Customer" + "','"+"Distributor"+"','"+"Reseller"+"','"+"Partner"+"','"+"Prospect Customer"+"') OR PARTY_TYPE is null)");
						LOG.info("Query to Check rowid_object prsence in BO " + sqlPartyCheckQry.toString());
						
						jdbcConnection = jDBCConnectionProvider.getJdbcConnectionFromDS();
						//	jdbcConnection = JdbcConn.GetJdbcConnObject();
							statement = jdbcConnection.createStatement();
							resultBOSet = statement.executeQuery(sqlPartyCheckQry.toString());
							while(resultBOSet.next()){
								
								if(resultBOSet.getInt(1)>0){
									goldenRecSet.add(rowid_object);
								}
							}
								
								if(goldenRecSet.size()==0){
									
									sqlPartyXrefCheckQry.append("select rowid_object  from c_b_party_xref where orig_rowid_object = '"+rowid_object+"'");
									sqlPartyXrefCheckQry.append(" AND BO_CLASS_CODE = '" + "Organization" + "'");
									sqlPartyXrefCheckQry.append(" AND (PARTY_TYPE in ('" + "Customer" + "','"+"Distributor"+"','"+"Reseller"+"','"+"Partner"+"','"+"Prospect Customer"+"') OR PARTY_TYPE is null)");
									LOG.debug("Query to Check rowid_object prsence in Xref " + sqlPartyXrefCheckQry.toString());
									//jdbcConnection=null;
									
									
									//	jdbcConnection = JdbcConn.GetJdbcConnObject();
									xrefCheckstmt = jdbcConnection.createStatement();
										
									
										resultXrfSet=xrefCheckstmt.executeQuery(sqlPartyXrefCheckQry.toString());
									
									while(resultXrfSet.next()){
										if(resultXrfSet.getString(1)!=null && !resultXrfSet.getString(1).isEmpty()){
											LOG.info("Matched Xref rowid_object is "+resultXrfSet.getString(1));
											goldenRecSet.add(resultXrfSet.getString(1));
											
										}
									}
									
								}
							}
						
						
					}
					
					
							

			} catch (SQLException sqlEx) {
				LOG.error("Exception in getGoldenRecforID() for ID based Search: " , sqlEx);
				ServiceProcessingException customException = new ServiceProcessingException(sqlEx);
				customException.setMessage("Failed to fetch Party profile from ORS." + customException.getMessage());
			//	throw customException;
			} catch (ServiceProcessingException sqlEx) {
				LOG.error("Exception in getGoldenRecforID() for ID based Search: " , sqlEx);
				ServiceProcessingException customException = new ServiceProcessingException(sqlEx);
				customException.setMessage("Failed to fetch Party profile from ORS." + customException.getMessage());
			//	throw customException;
			}	finally {
				try {
						if( resultSet != null)	resultSet.close();
						if( statement != null) statement.close();
						if(jdbcConnection != null) jdbcConnection.close();
					} catch (SQLException e) {

						LOG.debug("Caught SQLException in getGoldenRecforID: " , e);
					}
			}

		LOG.info("goldenRecSet-->>"+goldenRecSet.toString());
		LOG.info("End of processHierarchyUCNHistorySearchRequest "+(System.currentTimeMillis()-startTime)+" ms");
			return goldenRecSet;
		}
		
			public Set<String> processHierarchyUCNSearchRequest(String ucn) {
			// TODO Auto-generated method stub
			long startTime=System.currentTimeMillis();
		LOG.info("Inside processHierarchyUCNSearchRequest "+ucn);
			Set<String> goldenRecSet = null;
			Statement statement = null;
			StringBuilder sqlQry = new StringBuilder();
		//	String rowid_object = null;
			Connection jdbcConnection = null;
			ResultSet resultSet = null;
			goldenRecSet = new HashSet<String>();
			
			try {

				JDBCConnectionProvider jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();

				if ( !Util.isNullOrEmpty(ucn))	{

					LOG.info("Fetching Golden copy from party " + ucn);

					sqlQry.append("SELECT ROWID_OBJECT FROM C_B_PARTY WHERE UCN = ('" + ucn + "')");
					sqlQry.append(" AND BO_CLASS_CODE = '" + "Organization" + "'");
					sqlQry.append(" AND (PARTY_TYPE in ('" + "Customer" + "','"+"Distributor"+"','"+"Reseller"+"','"+"Partner"+"','"+"Prospect Customer"+"') OR PARTY_TYPE is null)");

					LOG.info("Query to fetch getGoldenRecforID: " + sqlQry);


					jdbcConnection = jDBCConnectionProvider.getJdbcConnectionFromDS();
				//	jdbcConnection = JdbcConn.GetJdbcConnObject();
					statement = jdbcConnection.createStatement();
					resultSet = statement.executeQuery(sqlQry.toString());
					
					while(resultSet.next()){
						goldenRecSet.add(resultSet.getString(1));
						LOG.info("Found RowidObj in HierarchyUCNSearch"+resultSet.getString(1));
					}
					
				}			

			} catch (SQLException sqlEx) {
				LOG.error("Exception in getGoldenRecforID() for ID based Search: " , sqlEx);
				ServiceProcessingException customException = new ServiceProcessingException(sqlEx);
				customException.setMessage("Failed to fetch Party profile from ORS." + customException.getMessage());
			//	throw customException;
			} catch (ServiceProcessingException sqlEx) {
				LOG.error("Exception in getGoldenRecforID() for ID based Search: " , sqlEx);
				ServiceProcessingException customException = new ServiceProcessingException(sqlEx);
				customException.setMessage("Failed to fetch Party profile from ORS." + customException.getMessage());
			//	throw customException;
			}	finally {
				try {
						if( resultSet != null)	resultSet.close();
						if( statement != null) statement.close();
						if(jdbcConnection != null) jdbcConnection.close();
					} catch (SQLException e) {

						LOG.debug("Caught SQLException in getGoldenRecforID: " , e);
					}
			}

		LOG.info("Ending processHierarchyUCNSearchRequest in SearchPartyDAO");
		LOG.info("Time Taken to complete processHierarchyUCNSearchRequest "+(System.currentTimeMillis()-startTime)+" ms");
			return goldenRecSet;
		}
		private String validatePartyName(String partyName){
			LOG.info("Inside validatePartyName "+partyName);
			String actualNm=partyName;
	         String tempPartyNm="";
	         try{
	      List<Integer> charPosList= new ArrayList<Integer>();
	      if(partyName.contains("") || partyName.contains("")){
				while(partyName.indexOf("")>0 || partyName.indexOf("")>0){
					
						int pos=partyName.indexOf("");
						if(pos<0){
							pos=partyName.indexOf("");
						}
						if(charPosList.size()==0){
						charPosList.add(pos);
						}else{
							charPosList.add(charPosList.get(charPosList.size()-1)+pos);
						}
						partyName=partyName.substring(pos+1,partyName.length());
						
					}
	
		
	for(int i=0;i<charPosList.size();i++){
	    if(tempPartyNm.isEmpty()){
	    tempPartyNm=tempPartyNm+actualNm.substring(0,charPosList.get(i));
	    }else{
	       
	        tempPartyNm=tempPartyNm+actualNm.substring(charPosList.get(i-1)+1,charPosList.get(i)+1);
	    }
	}
	
	tempPartyNm=tempPartyNm+actualNm.substring(charPosList.get(charPosList.size()-1)+2,actualNm.length());
	LOG.info("Modified Party Name is "+tempPartyNm);
	      }else{
	    	  tempPartyNm=partyName;
	      }
	         }catch(Exception e){
	        	 LOG.info("Exception occurred "+e.getLocalizedMessage());
	         }
			
			return tempPartyNm;
			
		}
		
		public HierarchyResponseType getListOfPartiesForUCNHierarchySearch(List<String> listOfGUCN,String requestUCN) {	
			long startTime=System.currentTimeMillis();
			LOG.info("Starting getListOfPartiesForUCNHierarchySearch");
			Iterator<String> GUCNs = listOfGUCN.iterator();		
			Connection jdbcConnection = null;
			ResultSet resultSet = null;
			Statement statement = null;
			List<Party> listOfParties = null; 
			Parties parties=null;
			List<String> historicalUCNsList=null;
			Map<String,Party> partyDtlsMap= new HashMap<String,Party>();
			Map<String,String> partyHistUCNMap= new HashMap<String,String>();
			HierarchyResponseType hierarchyResponseType= new HierarchyResponseType();
			try {
				JDBCConnectionProvider jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
				jdbcConnection = jDBCConnectionProvider.getJdbcConnectionFromDS();
				statement = jdbcConnection.createStatement();
				// Query start			
				if(listOfGUCN!=null && listOfGUCN.size()>0) {
					listOfParties = new ArrayList<Party>();
					StringBuilder sqlQry = new StringBuilder();
					sqlQry.append("SELECT * FROM ( SELECT DISTINCT a.*, CASE WHEN a.ucn = b.ucn THEN NULL ELSE b.ucn END ucn_hist FROM  mdm_mcafee_hier_denorm_vw a INNER JOIN c_b_party_xref cbx ON a.rowid_object = cbx.rowid_object INNER JOIN c_b_party_hist b ON  cbx.orig_rowid_object = b.rowid_object AND  a.mfe_glbl_parent_ucn = '");
					sqlQry.append(listOfGUCN.get(0));
					sqlQry.append(	 "' and b.ucn is not null) x WHERE NOT EXISTS (SELECT 1 FROM mdm_mcafee_hier_denorm_vw vw WHERE vw.ucn = nvl(x.ucn_hist,'99999'))");
					
					LOG.info(" Query for List of parties is :: " + sqlQry.toString());
					resultSet = statement.executeQuery(sqlQry.toString());			
					Party partiesObj = null;
					while (resultSet.next()) {
						String temp_RowIdObj="";
						temp_RowIdObj=resultSet.getString(1);
						LOG.info("temp_RowIdObj iss -->>"+temp_RowIdObj);
						if(!partyDtlsMap.containsKey(temp_RowIdObj)){
							
						
						partiesObj = new Party();
						partiesObj.setROWIDOBJECT(resultSet.getString(1));
						partiesObj.setUCN(resultSet.getString(3));
						partiesObj.setPARTYNAME(validatePartyName(resultSet.getString(2)));
						partiesObj.setMDMPARENTUCN(resultSet.getString(4));
						
						
						if(partiesObj.getUCN().equalsIgnoreCase(requestUCN)){
							partiesObj.setREQUESTNODE("Y");
						}						 
						LOG.info("REQUESTNODE is "+partiesObj.getREQUESTNODE());
						hierarchyResponseType.setMDMGLOBALPARENTNAME(validatePartyName(resultSet.getString(5)));
						hierarchyResponseType.setMDMGLOBALUCN(resultSet.getString(6));
							LOG.info("Global Parent UCN iss "+hierarchyResponseType.getMDMGLOBALUCN());
							partiesObj.setGEO(resultSet.getString(7));
							partiesObj.setREGION(resultSet.getString(8));
							partiesObj.setCOUNTRYNAME(resultSet.getString(9));
							if(!Util.isNullOrEmpty(resultSet.getString(10)) && !resultSet.getString(10).contains("tmp_")){
							partyHistUCNMap.put(resultSet.getString(1), resultSet.getString(10));
							}
								
							
							LOG.info("Rowid>>"+partiesObj.getROWIDOBJECT()+"UCN>>"+partiesObj.getUCN()+"NAME>>"+partiesObj.getPARTYNAME()+"Parent_UCN>>"+partiesObj.getMDMPARENTUCN()+"GEO>>"+partiesObj.getGEO()+"REGION>>"+partiesObj.getREGION()+"COUNTRY_NAME>>"+partiesObj.getCOUNTRYNAME()+"Hist_UCN>>"+resultSet.getString(10));
							partyDtlsMap.put(resultSet.getString(1), partiesObj);
						LOG.info("listOfParties sizeee is "+listOfParties.size());
						
						partiesObj = null;
					}else if(partyDtlsMap.containsKey(temp_RowIdObj)){
						
						String temp_hist_ucn="";
						temp_hist_ucn=partyHistUCNMap.get(temp_RowIdObj);
						
						if(!Util.isNullOrEmpty(resultSet.getString(10)) && !resultSet.getString(10).contains("tmp_")){
							if(!Util.isNullOrEmpty(temp_hist_ucn)){
						temp_hist_ucn=temp_hist_ucn+";"+resultSet.getString(10);
							}else{
								temp_hist_ucn=resultSet.getString(10);
							}
						}
						if(!Util.isNullOrEmpty(temp_hist_ucn) && !temp_hist_ucn.contains("tmp_")){
						partyHistUCNMap.put(resultSet.getString(1), temp_hist_ucn);
						}
						
					}
					}
					
						
					LOG.info("partyHistUCNMap Sizee "+partyHistUCNMap.size()+ " "+partyHistUCNMap.toString());
					LOG.info("partyDtlsMap Sizee "+partyDtlsMap.size()+" "+partyDtlsMap.toString());
					String[] histUCNArr=null;
					String temp_party_hist_UCN=null;
					sqlQry = null;
					for(Map.Entry<String, Party> entry : partyDtlsMap.entrySet()){
						temp_party_hist_UCN="";
						histUCNArr=null;
						String rowid_object="";
						historicalUCNsList=null;
						rowid_object=entry.getKey();
						LOG.info("rowid_object-->>"+rowid_object);
						Party partyObj=null;
						partyObj=entry.getValue();
						if(!Util.isNullOrEmpty(rowid_object)){
						 temp_party_hist_UCN=partyHistUCNMap.get(rowid_object);
						LOG.info("temp_party_hist_UCN-->>"+temp_party_hist_UCN);
						}
						if(!Util.isNullOrEmpty(temp_party_hist_UCN)){
						 histUCNArr=temp_party_hist_UCN.split(";");
						 LOG.info("histUCNArr -->>"+histUCNArr.toString());
						}
						
						if(histUCNArr!=null && histUCNArr.length>0){
							historicalUCNsList=new ArrayList<String>();
							
						for (int i=0; i<histUCNArr.length;i++){
							if(!Util.isNullOrEmpty(histUCNArr[i])){
								LOG.info("histUCNArr[i] >>>"+histUCNArr[i]);
							historicalUCNsList.add(histUCNArr[i]);
							}
						}
						LOG.info("historicalUCNsList iss "+historicalUCNsList.toString());
						}
						LOG.info("Req Node of current Party obj iss "+partyObj.getREQUESTNODE());
						if(historicalUCNsList!=null && historicalUCNsList.size()>0){
							for(String historicalUCNs : historicalUCNsList){
								
								if(historicalUCNs.contains(requestUCN)){
									partyObj.setREQUESTNODE("Y");
									break;
								}
							}
							if(partyObj.getREQUESTNODE()==null || !partyObj.getREQUESTNODE().equalsIgnoreCase("Y")){
								partyObj.setREQUESTNODE("N");
							}
							}else{
								if(partyObj.getREQUESTNODE()==null || !partyObj.getREQUESTNODE().equalsIgnoreCase("Y")){
								partyObj.setREQUESTNODE("N");
								}
							}
						if(historicalUCNsList!=null && historicalUCNsList.size()>0){
							HistoricalUCNs historicalUCNs=new HistoricalUCNs();
							historicalUCNs.getHISTORICALUCN().addAll(historicalUCNsList);
							partyObj.setHISTORICALUCNs(historicalUCNs);
						LOG.info("Rowid Obj->>"+partyObj.getROWIDOBJECT()+" History UCN Sizee "+partyObj.getHISTORICALUCNs().getHISTORICALUCN().size()+partyObj.getHISTORICALUCNs().getHISTORICALUCN().toString());
						}else{
							HistoricalUCNs historicalUCNs=new HistoricalUCNs();
							
							partyObj.setHISTORICALUCNs(historicalUCNs);
						}
						
						listOfParties.add(partyObj);
					}
					
					
					
					
					
					LOG.info("listOfParties sizeee is "+listOfParties.size());
					
					if(listOfParties!=null && listOfParties.size()>0){
						
						parties= new Parties();
						parties.getParty().addAll(listOfParties);
						hierarchyResponseType.getParties().add(parties);
						LOG.info("Parties Sizee "+hierarchyResponseType.getParties().size());
					}
					
					
				}
			} catch (ServiceProcessingException serviceEx) {
				
				serviceEx.printStackTrace();
				LOG.error("Exception: Unable to create JDBC connection from datasource: for getListOfPartiesForUCNHierarchySearch " + serviceEx.getLocalizedMessage());
			} catch (SQLException sqlEx) {
				sqlEx.printStackTrace();
				LOG.error("Exception occurred in getListOfPartiesForUCNHierarchySearch: "	+ sqlEx.getLocalizedMessage());
				sqlEx.printStackTrace();
			} finally {
				try {
					if (resultSet != null)
						resultSet.close();
					if (statement != null)
						statement.close();
					if (jdbcConnection != null)
						jdbcConnection.close();
				} catch (SQLException sqlEx) {
					LOG.error("Sql Exception occurred in getListOfPartiesForUCNHierarchySearch : " + sqlEx.getLocalizedMessage());
				}
			}
			
			LOG.info("End of getListOfPartiesForUCNHierarchySearch "+(System.currentTimeMillis()-startTime)+" ms");
			return hierarchyResponseType;
		}
		
		public List<String> searchHistoricalUCNs(String rowIdObject){
			LOG.info("Starting searchHistoricalUCNs for rowIdObject "+rowIdObject);
			Connection jdbcConnection = null;
			ResultSet resultSet = null;
			Statement statement = null;
			//List<HistoricalUCNs> historicalUCNsList= new ArrayList<HistoricalUCNs>();
			List<String> historicalUCNList=new ArrayList<String>();
			try{
				JDBCConnectionProvider jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
				jdbcConnection = jDBCConnectionProvider.getJdbcConnectionFromDS();
				statement = jdbcConnection.createStatement();
				if(rowIdObject!=null && !rowIdObject.isEmpty()){
					StringBuilder sqlQry = new StringBuilder();
					sqlQry.append("select distinct(UCN) from C_B_party_hist hs where hs.rowid_object = '"+rowIdObject+"'");
					sqlQry.append(" AND hs.UCN is not null ");
					sqlQry.append(" AND not exists ( select 1 from C_B_party where UCN=hs.UCN )");
					
					resultSet=statement.executeQuery(sqlQry.toString());
					while(resultSet.next()){
						historicalUCNList.add(resultSet.getString(1));
						LOG.info("Retrieved historicalUCN is "+resultSet.getString(1));
					}
					
					/*if(historicalUCNList!=null){
						
					HistoricalUCNs historicalUCNs= new HistoricalUCNs();
					historicalUCNs.getHISTORICALUCN().addAll(historicalUCNList);
					//historicalUCNsList.add(historicalUCNs);
					}*/
					LOG.info("sizee of historicalUCNsList "+historicalUCNList.size());
				}
			}catch(Exception e){
				e.printStackTrace();
			}finally {
				try {
					if (resultSet != null)
						resultSet.close();
					if (statement != null)
						statement.close();
					if (jdbcConnection != null)
						jdbcConnection.close();
				} catch (SQLException sqlEx) {
					LOG.error("Sql Exception occurred in getAllPartyGolden : " + sqlEx);
				}
			}
			
			LOG.info("End of searchHistoricalUCNs");
			
			return historicalUCNList;
		}
		
		private String getADBSearchCountryNm(String countryCd){
			LOG.info("Inside getADBSearchCountryNm "+countryCd);
			String countryNm="";
			Connection jdbcConnection = null;
			ResultSet resultSet = null;
			Statement statement = null;
			try{
				JDBCConnectionProvider jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
				jdbcConnection = jDBCConnectionProvider.getJdbcConnectionFromDS();
				statement = jdbcConnection.createStatement();
				StringBuilder sqlQry = new StringBuilder();
				sqlQry.append("select ADB_COUNTRY_NM from mdm_country where ADB_COUNTRY_CD='");
				sqlQry.append(countryCd);
				sqlQry.append("'");
				resultSet=statement.executeQuery(sqlQry.toString());
				while(resultSet.next()){
					countryNm=resultSet.getString(1);
				}
				LOG.info("countryNm iss "+countryNm);
			}catch(Exception e){
				e.printStackTrace();
			}finally {
				try {
					if (resultSet != null)
						resultSet.close();
					if (statement != null)
						statement.close();
					if (jdbcConnection != null)
						jdbcConnection.close();
				} catch (SQLException sqlEx) {
					LOG.error("Sql Exception occurred in getAllPartyGolden : " + sqlEx);
				}
			}
			
			return countryNm;
		}
		
}
