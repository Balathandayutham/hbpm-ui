package com.mcafee.mdm.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.mcafee.mdm.constants.Constant;
import com.mcafee.mdm.constants.MDMAttributeNames;
import com.mcafee.mdm.dao.pojo.GlobalHierarchyNode;
import com.mcafee.mdm.dao.pojo.SearchedRecordCollection;
import com.mcafee.mdm.dao.pojo.SearchedXrefRecordCollection;
import com.mcafee.mdm.exception.ServiceProcessingException;
import com.mcafee.mdm.generated.AccountType;
import com.mcafee.mdm.generated.AccountXrefType;
import com.mcafee.mdm.generated.AddressType;
import com.mcafee.mdm.generated.AddressXrefType;
import com.mcafee.mdm.generated.ClassificationType;
import com.mcafee.mdm.generated.ClassificationXrefType;
import com.mcafee.mdm.generated.CommunicationType;
import com.mcafee.mdm.generated.CommunicationXrefType;
import com.mcafee.mdm.generated.PartyAccountRelationshipType;
import com.mcafee.mdm.generated.PartyAccountRelationshipXrefType;
import com.mcafee.mdm.generated.PartyOrgExtType;
import com.mcafee.mdm.generated.PartyOrgExtXrefType;
import com.mcafee.mdm.generated.PartyPersonExtXrefType;
import com.mcafee.mdm.generated.PartyPersonType;
import com.mcafee.mdm.generated.PartyPersonXrefType;
import com.mcafee.mdm.generated.PartyRel;
import com.mcafee.mdm.generated.PartyRelationshipType;
import com.mcafee.mdm.generated.PartyRelationshipXrefType;
import com.mcafee.mdm.generated.PartyType;
import com.mcafee.mdm.generated.PartyXrefType;
import com.mcafee.mdm.generated.XREFType;
import com.mcafee.mdm.util.CanonicalFormManipulator;
import com.mcafee.mdm.util.CommonUtil;
import com.mcafee.mdm.util.JDBCConnectionProvider;
import com.mcafee.mdm.util.ObjectPool;
import com.mcafee.mdm.util.PropertyUtil;
import com.mcafee.mdm.util.Util;
import com.siperian.sif.client.SiperianClient;
import com.siperian.sif.message.Record;
import com.siperian.sif.message.RecordKey;
import com.siperian.sif.message.mrm.GetRequest;
import com.siperian.sif.message.mrm.GetResponse;

@Component
public class GetPartyDAO extends ObjectPool {
	
	private static final Logger LOG = Logger.getLogger(GetPartyDAO.class.getName());
	Properties configProps = PropertyUtil.getPropertiesFromFile("configProp");
	private String sipPopFromXref = null;


	public String getSipPopFromXref() {
		return sipPopFromXref;
	}
	public void setSipPopFromXref(String sipPopFromXref) {
		this.sipPopFromXref = sipPopFromXref;
	}
	@Autowired
	SearchPartyDAO searchDao;
	@Autowired
	private CommonUtil commonUtil;
	
	public PartyXrefType getParty(String partyID) throws ServiceProcessingException {
			LOG.info("Executing getParty()");
	
			PartyXrefType partyResponse = null;
			SiperianClient siperianClient = null;
	
			GetRequest request = new GetRequest();
			GetResponse response = null;
			RecordKey recordKey = new RecordKey();
			recordKey.setRowid(partyID);
			request.setRecordKey(recordKey); //Required
			request.setSiperianObjectUid("PACKAGE.PKG_XREF_FOR_SEARCH"); //Required
	
			try {
				siperianClient = (SiperianClient) checkOut();
				
				LOG.info("processing GetRequest for partyID " + partyID);
				response = (GetResponse) siperianClient.process(request);
				LOG.info("after response");
				
				if (response != null && response.getRecords().size() > 0) {
					LOG.info("GetRequest rec cnt= "+ response.getRecords().size());
					partyResponse = processXrefCopyResults(response.getRecords());

				}
			} catch (ServiceProcessingException spEx) {
				throw spEx;
			} catch (Exception excp) {
				LOG.error("Exception occurred while fetching Party golden copy: " + excp.getMessage());
				ServiceProcessingException customException = new ServiceProcessingException(excp);
				customException.setMessage("Failed to fetch Party golden copy." + customException.getMessage());
				throw customException;
			} finally {
				checkIn(siperianClient);
			}
			LOG.info("Executed getParty()");
			return partyResponse;
		}
	
	
	private PartyXrefType processXrefCopyResults(List searchRecords) throws ServiceProcessingException {
		LOG.info("Executing processXrefCopyResults()");

		PartyXrefType partyResponse = null;
		XREFType xref = null;
		CommunicationXrefType communication = null;
		AccountXrefType accInfo = null;
		AddressXrefType address = null;
		ClassificationXrefType classfction = null;
		PartyOrgExtXrefType partyOrgExt = null;
		PartyPersonExtXrefType partyPersonExt = null;
		PartyRelationshipXrefType partyRelationship = null;
		
		/** Modified for M4M START */
		PartyAccountRelationshipXrefType partyAccountRelationship = null;
		/** Modified for M4M END */
		
		List<XREFType> listXref = null;

		//Map<String, SearchedRecordCollection> searchedRecCollMap = new HashMap<String, SearchedRecordCollection>();
		//SearchedRecordCollection searchedRecCollObj = null;
		// boolean bUniqueRec = false;
		try {
			if (searchRecords != null && searchRecords.size() != 0) {
				for (Iterator iter = searchRecords.iterator(); iter.hasNext();) {
					
					Record record = (Record) iter.next();
					
					String partyRowIdXref = record.getField("PARTY_ROWID_OBJECT").getStringValue();
						
					LOG.debug("============setting PartyResponse");
					partyResponse = new PartyXrefType();
					
					if (record.getField("PARTY_ROWID_OBJECT").getStringValue() != null) {

						partyResponse.setROWIDOBJECT(record.getField("PARTY_ROWID_OBJECT").getStringValue());
						
					}
					if (record.getField("ORIG_ROWID_OBJECT").getStringValue() != null) {

						partyResponse.setORIGROWIDOBJECT(record.getField("ORIG_ROWID_OBJECT").getStringValue());
					
					}
					if (record.getField("BO_CLASS_CODE").getStringValue() != null) {
						
						partyResponse.setBOCLASSCODE(record.getField("BO_CLASS_CODE").getStringValue());
					
					}
					if (record.getField("PARTY_TYPE").getStringValue() != null) {
						
						partyResponse.setPARTYTYPE(record.getField("PARTY_TYPE").getStringValue());
						
					}
					if (record.getField("PARTY_NAME").getStringValue() != null) {
						
						partyResponse.setPARTYNAME(record.getField("PARTY_NAME").getStringValue());
					}
					if (record.getField("PARTY_GEO").getStringValue() != null) {
						partyResponse.setGEO(record.getField("PARTY_GEO").getStringValue());
					}
					if (record.getField("PARTY_REGION").getStringValue() != null) {
						partyResponse.setREGION(record.getField("PARTY_REGION").getStringValue());
					}
					if (record.getField("STATUS_CD").getStringValue() != null) {
						partyResponse.setSTATUSCD(record.getField("STATUS_CD").getStringValue());
					}
					if (record.getField("PARTY_VAT_REG_NBR").getStringValue() != null) {
						partyResponse.setVATREGNBR(record.getField("PARTY_VAT_REG_NBR").getStringValue());
					}
					if (record.getField("PARTY_TAX_JURSDCTN_CD").getStringValue() != null) {
						partyResponse.setTAXJURSDCTNCD(record.getField("PARTY_TAX_JURSDCTN_CD").getStringValue());
					}
					if (record.getField("SALES_BLOCK_CD").getStringValue() != null) {
						partyResponse.setSALESBLOCKCD(record.getField("SALES_BLOCK_CD").getStringValue());
					}
					if (record.getField("UCN").getStringValue() != null) {
						partyResponse.setUCN(record.getField("UCN").getStringValue());
					}
					if (record.getField("ENGLISH_NAME").getStringValue() != null) {
						partyResponse.setENGLISHNAME(record.getField("ENGLISH_NAME").getStringValue());
					}

	
					
					LOG.debug("============setting XREFType");
					xref = new XREFType();
					xref.setSRCSYSTEM(record.getField("PARTY_ROWID_SYSTEM").getStringValue());
					xref.setSRCPKEY(record.getField("PARTY_PKEY_SRC_OBJECT").getStringValue());
					
					LOG.debug("===Inserting into XREFType list===");
					listXref = new ArrayList<XREFType>();
					listXref.add(xref);
					partyResponse.getXREF().addAll(listXref);	
					

					
					LOG.debug("============setting AccountType");
					if (record.getField("ACCOUNT_ROWID_OBJECT").getStringValue() != null ) {
						
					LOG.debug("============setting AccountType");
					accInfo = new AccountXrefType();
					
					if (record.getField("ACCOUNT_ROWID_OBJECT").getStringValue() != null) {
						accInfo.setROWIDACCOUNT(record.getField(
								"ACCOUNT_ROWID_OBJECT").getStringValue());
					}
					if (record.getField("ACCOUNT_ROWID_SYSTEM").getStringValue() != null) {
						accInfo.setSRCSYSTEM(record.getField(
								"ACCOUNT_ROWID_SYSTEM").getStringValue());
					}
					if (record.getField("ACCOUNT_PKEY_SRC_OBJECT").getStringValue() != null) {
						accInfo.setSRCPKEY(record.getField(
								"ACCOUNT_PKEY_SRC_OBJECT").getStringValue());
					}
					
					if (record.getField("ACCT_NAME").getStringValue() != null) {
						accInfo.setACCTNAME(record.getField("ACCT_NAME")
								.getStringValue());
					}
					if (record.getField("ALIAS_NAME").getStringValue() != null) {
						accInfo.setALIASNAME(record.getField("ALIAS_NAME")
								.getStringValue());
					}
					if (record.getField("ACCT_STATUS").getStringValue() != null) {
						accInfo.setACCTSTATUS(record
								.getField("ACCT_STATUS").getStringValue());
					}
					if (record.getField("ACCT_TYPE").getStringValue() != null) {
						accInfo.setACCTTYPE(record.getField("ACCT_TYPE")
								.getStringValue());
					}
					if (record.getField("ACCOUNT_REGION").getStringValue() != null) {
						accInfo.setACCOUNTREGION(record.getField(
								"ACCOUNT_REGION").getStringValue());
					}
					if (record.getField("ACCOUNT_GEO").getStringValue() != null) {
						accInfo.setACCOUNTGEO(record
								.getField("ACCOUNT_GEO").getStringValue());
					}
					if (record.getField("MARKET").getStringValue() != null) {
						accInfo.setMARKET(record.getField("MARKET")
								.getStringValue());
					}
					if (record.getField("CUST_GROUP").getStringValue() != null) {
						accInfo.setCUSTGROUP(record.getField("CUST_GROUP")
								.getStringValue());
					}
					if (record.getField("PRICE_GROUP").getStringValue() != null) {
						accInfo.setPRICEGROUP(record
								.getField("PRICE_GROUP").getStringValue());
					}
					if (record.getField("COMPANY_CD").getStringValue() != null) {
						accInfo.setCOMPANYCD(record.getField("COMPANY_CD")
								.getStringValue());
					}
					if (record.getField("ACCOUNT_VAT_REG_NBR")
							.getStringValue() != null) {
						accInfo.setACCOUNTVATREGNBR(record.getField(
								"ACCOUNT_VAT_REG_NBR").getStringValue());
					}
					if (record.getField("TAX_TYPE").getStringValue() != null) {
						accInfo.setTAXTYPE(record.getField("TAX_TYPE")
								.getStringValue());
					}
					if (record.getField("ACCOUNT_TAX_JURDSCTN_CD")
							.getStringValue() != null) {
						accInfo.setACCOUNTTAXJURSDCTNCD(record.getField(
								"ACCOUNT_TAX_JURDSCTN_CD").getStringValue());
					}
					if (record.getField("BILL_BLOCK_CD").getStringValue() != null) {
						accInfo.setBILLBLOCKCD(record.getField(
								"BILL_BLOCK_CD").getStringValue());
					}
					if (record.getField("ORDR_BLOCK_CD").getStringValue() != null) {
						accInfo.setORDRBLOCKCD(record.getField(
								"ORDR_BLOCK_CD").getStringValue());
					}
					if (record.getField("DLVRY_BLOCK_CD").getStringValue() != null) {
						accInfo.setDLVRYBLOCKCD(record.getField(
								"DLVRY_BLOCK_CD").getStringValue());
					}
					if (record.getField("POST_BLOCK_CD").getStringValue() != null) {
						accInfo.setPOSTBLOCKCD(record.getField(
								"POST_BLOCK_CD").getStringValue());
					}
					if (record.getField("SALE_BLOCK_CD").getStringValue() != null) {
						accInfo.setSALEBLOCKCD(record.getField(
								"SALE_BLOCK_CD").getStringValue());
					}
					if (record.getField("CHANNEL_ID").getStringValue() != null) {
						accInfo.setCHANNELID(record.getField("CHANNEL_ID")
								.getStringValue());
					}
					if (record.getField("PARTNER_TYPE").getStringValue() != null) {
						accInfo.setPARTNERTYPE(record.getField(
								"PARTNER_TYPE").getStringValue());
					}
					if (record.getField("VENDOR_NBR").getStringValue() != null) {
						accInfo.setVENDORNBR(record.getField("VENDOR_NBR")
								.getStringValue());
					}
					if (record.getField("DIRECT_IND").getStringValue() != null) {
						accInfo.setDIRECTIND(record.getField("DIRECT_IND")
								.getStringValue());
					}
					if (record.getField("NAMED_ACCT_IND").getStringValue() != null) {
						accInfo.setNAMEDACCTIND(record.getField(
								"NAMED_ACCT_IND").getStringValue());
					}
					if (record.getField("NON_VAL_ACCT_IND")
							.getStringValue() != null) {
						accInfo.setNONVALACCTIND(record.getField(
								"NON_VAL_ACCT_IND").getStringValue());
					}
					if (record.getField("PARTNER_IND").getStringValue() != null) {
						accInfo.setPARTNERIND(record
								.getField("PARTNER_IND").getStringValue());
					}
					if (record.getField("SIEBEL_ROWID").getStringValue() != null) {
						accInfo.setSIEBELROWID(record
								.getField("SIEBEL_ROWID").getStringValue());
					}
					if (record.getField("SAP_CUST_NUMBER").getStringValue() != null) {
						accInfo.setSAPCUSTNUMBER(record
								.getField("SAP_CUST_NUMBER").getStringValue());
					}
					if (record.getField("MDM_LEGACY_ID").getStringValue() != null) {
						accInfo.setMDMLEGACYID(record.getField("MDM_LEGACY_ID").getStringValue());
					}
					if (record.getField("SAP_NAME_1").getStringValue() != null) {
						accInfo.setSAPNAME1(record.getField("SAP_NAME_1").getStringValue());
					}
					if (record.getField("SAP_NAME_2").getStringValue() != null) {
						accInfo.setSAPNAME2(record.getField("SAP_NAME_2").getStringValue());
					}
					if (record.getField("SAP_NAME_3").getStringValue() != null) {
						accInfo.setSAPNAME3(record.getField("SAP_NAME_3").getStringValue());
					}
					if (record.getField("SAP_NAME_4").getStringValue() != null) {
						accInfo.setSAPNAME4(record.getField("SAP_NAME_4").getStringValue());
					}

					LOG.debug("===Inserting into AccountType Map===");

			}			
					
					
					LOG.debug("============setting AddressType");
					if (record.getField("ADDRESS_ROWID_OBJECT").getStringValue() != null ) {
						
					
					address = new AddressXrefType();
					if (record.getField("ADDRESS_ROWID_OBJECT").getStringValue() != null) {
						address.setROWIDADDRESS(record.getField(
								"ADDRESS_ROWID_OBJECT").getStringValue());
					}
					if (record.getField("ADDRESS_ROWID_SYSTEM").getStringValue() != null) {
						address.setSRCSYSTEM(record.getField(
								"ADDRESS_ROWID_SYSTEM").getStringValue());
					}
					if (record.getField("ADDRESS_PKEY_SRC_OBJECT").getStringValue() != null) {
						address.setSRCPKEY(record.getField(
								"ADDRESS_PKEY_SRC_OBJECT").getStringValue());
					}
					if (record.getField("ADDR_LN1").getStringValue() != null) {
						address.setADDRLN1(record.getField("ADDR_LN1")
								.getStringValue());
					}
					if (record.getField("ADDR_LN2").getStringValue() != null) {
						address.setADDRLN2(record.getField("ADDR_LN2")
								.getStringValue());
					}
					if (record.getField("ADDR_LN3").getStringValue() != null) {
						address.setADDRLN3(record.getField("ADDR_LN3")
								.getStringValue());
					}
					if (record.getField("ADDR_LN4").getStringValue() != null) {
						address.setADDRLN4(record.getField("ADDR_LN4")
								.getStringValue());
					}
					if (record.getField("CITY").getStringValue() != null) {
						address.setCITY(record.getField("CITY")
								.getStringValue());
					}
					if (record.getField("COUNTY").getStringValue() != null) {
						address.setCOUNTY(record.getField("COUNTY")
								.getStringValue());
					}
					if (record.getField("DISTRICT").getStringValue() != null) {
						address.setDISTRICT(record.getField("DISTRICT")
								.getStringValue());
					}
					if (record.getField("STATE_CD").getStringValue() != null) {
						address.setSTATECD(record.getField("STATE_CD")
								.getStringValue());
					}
					if (record.getField("POSTAL_CD").getStringValue() != null) {
						address.setPOSTALCD(record.getField("POSTAL_CD")
								.getStringValue());
					}
					if (record.getField("COUNTRY_CD").getStringValue() != null) {
						address.setCOUNTRYCD(record.getField("COUNTRY_CD")
								.getStringValue());
					}
					if (record.getField("LANG_CD").getStringValue() != null) {
						address.setLANGCD(record.getField("LANG_CD")
								.getStringValue());
					}
					if (record.getField("LONGITUDE").getStringValue() != null) {
						address.setLONGITUDE(record.getField("LONGITUDE")
								.getStringValue());
					}
					if (record.getField("LATITUDE").getStringValue() != null) {
						address.setLATITUDE(record.getField("LATITUDE")
								.getStringValue());
					}
					if (record.getField("ADDR_TYPE").getStringValue() != null) {
						address.setADDRTYPE(record.getField("ADDR_TYPE")
								.getStringValue());
					}
					if (record.getField("ADDR_STATUS").getStringValue() != null) {
						address.setADDRSTATUS(record
								.getField("ADDR_STATUS").getStringValue());
					}

					LOG.debug("===Inserting into Address Map===");

			}
					
					
					
					
					LOG.debug("============adding CommunicationType ");
					if (record.getField("COMMUNICATION_ROWID_OBJECT").getStringValue() != null ) {
						
					
					communication = new CommunicationXrefType();
					LOG.debug("============adding CommunicationType ");

					if (record.getField("COMMUNICATION_ROWID_OBJECT")
							.getStringValue() != null) {
						communication.setROWIDCOMMUNICATION(record
								.getField("COMMUNICATION_ROWID_OBJECT")
								.getStringValue());
					}
					if (record.getField("COMMUNICATION_ROWID_SYSTEM")
							.getStringValue() != null) {
						communication.setSRCSYSTEM(record
								.getField("COMMUNICATION_ROWID_SYSTEM")
								.getStringValue());
					}
					if (record.getField("COMMUNICATION_PKEY_SRC_OBJECT")
							.getStringValue() != null) {
						communication.setSRCPKEY(record
								.getField("COMMUNICATION_PKEY_SRC_OBJECT")
								.getStringValue());
					}
					if (record.getField("COMM_TYPE").getStringValue() != null) {
						communication.setCOMMTYPE(record.getField(
								"COMM_TYPE").getStringValue());
					}
					if (record.getField("COMM_VALUE").getStringValue() != null) {
						communication.setCOMMVALUE(record.getField(
								"COMM_VALUE").getStringValue());
					}
					if (record.getField("COMM_STATUS").getStringValue() != null) {
						communication.setCOMMSTATUS(record.getField(
								"COMM_STATUS").getStringValue());
					}
					if (record.getField("PRFRD_COMM_IND").getStringValue() != null) {
						communication.setPRFRDCOMMIND(record.getField(
								"PRFRD_COMM_IND").getStringValue());
					}
					if (record.getField("WEB_DOMAIN").getStringValue() != null) {
						communication.setWEBDOMAIN(record.getField(
								"WEB_DOMAIN").getStringValue());
					}

					LOG.debug("===Inserting into Communication Map===");

			}
					
					
					
					LOG.debug("============adding PartyOrgExtType ");
					if (record.getField("PARTY_ORG_ROWID_OBJECT").getStringValue() != null ) {
						
					
					partyOrgExt = new PartyOrgExtXrefType();
					LOG.debug("============adding PartyOrgExtType ");

					if (record.getField("PARTY_ORG_ROWID_OBJECT").getStringValue() != null) {
						partyOrgExt.setROWIDORGEXTN(record.getField(
								"PARTY_ORG_ROWID_OBJECT").getStringValue());
					}
					if (record.getField("PARTY_ORG_PKEY_SRC_OBJECT").getStringValue() != null) {
						partyOrgExt.setSRCPKEY(record.getField(
								"PARTY_ORG_PKEY_SRC_OBJECT").getStringValue());
					}
					if (record.getField("PARTY_ORG_ROWID_SYSTEM").getStringValue() != null) {
						partyOrgExt.setSRCSYSTEM(record.getField(
								"PARTY_ORG_ROWID_SYSTEM").getStringValue());
					}
					if (record.getField("ORG_DUNS_NBR").getStringValue() != null) {
						partyOrgExt.setORGDUNSNBR(record.getField(
								"ORG_DUNS_NBR").getStringValue());
					}
					if (record.getField("TRADE_NAME").getStringValue() != null) {
						partyOrgExt.setTRADENAME(record.getField(
								"TRADE_NAME").getStringValue());
					}
					if (record.getField("TRADE_NAME_2").getStringValue() != null) {
						partyOrgExt.setTRADENAME2(record.getField(
								"TRADE_NAME_2").getStringValue());
					}
					if (record.getField("SITE_EMPL_CNT").getStringValue() != null) {
						partyOrgExt.setSITEEMPLCNT(record.getField(
								"SITE_EMPL_CNT").getStringValue());
					}
					if (record.getField("GLBL_EMPL_CNT").getStringValue() != null) {
						partyOrgExt.setGLBLEMPLCNT(record.getField(
								"GLBL_EMPL_CNT").getStringValue());
					}
					if (record.getField("VERTICAL").getStringValue() != null) {
						partyOrgExt.setVERTICAL(record.getField("VERTICAL")
								.getStringValue());
					}
					if (record.getField("REVENUE").getStringValue() != null) {
						partyOrgExt.setREVENUE(record.getField("REVENUE")
								.getStringValue());
					}
					if (record.getField("LINE_OF_BUS").getStringValue() != null) {
						partyOrgExt.setLINEOFBUS(record.getField(
								"LINE_OF_BUS").getStringValue());
					}
					if (record.getField("PRIM_SIC").getStringValue() != null) {
						partyOrgExt.setPRIMSIC(record.getField("PRIM_SIC")
								.getStringValue());
					}
					if (record.getField("SEC_SIC").getStringValue() != null) {
						partyOrgExt.setSECSIC(record.getField("SEC_SIC")
								.getStringValue());
					}
					if (record.getField("SALES_VOLUME").getStringValue() != null) {
						partyOrgExt.setSALESVOLUME(record.getField(
								"SALES_VOLUME").getStringValue());
					}
					if (record.getField("SALES_AMOUNT").getStringValue() != null) {
						partyOrgExt.setSALESAMOUNT(record.getField(
								"SALES_AMOUNT").getStringValue());
					}
					if (record.getField("CURRENCY_CD").getStringValue() != null) {
						partyOrgExt.setCURRENCYCD(record.getField(
								"CURRENCY_CD").getStringValue());
					}
					if (record.getField("OUT_OF_BUS_IND").getStringValue() != null) {
						partyOrgExt.setOUTOFBUSIND(record.getField(
								"OUT_OF_BUS_IND").getStringValue());
					}
					if (record.getField("GLBL_ULT_IND").getStringValue() != null) {
						partyOrgExt.setGLBLULTIND(record.getField(
								"GLBL_ULT_IND").getStringValue());
					}
					if (record.getField("FORTUNE_INFO").getStringValue() != null) {
						partyOrgExt.setFORTUNEINFO(record.getField(
								"FORTUNE_INFO").getStringValue());
					}
					if (record.getField("HIERARCHY_LEVEL").getStringValue() != null) {
						partyOrgExt.setHIERARCHYLEVEL(record.getField(
								"HIERARCHY_LEVEL").getStringValue());
					}
					if (record.getField("ORG_HQ_PARENT_DUNS").getStringValue() != null) {
						partyOrgExt.setORGHQPARENTDUNS(record.getField(
								"ORG_HQ_PARENT_DUNS").getStringValue());
					}
					if (record.getField("ORG_DOM_ULT_DUNS").getStringValue() != null) {
						partyOrgExt.setORGDOMULTDUNS(record.getField(
								"ORG_DOM_ULT_DUNS").getStringValue());
					}
					if (record.getField("ORG_GLB_ULT_DUNS").getStringValue() != null) {
						partyOrgExt.setORGGLBULTDUNS(record.getField(
								"ORG_GLB_ULT_DUNS").getStringValue());
					}

					LOG.debug("===Inserting into PartyOrgExtType Map==");

			}		
					
					
					LOG.debug("============adding PartyPersonExtType ");
					if (record.getField("PARTY_PERSON_ROWID_OBJECT").getStringValue() != null ) {
						
					
					partyPersonExt = new PartyPersonExtXrefType();
					LOG.debug("============adding PartyPersonExtType ");

					if (record.getField("PARTY_PERSON_ROWID_OBJECT").getStringValue() != null) {
						partyPersonExt.setROWIDPRSNEXTN(record.getField(
								"PARTY_PERSON_ROWID_OBJECT").getStringValue());
					}
					if (record.getField("PARTY_PERSON_PKEY_SRC_OBJECT").getStringValue() != null) {
						partyPersonExt.setSRCPKEY(record.getField(
								"PARTY_PERSON_PKEY_SRC_OBJECT").getStringValue());
					}
					if (record.getField("PARTY_PERSON_ROWID_SYSTEM").getStringValue() != null) {
						partyPersonExt.setSRCSYSTEM(record.getField(
								"PARTY_PERSON_ROWID_SYSTEM").getStringValue());
					}
					if (record.getField("PREFIX").getStringValue() != null) {
						partyPersonExt.setPREFIX(record.getField("PREFIX")
								.getStringValue());
					}
					if (record.getField("FIRST_NAME").getStringValue() != null) {
						partyPersonExt.setFIRSTNAME(record.getField(
								"FIRST_NAME").getStringValue());
					}
					if (record.getField("MIDDLE_NAME").getStringValue() != null) {
						partyPersonExt.setLASTNAME(record.getField(
								"MIDDLE_NAME").getStringValue());
					}
					if (record.getField("LAST_NAME").getStringValue() != null) {
						partyPersonExt.setLASTNAME(record.getField(
								"LAST_NAME").getStringValue());
					}
					if (record.getField("SUFFIX").getStringValue() != null) {
						partyPersonExt.setSUFFIX(record.getField("SUFFIX")
								.getStringValue());
					}
					if (record.getField("PERSON_TYPE").getStringValue() != null) {
						partyPersonExt.setPERSONTYPE(record.getField(
								"PERSON_TYPE").getStringValue());
					}

					LOG.debug("===Inserting into PartyPersonExtType List===");
			}
					
					LOG.debug("============adding ClassificationType ");
					if (record.getField("PARTY_CLASS_ROWID_OBJECT").getStringValue() != null ) {
						
					
					classfction = new ClassificationXrefType();

					if (record.getField("PARTY_CLASS_ROWID_OBJECT")
							.getStringValue() != null) {
						classfction.setROWIDCLASSIFICTN(record.getField("PARTY_CLASS_ROWID_OBJECT").getStringValue());
					}
					if (record.getField("PARTY_CLASS_PKEY_SRC_OBJECT")
							.getStringValue() != null) {
						classfction.setSRCPKEY(record.getField("PARTY_CLASS_PKEY_SRC_OBJECT").getStringValue());
					}
					if (record.getField("PARTY_CLASS_ROWID_SYSTEM")
							.getStringValue() != null) {
						classfction.setSRCSYSTEM(record.getField("PARTY_CLASS_ROWID_SYSTEM").getStringValue());
					}
					if (record.getField("CLASSIFCTN_TYPE").getStringValue() != null) {
						classfction.setCLASSIFICTNTYPE(record.getField(
								"CLASSIFCTN_TYPE").getStringValue());
					}
					if (record.getField("CLASSIFCTN_VALUE").getStringValue() != null) {
						classfction.setCLASSIFICTNVALUE(record.getField(
								"CLASSIFCTN_VALUE").getStringValue());
					}
					if (record.getField("START_DATE").getStringValue() != null) {
						classfction.setSTARTDATE(record.getField(
								"START_DATE").getStringValue());
					}
					if (record.getField("END_DATE").getStringValue() != null) {
						classfction.setENDDATE(record.getField(
								"END_DATE").getStringValue());
					}
					


			}
					LOG.debug("============adding RelationshipType ");
					if (record.getField("PARTY_REL_ROWID_CHILD").getStringValue() != null  ) {
						
					
					partyRelationship = new PartyRelationshipXrefType();
					
					/** Modified for M4M START */
					partyAccountRelationship = new PartyAccountRelationshipXrefType();

					if (record.getField("PARTY_REL_ROWID_PARENT")
							.getStringValue() != null) {
				//		partyRelationship.setPARENTROWIDPARTY(record.getField("PARTY_REL_ROWID_PARENT").getStringValue());
					}
					if (record.getField("PARTY_REL_PKEY_SRC_OBJECT")
							.getStringValue() != null) {
						partyAccountRelationship.setSRCPKEY(record.getField("PARTY_REL_PKEY_SRC_OBJECT").getStringValue());
					}
					if (record.getField("PARTY_REL_ROWID_SYSTEM")
							.getStringValue() != null) {
						partyAccountRelationship.setSRCSYSTEM(record.getField("PARTY_REL_ROWID_SYSTEM").getStringValue());
					}
					if (record.getField("ROWID_REL_TYPE").getStringValue() != null) {
						partyAccountRelationship.setRELTYPE(record.getField(
								"ROWID_REL_TYPE").getStringValue());
					}
					if (record.getField("ROWID_HIERARCHY").getStringValue() != null) {
						partyAccountRelationship.setHIERARCHYTYPE(record.getField(
								"ROWID_HIERARCHY").getStringValue());
					}
					
					partyRelationship.getPARTYACCOUNTREL().add(partyAccountRelationship);
					
					/** Modified for M4M END */

			}
				
				LOG.debug("====Populating PartyProfileList");
				
				partyResponse.getAccount().add(accInfo);
				partyResponse.getAddress().add(address);
				partyResponse.getCommunication().add(communication);
				partyResponse.getPartyOrgExt().add(partyOrgExt);
				partyResponse.getPartyPersonExt().add(partyPersonExt);
				partyResponse.getClassification().add(classfction);
				
				/** Modified for M4M START */
				partyResponse.setPartyRel(partyRelationship);
				/** Modified for M4M END */
					
			}
		}
		
		} catch (Exception exp) {
			LOG.error(" Caught Exception in processXrefCopyResults() in GetPartyDAO");
			exp.printStackTrace();
			ServiceProcessingException customException = new ServiceProcessingException(exp);
			customException.setMessage("Failed to process processXrefCopyResults() in GetPartyDAO." + customException.getMessage());
			throw customException;
		}
		LOG.info("Executed processXrefCopyResults()");
		
		return partyResponse;
	}
	//Reading SENT_TO values from SRC_DATA_FLOW_CONTROLLER table for Update LegacyRef Records
	public List<String> getSentToList(String operationType, String fromSrc, boolean isContactRec) throws ServiceProcessingException {
        	LOG.info("Executing getSentToList()");
        	List<String> sendToSrcList = new ArrayList<String>();
       
               JDBCConnectionProvider connProvider = null;
               Connection jdbcConnection = null;
               Statement statement = null;
               PreparedStatement pstatement = null;
               ResultSet resultSet = null;
               String opType = null;
               String sql = null;
               if(operationType.equalsIgnoreCase("Insert"))	{
            	   opType = "Create";
               } else if(operationType.equalsIgnoreCase("Update"))	{
            	   opType = "Update";
               }
               else{
            	   opType = "Create";
               }
               
               if (isContactRec){
            	   sql = "SELECT SEND_TO,OPERATION_NAME,CAME_FROM FROM CNTCT_DATA_FLW_RTING_CNTRLLR WHERE OPERATION_NAME = '" + opType + "' AND CAME_FROM = '" + fromSrc + "' AND EVENT = 'SYNCH_UPDATE'";
               }
               else{
            	   sql = "SELECT SEND_TO,OPERATION_NAME,CAME_FROM FROM DATA_FLOW_ROUTING_CONTROLLER WHERE OPERATION_NAME = '" + opType + "' AND CAME_FROM = '" + fromSrc + "' AND EVENT = 'SYNCH_UPDATE'";
               }
               LOG.info("Query Sent_ToList: "+sql);
               try {
                     //for each party create message object tree with canonical form of Golden copy, Xref copy, legacy Xref copy.
                     //For create event, need to add other Xrefs for target source systems
                     connProvider = JDBCConnectionProvider.getSingleInstance();
                     jdbcConnection = connProvider.getJdbcConnectionFromDS();
                    
                     LOG.info("Fetching Send-to source systems for update operations");
                     statement = jdbcConnection.createStatement();
                     resultSet = statement.executeQuery(sql);
                    
                     while (resultSet.next()) {
                    	 sendToSrcList.add(resultSet.getString(1)); 
                     }
                    
                     LOG.info("Number of records found in DATA_FLOW_CONTROLLER table = " + sendToSrcList.size());
               } catch (SQLException sqlEx) {
                     LOG.error("Exception occurred while fetching DATA_FLOW_CONTROLLER records: " + sqlEx);
                     sqlEx.printStackTrace();
                     ServiceProcessingException customException = new ServiceProcessingException(sqlEx);
                     customException.setMessage("Failed to fetch Party profile from ORS. " + customException.getMessage());
                     throw customException;
               } finally{
      				try {
      					if( resultSet != null) resultSet.close();
       					if( pstatement != null) pstatement.close();
       					if( statement != null) statement.close();
       					if(jdbcConnection != null) jdbcConnection.close();
       				} catch (SQLException e) {
       					
       					e.printStackTrace();
       				}
               }
  
       
        LOG.info("Executed getDataFlowToSrcList()");
       
        return sendToSrcList;
	}
	
	
	//fetch all party and child xref records 
	public PartyXrefType fetchPartyXrefTypeFromORS(String srcSYS, String srcPKEY, boolean p2cEligible) throws ServiceProcessingException {
		LOG.info("Executing fetchPartyXrefTypeFromORS()");
		
		PartyXrefType party = null;
		PreparedStatement pstatement = null;
		Statement statement = null;
		StringBuilder sqlQry = new StringBuilder();
		JDBCConnectionProvider jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();;
		Connection jdbcConnection = null;
		ResultSet resultSet = null;
		boolean activeorgExtnExist = false;
		boolean activeclfctnExist = false;
		
		try {
			LOG.info("Fetching Party profile for partySRCSYS: " + srcSYS);
			LOG.info("Fetching Party profile for partySRCPKEY: " + srcPKEY);
		//	String query = "SELECT * FROM PKG_XREF_FOR_SEARCH WHERE PARTY_ROWID_SYSTEM = ? AND PARTY_PKEY_SRC_OBJECT = ?";
			activeclfctnExist = commonUtil.checkActiveClsfnXrefcExist(srcPKEY);
			activeorgExtnExist = commonUtil.checkActiveOrgExtnXrefExist(srcPKEY);
			sqlQry.append("SELECT * FROM PKG_XREF_FOR_SEARCH WHERE PARTY_ROWID_SYSTEM = '");
			sqlQry.append(srcSYS + "' AND PARTY_PKEY_SRC_OBJECT = '");
			sqlQry.append(srcPKEY + "'");
			if (p2cEligible || (!activeclfctnExist) || (!activeorgExtnExist)){
				sqlQry.append(" AND HUB_STATE_IND = '1'");
			}else{
			sqlQry.append(" AND HUB_STATE_IND = '" + 1 + "'" + "AND NVL(ORG_EXTN_HUB_STATE_IND,1) <> '-1' AND NVL(CLASSIFCTN_HUB_STATE_IND,1) <> '-1'");
			
			}
			sqlQry.append(" AND nvl(trunc(END_DATE),'31-DEC-9999') = '31-DEC-9999'");
			sqlQry.append(" Order by PARTY_CLASS_ROWID_OBJECT, END_DATE");
			
		//	sqlQry.append("SELECT * FROM PKG_XREF_FOR_SEARCH WHERE PARTY_ROWID_SYSTEM = ? AND PARTY_PKEY_SRC_OBJECT = ?");
			
			LOG.debug("Query to fetch insertedPartyData: " + sqlQry);
			
			jdbcConnection = jDBCConnectionProvider.getJdbcConnectionFromDS();
			statement = jdbcConnection.createStatement();
			resultSet = statement.executeQuery(sqlQry.toString());
		//	pstatement = jdbcConnection.prepareStatement(sqlQry.toString());
		//	pstatement.setString(1, srcSYS);
		//	pstatement.setString(2, srcPKEY);
			
		//	resultSet = pstatement.executeQuery();
			party = createXrefCanonicalForm(resultSet);
			
		} catch (SQLException sqlEx) {
			LOG.error("Exception occurred while fetching Party profile: " + sqlEx);
			sqlEx.printStackTrace();
			ServiceProcessingException customException = new ServiceProcessingException(sqlEx);
			customException.setMessage("Failed to fetch Party profile from ORS." + customException.getMessage());
			throw customException;
		} finally {
			try {
					if( resultSet != null) resultSet.close();
					if( pstatement != null) pstatement.close();
					if( statement != null) statement.close();
					if(jdbcConnection != null) jdbcConnection.close();
				} catch (SQLException e) {
					
					e.printStackTrace();
				}
		}
		
		LOG.info("Executed fetchPartyXrefTypeFromORS()");
		
		return party;
	}

	/*SAP-SBL Account XREF Cannonical Structure*/
	public PartyXrefType createXrefCanonicalForm(ResultSet resultSet) throws SQLException {
		LOG.info("Executing createXrefCanonicalForm()");
		PartyXrefType party = null;
		XREFType xref = null;
		CommunicationXrefType communication = null;
		AccountXrefType accInfo = null;
		AddressXrefType address = null;
		ClassificationXrefType classfction = null;
		PartyOrgExtXrefType partyOrgExt = null;
		PartyRelationshipXrefType partyRelationship = null;
		
		/** Modified for M4M START */
		PartyAccountRelationshipXrefType partyAccountRelationship = null;
		/** Modified for M4M END */
		
		ArrayList<XREFType> listXref = null;
		

		Map<String, SearchedXrefRecordCollection> searchedRecCollMap = new HashMap<String, SearchedXrefRecordCollection>();
		SearchedXrefRecordCollection searchedRecCollObj = null;
		boolean bUniqueRec = false;
		
		while (resultSet.next()) {
			String partyRowId = resultSet.getString("ORIG_ROWID_OBJECT");
			
			if (!searchedRecCollMap.containsKey(partyRowId)) {
				
				LOG.debug("Populate searchedXrefRecCollMap for new PARTY_ROWID " + partyRowId);
				searchedRecCollMap.put(partyRowId, new SearchedXrefRecordCollection());
				bUniqueRec = true;
			}

			searchedRecCollObj = searchedRecCollMap.get(partyRowId);

			if(bUniqueRec)	{
				
			//	LOG.debug("============setting Xref Copy");
				
				party = new PartyXrefType();
				party.setROWIDOBJECT(resultSet.getString("PARTY_ROWID_OBJECT"));
				searchedRecCollObj.setParty_rowid(resultSet.getString("PARTY_ROWID_OBJECT"));
				party.setBOCLASSCODE(resultSet.getString("BO_CLASS_CODE"));
				searchedRecCollObj.setBo_class(resultSet.getString("BO_CLASS_CODE"));
				party.setPARTYTYPE(resultSet.getString("PARTY_TYPE"));
				searchedRecCollObj.setParty_type(resultSet.getString("PARTY_TYPE"));
				party.setPARTYNAME(resultSet.getString("PARTY_NAME"));
				searchedRecCollObj.setParty_name(resultSet.getString("PARTY_NAME"));
				party.setGEO(resultSet.getString("PARTY_GEO"));
				searchedRecCollObj.setGeo(resultSet.getString("PARTY_GEO"));
				party.setREGION(resultSet.getString("PARTY_REGION"));
				searchedRecCollObj.setRegion(resultSet.getString("PARTY_REGION"));
				party.setSTATUSCD(resultSet.getString("STATUS_CD"));
				searchedRecCollObj.setStatus_cd(resultSet.getString("STATUS_CD"));
				party.setVATREGNBR(resultSet.getString("PARTY_VAT_REG_NBR"));
				searchedRecCollObj.setVat_regno(resultSet.getString("PARTY_VAT_REG_NBR"));
				party.setTAXJURSDCTNCD(resultSet.getString("PARTY_TAX_JURSDCTN_CD"));
				searchedRecCollObj.setTax_jd_cd(resultSet.getString("PARTY_TAX_JURSDCTN_CD"));
				party.setSALESBLOCKCD(resultSet.getString("SALES_BLOCK_CD"));
				searchedRecCollObj.setSales_cd(resultSet.getString("SALES_BLOCK_CD"));
				party.setUCN(resultSet.getString("UCN"));
				searchedRecCollObj.setUcn(resultSet.getString("UCN"));
				sipPopFromXref = resultSet.getString("SIP_POP");
				party.setENGLISHNAME(resultSet.getString("ENGLISH_NAME"));
				searchedRecCollObj.setEnglish_name(resultSet.getString("ENGLISH_NAME"));
				searchedRecCollObj.setLegacyUcn(resultSet.getString("LEGACY_UCN"));
				party.setLEGACYUCN(resultSet.getString("LEGACY_UCN"));
				searchedRecCollObj.setDnbdbaname(resultSet.getString("DNB_DBA_NAME"));
				
				/** Modified for M4M START */
				party.setDNBDBANAME(resultSet.getString("DNB_DBA_NAME"));
				searchedRecCollObj.setDnbsectradestyle(resultSet.getString("DNB_SECOND_TRADE_STYLE"));
				party.setDNBSECONDTRADESTYLE(resultSet.getString("DNB_SECOND_TRADE_STYLE"));
				searchedRecCollObj.setDnbregname(resultSet.getString("DNB_REG_NAME"));
				party.setDNBREGNAME(resultSet.getString("DNB_REG_NAME"));
				/** Modified for M4M END */
				
				LOG.debug("============setting PartyXREFType");
				xref = new XREFType();
				xref.setSRCSYSTEM(resultSet.getString("PARTY_ROWID_SYSTEM"));
				xref.setSRCPKEY(resultSet.getString("PARTY_PKEY_SRC_OBJECT"));
				
			//	LOG.debug("===Inserting into XREFType list===");
				listXref = new ArrayList<XREFType>();
				listXref.add(xref);
				party.getXREF().addAll(listXref);
				
			}
			
			if (resultSet.getString("ACCOUNT_ROWID_OBJECT") != null &&
					!searchedRecCollObj.getAccountMap().containsKey(resultSet.getString("ACCOUNT_ROWID_OBJECT"))) {
				LOG.debug("============setting Account info");
				accInfo = new AccountXrefType();
				accInfo.setROWIDACCOUNT(resultSet.getString("ACCOUNT_ROWID_OBJECT"));
				accInfo.setSRCSYSTEM(resultSet.getString("ACCOUNT_ROWID_SYSTEM"));
				accInfo.setSRCPKEY(resultSet.getString("ACCOUNT_PKEY_SRC_OBJECT"));
				accInfo.setACCTNAME(resultSet.getString("ACCT_NAME"));
				accInfo.setALIASNAME(resultSet.getString("ALIAS_NAME"));
				accInfo.setACCTSTATUS(resultSet.getString("ACCT_STATUS"));
				accInfo.setACCTTYPE(resultSet.getString("ACCT_TYPE"));
				accInfo.setACCOUNTREGION(resultSet.getString("ACCOUNT_REGION"));
				accInfo.setACCOUNTGEO(resultSet.getString("ACCOUNT_GEO"));
				accInfo.setMARKET(resultSet.getString("MARKET"));
				accInfo.setCUSTGROUP(resultSet.getString("CUST_GROUP"));
				accInfo.setPRICEGROUP(resultSet.getString("PRICE_GROUP"));
				accInfo.setCOMPANYCD(resultSet.getString("COMPANY_CD"));
				accInfo.setACCOUNTVATREGNBR(resultSet.getString("ACCOUNT_VAT_REG_NBR"));
				accInfo.setTAXTYPE(resultSet.getString("TAX_TYPE"));
				accInfo.setACCOUNTTAXJURSDCTNCD(resultSet.getString("ACCOUNT_TAX_JURDSCTN_CD"));
				accInfo.setBILLBLOCKCD(resultSet.getString("BILL_BLOCK_CD"));
				accInfo.setORDRBLOCKCD(resultSet.getString("ORDR_BLOCK_CD"));
				accInfo.setDLVRYBLOCKCD(resultSet.getString("DLVRY_BLOCK_CD"));
				accInfo.setPOSTBLOCKCD(resultSet.getString("POST_BLOCK_CD"));
				accInfo.setSALEBLOCKCD(resultSet.getString("SALE_BLOCK_CD"));
				accInfo.setCHANNELID(resultSet.getString("CHANNEL_ID"));
				accInfo.setPARTNERTYPE(resultSet.getString("PARTNER_TYPE"));
				accInfo.setVENDORNBR(resultSet.getString("VENDOR_NBR"));
				accInfo.setDIRECTIND(resultSet.getString("DIRECT_IND"));
				accInfo.setNAMEDACCTIND(resultSet.getString("NAMED_ACCT_IND"));
				accInfo.setNONVALACCTIND(resultSet.getString("NON_VAL_ACCT_IND"));
				accInfo.setPARTNERIND(resultSet.getString("PARTNER_IND"));
				accInfo.setSIEBELROWID(resultSet.getString("SIEBEL_ROWID"));
				accInfo.setSAPCUSTNUMBER(resultSet.getString("SAP_CUST_NUMBER"));
				accInfo.setMDMLEGACYID(resultSet.getString("MDM_LEGACY_ID"));
				accInfo.setSAPNAME1(resultSet.getString("SAP_NAME_1"));
				accInfo.setSAPNAME2(resultSet.getString("SAP_NAME_2"));
				accInfo.setSAPNAME3(resultSet.getString("SAP_NAME_3"));
				accInfo.setSAPNAME4(resultSet.getString("SAP_NAME_4"));
				accInfo.setDATASRCSYSTEM(resultSet.getString("DATA_SRC_SYSTEM"));
				
				/** Modified for SFDC START */
				accInfo.setSalesForceID(resultSet.getString("SFID"));
				accInfo.setDraftAccountFlag(resultSet.getString("DRAFT_FLG"));
				/** Modified for SFDC END */
				/** changes for Sales Force Integration -Start */
				accInfo.setLOCALNAME(resultSet.getString("LOCAL_NAME"));
				accInfo.setCURRENCYCD(resultSet.getString("ACCOUNT_CURRENCY_CD"));
				accInfo.setTAXID(resultSet.getString("TAX_ID"));
				accInfo.setPRICEBANDAGGREMENT(resultSet.getString("PRICING_BAND_AGRMNT"));
				/** changes for Sales Force Integration -End */
				/** changes for Track-2 -Start */
				accInfo.setSITEDESIGNATION(resultSet.getString("SITE_DESIGNATION"));
				/** changes for Track-2 -End */
				/** changes for Track-3 -Start */
				accInfo.setRESELLLEVEL(resultSet.getString("RESELL_LEVEL"));
				accInfo.setPARTNERSHIPSTATUS(resultSet.getString("PARTNERSHIP_STATUS"));
				/** changes for Track-3 -End */
				LOG.debug("===Inserting into Account Map===");
				searchedRecCollObj.getAccountMap().put(accInfo.getROWIDACCOUNT(), accInfo);
			}			
			
			if (resultSet.getString("ADDRESS_ROWID_OBJECT") != null &&
					!searchedRecCollObj.getAddressMap().containsKey(resultSet.getString("ADDRESS_ROWID_OBJECT"))) {
				LOG.debug("============setting Address");
			
				address = new AddressXrefType();
				address.setROWIDADDRESS(resultSet.getString("ADDRESS_ROWID_OBJECT"));
				address.setSRCSYSTEM(resultSet.getString("ADDRESS_ROWID_SYSTEM"));
				address.setSRCPKEY(resultSet.getString("ADDRESS_PKEY_SRC_OBJECT"));
				address.setADDRLN1(resultSet.getString("ADDR_LN1"));
				address.setADDRLN2(resultSet.getString("ADDR_LN2"));
				address.setADDRLN3(resultSet.getString("ADDR_LN3"));
				address.setADDRLN4(resultSet.getString("ADDR_LN4"));
				address.setCITY(resultSet.getString("CITY"));
				address.setCOUNTY(resultSet.getString("COUNTY"));
				address.setDISTRICT(resultSet.getString("DISTRICT"));
				address.setSTATECD(resultSet.getString("STATE_CD"));
				address.setPOSTALCD(resultSet.getString("POSTAL_CD"));
				address.setCOUNTRYCD(resultSet.getString("COUNTRY_CD"));
				address.setLANGCD(resultSet.getString("LANG_CD"));
				address.setLONGITUDE(resultSet.getString("LONGITUDE"));
				address.setLATITUDE(resultSet.getString("LATITUDE"));
				address.setADDRTYPE(resultSet.getString("ADDR_TYPE"));
				address.setADDRSTATUS(resultSet.getString("ADDR_STATUS"));

				LOG.debug("===Inserting into Address Map===");
				searchedRecCollObj.getAddressMap().put(address.getROWIDADDRESS(), address);
			}
			
			if (resultSet.getString("COMMUNICATION_ROWID_OBJECT") != null && 
					!searchedRecCollObj.getCommMap().containsKey(resultSet.getString("COMMUNICATION_ROWID_OBJECT"))) {
				communication = new CommunicationXrefType();
				LOG.debug("============adding Communication");

				communication.setROWIDCOMMUNICATION(resultSet.getString("COMMUNICATION_ROWID_OBJECT"));
				communication.setSRCSYSTEM(resultSet.getString("COMMUNICATION_ROWID_SYSTEM"));
				communication.setSRCPKEY(resultSet.getString("COMMUNICATION_PKEY_SRC_OBJECT"));
				communication.setCOMMTYPE(resultSet.getString("COMM_TYPE"));
				communication.setCOMMVALUE(resultSet.getString("COMM_VALUE"));
				communication.setCOMMSTATUS(resultSet.getString("COMM_STATUS"));
				communication.setPRFRDCOMMIND(resultSet.getString("PRFRD_COMM_IND"));
				communication.setWEBDOMAIN(resultSet.getString("WEB_DOMAIN"));

				LOG.debug("===Inserting into Communication Map===");
				searchedRecCollObj.getCommMap().put(communication.getROWIDCOMMUNICATION(), communication);
			}
			
			if (resultSet.getString("PARTY_ORG_ROWID_OBJECT") != null && 
					!searchedRecCollObj.getPartyOrgMap().containsKey(resultSet.getString("PARTY_ORG_ROWID_OBJECT"))) {
				partyOrgExt = new PartyOrgExtXrefType();
				LOG.debug("============adding PartyOrgExt");

				partyOrgExt.setROWIDORGEXTN(resultSet.getString("PARTY_ORG_ROWID_OBJECT"));
		//		partyOrgExt.setSRCSYSTEM(resultSet.getString("PARTY_ORG_ROWID_SYSTEM"));
		//		partyOrgExt.setSRCPKEY(resultSet.getString("PARTY_ORG_PKEY_SRC_OBJECT"));
				partyOrgExt.setORGDUNSNBR(resultSet.getString("ORG_DUNS_NBR"));
				partyOrgExt.setTRADENAME(resultSet.getString("TRADE_NAME"));
				partyOrgExt.setTRADENAME2(resultSet.getString("TRADE_NAME_2"));
				partyOrgExt.setSITEEMPLCNT(resultSet.getString("SITE_EMPL_CNT"));
				partyOrgExt.setGLBLEMPLCNT(resultSet.getString("GLBL_EMPL_CNT"));
				partyOrgExt.setVERTICAL(resultSet.getString("VERTICAL"));
				partyOrgExt.setREVENUE(resultSet.getString("REVENUE"));
				partyOrgExt.setLINEOFBUS(resultSet.getString("LINE_OF_BUS"));
				partyOrgExt.setPRIMSIC(resultSet.getString("PRIM_SIC"));
				partyOrgExt.setSECSIC(resultSet.getString("SEC_SIC"));
				partyOrgExt.setSALESVOLUME(resultSet.getString("SALES_VOLUME"));
				partyOrgExt.setSALESAMOUNT(resultSet.getString("SALES_AMOUNT"));
				partyOrgExt.setCURRENCYCD(resultSet.getString("CURRENCY_CD"));
				partyOrgExt.setOUTOFBUSIND(resultSet.getString("OUT_OF_BUS_IND"));
				partyOrgExt.setGLBLULTIND(resultSet.getString("GLBL_ULT_IND"));
				partyOrgExt.setFORTUNEINFO(resultSet.getString("FORTUNE_INFO"));
				partyOrgExt.setHIERARCHYLEVEL(resultSet.getString("HIERARCHY_LEVEL"));
				partyOrgExt.setORGHQPARENTDUNS(resultSet.getString("ORG_HQ_PARENT_DUNS"));
				partyOrgExt.setORGDOMULTDUNS(resultSet.getString("ORG_DOM_ULT_DUNS"));
				partyOrgExt.setORGGLBULTDUNS(resultSet.getString("ORG_GLB_ULT_DUNS"));

				LOG.debug("===Inserting into PartyOrgExtType Map==");
				searchedRecCollObj.getPartyOrgMap().put(partyOrgExt.getROWIDORGEXTN(), partyOrgExt);
			}		
			

	/*		if (resultSet.getString("PARTY_PERSON_ROWID_OBJECT") != null && 
					!searchedRecCollObj.getPartyPersonMap().containsKey(resultSet.getString("PARTY_PERSON_ROWID_OBJECT"))) {
			
				partyPersonExt = new PartyPersonExtXrefType();
				LOG.debug("============adding PartyPersonExt");

				partyPersonExt.setROWIDPRSNEXTN(resultSet.getString("PARTY_PERSON_ROWID_OBJECT"));
				partyPersonExt.setSRCSYSTEM(resultSet.getString("PARTY_PERSON_ROWID_SYSTEM"));
				partyPersonExt.setSRCPKEY(resultSet.getString("PARTY_PERSON_PKEY_SRC_OBJECT"));
				partyPersonExt.setPREFIX(resultSet.getString("PREFIX"));
				partyPersonExt.setFIRSTNAME(resultSet.getString("FIRST_NAME"));
				partyPersonExt.setMIDDLENAME(resultSet.getString("MIDDLE_NAME"));
				partyPersonExt.setLASTNAME(resultSet.getString("LAST_NAME"));
				partyPersonExt.setSUFFIX(resultSet.getString("SUFFIX"));
				partyPersonExt.setPERSONTYPE(resultSet.getString("PERSON_TYPE"));

				LOG.debug("===Inserting into PartyPersonExtType List===");
				searchedRecCollObj.getPartyPersonMap().put(partyPersonExt.getROWIDPRSNEXTN(), partyPersonExt);
			}	*/
			
			/* Change For US-336 *******
			 * if (resultSet.getString("PARTY_CLASS_ROWID_OBJECT") != null && 
					!searchedRecCollObj.getClassMap().containsKey(resultSet.getString("PARTY_CLASS_ROWID_OBJECT"))) { */
			if (resultSet.getString("PARTY_CLASS_ROWID_OBJECT") != null && 
					!searchedRecCollObj.getClassMap().containsKey(resultSet.getString("PARTY_CLASS_PKEY_SRC_OBJECT"))) {
			
				classfction = new ClassificationXrefType();
				LOG.debug("============adding Classification");

				classfction.setROWIDCLASSIFICTN(resultSet.getString("PARTY_CLASS_ROWID_OBJECT"));
				classfction.setSRCSYSTEM(resultSet.getString("PARTY_CLASS_ROWID_SYSTEM"));
				classfction.setSRCPKEY(resultSet.getString("PARTY_CLASS_PKEY_SRC_OBJECT"));
				classfction.setCLASSIFICTNTYPE(resultSet.getString("CLASSIFCTN_TYPE"));
				classfction.setCLASSIFICTNVALUE(resultSet.getString("CLASSIFCTN_VALUE"));
				classfction.setCLASSIFICTNMETH(resultSet.getString("CLASSIFCTN_METH"));
				classfction.setSTARTDATE(resultSet.getString("START_DATE"));
				classfction.setENDDATE(resultSet.getString("END_DATE"));

				LOG.debug("===Inserting into Classification Map===");
				searchedRecCollObj.getClassMap().put(classfction.getROWIDCLASSIFICTN(), classfction);

			}
			
			if (resultSet.getString("PARTY_REL_ROWID_OBJECT") != null && 
					!searchedRecCollObj.getPartyRelMap().containsKey(resultSet.getString("PARTY_REL_ROWID_OBJECT"))) {
				
				/** Modified for M4M START */
				
				partyAccountRelationship = new PartyAccountRelationshipXrefType();
				LOG.debug("============adding PartyRelationship");

		//		partyRelationship.setSRCPKEY(resultSet.getString("PARTY_REL_PKEY_SRC_OBJECT"));
		//		partyRelationship.setSRCSYSTEM(resultSet.getString("PARTY_REL_ROWID_SYSTEM"));
				partyAccountRelationship.setHIERARCHYTYPE(resultSet.getString("ROWID_HIERARCHY"));
		//		partyRelationship.setPARENTROWIDPARTY(resultSet.getString("PARTY_REL_ROWID_PARENT"));
				partyAccountRelationship.setRELTYPE(resultSet.getString("ROWID_REL_TYPE"));

				LOG.debug("===Inserting into Relationship Map===");
				searchedRecCollObj.getPartyRelMap().put(resultSet.getString("PARTY_REL_ROWID_OBJECT"), partyAccountRelationship);
				
				/** Modified for M4M END */

			}
			
			bUniqueRec = false;
		}
			
		LOG.debug("====Populating Party records");
		if (party != null && searchedRecCollObj != null) {
			party.getAccount().addAll(searchedRecCollObj.getAccountMap().values());
			party.getAddress().addAll(searchedRecCollObj.getAddressMap().values());
			party.getCommunication().addAll(searchedRecCollObj.getCommMap().values());
			party.getPartyOrgExt().addAll(searchedRecCollObj.getPartyOrgMap().values());
			party.getPartyPersonExt().addAll(searchedRecCollObj.getPartyPersonMap().values());
			party.getClassification().addAll(searchedRecCollObj.getClassMap().values());
			
			/** Modified for M4M START */
			PartyRelationshipXrefType partyRel = party.getPartyRel();
			if(partyRel == null) {
				partyRel = new PartyRelationshipXrefType();
			}
			partyRel.getPARTYACCOUNTREL().addAll(searchedRecCollObj.getPartyRelMap().values());
			party.setPartyRel(partyRel);
			/** Modified for M4M END */
		}
		LOG.info("Executed createXrefCanonicalForm()");
		return party;
	

		
	}
	
	//fetch all party contact and child xref records 
	public PartyXrefType fetchContactXrefTypeFromORS(String srcSYS, String srcPKEY) throws ServiceProcessingException {
		LOG.info("Executing fetchContactXrefTypeFromORS()");
		
		PartyXrefType party = null;
		Statement statement = null;
		StringBuilder sqlQry = new StringBuilder();
		JDBCConnectionProvider jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();;
		Connection jdbcConnection = null;
		ResultSet resultSet = null;
		
		
		try {
			LOG.info("Fetching Party profile for partySRCSYS: " + srcSYS);
			LOG.info("Fetching Party profile for partySRCPKEY: " + srcPKEY);
		//	String query = "SELECT * FROM PKG_XREF_FOR_SEARCH WHERE PARTY_ROWID_SYSTEM = ? AND PARTY_PKEY_SRC_OBJECT = ?";
			sqlQry.append("SELECT * FROM PKG_XREF_PERSON_SEARCH WHERE PARTY_ROWID_SYSTEM = '");
			sqlQry.append(srcSYS + "' AND PARTY_PKEY_SRC_OBJECT = '");
			sqlQry.append(srcPKEY + "'");
			sqlQry.append(" AND HUB_STATE_IND <> '" + -1 + "'");
			LOG.debug("Query to fetch insertedCONTACTData: " + sqlQry);
			
			jdbcConnection = jDBCConnectionProvider.getJdbcConnectionFromDS();
		//	jdbcConnection = JdbcConn.GetJdbcConnObject();
			statement = jdbcConnection.createStatement();
			resultSet = statement.executeQuery(sqlQry.toString());
			party = createContactXrefCanonicalForm(resultSet);
			
		} catch (SQLException sqlEx) {
			LOG.error("Exception occurred while fetching Party profile: " + sqlEx);
			sqlEx.printStackTrace();
			ServiceProcessingException customException = new ServiceProcessingException(sqlEx);
			customException.setMessage("Failed to fetch Party profile from ORS." + customException.getMessage());
			throw customException;
		} finally {
			try {
					if( resultSet != null) resultSet.close();
					if( statement != null) statement.close();
					if(jdbcConnection != null) jdbcConnection.close();
				} catch (SQLException e) {
					
					e.printStackTrace();
				}
		}
		
		LOG.info("Executed fetchContactXrefTypeFromORS()");
		
		return party;
	}
	
	/*ELOQUA Contact XREF Cannonical Structure*/
	public PartyXrefType createContactXrefCanonicalForm(ResultSet resultSet) throws SQLException {
		LOG.info("Executing createContactXrefCanonicalForm()");
		PartyXrefType party = null;
		XREFType xref = null;
		CommunicationXrefType communication = null;
		AddressXrefType address = null;
		PartyPersonXrefType partyPerson = null;
		PartyRelationshipXrefType partyRelationship = null;
		
		/** Modified for M4M START */
		PartyAccountRelationshipXrefType partyAccountRelationship = null;
		/** Modified for M4M END */
		
		ArrayList<XREFType> listXref = null;
		
		try	{
		Map<String, SearchedXrefRecordCollection> searchedRecCollMap = new HashMap<String, SearchedXrefRecordCollection>();
		SearchedXrefRecordCollection searchedRecCollObj = null;
		boolean bUniqueRec = false;
		
		while (resultSet.next()) {
			String partyRowId = resultSet.getString("ORIG_ROWID_OBJECT");
			
			if (!searchedRecCollMap.containsKey(partyRowId)) {
				
				LOG.debug("Populate searchedXrefRecCollMap for new PARTY_ROWID " + partyRowId);
				searchedRecCollMap.put(partyRowId, new SearchedXrefRecordCollection());
				bUniqueRec = true;
			}

			searchedRecCollObj = searchedRecCollMap.get(partyRowId);

			if(bUniqueRec)	{
				
			//	LOG.debug("============setting Xref Copy");
				
				party = new PartyXrefType();
				party.setROWIDOBJECT(resultSet.getString("PARTY_ROWID_OBJECT"));
				searchedRecCollObj.setParty_rowid(resultSet.getString("PARTY_ROWID_OBJECT"));
				party.setBOCLASSCODE(resultSet.getString("BO_CLASS_CODE"));
				searchedRecCollObj.setBo_class(resultSet.getString("BO_CLASS_CODE"));
				party.setPARTYTYPE(resultSet.getString("PARTY_TYPE"));
				searchedRecCollObj.setParty_type(resultSet.getString("PARTY_TYPE"));
				party.setPARTYNAME(resultSet.getString("PARTY_NAME"));
				searchedRecCollObj.setParty_name(resultSet.getString("PARTY_NAME"));
				party.setGEO(resultSet.getString("PARTY_GEO"));
				searchedRecCollObj.setGeo(resultSet.getString("PARTY_GEO"));
				party.setREGION(resultSet.getString("PARTY_REGION"));
				searchedRecCollObj.setRegion(resultSet.getString("PARTY_REGION"));
				party.setSTATUSCD(resultSet.getString("STATUS_CD"));
				searchedRecCollObj.setStatus_cd(resultSet.getString("STATUS_CD"));
				party.setVATREGNBR(resultSet.getString("PARTY_VAT_REG_NBR"));
				searchedRecCollObj.setVat_regno(resultSet.getString("PARTY_VAT_REG_NBR"));
				party.setTAXJURSDCTNCD(resultSet.getString("PARTY_TAX_JURSDCTN_CD"));
				searchedRecCollObj.setTax_jd_cd(resultSet.getString("PARTY_TAX_JURSDCTN_CD"));
				party.setSALESBLOCKCD(resultSet.getString("SALES_BLOCK_CD"));
				searchedRecCollObj.setSales_cd(resultSet.getString("SALES_BLOCK_CD"));
				party.setUCN(resultSet.getString("UCN"));
				searchedRecCollObj.setUcn(resultSet.getString("UCN"));
				sipPopFromXref = resultSet.getString("SIP_POP");
				party.setENGLISHNAME(resultSet.getString("ENGLISH_NAME"));
				searchedRecCollObj.setEnglish_name(resultSet.getString("ENGLISH_NAME"));
				searchedRecCollObj.setLegacyUcn(resultSet.getString("LEGACY_UCN"));
				party.setLEGACYUCN(resultSet.getString("LEGACY_UCN"));
				
				
				/** Modified for M4M START */
				searchedRecCollObj.setDnbdbaname(resultSet.getString("DNB_DBA_NAME"));
				party.setDNBDBANAME(resultSet.getString("DNB_DBA_NAME"));
				searchedRecCollObj.setDnbsectradestyle(resultSet.getString("DNB_SECOND_TRADE_STYLE"));
				party.setDNBSECONDTRADESTYLE(resultSet.getString("DNB_SECOND_TRADE_STYLE"));
				searchedRecCollObj.setDnbregname(resultSet.getString("DNB_REG_NAME"));
				party.setDNBREGNAME(resultSet.getString("DNB_REG_NAME"));
				/** Modified for M4M END */
				
				LOG.debug("============setting PartyXREFType");
				xref = new XREFType();
				xref.setSRCSYSTEM(resultSet.getString("PARTY_ROWID_SYSTEM"));
				xref.setSRCPKEY(resultSet.getString("PARTY_PKEY_SRC_OBJECT"));
				
			//	LOG.debug("===Inserting into XREFType list===");
				listXref = new ArrayList<XREFType>();
				listXref.add(xref);
				party.getXREF().addAll(listXref);
				
			}
			
			if (resultSet.getString("PERSON_ROWID_OBJECT") != null &&
					!searchedRecCollObj.getPartyPersonXrefMap().containsKey(resultSet.getString("PERSON_ROWID_OBJECT"))) {
				LOG.debug("============setting PartyPerson");
			
				partyPerson = new PartyPersonXrefType();
				partyPerson.setROWIDOBJECT(resultSet.getString("PERSON_ROWID_OBJECT"));
				partyPerson.setSRCSYSTEM(resultSet.getString("PERSON_ROWID_SYSTEM"));
				partyPerson.setSRCPKEY(resultSet.getString("PERSON_PKEY_SRC_OBJECT"));
				partyPerson.setJOBLEVEL(resultSet.getString("JOB_LEVEL"));
				partyPerson.setLATTICESCORE(resultSet.getString("LATTICE_SCORE"));
				partyPerson.setREPORTEDCOMPANYNAME(resultSet.getString("REPTD_COMP_NAME"));
				partyPerson.setLISTSOURCE(resultSet.getString("LIST_SOURCE"));
				partyPerson.setDATASOURCESYSTEM(resultSet.getString("DATA_SRC_SYS"));
				partyPerson.setPREFLANGUAGE(resultSet.getString("PREF_LANGUAGE"));
				partyPerson.setPREFIX(resultSet.getString("PREFIX"));
				partyPerson.setFIRSTNAME(resultSet.getString("FIRST_NAME"));
				partyPerson.setMIDDLENAME(resultSet.getString("MIDDLE_NAME"));
				partyPerson.setLASTNAME(resultSet.getString("LAST_NAME"));
				partyPerson.setPERSONSTATUS(resultSet.getString("PERSON_STATUS"));
				partyPerson.setSUFFIX(resultSet.getString("SUFFIX"));
				partyPerson.setJOBFUNCTION(resultSet.getString("JOB_FUNCTION"));
				partyPerson.setJOBTITLE(resultSet.getString("JOB_TITLE"));
				partyPerson.setPERSONTYPE(resultSet.getString("PERSON_TYPE"));
				/** Modified for SFDC-Track4 START */
				partyPerson.setSRCACCOUNTID(resultSet.getString("SRC_ACCOUNT_ID"));
				partyPerson.setJOBROLE(resultSet.getString("JOB_ROLE"));
				partyPerson.setPARTNERCONTACTFLG(resultSet.getString("PARTNER_CONTACT_FLG"));
				/** Modified for SFDC-Track4 End */
				LOG.debug("===Inserting into PartyPerson Map===");
				searchedRecCollObj.getPartyPersonXrefMap().put(partyPerson.getROWIDOBJECT(), partyPerson);
			}
			
			if (resultSet.getString("ADDRESS_ROWID_OBJECT") != null &&
					!searchedRecCollObj.getAddressMap().containsKey(resultSet.getString("ADDRESS_ROWID_OBJECT"))) {
				LOG.debug("============setting Address");
			
				address = new AddressXrefType();
				address.setROWIDADDRESS(resultSet.getString("ADDRESS_ROWID_OBJECT"));
				address.setSRCSYSTEM(resultSet.getString("ADDRESS_ROWID_SYSTEM"));
				address.setSRCPKEY(resultSet.getString("ADDRESS_PKEY_SRC_OBJECT"));
				address.setADDRLN1(resultSet.getString("ADDR_LN1"));
				address.setADDRLN2(resultSet.getString("ADDR_LN2"));
				address.setADDRLN3(resultSet.getString("ADDR_LN3"));
				address.setADDRLN4(resultSet.getString("ADDR_LN4"));
				address.setCITY(resultSet.getString("CITY"));
				address.setCOUNTY(resultSet.getString("COUNTY"));
				address.setDISTRICT(resultSet.getString("DISTRICT"));
				address.setSTATECD(resultSet.getString("STATE_CD"));
				address.setPOSTALCD(resultSet.getString("POSTAL_CD"));
				address.setCOUNTRYCD(resultSet.getString("COUNTRY_CD"));
				address.setLANGCD(resultSet.getString("LANG_CD"));
				address.setLONGITUDE(resultSet.getString("LONGITUDE"));
				address.setLATITUDE(resultSet.getString("LATITUDE"));
				address.setADDRTYPE(resultSet.getString("ADDR_TYPE"));
				address.setADDRSTATUS(resultSet.getString("ADDR_STATUS"));
				address.setADDRMKTGPREF(resultSet.getString("ADDR_MKTG_PREF"));

				LOG.debug("===Inserting into Address Map===");
				searchedRecCollObj.getAddressMap().put(address.getROWIDADDRESS(), address);
			}
			
			if (resultSet.getString("COMMUNICATION_ROWID_OBJECT") != null && 
					!searchedRecCollObj.getCommMap().containsKey(resultSet.getString("COMMUNICATION_ROWID_OBJECT"))) {
				communication = new CommunicationXrefType();
				LOG.debug("============adding Communication");

				communication.setROWIDCOMMUNICATION(resultSet.getString("COMMUNICATION_ROWID_OBJECT"));
				communication.setSRCSYSTEM(resultSet.getString("COMMUNICATION_ROWID_SYSTEM"));
				communication.setSRCPKEY(resultSet.getString("COMMUNICATION_PKEY_SRC_OBJECT"));
				communication.setCOMMTYPE(resultSet.getString("COMM_TYPE"));
				communication.setCOMMVALUE(resultSet.getString("COMM_VALUE"));
				communication.setCOMMSTATUS(resultSet.getString("COMM_STATUS"));
				communication.setPRFRDCOMMIND(resultSet.getString("PRFRD_COMM_IND"));
				communication.setWEBDOMAIN(resultSet.getString("WEB_DOMAIN"));
				communication.setCOMMEXTN(resultSet.getString("COMM_EXTN"));
				communication.setCOMMMKTGPREF(resultSet.getString("COMM_MKTG_PREF"));
				/** Modified for SFDC-Track4 START */
				communication.setCOMMSALESPREF(resultSet.getString("COMM_SALES_PREF"));
				/** Modified for SFDC-Track4 End */
				LOG.debug("===Inserting into Communication Map===");
				searchedRecCollObj.getCommMap().put(communication.getROWIDCOMMUNICATION(), communication);
			}
			
			bUniqueRec = false;
		}
			
		LOG.debug("====Populating Party records");
		if (party != null && searchedRecCollObj != null) {
			party.getAddress().addAll(searchedRecCollObj.getAddressMap().values());
			party.getCommunication().addAll(searchedRecCollObj.getCommMap().values());
			party.getPartyPerson().addAll(searchedRecCollObj.getPartyPersonXrefMap().values());
			
		}
		} catch(Exception excp)	{
			LOG.error("Caught exception in createContactXrefCanonicalForm()-->",excp);
		}
		LOG.info("Executed createContactXrefCanonicalForm()");
		return party;
		
	}
	
	//Checking Match Exclusion Pattern Exists or not.
	public int checkMatchExclusionPattern(String rowidObject) throws ServiceProcessingException {
		LOG.info("Executing checkMatchExclusionPattern()");
		
		
		
		Statement statement = null;
		StringBuilder sqlQry = new StringBuilder();
		JDBCConnectionProvider jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();;
		Connection jdbcConnection = null;
		ResultSet resultSet = null;		
		boolean firstCondition = true;
		int recordCount = 0;
		
		try {
			List<String> exclusionConditionList = getMatchExclusionList(Boolean.FALSE);
			if (exclusionConditionList != null && exclusionConditionList.size()>0) {
				
				sqlQry.append(Constant.COUNT_FROM_PKG_PARTY_JMS_MQ_PUB);
				sqlQry.append("'"+rowidObject + "' AND ( ");
				//sqlQry.append(srcPKEY + "'");
				for (String condition : exclusionConditionList) {
					
					if (firstCondition) {
						sqlQry.append(" ( ");
						sqlQry.append(condition);
						firstCondition = false;
					}else {
						sqlQry.append(" OR ");
						sqlQry.append(" ( ");
						sqlQry.append(condition);
					}
					
					sqlQry.append(" ) ");
				}
				sqlQry.append(" ) ");
				LOG.info("Query to fetch presence of match exclusion pattern: " + sqlQry);

				jdbcConnection = jDBCConnectionProvider.getJdbcConnectionFromDS();
				
				statement = jdbcConnection.createStatement();
				resultSet = statement.executeQuery(sqlQry.toString());
				while (resultSet.next()) {
					recordCount = resultSet.getInt(1);
					
				}	
				LOG.info("Record count with match exclusion pattern = " + recordCount);
			}
			
			
		} catch (SQLException sqlEx) {
			LOG.error("Exception occurred while checking the presence of match exclusion pattern: ", sqlEx);
			//sqlEx.printStackTrace();
			ServiceProcessingException customException = new ServiceProcessingException(sqlEx);
			customException.setMessage("Failed to check the presence of match exclusion pattern: " + sqlEx.getMessage());
			throw customException;
		} finally {
			try {
					if( resultSet != null)	resultSet.close();
					if( statement != null) statement.close();
					if(jdbcConnection != null) jdbcConnection.close();
				} catch (SQLException e) {
					
					e.printStackTrace();
				}
		}
		
		LOG.info("Executed checkMatchExclusionPattern()");
		
		return recordCount;
	}
	
	public int checkExclusionPatternProspect(String rowidObject) throws ServiceProcessingException {
		LOG.info("Executing checkMatchExclusionPattern()");
		
		
		
		Statement statement = null;
		StringBuilder sqlQry = new StringBuilder();
		JDBCConnectionProvider jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();;
		Connection jdbcConnection = null;
		ResultSet resultSet = null;		
		boolean firstCondition = true;
		int recordCount = 0;
		
		try {
			List<String> exclusionConditionList = getMatchExclusionList(Boolean.TRUE);
			if (exclusionConditionList != null && exclusionConditionList.size()>0) {
				
				sqlQry.append(Constant.COUNT_FROM_C_B_PARTY);
				sqlQry.append("'"+rowidObject + "' AND ( ");
				//sqlQry.append(srcPKEY + "'");
				for (String condition : exclusionConditionList) {
					
					if (firstCondition) {
						sqlQry.append(" ( ");
						sqlQry.append(condition);
						firstCondition = false;
					}else {
						sqlQry.append(" OR ");
						sqlQry.append(" ( ");
						sqlQry.append(condition);
					}
					
					sqlQry.append(" ) ");
				}
				sqlQry.append(" ) ");
				LOG.info("Query to fetch presence of match exclusion pattern: " + sqlQry);

				jdbcConnection = jDBCConnectionProvider.getJdbcConnectionFromDS();
				
				statement = jdbcConnection.createStatement();
				resultSet = statement.executeQuery(sqlQry.toString());
				while (resultSet.next()) {
					recordCount = resultSet.getInt(1);
					
				}	
				LOG.info("Record count with match exclusion pattern = " + recordCount);
			}
			
			
		} catch (SQLException sqlEx) {
			LOG.error("Exception occurred while checking the presence of match exclusion pattern: ", sqlEx);
			//sqlEx.printStackTrace();
			ServiceProcessingException customException = new ServiceProcessingException(sqlEx);
			customException.setMessage("Failed to check the presence of match exclusion pattern: " + sqlEx.getMessage());
			throw customException;
		} finally {
			try {
					if( resultSet != null)	resultSet.close();
					if( statement != null) statement.close();
					if(jdbcConnection != null) jdbcConnection.close();
				} catch (SQLException e) {
					
					e.printStackTrace();
				}
		}
		
		LOG.info("Executed checkMatchExclusionPattern()");
		
		return recordCount;
	}
	
	//Fetching List Of values from table MATCH_MERGE_EXCLUSION_COND.
	public List<String> getMatchExclusionList(boolean isProcepect) throws ServiceProcessingException {
			
			LOG.info("Executing getMatchExclusionList()");
			StringBuilder sqlQry = new StringBuilder();
			JDBCConnectionProvider jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();;
			Connection jdbcConnection = null;
			Statement statement = null;
			ResultSet resultSet = null;
			List<String> exclusionConditionList = new ArrayList<String>();
			
			try {
				if(isProcepect){
					sqlQry.append(Constant.SELECT_FROM_MATCH_MERGE_EXCLSN_COND_PROS);
				}else {
					sqlQry.append(Constant.SELECT_FROM_MATCH_MERGE_EXCLUSION_COND);
				}
				
				LOG.info("Query to fetch dynamic match exclusion conditions: " + sqlQry);
				
				
	//			pstatement = jdbcConnection.prepareStatement(query);
	//			pstatement.setString(1, srcSYS);
	//			pstatement.setString(2, srcPKEY);
	//			resultSet = pstatement.executeQuery();	
				jdbcConnection = jDBCConnectionProvider.getJdbcConnectionFromDS();
			//	jdbcConnection = JdbcConn.GetJdbcConnObject();
				statement = jdbcConnection.createStatement();
				resultSet = statement.executeQuery(sqlQry.toString());
				while (resultSet.next()) {
					String conditionParameter = resultSet.getString("CONDITION_PARAMETER");
					exclusionConditionList.add(conditionParameter);
				}	
				LOG.info("Number of exclusion condition found is " + exclusionConditionList);
				
			} catch (SQLException sqlEx) {
				LOG.error("Exception occurred while fetching MATCH_MERGE_EXCLUSION_COND table: ", sqlEx);
				//sqlEx.printStackTrace();
				ServiceProcessingException customException = new ServiceProcessingException(sqlEx);
				customException.setMessage("Failed to fetch MATCH_MERGE_EXCLUSION_COND table: " + sqlEx.getMessage());
				throw customException;
			} finally {
				try {
						if( resultSet != null) resultSet.close();
						if( statement != null) statement.close();
						if(jdbcConnection != null) jdbcConnection.close();
					} catch (SQLException e) {
						
						e.printStackTrace();
					}
			}
			LOG.info("Executed getMatchExclusionList()");
			return exclusionConditionList;
		}
	
		// Updating Consolidation_IND of Party Record to 9.
	public void updatePartyConsolidationInd(String rowidObject) throws ServiceProcessingException {
		/* Changed for US905 (MDMP-2482) START */
		LOG.debug("[updatePartyConsolidationInd] ENTER:: ROWID_OBJECT::" + rowidObject);
		JDBCConnectionProvider jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
		Connection jdbcConnection = null;
		CallableStatement callStmt = null;
		try {
			jdbcConnection = jDBCConnectionProvider.getJdbcConnectionFromDS();
			LOG.info("[updatePartyConsolidationInd]Query to update Party consolidation indicator: "
					+ Constant.UPDATE_PARTY_CONSOLIDATION_IND);
			callStmt = jdbcConnection.prepareCall(Constant.UPDATE_PARTY_CONSOLIDATION_IND);
			callStmt.setString(1, "RT-INBOUND");
			callStmt.setInt(2, 9);
			callStmt.setString(3, null);
			callStmt.setString(4, Constant.STR_N);
			callStmt.setString(5, rowidObject);
			LOG.info("[updatePartyConsolidationInd]Executing procedure");
			callStmt.execute();
			LOG.info("[updatePartyConsolidationInd]Party consolidation indicator updated to 9");
		} catch (SQLException sqlEx) {
			LOG.error("[updatePartyConsolidationInd]Exception occurred to update Party consolidation indicator", sqlEx);
			ServiceProcessingException customException = new ServiceProcessingException(sqlEx);
			customException.setMessage("Failed to update Party consolidation indicator: " + sqlEx.getMessage());
			throw customException;
		} finally {
			try {
				if (callStmt != null) {
					callStmt.close();
				}
			} catch (SQLException e) {
				LOG.error("[updatePartyConsolidationInd]Failed to close callStmt", e);
			}
			try {
				if (jdbcConnection != null) {
					jdbcConnection.close();
				}
			} catch (SQLException e) {
				LOG.error("[updatePartyConsolidationInd]Failed to close jdbcConnection", e);
			}
		}

		LOG.debug("[updatePartyConsolidationInd] EXIT");
		/* Changed for US905(MDMP-2482) END */
	}
		//M4M-Contact related
		public PartyType getBOContact(String contactID) throws ServiceProcessingException {
			LOG.info("Executing getParty()");

			PartyType partyResponse = null;
			SiperianClient siperianClient = null;
			boolean isContactRec = true;

			GetRequest request = new GetRequest();
			GetResponse response = null;
			String pkgNameBO = "PACKAGE.PKG_BO_PERSON_SEARCH";

			try {
				siperianClient = (SiperianClient) checkOut();
				
				RecordKey recordKey = new RecordKey();
				recordKey.setRowid(contactID);
				request.setRecordKey(recordKey); //Required
				request.setSiperianObjectUid(pkgNameBO); //Required
				
				LOG.info("processing GetRequest on " + pkgNameBO + " for partyID " + contactID);
				response = (GetResponse) siperianClient.process(request);
				LOG.debug("GetRequest processed");
				
				if (response != null && response.getRecords().size() > 0) {
					LOG.info("GetRequest rec cnt="+ response.getRecords().size());
					partyResponse = processGoldenCopyResults(response.getRecords(),isContactRec);
				}
			} catch (Exception excp) {
				LOG.error("Exception occurred while fetching Party golden copy:", excp);
				//excp.printStackTrace();
				ServiceProcessingException customException = new ServiceProcessingException(excp);
				customException.setMessage("Failed to fetch Party golden copy: " + excp.getMessage());
				throw customException;
			} finally {
				try{
					checkIn(siperianClient);
				} catch(Exception excp) {
					LOG.error("Failed to checkin siperianClient connection to Object pool: " + excp.toString());
				}
			}
			LOG.info("Executed getParty()");
			return partyResponse;
		}
		//End OF M4M Contact Related
		
		//SAP-SBL Account Related
		public PartyType getBOParty(String partyID, boolean p2cEligible) throws ServiceProcessingException {
			LOG.info("Executing getParty()");

			PartyType partyResponse = null;
			SiperianClient siperianClient = null;

			GetRequest request = new GetRequest();
			GetResponse response = null;
			//String pkgNameBO = "PACKAGE.PKG_PARTY_JMS_MQ_PUB";
			String pkgNameBO = "PACKAGE.PKG_PARTY_SYNC_PUB";
			boolean activeorgExtnExist = false;
			boolean activeclfctnExist = false;

			try {
				activeclfctnExist = commonUtil.checkActiveClsfncExist(partyID);
				activeorgExtnExist = commonUtil.checkActiveOrgExtnExist(partyID);
				siperianClient = (SiperianClient) checkOut();
				
				RecordKey recordKey = new RecordKey();
				recordKey.setRowid(partyID);
				request.setRecordKey(recordKey); //Required
				request.setSiperianObjectUid(pkgNameBO); //Required
				if (p2cEligible || (!activeclfctnExist) || (!activeorgExtnExist)){
				request.setDataFilter(" HUB_STATE_IND = '1'");
				}
				else{
				//request.setDataFilter("HUB_STATE_IND = '1' AND NVL(ORG_EXTN_HUB_STATE_IND,1) <> '-1' AND NVL(CLASSIFCTN_HUB_STATE_IND,1) <> '-1'  AND nvl(trunc(END_DATE),'31-DEC-9999') = '31-DEC-9999' ");
				request.setDataFilter("HUB_STATE_IND = '1' AND NVL(ORG_EXTN_HUB_STATE_IND,1) <> '-1' AND NVL(CLASSIFCTN_HUB_STATE_IND,1) <> '-1'");
				}
				LOG.info("processing GetRequest on " + pkgNameBO + " for partyID " + partyID + " Data Filter:: " + request.getDataFilter());
				
				response = (GetResponse) siperianClient.process(request);
				LOG.debug("GetRequest processed");
				
				if (response != null && response.getRecords().size() > 0) {
					LOG.info("GetRequest rec cnt="+ response.getRecords().size());
					partyResponse = processGoldenCopyResults(response.getRecords(),Boolean.FALSE);
				}
				
			} catch (Exception excp) {
				LOG.error("Exception occurred while fetching Party golden copy:", excp);
				//excp.printStackTrace();
				ServiceProcessingException customException = new ServiceProcessingException(excp);
				customException.setMessage("Failed to fetch Party golden copy: " + excp.getMessage());
				throw customException;
			} finally {
				try{
					checkIn(siperianClient);
				} catch(Exception excp) {
					LOG.error("Failed to checkin siperianClient connection to Object pool: " + excp.toString());
				}
			}
			LOG.info("Executed getParty()");
			return partyResponse;
		}
		
		
		public PartyType getBOPartyForAdobe(String partyID) throws ServiceProcessingException {
			LOG.info("Executing getParty()");

			PartyType partyResponse = null;
			SiperianClient siperianClient = null;

			GetRequest request = new GetRequest();
			GetResponse response = null;
			//String pkgNameBO = "PACKAGE.PKG_PROSPECT_JMS_MQ_PUB";
			String pkgNameBO = "PACKAGE.PKG_PARTY_PROSPECT_DETAILS";

			try {
				siperianClient = (SiperianClient) checkOut();
				
				RecordKey recordKey = new RecordKey();
				recordKey.setRowid(partyID);
				request.setRecordKey(recordKey); //Required
				request.setSiperianObjectUid(pkgNameBO); //Required
				request.setDataFilter("HUB_STATE_IND = '1' AND NVL(ADDR_HUB_STATE_IND,1) <> '-1' AND NVL(ORG_EXTN_HUB_STATE_IND,1) <> '-1' AND NVL(CLASSIFCTN_HUB_STATE_IND,1) <> '-1'");
				//request.setDataFilter("HUB_STATE_IND = '1' AND NVL(ORG_EXTN_HUB_STATE_IND,1) <> '-1' AND NVL(CLASSIFCTN_HUB_STATE_IND,1) <> '-1'");
				LOG.info("processing GetRequest on " + pkgNameBO + " for partyID " + partyID + " Data Filter:: " + request.getDataFilter());
				
				//LOG.info("processing GetRequest on " + pkgNameBO + " for partyID " + partyID);
				response = (GetResponse) siperianClient.process(request);
				LOG.debug("GetRequest processed");
				
				if (response != null && response.getRecords().size() > 0) {
					LOG.info("GetRequest rec cnt="+ response.getRecords().size());
					partyResponse = processGoldenCopyResults(response.getRecords(),Boolean.FALSE);
				}
			} catch (Exception excp) {
				LOG.error("Exception occurred while fetching Party golden copy:", excp);
				//excp.printStackTrace();
				ServiceProcessingException customException = new ServiceProcessingException(excp);
				customException.setMessage("Failed to fetch Party golden copy: " + excp.getMessage());
				throw customException;
			} finally {
				try{
					checkIn(siperianClient);
				} catch(Exception excp) {
					LOG.error("Failed to checkin siperianClient connection to Object pool: " + excp.toString());
				}
			}
			LOG.info("Executed getParty()");
			return partyResponse;
		}
		
		
		
		private PartyType processGoldenCopyResults(List<Record> searchRecords,boolean isContactRec) throws ServiceProcessingException {
			LOG.info("Executing processGoldenCopyResults()");

			PartyType partyResponse = null;
			CommunicationType communication = null;
			AccountType accInfo = null;
			AddressType address = null;
			ClassificationType classfction = null;
			PartyOrgExtType partyOrgExt = null;
			PartyPersonType partyPerson = null;
			PartyRelationshipType partyRelationship = null;
			PartyAccountRelationshipType partyAccountRelationship = null;
			//List<XREF> listXref = null;

			Map<String, SearchedRecordCollection> searchedRecCollMap = new HashMap<String, SearchedRecordCollection>();
			SearchedRecordCollection searchedRecCollObj = null;
			boolean bUniqueRec = false;
			String hierarchyGRP = configProps.getProperty("HierGRP");
			try {
				if (searchRecords != null && searchRecords.size() != 0) {
					for (Iterator<Record> iter = searchRecords.iterator(); iter.hasNext();) {
						Record record = (Record) iter.next();

						String partyRowId = record.getField("ROWID_OBJECT").getStringValue();
						partyResponse = new PartyType();
						String isGlobalParent = "N";
						String partyType = record.getField("PARTY_TYPE").getStringValue();
						String hierarchyCd = null;
						String rowidRelationship = null;
						if (!searchedRecCollMap.containsKey(partyRowId)) {
							
							LOG.debug("Populate searchedRecCollMap for new PARTY_ROWID " + partyRowId);
							searchedRecCollMap.put(partyRowId, new SearchedRecordCollection());
							bUniqueRec = true;
						}

						searchedRecCollObj = searchedRecCollMap.get(partyRowId);

						if(bUniqueRec)	{
							LOG.debug("============setting GoldenCopy");
							
							searchedRecCollObj.setParty_rowid(partyRowId);
							searchedRecCollObj.setBo_class(record.getField("BO_CLASS_CODE").getStringValue());
							searchedRecCollObj.setParty_type(record.getField("PARTY_TYPE").getStringValue());
							searchedRecCollObj.setParty_name(record.getField("PARTY_NAME").getStringValue());
							searchedRecCollObj.setGeo(record.getField("GEO").getStringValue());
							searchedRecCollObj.setRegion(record.getField("REGION").getStringValue());
							searchedRecCollObj.setStatus_cd(record.getField("STATUS_CD").getStringValue());
							searchedRecCollObj.setVat_regno(record.getField("VAT_REG_NBR").getStringValue());
							searchedRecCollObj.setTax_jd_cd(record.getField("TAX_JURSDCTN_CD").getStringValue());
							searchedRecCollObj.setSales_cd(record.getField("SALES_BLOCK_CD").getStringValue());
							searchedRecCollObj.setUcn(record.getField("UCN").getStringValue());
							searchedRecCollObj.setEnglish_name(record.getField("ENGLISH_NAME").getStringValue());
							searchedRecCollObj.setSipPop(record.getField("SIP_POP").getStringValue());
							LOG.debug("============setting GoldenCopy removed sippop" + searchedRecCollObj.getSipPop());
							/** changes for Sales Force Integration -Start */
							searchedRecCollObj.setMsgTrackingId(record.getField("MSG_TRKN_ID").getStringValue());
							searchedRecCollObj.setSrcUpdateBy(record.getField("SRC_UPDT_BY").getStringValue());
							searchedRecCollObj.setPhysicalGeo(record.getField("PHYSICAL_GEO").getStringValue());
							searchedRecCollObj.setPhysicalRegion(record.getField("PHYSICAL_REGION").getStringValue());
							 Date updateDate = record.getField("LAST_UPDATE_DATE").getDateValue();
                             if(updateDate != null) {
                                 String formatedStartDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(updateDate);                       
                                 searchedRecCollObj.setUpdatedate(formatedStartDate);                                                
                             }
						}
						if(isContactRec){
						if (record.getField("PERSON_ROWID_OBJECT").getStringValue() != null &&
								!searchedRecCollObj.getPartyPersnMap().containsKey(record.getField("PERSON_ROWID_OBJECT").getStringValue())) {
							LOG.debug("============setting PartyPerson");
						
							partyPerson = new PartyPersonType();
							partyPerson.setROWIDOBJECT(record.getField("PERSON_ROWID_OBJECT").getStringValue());
							partyPerson.setJOBLEVEL(record.getField("JOB_LEVEL").getStringValue());
							partyPerson.setLATTICESCORE(record.getField("LATTICE_SCORE").getStringValue());
							partyPerson.setREPORTEDCOMPANYNAME(record.getField("REPTD_COMP_NAME").getStringValue());
							partyPerson.setLISTSOURCE(record.getField("LIST_SOURCE").getStringValue());
							partyPerson.setDATASOURCESYSTEM(record.getField("DATA_SRC_SYS").getStringValue());
							partyPerson.setPREFLANGUAGE(record.getField("PREF_LANGUAGE").getStringValue());
							partyPerson.setPREFIX(record.getField("PREFIX").getStringValue());
							partyPerson.setFIRSTNAME(record.getField("FIRST_NAME").getStringValue());
							partyPerson.setMIDDLENAME(record.getField("MIDDLE_NAME").getStringValue());
							partyPerson.setLASTNAME(record.getField("LAST_NAME").getStringValue());
							partyPerson.setPERSONSTATUS(record.getField("PERSON_STATUS").getStringValue());
							partyPerson.setSUFFIX(record.getField("SUFFIX").getStringValue());
							partyPerson.setJOBFUNCTION(record.getField("JOB_FUNCTION").getStringValue());
							partyPerson.setJOBTITLE(record.getField("JOB_TITLE").getStringValue());
							partyPerson.setPERSONTYPE(record.getField("PERSON_TYPE").getStringValue());
							/** Modified for SFDC-Track4 START */
							partyPerson.setSRCACCOUNTID(record.getField("SRC_ACCOUNT_ID").getStringValue());
							partyPerson.setJOBROLE(record.getField("JOB_ROLE").getStringValue());
							partyPerson.setCLEANSEIND(record.getField("CLEANSE_IND").getStringValue());
							partyPerson.setPARTNERCONTACTFLG(record.getField("PARTNER_CONTACT_FLG").getStringValue());
							partyPerson.setSalesForceID(record.getField("SALES_FORCE_ID").getStringValue());
							/** Modified for SFDC-Track4 End */
							LOG.debug("===Inserting into PartyPerson Map===");
							searchedRecCollObj.getPartyPersnMap().put(partyPerson.getROWIDOBJECT(), partyPerson);
						}
						}
						if(!isContactRec){
						if (record.getField("ROWID_ACCOUNT").getStringValue() != null && 
								!searchedRecCollObj.getAccountMap().containsKey(record.getField("ROWID_ACCOUNT").getStringValue())) {
							
							LOG.debug("============setting AccountType");
							accInfo = new AccountType();
						
							accInfo.setROWIDACCOUNT(record.getField("ROWID_ACCOUNT").getStringValue());
							accInfo.setACCTNAME(record.getField("ACCT_NAME").getStringValue());
							accInfo.setALIASNAME(record.getField("ALIAS_NAME").getStringValue());
							accInfo.setACCTSTATUS(record.getField("ACCT_STATUS").getStringValue());
							accInfo.setACCTTYPE(record.getField("ACCT_TYPE").getStringValue());
							accInfo.setACCOUNTREGION(record.getField("ACCOUNT_REGION").getStringValue());
							accInfo.setACCOUNTGEO(record.getField("ACCOUNT_GEO").getStringValue());
							accInfo.setMARKET(record.getField("MARKET").getStringValue());
							accInfo.setCUSTGROUP(record.getField("CUST_GROUP").getStringValue());
							accInfo.setPRICEGROUP(record.getField("PRICE_GROUP").getStringValue());
							accInfo.setCOMPANYCD(record.getField("COMPANY_CD").getStringValue());
							accInfo.setACCOUNTVATREGNBR(record.getField("ACCOUNT_VAT_REG_NBR").getStringValue());
							accInfo.setTAXTYPE(record.getField("TAX_TYPE").getStringValue());
							accInfo.setACCOUNTTAXJURSDCTNCD(record.getField("ACCOUNT_TAX_JURSDCTN_CD").getStringValue());
							accInfo.setBILLBLOCKCD(record.getField("BILL_BLOCK_CD").getStringValue());
							accInfo.setORDRBLOCKCD(record.getField("ORDR_BLOCK_CD").getStringValue());
							accInfo.setDLVRYBLOCKCD(record.getField("DLVRY_BLOCK_CD").getStringValue());
							accInfo.setPOSTBLOCKCD(record.getField("POST_BLOCK_CD").getStringValue());
							accInfo.setSALEBLOCKCD(record.getField("SALE_BLOCK_CD").getStringValue());
							accInfo.setCHANNELID(record.getField("CHANNEL_ID").getStringValue());
							accInfo.setPARTNERTYPE(record.getField("PARTNER_TYPE").getStringValue());
							accInfo.setVENDORNBR(record.getField("VENDOR_NBR").getStringValue());
							accInfo.setDIRECTIND(record.getField("DIRECT_IND").getStringValue());
							accInfo.setNAMEDACCTIND(record.getField("NAMED_ACCT_IND").getStringValue());
							accInfo.setNONVALACCTIND(record.getField("NON_VAL_ACCT_IND").getStringValue());
							accInfo.setPARTNERIND(record.getField("PARTNER_IND").getStringValue());
							accInfo.setSIEBELROWID(record.getField("SIEBEL_ROWID").getStringValue());
							accInfo.setSAPCUSTNUMBER(record.getField("SAP_CUST_NUMBER").getStringValue());
							accInfo.setMDMLEGACYID(record.getField("MDM_LEGACY_ID").getStringValue());
							accInfo.setSAPNAME1(record.getField("SAP_NAME_1").getStringValue());
							accInfo.setSAPNAME2(record.getField("SAP_NAME_2").getStringValue());
							accInfo.setSAPNAME3(record.getField("SAP_NAME_3").getStringValue());
							accInfo.setSAPNAME4(record.getField("SAP_NAME_4").getStringValue());
						//	accInfo.setDATASRCSYSTEM(record.getField("DATA_SRC_SYSTEM").getStringValue());
							
							/** Modified for SFDC START */
							accInfo.setSalesForceID(record.getField("SFID").getStringValue());
							accInfo.setDraftAccountFlag(record.getField("DRAFT_FLG").getStringValue());
							/** Modified for SFDC END */
							/** changes for Sales Force Integration -Start */
							accInfo.setLOCALNAME(record.getField("LOCAL_NAME").getStringValue());
							accInfo.setCURRENCYCD(record.getField("ACCOUNT_CURRENCY_CD").getStringValue());
							accInfo.setTAXID(record.getField("TAX_ID").getStringValue());
							accInfo.setPRICEBANDAGGREMENT(record.getField("PRICING_BAND_AGRMNT").getStringValue());
							/** changes for Sales Force Integration -End */
							/** changes for Track-2 -Start */
							accInfo.setSITEDESIGNATION(record.getField("SITE_DESIGNATION").getStringValue());
							/** changes for Track-2 -End */
							/** changes for Track-3 -Start */
							accInfo.setRESELLLEVEL(record.getField("RESELL_LEVEL").getStringValue());
							accInfo.setPARTNERSHIPSTATUS(record.getField("PARTNERSHIP_STATUS").getStringValue());
							/** changes for Track-3 -End */
							/** changes for MDMp-2885 -Start */
							accInfo.setISDENIEDFLG(record.getField("IS_DENIED_FLG").getStringValue());
							/** changes for MDMP-3092 -Start */
							accInfo.setTOP250FLG(record.getField("TOP_250_FLG").getStringValue());
							accInfo.setTOP1000FLG(record.getField("TOP_1000_FLG").getStringValue());
							/** changes for MDMP-3092 -End */
							LOG.debug("===Inserting into AccountType Map===");
							searchedRecCollObj.getAccountMap().put(record.getField("ROWID_ACCOUNT").getStringValue(), accInfo);

						}
						if (record.getField("ROWID_PROSPECT") != null && !Util.isNullOrEmpty(record.getField("ROWID_PROSPECT").getStringValue()) &&
								!searchedRecCollObj.getAccountMap().containsKey(record.getField("ROWID_PROSPECT"))) {
							accInfo = new AccountType();
							accInfo.setROWIDACCOUNT(record.getField("ROWID_PROSPECT").getStringValue());
							accInfo.setACCTNAME(record.getField("PROSPECT_NAME").getStringValue());
							accInfo.setACCTTYPE(record.getField("PROSPECT_TYPE").getStringValue());
							accInfo.setCUSTGROUP(record.getField("PROSPECT_GROUP").getStringValue());
							searchedRecCollObj.getAccountMap().put(accInfo.getROWIDACCOUNT(), accInfo);
						}
						}
						
						if (record.getField("ROWID_ADDRESS").getStringValue() != null && 
								!searchedRecCollObj.getAddressMap().containsKey(record.getField("ROWID_ADDRESS").getStringValue())) {
						
							address = new AddressType();
							address.setROWIDADDRESS(record.getField("ROWID_ADDRESS").getStringValue());
							address.setADDRLN1(record.getField("ADDR_LN1").getStringValue());
							address.setADDRLN2(record.getField("ADDR_LN2").getStringValue());
							address.setADDRLN3(record.getField("ADDR_LN3").getStringValue());
							address.setADDRLN4(record.getField("ADDR_LN4").getStringValue());
							address.setCITY(record.getField("CITY").getStringValue());
							address.setCOUNTY(record.getField("COUNTY").getStringValue());
							address.setDISTRICT(record.getField("DISTRICT").getStringValue());
							address.setSTATECD(record.getField("STATE_CD").getStringValue());
							address.setPOSTALCD(record.getField("POSTAL_CD").getStringValue());
							address.setCOUNTRYCD(record.getField("COUNTRY_CD").getStringValue());
							address.setLANGCD(record.getField("LANG_CD").getStringValue());
							address.setLONGITUDE(record.getField("LONGITUDE").getStringValue());
							address.setLATITUDE(record.getField("LATITUDE").getStringValue());
							address.setADDRTYPE(record.getField("ADDR_TYPE").getStringValue());
							address.setADDRSTATUS(record.getField("ADDR_STATUS").getStringValue());

							LOG.debug("===Inserting into Address Map===");
							searchedRecCollObj.getAddressMap().put(record.getField("ROWID_ADDRESS").getStringValue(), address);

						}
						
						if (record.getField("ROWID_COMMUNICATION").getStringValue() != null && 
								!searchedRecCollObj.getCommMap().containsKey(record.getField("ROWID_COMMUNICATION").getStringValue())) {
							if(record.getField("COMM_HUB_STATE_IND")!=null && record.getField("COMM_HUB_STATE_IND").getValue().toString().equalsIgnoreCase("1")){
							communication = new CommunicationType();
							LOG.debug("============adding CommunicationType ");

							communication.setROWIDCOMMUNICATION(record.getField("ROWID_COMMUNICATION").getStringValue());
							communication.setCOMMTYPE(record.getField("COMM_TYPE").getStringValue());
							communication.setCOMMVALUE(record.getField("COMM_VALUE").getStringValue());
							communication.setCOMMSTATUS(record.getField("COMM_STATUS").getStringValue());
							communication.setPRFRDCOMMIND(record.getField("PRFRD_COMM_IND").getStringValue());
							communication.setWEBDOMAIN(record.getField("WEB_DOMAIN").getStringValue());
							communication.setCOMMEXTN(record.getField("COMM_EXTN").getStringValue());
							communication.setCOMMMKTGPREF(record.getField("COMM_MKTG_PREF").getStringValue());
							if(isContactRec){
								communication.setCOMMSALESPREF(record.getField("COMM_SALES_PREF").getStringValue());
							}
							LOG.debug("===Inserting into Communication Map===");
							searchedRecCollObj.getCommMap().put(record.getField("ROWID_COMMUNICATION").getStringValue(), communication);
							}

						}
						
						if(!isContactRec){
						if (record.getField("ROWID_CLASSIFCTN").getStringValue() != null && 
								!searchedRecCollObj.getClassMap().containsKey(record.getField("ROWID_CLASSIFCTN").getStringValue())) {
							if(record.getField("CLASSIFCTN_HUB_STATE_IND")!=null && record.getField("CLASSIFCTN_HUB_STATE_IND").getValue().toString().equalsIgnoreCase("1")){
							classfction = new ClassificationType();
							LOG.debug("============adding ClassificationType ");
		
							classfction.setROWIDCLASSIFICTN(record.getField("ROWID_CLASSIFCTN").getStringValue());
							classfction.setCLASSIFICTNTYPE(record.getField("CLASSIFCTN_TYPE").getStringValue());
							classfction.setCLASSIFICTNVALUE(record.getField("CLASSIFCTN_VALUE").getStringValue());
							classfction.setCLASSIFICTNMETH(record.getField("CLASSIFCTN_METH").getStringValue());
							/** changes for Sales Force Integration -Start */
							//For Golden copy date display in response - Fix
							//classfction.setSTARTDATE(record.getField("START_DATE").getStringValue());
							//classfction.setENDDATE(record.getField("END_DATE").getStringValue());
							  Date startDate = record.getField("START_DATE").getDateValue();
                              Date endDate   = record.getField("END_DATE").getDateValue();
                              if(startDate != null) {
                                  String formatedStartDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(startDate);                       
                                  classfction.setSTARTDATE(formatedStartDate);                                                
                              }
                              if( endDate != null) {
                                    String formatedEndDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(endDate);                   
                                    classfction.setENDDATE(formatedEndDate);
                              }
                              /** changes for Sales Force Integration -End */
							LOG.debug("===Inserting into Classification Map===");
							searchedRecCollObj.getClassMap().put(record.getField("ROWID_CLASSIFCTN").getStringValue(), classfction);
							}
		
						}
						/** Modified for SFDC START */
					
						if (record.getField("ROWID_ORG_EXTN").getStringValue() != null &&
								!searchedRecCollObj.getPartyOrgMap().containsKey(record.getField("ROWID_ORG_EXTN").getStringValue())) {

						if(record.getField("ORG_EXTN_HUB_STATE_IND").getValue().toString().equalsIgnoreCase("1")){
						partyOrgExt = new PartyOrgExtType();
						LOG.debug("============adding PartyOrgExtType ");


						partyOrgExt.setROWIDORGEXTN(record.getField("ROWID_ORG_EXTN").getStringValue());
						partyOrgExt.setORGDUNSNBR(record.getField("ORG_DUNS_NBR").getStringValue());
						partyOrgExt.setTRADENAME(record.getField("TRADE_NAME").getStringValue());
						partyOrgExt.setTRADENAME2(record.getField("TRADE_NAME_2").getStringValue());
						partyOrgExt.setSITEEMPLCNT(record.getField("SITE_EMPL_CNT").getStringValue());
						partyOrgExt.setGLBLEMPLCNT(record.getField("GLBL_EMPL_CNT").getStringValue());
						partyOrgExt.setVERTICAL(record.getField("VERTICAL").getStringValue());
						partyOrgExt.setREVENUE(record.getField("REVENUE").getStringValue());
						//partyOrgExt.setLINEOFBUS(record.getField("LINE_OF_BUS").getStringValue());
						if (record.getField("PRIM_SIC").getStringValue() != null){
						partyOrgExt.setLINEOFBUS(getLineOfBus(record.getField("PRIM_SIC").getStringValue()));
						}
						partyOrgExt.setPRIMSIC(record.getField("PRIM_SIC").getStringValue());
						partyOrgExt.setSECSIC(record.getField("SEC_SIC").getStringValue());
						partyOrgExt.setSALESVOLUME(record.getField("SALES_VOLUME").getStringValue());
						partyOrgExt.setSALESAMOUNT(record.getField("SALES_AMOUNT").getStringValue());
						partyOrgExt.setCURRENCYCD(record.getField("CURRENCY_CD").getStringValue());
						partyOrgExt.setOUTOFBUSIND(record.getField("OUT_OF_BUS_IND").getStringValue());
						partyOrgExt.setGLBLULTIND(record.getField("GLBL_ULT_IND").getStringValue());
						partyOrgExt.setFORTUNEINFO(record.getField("FORTUNE_INFO").getStringValue());
						partyOrgExt.setHIERARCHYLEVEL(record.getField("HIERARCHY_LEVEL").getStringValue());
						partyOrgExt.setORGHQPARENTDUNS(record.getField("ORG_HQ_PARENT_DUNS").getStringValue());
						partyOrgExt.setORGDOMULTDUNS(record.getField("ORG_DOM_ULT_DUNS").getStringValue());
						partyOrgExt.setORGGLBULTDUNS(record.getField("ORG_GLB_ULT_DUNS").getStringValue());
						partyOrgExt.setMFEGLBLPARENTNM(record.getField("MFE_GLBL_PARENT_NM").getStringValue());
						partyOrgExt.setMFEPARENTNM(record.getField("MFE_PARENT_NM").getStringValue());
						partyOrgExt.setMFEPRTNRPARENTORG(record.getField("MFE_PRTNR_PARENT_ORG").getStringValue()); 
						partyOrgExt.setSALESREVNUOVRID(record.getField("SALES_REVNU_OVRID").getStringValue());
						partyOrgExt.setMFEEMPCNTOVERIDE(record.getField("MFE_EMP_CNT_OVERIDE").getStringValue());
						partyOrgExt.setSICCDOVRIDE(record.getField("SIC_CD_OVRIDE").getStringValue());
						/** changes for Track-2 -Start */
						partyOrgExt.setMFECOUNTRYULTUCN(record.getField("MFE_COUNTRY_ULT_UCN").getStringValue());
						partyOrgExt.setMFEGLBLPARENTUCN(record.getField("MFE_GLBL_PARENT_UCN").getStringValue());
						partyOrgExt.setMFEGLOBALPARNMOVRIDE(record.getField("MFE_GLOBAL_PAR_NM_OVRIDE").getStringValue());
						partyOrgExt.setMFENEXTLVLSUBSPARNM(record.getField("MFE_NEXT_LVL_SUBS_PAR_NM").getStringValue());
						partyOrgExt.setMFENEXTLVLSUBSPARUCN(record.getField("MFE_NEXT_LVL_SUBS_PAR_UCN").getStringValue());
						partyOrgExt.setMFESUBSDRYPARENTNM(record.getField("MFE_SUBS_PARENT_NM").getStringValue());
						partyOrgExt.setMFESUBSDRYPARENTPRTNNM(record.getField("MFE_SUBSDRY_PARENT_PRTN_NM").getStringValue());
						partyOrgExt.setMFESUBSPARENTNMOVRIDE(record.getField("MFE_SUBS_PARENT_NM_OVRIDE").getStringValue());
						partyOrgExt.setMFESUBSPARENTUCN(record.getField("MFE_SUBS_PARENT_UCN").getStringValue());
						partyOrgExt.setMFETXN5YRFLG(record.getField("MFE_TXN_5_YR_FLG").getStringValue());
						partyOrgExt.setMFETXN7YRFLG(record.getField("MFE_TXN_7_YR_FLG").getStringValue());
						partyOrgExt.setMFEWWPARENTNM(record.getField("MFE_WW_PARENT_NM").getStringValue());
						partyOrgExt.setMFEWWPARENTPRTNNM(record.getField("MFE_WW_PARENT_PRTN_NM").getStringValue());
						partyOrgExt.setTXN5YRFLG(record.getField("TXN_5_YR_FLG").getStringValue());
						partyOrgExt.setTXN7YRFLG(record.getField("TXN_7_YR_FLG").getStringValue());
						partyOrgExt.setGLBEMPCNTOVERRIDE(record.getField("GLB_EMP_CNT_OVERRIDE").getStringValue());
						partyOrgExt.setACTIVETXNFLG(record.getField("ACTIVE_TXN_FLAG").getStringValue());
						partyOrgExt.setPARENTFLG(record.getField("PARENT_FLAG").getStringValue());
						partyOrgExt.setPARTNERFLG(record.getField("PARTNER_FLAG").getStringValue());
						partyOrgExt.setCUSTFLG(record.getField("CUST_FLAG").getStringValue());
						partyOrgExt.setGLBFLG(record.getField("GLB_FLG").getStringValue());
						partyOrgExt.setCOUNTRYULTIND(record.getField("COUNTRY_ULT_IND").getStringValue());	
						//partyOrgExt.setCUSTOMPARENTUCN(record.getField("CUSTOM_PARENT_UCN").getStringValue());
						//partyOrgExt.setCUSTOMPARENTNAME(record.getField("CUSTOM_PARENT_NAME").getStringValue());
						partyOrgExt.setSUBSIDIARYIND(record.getField("SUBSIDIARY_IND").getStringValue());
						partyOrgExt.setMDMPARENTUCN(record.getField("MDM_PARENT_UCN").getStringValue());
					   // partyOrgExt.setCUSTOMERPARENTFLAG(record.getField("CUSTOMER_PARENT_FLAG").getStringValue());
						partyOrgExt.setG2KFLG(record.getField("G2K_FLG").getStringValue());
						partyOrgExt.setGLBSALESREVNUOVRID(record.getField("GLB_SALES_REVNU_OVRID").getStringValue());
						/** changes for Track-2 -End */
						/** changes for Track-3 -Start */
						partyOrgExt.setPTRPARENTUCN(record.getField("PTR_PARENT_UCN").getStringValue());
						partyOrgExt.setPTRPARENTNM(record.getField("PTR_PARENT_NM").getStringValue());
						partyOrgExt.setPTRGLBLPARENTUCN(record.getField("PTR_GLBL_PARENT_UCN").getStringValue());
						/** changes for Track-3 -End */
						LOG.debug("===Inserting into PartyOrgExtType Map==");
						searchedRecCollObj.getPartyOrgMap().put(record.getField("ROWID_ORG_EXTN").getStringValue(), partyOrgExt);
						}
				}
						
						
						if(bUniqueRec)	{
						/* changes for Hierarchy - Track2 -Start */
						Map<String,String> ucnMap = searchDao.getMdmHierarchyView(partyRowId);
						Map<String,String> partnerResellerUCNMap = null;
						if("Reseller".equalsIgnoreCase(partyType) || "Distributor".equalsIgnoreCase(partyType)){
							partnerResellerUCNMap = searchDao.getPartnerRellserHierarchyView(partyRowId,partyType);
						}else{
							partnerResellerUCNMap = new HashMap<String,String>();
							partnerResellerUCNMap.put("MDM_PRTNR_ORG_UCN","");
							partnerResellerUCNMap.put("PRTNR_ORG_NM","");
						}
						isGlobalParent = Util.isNullOrEmpty(ucnMap.get("GLB_FLG"))?isGlobalParent:ucnMap.get("GLB_FLG");
						String wwParentUcn = ucnMap.get("PTR_GLBL_PARENT_UCN");
						LOG.debug("WW Parent UCN "+wwParentUcn);
						String globalParentName = ucnMap.get("MFE_GLOBAL_PAR_NM_OVRIDE"); 
						 if(partyType.equalsIgnoreCase("Partner")||partyType.equalsIgnoreCase("Reseller")|| 
								 partyType.equalsIgnoreCase("Distributor")){
								LOG.debug("============adding Partner partyAccountRelationship ");
								
								if(!Util.isNullOrEmpty(wwParentUcn)){
									
									rowidRelationship = "0";  // As there is no party relation so rel rowid is set as 0
									partyAccountRelationship = new PartyAccountRelationshipType();
									LOG.debug("Populating Partner Hierarchy=== ");	
									if ("Partner".equalsIgnoreCase(partyType)) {
										partyAccountRelationship.setMDMPARENTUCN(ucnMap.get("PTR_PARENT_UCN"));
										partyAccountRelationship.setMDMPARENTNAME(ucnMap.get("PTR_PARENT_NM"));
									} else if("Reseller".equalsIgnoreCase(partyType) || "Distributor".equalsIgnoreCase(partyType)){
										partyAccountRelationship.setMDMPARENTUCN(partnerResellerUCNMap.get("MDM_PRTNR_ORG_UCN"));
										partyAccountRelationship.setMDMPARENTNAME(partnerResellerUCNMap.get("PRTNR_ORG_NM"));
									}
									partyAccountRelationship.setMDMGLBPARENTUCN(ucnMap.get("PTR_GLBL_PARENT_UCN"));
									partyAccountRelationship.setMDMGLBPARENTNAME(ucnMap.get("MFE_WW_PARENT_PRTN_NM"));
									partyAccountRelationship.setHIERARCHYTYPE(Constant.Partner_Hierarchy);
									
									if (partyAccountRelationship.getHIERARCHYTYPE() != null && hierarchyGRP.contains(partyAccountRelationship.getHIERARCHYTYPE())){
										if (!searchedRecCollObj.getPartyAcctRelMap()
												.containsKey(Constant.Partner_Hierarchy+rowidRelationship) ){
										LOG.debug("======Inserting into Partner Relationship Map======");
										searchedRecCollObj.getPartyAcctRelMap().put(partyAccountRelationship.getHIERARCHYTYPE()+rowidRelationship, partyAccountRelationship);
									}
								 }
								}
								
								
								  if(!Util.isNullOrEmpty(ucnMap.get("MDM_PARENT_UCN"))){
									  rowidRelationship = "1";  // As there is no party relation so rel rowid is set as 1
										partyAccountRelationship = new PartyAccountRelationshipType();
										partyAccountRelationship.setHIERARCHYTYPE(Constant.McAfee_Hierarchy);
										partyAccountRelationship.setMDMPARENTUCN(ucnMap.get("MDM_PARENT_UCN"));
										partyAccountRelationship.setMDMPARENTNAME(ucnMap.get("MFE_PARENT_NM"));
										partyAccountRelationship.setMDMGLBPARENTUCN(ucnMap.get("MFE_GLBL_PARENT_UCN"));
									if (Util.isNullOrEmpty(globalParentName)) {
										partyAccountRelationship.setMDMGLBPARENTNAME(ucnMap.get("MFE_GLBL_PARENT_NM"));
									} else {
										partyAccountRelationship.setMDMGLBPARENTNAME(ucnMap.get("MFE_GLOBAL_PAR_NM_OVRIDE"));
									}
										if (hierarchyGRP.contains(partyAccountRelationship.getHIERARCHYTYPE())) {
											LOG.debug("===Inserting into  McAfee_Hierarchy  Relationship Map==="+partyAccountRelationship.getHIERARCHYTYPE()+rowidRelationship);
											searchedRecCollObj.getPartyAcctRelMap().put(partyAccountRelationship.getHIERARCHYTYPE()+rowidRelationship,
													partyAccountRelationship);
										}
		                            }
								  } 
						 else if(partyType.equalsIgnoreCase("Customer")){
							 LOG.debug("============adding Mcafee Hierarchy partyAccountRelationship ");
							 
                            if(!Util.isNullOrEmpty(ucnMap.get("MDM_PARENT_UCN"))){
                            	rowidRelationship = "0";  // As there is no party relation so rel rowid is set as 0
								partyAccountRelationship = new PartyAccountRelationshipType();
								partyAccountRelationship.setHIERARCHYTYPE(Constant.McAfee_Hierarchy);
								partyAccountRelationship.setMDMPARENTUCN(ucnMap.get("MDM_PARENT_UCN"));
								partyAccountRelationship.setMDMPARENTNAME(ucnMap.get("MFE_PARENT_NM"));
								partyAccountRelationship.setMDMGLBPARENTUCN(ucnMap.get("MFE_GLBL_PARENT_UCN"));
							if (Util.isNullOrEmpty(globalParentName)) {
								partyAccountRelationship.setMDMGLBPARENTNAME(ucnMap.get("MFE_GLBL_PARENT_NM"));
							} else {
								partyAccountRelationship.setMDMGLBPARENTNAME(ucnMap.get("MFE_GLOBAL_PAR_NM_OVRIDE"));
							}
							if ((!Util.isNullOrEmpty(isGlobalParent)) && isGlobalParent.equalsIgnoreCase("N")) {
								if ((!Util.isNullOrEmpty(partyAccountRelationship.getMDMPARENTUCN())) && (!Util.isNullOrEmpty(partyAccountRelationship.getMDMGLBPARENTUCN()))
										&& (partyAccountRelationship.getMDMPARENTUCN().equals(partyAccountRelationship.getMDMGLBPARENTUCN()))) {
									LOG.debug("============set singlesite flag ");
									partyAccountRelationship.setSINGLESITEFLAG(Constant.STR_Y);
								} else {
									partyAccountRelationship.setSINGLESITEFLAG(Constant.STR_N);
								}
							} else {
								partyAccountRelationship.setSINGLESITEFLAG(Constant.STR_N);
							}
								if (hierarchyGRP.contains(partyAccountRelationship.getHIERARCHYTYPE())) {
									LOG.debug("===Inserting into  McAfee_Hierarchy  Relationship Map==="+partyAccountRelationship.getHIERARCHYTYPE()+rowidRelationship);
									searchedRecCollObj.getPartyAcctRelMap().put(partyAccountRelationship.getHIERARCHYTYPE()+rowidRelationship,
											partyAccountRelationship);
								}
								if(!Util.isNullOrEmpty(wwParentUcn)){
									
									rowidRelationship = "1";  // As there is no party relation so rel rowid is set as 1
									partyAccountRelationship = new PartyAccountRelationshipType();
									LOG.debug("Populating Partner Hierarchy=== ");							
									if("Reseller".equalsIgnoreCase(partyType) || "Distributor".equalsIgnoreCase(partyType)){
										partyAccountRelationship.setMDMPARENTUCN(partnerResellerUCNMap.get("MDM_PRTNR_ORG_UCN"));
										partyAccountRelationship.setMDMPARENTNAME(partnerResellerUCNMap.get("PRTNR_ORG_NM"));
									}else {
										partyAccountRelationship.setMDMPARENTUCN(ucnMap.get("PTR_PARENT_UCN"));
										partyAccountRelationship.setMDMPARENTNAME(ucnMap.get("PTR_PARENT_NM"));
									}
									partyAccountRelationship.setMDMGLBPARENTUCN(ucnMap.get("PTR_GLBL_PARENT_UCN"));
									partyAccountRelationship.setMDMGLBPARENTNAME(ucnMap.get("MFE_WW_PARENT_PRTN_NM"));
									partyAccountRelationship.setHIERARCHYTYPE(Constant.Partner_Hierarchy);
									if (partyAccountRelationship.getHIERARCHYTYPE() != null && hierarchyGRP.contains(partyAccountRelationship.getHIERARCHYTYPE())){
										if (!searchedRecCollObj.getPartyAcctRelMap().containsKey(Constant.Partner_Hierarchy+rowidRelationship) ){
										LOG.debug("======Inserting into Partner Relationship Map======");
										searchedRecCollObj.getPartyAcctRelMap().put(partyAccountRelationship.getHIERARCHYTYPE()+rowidRelationship, partyAccountRelationship);
									}
	                            }
								}
							
                            }
							else {
								if (searchedRecCollObj.getPartyAcctRelMap().isEmpty()) {
									LOG.debug("============adding dummy partyAccountRelationship ");
									rowidRelationship = "0"; 
									partyAccountRelationship = new PartyAccountRelationshipType();
									if (!"Y".equalsIgnoreCase(isGlobalParent)) {
										partyAccountRelationship.setMDMPARENTUCN(searchedRecCollObj.getUcn());
										partyAccountRelationship.setMDMPARENTNAME(searchedRecCollObj.getParty_name());
										partyAccountRelationship.setMDMGLBPARENTUCN(searchedRecCollObj.getUcn());
										partyAccountRelationship.setMDMGLBPARENTNAME(searchedRecCollObj.getParty_name());
										partyAccountRelationship.setHIERARCHYTYPE(Constant.McAfee_Hierarchy);
										partyAccountRelationship.setSINGLESITEFLAG(Constant.STR_Y);
									}
									if (partyAccountRelationship.getHIERARCHYTYPE() != null
											&& hierarchyGRP.contains(partyAccountRelationship.getHIERARCHYTYPE())) {
										LOG.debug("======Inserting into Single Site Relationship Map======");
										searchedRecCollObj.getPartyAcctRelMap().put(rowidRelationship,
												partyAccountRelationship);
									}

								}
							}
						 }
						 else {
							 if(searchedRecCollObj.getPartyAcctRelMap().isEmpty()){
									LOG.debug("============adding dummy partyAccountRelationship ");
									rowidRelationship = "0"; // As there is no party
																// relation so rel rowid
																// is set as 0

									partyAccountRelationship = new PartyAccountRelationshipType();

									if(!Util.isNullOrEmpty(wwParentUcn)){
										LOG.debug("Populating Partner Hierarchy=== ");
										if("Reseller".equalsIgnoreCase(partyType) || "Distributor".equalsIgnoreCase(partyType)){
											partyAccountRelationship.setMDMPARENTUCN(partnerResellerUCNMap.get("MDM_PRTNR_ORG_UCN"));
											partyAccountRelationship.setMDMPARENTNAME(partnerResellerUCNMap.get("PRTNR_ORG_NM"));
										}else{
										partyAccountRelationship.setMDMPARENTUCN(ucnMap.get("PTR_PARENT_UCN"));
										partyAccountRelationship.setMDMPARENTNAME(ucnMap.get("PTR_PARENT_NM"));
										}
										partyAccountRelationship.setMDMGLBPARENTUCN(ucnMap.get("PTR_GLBL_PARENT_UCN"));
										partyAccountRelationship.setMDMGLBPARENTNAME(ucnMap.get("MFE_WW_PARENT_PRTN_NM"));
										partyAccountRelationship.setHIERARCHYTYPE(Constant.Partner_Hierarchy);
									}else if (!"Y".equalsIgnoreCase(isGlobalParent)) {
										partyAccountRelationship.setMDMPARENTUCN(searchedRecCollObj.getUcn());
										partyAccountRelationship.setMDMPARENTNAME(searchedRecCollObj.getParty_name());
										partyAccountRelationship.setMDMGLBPARENTUCN(searchedRecCollObj.getUcn());
										partyAccountRelationship.setMDMGLBPARENTNAME(searchedRecCollObj.getParty_name());
										partyAccountRelationship.setHIERARCHYTYPE(Constant.McAfee_Hierarchy);
										partyAccountRelationship.setSINGLESITEFLAG(Constant.STR_Y);
									}
									if (partyAccountRelationship.getHIERARCHYTYPE() != null && hierarchyGRP.contains(partyAccountRelationship.getHIERARCHYTYPE())){
										LOG.debug("======Inserting into Single Site Relationship Map======");
										searchedRecCollObj.getPartyAcctRelMap().put(rowidRelationship, partyAccountRelationship);
									}
								}
							}
						}
					}
						
						bUniqueRec = false;
						
					}
						
					LOG.debug("====Populating PartyProfileList");

					partyResponse.setROWIDOBJECT(searchedRecCollObj.getParty_rowid());
					partyResponse.setBOCLASSCODE(searchedRecCollObj.getBo_class());
					partyResponse.setPARTYTYPE(searchedRecCollObj.getParty_type());
					partyResponse.setPARTYNAME(searchedRecCollObj.getParty_name());
					partyResponse.setGEO(searchedRecCollObj.getGeo());
					partyResponse.setREGION(searchedRecCollObj.getRegion());
					partyResponse.setSTATUSCD(searchedRecCollObj.getStatus_cd());
					partyResponse.setVATREGNBR(searchedRecCollObj.getVat_regno());
					partyResponse.setTAXJURSDCTNCD(searchedRecCollObj.getTax_jd_cd());
					partyResponse.setSALESBLOCKCD(searchedRecCollObj.getSales_cd());
					partyResponse.setUCN(searchedRecCollObj.getUcn());
					/** changes for Sales Force Integration - to send sippop in match rule for self match */
					partyResponse.setSIPPOP(searchedRecCollObj.getSipPop());
					partyResponse.setMSGTRKNID(searchedRecCollObj.getMsgTrackingId());
					partyResponse.setSRCUPDTBY(searchedRecCollObj.getSrcUpdateBy());
					partyResponse.setPHYSICALGEO(searchedRecCollObj.getPhysicalGeo());
					partyResponse.setPHYSICALREGION(searchedRecCollObj.getPhysicalRegion());
					partyResponse.setUPDATEDATE(searchedRecCollObj.getUpdatedate());
					partyResponse.setENGLISHNAME(searchedRecCollObj.getEnglish_name());
					if(isContactRec){
						partyResponse.getPartyPerson().addAll(searchedRecCollObj.getPartyPersnMap().values());
					}
					if(!isContactRec){
						partyResponse.getAccount().addAll(searchedRecCollObj.getAccountMap().values());
						partyResponse.getClassification().addAll(searchedRecCollObj.getClassMap().values());
					}
					partyResponse.getAddress().addAll(searchedRecCollObj.getAddressMap().values());
					partyResponse.getCommunication().addAll(searchedRecCollObj.getCommMap().values());
				    partyResponse.getPartyOrgExt().addAll(searchedRecCollObj.getPartyOrgMap().values());
					if(partyRelationship == null) {
						partyRelationship = new PartyRelationshipType();
					}
					partyRelationship.getPARTYACCOUNTREL().addAll(searchedRecCollObj.getPartyAcctRelMap().values());
					
					LOG.info("================Adding Subsidiary Hierarchy==============");
					LOG.info("partyResponse.getROWIDOBJECT()::"+partyResponse.getROWIDOBJECT());
					//Added as part of Adobe integration - <Start>					
					if(Constant.PARTY_TYPE_CUSTOMER.equalsIgnoreCase(partyResponse.getPARTYTYPE()) || 
							Constant.PARTY_TYPE_PROSPECT_ACCOUNT.equalsIgnoreCase(partyResponse.getPARTYTYPE())){
					Map<String,String> ucnMap = searchDao.getMdmHierarchyView(partyResponse.getROWIDOBJECT().trim());	
					String globalFlag = ucnMap.get("GLB_FLG");
					String singleSiteFlag = "";
					String mdmParentUcn = "";
					String mdmParentName = "";
					String ucn = Util.isNullOrEmpty(partyResponse.getUCN())?"":partyResponse.getUCN();
					String glbParentUcn = ucnMap.get("MFE_GLBL_PARENT_UCN");
					String subParentUcn = ucnMap.get("MFE_SUBS_PARENT_UCN");
					String nextLvlParentUcn = ucnMap.get("MFE_NEXT_LVL_SUBS_PAR_UCN");
					LOG.info("glbParentUcn::"+glbParentUcn);
					LOG.info("subParentUcn::"+subParentUcn);
					LOG.info("nextLvlParentUcn::"+nextLvlParentUcn);
					if(ucn.equalsIgnoreCase(subParentUcn)){
						mdmParentUcn = nextLvlParentUcn;
						mdmParentName = ucnMap.get("MFE_NEXT_LVL_SUBS_PAR_NM");
					}else{
						mdmParentUcn = subParentUcn;
						mdmParentName = ucnMap.get("MFE_SUBS_PARENT_NM");
					}
					
					if(ucn.equalsIgnoreCase(glbParentUcn) && (Util.isNullOrEmpty(globalFlag)||"N".equalsIgnoreCase(globalFlag))){
						singleSiteFlag = "Y";
					}else{
						singleSiteFlag = "N";
					}
					
					PartyAccountRelationshipType partyAccRelparam = new PartyAccountRelationshipType();
					partyAccRelparam.setHIERARCHYTYPE(Constant.Subsidiary_Hierarchy);
					if(!Util.isNullOrEmpty(subParentUcn) || !Util.isNullOrEmpty(nextLvlParentUcn)){
						partyAccRelparam.setMDMPARENTUCN(mdmParentUcn);
						partyAccRelparam.setMDMPARENTNAME(mdmParentName);
						partyAccRelparam.setMDMGLBPARENTUCN(glbParentUcn);
						partyAccRelparam.setMDMGLBPARENTNAME(ucnMap.get("MFE_GLBL_PARENT_NM"));
						partyAccRelparam.setSINGLESITEFLAG(singleSiteFlag);
					}else{
						partyAccRelparam.setMDMPARENTUCN(ucn);
						partyAccRelparam.setMDMPARENTNAME(searchedRecCollObj.getParty_name());
						partyAccRelparam.setMDMGLBPARENTUCN(ucn);
						partyAccRelparam.setMDMGLBPARENTNAME(searchedRecCollObj.getParty_name());
						partyAccRelparam.setSINGLESITEFLAG("Y");
					}
					partyRelationship.getPARTYACCOUNTREL().add(partyAccRelparam);
					//Added as part of Adobe integration - <END>
					}
					partyResponse.setPartyRel(partyRelationship);
				} //end of if
			} catch (Exception exp) {
				LOG.error("Exception occurred in processing golden copy resultset", exp);
				//exp.printStackTrace();
				ServiceProcessingException customException = new ServiceProcessingException(exp);
				customException.setMessage("Failed to process golden copy resultset: " + exp.getMessage());
				throw customException;
			}
			LOG.info("Executed processGoldenCopyResults()");
			if(partyResponse!=null){
				CanonicalFormManipulator.setDefaultValueInGoldenAttributes(partyResponse);
			}
			
			if(partyResponse.getAccount()!=null && partyResponse.getAccount().size()>0){
				if(Util.isNullOrEmpty(partyResponse.getAccount().get(0).getACCTNAME())){
					partyResponse.getAccount().clear();
				}
			}
			if(partyResponse.getAddress()!=null && partyResponse.getAddress().size()>0){
				if(Util.isNullOrEmpty(partyResponse.getAddress().get(0).getADDRTYPE())){
					partyResponse.getAddress().clear();
				}
			}
			if(partyResponse.getCommunication()!=null && partyResponse.getCommunication().size()>0){
				if(Util.isNullOrEmpty(partyResponse.getCommunication().get(0).getCOMMTYPE())){
					partyResponse.getCommunication().clear();
				}
			}
			if(partyResponse.getClassification()!=null && partyResponse.getClassification().size()>0){
				if(Util.isNullOrEmpty(partyResponse.getClassification().get(0).getCLASSIFICTNTYPE())){
					partyResponse.getClassification().clear();
				}
			}
			if(partyResponse.getPartyOrgExt()!=null && partyResponse.getPartyOrgExt().size()>0){
				if(Util.isNullOrEmpty(partyResponse.getPartyOrgExt().get(0).getROWIDORGEXTN())){
					partyResponse.getPartyOrgExt().clear();
				}
			}
			if(partyResponse.getPartyPersonExt()!=null && partyResponse.getPartyPersonExt().size()>0){
				if(Util.isNullOrEmpty(partyResponse.getPartyPersonExt().get(0).getPERSONTYPE())){
					partyResponse.getPartyPersonExt().clear();
				}
			}
			if(partyResponse.getPartyPerson()!=null && partyResponse.getPartyPerson().size()>0){
				if(Util.isNullOrEmpty(partyResponse.getPartyPerson().get(0).getFIRSTNAME()) && Util.isNullOrEmpty(partyResponse.getPartyPerson().get(0).getLASTNAME())){
					partyResponse.getPartyPerson().clear();
				}
			}
			/*if(partyResponse.getPartyRel()!=null){
				if(partyResponse.getPartyRel().getPARTYACCOUNTREL()!=null && partyResponse.getPartyRel().getPARTYACCOUNTREL().size()>0){
					if(Util.isNullOrEmpty(partyResponse.getPartyRel().getPARTYACCOUNTREL().get(0).getHIERARCHYTYPE())){
						partyResponse.getPartyRel().getPARTYACCOUNTREL().clear();
					}
				}
				if(partyResponse.getPartyRel().getPARTYPERSONREL()!=null && partyResponse.getPartyRel().getPARTYPERSONREL().size()>0){
					if(Util.isNullOrEmpty(partyResponse.getPartyRel().getPARTYPERSONREL().get(0).getHIERARCHYTYPE())){
						partyResponse.getPartyRel().getPARTYPERSONREL().clear();
					}
				}
			}*/
			return partyResponse;
		}
		
		public String getLineOfBus(String primsSic) throws ServiceProcessingException	{
			LOG.debug("[getLineOfBus] ENTER");
			Connection jdbcConn = null;
			Statement statement = null;
			ResultSet resultSet = null;
			String lineofBus = null;
			
			StringBuilder sqlQuery = new StringBuilder();
			
			
			sqlQuery.append(Constant.QUERY_GET_LINE_OF_BUS +"'" + primsSic + "'");
		
			LOG.debug("Query for getLineOfBus: "+sqlQuery.toString());
			
			try {
					JDBCConnectionProvider jDBCConnectionProvider =  JDBCConnectionProvider.getSingleInstance();
					jdbcConn = jDBCConnectionProvider.getJdbcConnectionFromDS();
					statement = jdbcConn.createStatement();
					resultSet = statement.executeQuery(sqlQuery.toString());
		
					while (resultSet.next()) {
						lineofBus = resultSet.getString(1);
					}
			 } catch(SQLException sqlex) {
				 LOG.error("Caught sql exception in getLineOfBus()." + sqlex);
			 } finally {
				try {	//Closing connections
						if (resultSet != null) resultSet.close();
						if (statement != null) statement.close();
						if (jdbcConn != null) jdbcConn.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
			 }
			LOG.debug("Executed getLineOfBus");
			return lineofBus;	
		}
}
