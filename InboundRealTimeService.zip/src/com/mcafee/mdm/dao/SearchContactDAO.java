package com.mcafee.mdm.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;
import java.util.TreeSet;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.mcafee.mdm.constants.Constant;
import com.mcafee.mdm.constants.MDMAttributeNames;
import com.mcafee.mdm.constants.PartyAttributes;
import com.mcafee.mdm.constants.SearchMatchAttributes;
import com.mcafee.mdm.dao.pojo.SearchedRecordCollection;
import com.mcafee.mdm.dao.pojo.SearchedXrefRecordCollection;
import com.mcafee.mdm.exception.ServiceProcessingException;
import com.mcafee.mdm.generated.AccountType;
import com.mcafee.mdm.generated.AccountXrefType;
import com.mcafee.mdm.generated.AddressType;
import com.mcafee.mdm.generated.AddressXrefType;
import com.mcafee.mdm.generated.ClassificationType;
import com.mcafee.mdm.generated.ClassificationXrefType;
import com.mcafee.mdm.generated.CommunicationType;
import com.mcafee.mdm.generated.CommunicationXrefType;
import com.mcafee.mdm.generated.ContactProfileType;
import com.mcafee.mdm.generated.ContactSearchCriteriaType;
import com.mcafee.mdm.generated.ContactType;
import com.mcafee.mdm.generated.GoldenCopy;
import com.mcafee.mdm.generated.PartyAccountRelationshipType;
import com.mcafee.mdm.generated.PartyAccountRelationshipXrefType;
import com.mcafee.mdm.generated.PartyOrgExtType;
import com.mcafee.mdm.generated.PartyOrgExtXrefType;
import com.mcafee.mdm.generated.PartyPersonExtType;
import com.mcafee.mdm.generated.PartyPersonType;
import com.mcafee.mdm.generated.PartyPersonXrefType;
import com.mcafee.mdm.generated.PartyProfileType;
import com.mcafee.mdm.generated.PartyRelationshipType;
import com.mcafee.mdm.generated.PartyRelationshipXrefType;
import com.mcafee.mdm.generated.PartySearchCriteriaType;
import com.mcafee.mdm.generated.PartyType;
import com.mcafee.mdm.generated.PartyXrefType;
import com.mcafee.mdm.generated.SearchContactRequest;
import com.mcafee.mdm.generated.SearchContactResponse;
import com.mcafee.mdm.generated.SearchPartyRequest;
import com.mcafee.mdm.generated.SearchPartyResponse;
import com.mcafee.mdm.generated.XREFCopy;
import com.mcafee.mdm.generated.XREFType;
import com.mcafee.mdm.util.CanonicalFormManipulator;
import com.mcafee.mdm.util.CommonUtil;
import com.mcafee.mdm.util.JDBCConnectionProvider;
import com.mcafee.mdm.util.ObjectPool;
import com.mcafee.mdm.util.PerformanceLoggerUtil;
import com.mcafee.mdm.util.PropertyUtil;
import com.mcafee.mdm.util.Util;
import com.siperian.sif.client.SiperianClient;
import com.siperian.sif.client.SiperianServerException;
import com.siperian.sif.message.Field;
import com.siperian.sif.message.HubStateIndicator;
import com.siperian.sif.message.MatchType;
import com.siperian.sif.message.Record;
import com.siperian.sif.message.SiperianObjectType;
import com.siperian.sif.message.mrm.SearchMatchRequest;
import com.siperian.sif.message.mrm.SearchMatchResponse;

@Component
@Scope("prototype")
public class SearchContactDAO extends ObjectPool {
	private static final Logger LOG = Logger.getLogger(SearchContactDAO.class.getName());
	
//	@Resource(name = "configProp")
//	private Properties configProps;
	@Autowired
	private CommonUtil commonUtil;
	@Autowired
	private SearchPartyDAO searchPartyDAO;
	Properties configProps = PropertyUtil.getPropertiesFromFile("configProp");
	String matchScoreThresDef = configProps.getProperty("matchScore-Threshold");
//	String ruleSetName = configProps.getProperty("contactMatchRuleSet");
	String getPkgName = configProps.getProperty("pkgName");
	int recCountThresDef = Integer.parseInt(configProps.getProperty("recToReturnCount"));
	
//	String custGrpProsPartner = configProps.getProperty("custGrpProsPartner");
	String rowid_object = null;
	Map<String, Integer> recordMap = new HashMap<String, Integer>();
	Map<String,String> cntctAcctMap = null;
	PerformanceLoggerUtil perfLog = new PerformanceLoggerUtil();
//	@Autowired
//	SearchPartyXrefDAO searchXrefDao;


	//Method For Fuzzy Match
	public SearchPartyResponse processFuzzySearchRequest(
			SearchPartyRequest parameters) throws ServiceProcessingException {
		LOG.info("Executing processFuzzySearchRequest()");
		String searchType = null;
		MatchType matchType = null;

		if(!Util.isNullOrEmpty(parameters.getSearchType()))	{
			searchType = parameters.getSearchType();
		}

		PartySearchCriteriaType partyCriteria = parameters.getPartySearchCriteria();
		String matchScoreThresIp = parameters.getMatchScoreThresold();
		int minMatchScoreThres = 0;
		int mtchScoreValue = 0;
		Integer recCountThresIp = 0;
		String countryName = null ;

		if(!Util.isNullOrEmpty(partyCriteria.getCOUNTRYCD())){
			countryName = getCL_SIP_POP(partyCriteria.getCOUNTRYCD());
		}

		if (parameters.getRecordCountThresold() != null && parameters.getRecordCountThresold().length() > 0) {
			 recCountThresIp = Integer.parseInt(parameters.getRecordCountThresold());
		}
		int recCntThres = 0;
		String searchRuleSet = null;

		//Setting MatchScoreThreshold
		if(matchScoreThresIp != null && matchScoreThresIp.length() > 0)		{
			//Taking User entered value from SearchPartyRequest
			minMatchScoreThres = Integer.parseInt(matchScoreThresIp);
		} else {
			//Taking Default value from Configuration File
			minMatchScoreThres = Integer.parseInt(matchScoreThresDef);
		}

		LOG.debug("Setting MatchScoreThreshold: " + minMatchScoreThres);

		//Setting RecordsToReturnCount
		if(recCountThresIp != null && recCountThresIp.intValue() != 0)	{
			recCntThres = recCountThresIp;
		} else  {
			recCntThres = recCountThresDef;
		}

		LOG.debug("Setting RecordsToReturnCount: " + recCntThres);

		//Automated or Manual RuleSet based on SearchType
	//	if(Util.isNullOrEmpty(searchType) || searchType.equalsIgnoreCase("Auto"))	{
	//		searchRuleSet = configProps.getProperty("contactMatchRuleSet");
			searchRuleSet = "Party Person Fuzzy Rule Set New";
			matchType = MatchType.BOTH;
	//	} else {
	//		searchRuleSet = configProps.getProperty("manualSearchRuleSet");
	//		matchType = MatchType.AUTO;
	//	}

		SearchPartyResponse searchPartyMasterResponse = new SearchPartyResponse();

		SiperianClient siperianClient = null;

		SearchMatchRequest searchMatchRequest = null;
		SearchMatchResponse searchMatchResponse = null;


		searchMatchRequest = new SearchMatchRequest();
		searchMatchRequest.setRecordsToReturn(recCntThres); // Required
	//	searchMatchRequest.setSiperianObjectUid("PKG_PARTY_JMS_MQ_PUB");// Required
	//	searchMatchRequest.setSiperianObjectUid("PKG_BO_PERSON_SEARCH");//PKG_BO_PERSON_SEARCH
		searchMatchRequest.setSiperianObjectUid("PKG_BO_PERSON_SEARCH");
	//	searchMatchRequest.setSiperianObjectUid(getPkgName);// Required

	//  searchMatchRequest.setMatchRuleSetUid(SiperianObjectType.MATCH_RULE_SET.makeUid("Org_addr_fuzzy_RealTime"));// Sample_Fuzzy_Search_Rule
		searchMatchRequest.setMatchRuleSetUid(SiperianObjectType.MATCH_RULE_SET.makeUid(searchRuleSet));//searchRuleSet,ruleSetName
		searchMatchRequest.setMatchType(matchType);

		LOG.info("Match Rule Set: " + searchMatchRequest.getMatchRuleSetUid());
		LOG.info("Match Type :" + searchMatchRequest.getMatchType());

		//Organization_Name
		Field org_name = new Field("Organization_Name");
		StringBuilder orgNameConcat = new StringBuilder();
		if (!Util.isNullOrEmpty(partyCriteria.getFIRSTNAME())) {
			orgNameConcat.append(partyCriteria.getFIRSTNAME());
	//		LOG.info("First name :" + partyCriteria.getFIRSTNAME());
		
		}
		if (!Util.isNullOrEmpty(partyCriteria.getLASTNAME())) {
			orgNameConcat.append(" ");
			orgNameConcat.append(partyCriteria.getLASTNAME());
	//		LOG.info("First name :" + partyCriteria.getFIRSTNAME());
		
		}
		if(orgNameConcat != null && orgNameConcat.length() > 0){
			org_name.setStringValue(orgNameConcat.toString());
			searchMatchRequest.addMatchColumnField(org_name);
		}
		LOG.info("Field to search for :" + org_name.getName() + ':' + org_name.getStringValue());

		//Person_Name
		Field field_name = new Field("Person_Name");
		if(orgNameConcat != null && orgNameConcat.length() > 0){
			field_name.setStringValue(orgNameConcat.toString());
			searchMatchRequest.addMatchColumnField(field_name);
		}
		LOG.info("Field to search for :" + field_name.getName() + ':' + field_name.getStringValue());

		// Setting Ex_Comm_Typ_Type
		Field field_Eml_Type = new Field("Ex_Comm_Type_Email");
		field_Eml_Type.setStringValue("Email");
		searchMatchRequest.addMatchColumnField(field_Eml_Type);

		LOG.info("Field to search for :" + field_Eml_Type.getName()
				+ ':' + field_Eml_Type.getStringValue());

		// Setting Ex_Comm_Val_Eml
		Field field_Eml_Val = new Field("Ex_Comm_Val_Email");
		StringBuilder contEmlVal = new StringBuilder();
		if (!Util.isNullOrEmpty(partyCriteria.getEMAILADDRESS())) {	
			contEmlVal.append(partyCriteria.getEMAILADDRESS());
			field_Eml_Val.setStringValue(contEmlVal.toString());

			searchMatchRequest.addMatchColumnField(field_Eml_Val);
			
			LOG.info("Field to search for :" + field_Eml_Val.getName()
					+ ':' + field_Eml_Val.getStringValue());
		}

		// Setting field_Entity_Type
		Field field_Entity_Type = new Field("Ex_Entity_Type");
		field_Entity_Type.setStringValue("Person");
		searchMatchRequest.addMatchColumnField(field_Entity_Type);

		LOG.info("Field to search for :" + field_Entity_Type.getName()
				+ ':' + field_Entity_Type.getStringValue());

		// Adding SIP_POP
		Field field_SIPPOP = new Field("SIP_POP");
		field_SIPPOP.setStringValue(countryName);// sipPopVal
		searchMatchRequest.addMatchColumnField(field_SIPPOP);
		LOG.info("Field to match for :" + field_SIPPOP.getName() + ':'
				+ field_SIPPOP.getStringValue());

		StringBuffer criteria = new StringBuffer();
		boolean firstParam = false;

/*
		if (!Util.isNullOrEmpty(partyCriteria.getUCN())) {
			if (firstParam)
				criteria.append(" AND UCN='"+ partyCriteria.getUCN() + "'");
			else {
				firstParam = true;
				criteria.append(" UCN='"+ partyCriteria.getUCN() + "'");
			}
		}
*/
		/*Adding COUNTRY_CD as Exact Match Column to avoid Cross Country Matching*/
		if (!Util.isNullOrEmpty(partyCriteria.getCOUNTRYCD())) {
			if (firstParam) {
				criteria.append(" AND UPPER(COUNTRY_CD) = UPPER('" + partyCriteria.getCOUNTRYCD() + "')");

			} else {
				firstParam = true;
				criteria.append(" UPPER(COUNTRY_CD) = UPPER('" + partyCriteria.getCOUNTRYCD() + "')");
			}
		}

		//Removing Soft-Deleted Records from Search
		if (firstParam) {
			criteria.append(" AND HUB_STATE_IND !='" + -1 + "'");
		} else {
			firstParam = true;
			criteria.append(" HUB_STATE_IND !='" + -1 + "'");
		}

		//Fetching Active Records from Search
		if (firstParam) {
			criteria.append(" AND STATUS_CD ='" + "A" + "'");
		} else {
			firstParam = true;
			criteria.append(" STATUS_CD ='" + "A" + "'");
		}

		LOG.info("Filter Criteria: " + criteria.toString());

		searchMatchRequest.setFilterCriteria(criteria.toString());
		try {
			siperianClient = (SiperianClient) checkOut();

			LOG.info("processing SearchMatchRequest");
			LOG.info("before request");
			searchMatchResponse = (SearchMatchResponse) siperianClient.process(searchMatchRequest);
			LOG.info("after response");
		} catch (SiperianServerException sifExcp) {
			LOG.error("SiperianServerException occured while processing SearchMatchRequest: " + sifExcp);
			LOG.error("Get Message: "+ sifExcp.getMessage());
			ServiceProcessingException customException = new ServiceProcessingException(sifExcp.getMessage());
			customException.setRootExceptionMsg(sifExcp + " SearchMatch operation failed for Party_Name: "+ partyCriteria.getPARTYNAME());
			searchPartyMasterResponse.setErrorMsg(customException.getRootExceptionMsg());
			customException.setMessage("SIF exception occured while processing SearchMatch request for Party. ");
			throw customException;
		} catch (Exception exp) {
			LOG.error("Exception occured while processing SearchMatchRequest: " + exp);
			LOG.error("SearchMatch Exeption :" + exp.getMessage());
			ServiceProcessingException customException = new ServiceProcessingException(exp);
			customException.setRootExceptionMsg(exp + " SearchMatch operation failed for Party_Name: "+ partyCriteria.getPARTYNAME());
			searchPartyMasterResponse.setErrorMsg(customException.getRootExceptionMsg());
			customException.setMessage("SIF exception occured while processing SearchMatch request for Party.");
			throw customException;
		} finally {
			checkIn(siperianClient);
		}

	//	try {

	//		Map<String, Integer> recordMap = new HashMap<String, Integer>();
			if (searchMatchResponse != null
					&& searchMatchResponse.getRecords().size() > 0) {
				LOG.info("SearchMatchResponse rec cnt="	+ searchMatchResponse.getRecords().size());

				List searchRecords = searchMatchResponse.getRecords();
		//		Map<String,String> cntctAcctMap = null;
				
				if (searchRecords != null && searchRecords.size() != 0) {
					for (Iterator iter = searchRecords.iterator(); iter
							.hasNext();) {
						Record record = (Record) iter.next();
						// Calculate Highest Match Score
				//		LOG.debug("Match Score :"+ record.getField("MATCH_SCORE").getValue());
						String mtchScore = record.getField("MATCH_SCORE").getValue().toString().trim();
						String trimmedPartyRowId = record.getField("ROWID_OBJECT").getStringValue().trim();
				//		int key = Integer.parseInt(trimmedKey);
						mtchScoreValue = Integer.parseInt(mtchScore);
						LOG.info("rowid_object :" + trimmedPartyRowId+ " scoreValue :" + mtchScoreValue);
						if(mtchScoreValue >= minMatchScoreThres)	{
							//Process only those records with matchScore > minMatchScoreThres
							recordMap.put(trimmedPartyRowId, mtchScoreValue);
						}else {
							LOG.debug("Match Score value for Party: " + trimmedPartyRowId + " is lesser than MinThreshold Value: " + minMatchScoreThres);
						}
						}//end for loop
					}//end if
					if(recordMap.size() == 0) {
						searchPartyMasterResponse.setStatus("No Record Found with MatchScore more than Match_score_thresold value.");
						return searchPartyMasterResponse;
					}else {
						cntctAcctMap = getAccountRowidByContactID(recordMap.keySet());
						/*To Add Filter Criteria If ACCOUNT_SOURCE_ID is provided in the Input*/
						if(partyCriteria.getACCOUNTSOURCEID() != null && partyCriteria.getACCOUNTSOURCEID().length() > 1){
							String acctID = partyCriteria.getACCOUNTSOURCEID();
							List<String> acctPkeyList = null; 
							if(recordMap.size() > 1){
								LOG.info("Multiple Matching Contacts Found....");
							}else {
								LOG.debug("Only 1 Matching Contact Rowid Found--> "+recordMap.keySet());
							//	cntctAcctMap = getAccountRowidByContactID(recordMap.keySet());
								if(cntctAcctMap != null && cntctAcctMap.size() > 0){
									Collection<String> accountRowids = cntctAcctMap.values();
									List<String> acctRowidList = new ArrayList<String>(accountRowids);
									acctPkeyList = getAccntPkeys(acctRowidList);
									if(acctPkeyList != null && acctPkeyList.size()>0){
										if(!acctPkeyList.contains(acctID)){
											searchPartyMasterResponse.setStatus(Constant.noRecordFoundSFDC+acctID);
											return searchPartyMasterResponse;
										}else {
											searchPartyMasterResponse = createGoldenCopyFuzzySearch(searchRecords);
										//	searchPartyMasterResponse = getAllPartyGolden(recordMap.keySet());
										}
									}
								/*	for(Map.Entry<String, String> cntcAcct: cntctAcctMap.entrySet()){
									
									}	*/
								}else{
									LOG.info("No record Found Matching with input ACCOUNT_SOURCE_ID: "+acctID);
									searchPartyMasterResponse.setStatus(Constant.noRecordFoundSFDC+acctID); 
								}
							}
						}//ACCOUNT_SOURCE_ID Filter 
						else{
							searchPartyMasterResponse = createGoldenCopyFuzzySearch(searchRecords);
						}
					}
				}	else {
					LOG.info("No record Found");
					searchPartyMasterResponse.setStatus(Constant.noRecordFound);

		}
			LOG.info("Executed processFuzzySearchRequest()");
			return searchPartyMasterResponse;
	}

	//Process Fuzzy Search Golden Records
	private SearchPartyResponse createGoldenCopyFuzzySearch(List<Record> searchRecords)throws ServiceProcessingException {

		LOG.info("Inside createGoldenCopyFuzzySearch()");
		SearchPartyResponse searchPartyMasterResponse = new SearchPartyResponse();
		try {

				PartyProfileType partyProfile = null;
				List<PartyProfileType> partyProfileList = new ArrayList<PartyProfileType>();
				GoldenCopy goldenCpy = null;
				XREFCopy xrefCopy = null;

				PartyType partyResponse = null;

				XREFType xref = null;
				CommunicationType communication = null;
				AccountType accInfo = null;
				AddressType address = null;
				ClassificationType classfction = null;
				PartyOrgExtType partyOrgExt = null;
				PartyPersonExtType partyPersonExt = null;
				PartyRelationshipType partyRelationship = null;
				PartyPersonType partyPerson = null;
				
				/** Modified for M4M START */
				PartyAccountRelationshipType partyAccountRelationship = null;				
				/** Modified for M4M END */

		//		List searchRecords = searchMatchResponse.getRecords();

				// Calculate Highest Match Score
		//		Map<Integer, Integer> matchScoreMap = new TreeMap<Integer, Integer>();
		//		Set resultMatchScore = null;
				Map<String, SearchedRecordCollection> searchedRecCollMap = new HashMap<String, SearchedRecordCollection>();
				SearchedRecordCollection searchedRecCollObj;
				boolean bUniqueRec = false;


					if (searchRecords != null && searchRecords.size() != 0) {
						for (Iterator<Record> iter = searchRecords.iterator(); iter.hasNext();) {
							Record record = (Record) iter.next();
							
						String partyRowId = record.getField("ROWID_OBJECT").getStringValue();
						String trimmedRowid = partyRowId.trim();
						String acctRowidObject = null;
						SearchedRecordCollection searchedRecCollAcct = null;
						/*Records below Match_Score will not be displayed*/
						if(recordMap.keySet().contains(trimmedRowid)){
						
							if(cntctAcctMap!=null && cntctAcctMap.size()>0)	{
								acctRowidObject = cntctAcctMap.get(trimmedRowid);
								LOG.debug("partyRowId: "+partyRowId+" |acctRowidObject: "+acctRowidObject);
							}
							if (!searchedRecCollMap.containsKey(partyRowId)) {

							LOG.debug("Populate searchedRecCollMap for new PARTY_ROWID " + partyRowId);
							searchedRecCollMap.put(partyRowId, new SearchedRecordCollection());
							bUniqueRec = true;
						}

						searchedRecCollObj = searchedRecCollMap.get(partyRowId);

						if(bUniqueRec)	{

						LOG.debug("============setting GoldenCopy");

						//	partyResponse.setROWIDOBJECT(record.getField("ROWID_OBJECT").getStringValue());
						searchedRecCollObj.setParty_rowid(record.getField("ROWID_OBJECT").getStringValue());
						//	partyResponse.setBOCLASSCODE(record.getField("BO_CLASS_CODE").getStringValue());
						searchedRecCollObj.setBo_class(record.getField("BO_CLASS_CODE").getStringValue());
						//	partyResponse.setPARTYTYPE(record.getField("PARTY_TYPE").getStringValue());
						searchedRecCollObj.setParty_type(record.getField("PARTY_TYPE").getStringValue());
						//	partyResponse.setPARTYNAME(record.getField("PARTY_NAME").getStringValue());
						searchedRecCollObj.setParty_name(record.getField("PARTY_NAME").getStringValue());
						//	partyResponse.setGEO(record.getField("GEO").getStringValue());
						searchedRecCollObj.setGeo(record.getField("GEO").getStringValue());
						//	partyResponse.setREGION(record.getField("REGION").getStringValue());
						searchedRecCollObj.setRegion(record.getField("REGION").getStringValue());
						//	partyResponse.setSTATUSCD(record.getField("STATUS_CD").getStringValue());
						searchedRecCollObj.setStatus_cd(record.getField("STATUS_CD").getStringValue());
						//	partyResponse.setVATREGNBR(record.getField("VAT_REG_NBR").getStringValue());
						searchedRecCollObj.setVat_regno(record.getField("VAT_REG_NBR").getStringValue());
						//	partyResponse.setTAXJURSDCTNCD(record.getField("TAX_JURSDCTN_CD").getStringValue());
						searchedRecCollObj.setTax_jd_cd(record.getField("TAX_JURSDCTN_CD").getStringValue());
						//	partyResponse.setSALESBLOCKCD(record.getField("SALES_BLOCK_CD").getStringValue());
						searchedRecCollObj.setSales_cd(record.getField("SALES_BLOCK_CD").getStringValue());
						//	partyResponse.setUCN(record.getField("UCN").getStringValue());
						searchedRecCollObj.setUcn(record.getField("UCN").getStringValue());
						searchedRecCollObj.setMtchScoreValue(recordMap.get(trimmedRowid));
						//Change for English Name :: Adding English name field to response
						searchedRecCollObj.setEnglish_name(record.getField("ENGLISH_NAME").getStringValue());



				//		LOG.debug("============setting XREFType");
				//		xref = new XREFType();
				//		String partyID = record.getField("ROWID_OBJECT").getStringValue();
				//		getPartyXref(partyID, xref);


				//		LOG.debug("===Inserting into XREFType list===");
				//		listXref = new ArrayList<XREFType>();
				//		listXref.add(xref);
				//		partyResponse.getXREF().addAll(listXref);

						}
						
						if(!Util.isNullOrEmpty(acctRowidObject))	{
							searchedRecCollAcct = getAccountDetails(acctRowidObject);
							LOG.debug("============setting AccountSiteBOInfo ");
							
							accInfo = new AccountType();
							accInfo.setROWIDACCOUNT(acctRowidObject);
							accInfo.setACCOUNTNAME(searchedRecCollAcct.getParty_name());
							accInfo.setACCOUNTPARTYTYPE(searchedRecCollAcct.getParty_type());
							accInfo.setMDMACCOUNTUCN(searchedRecCollAcct.getUcn());
							
							Collection<AddressType> collAddr = searchedRecCollAcct.getAddressMap().values();
							for(AddressType addrType: collAddr){
								accInfo.setACCOUNTADDRESS1(addrType.getADDRLN1());
								accInfo.setACCOUNTADDRESS2(addrType.getADDRLN2());
								accInfo.setACCOUNTCITY(addrType.getCITY());
								accInfo.setACCOUNTCOUNTRY(addrType.getCOUNTRYCD());
								accInfo.setACCOUNTPOSTALCODE(addrType.getPOSTALCD());
								accInfo.setACCOUNTSTATE(addrType.getSTATECD());
							}
							searchedRecCollObj.getAccountMap().put(acctRowidObject, accInfo);
							
							searchedRecCollObj.getPartyOrgMap().putAll(searchedRecCollAcct.getPartyOrgMap());
							
						}
							
						
						if (record.getField("PERSON_ROWID_OBJECT").getStringValue() != null &&
								!searchedRecCollObj.getPartyPersnMap().containsKey(record.getField("PERSON_ROWID_OBJECT").getStringValue())) {
							LOG.debug("============setting PartyPerson");
						
							partyPerson = new PartyPersonType();
							partyPerson.setROWIDOBJECT(record.getField("PERSON_ROWID_OBJECT").getStringValue());
							partyPerson.setJOBLEVEL(record.getField("JOB_LEVEL").getStringValue());
							partyPerson.setLATTICESCORE(record.getField("LATTICE_SCORE").getStringValue());
							partyPerson.setREPORTEDCOMPANYNAME(record.getField("REPTD_COMP_NAME").getStringValue());
							partyPerson.setLISTSOURCE(record.getField("LIST_SOURCE").getStringValue());
							partyPerson.setDATASOURCESYSTEM(record.getField("DATA_SRC_SYS").getStringValue());
							partyPerson.setPREFLANGUAGE(record.getField("PREF_LANGUAGE").getStringValue());
							partyPerson.setPREFIX(record.getField("PREFIX").getStringValue());
							partyPerson.setFIRSTNAME(record.getField("FIRST_NAME").getStringValue());
							partyPerson.setMIDDLENAME(record.getField("MIDDLE_NAME").getStringValue());
							partyPerson.setLASTNAME(record.getField("LAST_NAME").getStringValue());
							partyPerson.setPERSONSTATUS(record.getField("PERSON_STATUS").getStringValue());
							partyPerson.setSUFFIX(record.getField("SUFFIX").getStringValue());
							partyPerson.setJOBFUNCTION(record.getField("JOB_FUNCTION").getStringValue());
							partyPerson.setJOBTITLE(record.getField("JOB_TITLE").getStringValue());
							partyPerson.setPERSONTYPE(record.getField("PERSON_TYPE").getStringValue());

							LOG.debug("===Inserting into PartyPerson Map===");
							searchedRecCollObj.getPartyPersnMap().put(partyPerson.getROWIDOBJECT(), partyPerson);
						}

						if (record.getField("ROWID_ADDRESS").getStringValue() != null &&
								!searchedRecCollObj.getAddressMap().containsKey(record.getField("ROWID_ADDRESS").getStringValue())) {

						LOG.debug("============setting AddressType");
						address = new AddressType();
						address.setROWIDADDRESS(record.getField("ROWID_ADDRESS").getStringValue());
						address.setADDRLN1(record.getField("ADDR_LN1").getStringValue());
						address.setADDRLN2(record.getField("ADDR_LN2").getStringValue());
						address.setADDRLN3(record.getField("ADDR_LN3").getStringValue());
						address.setADDRLN4(record.getField("ADDR_LN4").getStringValue());
						address.setCITY(record.getField("CITY").getStringValue());
						address.setCOUNTY(record.getField("COUNTY").getStringValue());
						address.setDISTRICT(record.getField("DISTRICT").getStringValue());
						address.setSTATECD(record.getField("STATE_CD").getStringValue());
						address.setPOSTALCD(record.getField("POSTAL_CD").getStringValue());
						address.setCOUNTRYCD(record.getField("COUNTRY_CD").getStringValue());
						address.setLANGCD(record.getField("LANG_CD").getStringValue());
						address.setLONGITUDE(record.getField("LONGITUDE").getStringValue());
						address.setLATITUDE(record.getField("LATITUDE").getStringValue());
						address.setADDRTYPE(record.getField("ADDR_TYPE").getStringValue());
						address.setADDRSTATUS(record.getField("ADDR_STATUS").getStringValue());

						LOG.debug("===Inserting into Address Map===");
						searchedRecCollObj.getAddressMap().put(record.getField("ROWID_ADDRESS").getStringValue(), address);

				}

						if (record.getField("ROWID_COMMUNICATION").getStringValue() != null &&
								!searchedRecCollObj.getCommMap().containsKey(record.getField("ROWID_COMMUNICATION").getStringValue())) {


						communication = new CommunicationType();
						LOG.debug("============adding CommunicationType ");

						communication.setROWIDCOMMUNICATION(record.getField("ROWID_COMMUNICATION").getStringValue());
						communication.setCOMMTYPE(record.getField("COMM_TYPE").getStringValue());
						communication.setCOMMVALUE(record.getField("COMM_VALUE").getStringValue());
						communication.setCOMMSTATUS(record.getField("COMM_STATUS").getStringValue());
						communication.setPRFRDCOMMIND(record.getField("PRFRD_COMM_IND").getStringValue());
						communication.setWEBDOMAIN(record.getField("WEB_DOMAIN").getStringValue());


						LOG.debug("===Inserting into Communication Map===");
						searchedRecCollObj.getCommMap().put(record.getField("ROWID_COMMUNICATION").getStringValue(), communication);

				}

					bUniqueRec = false;
				}
			}

			if(searchedRecCollMap.size() == 0) {
				searchPartyMasterResponse.setStatus("No Record Found with MatchScore more than Match_score_thresold value.");
				return searchPartyMasterResponse;
			}
			
			Map<String, List<PartyXrefType>> partyXrefListMap = getContactXrefRec(searchedRecCollMap.keySet());
			
	/*		Map<String, List<PartyXrefType>> partyXrefListMap = searchXrefDao.processXrefSearchRequest(searchedRecCollMap.keySet());
			for(Entry<String, List<PartyXrefType>> entry : partyXrefListMap.entrySet())	{
				LOG.debug("partyXrefListMap partyRowId: " + entry.getKey() + "| partyXrefListMap Xrefs:" + entry.getValue().size());
				for(PartyXrefType pXref : entry.getValue())	{
					LOG.debug("pXref Orig_RowidObject: " + pXref.getORIGROWIDOBJECT());
				}
			}
	 */
			for (Entry<String, SearchedRecordCollection> mapEntry : searchedRecCollMap.entrySet()) {

			//		LOG.debug("====Populating XREFCopyList.");
			//		xrefCopyList = searchXrefDao.processXrefSearchRequest(mapEntry.getKey(), recCntThres);
				if(partyXrefListMap.containsKey(mapEntry.getKey()))	{

					LOG.debug("====Populating PartyType");

					partyResponse = new PartyType();
					partyResponse.setROWIDOBJECT(mapEntry.getValue().getParty_rowid());
					partyResponse.setBOCLASSCODE(mapEntry.getValue().getBo_class());
					partyResponse.setPARTYTYPE(mapEntry.getValue().getParty_type());
					partyResponse.setPARTYNAME(mapEntry.getValue().getParty_name());
					partyResponse.setGEO(mapEntry.getValue().getGeo());
					partyResponse.setREGION(mapEntry.getValue().getRegion());
					partyResponse.setSALESBLOCKCD(mapEntry.getValue().getSales_cd());
					partyResponse.setSTATUSCD(mapEntry.getValue().getStatus_cd());
					partyResponse.setTAXJURSDCTNCD(mapEntry.getValue().getTax_jd_cd());
					partyResponse.setUCN(mapEntry.getValue().getUcn());
					partyResponse.setVATREGNBR(mapEntry.getValue().getVat_regno());

					//Change for English Name :: Adding English name field to response
					partyResponse.setENGLISHNAME(mapEntry.getValue().getEnglish_name());

					LOG.debug("==Populating party's XREFType==");
					xref = new XREFType();
					String partyID = mapEntry.getValue().getParty_rowid();
					getPartyXref(partyID, xref);
					partyResponse.getXREF().add(xref);

					partyResponse.getAccount().addAll(mapEntry.getValue().getAccountMap().values());
					partyResponse.getAddress().addAll(mapEntry.getValue().getAddressMap().values());
					partyResponse.getCommunication().addAll(mapEntry.getValue().getCommMap().values());
					partyResponse.getPartyOrgExt().addAll(mapEntry.getValue().getPartyOrgMap().values());
					partyResponse.getPartyPerson().addAll(mapEntry.getValue().getPartyPersnMap().values());
					

					LOG.debug("====Populating GoldenCopy");
					goldenCpy = new GoldenCopy();
					goldenCpy.setParty(partyResponse);
					goldenCpy.setMatchScore(mapEntry.getValue().getMtchScoreValue());


					LOG.debug("====Populating PartyProfile");
					partyProfile = new PartyProfileType();
					partyProfile.setGoldenCopy(goldenCpy);
					
					xrefCopy = new XREFCopy();
					LOG.debug("Adding XREF Copies in master response ");
					xrefCopy.getPartyXref().addAll(partyXrefListMap.get(partyResponse.getROWIDOBJECT()));
					partyProfile.getXREFCopy().add(xrefCopy);

					partyProfileList.add(partyProfile);
				} else {
					LOG.debug("Excluding DnB Singleton Rowid: " + mapEntry.getKey());
				}
		

			}
			
			LOG.debug("Sorting Matched Results in descending order of MatchScore.");
			Collections.sort(partyProfileList, new Comparator<PartyProfileType>()	{
		        public int compare(PartyProfileType p1, PartyProfileType p2)	{
		              // Write your logic here.
		        	int diffMatchScore = 0;
		        	if(p1.getGoldenCopy().getMatchScore() != null && p2.getGoldenCopy().getMatchScore() != null)	{
		        		diffMatchScore = p2.getGoldenCopy().getMatchScore().compareTo(p1.getGoldenCopy().getMatchScore());
		        	}

		        	return diffMatchScore;
		        }}
			);

/*
			//Populating NULL tags in Response Canonical Format
			if (partyProfileList.size() != 0) {
				for(int indx = 0 ; indx < partyProfileList.size(); indx++)	{
					CanonicalFormManipulator.setDefaultValueInGoldenAttributes(partyProfileList.get(indx).getGoldenCopy().getParty());
				}
			}
*/
			LOG.debug("finnaly adding in master response ");
			if (partyProfileList.size() != 0) {
				LOG.debug("No of Contacts Found: "+ partyProfileList.size());
				searchPartyMasterResponse.getPartyProfile().addAll(partyProfileList);
				searchPartyMasterResponse.setStatus(partyProfileList.size() + " Contacts successfully found!");
			}
	//		LOG.debug("Printing service response:-");
	//		Util.printObjectTreeInXML(SearchPartyResponse.class, searchPartyMasterResponse);

		}
		} catch (Exception exp) {
			LOG.error(" Caught Exception in searchMatchResponse ",exp);
			searchPartyMasterResponse.setErrorMsg(searchPartyMasterResponse.getErrorMsg() == null ? "":"\n");
			searchPartyMasterResponse.setErrorMsg(searchPartyMasterResponse.getErrorMsg() + " " + Constant.unExpectedError + exp);
			ServiceProcessingException customException = new ServiceProcessingException(exp);
			customException.setMessage("Failed to process search request." + customException.getMessage());
			throw customException;
		}
		
		LOG.info("Completed createGoldenCopyFuzzySearch()");
		return searchPartyMasterResponse;

	}

	//Fetch GoldenCopy Records from PKG_PARTY_JMS_MQ_PUB for FUZZY SEARCH
	public SearchPartyResponse  getAllPartyGolden(Set<String> rowidObjectSet) throws ServiceProcessingException {
		LOG.info("Executing getAllPartyGolden()");

		SearchPartyResponse searchPartyMasterResp = null;
		Statement statement = null;
		StringBuilder sqlQry = new StringBuilder();
		JDBCConnectionProvider jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();;
		Connection jdbcConnection = null;
		ResultSet resultSet = null;


		try {
			LOG.info("Fetching XREF copies for rowidObjectSet: " + rowidObjectSet);

			sqlQry.append("SELECT * FROM PKG_PARTY_JMS_MQ_PUB WHERE ROWID_OBJECT in (");

			for (String partyRowId : rowidObjectSet) {
				sqlQry.append("'" + partyRowId + "',");
			}
			sqlQry.deleteCharAt(sqlQry.length() - 1).toString();
			sqlQry.append(") AND HUB_STATE_IND <> '" + -1 + "'");
			sqlQry.append(" AND STATUS_CD = '" + "A" + "'");
			sqlQry.append(" AND BO_CLASS_CODE = '" + "Person" + "'");
	//		sqlQry.append(" AND PARTY_TYPE in ('" + "Person'" + "'Partner'," + "'Reseller'," + "'Distributor" + "')");
			/** Modified for SFDC START */
	//		sqlQry.append(" AND NVL(DRAFT_FLG,'N')<>'" + "Y" + "'");
			/** Modified for SFDC END */

			LOG.debug("Query to fetch partyGoldenMap: " + sqlQry);

			jdbcConnection = jDBCConnectionProvider.getJdbcConnectionFromDS();
		//	jdbcConnection = JdbcConn.GetJdbcConnObject();
			statement = jdbcConnection.createStatement();
			resultSet = statement.executeQuery(sqlQry.toString());
	//		searchPartyMasterResp = createGoldenCopyFuzzySearch(resultSet);

		} catch (SQLException sqlEx) {
			LOG.error("Exception occurred in getAllPartyGolden while fetching Party profile: " + sqlEx);
			sqlEx.printStackTrace();
			ServiceProcessingException customException = new ServiceProcessingException(sqlEx);
			customException.setMessage("Failed to fetch Party profile from ORS." + customException.getMessage());
			throw customException;
		} finally {
				try {
					if( resultSet != null) resultSet.close();
					if( statement != null) statement.close();
					if(jdbcConnection != null) jdbcConnection.close();
				} catch (SQLException e) {
					LOG.error("Sql Exception occurred in getAllPartyGolden : " + e);
					//e.printStackTrace();
				}
		}

		LOG.info("Executed getAllPartyGolden()");

		return searchPartyMasterResp;
	}
	
	//JDBC call to fetch CONTACT XREF Record
	public Map<String, List<PartyXrefType>> getContactXrefRec(Set<String> contactRowidSet)	{

		Map<String, List<PartyXrefType>> xrefRecMap = null;
		Statement statement = null;
		StringBuilder sqlQry = new StringBuilder();
		Connection jdbcConnection = null;
		ResultSet resultSet = null;

		try {

			JDBCConnectionProvider jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();

			LOG.info("Fetching XREF copy for contactRowidSet: " + contactRowidSet);

			sqlQry.append("SELECT * FROM PKG_XREF_PERSON_SEARCH WHERE PARTY_ROWID_OBJECT in (");
			for (String contctRowId : contactRowidSet) {
				sqlQry.append("'" + contctRowId.trim() + "',");
			}
			sqlQry.deleteCharAt(sqlQry.length() - 1).toString();

			sqlQry.append(") AND PARTY_ROWID_SYSTEM in ('SBL','SFC','ADB')");

			//sqlQry.append(") AND PARTY_ROWID_SYSTEM in ('SBL','SFC','ELQ','ADB')"); --MDMP-3311
			sqlQry.append(" AND HUB_STATE_IND <> '" + -1 + "'");
			sqlQry.append(" AND STATUS_CD = '" + "A" + "'");
			//sqlQry.append(" AND STATUS_CD in ('" + "A' ,"+ "'I"+ "')"); --Changed for MDMP-3322
			sqlQry.append(" AND BO_CLASS_CODE = '" + "Person" + "'");
	//		sqlQry.append(" AND PARTY_TYPE in ('" + "Customer'," + "'Partner'," + "'Reseller'," + "'Distributor" + "')");

			LOG.debug("Query to fetch getContactXrefRec: " + sqlQry);


			jdbcConnection = jDBCConnectionProvider.getJdbcConnectionFromDS();
		//	jdbcConnection = JdbcConn.GetJdbcConnObject();
			statement = jdbcConnection.createStatement();
			resultSet = statement.executeQuery(sqlQry.toString());
			xrefRecMap = createXrefCanonicalFormContact(resultSet);


		} catch (SQLException sqlEx) {
			LOG.error("Exception in getContactXrefRec() for Contact Search: " , sqlEx);
			ServiceProcessingException customException = new ServiceProcessingException(sqlEx);
			customException.setMessage("Failed to fetch Party profile from ORS." + customException.getMessage());
		//	throw customException;
		} catch (ServiceProcessingException sqlEx) {
			LOG.error("Exception in getContactXrefRec() for Contact Search: " , sqlEx);
			ServiceProcessingException customException = new ServiceProcessingException(sqlEx);
			customException.setMessage("Failed to fetch Party profile from ORS." + customException.getMessage());
		//	throw customException;
		}	finally {
			try {
					if( resultSet != null) resultSet.close();
					if( statement != null) statement.close();
					if(jdbcConnection != null) jdbcConnection.close();
				} catch (SQLException e) {

					LOG.debug("Caught SQLException in getContactXrefRec: " , e);
				}
		}
		return xrefRecMap;

	}
	
	public Map<String, List<PartyXrefType>> getAdobeContactXrefRec(String survivingPartyRowid)	{

		Map<String, List<PartyXrefType>> xrefRecMap = null;
		Statement statement = null;
		StringBuilder sqlQry = new StringBuilder();
		Connection jdbcConnection = null;
		ResultSet resultSet = null;

		try {

			JDBCConnectionProvider jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();

			LOG.info("Fetching XREF copy for contactRowidSet: " + survivingPartyRowid);

			sqlQry.append("SELECT * FROM PKG_XREF_PERSON_SEARCH WHERE PARTY_ROWID_OBJECT='"+survivingPartyRowid+"' ");
			sqlQry.append(" AND PARTY_ROWID_SYSTEM ='ADB' ");
			sqlQry.append(" AND HUB_STATE_IND <> '" + -1 + "'");
			sqlQry.append(" AND STATUS_CD in ('" + "A' ,"+ "'I"+ "')");
			sqlQry.append(" AND BO_CLASS_CODE = '" + "Person" + "'");
			LOG.debug("Query to fetch getAdobeContactXrefRec: " + sqlQry);

			jdbcConnection = jDBCConnectionProvider.getJdbcConnectionFromDS();
			statement = jdbcConnection.createStatement();
			resultSet = statement.executeQuery(sqlQry.toString());
			xrefRecMap = createXrefCanonicalFormContact(resultSet);


		} catch (SQLException sqlEx) {
			LOG.error("Exception in getContactXrefRec() for Contact Search: " , sqlEx);
			ServiceProcessingException customException = new ServiceProcessingException(sqlEx);
			customException.setMessage("Failed to fetch Party profile from ORS." + customException.getMessage());
		//	throw customException;
		} catch (ServiceProcessingException sqlEx) {
			LOG.error("Exception in getContactXrefRec() for Contact Search: " , sqlEx);
			ServiceProcessingException customException = new ServiceProcessingException(sqlEx);
			customException.setMessage("Failed to fetch Party profile from ORS." + customException.getMessage());
		//	throw customException;
		}	finally {
			try {
					if( resultSet != null) resultSet.close();
					if( statement != null) statement.close();
					if(jdbcConnection != null) jdbcConnection.close();
				} catch (SQLException e) {

					LOG.debug("Caught SQLException in getAdobeContactXrefRec: " , e);
				}
		}
		return xrefRecMap;

	}

	//ID based Search service
	public SearchPartyResponse processExactSearchRequest(SearchPartyRequest parameters) throws ServiceProcessingException {

		LOG.info("Executing processExactSearchRequest() for ID based Search");

		SearchPartyResponse searchPartyMasterResponse = new SearchPartyResponse();
		PartyProfileType partyProfile = null;
		List<PartyProfileType> partyProfileList = new ArrayList<PartyProfileType>();
		GoldenCopy goldenCpy = null;
		XREFCopy xrefCopy = null;
		PartyType partyResponse = null;
		XREFType xref = null;

		Map<String, PartyType> goldenRecMap = null;
		Map<String, List<PartyXrefType>> partyXrefMap = null;
		String contctSrcSysID = parameters.getPartySearchCriteria().getCONTACTSOURCEID();
		String contctSrcSystem = parameters.getPartySearchCriteria().getCONTACTSOURCESYSTEM();
		String mdmUCN = parameters.getPartySearchCriteria().getMDMCONTACTID();
		
		String contctSurvivorRowid = null ;
		Set<String> contctRowidSet = new TreeSet<String>() ;

		if(!Util.isNullOrEmpty(contctSrcSysID) && !Util.isNullOrEmpty(contctSrcSystem)){
			/*Contact Search using Contact_ID & Contact_Src_System*/
			goldenRecMap = getGoldenRecforID(contctSrcSysID, contctSrcSystem, mdmUCN);
		}else if(!Util.isNullOrEmpty(mdmUCN)){
			/*Contact Search using MDM_UCN*/
			goldenRecMap = getGoldenRecforID(contctSrcSysID, contctSrcSystem, mdmUCN);
		}

		if(goldenRecMap == null) {

			searchPartyMasterResponse.setStatus("The Contact_ID: " + contctSrcSysID +" does not exist in MDM.");
			return searchPartyMasterResponse;
		}

		contctSurvivorRowid = rowid_object;
		contctRowidSet.add(contctSurvivorRowid);
		/*Contact Xref Record*/
		partyXrefMap = getContactXrefRec(contctRowidSet);

		for (Entry<String, PartyType> mapEntry : goldenRecMap.entrySet()) {

			//		LOG.debug("====Populating XREFCopyList.");
			//		xrefCopyList = searchXrefDao.processXrefSearchRequest(mapEntry.getKey(), recCntThres);


					LOG.debug("====Populating PartyType");
					partyResponse = mapEntry.getValue();

					LOG.debug("==Populating party's XREFType==");
					xref = new XREFType();
					String partyID = partyResponse.getROWIDOBJECT();
					getPartyXref(partyID, xref);
					partyResponse.getXREF().add(xref);

					LOG.debug("====Populating GoldenCopy");
					goldenCpy = new GoldenCopy();
					goldenCpy.setParty(partyResponse);
					goldenCpy.setMatchScore(100);


					LOG.debug("====Populating PartyProfile");
					partyProfile = new PartyProfileType();
					partyProfile.setGoldenCopy(goldenCpy);

					xrefCopy = new XREFCopy();
					LOG.debug("Adding XREF Copies in master response ");
					xrefCopy.getPartyXref().addAll(partyXrefMap.get(partyResponse.getROWIDOBJECT()));
				//	xrefCopyList.add(xrefCopy);
					partyProfile.getXREFCopy().add(xrefCopy);

					partyProfileList.add(partyProfile);

			}
/*
		//Populating NULL tags in Response Canonical Format
		if (partyProfileList.size() != 0) {
		//	for(int indx = 0 ; indx < partyProfileList.size(); indx++)	{
			for(PartyProfileType ppT: partyProfileList){
			//	CanonicalFormManipulator.setDefaultValueInGoldenAttributes(partyProfileList.get(indx).getGoldenCopy().getParty());
				CanonicalFormManipulator.setDefaultValueInGoldenAttributes(ppT.getGoldenCopy().getParty());
			//	CanonicalFormManipulator.setDefaultValueInXrefAttributes(partyProfileList.get(indx).getXREFCopy().get(indx).getPartyXref().get(indx));
				for(XREFCopy xrefcpy: ppT.getXREFCopy()){
					for(PartyXrefType partyXref: xrefcpy.getPartyXref()){
						CanonicalFormManipulator.setDefaultValueInXrefAttributes(partyXref);
					}
				}
			}
		}
*/
		LOG.debug("finnaly adding in master response ");
		if (partyProfileList.size() != 0) {

			searchPartyMasterResponse.getPartyProfile().addAll(partyProfileList);
			searchPartyMasterResponse.setStatus(partyProfileList.size() + " Contacts successfully found!");
		}
		
//		LOG.debug("Printing service response:-");
//		Util.printObjectTreeInXML(SearchPartyResponse.class, searchPartyMasterResponse);

		LOG.info("Executed processExactSearchRequest() for ID based Search");

		return searchPartyMasterResponse;
	}
	
	//Method To Fetch Party XREFType
	public void getPartyXref(String partyID, XREFType xref) throws ServiceProcessingException	{
		Connection jdbcConn = null;
		PreparedStatement pstatement = null;
		ResultSet resultSet = null;
		JDBCConnectionProvider jDBCConnectionProvider =  JDBCConnectionProvider.getSingleInstance();
		jdbcConn = jDBCConnectionProvider.getJdbcConnectionFromDS();
		String sql = "select ROWID_SYSTEM,PKEY_SRC_OBJECT from C_B_PARTY_XREF where ROWID_OBJECT = ? and ROWID_SYSTEM in ('ELQ')";

		LOG.debug("Query for getPartyXref: "+sql);
		try {
				pstatement = jdbcConn.prepareStatement(sql);
				pstatement.setString(1, partyID);
				resultSet = pstatement.executeQuery();

				while (resultSet.next()) {
					String srcSys = resultSet.getString(1);
					String srcPkey = resultSet.getString(2);

					if (srcSys != null) {
						xref.setSRCSYSTEM(srcSys);
					}
					if (srcPkey != null) {
						xref.setSRCPKEY(srcPkey);
					}
				}
		 } catch(SQLException sqlex) {
			 LOG.error("Caught sql exception in getPartyXref()." + sqlex);
		 } finally {
				try {	//Closing connections
						if (resultSet != null) resultSet.close();
						if (pstatement != null) pstatement.close();
						if (jdbcConn != null) jdbcConn.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
		 }
	}

	//Fetch Account Pkeys for Account-Rowids
	public List<String> getAccntPkeys(List<String> partyIDList) throws ServiceProcessingException	{
		LOG.debug("Inside getAccntPkeys");
		Connection jdbcConn = null;
		Statement statement = null;
		ResultSet resultSet = null;
		List<String> pkeyList = new ArrayList<String>();
		
		StringBuilder sql = new StringBuilder();
		sql.append("select PKEY_SRC_OBJECT from C_B_PARTY_XREF where ROWID_OBJECT in (");
		
		for (String partyRowId : partyIDList) {
			sql.append("'" + partyRowId.trim() + "',");
		}
		sql.deleteCharAt(sql.length() - 1).toString();
		sql.append(") and ROWID_SYSTEM in ('ELQ','SBL')");
		
		LOG.debug("Query for getPartyXref: "+sql.toString());
		
		try {
				JDBCConnectionProvider jDBCConnectionProvider =  JDBCConnectionProvider.getSingleInstance();
				jdbcConn = jDBCConnectionProvider.getJdbcConnectionFromDS();
				statement = jdbcConn.createStatement();
				resultSet = statement.executeQuery(sql.toString());
	
				while (resultSet.next()) {
					pkeyList.add(resultSet.getString(1));
				}
		 } catch(SQLException sqlex) {
			 LOG.error("Caught sql exception in getAccntPkeys()." + sqlex);
		 } finally {
			try {	//Closing connections
					if (resultSet != null) resultSet.close();
					if (statement != null) statement.close();
					if (jdbcConn != null) jdbcConn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		 }
		LOG.debug("Executed getAccntPkeys");
		return pkeyList;	
	}

	//Method To Fetch Party XREFType
	public String getCL_SIP_POP(String countryCd)	{

		LOG.debug("Inside getCL_SIP_POP");
		Connection jdbcConn = null;
		Statement statement = null;
		ResultSet resultSet = null;
		String countryName = null;

		String sql = "SELECT COUNTRY_NAME from CL_SIP_POP where upper(COUNTRY_CD) = upper('" + countryCd + "')";

		try {
			JDBCConnectionProvider jDBCConnectionProvider =  JDBCConnectionProvider.getSingleInstance();
			jdbcConn = jDBCConnectionProvider.getJdbcConnectionFromDS();
			statement = jdbcConn.createStatement();
			resultSet = statement.executeQuery(sql);

				while (resultSet.next()) {
					 countryName = resultSet.getString(1);
				}
				LOG.debug("SIP_POP value: " + countryName);

		 } catch(SQLException sqlex) {
			 LOG.error("Caught SQLException in getCL_SIP_POP()" , sqlex);
		 } catch(ServiceProcessingException servExp) {
			 LOG.error("Caught ServiceProcessingException in getCL_SIP_POP()" , servExp);
		 }
		finally {
			try {
					//Closing connections
					if (resultSet != null) 	resultSet.close();
					if (statement != null) statement.close();
					if (jdbcConn != null) jdbcConn.close();
				} catch (SQLException e) {
					LOG.error("Caught sql exception in getCL_SIP_POP()." + e);
				}

		 }
		LOG.debug("Executed getCL_SIP_POP.");
		return countryName;
	}

	//JDBC call to fetch Golden Record for ID based search
	public Map<String, PartyType> getGoldenRecforID(String srcSysID, String srcSysName, String mdmUCN)	{

		Map<String, PartyType> goldenRecMap = null;
		Statement statement = null;
		StringBuilder sqlQry = new StringBuilder();
	//	String rowid_object = null;
		Connection jdbcConnection = null;
		ResultSet resultSet = null;
		Set<String> rowidSet= new TreeSet<String>();
		
		try {

			JDBCConnectionProvider jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();

			if(!Util.isNullOrEmpty(srcSysID)){
				rowid_object = getPartyRowidObject(srcSysID, srcSysName, mdmUCN);
			}else if(!Util.isNullOrEmpty(mdmUCN)){
				rowid_object = getPartyRowidObject(srcSysID, srcSysName, mdmUCN);
			}
			
			if ( !Util.isNullOrEmpty(rowid_object))	{
				rowidSet.add(rowid_object);
				cntctAcctMap = getAccountRowidByContactID(rowidSet);
			}
			
			if ( !Util.isNullOrEmpty(rowid_object))	{

				LOG.info("Fetching Golden copy for Contact_RowID: " + rowid_object);

				sqlQry.append("SELECT * FROM PKG_BO_PERSON_SEARCH WHERE ROWID_OBJECT in ('" + rowid_object + "')");

				sqlQry.append(" AND HUB_STATE_IND <> '" + -1 + "'");
				sqlQry.append(" AND STATUS_CD = '" + "A" + "'");
				sqlQry.append(" AND BO_CLASS_CODE = '" + "Person" + "'");
		//		sqlQry.append(" AND PARTY_TYPE in ('" + "Customer'," + "'Partner'," + "'Reseller'," + "'Distributor" + "')");

				LOG.debug("Query to fetch getGoldenContact: " + sqlQry);
				jdbcConnection = jDBCConnectionProvider.getJdbcConnectionFromDS();
			//	jdbcConnection = JdbcConn.GetJdbcConnObject();
				statement = jdbcConnection.createStatement();
				resultSet = statement.executeQuery(sqlQry.toString());
				goldenRecMap = createGoldenCopyCanonicalFormMultipleParty(resultSet);
			}

		} catch (SQLException sqlEx) {
			LOG.error("Exception in getGoldenRecforID() for ID based Search: " , sqlEx);
			ServiceProcessingException customException = new ServiceProcessingException(sqlEx);
			customException.setMessage("Failed to fetch Party profile from ORS." + customException.getMessage());
		//	throw customException;
		} catch (ServiceProcessingException sqlEx) {
			LOG.error("Exception in getGoldenRecforID() for ID based Search: " , sqlEx);
			ServiceProcessingException customException = new ServiceProcessingException(sqlEx);
			customException.setMessage("Failed to fetch Party profile from ORS." + customException.getMessage());
		//	throw customException;
		}	finally {
			try {
					if( resultSet != null)	resultSet.close();
					if( statement != null) statement.close();
					if(jdbcConnection != null) jdbcConnection.close();
				} catch (SQLException e) {

					LOG.debug("Caught SQLException in getGoldenRecforID: " , e);
				}
		}
		return goldenRecMap;

	}

	//Method To Fetch Party_ROWID_OBJECT from SrcSystemID
	public String getPartyRowidObject(String partyPkeyID, String srcSystemName, String mdmUCN) throws ServiceProcessingException	{

		LOG.debug("Executing getPartyRowidObject() ");
		Connection jdbcConn = null;
		PreparedStatement pstatement = null;
		ResultSet resultSet = null;
		StringBuilder sql = new StringBuilder ();
		String rowidObject = null;
//		String srcSystemName = null;
		
		try {
		JDBCConnectionProvider jDBCConnectionProvider =  JDBCConnectionProvider.getSingleInstance();
		jdbcConn = jDBCConnectionProvider.getJdbcConnectionFromDS();

		if(!Util.isNullOrEmpty(partyPkeyID)){
			sql.append("select ROWID_OBJECT from C_B_PARTY_XREF where PKEY_SRC_OBJECT = ?");

			if ( !Util.isNullOrEmpty(srcSystemName) ) {
				sql.append(" and ROWID_SYSTEM in ('" + srcSystemName + "')");
	
			} 

			LOG.debug("Query for getPartyRowidObject: " + sql.toString());
			pstatement = jdbcConn.prepareStatement(sql.toString());
			pstatement.setString(1, partyPkeyID);
		}else if(!Util.isNullOrEmpty(mdmUCN)){
			sql.append("select ROWID_OBJECT from C_B_PARTY where UCN = ?");

			LOG.debug("Query for getPartyRowidObject: " + sql.toString());
			pstatement = jdbcConn.prepareStatement(sql.toString());
			pstatement.setString(1, mdmUCN);
		}
			resultSet = pstatement.executeQuery();

			while (resultSet.next()) {
				rowidObject = resultSet.getString(1);
			}
		 } catch(SQLException sqlex) {
			 LOG.error("Caught sql exception in getPartyRowidObject(): " , sqlex);
		 } finally {
			 try {
				 //Closing connections
				 if (resultSet != null)	resultSet.close();
				 if (pstatement != null) pstatement.close();
				 if (jdbcConn != null) jdbcConn.close();
				} catch (SQLException e) {
					 LOG.error("Caught sql exception in getPartyRowidObject(): " , e);
				}
		 }

		LOG.debug("Executed getPartyRowidObject() ");
		return rowidObject;
	}

	//JDBC call to fetch XREF Record for ID based search
	public Map<String, List<PartyXrefType>> getXrefRecforID(String survivorRowid)	{

		Map<String, List<PartyXrefType>> xrefRecMap = null;
		Statement statement = null;
		StringBuilder sqlQry = new StringBuilder();
		Connection jdbcConnection = null;
		ResultSet resultSet = null;

		try {

			JDBCConnectionProvider jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();

			LOG.info("Fetching XREF copy for PkeySrcID: " + survivorRowid);

			sqlQry.append("SELECT * FROM PKG_XREF_PERSON_SEARCH WHERE PARTY_ROWID_OBJECT in ('" + survivorRowid + "') AND PARTY_ROWID_SYSTEM in ('SAP','SBL')");


			sqlQry.append(" AND HUB_STATE_IND <> '" + -1 + "'");
			sqlQry.append(" AND STATUS_CD = '" + "A" + "'");
			sqlQry.append(" AND BO_CLASS_CODE = '" + "Organization" + "'");
			sqlQry.append(" AND PARTY_TYPE in ('" + "Customer'," + "'Partner'," + "'Reseller'," + "'Distributor" + "')");

			LOG.debug("Query to fetch getXrefRecforID: " + sqlQry);


			jdbcConnection = jDBCConnectionProvider.getJdbcConnectionFromDS();
		//	jdbcConnection = JdbcConn.GetJdbcConnObject();
			statement = jdbcConnection.createStatement();
			resultSet = statement.executeQuery(sqlQry.toString());
	//		xrefRecMap = createXrefCanonicalFormMultipleParty(resultSet);


		} catch (SQLException sqlEx) {
			LOG.error("Exception in getXrefRecforID() for ID based Search: " , sqlEx);
			ServiceProcessingException customException = new ServiceProcessingException(sqlEx);
			customException.setMessage("Failed to fetch Party profile from ORS." + customException.getMessage());
		//	throw customException;
		} catch (ServiceProcessingException sqlEx) {
			LOG.error("Exception in getXrefRecforID() for ID based Search: " , sqlEx);
			ServiceProcessingException customException = new ServiceProcessingException(sqlEx);
			customException.setMessage("Failed to fetch Party profile from ORS." + customException.getMessage());
		//	throw customException;
		}	finally {
			try {
					if( resultSet != null) resultSet.close();
					if( statement != null) statement.close();
					if(jdbcConnection != null) jdbcConnection.close();
				} catch (SQLException e) {

					LOG.debug("Caught SQLException in getXrefRecforID: " , e);
				}
		}
		return xrefRecMap;

	}


	//Fetch Golden Copy CanonicalForm for ID Based Search
	private Map<String, PartyType> createGoldenCopyCanonicalFormMultipleParty(ResultSet resultSet) {
		LOG.info("Executing createGoldenCopyCanonicalFormMultipleParty()");
		PartyType party = null;
		CommunicationType communication = null;
		AccountType accInfo = null;
		AddressType address = null;
		PartyOrgExtType partyOrgExt = null;
		PartyPersonType partyPerson = null;

		Map<String, PartyType> partyMap = new HashMap<String, PartyType>();
		Map<String, SearchedRecordCollection> searchedRecCollMap = new HashMap<String, SearchedRecordCollection>();
		SearchedRecordCollection searchedRecCollObj = null;
		boolean bUniqueRec = false;
		
		String acctRowidObject = null;
		SearchedRecordCollection searchedRecCollAcct = null;

		try {
			LOG.info("Retrieving Party profiles (Gold copy) from result set");
			while (resultSet.next()) {
				String partyRowId = resultSet.getString("ROWID_OBJECT");
				if(cntctAcctMap!=null && cntctAcctMap.size()>0)	{
					acctRowidObject = cntctAcctMap.get(partyRowId.trim());
					LOG.debug("partyRowId: "+partyRowId+" |acctRowidObject: "+acctRowidObject);
				}

				if (!searchedRecCollMap.containsKey(partyRowId)) {

					LOG.debug("Populate searchedRecCollMap for new PARTY_ROWID " + partyRowId);
					searchedRecCollMap.put(partyRowId, new SearchedRecordCollection());
					bUniqueRec = true;
				}

				searchedRecCollObj = searchedRecCollMap.get(partyRowId);

				if(bUniqueRec)	{

					LOG.debug("============setting Party Gold Copy");
					searchedRecCollObj.setParty_rowid(partyRowId);
					searchedRecCollObj.setBo_class(resultSet.getString("BO_CLASS_CODE"));
					searchedRecCollObj.setParty_type(resultSet.getString("PARTY_TYPE"));
					searchedRecCollObj.setParty_name(resultSet.getString("PARTY_NAME"));
					searchedRecCollObj.setGeo(resultSet.getString("GEO"));
					searchedRecCollObj.setRegion(resultSet.getString("REGION"));
					searchedRecCollObj.setStatus_cd(resultSet.getString("STATUS_CD"));
					searchedRecCollObj.setVat_regno(resultSet.getString("VAT_REG_NBR"));
					searchedRecCollObj.setTax_jd_cd(resultSet.getString("TAX_JURSDCTN_CD"));
					searchedRecCollObj.setSales_cd(resultSet.getString("SALES_BLOCK_CD"));
					searchedRecCollObj.setUcn(resultSet.getString("UCN"));
				//	searchedRecCollObj.setLegacyUcn(resultSet.getString("LEGACY_UCN"));
					searchedRecCollObj.setEnglish_name(resultSet.getString("ENGLISH_NAME"));
				}
				
				if(!Util.isNullOrEmpty(acctRowidObject))	{
					searchedRecCollAcct = getAccountDetails(acctRowidObject);
					LOG.debug("============setting AccountSiteBOInfo ");
					
					accInfo = new AccountType();
					accInfo.setROWIDACCOUNT(acctRowidObject);
					accInfo.setACCOUNTNAME(searchedRecCollAcct.getParty_name());
					accInfo.setACCOUNTPARTYTYPE(searchedRecCollAcct.getParty_type());
					accInfo.setMDMACCOUNTUCN(searchedRecCollAcct.getUcn());
					
					Collection<AddressType> collAddr = searchedRecCollAcct.getAddressMap().values();
					for(AddressType addrType: collAddr){
						accInfo.setACCOUNTADDRESS1(addrType.getADDRLN1());
						accInfo.setACCOUNTADDRESS2(addrType.getADDRLN2());
						accInfo.setACCOUNTCITY(addrType.getCITY());
						accInfo.setACCOUNTCOUNTRY(addrType.getCOUNTRYCD());
						accInfo.setACCOUNTPOSTALCODE(addrType.getPOSTALCD());
						accInfo.setACCOUNTSTATE(addrType.getSTATECD());
					}
					searchedRecCollObj.getAccountMap().put(acctRowidObject, accInfo);
					
					searchedRecCollObj.getPartyOrgMap().putAll(searchedRecCollAcct.getPartyOrgMap());
					
				}
					
				
				if (resultSet.getString("PERSON_ROWID_OBJECT") != null &&
						!searchedRecCollObj.getPartyPersnMap().containsKey(resultSet.getString("PERSON_ROWID_OBJECT"))) {
					LOG.debug("============setting PartyPerson");
				
					partyPerson = new PartyPersonType();
					partyPerson.setROWIDOBJECT(resultSet.getString("PERSON_ROWID_OBJECT"));
					partyPerson.setJOBLEVEL(resultSet.getString("JOB_LEVEL"));
					partyPerson.setLATTICESCORE(resultSet.getString("LATTICE_SCORE"));
					partyPerson.setREPORTEDCOMPANYNAME(resultSet.getString("REPTD_COMP_NAME"));
					partyPerson.setLISTSOURCE(resultSet.getString("LIST_SOURCE"));
					partyPerson.setDATASOURCESYSTEM(resultSet.getString("DATA_SRC_SYS"));
					partyPerson.setPREFLANGUAGE(resultSet.getString("PREF_LANGUAGE"));
					partyPerson.setPREFIX(resultSet.getString("PREFIX"));
					partyPerson.setFIRSTNAME(resultSet.getString("FIRST_NAME"));
					partyPerson.setMIDDLENAME(resultSet.getString("MIDDLE_NAME"));
					partyPerson.setLASTNAME(resultSet.getString("LAST_NAME"));
					partyPerson.setPERSONSTATUS(resultSet.getString("PERSON_STATUS"));
					partyPerson.setSUFFIX(resultSet.getString("SUFFIX"));
					partyPerson.setJOBFUNCTION(resultSet.getString("JOB_FUNCTION"));
					partyPerson.setJOBTITLE(resultSet.getString("JOB_TITLE"));
					partyPerson.setPERSONTYPE(resultSet.getString("PERSON_TYPE"));

					LOG.debug("===Inserting into PartyPerson Map===");
					searchedRecCollObj.getPartyPersnMap().put(partyPerson.getROWIDOBJECT(), partyPerson);
				}

				String rowidAddress = resultSet.getString("ROWID_ADDRESS");
				if (rowidAddress != null &&
						!searchedRecCollObj.getAddressMap().containsKey(rowidAddress)) {
					LOG.debug("============setting Address");

					address = new AddressType();
					address.setROWIDADDRESS(rowidAddress);
					address.setADDRLN1(resultSet.getString("ADDR_LN1"));
					address.setADDRLN2(resultSet.getString("ADDR_LN2"));
					address.setADDRLN3(resultSet.getString("ADDR_LN3"));
					address.setADDRLN4(resultSet.getString("ADDR_LN4"));
					address.setCITY(resultSet.getString("CITY"));
					address.setCOUNTY(resultSet.getString("COUNTY"));
					address.setDISTRICT(resultSet.getString("DISTRICT"));
					address.setSTATECD(resultSet.getString("STATE_CD"));
					address.setPOSTALCD(resultSet.getString("POSTAL_CD"));
					address.setCOUNTRYCD(resultSet.getString("COUNTRY_CD"));
					address.setLANGCD(resultSet.getString("LANG_CD"));
					address.setLONGITUDE(resultSet.getString("LONGITUDE"));
					address.setLATITUDE(resultSet.getString("LATITUDE"));
					address.setADDRTYPE(resultSet.getString("ADDR_TYPE"));
					address.setADDRSTATUS(resultSet.getString("ADDR_STATUS"));

					LOG.debug("===Inserting into Address Map===");
					searchedRecCollObj.getAddressMap().put(address.getROWIDADDRESS(), address);
				}

				String rowidComm = resultSet.getString("ROWID_COMMUNICATION");
				if (rowidComm != null &&
						!searchedRecCollObj.getCommMap().containsKey(rowidComm)) {
					communication = new CommunicationType();
					LOG.debug("============adding Communication");

					communication.setROWIDCOMMUNICATION(rowidComm);
					communication.setCOMMTYPE(resultSet.getString("COMM_TYPE"));
					communication.setCOMMVALUE(resultSet.getString("COMM_VALUE"));
					communication.setCOMMSTATUS(resultSet.getString("COMM_STATUS"));
					communication.setPRFRDCOMMIND(resultSet.getString("PRFRD_COMM_IND"));
					communication.setWEBDOMAIN(resultSet.getString("WEB_DOMAIN"));

					LOG.debug("===Inserting into Communication Map===");
					searchedRecCollObj.getCommMap().put(communication.getROWIDCOMMUNICATION(), communication);
				}

				bUniqueRec = false;
			}
			LOG.info("Number of retrived party profile = " + searchedRecCollMap.keySet().size());

			LOG.debug("====Populating Party canonical formats");
			for (Entry<String, SearchedRecordCollection> entry : searchedRecCollMap.entrySet()) {
				SearchedRecordCollection fetchedRecCollObj = entry.getValue();
				if (fetchedRecCollObj != null) {
					party = new PartyType();
					party.setBOCLASSCODE(fetchedRecCollObj.getBo_class());
					party.setENGLISHNAME(fetchedRecCollObj.getEnglish_name());
					party.setGEO(fetchedRecCollObj.getGeo());
					party.setPARTYNAME(fetchedRecCollObj.getParty_name());
					party.setPARTYTYPE(fetchedRecCollObj.getParty_type());
					party.setREGION(fetchedRecCollObj.getRegion());
					party.setROWIDOBJECT(fetchedRecCollObj.getParty_rowid());
					party.setSALESBLOCKCD(fetchedRecCollObj.getSales_cd());
					party.setSTATUSCD(fetchedRecCollObj.getStatus_cd());
					party.setTAXJURSDCTNCD(fetchedRecCollObj.getTax_jd_cd());
					party.setUCN(fetchedRecCollObj.getUcn());
			//		party.setLEGACYUCN(fetchedRecCollObj.getLegacyUcn());
					party.setVATREGNBR(fetchedRecCollObj.getVat_regno());

					party.getXREF().addAll(fetchedRecCollObj.getXrefMap().values());
					party.getAccount().addAll(fetchedRecCollObj.getAccountMap().values());
					party.getAddress().addAll(fetchedRecCollObj.getAddressMap().values());
					party.getCommunication().addAll(fetchedRecCollObj.getCommMap().values());
					party.getPartyOrgExt().addAll(fetchedRecCollObj.getPartyOrgMap().values());
					party.getPartyPerson().addAll(fetchedRecCollObj.getPartyPersnMap().values());

					partyMap.put(entry.getKey(), party);
				}
			}
			LOG.info("Number of party canonical format created = " + partyMap.keySet().size());
		} catch (SQLException sqlEx) {
			LOG.error("SQLException occurred while retrieving party details from resultset: ", sqlEx);
			//sqlEx.printStackTrace();
		} catch (Exception excp) {
			LOG.error("Exception occurred while creating party canonical format from resultset: ", excp);
			//excp.printStackTrace();
		}

		LOG.info("Executed createGoldenCopyCanonicalFormMultipleParty()");
		return partyMap;
	}

	private Map<String, List<PartyXrefType>> createXrefCanonicalFormContact(ResultSet resultSet) {
		LOG.info("Executing createXrefCanonicalFormContact()");
		PartyXrefType party = null;
		XREFType xref = null;
		CommunicationXrefType communication = null;
		AccountXrefType accInfo = null;
		AddressXrefType address = null;
		ClassificationXrefType classfction = null;
		PartyOrgExtXrefType partyOrgExt = null;
		PartyPersonXrefType person = null;
		PartyRelationshipXrefType partyRelationship = null;
//		String acctRowidObject = null;
		
		/** Modified for M4M START */
		PartyAccountRelationshipXrefType partyAccountRelationship = null;
		/** Modified for M4M END */
		
		List<String> srcSystemIdList = null;

		Map<String, List<PartyXrefType>> partyXrefMap = new HashMap<String, List<PartyXrefType>>();
		List<PartyXrefType> partyXrefList = new ArrayList<PartyXrefType>();
		Map<String, SearchedXrefRecordCollection> searchedRecCollMap = new HashMap<String, SearchedXrefRecordCollection>();
		SearchedXrefRecordCollection searchedRecCollObj = null;
		boolean bUniqueRec = false;

		Map<String, Map<String, SearchedXrefRecordCollection>> searchedRecCollMapAllParties = new HashMap<String, Map<String, SearchedXrefRecordCollection>>();

		try {
			LOG.info("Retrieving Contact profiles (Xref) from result set");
			while (resultSet.next()) {

				String partyRowId = resultSet.getString("PARTY_ROWID_OBJECT");
				String partyOrigRowId = resultSet.getString("ORIG_ROWID_OBJECT");
				String acctRowidObject = null;
				SearchedRecordCollection searchedRecCollAcct = null;
				SearchedXrefRecordCollection searchedRecCollAcctXref = null;
				
				if(cntctAcctMap!=null && cntctAcctMap.size()>0){
					acctRowidObject = cntctAcctMap.get(partyRowId.trim());
				}

				if (!searchedRecCollMapAllParties.containsKey(partyRowId)) {
					LOG.debug("Populate searchedRecCollMapAllParties for new PARTY_ROWID " + partyRowId);
					searchedRecCollMapAllParties.put(partyRowId, new HashMap<String, SearchedXrefRecordCollection>());
				}
				searchedRecCollMap = searchedRecCollMapAllParties.get(partyRowId);

				//for each Orig_rowid_object store xref values in canonical form
				if (!searchedRecCollMap.containsKey(partyOrigRowId)) {

					LOG.debug("Populate searchedXrefRecCollMap for new PARTY_ORIG_ROWID " + partyOrigRowId + " for PARTY_ROWID " + partyRowId);
					searchedRecCollMap.put(partyOrigRowId, new SearchedXrefRecordCollection());
					bUniqueRec = true;
				}

				searchedRecCollObj = searchedRecCollMap.get(partyOrigRowId);

				if(bUniqueRec)	{

					LOG.debug("============setting Party Xref Copy");
					searchedRecCollObj.setParty_rowid(partyRowId.trim());
					searchedRecCollObj.setOrig_rowid(partyOrigRowId.trim());
					searchedRecCollObj.setBo_class(resultSet.getString("BO_CLASS_CODE"));
					searchedRecCollObj.setParty_type(resultSet.getString("PARTY_TYPE"));
					searchedRecCollObj.setParty_name(resultSet.getString("PARTY_NAME"));
					searchedRecCollObj.setGeo(resultSet.getString("PARTY_GEO"));
					searchedRecCollObj.setRegion(resultSet.getString("PARTY_REGION"));
					searchedRecCollObj.setStatus_cd(resultSet.getString("STATUS_CD"));
					searchedRecCollObj.setVat_regno(resultSet.getString("PARTY_VAT_REG_NBR"));
					searchedRecCollObj.setTax_jd_cd(resultSet.getString("PARTY_TAX_JURSDCTN_CD"));
					searchedRecCollObj.setSales_cd(resultSet.getString("SALES_BLOCK_CD"));
					searchedRecCollObj.setUcn(resultSet.getString("UCN"));
					searchedRecCollObj.setEnglish_name(resultSet.getString("ENGLISH_NAME"));
				}

				if (!searchedRecCollObj.getXrefMap().containsKey(partyOrigRowId)) {
					LOG.debug("============setting XREFType");
					xref = new XREFType();
					xref.setSRCSYSTEM(resultSet.getString("PARTY_ROWID_SYSTEM").trim());
					if(Constant.SRC_SYSTEM_ADB.equals(resultSet.getString("PARTY_ROWID_SYSTEM").trim())){
						xref.setSRCPKEY(resultSet.getString("PARTY_PKEY_SRC_OBJECT").trim().replaceAll(Constant.ADB_CNT_PREFIX, Constant.STR_BLANK));
					}else{
						xref.setSRCPKEY(resultSet.getString("PARTY_PKEY_SRC_OBJECT").trim());	
					}
					
					searchedRecCollObj.getXrefMap().put(partyOrigRowId, xref);
				}

				String rowidPerson = resultSet.getString("PERSON_ROWID_OBJECT");
				if (rowidPerson != null &&
						!searchedRecCollObj.getPartyPersonXrefMap().containsKey(rowidPerson)) {
					LOG.debug("============setting Person Xref info");
					person = new PartyPersonXrefType();
					person.setROWIDOBJECT(rowidPerson.trim());
					person.setSRCSYSTEM(resultSet.getString("PERSON_ROWID_SYSTEM").trim());
					if(Constant.SRC_SYSTEM_ADB.equals(resultSet.getString("PERSON_ROWID_SYSTEM").trim())){
						person.setSRCPKEY(resultSet.getString("PERSON_PKEY_SRC_OBJECT").replaceAll(Constant.ADB_CNT_PREFIX, Constant.STR_BLANK));
					}else{
						person.setSRCPKEY(resultSet.getString("PERSON_PKEY_SRC_OBJECT"));
					}
					person.setPERSONSTATUS(resultSet.getString("PERSON_STATUS"));
					person.setPREFIX(resultSet.getString("PREFIX"));
			//		person.setPERSONTYPE(resultSet.getString("PERSON_TYPE"));
					person.setFIRSTNAME(resultSet.getString("FIRST_NAME"));
					person.setMIDDLENAME(resultSet.getString("MIDDLE_NAME"));
					person.setLASTNAME(resultSet.getString("LAST_NAME"));
					person.setSUFFIX(resultSet.getString("SUFFIX"));
					person.setJOBLEVEL(resultSet.getString("JOB_LEVEL"));
					person.setJOBTITLE(resultSet.getString("JOB_TITLE"));
					person.setJOBFUNCTION(resultSet.getString("JOB_FUNCTION"));
					person.setPREFLANGUAGE(resultSet.getString("PREF_LANGUAGE"));
					person.setLATTICESCORE(resultSet.getString("LATTICE_SCORE"));
					person.setLISTSOURCE(resultSet.getString("LIST_SOURCE"));
					person.setDATASOURCESYSTEM(resultSet.getString("DATA_SRC_SYS"));
					person.setREPORTEDCOMPANYNAME(resultSet.getString("REPTD_COMP_NAME"));
					//added for SFDC-Track4
					if(Constant.SRC_SYSTEM_ADB.equals(resultSet.getString("PERSON_ROWID_SYSTEM").trim())){
						if(!Util.isNullOrEmpty(resultSet.getString("SRC_ACCOUNT_ID"))){
							person.setSRCACCOUNTID(resultSet.getString("SRC_ACCOUNT_ID").replaceAll(Constant.ADB_ACT_PREFIX, Constant.STR_BLANK));							
						}
					}else{
						person.setSRCACCOUNTID(resultSet.getString("SRC_ACCOUNT_ID"));
					}
					person.setJOBROLE(resultSet.getString("JOB_ROLE"));
					person.setCLEANSEIND(resultSet.getString("CLEANSE_IND"));
					person.setPARTNERCONTACTFLG(resultSet.getString("PARTNER_CONTACT_FLG"));
					LOG.debug("===Inserting into Person Map===");
					searchedRecCollObj.getPartyPersonXrefMap().put(rowidPerson, person);
				}
				
				if(!Util.isNullOrEmpty(acctRowidObject))	{
					searchedRecCollAcct = getAccountDetails(acctRowidObject);
					LOG.debug("============setting AccountSiteXrefInfo");
					
					accInfo = new AccountXrefType();
					accInfo.setROWIDACCOUNT(acctRowidObject);
					accInfo.setACCOUNTNAME(searchedRecCollAcct.getParty_name());
					accInfo.setACCOUNTPARTYTYPE(searchedRecCollAcct.getParty_type());
					accInfo.setMDMACCOUNTUCN(searchedRecCollAcct.getUcn());
					
					Collection<AddressType> collAddr = searchedRecCollAcct.getAddressMap().values();
					for(AddressType addrType: collAddr){
						accInfo.setACCOUNTADDRESS1(addrType.getADDRLN1());
						accInfo.setACCOUNTADDRESS2(addrType.getADDRLN2());
						accInfo.setACCOUNTCITY(addrType.getCITY());
						accInfo.setACCOUNTCOUNTRY(addrType.getCOUNTRYCD());
						accInfo.setACCOUNTPOSTALCODE(addrType.getPOSTALCD());
						accInfo.setACCOUNTSTATE(addrType.getSTATECD());
					}
					searchedRecCollObj.getAccountMap().put(acctRowidObject, accInfo);
					
					if(searchedRecCollAcct.getPartyOrgMap() != null && searchedRecCollAcct.getPartyOrgMap().size()>0)	{
						
						for(Map.Entry<String, PartyOrgExtType> mapEntry: searchedRecCollAcct.getPartyOrgMap().entrySet()){
							partyOrgExt = new PartyOrgExtXrefType();
							partyOrgExt.setMFEGLBLPARENTNM(mapEntry.getValue().getMFEGLBLPARENTNM());
							partyOrgExt.setMFEGLBLPARENTUCN(mapEntry.getValue().getMFEGLBLPARENTUCN());
							
							searchedRecCollObj.getPartyOrgMap().put(mapEntry.getKey(), partyOrgExt);
						}
					}	
				}//AccountSiteInfo

				if (resultSet.getString("ADDRESS_ROWID_OBJECT") != null &&
						!searchedRecCollObj.getAddressMap().containsKey(resultSet.getString("ADDRESS_ROWID_OBJECT"))) {
					LOG.debug("============setting Address");

					address = new AddressXrefType();
					address.setROWIDADDRESS(resultSet.getString("ADDRESS_ROWID_OBJECT").trim());
					address.setSRCSYSTEM(resultSet.getString("ADDRESS_ROWID_SYSTEM").trim());
					if(Constant.SRC_SYSTEM_ADB.equals(resultSet.getString("ADDRESS_ROWID_SYSTEM").trim())){
						address.setSRCPKEY(resultSet.getString("ADDRESS_PKEY_SRC_OBJECT").replaceAll(Constant.ADB_CNT_PREFIX, Constant.STR_BLANK));	
					}else{
						address.setSRCPKEY(resultSet.getString("ADDRESS_PKEY_SRC_OBJECT"));
					}
					address.setADDRLN1(resultSet.getString("ADDR_LN1"));
					address.setADDRLN2(resultSet.getString("ADDR_LN2"));
					address.setADDRLN3(resultSet.getString("ADDR_LN3"));
					address.setADDRLN4(resultSet.getString("ADDR_LN4"));
					address.setCITY(resultSet.getString("CITY"));
					address.setCOUNTY(resultSet.getString("COUNTY"));
					address.setDISTRICT(resultSet.getString("DISTRICT"));
					address.setSTATECD(resultSet.getString("STATE_CD"));
					address.setPOSTALCD(resultSet.getString("POSTAL_CD"));
					address.setCOUNTRYCD(resultSet.getString("COUNTRY_CD"));
					address.setLANGCD(resultSet.getString("LANG_CD"));
					address.setLONGITUDE(resultSet.getString("LONGITUDE"));
					address.setLATITUDE(resultSet.getString("LATITUDE"));
					address.setADDRTYPE(resultSet.getString("ADDR_TYPE"));
					address.setADDRSTATUS(resultSet.getString("ADDR_STATUS"));
					address.setADDRMKTGPREF(resultSet.getString("ADDR_MKTG_PREF"));

					LOG.debug("===Inserting into Address Map===");
					searchedRecCollObj.getAddressMap().put(address.getROWIDADDRESS(), address);
				}

				if (resultSet.getString("COMMUNICATION_ROWID_OBJECT") != null &&
						!searchedRecCollObj.getCommMap().containsKey(resultSet.getString("COMMUNICATION_ROWID_OBJECT"))) {
					communication = new CommunicationXrefType();
					LOG.debug("============adding Communication");

					communication.setROWIDCOMMUNICATION(resultSet.getString("COMMUNICATION_ROWID_OBJECT").trim());
					communication.setSRCSYSTEM(resultSet.getString("COMMUNICATION_ROWID_SYSTEM").trim());
					if(Constant.SRC_SYSTEM_ADB.equals(resultSet.getString("COMMUNICATION_ROWID_SYSTEM").trim())){
						communication.setSRCPKEY(resultSet.getString("COMMUNICATION_PKEY_SRC_OBJECT").replaceAll(Constant.ADB_CNT_PREFIX, Constant.STR_BLANK));	
					}else{
						communication.setSRCPKEY(resultSet.getString("COMMUNICATION_PKEY_SRC_OBJECT"));
					}
					communication.setCOMMTYPE(resultSet.getString("COMM_TYPE"));
					communication.setCOMMVALUE(resultSet.getString("COMM_VALUE"));
					communication.setCOMMSTATUS(resultSet.getString("COMM_STATUS"));
					communication.setPRFRDCOMMIND(resultSet.getString("PRFRD_COMM_IND"));
					communication.setWEBDOMAIN(resultSet.getString("WEB_DOMAIN"));
					communication.setCOMMEXTN(resultSet.getString("COMM_EXTN"));
					communication.setCOMMMKTGPREF(resultSet.getString("COMM_MKTG_PREF"));
					//added for SFDC-Track4
					communication.setCOMMSALESPREF(resultSet.getString("COMM_SALES_PREF"));
					LOG.debug("===Inserting into Communication Map===");
					searchedRecCollObj.getCommMap().put(communication.getROWIDCOMMUNICATION(), communication);
				}
				
				bUniqueRec = false;
			}
			LOG.info("Number of retrived party xref profile = " + searchedRecCollMap.size());

			LOG.debug("====Populating Party xref canonical formats");

			for (Entry<String, Map<String, SearchedXrefRecordCollection>> mapEntry : searchedRecCollMapAllParties.entrySet()) {

				for(Entry<String, SearchedXrefRecordCollection> entry : mapEntry.getValue().entrySet()) {

					SearchedXrefRecordCollection fetchedRecCollObj = entry.getValue();
					if (fetchedRecCollObj != null) {
						String partyRowId = fetchedRecCollObj.getParty_rowid();
						party = new PartyXrefType();
						party.setORIGROWIDOBJECT(fetchedRecCollObj.getOrig_rowid());
						party.setBOCLASSCODE(fetchedRecCollObj.getBo_class());
						party.setENGLISHNAME(fetchedRecCollObj.getEnglish_name());
						party.setGEO(fetchedRecCollObj.getGeo());
						party.setPARTYNAME(fetchedRecCollObj.getParty_name());
						party.setPARTYTYPE(fetchedRecCollObj.getParty_type());
						party.setREGION(fetchedRecCollObj.getRegion());
						party.setROWIDOBJECT(partyRowId);
						party.setSALESBLOCKCD(fetchedRecCollObj.getSales_cd());
						party.setSTATUSCD(fetchedRecCollObj.getStatus_cd());
						party.setTAXJURSDCTNCD(fetchedRecCollObj.getTax_jd_cd());
						party.setUCN(fetchedRecCollObj.getUcn());
				//		party.setLEGACYUCN(fetchedRecCollObj.getLegacyUcn());
						party.setVATREGNBR(fetchedRecCollObj.getVat_regno());

						party.getXREF().addAll(fetchedRecCollObj.getXrefMap().values());
						party.getAccount().addAll(fetchedRecCollObj.getAccountMap().values());
						party.getAddress().addAll(fetchedRecCollObj.getAddressMap().values());
						party.getCommunication().addAll(fetchedRecCollObj.getCommMap().values());
						party.getPartyOrgExt().addAll(fetchedRecCollObj.getPartyOrgMap().values());
						party.getPartyPerson().addAll(fetchedRecCollObj.getPartyPersonXrefMap().values());
						party.getClassification().addAll(fetchedRecCollObj.getClassMap().values());

						CanonicalFormManipulator.setDefaultValueInXrefAttributes(party);
						
						if(party.getAccount()!=null && party.getAccount().size()>0){
							if(Util.isNullOrEmpty(party.getAccount().get(0).getACCTNAME())){
								party.getAccount().clear();
							}
						}
						if(party.getAddress()!=null && party.getAddress().size()>0){
							if(Util.isNullOrEmpty(party.getAddress().get(0).getADDRTYPE())){
								party.getAddress().clear();
							}
						}
						if(party.getCommunication()!=null && party.getCommunication().size()>0){
							if(Util.isNullOrEmpty(party.getCommunication().get(0).getCOMMTYPE())){
								party.getCommunication().clear();
							}
						}
						if(party.getClassification()!=null && party.getClassification().size()>0){
							if(Util.isNullOrEmpty(party.getClassification().get(0).getCLASSIFICTNTYPE())){
								party.getClassification().clear();
							}
						}
						if(party.getPartyOrgExt()!=null && party.getPartyOrgExt().size()>0){
							if(Util.isNullOrEmpty(party.getPartyOrgExt().get(0).getROWIDORGEXTN())){
								party.getPartyOrgExt().clear();
							}
						}
						
						if(party.getPartyPersonExt()!=null && party.getPartyPersonExt().size()>0){
							if(Util.isNullOrEmpty(party.getPartyPersonExt().get(0).getPERSONTYPE())){
								party.getPartyPersonExt().clear();
							}
						}
						
						if(party.getPartyPerson()!=null && party.getPartyPerson().size()>0){
							if(Util.isNullOrEmpty(party.getPartyPerson().get(0).getFIRSTNAME())){
								party.getPartyPerson().clear();
							}
						}
						
						if(party.getPartyRel()!=null){
							if(party.getPartyRel().getPARTYACCOUNTREL()!=null && party.getPartyRel().getPARTYACCOUNTREL().size()>0){
								if(Util.isNullOrEmpty(party.getPartyRel().getPARTYACCOUNTREL().get(0).getHIERARCHYTYPE())){
									party.getPartyRel().getPARTYACCOUNTREL().clear();
								}
							}
							if(party.getPartyRel().getPARTYPERSONREL()!=null && party.getPartyRel().getPARTYPERSONREL().size()>0){
								if(Util.isNullOrEmpty(party.getPartyRel().getPARTYPERSONREL().get(0).getHIERARCHYTYPE())){
									party.getPartyRel().getPARTYPERSONREL().clear();
								}
							}
						}
						
						
						partyXrefList.add(party);
					}
				}
				partyXrefMap.put(mapEntry.getKey(), partyXrefList);
			}

			LOG.info("Number of Contact xref canonical format created = " + partyXrefMap.size());
		} catch (SQLException sqlEx) {
			LOG.error("SQLException occurred while retrieving Contact details from resultset: ", sqlEx);
			//sqlEx.printStackTrace();
		} catch (Exception excp) {
			LOG.error("Exception occurred while creating Contact canonical format from resultset: ", excp);
			//excp.printStackTrace();
		}

		LOG.info("Executed createXrefCanonicalFormContact()");
		return partyXrefMap;
	}

		
	/*COntact Fuzzy Seach*/
	//Method To Fetch ACCOUNT_ROWID_OBJECT from Contact_RowID
	public Map <String,String> getAccountRowidByContactID(Set<String> contactIDList) throws ServiceProcessingException	{

		LOG.info("Executing getAccountRowidByContactID() ");
		Connection jdbcConn = null;
		Statement statement = null;
		ResultSet resultSet = null;
		StringBuilder sql = new StringBuilder ();

		JDBCConnectionProvider jDBCConnectionProvider =  JDBCConnectionProvider.getSingleInstance();
		jdbcConn = jDBCConnectionProvider.getJdbcConnectionFromDS();
		Map <String,String> cntctAcctMap = new HashMap<String,String>();

		sql.append("SELECT ROWID_PARTY_2, ROWID_PARTY FROM C_B_PARTY_REL WHERE ROWID_PARTY_2 in (");
		for (String cntctRowId : contactIDList) {
			sql.append("'" + cntctRowId.trim() + "',");
		}
		sql.deleteCharAt(sql.length() - 1).toString();
		sql.append(") AND ROWID_REL_TYPE = '25' AND ROWID_HIERARCHY = '4' AND HUB_STATE_IND<>-1");

		LOG.info("Query for getAccountRowidByContactID: " + sql.toString());
		try {
			statement = jdbcConn.createStatement();
			resultSet = statement.executeQuery(sql.toString());

			while (resultSet.next()) {
				/*Map with pair = ContactID, AccountID*/
				cntctAcctMap.put(resultSet.getString(1).trim(), resultSet.getString(2).trim());
			}
			
			if(cntctAcctMap != null && cntctAcctMap.size()>0){
				for(Map.Entry<String,String> mEntry: cntctAcctMap.entrySet()){
					LOG.info("ContactID: "+mEntry.getKey()+" |AccountID:"+mEntry.getValue()+".");
				}
			}
		 } catch(SQLException sqlex) {
			 LOG.error("Caught sql exception in getAccountRowidByContactID(): " , sqlex);
		 } finally {
			 try {
				 //Closing connections
				 if (resultSet != null)	resultSet.close();
				 if (statement != null) statement.close();
				 if (jdbcConn != null) jdbcConn.close();
				} catch (SQLException e) {
					 LOG.error("Caught sql exception in getAccountRowidByContactID(): " , e);
				}
		 }
		LOG.info("Executed getAccountRowidByContactID() ");
		return cntctAcctMap;
	}
	
	/*COntact Fuzzy Seach*/
	//Method To Fetch ACCOUNT Details from ACCOUNT_ROWID_OBJECT
	public SearchedRecordCollection getAccountDetails(String acctRowid) throws ServiceProcessingException	{

		LOG.debug("Executing getAccountDetails() ");
		Connection jdbcConn = null;
		Statement statement = null;
		ResultSet resultSet = null;
		StringBuilder sql = new StringBuilder ();

		PartyType party = null;
		PartyOrgExtType partyOrgExt = null;
		AddressType address = null;
		SearchedRecordCollection searchedRecCollObj = null;

		sql.append("SELECT ORG.ROWID_OBJECT ROWID_ORG_EXTN, ORG.MFE_GLBL_PARENT_NM, ORG.MFE_GLBL_PARENT_UCN, PARTY.UCN, PARTY.PARTY_NAME, PARTY.PARTY_TYPE,");
		sql.append(" ADDR.ROWID_OBJECT ADDRESS_ROWID_OBJECT, ADDR.ADDR_LN1, ADDR.ADDR_LN2, ADDR.CITY, ADDR.STATE_CD, ADDR.POSTAL_CD, ADDR.COUNTRY_CD");
		sql.append(" FROM C_B_PARTY_ORG_EXTN ORG, C_B_PARTY PARTY, C_B_ADDRESS ADDR");
		sql.append(" WHERE PARTY.ROWID_OBJECT = ADDR.ROWID_PARTY");
		sql.append(" AND PARTY.ROWID_OBJECT = ORG.ROWID_PARTY(+)");
		sql.append(" and PARTY.ROWID_OBJECT = '"+acctRowid+"'");

		LOG.debug("Query for getAccountDetails: " + sql.toString());
		try {
			JDBCConnectionProvider jDBCConnectionProvider =  JDBCConnectionProvider.getSingleInstance();
			jdbcConn = jDBCConnectionProvider.getJdbcConnectionFromDS();
			statement = jdbcConn.createStatement();
			resultSet = statement.executeQuery(sql.toString());

			while (resultSet.next()) {
				
		//		party = new PartyType();
				searchedRecCollObj = new SearchedRecordCollection();
		//		party.setUCN(resultSet.getString("UCN"));
				searchedRecCollObj.setUcn(resultSet.getString("UCN"));
		//		party.setPARTYTYPE(resultSet.getString("PARTY_TYPE"));
				searchedRecCollObj.setParty_type(resultSet.getString("PARTY_TYPE"));
		//		party.setPARTYNAME(resultSet.getString("PARTY_NAME"));
				searchedRecCollObj.setParty_name(resultSet.getString("PARTY_NAME"));
				
				if (resultSet.getString("ADDRESS_ROWID_OBJECT") != null &&
						!searchedRecCollObj.getAddressMap().containsKey(resultSet.getString("ADDRESS_ROWID_OBJECT"))) {
					LOG.debug("============setting Account-Address");
				
					address = new AddressType();
					address.setROWIDADDRESS(resultSet.getString("ADDRESS_ROWID_OBJECT"));
					address.setADDRLN1(resultSet.getString("ADDR_LN1"));
					address.setADDRLN2(resultSet.getString("ADDR_LN2"));
					address.setCITY(resultSet.getString("CITY"));
					address.setSTATECD(resultSet.getString("STATE_CD"));
					address.setPOSTALCD(resultSet.getString("POSTAL_CD"));
					address.setCOUNTRYCD(resultSet.getString("COUNTRY_CD"));

					LOG.debug("===Inserting into Account-Address-Map===");
					searchedRecCollObj.getAddressMap().put(address.getROWIDADDRESS(), address);
				}
				
				if (resultSet.getString("ROWID_ORG_EXTN") != null && 
						!searchedRecCollObj.getPartyOrgMap().containsKey(resultSet.getString("ROWID_ORG_EXTN"))) {
					partyOrgExt = new PartyOrgExtType();
					LOG.debug("============adding Account-PartyOrgExt");

					partyOrgExt.setROWIDORGEXTN(resultSet.getString("ROWID_ORG_EXTN"));
					partyOrgExt.setORGDOMULTDUNS(resultSet.getString("MFE_GLBL_PARENT_NM"));
					partyOrgExt.setORGGLBULTDUNS(resultSet.getString("MFE_GLBL_PARENT_UCN"));

					LOG.debug("===Inserting into Account-PartyOrgExtType Map==");
					searchedRecCollObj.getPartyOrgMap().put(partyOrgExt.getROWIDORGEXTN(), partyOrgExt);
				}	
			}
		 } catch(SQLException sqlex) {
			 LOG.error("Caught sql exception in getAccountDetails(): " , sqlex);
		 } finally {
			 try {
				 //Closing connections
				 if (resultSet != null)	resultSet.close();
				 if (statement != null) statement.close();
				 if (jdbcConn != null) jdbcConn.close();
				} catch (SQLException e) {
					 LOG.error("Caught sql exception in getAccountDetails(): " , e);
				}
		 }
		LOG.debug("Executed getAccountDetails() ");
		return searchedRecCollObj;
	}

	public SearchContactResponse searchContact(SearchContactRequest parameters) throws ServiceProcessingException {
		
		LOG.debug("Inside  searchContact method.. ");
		SearchContactResponse  searchContactResponse= new SearchContactResponse();
		ContactSearchCriteriaType contactSearchCriteriaType = parameters
				.getContactSearchCriteria();
		if ((!Util.isNullOrEmpty(contactSearchCriteriaType.getFIRSTNAME())
				|| !Util.isNullOrEmpty(contactSearchCriteriaType.getLASTNAME())) && 
				Util.isNullOrEmpty(contactSearchCriteriaType.getACCOUNTNAME())) {
			
			LOG.debug("Calling  performContactFuzzySearch..");
			searchContactResponse = performContactFuzzySearch(parameters);

		}else if((!Util.isNullOrEmpty(contactSearchCriteriaType.getFIRSTNAME())
				|| !Util.isNullOrEmpty(contactSearchCriteriaType.getLASTNAME())) && 
				!Util.isNullOrEmpty(contactSearchCriteriaType.getACCOUNTNAME())){
			LOG.debug("Calling  performContactAccountFuzzySearch..");
			searchContactResponse = performContactAccFuzzySearch(parameters);
		}
		else if (Util.isNullOrEmpty(contactSearchCriteriaType.getLASTNAME())
				&& Util.isNullOrEmpty(contactSearchCriteriaType.getFIRSTNAME())
				&& !Util.isNullOrEmpty(contactSearchCriteriaType
						.getACCOUNTNAME())) {
			
			LOG.debug("Calling  performAccountFuzzySearch..");
			searchContactResponse= performAccountFuzzySearch(parameters);
			
		}else{
			
			
			LOG.debug("Calling  performEmailSearch..");
			searchContactResponse=performEmailSearch(parameters);
		}
		if(searchContactResponse.getContactProfiles()!= null){
			LOG.debug("searchContactResponse.getContactProfiles() not  null ");
		}
		
		LOG.debug("Printing SearchContactResponse request:-");
		Util.printObjectTreeInXML(SearchContactResponse.class,searchContactResponse);
		return searchContactResponse;
	
	}



	private SearchContactResponse performEmailSearch(
			SearchContactRequest parameters) throws ServiceProcessingException {

		LOG.debug("Inside  performContactLikeSearch method.. ");
		SearchMatchResponse searchMatchResponse= new SearchMatchResponse();
		int matchScoreThresold=0;
		if (!Util.isNullOrEmpty(parameters.getMatchScoreThresold())) {
			matchScoreThresold = Integer.parseInt(parameters
					.getMatchScoreThresold());
		} else {
			matchScoreThresold = Integer.parseInt(matchScoreThresDef);
		}
		long startTime=System.currentTimeMillis();
		searchMatchResponse=performOnlyEmailSearch(parameters);
		long endTime=System.currentTimeMillis();
		LOG.info("Total Time in only email seacrh response  -------:"+(endTime-startTime) ); 
	
		SearchContactResponse searchContactResponse = new SearchContactResponse();
		if (searchMatchResponse != null
				&& searchMatchResponse.getRecords().size() > 0) {
			LOG.info("SearchMatchResponse rec cnt="
					+ searchMatchResponse.getRecords().size());
			
			
			
			int matchScore=0;
			List searchRecords = searchMatchResponse.getRecords();
			if (searchRecords != null && searchRecords.size() != 0) {
				LOG.info("inside searchRecords != null && searchRecords.size() != 0");
				for (Iterator iter = searchRecords.iterator(); iter
						.hasNext();) {
					Record record = (Record) iter.next();
					String rowId=null;
					
					if(record.getField("MATCH_SCORE") != null && record.getField("MATCH_SCORE").getStringValue()!= null ){
						LOG.info("match score ::"+Integer.parseInt(record.getField("MATCH_SCORE").getStringValue().trim()));
						matchScore=Integer.parseInt(record.getField("MATCH_SCORE").getStringValue().trim());
						}
					if(record.getField("ROWID_OBJECT") != null &&  record.getField("ROWID_OBJECT").getStringValue()!= null){
						LOG.info("inside ROWID_OBJECT != null");
						rowId=record.getField("ROWID_OBJECT").getStringValue().trim();
					
						LOG.info("rowid from search :" +rowId);
						//if(matchScore >=matchScoreThresold ){
						recordMap.put(rowId, matchScore);
					
						//}
						
					}
					
				}
			}
			
			

			Statement statement = null;
			StringBuilder sqlQry = new StringBuilder();
			Connection jdbcConnection = null;
			ResultSet resultSet = null;
			int recordCountThresold = 0;
			String email = null;
			if (!Util.isNullOrEmpty(parameters.getRecordCountThresold())) {
				recordCountThresold = Integer.parseInt(parameters
						.getRecordCountThresold());
			} else {
				recordCountThresold = recCountThresDef;
			}
			LOG.debug("Setting recordCountThresold: " + recordCountThresold);
			if (!Util.isNullOrEmpty(parameters.getContactSearchCriteria()
					.getEMAILADDRESS())) {
				email = parameters.getContactSearchCriteria().getEMAILADDRESS();
			}
			try {

				JDBCConnectionProvider jDBCConnectionProvider = JDBCConnectionProvider
						.getSingleInstance();
				sqlQry.append("select * from pkg_contact_fuzzy_search where ROWID_OBJECT in ( ");
				
				for (String contctRowId : recordMap.keySet()) {
					sqlQry.append("'" + contctRowId.trim() + "',");
					
				}
				sqlQry.deleteCharAt(sqlQry.length() - 1).toString();
				sqlQry.append(")");
				LOG.debug("Query to fetch records: " + sqlQry);
				jdbcConnection = jDBCConnectionProvider
						.getJdbcConnectionFromDS();
				statement = jdbcConnection.createStatement();
				long startTimeforpkg=System.currentTimeMillis();
				resultSet = statement.executeQuery(sqlQry.toString());

				long endTimeforpkg=System.currentTimeMillis();
				LOG.info("Total Time in pkg query seacrh response  -------:"+(endTimeforpkg-startTimeforpkg) ); 
				long startTimeforbuildRes=System.currentTimeMillis();
				searchContactResponse = buildResponseContactLikeSearch(resultSet);
				long endTimeforbuildRes=System.currentTimeMillis();
				LOG.info("Total Time in pkg query seacrh response  -------:"+(endTimeforbuildRes-startTimeforbuildRes) ); 

			} catch (SQLException sqlEx) {
				LOG.error(
						"Exception in getXrefRecforID() for ID based Search: ",
						sqlEx);
				ServiceProcessingException customException = new ServiceProcessingException(
						sqlEx);
				customException
						.setMessage("Failed to fetch Party profile from ORS."
								+ customException.getMessage());
				throw customException;
			} finally {
				try {
					if (resultSet != null)
						resultSet.close();
					if (statement != null)
						statement.close();
					if (jdbcConnection != null)
						jdbcConnection.close();
				} catch (SQLException e) {

					LOG.debug("Caught SQLException in getXrefRecforID: ", e);
				}
			}
		}else{
			LOG.info("no records from match response");
			searchContactResponse.setErrorMsg("No Record Found");
		}
		return searchContactResponse;
	}

private SearchMatchResponse performOnlyEmailSearch(SearchContactRequest parameters)  throws ServiceProcessingException{
		

		LOG.debug("Inside  performContactFuzzySearch method.. ");
		SearchContactResponse searchContactResponse = new SearchContactResponse();
		// code goes here
		String searchRuleSet = null;
		String searchType = null;
		MatchType matchType = null;
		int recordCountThresold = 0;
		int matchScoreThresold = 0;
	//	String countryName= null;
		if (!Util.isNullOrEmpty(parameters.getSearchType())) {
			searchType = parameters.getSearchType();
		}
		LOG.debug("Search Type:: " + searchType);
		if (!Util.isNullOrEmpty(parameters.getMatchScoreThresold())) {
			matchScoreThresold = Integer.parseInt(parameters
					.getMatchScoreThresold());
		} else {
			matchScoreThresold = Integer.parseInt(matchScoreThresDef);
		}
		LOG.debug("Setting MatchScoreThreshold: " + matchScoreThresold);
		if (!Util.isNullOrEmpty(parameters.getRecordCountThresold())) {
			recordCountThresold = Integer.parseInt(parameters
					.getRecordCountThresold());
		} else {
			recordCountThresold = recCountThresDef;
		}
		LOG.debug("Setting recordCountThresold: " + recordCountThresold);
		ContactSearchCriteriaType contactSearchCriteriaType = parameters
				.getContactSearchCriteria();
		searchRuleSet = "Party Person Fuzzy Ruleset Person Email";
		
		matchType = MatchType.BOTH;
		SiperianClient siperianClient = null;

		SearchMatchRequest searchMatchRequest = null;
		SearchMatchResponse searchMatchResponse = null;
		searchMatchRequest = new SearchMatchRequest();
		searchMatchRequest.setRecordsToReturn(recordCountThresold);

		searchMatchRequest
				.setSiperianObjectUid("BASE_OBJECT.C_B_PARTY_PERSON");
		searchMatchRequest.setMatchRuleSetUid(SiperianObjectType.MATCH_RULE_SET
				.makeUid(searchRuleSet));// searchRuleSet,ruleSetName
		searchMatchRequest.setMatchType(matchType);

		LOG.info("Match Rule Set: " + searchMatchRequest.getMatchRuleSetUid());
		LOG.info("Match Type :" + searchMatchRequest.getMatchType());
		LOG.info("PKG::" + searchMatchRequest.getSiperianObjectUid());
		
		Field emailAdd = new Field("Ex_Comm_Value");
		StringBuilder emailConcat = new StringBuilder();
		Field exCommType= new Field("Ex_Comm_Type");
		Field exRowidParty= new Field("Ex_Rowid_Party");   
		String type= "Email";
		if (!Util.isNullOrEmpty(contactSearchCriteriaType.getEMAILADDRESS())) {
			emailConcat.append(contactSearchCriteriaType.getEMAILADDRESS());
		}
		if (emailConcat != null && emailConcat.length() > 0) {
			emailAdd.setStringValue(emailConcat.toString());
			exCommType.setStringValue(type);
			searchMatchRequest.addMatchColumnField(emailAdd);
			searchMatchRequest.addMatchColumnField(exCommType);
			searchMatchRequest.addMatchColumnField(exRowidParty);
		}

		LOG.info("Field to search for :" + emailAdd.getName() + ':'
				+ emailAdd.getStringValue());
		ArrayList matchColumField = searchMatchRequest.getMatchColumnFields();
		for (Object obj : matchColumField) {
			LOG.info("matchColumField" + obj.toString());
		}
	
		try {
			siperianClient = (SiperianClient) checkOut();

			LOG.info("processing SearchMatchRequest");
			// Util.printObjectTreeInXML(SearchMatchRequest.class,searchMatchRequest);
			LOG.info("before request");
			searchMatchResponse = (SearchMatchResponse) siperianClient
					.process(searchMatchRequest);
			LOG.info("after response");
		} catch (SiperianServerException sifExcp) {
			LOG.error("SiperianServerException occured while processing SearchMatchRequest: "
					+ sifExcp);
			LOG.error("Get Message: " + sifExcp.getMessage());
			ServiceProcessingException customException = new ServiceProcessingException(
					sifExcp.getMessage());
			customException.setRootExceptionMsg(sifExcp
					+ " SearchMatch operation failed for Person_Name: "
					+ contactSearchCriteriaType.getFIRSTNAME());
			searchContactResponse.setErrorMsg(customException
					.getRootExceptionMsg());
			customException
					.setMessage("SIF exception occured while processing SearchMatch request for Party. ");
			throw customException;
		} catch (Exception exp) {
			LOG.error("Exception occured while processing SearchMatchRequest: "
					+ exp);
			LOG.error("SearchMatch Exeption :" + exp.getMessage());
			ServiceProcessingException customException = new ServiceProcessingException(
					exp);
			customException.setRootExceptionMsg(exp
					+ " SearchMatch operation failed for Person_Name: "
					+ contactSearchCriteriaType.getFIRSTNAME());
			searchContactResponse.setErrorMsg(customException
					.getRootExceptionMsg());
			customException
					.setMessage("SIF exception occured while processing SearchMatch request for Party.");
			throw customException;
		} finally {
			checkIn(siperianClient);
		}

	
		return searchMatchResponse;
	
	
	}

	private SearchContactResponse performContactAccFuzzySearch(
			SearchContactRequest parameters) throws ServiceProcessingException{
		LOG.debug("Inside  performContactAccFuzzySearch method.. ");
		SearchContactResponse searchContactResponse= new SearchContactResponse();
		
		//calling person Search
		long startTime=System.currentTimeMillis();
		SearchMatchResponse searchMatchResponseFromperson= performOnlyPersonSearch(parameters);
		long endTime=System.currentTimeMillis();
		LOG.info("Total Time in only person seacrh response -------:"+(endTime-startTime) );
		if (searchMatchResponseFromperson != null
				&& searchMatchResponseFromperson.getRecords().size() > 0) {
		String searchRuleSet= null;
		String searchType = null;
		MatchType matchType = null;
		int recordCountThresold= 0;
		int matchScoreThresold= 0;
		if(!Util.isNullOrEmpty(parameters.getSearchType()))	{
			searchType = parameters.getSearchType();
		}
		LOG.debug("Search Type:: " + searchType);
		if(!Util.isNullOrEmpty(parameters.getMatchScoreThresold())){
			matchScoreThresold=Integer.parseInt(parameters.getMatchScoreThresold());
		}else{
			matchScoreThresold=Integer.parseInt(matchScoreThresDef);
		}
		LOG.debug("Setting MatchScoreThreshold: " + matchScoreThresold);
		if(!Util.isNullOrEmpty(parameters.getRecordCountThresold())){
			recordCountThresold= Integer.parseInt(parameters.getRecordCountThresold());
		}else{
			recordCountThresold=recCountThresDef;
		}
		LOG.debug("Setting recordCountThresold: " + recordCountThresold);
		ContactSearchCriteriaType contactSearchCriteriaType= parameters.getContactSearchCriteria();
		searchRuleSet = "Account Fuzzy Ruleset";
		matchType = MatchType.BOTH;
		SiperianClient siperianClient = null;

		SearchMatchRequest searchMatchRequestForAcc = null;
		SearchMatchResponse searchMatchResponseForAcc = null;
		searchMatchRequestForAcc = new SearchMatchRequest();
		searchMatchRequestForAcc.setRecordsToReturn(recordCountThresold);
		
		searchMatchRequestForAcc.setSiperianObjectUid("BASE_OBJECT.C_B_ACCOUNT");
		searchMatchRequestForAcc.setMatchRuleSetUid(SiperianObjectType.MATCH_RULE_SET.makeUid(searchRuleSet));//searchRuleSet,ruleSetName
		searchMatchRequestForAcc.setMatchType(matchType);

		LOG.info("Match Rule Set for Acc: " + searchMatchRequestForAcc.getMatchRuleSetUid());
		LOG.info("Match Type for Acc :" + searchMatchRequestForAcc.getMatchType());
		LOG.info("SiperianObjectUid for Acc: "+ searchMatchRequestForAcc.getSiperianObjectUid());
		Field orgName = new Field("Organization_Name");
				StringBuilder orgNameConcat = new StringBuilder();
				if (!Util.isNullOrEmpty(contactSearchCriteriaType.getACCOUNTNAME())) {
					orgNameConcat.append(contactSearchCriteriaType.getACCOUNTNAME());
				}
				if(orgNameConcat != null && orgNameConcat.length() > 0){
					orgName.setStringValue(orgNameConcat.toString());
					searchMatchRequestForAcc.addMatchColumnField(orgName);
				}
				
				try {
					siperianClient = (SiperianClient) checkOut();

					LOG.info("processing SearchMatchRequest  ");
				//	Util.printObjectTreeInXML(SearchMatchRequest.class,searchMatchRequest);
					LOG.info("before request");
					long startTimeforAcc=System.currentTimeMillis();
					searchMatchResponseForAcc = (SearchMatchResponse) siperianClient.process(searchMatchRequestForAcc);
					long endTimeforAcc=System.currentTimeMillis();
					LOG.info("Total Time in only account seacrh response  -------:"+(endTimeforAcc-startTimeforAcc) ); 
					LOG.info("after response");
				} catch (SiperianServerException sifExcp) {
					LOG.error("SiperianServerException occured while processing SearchMatchRequest: " + sifExcp);
					LOG.error("Get Message: "+ sifExcp.getMessage());
					ServiceProcessingException customException = new ServiceProcessingException(sifExcp.getMessage());
					customException.setRootExceptionMsg(sifExcp + " SearchMatch operation failed for Organization_Name: "+ contactSearchCriteriaType.getACCOUNTNAME());
					searchContactResponse.setErrorMsg(customException.getRootExceptionMsg());
					customException.setMessage("SIF exception occured while processing SearchMatch request for Party. ");
					throw customException;
				} catch (Exception exp) {
					LOG.error("Exception occured while processing SearchMatchRequest: " + exp);
					LOG.error("SearchMatch Exeption :" + exp.getMessage());
					ServiceProcessingException customException = new ServiceProcessingException(exp);
					customException.setRootExceptionMsg(exp + " SearchMatch operation failed for Organization_Name: "+ contactSearchCriteriaType.getACCOUNTNAME());
					searchContactResponse.setErrorMsg(customException.getRootExceptionMsg());
					customException.setMessage("SIF exception occured while processing SearchMatch request for Party.");
					throw customException;
				} finally {
					checkIn(siperianClient);
				}
				List<String> rowIdPartyList= new ArrayList<String>();
				if (searchMatchResponseForAcc != null
						&& searchMatchResponseForAcc.getRecords().size() > 0) {
					LOG.info("SearchMatchResponse rec cnt="	+ searchMatchResponseForAcc.getRecords().size());
					List searchRecords = searchMatchResponseForAcc.getRecords();
					if (searchRecords != null && searchRecords.size() != 0) {
						//LOG.info("inside searchRecords != null && searchRecords.size() != 0");
						for (Iterator iter = searchRecords.iterator(); iter
								.hasNext();) {
							Record record = (Record) iter.next();
							String rowId=null;
						if(record.getField("ROWID_PARTY") != null &&  record.getField("ROWID_PARTY").getStringValue()!= null){
								//LOG.info("inside ROWID_PARTY != null");
								rowId=record.getField("ROWID_PARTY").getStringValue().trim();
								LOG.info("rowid_party from acc search :" +rowId);
								rowIdPartyList.add(rowId);
								
							}
						}
						
					}
					searchContactResponse=	buildcontactSearchPart(searchMatchResponseFromperson,parameters,matchScoreThresold,rowIdPartyList)	;
				}else{
					LOG.info("no records from match response");
					searchContactResponse.setErrorMsg("No Record Found");
				}
		}else{
			LOG.info("no records from match response");
			searchContactResponse.setErrorMsg("No Record Found");
		}
		return searchContactResponse;
	}
	private SearchContactResponse buildcontactSearchPart(
			SearchMatchResponse searchMatchResponse,
			SearchContactRequest parameters, int matchScoreThresold, List<String> rowIdPartyListFromAccSearch)  throws ServiceProcessingException  {

		LOG.info("inside buildReponseForAccountSearch");
		SearchContactResponse searchContactResponse= new SearchContactResponse();
		int matchScore=0;
		List<String> rowidParty= new ArrayList<String>();
		List searchRecords = searchMatchResponse.getRecords();
		if (searchRecords != null && searchRecords.size() != 0) {
			LOG.info("inside searchRecords != null && searchRecords.size() != 0");
			for (Iterator iter = searchRecords.iterator(); iter
					.hasNext();) {
				Record record = (Record) iter.next();
				String rowId=null;
				
				if(record.getField("MATCH_SCORE") != null && record.getField("MATCH_SCORE").getStringValue()!= null ){
					//LOG.info("match score ::"+Integer.parseInt(record.getField("MATCH_SCORE").getStringValue().trim()));
					matchScore=Integer.parseInt(record.getField("MATCH_SCORE").getStringValue().trim());
					}
				if(record.getField("ROWID_OBJECT") != null &&  record.getField("ROWID_OBJECT").getStringValue()!= null){
				//	LOG.info("inside ROWID_OBJECT != null");
					rowId=record.getField("ROWID_OBJECT").getStringValue().trim();
				
					//LOG.info("rowid from search :" +rowId);
					if(matchScore >=matchScoreThresold ){
					recordMap.put(rowId, matchScore);
					LOG.info("ROWID_PARTY "+ record.getField("ROWID_PARTY").getStringValue());
					rowidParty.add(record.getField("ROWID_PARTY").getStringValue());
					}
					
				}
				
			}
			if(recordMap.size() >0 ){
				LOG.info("rowIDList size :: "+ recordMap.size());
				searchContactResponse=	performSearchOnPackageForContactAcc(parameters,matchScore,rowidParty,rowIdPartyListFromAccSearch);
				
				
			}else{
				searchContactResponse.setErrorMsg(Constant.noRecordFound);
			}
			
		}
		return searchContactResponse;
	}
	private SearchContactResponse performSearchOnPackageForContactAcc(
			SearchContactRequest parameters, int matchScore,
			List<String> rowidParty, List<String> rowIdPartyListFromAccSearch)  throws ServiceProcessingException  {



		
		LOG.debug("Inside  performSearchOnPackage method.. ");
		SearchContactResponse searchContactResponse= new SearchContactResponse();
		//code goes here
		Statement statement = null;
		StringBuilder sqlQry = new StringBuilder();
		Connection jdbcConnection = null;
		ResultSet resultSet = null;
		ResultSet resultSet1 = null;
		String email=null;
		if (!Util.isNullOrEmpty(parameters.getContactSearchCriteria().getEMAILADDRESS())) {
			email= parameters.getContactSearchCriteria().getEMAILADDRESS();
		}
		try {

			JDBCConnectionProvider jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
		
			sqlQry.append("(select x.rowid_object from ");
			sqlQry.append("(select c.rowid_object, row_number() over (partition by c.rowid_party_2 order by c.create_date desc) rn ");
			sqlQry.append("from c_b_party_rel c ,c_b_party p  ");
			sqlQry.append("where c.rowid_party_2 in( ");
			for (String party : rowidParty) {
				sqlQry.append("'" + party.trim() + "',");
			}
			sqlQry.deleteCharAt(sqlQry.length() - 1).toString();
			sqlQry.append(" ) and c.hub_state_ind = 1 ");
			sqlQry.append("and c.rowid_hierarchy = '4' ");
			sqlQry.append("and c.rowid_rel_type = '25' and p.PARTY_TYPE ='Customer' and c.ROWID_PARTY=p.ROWID_OBJECT) x where x.rn = 1)");
			
			LOG.debug("Query to fetch records: " + sqlQry);
			jdbcConnection = jDBCConnectionProvider.getJdbcConnectionFromDS();
			statement = jdbcConnection.createStatement();
			long startTime=System.currentTimeMillis();
			resultSet = statement.executeQuery(sqlQry.toString());
			long endTime=System.currentTimeMillis();
			LOG.info("Total Time in finding latest contact query  response -------:"+(endTime-startTime) ); 
			List<String> relRowIdList= new ArrayList<String>();
			while (resultSet.next()) {
				
				String relRowid= resultSet.getString("rowid_object");
				relRowIdList.add(relRowid);
			}
			if(relRowIdList.size()>0){
			StringBuilder sqlQry1 = new StringBuilder();
			sqlQry1.append("select * from pkg_contact_fuzzy_search where REL_ROWID in ( ");
			for (String relRowId : relRowIdList) {
				sqlQry1.append("'" + relRowId.trim() + "',");
			}
			sqlQry1.deleteCharAt(sqlQry1.length() - 1).toString();
			sqlQry1.append(" ) and ROWID_OBJECT in (");
			for (String contctRowId : recordMap.keySet()) {
				sqlQry1.append("'" + contctRowId.trim() + "',");
				
			}
			sqlQry1.deleteCharAt(sqlQry1.length() - 1).toString();
			sqlQry1.append(")");
			/*if(email != null){
				sqlQry1.append(" and COMM_VALUE like ('%" +email +"%')" );
			}*/
			LOG.debug("Query to fetch records: " + sqlQry1);
			long startTimeforpkg=System.currentTimeMillis();
			resultSet1 = statement.executeQuery(sqlQry1.toString());
			long endTimeforpkg=System.currentTimeMillis();
			LOG.info("Total Time in pkg  seacrh response -------:"+(endTimeforpkg-startTimeforpkg) ); 
			long startTimeforBuildRes=System.currentTimeMillis();
			searchContactResponse= buildResponseforContactAcc(resultSet1,rowIdPartyListFromAccSearch);
			long endTimeforBuildRes=System.currentTimeMillis();
			LOG.info("Total Time in pkg  seacrh response -------:"+(endTimeforBuildRes-startTimeforBuildRes) ); 
			}
			else{
				searchContactResponse.setErrorMsg(Constant.noRecordFound);
			}
			
			
			
		} catch (SQLException sqlEx) {
			LOG.error("Exception in getXrefRecforID() for ID based Search: " , sqlEx);
			ServiceProcessingException customException = new ServiceProcessingException(sqlEx);
			customException.setMessage("Failed to fetch Party profile from ORS." + customException.getMessage());
			throw customException;
		}	finally {
			try {
					if( resultSet != null) resultSet.close();
					if( statement != null) statement.close();
					if(jdbcConnection != null) jdbcConnection.close();
				} catch (SQLException e) {

					LOG.debug("Caught SQLException in getXrefRecforID: " , e);
				}
		}

		
		return searchContactResponse;
	
		
	
	
	}

	private SearchContactResponse buildResponseforContactAcc(
			ResultSet resultSet, List<String> rowIdPartyListFromAccSearch) {


		LOG.debug("inside Build Response");
		SearchContactResponse searchContactResponse= new SearchContactResponse();
		Map <String , ContactType> contactTypeMap= new HashMap<String, ContactType>();
		ContactType contactType=  null;
		ContactProfileType contactProfileType= new ContactProfileType();
		boolean bUniqueRec= false;
		try {
			while (resultSet.next()) {
				String accId=resultSet.getString("ACCT_ROWID").trim();
				LOG.info("ACCT_ROWID from pkg result set :: "+ accId);
				//LOG.info("rowIdPartyListFromAccSearch size : " +rowIdPartyListFromAccSearch.size());
					if(rowIdPartyListFromAccSearch.contains(accId)){
						LOG.debug("inside resultSet.next() MDMCONTACTID ::" +resultSet.getString("MDM_CONTACT_UCN"));
						String rowIdObj=resultSet.getString("ROWID_OBJECT").trim();
						String acctRowId=resultSet.getString("ACCT_ROWID").trim();
						String key=rowIdObj.concat(acctRowId);
						if(!contactTypeMap.containsKey(key)){
							//LOG.debug("populate contactTypeMap for ROWID_OBJECT : "+key);
							contactTypeMap.put(key, new ContactType());
							bUniqueRec=true;
						}
						contactType= contactTypeMap.get(key);
						if(bUniqueRec){
							//LOG.debug("inside bUniqueRec..");
							
						 Iterator it = recordMap.entrySet().iterator();
						    while (it.hasNext()) {
						    //	LOG.info("inside it.hasNext()");
						        Map.Entry pair = (Map.Entry)it.next();
						       // LOG.info("pair.getKey().toString() ::" +pair.getKey().toString() + "match value:"+pair.getValue());
						        String key1=pair.getKey().toString().trim();
						       // LOG.info("Key :" +key1);
						        String rowIdObject=resultSet.getString("ROWID_OBJECT").trim();
						    //    LOG.info("ROWID_OBJECT : "+ rowIdObject);
						        if(rowIdObject.equalsIgnoreCase(key1)){
						        	LOG.info("inside if block");
						        	contactType.setMatchScore((Integer)pair.getValue());
						        }
						        
						    }
						contactType.setMDMCONTACTID(resultSet.getString("MDM_CONTACT_UCN"));
						contactType.setFIRSTNAME(resultSet.getString("FIRST_NAME"));
						contactType.setLASTNAME(resultSet.getString("LAST_NAME"));
						contactType.setEMAILADDRESS(resultSet.getString("COMM_VALUE"));
						contactType.setACCOUNTUCN(resultSet.getString("ACCOUNT_UCN"));
						contactType.setACCOUNTNAME(resultSet.getString("ACCOUNT_NAME"));
						contactProfileType.getContact().add(contactType);	
							}
						bUniqueRec=false;
					}
			
				
			
			}
			if(contactProfileType.getContact()!= null && contactProfileType.getContact().size()>0){
				LOG.info("contactProfileType size::" + contactProfileType.getContact().size());
				searchContactResponse.setStatus(Constant.SUCCESS);
				searchContactResponse.setContactProfiles(contactProfileType);
				
				}
				else{
					
					searchContactResponse.setErrorMsg(Constant.noRecordFound);
				}
				
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return searchContactResponse;
	
	
	}

	private SearchMatchResponse performOnlyPersonSearch(SearchContactRequest parameters)  throws ServiceProcessingException{
		

		LOG.debug("Inside  performContactFuzzySearch method.. ");
		SearchContactResponse searchContactResponse = new SearchContactResponse();
		// code goes here
		String searchRuleSet = null;
		String searchType = null;
		MatchType matchType = null;
		int recordCountThresold = 0;
		int matchScoreThresold = 0;
	//	String countryName= null;
		if (!Util.isNullOrEmpty(parameters.getSearchType())) {
			searchType = parameters.getSearchType();
		}
		LOG.debug("Search Type:: " + searchType);
		if (!Util.isNullOrEmpty(parameters.getMatchScoreThresold())) {
			matchScoreThresold = Integer.parseInt(parameters
					.getMatchScoreThresold());
		} else {
			matchScoreThresold = Integer.parseInt(matchScoreThresDef);
		}
		LOG.debug("Setting MatchScoreThreshold: " + matchScoreThresold);
		if (!Util.isNullOrEmpty(parameters.getRecordCountThresold())) {
			recordCountThresold = Integer.parseInt(parameters
					.getRecordCountThresold());
		} else {
			recordCountThresold = recCountThresDef;
		}
		LOG.debug("Setting recordCountThresold: " + recordCountThresold);
		ContactSearchCriteriaType contactSearchCriteriaType = parameters
				.getContactSearchCriteria();
		if(!Util.isNullOrEmpty(contactSearchCriteriaType.getEMAILADDRESS())){
			searchRuleSet="Party Person Fuzzy Search";
		}else{
		searchRuleSet = "Party Person Fuzzy Ruleset Person Email";
		}
		
		matchType = MatchType.BOTH;
		SiperianClient siperianClient = null;

		SearchMatchRequest searchMatchRequest = null;
		SearchMatchResponse searchMatchResponse = null;
		searchMatchRequest = new SearchMatchRequest();
		searchMatchRequest.setRecordsToReturn(recordCountThresold);

		searchMatchRequest
				.setSiperianObjectUid("BASE_OBJECT.C_B_PARTY_PERSON");
		searchMatchRequest.setMatchRuleSetUid(SiperianObjectType.MATCH_RULE_SET
				.makeUid(searchRuleSet));// searchRuleSet,ruleSetName
		searchMatchRequest.setMatchType(matchType);

		LOG.info("Match Rule Set: " + searchMatchRequest.getMatchRuleSetUid());
		LOG.info("Match Type :" + searchMatchRequest.getMatchType());
		LOG.info("PKG::" + searchMatchRequest.getSiperianObjectUid());

		Field perName = new Field("Person_Name");
		StringBuilder perNameConcat = new StringBuilder();
		if (!Util.isNullOrEmpty(contactSearchCriteriaType.getFIRSTNAME())) {
			perNameConcat.append(contactSearchCriteriaType.getFIRSTNAME());
		}
		if (!Util.isNullOrEmpty(contactSearchCriteriaType.getLASTNAME())) {
			perNameConcat.append(" ");
			perNameConcat.append(contactSearchCriteriaType.getLASTNAME());

		}
		if (perNameConcat != null && perNameConcat.length() > 0) {
			perName.setStringValue(perNameConcat.toString());
			searchMatchRequest.addMatchColumnField(perName);
		}
		LOG.info("Field to search for :" + perName.getName() + ':'
				+ perName.getStringValue());


		Field emailAdd = new Field("Ex_Comm_Value");
		StringBuilder emailConcat = new StringBuilder();
		Field exCommType= new Field("Ex_Comm_Type");
		String type= "Email";
		if (!Util.isNullOrEmpty(contactSearchCriteriaType.getEMAILADDRESS())) {
			emailConcat.append(contactSearchCriteriaType.getEMAILADDRESS());
		}
		if (emailConcat != null && emailConcat.length() > 0) {
			emailAdd.setStringValue(emailConcat.toString());
			exCommType.setStringValue(type);
			searchMatchRequest.addMatchColumnField(emailAdd);
			searchMatchRequest.addMatchColumnField(exCommType);
		}

		LOG.info("Field to search for :" + emailAdd.getName() + ':'
				+ emailAdd.getStringValue());
		ArrayList matchColumField = searchMatchRequest.getMatchColumnFields();
		for (Object obj : matchColumField) {
			LOG.info("matchColumField" + obj.toString());
		}
	
		try {
			siperianClient = (SiperianClient) checkOut();

			LOG.info("processing SearchMatchRequest");
			// Util.printObjectTreeInXML(SearchMatchRequest.class,searchMatchRequest);
			LOG.info("before request");
			searchMatchResponse = (SearchMatchResponse) siperianClient
					.process(searchMatchRequest);
			LOG.info("after response");
		} catch (SiperianServerException sifExcp) {
			LOG.error("SiperianServerException occured while processing SearchMatchRequest: "
					+ sifExcp);
			LOG.error("Get Message: " + sifExcp.getMessage());
			ServiceProcessingException customException = new ServiceProcessingException(
					sifExcp.getMessage());
			customException.setRootExceptionMsg(sifExcp
					+ " SearchMatch operation failed for Person_Name: "
					+ contactSearchCriteriaType.getFIRSTNAME());
			searchContactResponse.setErrorMsg(customException
					.getRootExceptionMsg());
			customException
					.setMessage("SIF exception occured while processing SearchMatch request for Party. ");
			throw customException;
		} catch (Exception exp) {
			LOG.error("Exception occured while processing SearchMatchRequest: "
					+ exp);
			LOG.error("SearchMatch Exeption :" + exp.getMessage());
			ServiceProcessingException customException = new ServiceProcessingException(
					exp);
			customException.setRootExceptionMsg(exp
					+ " SearchMatch operation failed for Person_Name: "
					+ contactSearchCriteriaType.getFIRSTNAME());
			searchContactResponse.setErrorMsg(customException
					.getRootExceptionMsg());
			customException
					.setMessage("SIF exception occured while processing SearchMatch request for Party.");
			throw customException;
		} finally {
			checkIn(siperianClient);
		}

	
		return searchMatchResponse;
	
	
	}
	
	

	private SearchContactResponse performAccountFuzzySearch(
			SearchContactRequest parameters) throws ServiceProcessingException {
		LOG.debug("Inside  performAccountFuzzySearch method.. ");
		SearchContactResponse searchContactResponse= new SearchContactResponse();
		//code goes here
		String searchRuleSet= null;
		String searchType = null;
		MatchType matchType = null;
		//String countryName=null;
		int recordCountThresold= 0;
		int matchScoreThresold= 0;

		if(!Util.isNullOrEmpty(parameters.getSearchType()))	{
			searchType = parameters.getSearchType();
		}
		LOG.debug("Search Type:: " + searchType);
		if(!Util.isNullOrEmpty(parameters.getMatchScoreThresold())){
			matchScoreThresold=Integer.parseInt(parameters.getMatchScoreThresold());
		}else{
			matchScoreThresold=Integer.parseInt(matchScoreThresDef);
		}
		LOG.debug("Setting MatchScoreThreshold: " + matchScoreThresold);
		if(!Util.isNullOrEmpty(parameters.getRecordCountThresold())){
			recordCountThresold= Integer.parseInt(parameters.getRecordCountThresold());
		}else{
			recordCountThresold=recCountThresDef;
		}
		LOG.debug("Setting recordCountThresold: " + recordCountThresold);
		ContactSearchCriteriaType contactSearchCriteriaType= parameters.getContactSearchCriteria();
		/*if(!Util.isNullOrEmpty(contactSearchCriteriaType.getCOUNTRYCD())){
			LOG.debug("Country Cd :: "+contactSearchCriteriaType.getCOUNTRYCD() );
			countryName= getCL_SIP_POP(contactSearchCriteriaType.getCOUNTRYCD());
			LOG.debug("Country Name :: "+ countryName);;
			
		}*/
		searchRuleSet = "Account Fuzzy Ruleset";
		matchType = MatchType.BOTH;
		SiperianClient siperianClient = null;

		SearchMatchRequest searchMatchRequest = null;
		SearchMatchResponse searchMatchResponse = null;


		searchMatchRequest = new SearchMatchRequest();
		searchMatchRequest.setRecordsToReturn(recordCountThresold);
		
		searchMatchRequest.setSiperianObjectUid("BASE_OBJECT.C_B_ACCOUNT");
		searchMatchRequest.setMatchRuleSetUid(SiperianObjectType.MATCH_RULE_SET.makeUid(searchRuleSet));//searchRuleSet,ruleSetName
		searchMatchRequest.setMatchType(matchType);

		LOG.info("Match Rule Set: " + searchMatchRequest.getMatchRuleSetUid());
		LOG.info("Match Type :" + searchMatchRequest.getMatchType());
		LOG.info("SiperianObjectUid : "+ searchMatchRequest.getSiperianObjectUid());
		Field orgName = new Field("Organization_Name");
				StringBuilder orgNameConcat = new StringBuilder();
				if (!Util.isNullOrEmpty(contactSearchCriteriaType.getACCOUNTNAME())) {
					orgNameConcat.append(contactSearchCriteriaType.getACCOUNTNAME());
				}
				if(orgNameConcat != null && orgNameConcat.length() > 0){
					orgName.setStringValue(orgNameConcat.toString());
					searchMatchRequest.addMatchColumnField(orgName);
				}
				/*Field exEntityType = new Field("Ex_Entity_Type");	
				exEntityType.setStringValue("Organization");
				searchMatchRequest.addMatchColumnField(exEntityType);
				
				// Adding SIP_POP
				Field field_SIPPOP = new Field("SIP_POP");
				field_SIPPOP.setStringValue(countryName);// sipPopVal
				searchMatchRequest.addMatchColumnField(field_SIPPOP);
				LOG.info("Field to match for :" + field_SIPPOP.getName() + ':'
						+ field_SIPPOP.getStringValue());
				
				ArrayList matchColumField= searchMatchRequest.getMatchColumnFields();
				for(Object obj:matchColumField){
				LOG.info( "matchColumField"+obj.toString());
				}
				StringBuffer criteria = new StringBuffer();
				boolean firstParam = false;
				//Fetching Active Records from Search
				if (firstParam) {
					criteria.append(" AND STATUS_CD ='" + "A" + "'");
				} else {
					firstParam = true;
					criteria.append(" STATUS_CD ='" + "A" + "'");
				}

				LOG.info("Filter Criteria: " + criteria.toString());

				searchMatchRequest.setFilterCriteria(criteria.toString());
				LOG.info("get Filter Criteria : " + searchMatchRequest.getFilterCriteria());*/
				try {
					siperianClient = (SiperianClient) checkOut();

					LOG.info("processing SearchMatchRequest  ");
				//	Util.printObjectTreeInXML(SearchMatchRequest.class,searchMatchRequest);
					LOG.info("before request");
					long startTime=System.currentTimeMillis();
					searchMatchResponse = (SearchMatchResponse) siperianClient.process(searchMatchRequest);
					long endTime=System.currentTimeMillis();
					LOG.info("Total Time in account ruleset seacrh response  -------:"+(endTime-startTime) ); 
					LOG.info("after response");
				} catch (SiperianServerException sifExcp) {
					LOG.error("SiperianServerException occured while processing SearchMatchRequest: " + sifExcp);
					LOG.error("Get Message: "+ sifExcp.getMessage());
					ServiceProcessingException customException = new ServiceProcessingException(sifExcp.getMessage());
					customException.setRootExceptionMsg(sifExcp + " SearchMatch operation failed for Organization_Name: "+ contactSearchCriteriaType.getACCOUNTNAME());
					searchContactResponse.setErrorMsg(customException.getRootExceptionMsg());
					customException.setMessage("SIF exception occured while processing SearchMatch request for Party. ");
					throw customException;
				} catch (Exception exp) {
					LOG.error("Exception occured while processing SearchMatchRequest: " + exp);
					LOG.error("SearchMatch Exeption :" + exp.getMessage());
					ServiceProcessingException customException = new ServiceProcessingException(exp);
					customException.setRootExceptionMsg(exp + " SearchMatch operation failed for Organization_Name: "+ contactSearchCriteriaType.getACCOUNTNAME());
					searchContactResponse.setErrorMsg(customException.getRootExceptionMsg());
					customException.setMessage("SIF exception occured while processing SearchMatch request for Party.");
					throw customException;
				} finally {
					checkIn(siperianClient);
				}
				
				if (searchMatchResponse != null
						&& searchMatchResponse.getRecords().size() > 0) {
					LOG.info("SearchMatchResponse rec cnt="	+ searchMatchResponse.getRecords().size());
					
					searchContactResponse = buildReponseForAccountSearch (searchMatchResponse,parameters,matchScoreThresold);
				}else{
					LOG.info("no records from match response");
					searchContactResponse.setErrorMsg("No Record Found");
				}

		return searchContactResponse;
	
	}



	private SearchContactResponse performContactFuzzySearch(
			SearchContactRequest parameters) throws ServiceProcessingException {
		LOG.debug("Inside  performContactFuzzySearch method.. ");
		SearchContactResponse searchContactResponse = new SearchContactResponse();
		// code goes here
		String searchRuleSet = null;
		String searchType = null;
		MatchType matchType = null;
		int recordCountThresold = 0;
		int matchScoreThresold = 0;
		
		if (!Util.isNullOrEmpty(parameters.getSearchType())) {
			searchType = parameters.getSearchType();
		}
		LOG.debug("Search Type:: " + searchType);
		if (!Util.isNullOrEmpty(parameters.getMatchScoreThresold())) {
			matchScoreThresold = Integer.parseInt(parameters
					.getMatchScoreThresold());
		} else {
			matchScoreThresold = Integer.parseInt(matchScoreThresDef);
		}
		LOG.debug("Setting MatchScoreThreshold: " + matchScoreThresold);
		if (!Util.isNullOrEmpty(parameters.getRecordCountThresold())) {
			recordCountThresold = Integer.parseInt(parameters
					.getRecordCountThresold());
		} else {
			recordCountThresold = recCountThresDef;
		}
		LOG.debug("Setting recordCountThresold: " + recordCountThresold);
		ContactSearchCriteriaType contactSearchCriteriaType = parameters
				.getContactSearchCriteria();

		if(!Util.isNullOrEmpty(contactSearchCriteriaType.getEMAILADDRESS())){
			searchRuleSet="Party Person Fuzzy Search";
		}else{
		searchRuleSet = "Party Person Fuzzy Ruleset Person Email";
		}
		
		matchType = MatchType.BOTH;
		SiperianClient siperianClient = null;

		SearchMatchRequest searchMatchRequest = null;
		SearchMatchResponse searchMatchResponse = null;
		searchMatchRequest = new SearchMatchRequest();
		searchMatchRequest.setRecordsToReturn(recordCountThresold);

		searchMatchRequest
				.setSiperianObjectUid("BASE_OBJECT.C_B_PARTY_PERSON");
		searchMatchRequest.setMatchRuleSetUid(SiperianObjectType.MATCH_RULE_SET
				.makeUid(searchRuleSet));// searchRuleSet,ruleSetName
		searchMatchRequest.setMatchType(matchType);

		LOG.info("Match Rule Set: " + searchMatchRequest.getMatchRuleSetUid());
		LOG.info("Match Type :" + searchMatchRequest.getMatchType());
		LOG.info("PKG::" + searchMatchRequest.getSiperianObjectUid());

		Field perName = new Field("Person_Name");
		StringBuilder perNameConcat = new StringBuilder();
		if (!Util.isNullOrEmpty(contactSearchCriteriaType.getFIRSTNAME())) {
			perNameConcat.append(contactSearchCriteriaType.getFIRSTNAME());
		}
		if (!Util.isNullOrEmpty(contactSearchCriteriaType.getLASTNAME())) {
			perNameConcat.append(" ");
			perNameConcat.append(contactSearchCriteriaType.getLASTNAME());

		}
		if (perNameConcat != null && perNameConcat.length() > 0) {
			perName.setStringValue(perNameConcat.toString());
			searchMatchRequest.addMatchColumnField(perName);
		}
		LOG.info("Field to search for :" + perName.getName() + ':'
				+ perName.getStringValue());


		Field emailAdd = new Field("Ex_Comm_Value");
		StringBuilder emailConcat = new StringBuilder();
		Field exCommType= new Field("Ex_Comm_Type");
		String type= "Email";
		if (!Util.isNullOrEmpty(contactSearchCriteriaType.getEMAILADDRESS())) {
			emailConcat.append(contactSearchCriteriaType.getEMAILADDRESS());
		}
		if (emailConcat != null && emailConcat.length() > 0) {
			emailAdd.setStringValue(emailConcat.toString());
			exCommType.setStringValue(type);
			searchMatchRequest.addMatchColumnField(emailAdd);
			searchMatchRequest.addMatchColumnField(exCommType);
		}

		LOG.info("Field to search for :" + emailAdd.getName() + ':'
				+ emailAdd.getStringValue());
		ArrayList matchColumField = searchMatchRequest.getMatchColumnFields();
		for (Object obj : matchColumField) {
			LOG.info("matchColumField" + obj.toString());
		}
		
		try {
			siperianClient = (SiperianClient) checkOut();

			LOG.info("processing SearchMatchRequest");
			// Util.printObjectTreeInXML(SearchMatchRequest.class,searchMatchRequest);
			LOG.info("before request");
			long startTime=System.currentTimeMillis();
			searchMatchResponse = (SearchMatchResponse) siperianClient
					.process(searchMatchRequest);
			long endTime=System.currentTimeMillis();
			LOG.info("Total Time in contact ruleset on Person response -------:"+(endTime-startTime) ); 
			LOG.info("after response");
		} catch (SiperianServerException sifExcp) {
			LOG.error("SiperianServerException occured while processing SearchMatchRequest: "
					+ sifExcp);
			LOG.error("Get Message: " + sifExcp.getMessage());
			ServiceProcessingException customException = new ServiceProcessingException(
					sifExcp.getMessage());
			customException.setRootExceptionMsg(sifExcp
					+ " SearchMatch operation failed for Person_Name: "
					+ contactSearchCriteriaType.getFIRSTNAME());
			searchContactResponse.setErrorMsg(customException
					.getRootExceptionMsg());
			customException
					.setMessage("SIF exception occured while processing SearchMatch request for Party. ");
			throw customException;
		} catch (Exception exp) {
			LOG.error("Exception occured while processing SearchMatchRequest: "
					+ exp);
			LOG.error("SearchMatch Exeption :" + exp.getMessage());
			ServiceProcessingException customException = new ServiceProcessingException(
					exp);
			customException.setRootExceptionMsg(exp
					+ " SearchMatch operation failed for Person_Name: "
					+ contactSearchCriteriaType.getFIRSTNAME());
			searchContactResponse.setErrorMsg(customException
					.getRootExceptionMsg());
			customException
					.setMessage("SIF exception occured while processing SearchMatch request for Party.");
			throw customException;
		} finally {
			checkIn(siperianClient);
		}

		if (searchMatchResponse != null
				&& searchMatchResponse.getRecords().size() > 0) {
			LOG.info("SearchMatchResponse rec cnt="
					+ searchMatchResponse.getRecords().size());
			searchContactResponse=buildReponseForContactSearch(searchMatchResponse,parameters,matchScoreThresold);
			
		} else {
			LOG.info("no records from match response");
			searchContactResponse.setErrorMsg(Constant.noRecordFound);
		}

		return searchContactResponse;
	}


	private SearchContactResponse buildReponseForContactSearch(
			SearchMatchResponse searchMatchResponse,
			SearchContactRequest parameters, int matchScoreThresold)  throws ServiceProcessingException  {

		LOG.info("inside buildReponseForAccountSearch");
		SearchContactResponse searchContactResponse= new SearchContactResponse();
		int matchScore=0;
		List<String> rowidParty= new ArrayList<String>();
		List searchRecords = searchMatchResponse.getRecords();
		if (searchRecords != null && searchRecords.size() != 0) {
			LOG.info("inside searchRecords != null && searchRecords.size() != 0");
			for (Iterator iter = searchRecords.iterator(); iter
					.hasNext();) {
				Record record = (Record) iter.next();
				String rowId=null;
				
				if(record.getField("MATCH_SCORE") != null && record.getField("MATCH_SCORE").getStringValue()!= null ){
					//LOG.info("match score ::"+Integer.parseInt(record.getField("MATCH_SCORE").getStringValue().trim()));
					matchScore=Integer.parseInt(record.getField("MATCH_SCORE").getStringValue().trim());
					}
				if(record.getField("ROWID_OBJECT") != null &&  record.getField("ROWID_OBJECT").getStringValue()!= null){
					//LOG.info("inside ROWID_OBJECT != null");
					rowId=record.getField("ROWID_OBJECT").getStringValue().trim();
				
					//LOG.info("rowid from search :" +rowId);
					if(matchScore >=matchScoreThresold ){
					recordMap.put(rowId, matchScore);
					//LOG.info("ROWID_PARTY "+ record.getField("ROWID_PARTY").getStringValue());
					rowidParty.add(record.getField("ROWID_PARTY").getStringValue());
					}
					
				}
				
			}
			if(recordMap.size() >0 ){
				LOG.info("rowIDList size :: "+ recordMap.size());
				searchContactResponse=	performSearchOnPackageForContact(parameters,matchScore,rowidParty);
				
				
			}else{
				searchContactResponse.setErrorMsg(Constant.noRecordFound);
			}
			
		}
		return searchContactResponse;
	}

	private SearchContactResponse performSearchOnPackageForContact(
			SearchContactRequest parameters, int matchScore, List<String> rowidParty) throws ServiceProcessingException {


		
		LOG.debug("Inside  performSearchOnPackage method.. ");
		SearchContactResponse searchContactResponse= new SearchContactResponse();
		//code goes here
		Statement statement = null;
		StringBuilder sqlQry = new StringBuilder();
		Connection jdbcConnection = null;
		ResultSet resultSet = null;
		ResultSet resultSet1 = null;
		String email=null;
		int recordCountThresold=0;
		if (!Util.isNullOrEmpty(parameters.getContactSearchCriteria().getEMAILADDRESS())) {
			email= parameters.getContactSearchCriteria().getEMAILADDRESS();
		}
		if (!Util.isNullOrEmpty(parameters.getRecordCountThresold())) {
			recordCountThresold = Integer.parseInt(parameters
					.getRecordCountThresold());
		} else {
			recordCountThresold = recCountThresDef;
		}
		LOG.debug("Setting recordCountThresold: " + recordCountThresold);
		try {

			JDBCConnectionProvider jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
	
			sqlQry.append("(select x.rowid_object from ");
			sqlQry.append("(select c.rowid_object, row_number() over (partition by c.rowid_party_2 order by c.create_date desc) rn ");
			sqlQry.append("from c_b_party_rel c ,c_b_party p  ");
			sqlQry.append("where c.rowid_party_2 in( ");
			for (String party : rowidParty) {
				sqlQry.append("'" + party.trim() + "',");
			}
			sqlQry.deleteCharAt(sqlQry.length() - 1).toString();
			sqlQry.append(" ) and c.hub_state_ind = 1 ");
			sqlQry.append("and c.rowid_hierarchy = '4' ");
			sqlQry.append("and c.rowid_rel_type = '25' and p.PARTY_TYPE ='Customer' and c.ROWID_PARTY=p.ROWID_OBJECT) x where x.rn = 1)");
			LOG.debug("Query to fetch records: " + sqlQry);
			
			jdbcConnection = jDBCConnectionProvider.getJdbcConnectionFromDS();
			statement = jdbcConnection.createStatement();
			long startTime=System.currentTimeMillis();
			resultSet = statement.executeQuery(sqlQry.toString());
			long endTime=System.currentTimeMillis();
			LOG.info("Total Time in Querying latest contact on c b party response  -------:"+(endTime-startTime) ); 
			List<String> relRowIdList= new ArrayList<String>();
			while (resultSet.next()) {
				
				String relRowid= resultSet.getString("rowid_object");
				relRowIdList.add(relRowid);
			}
			if(relRowIdList.size()>0){
			StringBuilder sqlQry1 = new StringBuilder();
			sqlQry1.append("select * from pkg_contact_fuzzy_search where REL_ROWID in ( ");
			for (String relRowId : relRowIdList) {
				sqlQry1.append("'" + relRowId.trim() + "',");
			}
			sqlQry1.deleteCharAt(sqlQry1.length() - 1).toString();
			sqlQry1.append(" ) and ROWID_OBJECT in (");
			for (String contctRowId : recordMap.keySet()) {
				sqlQry1.append("'" + contctRowId.trim() + "',");
				
			}
			sqlQry1.deleteCharAt(sqlQry1.length() - 1).toString();
			sqlQry1.append(") AND  rownum <= ");
			sqlQry1.append(recordCountThresold);
			/*if(email != null){
				sqlQry1.append(" and COMM_VALUE like ('%" +email +"%')" );
			}*/
			LOG.debug("Query to fetch records: " + sqlQry1);
			long startTimeforPkgQuery=System.currentTimeMillis();
			resultSet1 = statement.executeQuery(sqlQry1.toString());
			long endTimeforPkgQuery=System.currentTimeMillis();
			LOG.info("Total Time in Pkg query  response  -------:"+(endTimeforPkgQuery-startTimeforPkgQuery) ); 
			
			long startTimeforBuildingRes=System.currentTimeMillis();
			searchContactResponse= buildResponseforContact(resultSet1);
			long endTimeforBuildingRes=System.currentTimeMillis();
			LOG.info("Total Time in contact search building  response  -------:"+(endTimeforBuildingRes-startTimeforBuildingRes) ); 
			
			}
			else{
				searchContactResponse.setErrorMsg(Constant.noRecordFound);
			}
			
			
			
		} catch (SQLException sqlEx) {
			LOG.error("Exception in getXrefRecforID() for ID based Search: " , sqlEx);
			ServiceProcessingException customException = new ServiceProcessingException(sqlEx);
			customException.setMessage("Failed to fetch Party profile from ORS." + customException.getMessage());
			throw customException;
		}	finally {
			try {
					if( resultSet != null) resultSet.close();
					if( statement != null) statement.close();
					if(jdbcConnection != null) jdbcConnection.close();
				} catch (SQLException e) {

					LOG.debug("Caught SQLException in getXrefRecforID: " , e);
				}
		}

		
		return searchContactResponse;
	
		
	
	}

	private SearchContactResponse buildResponseforContact(ResultSet resultSet) {

		LOG.debug("inside Build Response");
		SearchContactResponse searchContactResponse= new SearchContactResponse();
		Map <String , ContactType> contactTypeMap= new HashMap<String, ContactType>();
		ContactType contactType=  null;
		ContactProfileType contactProfileType= new ContactProfileType();
		boolean bUniqueRec= false;
		try {
			while (resultSet.next()) {
				//LOG.debug("inside resultSet.next() MDMCONTACTID ::" +resultSet.getString("MDM_CONTACT_UCN"));
				String rowIdObj=resultSet.getString("ROWID_OBJECT").trim();
				String acctRowId=resultSet.getString("ACCT_ROWID").trim();
				String key=rowIdObj.concat(acctRowId);
				if(!contactTypeMap.containsKey(key)){
					//LOG.debug("populate contactTypeMap for ROWID_OBJECT : "+key);
					contactTypeMap.put(key, new ContactType());
					bUniqueRec=true;
				}
				contactType= contactTypeMap.get(key);
				if(bUniqueRec){
					//LOG.debug("inside bUniqueRec..");
					
				 Iterator it = recordMap.entrySet().iterator();
				    while (it.hasNext()) {
				    	//LOG.info("inside it.hasNext()");
				        Map.Entry pair = (Map.Entry)it.next();
				       // LOG.info("pair.getKey().toString() ::" +pair.getKey().toString() + "match value:"+pair.getValue());
				        String key1=pair.getKey().toString().trim();
				       // LOG.info("Key :" +key1);
				        String rowIdObject=resultSet.getString("ROWID_OBJECT").trim();
				       // LOG.info("ROWID_OBJECT : "+ rowIdObject);
				        if(rowIdObject.equalsIgnoreCase(key1)){
				        	//LOG.info("inside if block");
				        	contactType.setMatchScore((Integer)pair.getValue());
				        }
				        
				    }
				contactType.setMDMCONTACTID(resultSet.getString("MDM_CONTACT_UCN"));
				contactType.setFIRSTNAME(resultSet.getString("FIRST_NAME"));
				contactType.setLASTNAME(resultSet.getString("LAST_NAME"));
				contactType.setEMAILADDRESS(resultSet.getString("COMM_VALUE"));
				contactType.setACCOUNTUCN(resultSet.getString("ACCOUNT_UCN"));
				contactType.setACCOUNTNAME(resultSet.getString("ACCOUNT_NAME"));
				contactProfileType.getContact().add(contactType);
				}
				bUniqueRec=false;
			}
			if(contactProfileType.getContact()!= null && contactProfileType.getContact().size()>0){
				LOG.info("contactProfileType size::" + contactProfileType.getContact().size());
				searchContactResponse.setStatus(Constant.SUCCESS);
				searchContactResponse.setContactProfiles(contactProfileType);
				
				}
				else{
					
					searchContactResponse.setErrorMsg(Constant.noRecordFound);
				}
				
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return searchContactResponse;
	
	}

	private SearchContactResponse buildResponseContactLikeSearch (
			ResultSet resultSet) throws ServiceProcessingException {

		LOG.debug("inside Build Response");
		SearchContactResponse searchContactResponse = new SearchContactResponse();
		ContactProfileType contactProfileType = new ContactProfileType();
		Map <String , ContactType> contactTypeMap= new HashMap<String, ContactType>();
		ContactType contactType= null;
		boolean bUniqueRec= false;
		try {
			while (resultSet.next()) {
				LOG.debug("inside resultSet.next() MDMCONTACTID ::"
						+ resultSet.getString("MDM_CONTACT_UCN"));
				String rowIdObj=resultSet.getString("ROWID_OBJECT").trim();
				String acctRowId=resultSet.getString("ACCT_ROWID").trim();
				String key=rowIdObj.concat(acctRowId);
				if(!contactTypeMap.containsKey(key)){
					LOG.debug("populate contactTypeMap for ROWID_OBJECT : "+key);
					contactTypeMap.put(key, new ContactType());
					bUniqueRec=true;
				}
				contactType= contactTypeMap.get(key);
				if(bUniqueRec){
				LOG.debug("inside bUniqueRec..");
/*				 Iterator it = recordMap.entrySet().iterator();
				    while (it.hasNext()) {
				    	LOG.info("inside it.hasNext()");
				        Map.Entry pair = (Map.Entry)it.next();
				        LOG.info("pair.getKey().toString() ::" +pair.getKey().toString() + "match value:"+pair.getValue());
				        String key1=pair.getKey().toString().trim();
				        LOG.info("Key :" +key1);
				        String rowIdObject=resultSet.getString("ROWID_OBJECT").trim();
				        LOG.info("ROWID_OBJECT : "+ rowIdObject);
				        if(rowIdObject.equalsIgnoreCase(key1)){
				        	LOG.info("inside if block");
				        	contactType.setMatchScore((Integer)pair.getValue());
				        }
				        
				    }*/

				contactType.setMDMCONTACTID(resultSet
						.getString("MDM_CONTACT_UCN"));
				contactType.setFIRSTNAME(resultSet.getString("FIRST_NAME"));
				contactType.setLASTNAME(resultSet.getString("LAST_NAME"));
				contactType.setEMAILADDRESS(resultSet.getString("COMM_VALUE"));
				contactType.setACCOUNTUCN(resultSet.getString("ACCOUNT_UCN"));
				contactType.setACCOUNTNAME(resultSet.getString("ACCOUNT_NAME"));
				contactProfileType.getContact().add(contactType);
				}
				bUniqueRec=false;
			}
			if (contactProfileType.getContact() != null
					&& contactProfileType.getContact().size() > 0) {
				LOG.info("contactProfileType size::"
						+ contactProfileType.getContact().size());
				searchContactResponse.setStatus(Constant.SUCCESS);
				searchContactResponse.setContactProfiles(contactProfileType);
				
			} else {
				
				searchContactResponse.setErrorMsg(Constant.noRecordFound);
			}

		} catch (SQLException e) {

			e.printStackTrace();
		}
		return searchContactResponse;

	}
	private SearchContactResponse buildResponse(ResultSet resultSet, SearchContactRequest parameters) throws ServiceProcessingException{
		LOG.debug("inside Build Response");
		SearchContactResponse searchContactResponse= new SearchContactResponse();
		Map <String , ContactType> contactTypeMap= new HashMap<String, ContactType>();
		ContactType contactType=null;
		ContactProfileType contactProfileType= new ContactProfileType();
		boolean bUniqueRec= false;
		SearchMatchResponse searchMatchResponse=null;
		List<String> rowidFromEmailSearchList= null;
		String email=null;
		if (!Util.isNullOrEmpty(parameters.getContactSearchCriteria().getEMAILADDRESS())) {
			email= parameters.getContactSearchCriteria().getEMAILADDRESS();
		}
		if (email != null) {
			searchMatchResponse = new SearchMatchResponse();
			rowidFromEmailSearchList = new ArrayList<String>();
			searchMatchResponse = performOnlyEmailSearch(parameters);
			if (searchMatchResponse != null
					&& searchMatchResponse.getRecords().size() > 0) {
				LOG.info("SearchMatchResponse rec cnt="
						+ searchMatchResponse.getRecords().size());
				List searchRecords = searchMatchResponse.getRecords();
				if (searchRecords != null && searchRecords.size() != 0) {
					LOG.info("inside searchRecords != null && searchRecords.size() != 0");
					for (Iterator iter = searchRecords.iterator(); iter
							.hasNext();) {
						Record record = (Record) iter.next();
						String rowId = null;

						if (record.getField("ROWID_OBJECT") != null
								&& record.getField("ROWID_OBJECT")
										.getStringValue() != null) {
							//LOG.info("inside ROWID_OBJECT != null");
							rowId = record.getField("ROWID_OBJECT")
									.getStringValue().trim();
							LOG.info("ROWID_OBJECT from Email Rule set :: "+rowId);
							rowidFromEmailSearchList.add(rowId);

						}

					}
				}
			}
			if(rowidFromEmailSearchList != null && rowidFromEmailSearchList.size()>0){
				
				try {
					while (resultSet.next()) {
						//LOG.debug("inside resultSet.next() MDMCONTACTID ::" +resultSet.getString("MDM_CONTACT_UCN"));
						String rowIdObject=resultSet.getString("ROWID_OBJECT").trim();
						LOG.info("RowidObject from Account search ::" + rowIdObject);
						if(rowidFromEmailSearchList.contains(rowIdObject)){
						//String rowIdObject=resultSet.getString("ROWID_OBJECT").trim();
						String acctRowId=resultSet.getString("ACCT_ROWID").trim();
						String key=rowIdObject.concat(acctRowId);
						if(!contactTypeMap.containsKey(key)){
							LOG.debug("populate contactTypeMap for ROWID_OBJECT : "+key);
							contactTypeMap.put(key, new ContactType());
							bUniqueRec=true;
						}
						contactType= contactTypeMap.get(key);
						if(bUniqueRec){
						//	LOG.debug("inside bUniqueRec..");
							//ContactType contactType= new ContactType();
						 Iterator it = recordMap.entrySet().iterator();
						    while (it.hasNext()) {
						    	//LOG.info("inside it.hasNext()");
						        Map.Entry pair = (Map.Entry)it.next();
						      //  LOG.info("pair.getKey().toString() ::" +pair.getKey().toString() + "match value:"+pair.getValue().toString());
						        String key1=pair.getKey().toString().trim();
						   
						      //  LOG.info("Key :" +key1);
						        String acctRowID=resultSet.getString("ACCT_ROWID").trim();
						    //    LOG.info("ACCT_ROWID : "+ acctRowID);
						        if(acctRowID.equalsIgnoreCase(key1)){
						        //	LOG.info("inside if block");
						        	contactType.setMatchScore((Integer)pair.getValue());
						        }
						        
						    }
						contactType.setMDMCONTACTID(resultSet.getString("MDM_CONTACT_UCN"));
						contactType.setFIRSTNAME(resultSet.getString("FIRST_NAME"));
						contactType.setLASTNAME(resultSet.getString("LAST_NAME"));
						contactType.setEMAILADDRESS(resultSet.getString("COMM_VALUE"));
						contactType.setACCOUNTUCN(resultSet.getString("ACCOUNT_UCN"));
						contactType.setACCOUNTNAME(resultSet.getString("ACCOUNT_NAME"));
						contactProfileType.getContact().add(contactType);
						}
					}
						bUniqueRec=false;
					}
					if(contactProfileType.getContact()!= null && contactProfileType.getContact().size()>0){
						LOG.info("contactProfileType size::" + contactProfileType.getContact().size());
						searchContactResponse.setStatus(Constant.SUCCESS);
						searchContactResponse.setContactProfiles(contactProfileType);
						
						}
						else{
							
							searchContactResponse.setErrorMsg(Constant.noRecordFound);
						}
						
				} catch (SQLException e) {
					LOG.debug(e);
					e.printStackTrace();
				}
				
			}else{
				searchContactResponse.setErrorMsg(Constant.noRecordFound);
			}
		}else{
			callBuildresponseForAcc(resultSet, searchContactResponse,
					contactTypeMap, contactProfileType, bUniqueRec);
		}
		
		
		return searchContactResponse;
	}

	private void callBuildresponseForAcc(ResultSet resultSet,
			SearchContactResponse searchContactResponse,
			Map<String, ContactType> contactTypeMap,
			ContactProfileType contactProfileType, boolean bUniqueRec) {
		ContactType contactType;
		try {
			while (resultSet.next()) {
				//LOG.debug("inside resultSet.next() MDMCONTACTID ::" +resultSet.getString("MDM_CONTACT_UCN"));
				String rowIdObject=resultSet.getString("ROWID_OBJECT").trim();
				String acctRowId=resultSet.getString("ACCT_ROWID").trim();
				String key=rowIdObject.concat(acctRowId);
				if(!contactTypeMap.containsKey(key)){
				//	LOG.debug("populate contactTypeMap for ROWID_OBJECT : "+key);
					contactTypeMap.put(key, new ContactType());
					bUniqueRec=true;
				}
				contactType= contactTypeMap.get(key);
				if(bUniqueRec){
					//LOG.debug("inside bUniqueRec..");
					//ContactType contactType= new ContactType();
				 Iterator it = recordMap.entrySet().iterator();
				    while (it.hasNext()) {
				    	//LOG.info("inside it.hasNext()");
				        Map.Entry pair = (Map.Entry)it.next();
				      //  LOG.info("pair.getKey().toString() ::" +pair.getKey().toString() + "match value:"+pair.getValue().toString());
				        String key1=pair.getKey().toString().trim();
				   
				     //   LOG.info("Key :" +key1);
				        String acctRowID=resultSet.getString("ACCT_ROWID").trim();
				      //  LOG.info("ACCT_ROWID : "+ acctRowID);
				        if(acctRowID.equalsIgnoreCase(key1)){
				        	//LOG.info("inside if block");
				        	contactType.setMatchScore((Integer)pair.getValue());
				        }
				        
				    }
				contactType.setMDMCONTACTID(resultSet.getString("MDM_CONTACT_UCN"));
				contactType.setFIRSTNAME(resultSet.getString("FIRST_NAME"));
				contactType.setLASTNAME(resultSet.getString("LAST_NAME"));
				contactType.setEMAILADDRESS(resultSet.getString("COMM_VALUE"));
				contactType.setACCOUNTUCN(resultSet.getString("ACCOUNT_UCN"));
				contactType.setACCOUNTNAME(resultSet.getString("ACCOUNT_NAME"));
				contactProfileType.getContact().add(contactType);
				}
				bUniqueRec=false;
			}
			if(contactProfileType.getContact()!= null && contactProfileType.getContact().size()>0){
				LOG.info("contactProfileType size::" + contactProfileType.getContact().size());
				searchContactResponse.setStatus(Constant.SUCCESS);
				searchContactResponse.setContactProfiles(contactProfileType);
				
				}
				else{
					
					searchContactResponse.setErrorMsg(Constant.noRecordFound);
				}
				
		} catch (SQLException e) {
			LOG.debug(e);
			e.printStackTrace();
		}
	}
	private SearchContactResponse buildReponseForAccountSearch(
			SearchMatchResponse searchMatchResponse, SearchContactRequest parameters, int matchScoreThresold) throws ServiceProcessingException {
		LOG.info("inside buildReponseForAccountSearch");
		SearchContactResponse searchContactResponse= new SearchContactResponse();
		int matchScore=0;
		List searchRecords = searchMatchResponse.getRecords();
		if (searchRecords != null && searchRecords.size() != 0) {
			//LOG.info("inside searchRecords != null && searchRecords.size() != 0");
			for (Iterator iter = searchRecords.iterator(); iter
					.hasNext();) {
				Record record = (Record) iter.next();
				String rowId=null;
				
				if(record.getField("MATCH_SCORE") != null && record.getField("MATCH_SCORE").getStringValue()!= null ){
				//	LOG.info("match score ::"+Integer.parseInt(record.getField("MATCH_SCORE").getStringValue().trim()));
					matchScore=Integer.parseInt(record.getField("MATCH_SCORE").getStringValue().trim());
					}
				if(record.getField("ROWID_PARTY") != null &&  record.getField("ROWID_PARTY").getStringValue()!= null){
				//	LOG.info("inside ROWID_PARTY != null");
					rowId=record.getField("ROWID_PARTY").getStringValue().trim();
					//LOG.info("rowid from search :" +rowId);
					if(matchScore >=matchScoreThresold ){
					recordMap.put(rowId, matchScore);
					}
					
				}
				
				
			}
			if(recordMap.size() >0 ){
				LOG.info("rowIDList size :: "+ recordMap.size());
				searchContactResponse=	performSearchOnPackage(parameters,matchScore);
				
				
			}else{
				searchContactResponse.setErrorMsg(Constant.noRecordFound);
			}
		}
		return searchContactResponse;
	}

	private SearchContactResponse performSearchOnPackage(SearchContactRequest parameters, int matchScore) throws ServiceProcessingException {

		
		LOG.debug("Inside  performSearchOnPackage method.. ");
		SearchContactResponse searchContactResponse= new SearchContactResponse();
		//code goes here
		Statement statement = null;
		//StringBuilder sqlQry = new StringBuilder();
		Connection jdbcConnection = null;
		ResultSet resultSet = null;
		ResultSet resultSet1 = null;
		int recordCountThresold=0;
		if (!Util.isNullOrEmpty(parameters.getRecordCountThresold())) {
			recordCountThresold = Integer.parseInt(parameters
					.getRecordCountThresold());
		} else {
			recordCountThresold = recCountThresDef;
		}
	/*	String email=null;
		if (!Util.isNullOrEmpty(parameters.getContactSearchCriteria().getEMAILADDRESS())) {
			email= parameters.getContactSearchCriteria().getEMAILADDRESS();
		}*/
		try {

			JDBCConnectionProvider jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
			
		/*	(select x.rowid_object from
					(select rowid_object, row_number() over (partition by rowid_party_2 order by create_date desc) rn
					from c_b_party_rel 
					where rowid_party_2 in(select rowid_party_2 from c_b_party_rel where rowid_party in ('123') and hub_state_ind = 1 and rowid_hierarchy = '4' and rowid_rel_type = '25')
					and hub_state_ind = 1 
					and rowid_hierarchy = '4'
					and rowid_rel_type = '25') x where x.rn = 1*/


		/*	sqlQry.append("(select x.rowid_object from ");
			sqlQry.append("(select rowid_object, row_number() over (partition by rowid_party_2 order by create_date desc) rn ");
			sqlQry.append("from c_b_party_rel ");
			sqlQry.append("where rowid_party_2 in(select rowid_party_2 from c_b_party_rel where rowid_party in ( ");
			
			for (String contctRowId : recordMap.keySet()) {
				sqlQry.append("'" + contctRowId.trim() + "',");
			}
			sqlQry.deleteCharAt(sqlQry.length() - 1).toString();
			sqlQry.append(") and hub_state_ind = 1 and rowid_hierarchy = '4' and rowid_rel_type = '25') ");
			sqlQry.append("and hub_state_ind = 1 ");
			sqlQry.append("and rowid_hierarchy = '4' ");
			sqlQry.append("and rowid_rel_type = '25') x where x.rn = 1)");
			
			LOG.debug("Query to fetch records: " + sqlQry);*/
			jdbcConnection = jDBCConnectionProvider.getJdbcConnectionFromDS();
			statement = jdbcConnection.createStatement();
			/*long startTime=System.currentTimeMillis();
			resultSet = statement.executeQuery(sqlQry.toString());
			long endTime=System.currentTimeMillis();
			LOG.info("Total Time in  latest account query on c_b_party rel response  -------:"+(endTime-startTime) ); 
			List<String> relRowIdList= new ArrayList<String>();
			while (resultSet.next()) {
				
				String relRowid= resultSet.getString("rowid_object");
				relRowIdList.add(relRowid);
			}
			if(relRowIdList.size()>0){*/
			StringBuilder sqlQry1 = new StringBuilder();
			sqlQry1.append("select * from pkg_contact_fuzzy_search where REL_ROWID in ( ");
			/*for (String relRowId : relRowIdList) {
				sqlQry1.append("'" + relRowId.trim() + "',");
			}
			sqlQry1.deleteCharAt(sqlQry1.length() - 1).toString();*/
			sqlQry1.append("(select x.rowid_object from ");
			sqlQry1.append("(select rowid_object, row_number() over (partition by rowid_party_2 order by create_date desc) rn ");
			sqlQry1.append("from c_b_party_rel ");
			sqlQry1.append("where rowid_party_2 in(select rowid_party_2 from c_b_party_rel where rowid_party in ( ");
			
			for (String contctRowId : recordMap.keySet()) {
				sqlQry1.append("'" + contctRowId.trim() + "',");
			}
			sqlQry1.deleteCharAt(sqlQry1.length() - 1).toString();
			sqlQry1.append(") and hub_state_ind = 1 and rowid_hierarchy = '4' and rowid_rel_type = '25') ");
			sqlQry1.append("and hub_state_ind = 1 ");
			sqlQry1.append("and rowid_hierarchy = '4' ");
			sqlQry1.append("and rowid_rel_type = '25') x where x.rn = 1)");
			
			sqlQry1.append(" ) and acct_rowid in (");
			for (String contctRowId : recordMap.keySet()) {
				sqlQry1.append("'" + contctRowId.trim() + "',");
				
			}
			sqlQry1.deleteCharAt(sqlQry1.length() - 1).toString();
			sqlQry1.append(") AND  rownum <= ");
			sqlQry1.append(recordCountThresold);
			/*if(email != null){
				sqlQry1.append(" and COMM_VALUE like ('%" +email +"%')" );
			}*/
			LOG.debug("Query to fetch records: " + sqlQry1);
			long startTimeforPkgQuery=System.currentTimeMillis();
			resultSet1 = statement.executeQuery(sqlQry1.toString());
			long endTimeforPkgQuery=System.currentTimeMillis();
			LOG.info("Total Time in pkg query for account response  -------:"+(endTimeforPkgQuery-startTimeforPkgQuery) ); 
			
			long startTimeforbuildingres=System.currentTimeMillis();
			searchContactResponse= buildResponse(resultSet1,parameters);
			long endTimeforbuildingres=System.currentTimeMillis();
			LOG.info("Total Time in building res for account response  -------:"+(endTimeforbuildingres-startTimeforbuildingres) ); 
			/*}else{
				searchContactResponse.setErrorMsg(Constant.noRecordFound);
			}*/
			
			
			
		} catch (SQLException sqlEx) {
			LOG.error("Exception in getXrefRecforID() for ID based Search: " , sqlEx);
			ServiceProcessingException customException = new ServiceProcessingException(sqlEx);
			customException.setMessage("Failed to fetch Party profile from ORS." + customException.getMessage());
			throw customException;
		}	finally {
			try {
					if( resultSet != null) resultSet.close();
					if( statement != null) statement.close();
					if(jdbcConnection != null) jdbcConnection.close();
				} catch (SQLException e) {

					LOG.debug("Caught SQLException in getXrefRecforID: " , e);
				}
		}

		
		return searchContactResponse;
	
		
	}
	
	private SearchPartyResponse adbContactFuzzySearch(SearchPartyRequest params) throws ServiceProcessingException{
		long startTime=System.currentTimeMillis();
		perfLog.printLog("Adobe Fuzzy search", "", "Step-2", "Start of adbContactFuzzySearch");
		LOG.debug("Starting  adbContactFuzzySearch method.. ");
		//SearchContactResponse searchContactResponse = new SearchContactResponse();
		// code goes here
		SearchPartyResponse searchPartyResponse=null;
		String searchRuleSet = null;
		String searchType = null;
		MatchType matchType = null;
		int recordCountThresold = 0;
		int matchScoreThresold = 0;
		int minMatchScoreThres = 0;
		Integer recCountThresIp = 0;
		String highestMatchScoreParty="";
		if(!Util.isNullOrEmpty(params.getPartySearchCriteria().getCOUNTRYCD())){
		}
		if(!Util.isNullOrEmpty(params.getSearchType()))	{
			searchType = params.getSearchType();
		}
		
		String matchScoreThresIp = params.getMatchScoreThresold();
	
		LOG.info("Search Type:: " + searchType);
		
		if(matchScoreThresIp != null && matchScoreThresIp.length() > 0)		{
			//Taking User entered value from SearchPartyRequest
			minMatchScoreThres = Integer.parseInt(matchScoreThresIp);
		} else {
			//Taking Default value from Configuration File
			minMatchScoreThres = Integer.parseInt(matchScoreThresDef);
		}
		
		if(recCountThresIp != null && recCountThresIp.intValue() != 0)	{
		} else  {
		}

		LOG.debug("Setting MatchScoreThreshold: " + matchScoreThresold);
		
			recordCountThresold = recCountThresDef;
		
		LOG.debug("Setting recordCountThresold: " + recordCountThresold);
		
			searchRuleSet="Party Person Fuzzy Rule Set New";
		
		
		matchType = MatchType.BOTH;
		SiperianClient siperianClient = null;

		SearchMatchRequest searchMatchRequest = null;
		SearchMatchResponse searchMatchResponse = null;
		searchMatchRequest = new SearchMatchRequest();
		searchMatchRequest.setRecordsToReturn(recordCountThresold);

		searchMatchRequest
				.setSiperianObjectUid("PKG_BO_PERSON_SEARCH");
		searchMatchRequest.setMatchRuleSetUid(SiperianObjectType.MATCH_RULE_SET
				.makeUid(searchRuleSet));// searchRuleSet,ruleSetName
		searchMatchRequest.setMatchType(matchType);

		LOG.info("Match Rule Set: " + searchMatchRequest.getMatchRuleSetUid());
		LOG.info("Match Type :" + searchMatchRequest.getMatchType());
		LOG.info("PKG::" + searchMatchRequest.getSiperianObjectUid());

		Field org_name = new Field("Organization_Name");
		StringBuilder orgNameConcat = new StringBuilder();
		if (!Util.isNullOrEmpty(params.getPartySearchCriteria().getFIRSTNAME())) {
			orgNameConcat.append(params.getPartySearchCriteria().getFIRSTNAME());
		LOG.info("First name :" + params.getPartySearchCriteria().getFIRSTNAME());
		
		}
		if (!Util.isNullOrEmpty(params.getPartySearchCriteria().getLASTNAME())) {
			orgNameConcat.append(Constant.STR_SPACE+params.getPartySearchCriteria().getLASTNAME());
		LOG.info("First name :" + params.getPartySearchCriteria().getLASTNAME());
		
		}
		
		if(orgNameConcat != null && orgNameConcat.length() > 0){
			org_name.setStringValue(orgNameConcat.toString());
			searchMatchRequest.addMatchColumnField(org_name);
		}
		LOG.info("Field to search for :" + org_name.getName() + ':' + org_name.getStringValue());

		//Person_Name
		Field field_name = new Field("Person_Name");
		if(orgNameConcat != null && orgNameConcat.length() > 0){
			field_name.setStringValue(orgNameConcat.toString());
			searchMatchRequest.addMatchColumnField(field_name);
		}
		LOG.info("Field to search for :" + field_name.getName() + ':' + field_name.getStringValue());

		// Setting Ex_Comm_Type_Email
		
		Field field_comm_email_type= new Field("Ex_Comm_Type_Email");
		field_comm_email_type.setStringValue("Email");
		searchMatchRequest.addMatchColumnField(field_comm_email_type);

		LOG.info("Field to search for :" + field_comm_email_type.getName() + ':' + field_comm_email_type.getStringValue());

		// Setting Ex_Comm_Val_Eml
		Field field_Eml_Val = new Field("Ex_Comm_Val_Email");
		StringBuilder contEmlVal = new StringBuilder();
		if (!Util.isNullOrEmpty(params.getPartySearchCriteria().getEMAILADDRESS())) {	
			contEmlVal.append(params.getPartySearchCriteria().getEMAILADDRESS());
			field_Eml_Val.setStringValue(contEmlVal.toString());

			searchMatchRequest.addMatchColumnField(field_Eml_Val);
			
			LOG.info("Field to search for :" + field_Eml_Val.getName()
					+ ':' + field_Eml_Val.getStringValue());
		}

		// Setting field_Entity_Type
		Field field_Entity_Type = new Field("Ex_Entity_Type");
		field_Entity_Type.setStringValue("Person");
		searchMatchRequest.addMatchColumnField(field_Entity_Type);

		LOG.info("Field to search for :" + field_Entity_Type.getName()
				+ ':' + field_Entity_Type.getStringValue());

		// Adding SIP_POP
		if(!Util.isNullOrEmpty(params.getPartySearchCriteria().getCOUNTRYCD())){
		Field field_SIPPOP = new Field("SIP_POP");
		if(!Util.isNullOrEmpty(params.getPartySearchCriteria().getCOUNTRYCD()) && params.getPartySearchCriteria().getCOUNTRYCD().length()==2){
		field_SIPPOP.setStringValue(getSIP_POPValue(params.getPartySearchCriteria().getCOUNTRYCD()));// sipPopVal
		}else{
			field_SIPPOP.setStringValue(params.getPartySearchCriteria().getCOUNTRYCD());
		}
		searchMatchRequest.addMatchColumnField(field_SIPPOP);
		
		LOG.info("Field to match for :" + field_SIPPOP.getName() + ':'
				+ field_SIPPOP.getStringValue());
		}
		List<Field> searchMatchField = searchMatchRequest.getMatchColumnFields();
		for(int j=0;j<searchMatchField.size();j++){
			Field f = (Field)searchMatchField.get(j);
			LOG.info("Search field name : " + f.getName()+": Search field value :" + f.getValue()+":");
			
		}
	
		try {
			siperianClient = (SiperianClient) checkOut();

			LOG.info("processing SearchMatchRequest");
			// Util.printObjectTreeInXML(SearchMatchRequest.class,searchMatchRequest);
			LOG.info("before request");
			searchMatchResponse = (SearchMatchResponse) siperianClient
					.process(searchMatchRequest);
			LOG.info("after response");
			recordMap.clear();
			if(searchMatchResponse!=null && searchMatchResponse.getRecords().size()>0){
				for (Iterator iter = searchMatchResponse.getRecords().iterator(); iter
						.hasNext();) {
					Record record = (Record) iter.next();
					// Calculate Highest Match Score
			//		LOG.debug("Match Score :"+ record.getField("MATCH_SCORE").getValue());
					String mtchScore = record.getField("MATCH_SCORE").getValue().toString().trim();
					String trimmedPartyRowId = record.getField("ROWID_OBJECT").getStringValue().trim();
			//		int key = Integer.parseInt(trimmedKey);
					 int mtchScoreValue = Integer.parseInt(mtchScore);
					LOG.info("rowid_object :" + trimmedPartyRowId+ " scoreValue :" + mtchScoreValue);
					if(mtchScoreValue >= minMatchScoreThres)	{
						//Process only those records with matchScore > minMatchScoreThres
						recordMap.put(trimmedPartyRowId, mtchScoreValue);
					}
			}
				LOG.info("Sizee of recordMap iss "+recordMap.size());
				if(recordMap.size()>0){
					if(recordMap.size()>1){
						int highestMatchScore=Collections.max(recordMap.values());
						LOG.info("highestMatchScore iss "+highestMatchScore);
						for(Entry<String,Integer> entry : recordMap.entrySet()){
							if(entry.getValue()==highestMatchScore){
								highestMatchScoreParty=entry.getKey();
								break;
							}
						}
						
						for(String partyKey : recordMap.keySet()){
							if(partyKey!=highestMatchScoreParty){
								recordMap.remove(partyKey);
							}
						}
					}
					
					LOG.info("Current Sizee of recordMap "+recordMap.size()+ "Keyset "+recordMap.keySet());
					
					cntctAcctMap=	getAccountRowidByContactID(recordMap.keySet());
			
			
					LOG.info("sizee of cntctAcctMap iss "+cntctAcctMap.size()+" "+cntctAcctMap.toString());
			
			if (cntctAcctMap.size()>0){
				
				/*Collection<String> accIds=cntctAcctMap.values();
				Set<String> accIdSet= new TreeSet<String>(accIds);*/
				String finalAccRowidObject=validateContactLinkedAccount(cntctAcctMap.keySet());
				LOG.info("finalAccRowidObject is "+finalAccRowidObject);
				if(!Util.isNullOrEmpty(finalAccRowidObject)){
					searchPartyResponse=generateADBSearchGoldenCopy(finalAccRowidObject,params.getPartySearchCriteria().getSRCSYSTEM());
				}else{
					searchPartyResponse=adbAccntFuzzySearch(params);
				}
				
			}else if(cntctAcctMap.size()==0){
				searchPartyResponse=adbAccntFuzzySearch(params);
			}
			
				}
				
			}else if(searchMatchResponse.getRecords().size()==0){
				searchPartyResponse=adbAccntFuzzySearch(params);
			}
	}catch(ServiceProcessingException spEx){
		LOG.info("Exception in adbContactFuzzySearch is "+spEx.getLocalizedMessage());
		throw spEx;
	}
		catch(Exception e){
		LOG.info("Exception in adbContactFuzzySearch is "+e.getLocalizedMessage());
		e.printStackTrace();
	}
		perfLog.printLog("Adobe fuzzy search", "", "Step-2", "adbContactFuzzySearch Ending in "+(System.currentTimeMillis()-startTime)+" ms");
		return searchPartyResponse;
	}
	
	
	private String validateContactLinkedAccount(Set<String> rowidContact){
		LOG.info("Starting validateContactLinkedAccount");
		StringBuffer validAccSql= new StringBuffer();
		//StringBuffer checkProspectSql= new StringBuffer();
		String accRowIdObject="";
		Statement statement = null;
		JDBCConnectionProvider jDBCConnectionProvider;
		Connection jdbcConnection = null;
		ResultSet resultSet = null;
	
		try {
		validAccSql.append("select rowid_party from c_b_party_rel cbpr,( SELECT    x.rowid_object FROM    (        SELECT            c.rowid_object,            ROW_NUMBER() OVER(PARTITION BY                c.rowid_party_2                ORDER BY                    c.create_date                DESC            ) rn        FROM            c_b_party_rel c,            c_b_party p        WHERE                c.rowid_party_2 IN ( ");
		for(String contactRowid : rowidContact){
			validAccSql.append("'"+contactRowid+"' ,");
		}
		validAccSql.deleteCharAt(validAccSql.length()-1);
		validAccSql.append(" )            AND                c.hub_state_ind = 1            AND                c.rowid_hierarchy = '4'            AND                c.rowid_rel_type = '25'            AND                p.party_type in ('Customer','Prospect Customer')            AND                c.rowid_party = p.rowid_object    ) x WHERE    x.rn = 1) A where cbpr.rowid_object=A.rowid_object");
		
		
			jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
		 
		jdbcConnection = jDBCConnectionProvider.getJdbcConnectionFromDS();
		//	jdbcConnection = JdbcConn.GetJdbcConnObject();
			statement = jdbcConnection.createStatement();
			resultSet = statement.executeQuery(validAccSql.toString());
			LOG.info("Queryy is "+validAccSql.toString());
			while(resultSet.next()){
				accRowIdObject=resultSet.getString("ROWID_PARTY");
			}
			LOG.info("accRowIdObject in validateContactLinkedAccount is "+accRowIdObject);
		}catch (ServiceProcessingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return accRowIdObject;
	}
	
	
	private SearchPartyResponse generateADBSearchGoldenCopy(String accRowidObj,String srcSystem) throws ServiceProcessingException{
		long startTime=System.currentTimeMillis();
		perfLog.printLog("Adobe Fuzzy Search", "", "Step-5", "Starting generateADBSearchGoldenCopy");
		SearchPartyResponse searchPartyResponse=null;
		LOG.info("accRowidObj in generateADBSearchGoldenCopy "+accRowidObj);
		Set<String> rowidObjectSet = new HashSet<String>();
		rowidObjectSet.add(accRowidObj);
		try {
			searchPartyResponse=searchPartyDAO.getAllPartyGoldenCopyADBSearch(rowidObjectSet, srcSystem);
		} catch (ServiceProcessingException spex) {
			// TODO Auto-generated catch block
			LOG.info("Exception occurred in generateADBSearchGoldenCopy "+spex.getMessage()+" "+spex.getRootExceptionMsg());
			throw spex;
		}
		LOG.info("Ending generateADBSearchGoldenCopy");
		perfLog.printLog("Adobe Fuzzy Search", "", "Step-5", "Ending generateADBSearchGoldenCopy in "+(System.currentTimeMillis()-startTime)+" ms");
		return searchPartyResponse;
		
	}
	
	
	
	
	
	
	
	private SearchPartyResponse adbAccntFuzzySearch(SearchPartyRequest params) throws ServiceProcessingException{
		long startTime=System.currentTimeMillis();
		perfLog.printLog("Adobe Fuzzy Search", "", "Step-3", "staring adbAccntFuzzySearch");
		LOG.info("Starting adbAccntFuzzySearch ");
		SearchPartyResponse searchPartyResponse=null;
		SearchMatchRequest searchMatchRequest = new SearchMatchRequest();
		List<Record> searchRecords = null;
		SiperianClient siperianClient = null;
		int tempMatchRuleNo=0;
		String tempRowidObj="";
		String tempPartyType="";
		String tempPartyUCN="";
		Map<String,Integer> matchRuleRecordMap=new HashMap<String,Integer>();
		Map<String,String> partyTypeMap=new HashMap<String,String>();
		Map<String,Long> partyUCNMap=new HashMap<String,Long>();
		if(Util.isNullOrEmpty(params.getPartySearchCriteria().getPARTYNAME()) || Util.isNullOrEmpty(params.getPartySearchCriteria().getCITY()) || Util.isNullOrEmpty(params.getPartySearchCriteria().getCOUNTRYCD())){
			searchPartyResponse= new SearchPartyResponse();
			searchPartyResponse.setErrorMsg("Party Name, City and Country cannot be empty");
			LOG.info("Validation Message is "+searchPartyResponse.getErrorMsg());
		}
		else{
		searchMatchRequest.setRecordsToReturn(Integer.parseInt(configProps
				.getProperty(Constant.FUZZY_SEARCH_DFLT_REC_THRES_COUNT_PROP)));
		searchMatchRequest.setSiperianObjectUid(MDMAttributeNames.PARTY_BO);
		searchMatchRequest
		.setMatchRuleSetUid(SiperianObjectType.MATCH_RULE_SET.makeUid(configProps
				.getProperty(Constant.MATCH_RULE_SET_ADOBE_MULTI_GEO_TILL_CITY)));
		searchMatchRequest.setMatchType(MatchType.BOTH);
		if(!Util.isNullOrEmpty(params.getPartySearchCriteria().getPARTYNAME()) && ((params.getPartySearchCriteria().getPARTYNAME().contains("%20%20")) || (params.getPartySearchCriteria().getPARTYNAME().contains("%20")))){
			while(params.getPartySearchCriteria().getPARTYNAME().contains("%20%20")){
			params.getPartySearchCriteria().setPARTYNAME(params.getPartySearchCriteria().getPARTYNAME().replace("%20%20", Constant.STR_SPACE));
			}
			while(params.getPartySearchCriteria().getPARTYNAME().contains("%20")){
				params.getPartySearchCriteria().setPARTYNAME(params.getPartySearchCriteria().getPARTYNAME().replace("%20", Constant.STR_SPACE));
				}
			
			LOG.info("Modified Party Name iss "+params.getPartySearchCriteria().getPARTYNAME());
		}
		createSearchField(searchMatchRequest,
				SearchMatchAttributes.ORGANIZATION_NAME,
				params.getPartySearchCriteria().getPARTYNAME());
		createSearchField(searchMatchRequest,
				SearchMatchAttributes.EX_ORGANIZATION_NAME,
				params.getPartySearchCriteria().getPARTYNAME());
		createSearchField(searchMatchRequest,
				SearchMatchAttributes.EX_ENTITY_TYPE,
				Constant.BO_CLASS_CODE_ORG);
		StringBuffer criteria = new StringBuffer();
		criteria.append(" HUB_STATE_IND <>"
				+ HubStateIndicator.DELETED.getValue());
		//commented as per Venkat's review - ODOM-2443
		//criteria.append(" AND " + PartyAttributes.STATUS_CD + " = 'A' " );
		criteria.append(" AND " + Constant.STR_OPEN_BRACKET
				+ PartyAttributes.PARTY_TYPE + " IS NULL OR "
				+ PartyAttributes.PARTY_TYPE + " IN" + Constant.STR_SPACE
				+ Constant.STR_OPEN_BRACKET + Constant.STR_SINGLE_QUOTE
				+ Constant.PARTY_TYPE_CUSTOMER + Constant.STR_SINGLE_QUOTE
				+ Constant.STR_COMMA + Constant.STR_SINGLE_QUOTE
				+ Constant.PARTY_TYPE_PROSPECT_ACCOUNT
				+ Constant.STR_SINGLE_QUOTE + Constant.STR_CLOSE_BRACKET
				+ Constant.STR_CLOSE_BRACKET);

		LOG.debug("[matchAccountMultiGeoTillCity]Filter Criteria: "
				+ criteria.toString());

		searchMatchRequest.setFilterCriteria(criteria.toString());

		
			StringBuilder addrLn1Ln2Concat = new StringBuilder();
			if (!Util.isNullOrEmpty(params.getPartySearchCriteria().getADDRLN1())) {
				addrLn1Ln2Concat.append(params.getPartySearchCriteria().getADDRLN1());
			}
			if (!Util.isNullOrEmpty(params.getPartySearchCriteria().getADDRLN2())) {
				addrLn1Ln2Concat.append(Constant.STR_SPACE);
				addrLn1Ln2Concat.append(params.getPartySearchCriteria().getADDRLN2());
			}
			// Setting Address_Part2
			StringBuilder addrCityStateCountryConcat = new StringBuilder();
			if (!(Util.isNullOrEmpty(params.getPartySearchCriteria().getCITY()) || Constant.STR_UNKNOWN
					.equalsIgnoreCase(params.getPartySearchCriteria().getCITY()))) {
				addrCityStateCountryConcat.append(params.getPartySearchCriteria().getCITY());
			}
			if (!Util.isNullOrEmpty(params.getPartySearchCriteria().getSTATECD())) {
				addrCityStateCountryConcat.append(" ");
				addrCityStateCountryConcat.append(params.getPartySearchCriteria().getSTATECD());
			}

			if (!Util.isNullOrEmpty(params.getPartySearchCriteria().getCOUNTRYCD())) {
				if(params.getPartySearchCriteria().getCOUNTRYCD().length()==2){
				addrCityStateCountryConcat.append(" ");
				addrCityStateCountryConcat.append(params.getPartySearchCriteria()
						.getCOUNTRYCD());
				}else if(params.getPartySearchCriteria().getCOUNTRYCD().length()>2){
				
				addrCityStateCountryConcat.append(" ");
				addrCityStateCountryConcat.append(getCountryCd(params.getPartySearchCriteria().getCOUNTRYCD()));
				}
			}

			createSearchField(searchMatchRequest,
					SearchMatchAttributes.EX_ADDRESS_LN1,
					params.getPartySearchCriteria().getADDRLN1());
			createSearchField(searchMatchRequest,
					SearchMatchAttributes.EX_ADDRESS_LN2,
					params.getPartySearchCriteria().getADDRLN2());
			createSearchField(searchMatchRequest,
					SearchMatchAttributes.ADDR_PART1,
					addrLn1Ln2Concat.toString());
			createSearchField(searchMatchRequest,
					SearchMatchAttributes.EX_ADDR_PART1,
					addrLn1Ln2Concat.toString());
			createSearchField(searchMatchRequest,
					SearchMatchAttributes.ADDR_PART2,
					addrCityStateCountryConcat.toString());
			createSearchField(searchMatchRequest,
					SearchMatchAttributes.EX_CITY, params.getPartySearchCriteria().getCITY());
			if(params.getPartySearchCriteria().getCOUNTRYCD().length()==2){
			createSearchField(searchMatchRequest,
					SearchMatchAttributes.EX_COUNTRY_CD,
					params.getPartySearchCriteria().getCOUNTRYCD());
			createSearchField(searchMatchRequest, PartyAttributes.SIP_POP,
					getSIP_POPValue(params.getPartySearchCriteria().getCOUNTRYCD()));
			}else{
				createSearchField(searchMatchRequest,
						SearchMatchAttributes.EX_COUNTRY_CD,
						getCountryCd(params.getPartySearchCriteria().getCOUNTRYCD()));
				createSearchField(searchMatchRequest, PartyAttributes.SIP_POP,
						params.getPartySearchCriteria().getCOUNTRYCD());
				
			}
			
			createSearchField(searchMatchRequest,
					SearchMatchAttributes.EX_STATE,
					params.getPartySearchCriteria().getSTATECD());
			List<Field> searchMatchField = searchMatchRequest.getMatchColumnFields();
			for(int j=0;j<searchMatchField.size();j++){
				Field f = (Field)searchMatchField.get(j);
				LOG.info("Search field name : " + f.getName()+": Search field value :" + f.getValue()+":");
				
			}
			
			try {
				siperianClient = (SiperianClient) checkOut();
				LOG.info("[matchAccountMultiGeoTillCity]processing SearchMatchRequest::"
						+ searchMatchRequest.getMatchRuleSetUid()
						+ "::"
						+ searchMatchRequest.getMatchColumnFields());
				SearchMatchResponse searchMatchResponse = (SearchMatchResponse) siperianClient
						.process(searchMatchRequest);
				LOG.info("[matchAccountMultiGeoTillCity]after response");
				if (searchMatchResponse != null
						&& !CollectionUtils.isEmpty(searchMatchResponse
								.getRecords())) {
					if (CollectionUtils.isEmpty(searchRecords)) {
						searchRecords = searchMatchResponse.getRecords();
					} else {
						searchRecords.addAll(searchMatchResponse.getRecords());
					}
				}else{
					try {
						searchPartyResponse=adobeProspectFuzzySearch(params);
					} catch (ServiceProcessingException e) {
						// TODO Auto-generated catch block
						LOG.info("Exception iss "+e.getLocalizedMessage());
					}
					
					
		}
				
				if(searchRecords!=null && !searchRecords.isEmpty()){
				for(int i =0 ; i< searchRecords.size();i++){
					tempMatchRuleNo=0;
					tempRowidObj="";
					tempPartyType="";
					tempPartyUCN="";
					Record record = (Record) searchRecords.get(i);
					record.getFields();
					Collection<String> fields = record.getFields();
					Iterator iterator = fields.iterator();
					while(iterator.hasNext()){
						Field f = (Field)iterator.next();
						if(f.getName().equals("RULE_NUMBER") && f.getValue()!=null){
							tempMatchRuleNo=Integer.parseInt(f.getValue().toString());
						}
						if(f.getName().equals("ROWID_OBJECT") && f.getValue()!=null){
							tempRowidObj=f.getValue().toString();
						}
						if(f.getName().equals("PARTY_TYPE") && f.getValue()!=null){
							tempPartyType=f.getValue().toString();
						}
						if(f.getName().equals("UCN") && f.getValue()!=null){
							tempPartyUCN=f.getValue().toString();
						}
					}
					matchRuleRecordMap.put(tempRowidObj,tempMatchRuleNo);
					partyTypeMap.put(tempRowidObj, tempPartyType);
					partyUCNMap.put(tempRowidObj, Long.parseLong(tempPartyUCN));
				}
				LOG.info(" matchRuleRecordMap "+matchRuleRecordMap.toString());
				LOG.info(" partyTypeMap "+partyTypeMap.toString());
				LOG.info(" partyUCNMap "+partyUCNMap.toString());
				if(matchRuleRecordMap.size()>0){
				Map<String,Integer> minRuleRecordMap=findMinMatchRuleRecords(matchRuleRecordMap);
				LOG.info(" Sizee of minRuleRecordMap "+minRuleRecordMap.size());
				if(minRuleRecordMap.size()==1){
					List<String> minRuleRowIDList= new ArrayList<String>(minRuleRecordMap.keySet());
					LOG.info(" minRuleRowIDList "+minRuleRowIDList.toString());
					if(minRuleRowIDList!=null && minRuleRowIDList.size()>0 && !Util.isNullOrEmpty(minRuleRowIDList.get(0))){
				 searchPartyResponse=generateADBSearchGoldenCopy(minRuleRowIDList.get(0),params.getPartySearchCriteria().getSRCSYSTEM());
					}
					
				}else if(minRuleRecordMap.size()>1){
	List<String> accRowIdList =	findCustDNBXrefEntries(matchRuleRecordMap, partyTypeMap);
	LOG.info("accRowIdList with DNBXrefEntries "+accRowIdList.toString());
	if(accRowIdList!=null && accRowIdList.size()==1 && !Util.isNullOrEmpty(accRowIdList.get(0))){
		 searchPartyResponse=generateADBSearchGoldenCopy(accRowIdList.get(0),params.getPartySearchCriteria().getSRCSYSTEM());
	}else if(accRowIdList.size()==0 || accRowIdList.size()>1){
		
String accRowId = findMinUcnRowId(partyUCNMap);
LOG.info("accRowId with min UCN "+accRowId);
	if(!Util.isNullOrEmpty(accRowId)){
		 searchPartyResponse=generateADBSearchGoldenCopy(accRowId,params.getPartySearchCriteria().getSRCSYSTEM());
	}
	else{
		searchPartyResponse=new SearchPartyResponse();
		searchPartyResponse.setStatus(Constant.noRecordFound);
	}
	}
				}		}
				
				
				}		
				
			}catch (SiperianServerException sifExcp) {
					LOG.error(
							"[matchAccountMultiGeoTillCity]SiperianServerException occured while processing SearchMatchRequest",
							sifExcp);
				}catch(ServiceProcessingException spex){
					LOG.info("Exception occurred in adbAccntFuzzySearch :: "+spex.getRootExceptionMsg());
					throw spex;
				}
catch (Exception exp) {
					LOG.error(
							"[matchAccountMultiGeoTillCity]Exception occured while processing SearchMatchRequest",
							exp);
				} finally {
					checkIn(siperianClient);
				}
			
		}	
		LOG.info("Before return from adbAccntFuzzySearch Validation Message is "+searchPartyResponse.getErrorMsg());
		perfLog.printLog("Adobe Fuzzy Search", "", "Step-3", "Ending adbAccntFuzzySearch in "+(System.currentTimeMillis()-startTime)+" ms");
		return searchPartyResponse;
		
	}
	
	
	
	private List<String>  findCustDNBXrefEntries(Map<String,Integer> matchRuleRecordMap,Map<String,String> partyTypeMap){
		LOG.info("Starting findCustDNBXrefEntries ");
		List<String> customerPartyRowidList= new ArrayList<String>();
		List<String> prospectPartyRowidList= new ArrayList<String>();
		List<String> partyRowIdList=null;
		List<String> rowIdList=new ArrayList<String>();
		for(Map.Entry<String,Integer> entry:matchRuleRecordMap.entrySet()){
			
			for(Map.Entry<String, String> partyTypeEntry : partyTypeMap.entrySet()){
				if(entry.getKey().equals(partyTypeEntry.getKey()) && partyTypeEntry.getValue().equalsIgnoreCase(Constant.PARTY_TYPE_CUSTOMER)){
					customerPartyRowidList.add(partyTypeEntry.getKey());
				}
				if(entry.getKey().equals(partyTypeEntry.getKey()) && partyTypeEntry.getValue().equalsIgnoreCase(Constant.PARTY_TYPE_PROSPECT_ACCOUNT)){
					prospectPartyRowidList.add(partyTypeEntry.getKey());
				}
				
				
			}
			
			
		}
		partyRowIdList= new ArrayList<String>(matchRuleRecordMap.keySet());
		LOG.info(" customerPartyRowidList "+customerPartyRowidList.toString());
		LOG.info(" prospectPartyRowidList "+prospectPartyRowidList.toString());
		LOG.info(" partyRowIdList "+ partyRowIdList.toString());
		if(customerPartyRowidList.size()==1){
			rowIdList= customerPartyRowidList;
		}else if(customerPartyRowidList.size()>1 || customerPartyRowidList.size()==0){
			
			List<String> prospectDNBEntryList=checkProspectDNBXrefEntry(prospectPartyRowidList);
			
			if(prospectDNBEntryList!=null && prospectDNBEntryList.size()==1){
				rowIdList=prospectDNBEntryList;
				
			}else if(prospectDNBEntryList.size()>1 || prospectDNBEntryList.size()==0){
				List<String> dNBXrefEntryList=	checkNullDNBXrefEntry(partyRowIdList);
				
				if(dNBXrefEntryList!=null && dNBXrefEntryList.size()==1){
					rowIdList=dNBXrefEntryList;
					
				}
				
			}
			
		}
		
		
		
		return rowIdList;
	}
	
	
	private List<String> checkProspectDNBXrefEntry(List<String> rowidObjList){
		LOG.info(" Starting checkProspectDNBXrefEntry ");
		List<String> dNBXrefRowidObjList=new ArrayList<String>();
		StringBuffer prospectDNBXrefEntryCheckSql=new StringBuffer();
		Statement statement = null;
		JDBCConnectionProvider jDBCConnectionProvider;
		Connection jdbcConnection = null;
		ResultSet resultSet = null;
		try{
		prospectDNBXrefEntryCheckSql.append("select rowid_object from C_B_party p where p.party_type='Prospect Customer' and p.hub_state_ind=1 and exists(select 1 from c_b_party_xref where rowid_object=p.rowid_object and hub_state_ind=1 and rowid_system='DNB') and rowid_object in (");
		for(String partyId:rowidObjList){
			prospectDNBXrefEntryCheckSql.append("'"+partyId+"',");
		}
		prospectDNBXrefEntryCheckSql.deleteCharAt(prospectDNBXrefEntryCheckSql.length()-1);
		prospectDNBXrefEntryCheckSql.append(")");
		LOG.info("Queryy is "+prospectDNBXrefEntryCheckSql.toString());
		jDBCConnectionProvider=JDBCConnectionProvider.getSingleInstance();
		jdbcConnection=jDBCConnectionProvider.getJdbcConnectionFromDS();
		statement=jdbcConnection.createStatement();
		resultSet=statement.executeQuery(prospectDNBXrefEntryCheckSql.toString());
		while(resultSet.next()){
			dNBXrefRowidObjList.add(resultSet.getString(1));
		}
		LOG.info("Sizee of dNBXrefRowidObjList "+dNBXrefRowidObjList.size());
		}catch(ServiceProcessingException se){
			se.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		LOG.info(" Ending checkProspectDNBXrefEntry");
		return dNBXrefRowidObjList;
	}
	
	
	
	
	
	private List<String> checkNullDNBXrefEntry(List<String> rowidObjList){
		LOG.info("Starting checkNullDNBXrefEntry ");
		List<String> dNBXrefRowidObjList=new ArrayList<String>();
		StringBuffer dNBXrefEntryCheckSql=new StringBuffer();
		Statement statement = null;
		JDBCConnectionProvider jDBCConnectionProvider;
		Connection jdbcConnection = null;
		ResultSet resultSet = null;
		try{
			dNBXrefEntryCheckSql.append("select rowid_object from C_B_party p where p.hub_state_ind=1 and exists(select 1 from c_b_party_xref where rowid_object=p.rowid_object and hub_state_ind=1 and rowid_system='DNB') and rowid_object in (");
		for(String partyId:rowidObjList){
			dNBXrefEntryCheckSql.append("'"+partyId+"',");
		}
		dNBXrefEntryCheckSql.deleteCharAt(dNBXrefEntryCheckSql.length()-1);
		dNBXrefEntryCheckSql.append(")");
		LOG.info("Queryy "+dNBXrefEntryCheckSql.toString());
		jDBCConnectionProvider=JDBCConnectionProvider.getSingleInstance();
		jdbcConnection=jDBCConnectionProvider.getJdbcConnectionFromDS();
		statement=jdbcConnection.createStatement();
		resultSet=statement.executeQuery(dNBXrefEntryCheckSql.toString());
		while(resultSet.next()){
			dNBXrefRowidObjList.add(resultSet.getString(1));
		}
		}catch(ServiceProcessingException se){
			se.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		LOG.info("Sizee of dNBXrefRowidObjList "+dNBXrefRowidObjList.size());
		LOG.info("Ending checkNullDNBXrefEntry ");
		return dNBXrefRowidObjList;
	}
	
	private Map<String,Integer> findMinMatchRuleRecords(Map<String,Integer> matchRuleRecordMap){
		LOG.info("Starting findMinMatchRuleRecords ");
		Map<String,Integer> minRuleNoRecordMap= new HashMap<String,Integer>();
		List<Integer> resultMatchRuleSet= new ArrayList<Integer>(matchRuleRecordMap.values());
		
		int minMatchRuleNo=Collections.min(resultMatchRuleSet);
		LOG.info("minMatchRuleNo is "+minMatchRuleNo);
		for(Map.Entry<String,Integer> entry:matchRuleRecordMap.entrySet()){
			if(entry.getValue()==minMatchRuleNo){
				minRuleNoRecordMap.put(entry.getKey(), entry.getValue());
			}
		}
		
		
		LOG.info("minRuleNoRecordMap "+minRuleNoRecordMap.toString());
		
		return minRuleNoRecordMap;
	}
	
	
	private void createSearchField(SearchMatchRequest searchMatchRequest,
			String fieldName, Object fieldValue) {
		LOG.info("[createSearchField]ENTER::fieldName::" + fieldName
				+ "::fieldValue::" + fieldValue);
		Field field = null;
		if (!Util.isNullOrEmpty(fieldName)) {
			field = new Field(fieldName);
			field.setValue(fieldValue);
		}
		if (field != null) {
			searchMatchRequest.addMatchColumnField(field);
			LOG.info("[createSearchField]Added Field::" + field.getName()
					+ "::" + field.getStringValue());
		}
		LOG.info("[createSearchField]EXIT");
	}
	
	
	private String findMinUcnRowId(Map<String, Long> UCNCustNumMap) {
		LOG.info(" Starting findMinUcnRowId");
		Map<String,Long> resultMap = new HashMap<String,Long>();
		List<Long> ucnList = new ArrayList<Long>(UCNCustNumMap.values());
		Long minUcn = Collections.min(ucnList);
		LOG.info("Min UCN is "+minUcn);
		String rowId="";
		for (Entry<String, Long> entry : UCNCustNumMap.entrySet()) {
			if (minUcn.equals(entry.getValue())) {
				resultMap.put(entry.getKey(), minUcn);
			}
		}
		
		if(resultMap!=null && resultMap.size()>0){
			for(Entry<String, Long> entry : resultMap.entrySet()){
				rowId = entry.getKey();
				break;
			}
		}
		LOG.info("Min UCN RowId "+rowId);
        return rowId;
	}
	
	private String getSIP_POPValue(String countryCd){
		String sip_pop="";
		StringBuffer sipPopQuery = new StringBuffer();
		Statement statement = null;
		JDBCConnectionProvider jDBCConnectionProvider;
		Connection jdbcConnection = null;
		ResultSet resultSet = null;
		try{
			sipPopQuery.append("select country_nm from mdm_country where country_cd = '");
			sipPopQuery.append(""+countryCd+"'");
			jDBCConnectionProvider=JDBCConnectionProvider.getSingleInstance();
			jdbcConnection=jDBCConnectionProvider.getJdbcConnectionFromDS();
			statement=jdbcConnection.createStatement();
			resultSet=statement.executeQuery(sipPopQuery.toString());
			while(resultSet.next()){
				sip_pop=resultSet.getString(1);
			}
		}catch(ServiceProcessingException se){
			se.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return sip_pop;
	}
	
	private String getCountryCd(String countryName){
		
		String countryCd="";
		StringBuffer sipPopQuery = new StringBuffer();
		Statement statement = null;
		JDBCConnectionProvider jDBCConnectionProvider;
		Connection jdbcConnection = null;
		ResultSet resultSet = null;
		try{
			sipPopQuery.append("select country_cd from mdm_country where country_nm = '");
			sipPopQuery.append(""+countryName+"'");
			jDBCConnectionProvider=JDBCConnectionProvider.getSingleInstance();
			jdbcConnection=jDBCConnectionProvider.getJdbcConnectionFromDS();
			statement=jdbcConnection.createStatement();
			resultSet=statement.executeQuery(sipPopQuery.toString());
			while(resultSet.next()){
				countryCd=resultSet.getString(1);
			}
		}catch(ServiceProcessingException se){
			se.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return countryCd;
		
		
	}
	
	
	private SearchPartyResponse adobeProspectFuzzySearch(SearchPartyRequest params) throws ServiceProcessingException{
		long startTime=System.currentTimeMillis();
		perfLog.printLog("Adobe Fuzzy Search", "", "Step-4", "Starting adobeProspectFuzzySearch");
		LOG.info("STarting adobeProspectFuzzySearch");
		List searchRecords = new ArrayList();
		SearchPartyResponse searchPartyResponse=null;
		int tempMatchRuleNo=0;
		String tempRowidObj="";
		String tempPartyUCN="";
		Map<String,Integer> matchRuleRecordMap=new HashMap<String,Integer>();
		Map<String,Long> partyUCNMap=new HashMap<String,Long>();
		String ruleSetNameResellerDistributor = configProps.getProperty("matchRuleSetResellerDistributor");
		try{
			SearchMatchRequest searchMatchRequest = new SearchMatchRequest();
			SearchMatchResponse searchMatchResponse = null;
			SiperianClient siperianClient = null;
			searchMatchRequest.setRecordsToReturn(100);
			searchMatchRequest.setSiperianObjectUid("BASE_OBJECT.C_B_PARTY");
			searchMatchRequest.setMatchRuleSetUid(SiperianObjectType.MATCH_RULE_SET.makeUid(ruleSetNameResellerDistributor));
			searchMatchRequest.setMatchType(MatchType.BOTH);
			LOG.info("Match Rule Set: " + searchMatchRequest.getMatchRuleSetUid());
			LOG.info("Match Type :" + searchMatchRequest.getMatchType());
			
			if(!Util.isNullOrEmpty(params.getPartySearchCriteria().getPARTYNAME()) && params.getPartySearchCriteria().getPARTYNAME().contains("%20%20")){
				while(params.getPartySearchCriteria().getPARTYNAME().contains("%20%20")){
				params.getPartySearchCriteria().setPARTYNAME(params.getPartySearchCriteria().getPARTYNAME().replace("%20%20", Constant.STR_SPACE));
				}
				while(params.getPartySearchCriteria().getPARTYNAME().contains("%20")){
					params.getPartySearchCriteria().setPARTYNAME(params.getPartySearchCriteria().getPARTYNAME().replace("%20", Constant.STR_SPACE));
					}
				
				LOG.info("Modified Party Name iss "+params.getPartySearchCriteria().getPARTYNAME());
			}
			Field field_name = new Field("Organization_Name");
			if (!Util.isNullOrEmpty(params.getPartySearchCriteria().getPARTYNAME())) {
				field_name.setStringValue(params.getPartySearchCriteria().getPARTYNAME());
				LOG.info("Field to search for :" + field_name.getName() + ':' + field_name.getStringValue());
				searchMatchRequest.addMatchColumnField(field_name);
			}
			Field field_addr1 = new Field("Address_Part1");
			StringBuilder addrLn1Ln2Concat = new StringBuilder();
			if (!Util.isNullOrEmpty(params.getPartySearchCriteria().getADDRLN1())) {
				addrLn1Ln2Concat.append(params.getPartySearchCriteria().getADDRLN1());

			}
			if (!Util.isNullOrEmpty(params.getPartySearchCriteria().getADDRLN2())) {
				addrLn1Ln2Concat.append(" ");
				addrLn1Ln2Concat.append(params.getPartySearchCriteria().getADDRLN2());

			} else {
				addrLn1Ln2Concat.append(" ");
			}
			if (addrLn1Ln2Concat != null && addrLn1Ln2Concat.length() > 1) {
				field_addr1.setStringValue(addrLn1Ln2Concat.toString());
				searchMatchRequest.addMatchColumnField(field_addr1);
			}
			LOG.info("Field to search for :" + field_addr1.getName() + ':' + field_addr1.getStringValue());

			if (!Util.isNullOrEmpty(params.getPartySearchCriteria().getADDRLN1()))
				commonUtil.createSearchField(searchMatchRequest, SearchMatchAttributes.EX_ADDRESS_LN1,
						params.getPartySearchCriteria().getADDRLN1());
			if (!Util.isNullOrEmpty(params.getPartySearchCriteria().getADDRLN2()))
				commonUtil.createSearchField(searchMatchRequest, SearchMatchAttributes.EX_ADDRESS_LN2,
						params.getPartySearchCriteria().getADDRLN2());

			if (addrLn1Ln2Concat != null && addrLn1Ln2Concat.length() > 1) {
				if (!Util.isNullOrEmpty(params.getPartySearchCriteria().getADDRLN2())) {
					commonUtil.createSearchField(searchMatchRequest, SearchMatchAttributes.EX_ADDR_PART1,
							addrLn1Ln2Concat.toString()+Constant.STR_SPACE);	
				}else{
					commonUtil.createSearchField(searchMatchRequest, SearchMatchAttributes.EX_ADDR_PART1,
							addrLn1Ln2Concat.toString());
				}
				
			}
			if (!Util.isNullOrEmpty(params.getPartySearchCriteria().getCITY()))
				commonUtil.createSearchField(searchMatchRequest, SearchMatchAttributes.EX_CITY, params.getPartySearchCriteria().getCITY());
			if (!Util.isNullOrEmpty(params.getPartySearchCriteria().getCOUNTRYCD())){
				if(params.getPartySearchCriteria().getCOUNTRYCD().length()==2){
				commonUtil.createSearchField(searchMatchRequest, SearchMatchAttributes.EX_COUNTRY_CD,
						params.getPartySearchCriteria().getCOUNTRYCD());
				}else if(params.getPartySearchCriteria().getCOUNTRYCD().length()>2){
					commonUtil.createSearchField(searchMatchRequest, SearchMatchAttributes.EX_COUNTRY_CD,
							getCountryCd(params.getPartySearchCriteria().getCOUNTRYCD()));
				}
			}
				
			if (!Util.isNullOrEmpty(params.getPartySearchCriteria().getSTATECD()))
				commonUtil.createSearchField(searchMatchRequest, SearchMatchAttributes.EX_STATE, params.getPartySearchCriteria().getSTATECD());
			
			LOG.info("State search : " + params.getPartySearchCriteria().getSTATECD());
			LOG.info("country search : " + params.getPartySearchCriteria().getCOUNTRYCD());
			LOG.info("addresspart1 search: " + addrLn1Ln2Concat);
			LOG.info("Search organization name : " + params.getPartySearchCriteria().getPARTYNAME());
			LOG.info("searrch entity type : " + Constant.BO_CLASS_CODE_ORG);
			LOG.info("searrch for UCN : " + params.getPartySearchCriteria().getUCN());
			LOG.info("searrch for city : " + params.getPartySearchCriteria().getCITY());
			// Setting Address_Part2

			Field addr_part2 = new Field("Address_Part2");
			StringBuilder addrPart2Concat = new StringBuilder();
			if (!Util.isNullOrEmpty(params.getPartySearchCriteria().getCITY())) {
				addrPart2Concat.append(params.getPartySearchCriteria().getCITY());
			}
			if (!Util.isNullOrEmpty(params.getPartySearchCriteria().getSTATECD())) {
				if (addrPart2Concat != null && addrPart2Concat.length() > 1)
					addrPart2Concat.append(" ");
				addrPart2Concat.append(params.getPartySearchCriteria().getSTATECD());
			}
			if (!Util.isNullOrEmpty(params.getPartySearchCriteria().getCOUNTRYCD())) {
				if (addrPart2Concat != null && addrPart2Concat.length() > 1)
					addrPart2Concat.append(" ");
				if(params.getPartySearchCriteria().getCOUNTRYCD().length()==2){
					addrPart2Concat.append(params.getPartySearchCriteria().getCOUNTRYCD());
				}else{
					addrPart2Concat.append(getCountryCd(params.getPartySearchCriteria().getCOUNTRYCD()));
				}
				
			}
			if (addrPart2Concat != null && addrPart2Concat.length() > 1) {
				addr_part2.setStringValue(addrPart2Concat.toString());
				LOG.info("Field to search for :" + addr_part2.getName() + ':' + addr_part2.getStringValue());
				searchMatchRequest.addMatchColumnField(addr_part2);
			}
			commonUtil.createSearchField(searchMatchRequest, SearchMatchAttributes.EX_ORGANIZATION_NAME,
					params.getPartySearchCriteria().getPARTYNAME());

			commonUtil.createSearchField(searchMatchRequest, SearchMatchAttributes.EX_ENTITY_TYPE, Constant.BO_CLASS_CODE_ORG);
			commonUtil.createSearchField(searchMatchRequest, SearchMatchAttributes.EX_PARTY_TYPE,
					Constant.PARTY_TYPE_PROSPECT_ACCOUNT);
			Field field_SIPPOP = new Field("SIP_POP");
			if(!Util.isNullOrEmpty(params.getPartySearchCriteria().getCOUNTRYCD())){
				if(params.getPartySearchCriteria().getCOUNTRYCD().length()==2){
			field_SIPPOP.setStringValue(getSIP_POPValue(params.getPartySearchCriteria().getCOUNTRYCD()));
				}else{
					field_SIPPOP.setStringValue(params.getPartySearchCriteria().getCOUNTRYCD());
				}
			}
			searchMatchRequest.addMatchColumnField(field_SIPPOP);
			LOG.info("Field to match for :" + field_SIPPOP.getName() + ':' + field_SIPPOP.getStringValue());

			StringBuffer criteria = new StringBuffer();
			
			criteria.append(" PARTY_TYPE = 'Prospect Customer' ");
			
			searchMatchRequest.setFilterCriteria(criteria.toString());

			LOG.info("processing SearchMatchRequest");
			
			List<Field> searchMatchField = searchMatchRequest.getMatchColumnFields();
			for(int j=0;j<searchMatchField.size();j++){
				Field f = (Field)searchMatchField.get(j);
				LOG.info("Search field name : " + f.getName()+": Search field value :" + f.getValue()+":");
				
			}
			siperianClient = (SiperianClient) checkOut();
			LOG.info(" siperianClient iss "+siperianClient);
			LOG.info("Before Request");
			searchMatchResponse = (SearchMatchResponse) siperianClient.process(searchMatchRequest);
			LOG.info("After Response");
			searchRecords = searchMatchResponse.getRecords();
			LOG.info("Sizee of searchRecords "+searchRecords.size()+" "+searchRecords.toString());
			if(searchRecords!=null && !searchRecords.isEmpty()){
			for(int i =0 ; i< searchRecords.size();i++){
				Record record = (Record) searchRecords.get(i);
				Collection<String> fields = record.getFields();
				List<String> fieldList= new ArrayList<String>(fields);
				LOG.info("fieldList "+fieldList.toString());
				Iterator iterator = fields.iterator();
				while (iterator.hasNext()) {
					Field f = (Field)iterator.next();
					LOG.info("field name "+f.getName()+"Vallll" +f.getValue());
					if(f.getName().equals("RULE_NUMBER")){
					tempMatchRuleNo=Integer.parseInt(f.getValue().toString());	
					}
					if(f.getName().equals("ROWID_OBJECT")){
						tempRowidObj=f.getValue().toString();
					}
					if(f.getName().equals("UCN")){
						tempPartyUCN=f.getValue().toString();
					}
					
					
					
				}
				LOG.info("tempMatchRuleNo>>"+tempMatchRuleNo+"tempRowidObj>>"+tempRowidObj+"tempPartyUCN>>"+tempPartyUCN);
				
				matchRuleRecordMap.put(tempRowidObj,tempMatchRuleNo);
				partyUCNMap.put(tempRowidObj, Long.parseLong(tempPartyUCN));
			}
				LOG.info(" matchRuleRecordMap in adobeProspectFuzzySearch "+matchRuleRecordMap.toString());
				LOG.info(" partyUCNMap in adobeProspectFuzzySearch "+partyUCNMap.toString());
				if(matchRuleRecordMap.size()>0){
					Map<String,Integer> minRuleRecordMap=findMinMatchRuleRecords(matchRuleRecordMap);
					if(minRuleRecordMap!=null && minRuleRecordMap.size()==1){
						List<String> minRuleRowIDList=new ArrayList<String>(minRuleRecordMap.keySet());
						LOG.info(" minRuleRowIDList "+ minRuleRowIDList.toString());
						if(minRuleRowIDList!=null && minRuleRowIDList.size()>0 && !Util.isNullOrEmpty(minRuleRowIDList.get(0))){
					 searchPartyResponse=generateADBSearchGoldenCopy(minRuleRowIDList.get(0),params.getPartySearchCriteria().getSRCSYSTEM());
						}else if(minRuleRowIDList.size()>1){
							String accRowId = findMinUcnRowId(partyUCNMap);
							LOG.info("accRowId with Min UCN is "+accRowId);
							if(!Util.isNullOrEmpty(accRowId)){
								 searchPartyResponse=generateADBSearchGoldenCopy(accRowId,params.getPartySearchCriteria().getSRCSYSTEM());
							}
						}
						
					}else{
						String accRowId = findMinUcnRowId(partyUCNMap);
						LOG.info("accRowId with Min UCN is "+accRowId);
						if(!Util.isNullOrEmpty(accRowId)){
							 searchPartyResponse=generateADBSearchGoldenCopy(accRowId,params.getPartySearchCriteria().getSRCSYSTEM());
						}
					}
				
			}
			}else{
				searchPartyResponse=new SearchPartyResponse();
				searchPartyResponse.setStatus(Constant.noRecordFound);
			}
		}catch (SiperianServerException sifExcp) {

			LOG.error("SiperianServerException occured while processing SearchMatchRequest on PARTY BO: ", sifExcp);

			ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
			customException.setMessage("SIF exception occured while processing SearchMatchRequest on PARTY BO: "
					+ customException.getMessage());
			throw customException;
		} catch(ServiceProcessingException spEx){
			LOG.info("Exception occurred in adobeProspectFuzzySearch "+spEx.getMessage() +" "+ spEx.getRootExceptionMsg());
			throw spEx;
		}
		catch (Exception ex) {

			LOG.error("PARTY BO Merge operation failed with exception: ", ex);

			ServiceProcessingException customException = new ServiceProcessingException(ex);
			customException
					.setMessage("Failed to process SearchMatchRequest on PARTY BO: " + customException.getMessage());
			throw customException;
		}

		perfLog.printLog("Adobe Fuzzy Search", "", "Step-4", "Ending adobeProspectFuzzySearch in "+(System.currentTimeMillis()-startTime)+" ms");
		return searchPartyResponse;
	}
	
	
	
	public SearchPartyResponse processAdobeContactFuzzySearch(SearchPartyRequest params) throws ServiceProcessingException{
		long startTime=System.currentTimeMillis();
		
		LOG.info("Starting processAdobeContactFuzzySearch in SearchContactDAO");
		perfLog.printLog("Adobe Fuzzy Search", "", "Step-1", "Starting processAdobeContactFuzzySearch");
		SearchPartyResponse searchPartyResponse=null;
		if((!Util.isNullOrEmpty(params.getPartySearchCriteria().getFIRSTNAME()) || !Util.isNullOrEmpty(params.getPartySearchCriteria().getLASTNAME())) && !Util.isNullOrEmpty(params.getPartySearchCriteria().getEMAILADDRESS())){
			try{
			searchPartyResponse	=adbContactFuzzySearch(params);
			}catch(ServiceProcessingException spEx){
				LOG.info("Exception iss "+spEx.getMessage()+ " "+spEx.getRootExceptionMsg());
				if(spEx.getRootExceptionMsg().contains("Failed to create JDBC connection")){
					searchPartyResponse=new SearchPartyResponse();
					searchPartyResponse.setStatus("ERROR :: "+spEx.getRootExceptionMsg());
					searchPartyResponse.setErrorMsg(spEx.getRootExceptionMsg());
				}
			}catch(Exception e){
				LOG.info("Exception occurred in processAdobeContactFuzzySearch "+e.getMessage());
			}
			LOG.info("after return to processAdobeContactFuzzySearch "+searchPartyResponse.getErrorMsg()+" "+searchPartyResponse.getStatus());
			if(searchPartyResponse!=null && searchPartyResponse.getPartyProfile()==null && searchPartyResponse.getPartyProfile().size()==0){
				searchPartyResponse.setStatus(Constant.noRecordFound);
			}
			
		}else{
			searchPartyResponse=new SearchPartyResponse();
			searchPartyResponse.setErrorMsg("FirstName/LastName and E-mail address cannot be empty");
		}
		LOG.info("Ending processAdobeContactFuzzySearch in SearchContactDAO");
		perfLog.printLog("Adobe Fuzzy Sezrch", "", "Fuzzy Search", "Ending processAdobeContactFuzzySearch in "+(System.currentTimeMillis()-startTime)+" ms");
		return searchPartyResponse;
	}
	
	
}
