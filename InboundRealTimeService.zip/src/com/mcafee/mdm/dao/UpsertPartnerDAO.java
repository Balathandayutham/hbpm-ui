package com.mcafee.mdm.dao;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.mcafee.mdm.dao.pojo.PutResponseDataHolder;
import com.mcafee.mdm.exception.ServiceProcessingException;
import com.mcafee.mdm.generated.MdmUpsertPartyRequest;
import com.mcafee.mdm.generated.MdmUpsertPartyResponse;
import com.mcafee.mdm.generated.PartyXrefType;
import com.mcafee.mdm.util.PerformanceLoggerUtil;

/**
 * 
 * This class is used to call Partner/Reseller/Distributor creation in MDM.
 *
 */

public class UpsertPartnerDAO extends SFDCUpsertPartyDAO {
	
	private static final Logger LOG = Logger.getLogger(UpsertPartnerDAO.class.getName());
	
	
	
	public void processUpsertRequestForIndividualPartner(String methodName, PartyXrefType upsertParty,
			MdmUpsertPartyResponse upsertPartyResponse) throws ServiceProcessingException {
		LOG.info("Executing processUpsertRequestForIndividualPartner()");
		// TODO Auto-generated method stub
		processUpsertRequestForIndividualParty(methodName, upsertParty, upsertPartyResponse);
		LOG.info("Executed processUpsertRequestForIndividualPartner()");
	}

	
	@Override
	public void processUpsertRequestForIndividualParty(String methodName, PartyXrefType upsertParty,
			MdmUpsertPartyResponse upsertPartyResponse) throws ServiceProcessingException {
		// TODO Auto-generated method stub
		//super.processUpsertRequestForIndividualParty(methodName, upsertParty, upsertPartyResponse);


		LOG.info("Executing processUpsertRequestForIndividualParty()");
		
		PerformanceLoggerUtil perfLog = new PerformanceLoggerUtil();	
		
		String rowidObject = null;
		boolean retry = false;
		boolean execNext = false;
		PutResponseDataHolder putRespDataParty = null;
		GenericDAO genericDAO = new GenericDAO();
		//List searchRecords = new ArrayList();
		if(null != methodName){
			partyCount = 1;
			retry = true;
			execNext = true;
			try{
				Method method = this.getClass().getSuperclass().getDeclaredMethod (methodName,PartyXrefType.class,MdmUpsertPartyResponse.class,boolean.class,boolean.class, String.class);
				Object[] args = new Object[5];
				args[0] = upsertParty;
				args[1] = upsertPartyResponse;
				args[2] = retry;
				args[3] = execNext;
				args[4] = rowidObject;
			
				method.invoke (this.getClass().getSuperclass(),args);
			}catch(NoSuchMethodException e){
				LOG.error(e);
				throw new ServiceProcessingException(e);
			} catch (IllegalAccessException e) {
				LOG.error(e);
				throw new ServiceProcessingException(e);
			} catch (IllegalArgumentException e) {
				LOG.error(e);
				throw new ServiceProcessingException(e);
			} catch (InvocationTargetException e) {
				LOG.error(e);
				throw new ServiceProcessingException(e);
			}
		}else{
			retry = false;
			execNext = false;
			Map<String, Object> putRespDataHolderMap = null;
			upsertDataValidation(upsertParty, upsertPartyResponse,false, false, rowidObject);		
			
			upsertTrilliumProcessing(upsertParty, upsertPartyResponse,false, false, rowidObject);
			
			/*Change for MDMP-2885 :: START*/
			genericDAO.callIsDeniedPartyService(upsertParty);
			/*Change for MDMP-2885 :: END*/
			
			//Check for data quality in SFDC input
			checkDataQualityUpsert (upsertParty, upsertPartyResponse,false, false, rowidObject);	
			//Check pre upsert match processes
			preUpsertMatchProcess(upsertParty, upsertPartyResponse,false, false,rowidObject);
			
			processCleansePutRequest(upsertParty, upsertPartyResponse,false, false,rowidObject);
			
			upsertTokenize(upsertParty, upsertPartyResponse,false, false, rowidObject);
			
			upsertMatchMergeProcess(upsertParty, upsertPartyResponse,false, false, rowidObject);
			
			//upsertP2CProcess(upsertParty, upsertPartyResponse , false, false, rowidObject);
			
			upsertUCNStampProcess(upsertParty, upsertPartyResponse , false, false, rowidObject);
			
			upsertDataSyncAccSegAssignProcess(upsertParty, upsertPartyResponse , false, false, rowidObject);
					
		}

		populateUpsertResponse(upsertParty,upsertPartyResponse);

				

		LOG.info("Executed processUpsertRequestForIndividualParty()");

	
	}
}
