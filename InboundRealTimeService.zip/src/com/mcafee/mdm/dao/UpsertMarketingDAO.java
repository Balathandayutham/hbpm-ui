package com.mcafee.mdm.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;

import javax.annotation.Resource;
import javax.transaction.SystemException;
import javax.transaction.UserTransaction;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.mcafee.mdm.constants.AddressAttributes;
import com.mcafee.mdm.constants.CommunicationAttributes;
import com.mcafee.mdm.constants.Constant;
import com.mcafee.mdm.constants.MDMAttributeNames;
import com.mcafee.mdm.constants.PartyAttributes;
import com.mcafee.mdm.constants.PartyPersonAttributes;
import com.mcafee.mdm.constants.ProspectAttributes;
import com.mcafee.mdm.dao.pojo.AcntCntctRelData;
import com.mcafee.mdm.dao.pojo.CntctPkeyRowIdRelData;
import com.mcafee.mdm.dao.pojo.HighestScoreRecordHolder;
import com.mcafee.mdm.dao.pojo.PartyChildRowIdData;
import com.mcafee.mdm.dao.pojo.PutResponseDataHolder;
import com.mcafee.mdm.exception.ServiceProcessingException;
import com.mcafee.mdm.generated.Account;
import com.mcafee.mdm.generated.AccountXrefType;
import com.mcafee.mdm.generated.Address;
import com.mcafee.mdm.generated.AddressXrefType;
import com.mcafee.mdm.generated.Communication;
import com.mcafee.mdm.generated.CommunicationXrefType;
import com.mcafee.mdm.generated.MdmUpsertPartyResponse;
import com.mcafee.mdm.generated.PartyContactRelationshipXrefType;
import com.mcafee.mdm.generated.PartyPerson;
import com.mcafee.mdm.generated.PartyPersonXrefType;
import com.mcafee.mdm.generated.PartyType;
import com.mcafee.mdm.generated.PartyUpsertRespType;
import com.mcafee.mdm.generated.PartyXrefType;
import com.mcafee.mdm.generated.UpsertPartyRequest;
import com.mcafee.mdm.generated.UpsertPartyResponse;
import com.mcafee.mdm.util.JDBCConnectionProvider;
import com.mcafee.mdm.util.ObjectPool;
import com.mcafee.mdm.util.PerformanceLoggerUtil;
import com.mcafee.mdm.util.Util;
import com.siperian.sif.client.EjbSiperianClient;
import com.siperian.sif.client.SiperianClient;
import com.siperian.sif.client.SiperianServerException;
import com.siperian.sif.message.Field;
import com.siperian.sif.message.MatchType;
import com.siperian.sif.message.Record;
import com.siperian.sif.message.RecordKey;
import com.siperian.sif.message.SiperianObjectType;
import com.siperian.sif.message.TaskData;
import com.siperian.sif.message.TaskRecord;
import com.siperian.sif.message.XrefKey;
import com.siperian.sif.message.mrm.CleansePutRequest;
import com.siperian.sif.message.mrm.CleansePutResponse;
import com.siperian.sif.message.mrm.CreateTaskRequest;
import com.siperian.sif.message.mrm.CreateTaskResponse;
import com.siperian.sif.message.mrm.MergeRequest;
import com.siperian.sif.message.mrm.MergeResponse;
import com.siperian.sif.message.mrm.MultiMergeRequest;
import com.siperian.sif.message.mrm.MultiMergeResponse;
import com.siperian.sif.message.mrm.PutRequest;
import com.siperian.sif.message.mrm.PutResponse;
import com.siperian.sif.message.mrm.RestoreRequest;
import com.siperian.sif.message.mrm.RestoreResponse;
import com.siperian.sif.message.mrm.SearchMatchRequest;
import com.siperian.sif.message.mrm.SearchMatchResponse;
import com.siperian.sif.message.mrm.TokenizeRequest;
import com.siperian.sif.message.mrm.TokenizeResponse;
import com.siperian.sif.message.mrm.UnmergeResponse;

/**
 * This is DAO class to perform Upsert functionality for Marketing Systems
 * 
 * @since M4M Project
 * @author MDM Team Cognizant
 *
 */
@Component
@Scope("prototype")
public class UpsertMarketingDAO extends ObjectPool {

	private static final Logger LOG = Logger.getLogger(UpsertMarketingDAO.class.getName());

	@Autowired
	private GetPartyDAO getPartyDAO;
	@Autowired
	private SearchProspectPartyDAO searchProspectDao;
	@Autowired
	private MergeProspectPartyDAO mergeProspectPartyDAO;
	@Autowired
	private DeleteProspectPartyDAO deleteProspectPartyDAO;
	@Autowired
	private ProspectPartyDAO prospectPartyDAO;
	@Autowired
	private GetMarketingPartyDAO getMarketingPartyDAO;
	@Autowired
	private UpsertPartyContactDAO upsertContactDAO;

	@Resource(name = "m4mMessagesProp")
	private Properties messagesProp;

	@Resource(name = "configProp")
	private Properties configProps;

	Integer partyCount = 0;
	Date lastUpdateDate = null;
	String sipPopVal = null;
	boolean matchInd = false;
	boolean mergeInd = false;
	String tgtRowidObj = null;
	String commEmlVal = null;
	boolean isEmailValExists = false;
	boolean childMergeInd = false;

	/**
	 * Checks for BO Class code from Upsert request and performs Upsert
	 * operation for Marketing Account or Contact
	 * 
	 * @param upsertPartyRequest
	 * @return upsertPartyResponse
	 * @throws ServiceProcessingException
	 */
	public UpsertPartyResponse processMarketingUpsertRequest(UpsertPartyRequest upsertPartyRequest)
			throws ServiceProcessingException {
		LOG.debug("[processMarketingUpsertRequest] START");
		UpsertPartyResponse upsertPartyResponse = new UpsertPartyResponse();
//		boolean isEmailValuePresent = Boolean.FALSE;
		String emailValueFrmPayload = null;
		List<String> commPkeyEmlList = null;
		List<String> acctRowidCountryCdList = null;
		String commPkeyAppndEml = null;
		String existingPkey = null;
		String existingEmail = null;
		boolean isEmailProcssd = false;
		for (PartyXrefType curParty : upsertPartyRequest.getParty()) {
			try {				
				/** Modified for US68-Throughput Tracker START */
				validateMsgTrackingId(curParty, upsertPartyResponse);
				/** Modified for US68-Throughput Tracker END */
				
				String boClassCode = curParty.getBOCLASSCODE();
				if (Constant.BO_CLASS_CODE_PERSON.equalsIgnoreCase(boClassCode)) {
					
					PerformanceLoggerUtil perfLog = new PerformanceLoggerUtil();
					
					/** Modified for US-33: MDM service will reject any contact / account that comes with company name of Unknown START*/
					if(!validateCompanyName(curParty, upsertPartyResponse))	{
						//REPORTED_COMPANY_NAME is NOT VALID NAME OR INVALID
						LOG.debug(
								"Contact record does not have Valid REPORTED_COMPANY_NAME, hence bypassing Contact insertion: "
										+ curParty.getXREF().get(0).getSRCPKEY());
				//		upsertPartyResponse.setStatus("Contact record does not have Valid REPORTED_COMPANY_NAME, hence bypassing Contact insertion: "+
				//				curParty.getXREF().get(0).getSRCPKEY());
						return upsertPartyResponse;
					}
					/** Modified for US-33: MDM service will reject any contact / account that comes with company name of Unknown END*/
					
					if (validateContactRequest(curParty, upsertPartyResponse)) {
			//		if (curParty.getPartyPerson() != null) {
						/**
						 * Added for US-523 MDM service will reject any account
						 * that comes with Junk AddressLn1 or City STOP
						 **/
						if (!validateContactAddress(curParty,
								upsertPartyResponse)) {
							// REPORTED Address or city is junk
							LOG.debug("ELQ Contact record have AddressLn1 or city junk Rejecting:: "
									+ curParty.getXREF().get(0).getSRCPKEY());
							return upsertPartyResponse;
						}
						for (CommunicationXrefType commXrefType : curParty.getCommunication()) {
							if (commXrefType.getCOMMTYPE().equalsIgnoreCase("Email")) {
						//		isEmailValuePresent = Boolean.TRUE;
								emailValueFrmPayload = commXrefType.getCOMMVALUE();
							}
						}
						// Contact minimum data criteria--> IF (FIRSTNAME is NOT NULL
						// OR LASTNAME is NOT NULL) AND (EMAIL_ADDRESS is NOT NULL)
						// AND (COUNTRY_CD is NOT NULL) AND (REPORTED_COMPANY_NAME is NOT NULL)
			/*			if ((curParty.getPartyPerson().get(0).getFIRSTNAME() != null
								|| curParty.getPartyPerson().get(0).getLASTNAME() != null) && isEmailValuePresent 
								&& (curParty.getAddress().get(0).getCOUNTRYCD() != null)
								&& (curParty.getPartyPerson().get(0).getREPORTEDCOMPANYNAME() != null) ) {	*/
							/*
							 * Validate to see IF same CONTACT_PKEY contains
							 * same EMAIL_ADDRESS or not
							 */
							/* Fetch Existing Email ID & CONTACT_ID */
							commPkeyEmlList = prospectPartyDAO
									.getContactEmailByContactPkey(curParty.getXREF().get(0).getSRCPKEY());
							if (!commPkeyEmlList.isEmpty()) {
								commPkeyAppndEml = commPkeyEmlList.get(0);
								LOG.debug("[getContactEmailByContactPkey] Contact Pkey Value is::" + commPkeyAppndEml);
								String tmpArr[] = commPkeyAppndEml.split("\\|");
								existingPkey = tmpArr[0];// Contact Pkey from
															// MDM DB
								existingEmail = tmpArr[1];// Contact Email
															// ID from MDM
															// DB
								LOG.debug("Existing Contact PKEY_SRC_OBJECT-->" + existingPkey
										+ " Existing Email Value is-->" + existingEmail);
							}

							if (Util.isNullOrEmpty(existingPkey)) {
								/* Creating New Contact Record */
								LOG.debug("Creating New Contact Record");
								processUpsertRequestForIndividualContact(curParty, upsertPartyResponse);
							} else {
								/**SWAT EPBI: Remove MDM_FLag -7 Logic **/
							/*	 US55- Sprint# 5 Code Change 
								String contactCountryCd = curParty.getAddress().get(0).getCOUNTRYCD();
								 Fetch Existing ACCOUNT_ROWID & COUNTRY_CD 
								acctRowidCountryCdList = prospectPartyDAO.getExistingAccountCountryCd(existingPkey);
								if(!acctRowidCountryCdList.isEmpty()){
									for(String acctRowidCountry: acctRowidCountryCdList){
										String temp[] = acctRowidCountry.split("\\|");
										String acctRowid = temp[0]; 
										String acctCountryCd = temp[1];
										if(!acctCountryCd.equalsIgnoreCase(contactCountryCd)){
											LOG.debug("Contact CountryCd: "+contactCountryCd+" is not matching with Account CountryCd: "+acctCountryCd
													+ " having Account Rowid: "+acctRowid);
											createContactUpsertInfoMessage(upsertPartyResponse, Constant.INFO_CONTACT_COUNTRY_DIFF_ACCT_COUNTRY, existingPkey);
											return upsertPartyResponse;
										}
									}//end for-loop
								}else{
									LOG.debug("No Associated Account CountryCd Found for Contact: "+existingPkey);
								}
								*/
								
								if ((Util.isNullOrEmpty(existingEmail) || "null".equalsIgnoreCase(existingEmail))
										&& emailValueFrmPayload != null) {
									LOG.debug("existingEmail: " + existingEmail);
									LOG.debug("Incoming emailValueFrmPayload: " + emailValueFrmPayload);
									isEmailProcssd = true;
									/*
									 * Update Existing NULL Email id with Non-NULL Incoming Email value
									 */
									LOG.debug("Update Existing NULL Email id with Non-NULL Incoming Email value");
									processUpsertRequestForIndividualContact(curParty, upsertPartyResponse);
								}

								if (!Util.isNullOrEmpty(existingEmail)) {
									if (existingEmail.equalsIgnoreCase(emailValueFrmPayload)) {
										/* Updating Existing Contact Record */
										LOG.debug("Updating Existing Contact Record");
										processUpsertRequestForIndividualContact(curParty, upsertPartyResponse);
									} else if (!isEmailProcssd) {
										LOG.debug("Incoming Email value->" + emailValueFrmPayload
												+ " is different from Existing Email value->" + existingEmail
												+ ",hence bypassing Contact Update.");
									}
								} else {
									LOG.debug(
											"No Existing Email Address for Existing Contact record ->" + existingPkey);
								}
							}
			/*			} else {
							LOG.debug(
									"Contact record does not meet minimum data criteria,hence bypassing Contact insertion: "
											+ curParty.getXREF().get(0).getSRCPKEY());
							upsertPartyResponse.setStatus("Contact record does not meet minimum data criteria,hence bypassing Contact insertion: "+
									curParty.getXREF().get(0).getSRCPKEY());
						}	*/
			/*	} 	else {
						LOG.debug(
								"Contact record does not meet minimum data criteria,hence bypassing Contact insertion: "
										+ curParty.getXREF().get(0).getSRCPKEY());
						upsertPartyResponse.setStatus("Contact record does not meet minimum data criteria,hence bypassing Contact insertion: "+
								curParty.getXREF().get(0).getSRCPKEY());
					}	*/
					}
				} else if (Constant.BO_CLASS_CODE_ORG.equalsIgnoreCase(boClassCode)) {
					processUpsertRequestForIndividualAccount(curParty, upsertPartyResponse);
				} else {
					LOG.debug("Invalid BO Class Code for Party record::" + curParty.getXREF().get(0).getSRCPKEY());
					createAccountUpsertErrorResponse(upsertPartyResponse, Constant.ERROR_ACCOUNT_EMPTY_BO_CODE,
							curParty.getXREF().get(0).getSRCPKEY());
				}
			} catch (ServiceProcessingException servexp) {
				LOG.error("Caught ServiceProcessingException in processMarketingUpsertRequest()", servexp);
			} catch (Exception exp) {
				LOG.error("Caught exception in processMarketingUpsertRequest()", exp);
			}
			/* removed due to japan record publish */
			/* Started for US-727 Checking with ELQ Contact Associated with Japan country or not  */
			/*if(isELQContactAssociatedWithJapan(curParty,upsertPartyResponse)) {
				if(CollectionUtils.isEmpty(upsertPartyResponse.getParty())) {
					LOG.debug("The ELQ Account/Contact is assoicted with Japan: "+ upsertPartyResponse.getErrorMsg());
				} else {
					LOG.debug("The ELQ Account/Contact is assoicted with Japan RowId Object is: "+upsertPartyResponse.getParty().get(0).getROWIDOBJECT());
				}
			}*/
			/* Ended for US-727 Checking with ELQ Contact Associated with Japan country or not  */
			
			
		}

		
		if (Util.isNullOrEmpty(upsertPartyResponse.getStatus())) {
			upsertPartyResponse.setStatus("Processing completed for " + partyCount + " Party(ies).");
		} else {
			upsertPartyResponse.setStatus(
					"Processing completed for " + partyCount + " Party(ies).\n" + upsertPartyResponse.getStatus());
		
		}
		
		
		LOG.debug("[processMarketingUpsertRequest] EXIT");
		return upsertPartyResponse;
	}
	
	/* Started for US-727 Checking with ELQ Contact Associated with Japan country or not  */
	public boolean isELQContactAssociatedWithJapan(PartyXrefType curParty, UpsertPartyResponse upsertResponse){
		LOG.debug("[isELQContactAssociatedWithJapan] ENTER");
		boolean isElqAssociatedJapan = Boolean.FALSE;
		String srcSystem = curParty.getXREF().get(0).getSRCSYSTEM();
		String country_CD = curParty.getAddress().get(0).getCOUNTRYCD();
		//String srcSystem = curParty.getParty().get(0).getAddress().get(0).getSRCSYSTEM();
		//String country_CD = curParty.getParty().get(0).getAddress().get(0).getCOUNTRYCD();
		
           if (!Util.isNullOrEmpty(upsertResponse.getErrorCd())){
        	   isElqAssociatedJapan = Boolean.FALSE;
        	   LOG.debug("MessageCode is " + upsertResponse.getErrorCd());
		}else if(srcSystem.equalsIgnoreCase("ELQ") && country_CD.equalsIgnoreCase("JP") ){
			isElqAssociatedJapan=true;
			LOG.debug("The ELQ contact is associated with Japan  " + isElqAssociatedJapan);
			upsertResponse.setErrorCd(prospectPartyDAO.getErrorCodeByDescription(
					messagesProp.getProperty(Constant.QUERY_ELQCNT_ASSOCIATED_JAPAN)));
			}
		LOG.debug("[isELQContactAssociatedWithJapan] EXIT");
		return isElqAssociatedJapan;
	}
	/* Ended for  US-727  Checking with ELQ Contact Associated with Japan country or not  */
	
	/* Added for US68-Throughput Tracker START */
	
	/**
	 * validate input MSG_TRKN_ID
	 * 
	 * @param curParty
	 * @param upsertResponse
	 */
	private void validateMsgTrackingId(PartyXrefType curParty, UpsertPartyResponse upsertResponse) {
		LOG.debug("[validateMsgTrackingId] ENTER");
		if(Util.isNullOrEmpty(curParty.getMSGTRKNID())) {
			String respMsg = messagesProp.getProperty(Constant.INFO_MSG_TRKN_ID_VALIDATION);
			if (Util.isNullOrEmpty(upsertResponse.getStatus())) {
				upsertResponse.setStatus(respMsg);
			} else {
				upsertResponse.setStatus(upsertResponse.getStatus() + "\n" + respMsg);
			}
		}
		LOG.debug("[validateMsgTrackingId] EXIT");
	}
	
	/* Added for US68-Throughput Tracker END */
	
	/* Added for US33-"UNKNOWN Prospect" Tracker START */
	
	/**
	 * validate input REPORTED_COMPANY_NAME
	 * 
	 * @param curParty
	 * @param upsertResponse
	 */
	private boolean validateCompanyName(PartyXrefType curParty, UpsertPartyResponse upsertResponse) {
		LOG.debug("[validateCompanyName] START");
		Boolean isValid = Boolean.TRUE;
		boolean nameExclusionCond = Boolean.FALSE;
		
		try {
			String srcPkey = curParty.getXREF().get(0).getSRCPKEY();
			/*Checking	IF REPORTED_COMPANY_NAME is NOT NULL)	*/
			if (curParty.getPartyPerson() != null) {
				
				String reptdCompName = curParty.getPartyPerson().get(0).getREPORTEDCOMPANYNAME();
				if(Util.isNullOrEmpty(reptdCompName)){
					isValid = Boolean.FALSE;
					createContactUpsertInfoMessage(upsertResponse, Constant.INFO_CONTACT_EMPTY_REPTD_COMP_NAME, srcPkey);
				}else {
					nameExclusionCond = prospectPartyDAO.isNameExclusionExists(reptdCompName);
					if(nameExclusionCond)	{
						isValid = Boolean.FALSE;
						LOG.info("Junk Value in REPORTED_COMP_NAME is found :"+nameExclusionCond);
						createContactUpsertInfoMessage(upsertResponse, Constant.INFO_CONTACT_REPTD_COMP_NAME_UNKWN, srcPkey);
						/* Changed for US449 START */
						upsertResponse.setErrorCd(prospectPartyDAO.getErrorCodeByDescription(
								messagesProp.getProperty(Constant.INFO_CONTACT_REPTD_COMP_NAME_UNKWN)));
						/* Changed for US449 END */
					}
				}
			}else {
				isValid = Boolean.FALSE;
				createContactUpsertInfoMessage(upsertResponse, Constant.INFO_CONTACT_EMPTY_REPTD_COMP_NAME, srcPkey);
			}
		} catch (Exception sqlEx) {
			LOG.error("Exception occurred in validateCompanyName: ", sqlEx);
			//sqlEx.printStackTrace();
			ServiceProcessingException customException = new ServiceProcessingException(sqlEx);
			customException.setMessage("Custom Exception occurred in validateCompanyName: " + sqlEx.getMessage());
		//	throw customException;
		} 
		LOG.debug("[validateCompanyName] EXIT::isValid::" + isValid);
		return isValid;
	}
	
	/*
	 * Validate Contact address or city have junk
	 * 
	 * @param curParty
	 * 
	 * @param upsertResponse
	 */
	private boolean validateContactAddress(PartyXrefType curParty,
			UpsertPartyResponse upsertResponse) {
		LOG.debug("[validateContactAddress] START");
		Boolean isValid = Boolean.TRUE;
		boolean junkAddressLn1 = Boolean.FALSE;
		boolean junkCity = Boolean.FALSE;

		try {
			String srcPkey = curParty.getXREF().get(0).getSRCPKEY();
			String addressLn1 = curParty.getAddress().get(0).getADDRLN1();
			String city = curParty.getAddress().get(0).getCITY();
			if (!Util.isNullOrEmpty(addressLn1)) {

				junkAddressLn1 = prospectPartyDAO.isJunkAddressLn1(addressLn1);

				if (junkAddressLn1) {
					isValid = Boolean.FALSE;
					LOG.info("Junk Value in addressLn1 is found :"
							+ junkAddressLn1);
					createContactUpsertInfoMessage(upsertResponse,
							Constant.INFO_ADDRESS_UNKNOWN_JUNK, srcPkey);

					upsertResponse
							.setErrorCd(prospectPartyDAO.getErrorCodeByDescription(messagesProp
									.getProperty(Constant.INFO_ADDRESS_UNKNOWN_JUNK)));
				}

			}

			if (!Util.isNullOrEmpty(city)) {

				junkCity = prospectPartyDAO.isJunkCity(city);

				if (junkCity) {
					isValid = Boolean.FALSE;
					LOG.info("Junk Value in CITY is found :" + junkCity);
					createContactUpsertInfoMessage(upsertResponse,
							Constant.INFO_ADDRESS_UNKNOWN_JUNK, srcPkey);
					/* Changed for US449 START */
					upsertResponse
							.setErrorCd(prospectPartyDAO.getErrorCodeByDescription(messagesProp
									.getProperty(Constant.INFO_ADDRESS_UNKNOWN_JUNK)));
				}
			}
		} catch (Exception sqlEx) {
			LOG.error("Exception occurred in validateContactAddress: ", sqlEx);
			// sqlEx.printStackTrace();
			ServiceProcessingException customException = new ServiceProcessingException(
					sqlEx);
			customException
					.setMessage("Custom Exception occurred in validateContactAddress: "
							+ sqlEx.getMessage());
			// throw customException;
		}
		LOG.debug("[validateContact Address] EXIT::isValid::" + isValid);
		return isValid;

	}
	// Validate account address for Junk condition
		private boolean validateAccountAddressJunk(PartyXrefType curParty,
				UpsertPartyResponse upsertResponse) {
			LOG.debug("[validateAccountAddressJunk] START");
			Boolean isValid = Boolean.TRUE;
			boolean junkAddressLn1 = Boolean.FALSE;
			boolean junkCity = Boolean.FALSE;

			try {
				String srcPkey = curParty.getXREF().get(0).getSRCPKEY();
				String addressLn1 = curParty.getAddress().get(0).getADDRLN1();
				String city = curParty.getAddress().get(0).getCITY();
				if (!Util.isNullOrEmpty(addressLn1)) {
					junkAddressLn1 = prospectPartyDAO.isJunkAddressLn1(addressLn1);
					if (junkAddressLn1) {
						isValid = Boolean.FALSE;
						LOG.info(" Junk in AdressLn1 found : " + junkAddressLn1);
						createAccountUpsertInfoMessage(upsertResponse,
								Constant.INFO_ADDRESS_UNKNOWN_JUNK, srcPkey);

						upsertResponse
								.setErrorCd(prospectPartyDAO.getErrorCodeByDescription(messagesProp
										.getProperty(Constant.INFO_ADDRESS_UNKNOWN_JUNK)));

					}
				} 
				if (!Util.isNullOrEmpty(city)) {
					junkCity = prospectPartyDAO.isJunkCity(city);
					if (junkCity) {
						isValid = Boolean.FALSE;
						LOG.info("Junk Value in CITY found : " + junkCity);
						createAccountUpsertInfoMessage(upsertResponse,
								Constant.INFO_ADDRESS_UNKNOWN_JUNK, srcPkey);
						upsertResponse
								.setErrorCd(prospectPartyDAO.getErrorCodeByDescription(messagesProp
										.getProperty(Constant.INFO_ADDRESS_UNKNOWN_JUNK)));
					}

				}
			} catch (Exception sqlEx) {
				LOG.error("Exception occurred in validateAccountAddressJunk: ",
						sqlEx);
				ServiceProcessingException customException = new ServiceProcessingException(
						sqlEx);
				customException
						.setMessage("Custom Exception occurred in validateAccountAddressJunk: "
								+ sqlEx.getMessage());
				// throw customException;
			}
			LOG.debug("[validateAccountAddressJunk] EXIT::isValid::" + isValid);
			return isValid;

		}

		// validateAccountAddressNullUnknown
		private boolean validateAccountAddressNullUnknown(PartyXrefType curParty,
				UpsertPartyResponse upsertResponse) {
			LOG.debug("[validateAccountAddressNullUnknown] START");
			Boolean isValid = Boolean.TRUE;
			try {
				String srcPkey = curParty.getXREF().get(0).getSRCPKEY();

				List<AddressXrefType> addressXrefTypeList = curParty.getAddress();
				if (!CollectionUtils.isEmpty(addressXrefTypeList)) {

					String addressLn1 = curParty.getAddress().get(0).getADDRLN1();
					String city = curParty.getAddress().get(0).getCITY();

					if (Util.isNullOrEmpty(addressLn1) || Util.isNullOrEmpty(city)
							|| addressLn1.trim().equalsIgnoreCase("Unknown")
							|| city.trim().equalsIgnoreCase("Unknown")) {
						isValid = Boolean.FALSE;
						LOG.info(" Account AddressLn1 or city null or UnKnown  found :" +isValid );
						createAccountUpsertInfoMessage(upsertResponse,
								Constant.INFO_ADDRESS_UNKNOWN_JUNK, srcPkey);
						upsertResponse
								.setErrorCd(prospectPartyDAO.getErrorCodeByDescription(messagesProp
										.getProperty(Constant.INFO_ADDRESS_UNKNOWN_JUNK)));

					}

				}

			} catch (Exception sqlEx) {
				LOG.error(
						"Exception occurred in validateAccountAddressNullUnknown : ",
						sqlEx);
				// sqlEx.printStackTrace();
				ServiceProcessingException customException = new ServiceProcessingException(
						sqlEx);
				customException
						.setMessage("Custom Exception occurred in Account validateAddress for null or UnKnown: "
								+ sqlEx.getMessage());
				// throw customException;
			}
			LOG.debug("[validateAccountAddressNullUnknown] EXIT::isValid::"
					+ isValid);
			return isValid;

		}

	
	/**
	 * validate input Prospect ACCOUNT_NAME
	 * 
	 * @param curParty
	 * @param upsertResponse
	 */
	private boolean validateAccountName(PartyXrefType curParty, UpsertPartyResponse upsertResponse) {
		LOG.debug("[validateAccountName] START");
		Boolean isValid = Boolean.TRUE;
		boolean nameExclusionCond = Boolean.FALSE;
		
		try {
			String srcPkey = curParty.getXREF().get(0).getSRCPKEY();
			
			if ( !Util.isNullOrEmpty(curParty.getPARTYNAME()) ) {
				String accountName = curParty.getPARTYNAME();
				nameExclusionCond = prospectPartyDAO.isNameExclusionExists(accountName);
				if(nameExclusionCond)	{
					isValid = Boolean.FALSE;
					LOG.info("Junk Value in Prospect ACCOUNT_NAME is found :"+nameExclusionCond);
					createContactUpsertInfoMessage(upsertResponse, Constant.INFO_PROSPECT_ACCOUNT_NAME_UNKWN, srcPkey);
					/* Changed for US449 START */
					upsertResponse.setErrorCd(prospectPartyDAO.getErrorCodeByDescription(
							messagesProp.getProperty(Constant.INFO_PROSPECT_ACCOUNT_NAME_UNKWN)));
					/* Changed for US449 END */
				}
			}else {
				isValid = Boolean.FALSE;
				createAccountUpsertInfoMessage(upsertResponse, Constant.ERROR_ACCOUNT_EMPTY_NAME, srcPkey);
			}
		} catch (Exception sqlEx) {
			LOG.error("Exception occurred in validateAccountName: ", sqlEx);
			//sqlEx.printStackTrace();
			ServiceProcessingException customException = new ServiceProcessingException(sqlEx);
			customException.setMessage("Custom Exception occurred in validateAccountName: " + sqlEx.getMessage());
		//	throw customException;
		} 
		LOG.debug("[validateAccountName] EXIT::isValid::" + isValid);
		return isValid;
	}
	
	/* Added for US33-"UNKNOWN Prospect" Tracker END */
	
	/**
	 * Validates input contact data
	 * 
	 * @param partyXrefType
	 * @param upsertResponse
	 * @return isValid
	 */
	public boolean validateContactRequest(PartyXrefType curParty, UpsertPartyResponse upsertResponse) {
		LOG.debug("[validateContactRequest] START");
		Boolean isValid = Boolean.TRUE;
		String srcPkey = curParty.getXREF().get(0).getSRCPKEY();
		
	/*Checking	IF (FIRSTNAME is NOT NULL OR LASTNAME is NOT NULL) AND (REPORTED_COMPANY_NAME is NOT NULL)	*/
		if (curParty.getPartyPerson() != null) {
			
			String fName = curParty.getPartyPerson().get(0).getFIRSTNAME();
			String lName = curParty.getPartyPerson().get(0).getLASTNAME();
			String reptdCompName = curParty.getPartyPerson().get(0).getREPORTEDCOMPANYNAME();
			if ( Util.isNullOrEmpty(fName) && Util.isNullOrEmpty(lName) ){
				isValid = Boolean.FALSE;
				createContactUpsertInfoMessage(upsertResponse, Constant.INFO_CONTACT_EMPTY_FNAME_LNAME, srcPkey);
			}else if(Util.isNullOrEmpty(reptdCompName)){
				isValid = Boolean.FALSE;
				createContactUpsertInfoMessage(upsertResponse, Constant.INFO_CONTACT_EMPTY_REPTD_COMP_NAME, srcPkey);
			}
		}else {
			isValid = Boolean.FALSE;
			createContactUpsertInfoMessage(upsertResponse, Constant.INFO_CONTACT_EMPTY_REPTD_COMP_NAME, srcPkey);
		}
		
//		if (Util.isNullOrEmpty(curParty.getPARTYNAME())) {
		/*Checking if Email_Address from Communication is NULL OR NOT NULL*/
			List<CommunicationXrefType> commXrefTypeList = curParty.getCommunication();
			if (CollectionUtils.isEmpty(commXrefTypeList)) {
				isValid = Boolean.FALSE;
				createContactUpsertInfoMessage(upsertResponse, Constant.INFO_CONTACT_EMPTY_EMAIL_ADDR, srcPkey);
			} else {
				Boolean isEmailValuePresent = Boolean.FALSE;
				for (CommunicationXrefType commXrefType : commXrefTypeList) {
					if (commXrefType.getCOMMTYPE().equalsIgnoreCase("Email")) {
							if( !Util.isNullOrEmpty(commXrefType.getCOMMVALUE()) ){
							isEmailValuePresent = Boolean.TRUE;
							break;
						}
					}
				}
				if (!isEmailValuePresent) {
					isValid = Boolean.FALSE;
					createContactUpsertInfoMessage(upsertResponse, Constant.INFO_CONTACT_EMPTY_EMAIL_ADDR, srcPkey);
				}
			}
//		} else {
			/*Checking if Country_Cd from Address is NULL OR NOT NULL*/
			List<AddressXrefType> addressXrefTypeList = curParty.getAddress();
			if (CollectionUtils.isEmpty(addressXrefTypeList)) {
				isValid = Boolean.FALSE;
				createContactUpsertInfoMessage(upsertResponse, Constant.INFO_CONTACT_EMPTY_COUNTRY, srcPkey);
			} else {
				Boolean isCountryFound = Boolean.FALSE;
				for (AddressXrefType addressXrefType : addressXrefTypeList) {
					if (!Util.isNullOrEmpty(addressXrefType.getCOUNTRYCD())) {
						isCountryFound = Boolean.TRUE;
						break;
					}
				}
				if (!isCountryFound) {
					isValid = Boolean.FALSE;
					createContactUpsertInfoMessage(upsertResponse, Constant.INFO_CONTACT_EMPTY_COUNTRY, srcPkey);
				}
			}
//		}
		LOG.debug("[validateContactRequest] EXIT::isValid::" + isValid);
		return isValid;
	}
	
	/**
	 * Create Info messages for Contact upsert
	 * 
	 * @param upsertResponse
	 * @param errorPropId
	 * @param srcPkey
	 */
	private void createContactUpsertInfoMessage(UpsertPartyResponse upsertResponse, String infoPropId, String srcPkey) {
		LOG.debug("[createContactUpsertInfoMessage] START::srcPkey::" + srcPkey);
		String respMsg = null;
		if (srcPkey == null) {
			respMsg = messagesProp.getProperty(infoPropId);
		} else {
			respMsg = "SRC PKEY::" + srcPkey + "::" + messagesProp.getProperty(infoPropId);
		}
		if (Util.isNullOrEmpty(upsertResponse.getStatus())) {
			upsertResponse.setStatus(respMsg);
		} else {
			upsertResponse.setStatus(upsertResponse.getStatus() + "\n" + respMsg);
		}
		LOG.debug("[createContactUpsertInfoMessage] EXIT");
	}

	/**
	 * Processes upsert action for a marketing account
	 * 
	 * @param partyXrefType
	 * @param upsertResponse
	 * @throws ServiceProcessingException
	 */
	private void processUpsertRequestForIndividualAccount(PartyXrefType partyXrefType,
			UpsertPartyResponse upsertResponse) throws ServiceProcessingException {
		LOG.debug("[processUpsertRequestForIndividualAccount] START");
		try {
			
			/** Modified for US-33: MDM service will reject any contact / account that comes with company name of Unknown START*/
			if(!validateAccountName(partyXrefType, upsertResponse)){
				//Prospect Account name  is Not Valid
				LOG.debug(
						"ELQ Account record does not have Valid PARTY_NAME, hence bypassing ELQ Account insertion: ");
				return;
			}
			/** Modified for US-33: MDM service will reject any contact / account that comes with company name of Unknown END*/
			
			if (validateAccountRequest(partyXrefType, upsertResponse)) {
				if (partyXrefType.getPartyRel() != null) {
					List<PartyContactRelationshipXrefType> contactRelXrefTypeList = partyXrefType.getPartyRel()
							.getPARTYPERSONREL();
					if (CollectionUtils.isEmpty(contactRelXrefTypeList)) {
						LOG.debug("[processUpsertRequestForIndividualAccount] No Contact Rel found");
					} else {
						List<String> contactPkeyList = new ArrayList<String>();
						for (PartyContactRelationshipXrefType contactRelationshipXrefType : contactRelXrefTypeList) {
							if (!Util.isNullOrEmpty(contactRelationshipXrefType.getSRCPKEY())) {
								contactPkeyList.add(contactRelationshipXrefType.getSRCPKEY());
							}
						}
						if (CollectionUtils.isEmpty(contactPkeyList)) {
							LOG.debug("[processUpsertRequestForIndividualAccount] No Contact Pkey found");
						} else {
							if (prospectPartyDAO.isContactAssociatedWithCustomerOrDNB(contactPkeyList)) {
								createAccountUpsertInfoMessage(upsertResponse, Constant.INFO_CONTACT_ASSOCIATED, null);
								//US#581 send error code 805 for Contact associated with existing customer / DNB record. Request is not processed.
								upsertResponse.setErrorCd(prospectPartyDAO.getErrorCodeByDescription(
										messagesProp.getProperty(Constant.INFO_CONTACT_ASSOCIATED)));
								//
								return;
							}
						}
					}
				}
				List<String> srcPkeyList = retrieveAndValidateAccountPkey(partyXrefType, upsertResponse);
				if (CollectionUtils.isEmpty(srcPkeyList)) {
					LOG.debug("[processUpsertRequestForIndividualAccount] SRC PKEY List is NULL or EMPTY");
				} else {
					LOG.debug("[processUpsertRequestForIndividualAccount] srcPkeyList::" + srcPkeyList);
					for (String srcPkey : srcPkeyList) {
						partyXrefType.getXREF().get(0).setSRCPKEY(srcPkey);
						upsertIndividualAccount(partyXrefType, upsertResponse);
					}
				}
			}
		} catch (Exception exp) {
			LOG.error("[processUpsertRequestForIndividualAccount]Caught exception in processMarketingUpsertRequest()",
					exp);
			if (!(exp instanceof ServiceProcessingException)) {
				createAccountUpsertErrorResponse(upsertResponse, Constant.ERROR_UPSERT_ACCOUNT_EXCEPTION, null, exp);
			}
		}
		
		
		LOG.debug("[processUpsertRequestForIndividualAccount] EXIT");
	}

	/**
	 * Validates input account data
	 * 
	 * @param partyXrefType
	 * @param upsertResponse
	 * @return isValid
	 */
	public boolean validateAccountRequest(PartyXrefType partyXrefType, UpsertPartyResponse upsertResponse) {
		LOG.debug("[validateAccountRequest] START");
		Boolean isValid = Boolean.TRUE;
		String srcPkey = partyXrefType.getXREF().get(0).getSRCPKEY();
		if (!Util.isNullOrEmpty(partyXrefType.getUCN()) && Util.isNullOrEmpty(srcPkey)) {
			isValid = Boolean.FALSE;
			createAccountUpsertInfoMessage(upsertResponse, Constant.INFO_ACCOUNT_EMPTY_PKEY, null);
			//US#581 send error code 806 for SRC Pkey not found for account with UCN
			upsertResponse.setErrorCd(prospectPartyDAO.getErrorCodeByDescription(
					messagesProp.getProperty(Constant.INFO_ACCOUNT_EMPTY_PKEY)));
			//	
		} else if (Util.isNullOrEmpty(partyXrefType.getPARTYNAME())) {
			isValid = Boolean.FALSE;
			createAccountUpsertInfoMessage(upsertResponse, Constant.ERROR_ACCOUNT_EMPTY_NAME, srcPkey);
		} else {
			List<AddressXrefType> addressXrefTypeList = partyXrefType.getAddress();
			if (CollectionUtils.isEmpty(addressXrefTypeList)) {
				isValid = Boolean.FALSE;
				createAccountUpsertInfoMessage(upsertResponse, Constant.ERROR_ACCOUNT_EMPTY_COUNTRY, srcPkey);
			} else {
				Boolean isCountryFound = Boolean.FALSE;
				for (AddressXrefType addressXrefType : addressXrefTypeList) {
					if (!Util.isNullOrEmpty(addressXrefType.getCOUNTRYCD())) {
						isCountryFound = Boolean.TRUE;
						break;
					}
				}
				if (!isCountryFound) {
					isValid = Boolean.FALSE;
					createAccountUpsertInfoMessage(upsertResponse, Constant.ERROR_ACCOUNT_EMPTY_COUNTRY, srcPkey);
				}
			}
		}
		LOG.debug("[validateAccountRequest] EXIT::isValid::" + isValid);
		return isValid;
	}

	/**
	 * Retrieving and validating Account Pkey
	 * <ol>
	 * <li>Checks in pay-load for Pkey. if not found then creates Account PKey
	 * </li>
	 * <li>Validate if the Pkey already associated with a deleted party</li>
	 * <li>Validate if the Pkey already associated with a DNB Cluster</li>
	 * </ol>
	 * 
	 * @param partyXrefType
	 * @param upsertResponse
	 * @return accountPkeyList
	 */
	private List<String> retrieveAndValidateAccountPkey(PartyXrefType partyXrefType,
			UpsertPartyResponse upsertResponse) {
		LOG.debug("[retrieveAndValidateAccountPkey] START");
		List<String> accountPkeyList = new ArrayList<String>();
		String mdmUcn = partyXrefType.getUCN();
		String srcSystem = partyXrefType.getXREF().get(0).getSRCSYSTEM();
		if (Util.isNullOrEmpty(mdmUcn)) {
			if (partyXrefType.getPartyRel() != null) {
				List<PartyContactRelationshipXrefType> contactRelXrefTypeList = partyXrefType.getPartyRel()
						.getPARTYPERSONREL();
				if (CollectionUtils.isEmpty(contactRelXrefTypeList)) {
					LOG.debug("[retrieveAndValidateAccountPkey] No Contact Rel found");
					createAccountUpsertErrorResponse(upsertResponse, Constant.ERROR_CREATE_ACCOUNT_PKEY_NO_CONTACT,
							null);
				} else {
					for (PartyContactRelationshipXrefType contactRelationshipXrefType : contactRelXrefTypeList) {
						String accountPkey = createAccountPkey(contactRelationshipXrefType.getSRCPKEY());
						if (validateAccountPkey(accountPkey, srcSystem, upsertResponse)) {
							accountPkeyList.add(accountPkey);
						}
					}
				}
			} else {
				LOG.debug("[retrieveAndValidateAccountPkey] No Party Rel found");
				createAccountUpsertErrorResponse(upsertResponse, Constant.ERROR_CREATE_ACCOUNT_PKEY_NO_CONTACT, null);
			}
		} else {
			String accountPkey = partyXrefType.getXREF().get(0).getSRCPKEY();
			if (validateAccountPkey(accountPkey, srcSystem, upsertResponse)) {
				accountPkeyList.add(accountPkey);
			}
		}
		LOG.debug("[retrieveAndValidateAccountPkey] EXIT::accountPkeyList::" + accountPkeyList);
		return accountPkeyList;
	}

	/**
	 * Creates Account PKey for new account
	 * 
	 * @param partyXrefType
	 * @return accountPkey
	 */
	private String createAccountPkey(String contactPkey) {
		LOG.debug("[createAccountPkey] START");
		StringBuilder accountPkey = new StringBuilder(Constant.PROSPECT_ACCOUNT_PKEY_PREFIX);
		accountPkey.append(Constant.STR_DASH);
		accountPkey.append(contactPkey);
		LOG.debug("[createAccountPkey] EXIT::accountPkey::" + accountPkey.toString());
		return accountPkey.toString();
	}

	/**
	 * Validates account PKey
	 * 
	 * @param srcPkey
	 * @param srcSystem
	 * @param upsertResponse
	 * @return isValid
	 */
	private boolean validateAccountPkey(String srcPkey, String srcSystem, UpsertPartyResponse upsertResponse) {
		LOG.debug("[validateAccountPkey] START");
		Boolean isValid = Boolean.TRUE;
		if (prospectPartyDAO.isDeletedExistForPkey(srcPkey, srcSystem)) {
			isValid = Boolean.FALSE;
			createAccountUpsertInfoMessage(upsertResponse, Constant.INFO_ACCOUNT_EXISTING_DELETED_CLUSTER, srcPkey);
		} else if (prospectPartyDAO.isDNBClusterExistForPkey(srcPkey, srcSystem)) {
			isValid = Boolean.FALSE;
			createAccountUpsertInfoMessage(upsertResponse, Constant.INFO_ACCOUNT_EXISTING_DUNS_CLUSTER, srcPkey);
		}
		if (!isValid) {
			// US#581 send error code 805.Request is not processed.
			upsertResponse.setErrorCd(prospectPartyDAO
					.getErrorCodeByDescription(messagesProp
							.getProperty(Constant.INFO_CONTACT_ASSOCIATED)));
			//
		}
		LOG.debug("[validateAccountPkey] EXIT::isValid::" + isValid);
		return isValid;
	}

	/**
	 * Upsert a marketing account
	 * 
	 * @param partyXrefType
	 * @param upsertResponse
	 */
	private void upsertIndividualAccount(PartyXrefType partyXrefType, UpsertPartyResponse upsertResponse) {
		LOG.debug("[upsertIndividualAccount] START :: Processing for srcPkey::"
				+ partyXrefType.getXREF().get(0).getSRCPKEY());
		String srcPkey = null;
		int countOfRetry = Integer.parseInt(configProps.getProperty("NoOfRetries"));
		boolean isMultiGeoMatchSuccess = false;
		boolean isStrictMatchProspect = false;
		boolean isMergeELQPartySuccess = false;
		boolean isMergeELQAddressSuccess = false;
		boolean isMergeELQProspectSuccess = false;
		
		try {
			String srcSystem = partyXrefType.getXREF().get(0).getSRCSYSTEM();
			String mdmUcn = partyXrefType.getUCN();
			String rowIdParty = null;
			String rowIdProspect = null;
			String rowIdAddress = null;

			srcPkey = partyXrefType.getXREF().get(0).getSRCPKEY();

			Map<String, Integer> mrktRowIdCountMap = prospectPartyDAO.getExistingRowIdAndProspectRecordCount(srcPkey,
					srcSystem);
			Integer mrktRowCount = 0;
			if (!mrktRowIdCountMap.isEmpty()) {
				rowIdParty = mrktRowIdCountMap.keySet().iterator().next();
				if (!Util.isNullOrEmpty(rowIdParty)) {
					mrktRowCount = mrktRowIdCountMap.get(rowIdParty);
				}
			}
			if (mrktRowCount > 0) {
				LOG.debug("[updateProspectAccount] Found Marketing XRef without DNB");
				updateProspectAccount(partyXrefType, srcSystem, srcPkey, mrktRowCount, upsertResponse);
			} else {
				LOG.debug("[upsertIndividualAccount] Marketing XRef without DNB not found");
				if (Util.isNullOrEmpty(mdmUcn)) {
					LOG.debug("[upsertIndividualAccount] Marketing account without UCN");
					Boolean needToMerge = Boolean.FALSE;
					Boolean foundCustomerMatch = Boolean.FALSE;
					String targetRowId = null;
					String targetRowIdAddr = null;
					String targetRowIdProspect = null;
					Map<String, List<String>> rowIdMap = null;
					try {
						rowIdMap = searchProspectDao
							.findBestMatchedMultiGeoCityOrSingletonDunsAccount(partyXrefType);
						LOG.debug("[upsertIndividualAccount]: findBestMatchedMultiGeoCityOrSingletonDunsAccount is Completed successfully !");
					} catch (Exception ex) {
					//	mergeInd = false;
						LOG.error("[upsertIndividualAccount]: Exception occured while findBestMatchedMultiGeoCityOrSingletonDunsAccount: " , ex);
						for(int i = 0; i<countOfRetry; i++)	{
							try{
								LOG.debug("[upsertIndividualAccount]: Retrying findBestMatchedMultiGeoCityOrSingletonDunsAccount for "+ (i+1) +"th time");
								rowIdMap = searchProspectDao.findBestMatchedMultiGeoCityOrSingletonDunsAccount(partyXrefType);
								LOG.debug("[upsertIndividualAccount]: findBestMatchedMultiGeoCityOrSingletonDunsAccount is successful on attempt no. "+ (i+1));
								isMultiGeoMatchSuccess = true;
						//		mergeInd = true;
								break;
							} catch (Exception excp) {
								LOG.error("[upsertIndividualAccount]: Exception occured in findBestMatchedMultiGeoCityOrSingletonDunsAccount"
										+ " RetryMechanism on attempt no. "+ (i+1));
								LOG.error("[upsertIndividualAccount]: Exception occured in findBestMatchedMultiGeoCityOrSingletonDunsAccount RetryMechanism");
							}
						}
						if(!isMultiGeoMatchSuccess){
							ServiceProcessingException customException = new ServiceProcessingException(ex);
							customException.setMessage("[upsertIndividualAccount]: Exception occured in findBestMatchedMultiGeoCityOrSingletonDunsAccount "
									+ "RetryMechanism: " + customException.getMessage());
							throw customException;
						}
					}
					if (rowIdMap == null || rowIdMap.isEmpty()) {
						/**
						 * Modified for US-523 MDM service will reject any
						 * account that comes with Junk AddressLn1 or City STOP
						 **/
						LOG.debug("[upsertIndividualAccount] Customer match not found check for Account Address for Null or Unknown");
						// validate blank/null in address line 1 or city
						if (!validateAccountAddressNullUnknown(partyXrefType,
								upsertResponse)) {
							// REPORTED ADDRESS OR CITY HAVE null or unknown
							LOG.debug("ELQ Account record have NULL or Unknown "
									+ partyXrefType.getXREF().get(0)
											.getSRCPKEY());
						}
						LOG.debug("[upsertIndividualAccount] Customer match not found check for Account Address for Junk");
						if (!validateAccountAddressJunk(partyXrefType,
								upsertResponse)) {
							// REPORTED ADDRESS OR CITY HAVE JUNK
							LOG.debug("ELQ Contact record have AddressLn1 or city junk Rejecting::"
									+ partyXrefType.getXREF().get(0)
											.getSRCPKEY());
							return;
						}

						LOG.debug(
								"[upsertIndividualAccount] No Multi Geo match found. Creating account with input details");
						Map<String, Object> dataHolderMap = processCleansePutRequest(partyXrefType, upsertResponse);
						rowIdParty = ((PutResponseDataHolder) dataHolderMap.get(MDMAttributeNames.ENTITY_PARTY))
								.getRowidObject();
						rowIdAddress = ((List<PutResponseDataHolder>) dataHolderMap
								.get(MDMAttributeNames.ENTITY_ADDRESS)).get(0).getRowidObject();
						rowIdProspect = ((List<PutResponseDataHolder>) dataHolderMap
								.get(MDMAttributeNames.ENTITY_PROSPECT)).get(0).getRowidObject();
						targetRowId = rowIdParty;
						Set<String> rowIds = null;
						
						PutResponseDataHolder putRespDataParty = (PutResponseDataHolder)
								dataHolderMap.get(MDMAttributeNames.ENTITY_PARTY);
						
						/* US528 C/O Account issue
						 * By Pass match merge process if Account C/O 
						 */
						LOG.debug("isMatchExclusionPatternExists for prospect account created");
						boolean exclusionPatternExists = false;
						try {
							exclusionPatternExists = isMatchExclusionPatternExists(putRespDataParty.getRowidObject());
						} catch (Exception Excp) {

							LOG.error(
									"Caught exception in isMatchExclusionPatternExists: ",
									Excp);
							// Create Task for Tokenization failure
							String title = "Creating GenericTask to manually update the consolidation_ind to 9.";
							String comment = "Failed while updating consolidation indicator of the Party with 9 for the PartyID: "
									+ putRespDataParty.getRowidObject();
							processCreateTaskRequest(null,
									putRespDataParty.getRowidObject(),
									"FinalReview", title, comment);
						}
						if (exclusionPatternExists) {
							LOG.debug("[upsertIndividualAccount] By passing match merge process for " + putRespDataParty.getRowidObject());	
							needToMerge = Boolean.FALSE;

						} else {
							
							LOG.debug("Processing strict match for prospect account ");	
							try {
								rowIds = searchProspectDao.findStrictMatchProspect(partyXrefType, rowIdParty);
								LOG.debug("[upsertIndividualAccount]: findStrictMatchProspect is Completed successfully !");
							} catch (Exception ex) {
								//	mergeInd = false;
								LOG.error("[upsertIndividualAccount]: Exception occured while findStrictMatchProspect: " , ex);
								for(int i = 0; i<countOfRetry; i++)	{
									try{
										LOG.debug("[upsertIndividualAccount]: Retrying findStrictMatchProspect for "+ (i+1) +"th time");
										rowIds = searchProspectDao.findStrictMatchProspect(partyXrefType, rowIdParty);
										LOG.debug("[upsertIndividualAccount]: findStrictMatchProspect is successful on attempt no. "+ (i+1));
										isStrictMatchProspect = true;
								//		mergeInd = true;
										break;
									} catch (Exception excp) {
										LOG.error("[upsertIndividualAccount]: Exception occured in findStrictMatchProspect"
												+ " RetryMechanism on attempt no. "+ (i+1));
										LOG.error("[upsertIndividualAccount]: Exception occured in findStrictMatchProspect RetryMechanism");
									}
								}
								if(!isStrictMatchProspect){
									ServiceProcessingException customException = new ServiceProcessingException(ex);
									customException.setMessage("[upsertIndividualAccount]: Exception occured in findStrictMatchProspect "
											+ "RetryMechanism: " + customException.getMessage());
									throw customException;
								}
							}
							if (CollectionUtils.isEmpty(rowIds)) {
								LOG.debug("[upsertIndividualAccount] No Strict Match found");
							} else {
								List<PartyChildRowIdData> partyChildDataList = prospectPartyDAO.getPartyChildRowId(rowIds);
								if (CollectionUtils.isEmpty(partyChildDataList)) {
									LOG.debug("[upsertIndividualAccount] No Address and Prospect RowID Found");
									targetRowId = rowIds.iterator().next();
								} else {
									PartyChildRowIdData partyChildData = partyChildDataList.get(0);
									targetRowId = partyChildData.getRowIdParty();
									targetRowIdAddr = partyChildData.getRowIdAddr();
									targetRowIdProspect = partyChildData.getRowIdProspect();
								}
								needToMerge = Boolean.TRUE;
							}
							
						}
						

					} else if (rowIdMap.containsKey(Constant.CURRENT_ACTIVE_PARTY)) {
						LOG.debug(
								"[upsertIndividualAccount] Multi Geo match found for active party. Creating account-contact rel ONLY");
						for (String rowIdActiveParty : rowIdMap.get(Constant.CURRENT_ACTIVE_PARTY)) {
							processAcntCntctRel(upsertResponse, partyXrefType.getPartyRel().getPARTYPERSONREL(),
									rowIdActiveParty, srcSystem, srcPkey, Constant.BO_CLASS_CODE_ORG);
							if (Util.isNullOrEmpty(upsertResponse.getStatus())) {
								upsertResponse
										.setStatus("Contact relation created with Customer ROWID " + rowIdActiveParty);
							} else {
								upsertResponse.setStatus(upsertResponse.getStatus()
										+ "\nContact relation created with Customer ROWID " + rowIdActiveParty);
							}
							partyCount++;
							
							/** Modified for US68-Throughput Tracker START */
							try {
								putMsgTrackingId(rowIdActiveParty, partyXrefType.getMSGTRKNID());
							} catch (ServiceProcessingException spExcp) {
								LOG.error("Failed to set MSG_TRKN_ID: ", spExcp);
								upsertResponse.setStatus(upsertResponse.getStatus() + 
										"\nMSG_TRKN_ID update failed");
							} catch (Exception Excp) {
								LOG.error("Caught exception while updating MSG_TRKN_ID: ", Excp);
								upsertResponse.setStatus(upsertResponse.getStatus() + 
										"\nMSG_TRKN_ID update failed");
							}
							/** Modified for US68-Throughput Tracker END */
						}
						foundCustomerMatch = Boolean.TRUE;
					} else if (rowIdMap.containsKey(Constant.CURRENT_SINGLETON_OR_PROSPECT_DUNS_PARTY)) {
						LOG.debug(
								"[upsertIndividualAccount] Multi Geo match found for party with DUNS. Creating account with Duns details");
						needToMerge = Boolean.TRUE;
						targetRowId = rowIdMap.get(Constant.CURRENT_SINGLETON_OR_PROSPECT_DUNS_PARTY).get(0);
						PartyXrefType dunsPartyXRef = getMarketingPartyDAO.getBOPartyForMrktActn(targetRowId, srcSystem,
								srcPkey);
						targetRowIdAddr = dunsPartyXRef.getAddress().get(0).getROWIDADDRESS();
						dunsPartyXRef.setPARTYTYPE(partyXrefType.getPARTYTYPE());
						dunsPartyXRef.getXREF().addAll(partyXrefType.getXREF());
						dunsPartyXRef.getAccount().addAll(partyXrefType.getAccount());
						Map<String, Object> dataHolderMap = processCleansePutRequest(dunsPartyXRef, upsertResponse);
						rowIdParty = ((PutResponseDataHolder) dataHolderMap.get(MDMAttributeNames.ENTITY_PARTY))
								.getRowidObject();
						rowIdAddress = ((List<PutResponseDataHolder>) dataHolderMap
								.get(MDMAttributeNames.ENTITY_ADDRESS)).get(0).getRowidObject();
						rowIdProspect = ((List<PutResponseDataHolder>) dataHolderMap
								.get(MDMAttributeNames.ENTITY_PROSPECT)).get(0).getRowidObject();
					} else {
						LOG.debug("[upsertIndividualAccount] Invalid Multi Geo match map::" + rowIdMap);
					}
					if (foundCustomerMatch) {
						LOG.debug("[upsertIndividualAccount] Found customer match. Skipping merge and UCN process");
					} else {
						if (needToMerge) {
							try{
								mergeProspectPartyDAO.mergeProspectParties(MDMAttributeNames.PARTY_BO, rowIdParty,
									targetRowId);
								LOG.debug("[upsertIndividualAccount]: mergeProspectParties successful on C_B_PARTY..");
								isMergeELQPartySuccess = true;
								mergeProspectPartyDAO.mergeProspectParties(MDMAttributeNames.ADDRESS_BO, rowIdAddress,
									targetRowIdAddr);
								LOG.debug("[upsertIndividualAccount]: mergeProspectParties successful on C_B_ADDRESS..");
								isMergeELQAddressSuccess = true;
								if (!Util.isNullOrEmpty(targetRowIdProspect)) {
									mergeProspectPartyDAO.mergeProspectParties(MDMAttributeNames.PARTY_PROSPECT_BO,
										rowIdProspect, targetRowIdProspect);
									LOG.debug("[upsertIndividualAccount]: mergeProspectParties successful on C_B_PARTY_PROSPECT..");
									isMergeELQProspectSuccess = true;
								}
							} catch (Exception ex) {
								//	mergeInd = false;
								LOG.error("[upsertIndividualAccount]: Exception occured while mergeProspectParties: " , ex);
								for(int i = 0; i<countOfRetry; i++)	{
									try{
										if(!isMergeELQPartySuccess){
											LOG.debug("[upsertIndividualAccount]: Retrying mergeProspectParties for C_B_PARTY "+ (i+1) +"th time");
												mergeProspectPartyDAO.mergeProspectParties(MDMAttributeNames.PARTY_BO, rowIdParty,
														targetRowId);
												LOG.debug("[upsertIndividualAccount]:mergeProspectParties successful on C_B_PARTY in attempt no. "+ (i+1));
												isMergeELQPartySuccess = true;
									//		mergeInd = true;
											break;
										}
										} catch (Exception excp) {
										LOG.error("[upsertIndividualAccount]: Exception occured in mergeProspectParties for C_B_PARTY"
												+ " RetryMechanism on attempt no. "+ (i+1));
										LOG.error("[upsertIndividualAccount]: Exception occured in mergeProspectParties RetryMechanism for C_B_PARTY");
									}
								}
								if(!isMergeELQPartySuccess){
									ServiceProcessingException customException = new ServiceProcessingException(ex);
									customException.setMessage("[upsertIndividualAccount]: Exception occured in mergeProspectParties for C_B_PARTY "
											+ "RetryMechanism: " + customException.getMessage());
									throw customException;
								}
								
								for(int i = 0; i<countOfRetry; i++)	{
									try{
										if(!isMergeELQAddressSuccess){
											LOG.debug("[upsertIndividualAccount]: Retrying mergeProspectParties for C_B_ADDRESS "+ (i+1) +"th time");
												mergeProspectPartyDAO.mergeProspectParties(MDMAttributeNames.ADDRESS_BO, rowIdAddress,
														targetRowIdAddr);
												LOG.debug("[upsertIndividualAccount]:mergeProspectParties successful on C_B_ADDRESS in attempt no. "+ (i+1));
												isMergeELQAddressSuccess = true;
									//		mergeInd = true;
											break;
										}
									} catch (Exception excp) {
										LOG.error("[upsertIndividualAccount]: Exception occured in mergeProspectParties for C_B_ADDRESS"
												+ " RetryMechanism on attempt no. "+ (i+1));
										LOG.error("[upsertIndividualAccount]: Exception occured in mergeProspectParties RetryMechanism for C_B_ADDRESS");
									}
								}
								if(!isMergeELQAddressSuccess){
									ServiceProcessingException customException = new ServiceProcessingException(ex);
									customException.setMessage("[upsertIndividualAccount]: Exception occured in mergeProspectParties for C_B_ADDRESS "
											+ "RetryMechanism: " + customException.getMessage());
									throw customException;
								}
								
								for(int i = 0; i<countOfRetry; i++)	{
									try{
										if(!isMergeELQProspectSuccess){
											LOG.debug("[upsertIndividualAccount]: Retrying mergeProspectParties for C_B_PARTY_PROSPECT "+ (i+1) +"th time");
											if (!Util.isNullOrEmpty(targetRowIdProspect)) {
												mergeProspectPartyDAO.mergeProspectParties(MDMAttributeNames.PARTY_PROSPECT_BO,
														rowIdProspect, targetRowIdProspect);
												LOG.debug("[upsertIndividualAccount]:mergeProspectParties successful on C_B_PARTY_PROSPECT in attempt no. "+ (i+1));
												isMergeELQProspectSuccess = true;
											}
									//		mergeInd = true;
											break;
										}
									} catch (Exception excp) {
										LOG.error("[upsertIndividualAccount]: Exception occured in mergeProspectParties for C_B_PARTY_PROSPECT"
												+ " RetryMechanism on attempt no. "+ (i+1));
										LOG.error("[upsertIndividualAccount]: Exception occured in mergeProspectParties RetryMechanism for C_B_PARTY_PROSPECT");
									}
								}
								if(!isMergeELQProspectSuccess){
									ServiceProcessingException customException = new ServiceProcessingException(ex);
									customException.setMessage("[upsertIndividualAccount]: Exception occured in mergeProspectParties for C_B_PARTY_PROSPECT "
											+ "RetryMechanism: " + customException.getMessage());
									throw customException;
								}
								
							}
						}
						mdmUcn = prospectPartyDAO.checkifUCNExists(targetRowId);
						rowIdParty = targetRowId;
						if (Util.isNullOrEmpty(mdmUcn)) {
							try {
								setUCNSeq(rowIdParty, null);
							} catch (ServiceProcessingException spExcp) {
								LOG.error("Failed to set UCN: ", spExcp);
							} catch (Exception Excp) {
								LOG.error("Caught exception while updating UCN: ", Excp);
							}
						}
						if (partyXrefType.getPartyRel() != null) {
							processAcntCntctRel(upsertResponse, partyXrefType.getPartyRel().getPARTYPERSONREL(),
									rowIdParty, srcSystem, srcPkey, Constant.BO_CLASS_CODE_ORG);
						}
					}
				} else {
					LOG.debug("[upsertIndividualAccount] Marketing account with UCN::" + partyXrefType.getUCN()
							+ ":: Request won't be processed");
					createAccountUpsertInfoMessage(upsertResponse, Constant.INFO_ACCOUNT_EXISTING_NON_MARKETING_ACCOUNT,
							srcPkey);
				}
			}
		} catch (ServiceProcessingException servexp) {
			LOG.error("[upsertIndividualAccount]Caught ServiceProcessingException", servexp);
		} catch (Exception exp) {
			LOG.error("[upsertIndividualAccount]Caught exception in processMarketingUpsertRequest()", exp);
			createAccountUpsertErrorResponse(upsertResponse, Constant.ERROR_UPSERT_ACCOUNT_EXCEPTION, srcPkey, exp);
		}
				
		LOG.debug("[processUpsertRequestForIndividualAccount] EXIT");
	}
	
	private boolean isMatchExclusionPatternExists(String rowidobject) throws ServiceProcessingException {

		boolean exclusionPatternExists = false;
		int patternExist = getPartyDAO.checkExclusionPatternProspect(rowidobject);
		if (patternExist > 0) {
			exclusionPatternExists = true;
			getPartyDAO.updatePartyConsolidationInd(rowidobject);
		}

		return exclusionPatternExists;
	}
	
	// Method for CreatingTask for Administrator
		private void processCreateTaskRequest(String tgtPartyRowId, String rowIdObject, String taskType, String title, String comment) {

			LOG.info("Executing processCreateTaskRequest()");
			SiperianClient siperianClient = null;

			try {
				String mergeOwnerUID = configProps.getProperty("mergeOwnerUID");
				String ownerUid = configProps.getProperty("ownerUID");
				String subjectAreaUID = configProps.getProperty("subjectAreaUID");

				CreateTaskResponse response = null;
				CreateTaskRequest request = new CreateTaskRequest();
				TaskData taskData = new TaskData();

				if (taskType.equalsIgnoreCase("Merge"))	{
					taskData.setOwnerUid(mergeOwnerUID);

				} else {
					taskData.setOwnerUid(ownerUid);

				}

				TaskRecord taskRecord = new TaskRecord();
				RecordKey recordKey = new RecordKey();
				taskRecord.setSiperianObjectUid(SiperianObjectType.BASE_OBJECT.makeUid(MDMAttributeNames.PARTY_BO));
				recordKey.setRowid(rowIdObject);
				LOG.debug("rowIdObject: " + rowIdObject);
				taskRecord.setRecordKey(recordKey);
				List<TaskRecord> recordList = new ArrayList<TaskRecord>();
				recordList.add(taskRecord);

				if (taskType.equalsIgnoreCase("Merge")) {

				//	for (HighestScoreRecordHolder srcRecHolder : mergeSorceHolderMap.values())
				//		tgtPartyRowId = srcRecHolder.getPartyRowIDObject();

					TaskRecord taskRecord2 = new TaskRecord();
					taskRecord2.setSiperianObjectUid(SiperianObjectType.BASE_OBJECT.makeUid(MDMAttributeNames.PARTY_BO));
					RecordKey recordKey2 = new RecordKey();
					recordKey2.setRowid(tgtPartyRowId);
					LOG.debug("tgtPartyRowId :" + tgtPartyRowId);
					taskRecord2.setRecordKey(recordKey2);
					recordList.add(0, taskRecord2);
				}

				taskData.setTaskRecords(recordList);
				request.setTaskData(taskData);
				taskData.setTitle(title);
				taskData.setComment(comment);

				Calendar cal = Calendar.getInstance();
				cal.setTime(new Date(System.currentTimeMillis()));
				cal.add(Calendar.DATE, 7);

				taskData.setDueDate(cal.getTime());
				// taskData.setSubjectAreaUid("SUBJECT_AREA.test|Person");
				taskData.setSubjectAreaUid(subjectAreaUID);
				// taskData.setTaskType("ReviewNoApprove");
				taskData.setTaskType(taskType);

				siperianClient = (SiperianClient) checkOut();

				LOG.info("processing CreateTaskRequest");
				response = (CreateTaskResponse) siperianClient.process(request);
				LOG.info("CreateTaskResponse result: " + response.getMessage());
				LOG.info("CreateTaskResponse taskId: " + response.getTaskId());
				LOG.info("CreateTaskResponse interactionId: " + response.getInteractionId());
				LOG.info("after response");
			} catch (Exception excp) {
				LOG.error("Caught Exception in CreateTaskRequest Error Message: " + excp);
			} finally {
				checkIn(siperianClient);
			}
			LOG.info("Executed processCreateTaskRequest()");
		}

	/**
	 * Updates Prospect Account
	 * 
	 * @param partyXrefType
	 * @param srcSystem
	 * @param srcPkey
	 * @param upsertResponse
	 */
	private void updateProspectAccount(PartyXrefType partyXrefType, String srcSystem, String srcPkey,
			Integer mrktRowCount, UpsertPartyResponse upsertResponse) {
		LOG.debug("[updateProspectAccount] ENTER");
		String rowIdParty = null;
		try {
			// check for Account Address for Null or Unknown
			LOG.debug("[updateProspectAccount] check for Account Address for Null or Unknown");
			if (!validateAccountAddressNullUnknown(partyXrefType,
					upsertResponse)) {
				// REPORTED ADDRESS OR CITY HAVE null or unknown
				LOG.debug("ELQ Account record have NULL or Unknown "
						+ partyXrefType.getXREF().get(0).getSRCPKEY());
			}
			LOG.debug("[updateProspectAccount] check for Account Address for Junk");
			// check for Account Address for Junk and reject the account request
			if (!validateAccountAddressJunk(partyXrefType, upsertResponse)) {
				LOG.debug("ELQ Account record have AddressLn1 or city junk ::Rejecting"
						+ partyXrefType.getXREF().get(0).getSRCPKEY());
				return;

			}
			Boolean isOnlyUpdatePropect = (mrktRowCount == 1);
			if (!isOnlyUpdatePropect) {
				rowIdParty = prospectPartyDAO.getPartyRowIdBySrcPkey(srcPkey, srcSystem);
				isOnlyUpdatePropect = searchProspectDao.findSelfMatchProspect(partyXrefType, srcPkey);
			}
			LOG.debug("[updateProspectAccount] isOnlyUpdatePropect::" + isOnlyUpdatePropect);
			if (isOnlyUpdatePropect) {
				if (partyXrefType.getPartyRel() != null) {
					partyXrefType.getPartyRel().getPARTYPERSONREL().clear();
				}
			} else {
				List<String> contactRelRowIdList = prospectPartyDAO.getContactsByAccountRowId(rowIdParty);
				if (CollectionUtils.isEmpty(contactRelRowIdList)) {
					LOG.debug("[updateProspectAccount] No related contact found");
				} else {
					String inputAccountContactPkey = srcPkey
							.substring((Constant.PROSPECT_ACCOUNT_PKEY_PREFIX + Constant.STR_DASH).length());
					if (contactRelRowIdList.contains(inputAccountContactPkey)) {
						contactRelRowIdList.remove(inputAccountContactPkey);
					}
				}
				UnmergeResponse unMergeResponse = mergeProspectPartyDAO.unMergeProspectParties(srcPkey, srcSystem);
				String rowIdUnmergedCluster = unMergeResponse.getRecordKey().getRowid();
				if (CollectionUtils.isEmpty(contactRelRowIdList)) {
					LOG.debug("[updateProspectAccount] No related contact to put for after Unmerge");
				} else {
					if (prospectPartyDAO.isRootUnmerge(rowIdUnmergedCluster, srcPkey, srcSystem)) {
						LOG.debug(
								"[processUpsertRequestForIndividualAccount] Root Unmerge. Contacts will be associated with::"
										+ rowIdUnmergedCluster);
						deleteProspectPartyDAO.deleteContactRel(contactRelRowIdList);
						for (String contactRowId : contactRelRowIdList) {
							/*cleansePutAccountContactRel(upsertResponse, contactRowId, rowIdUnmergedCluster, srcSystem,
									srcPkey, null);*/
							
							/** US478 : Retry on cleanse Put Start**/
							int cleansePutAccountContactcountOfRetry = Integer.parseInt(configProps.getProperty("NoOfRetries"));
							boolean iscleansePutRetrySuccess = false;
							try{
								Map<String, String> deactiveRelationMap = checkRelationship(contactRowId, rowIdUnmergedCluster);
								if(!deactiveRelationMap.isEmpty()){
									for(Map.Entry<String, String> dm : deactiveRelationMap.entrySet()){
										restoreAccountContactRel(dm.getValue(), dm.getKey());
									}
									
								}else{
									cleansePutAccountContactRel(upsertResponse, contactRowId, rowIdUnmergedCluster, srcSystem,
											srcPkey, null);
								}
								
							}catch (Exception servExcp) {
								LOG.error("Exception occured while cleansePut AccountContact: " , servExcp);
								for(int i = 0; i<cleansePutAccountContactcountOfRetry; i++)	{
									try{
										LOG.debug("Retrying cleansePut AccountContact for "+ (i+1) +"th time");
										cleansePutAccountContactRel(upsertResponse, contactRowId, rowIdUnmergedCluster, srcSystem,
												srcPkey, null);
										LOG.debug("Retry cleansePut AccountContact is successful on attempt no. "+ (i+1));
										iscleansePutRetrySuccess = true;
										break;
									} catch (Exception excp) {
										LOG.error("Exception occured in cleansePut AccountContact Retry on attempt no. "+ (i+1));
										LOG.error("Exception occured in cleansePut AccountContact RetryMechanism...");
									}
									
								}if(!iscleansePutRetrySuccess){
									upsertResponse.setErrorMsg("CleansePut operation failed for Account - Contact Rel" + srcPkey);
									ServiceProcessingException customException = new ServiceProcessingException(servExcp);
									customException.setMessage("SIF exception occured while processing cleansePut AccountContact : " + customException.getMessage());
									throw customException;
								}					
							}
							
						/** US478 : Retry on cleanse Put END**/
							
							
						}
					} else {
						LOG.debug("[updateProspectAccount] NOT a Root Unmerge.");
					}
				}
			}
			Map<String, Object> dataHolderMap = processCleansePutRequest(partyXrefType, upsertResponse);
			rowIdParty = ((PutResponseDataHolder) dataHolderMap.get(MDMAttributeNames.ENTITY_PARTY)).getRowidObject();
			if (partyXrefType.getPartyRel() != null) {
				processAcntCntctRel(upsertResponse, partyXrefType.getPartyRel().getPARTYPERSONREL(), rowIdParty,
						srcSystem, srcPkey, Constant.BO_CLASS_CODE_ORG);
			}
			PutResponseDataHolder putRespDataParty = (PutResponseDataHolder)
					dataHolderMap.get(MDMAttributeNames.ENTITY_PARTY);
			
			/* US528 C/O Account issue
			 * By Pass match merge process if Account C/O 
			 */
			LOG.debug("isMatchExclusionPatternExists for prospect account updated");
			boolean exclusionPatternExists = false;
			try {
				exclusionPatternExists = isMatchExclusionPatternExists(putRespDataParty.getRowidObject());
				if(exclusionPatternExists){
					LOG.debug("[updateProspectAccount] CI  is set to 9 for" + putRespDataParty.getRowidObject());
				}
				
			} catch (Exception Excp) {

				LOG.error(
						"Caught exception in isMatchExclusionPatternExists: ",
						Excp);
				// Create Task for Tokenization failure
				String title = "Creating GenericTask to manually update the consolidation_ind to 9.";
				String comment = "Failed while updating consolidation indicator of the Party with 9 for the PartyID: "
						+ putRespDataParty.getRowidObject();
				processCreateTaskRequest(null,
						putRespDataParty.getRowidObject(),
						"FinalReview", title, comment);
			}
			
		} catch (ServiceProcessingException servexp) {
			LOG.error("[updateProspectAccount]Caught ServiceProcessingException", servexp);
		} catch (Exception exp) {
			LOG.error("[updateProspectAccount]Caught exception in processMarketingUpsertRequest()", exp);
			createAccountUpsertErrorResponse(upsertResponse, Constant.ERROR_UPSERT_ACCOUNT_EXCEPTION, srcPkey, exp);
		}
		LOG.debug("[updateProspectAccount] EXIT");
	}

	/**
	 * Processing Account-Contact Relation mapping
	 * <ol>
	 * <li>Retrieve data from temp table MDM_RTS_MRKT_ACC_CONTACT_REL</li>
	 * <li>Create composite list of contact PKEY from incoming data & temp table
	 * data</li>
	 * <li>Check in XRef for those Pkeys</li>
	 * <li>If found then CleasePut in Golden record and delete from temp table
	 * </li>
	 * <li>Else insert data in temp table for any new incoming data</li>
	 * </ol>
	 * 
	 * @param upsertResponse
	 * @param partyContactRelList
	 * @param rowIdParty
	 * @param srcSystem
	 * @param srcPkey
	 * @throws ServiceProcessingException
	 */
	private void processAcntCntctRel(UpsertPartyResponse upsertResponse,
			List<PartyContactRelationshipXrefType> partyContactRelList, String rowIdParty, String srcSystem,
			String srcPkey, String boClassCode) throws ServiceProcessingException {
		LOG.debug("[processAcntCntctRel] ENTER");
		List<AcntCntctRelData> actnCntctRelDataList = prospectPartyDAO.getPendingAcntCntctRel(srcSystem, srcPkey,
				boClassCode,false);
		Map<String, Boolean> contactPkeyMap = new HashMap<String, Boolean>();
		Map<String, String> acctPkeyRowidMap = new HashMap<String, String>();
		if (!CollectionUtils.isEmpty(partyContactRelList)) {
			for (PartyContactRelationshipXrefType partyContactRel : partyContactRelList) {
				if (!Util.isNullOrEmpty(partyContactRel.getSRCPKEY())) {
					contactPkeyMap.put(partyContactRel.getSRCPKEY(), Boolean.FALSE);
				}
			}
		}

		if (!CollectionUtils.isEmpty(actnCntctRelDataList)) {
			if (Constant.BO_CLASS_CODE_ORG.equalsIgnoreCase(boClassCode)) { // For
																			// Prospect
																			// Account
				for (AcntCntctRelData actnCntctRelData : actnCntctRelDataList) {
					contactPkeyMap.put(actnCntctRelData.getCntctSrcPkey(), Boolean.TRUE);
				}
			} else if (Constant.BO_CLASS_CODE_PERSON.equalsIgnoreCase(boClassCode)) { // For
																						// Person
																						// Contact
				for (AcntCntctRelData actnCntctRelData : actnCntctRelDataList) {
					acctPkeyRowidMap.put(actnCntctRelData.getAcntSrcPkey(), actnCntctRelData.getAcntRowid());
				}
			}
		}

		// For Prospect Account
		if (CollectionUtils.isEmpty(contactPkeyMap.keySet())) {
			LOG.debug("[processAcntCntctRel] No Contact Rel to process");
		} else {
			LOG.debug("[processAcntCntctRel] contactPkeyMap to process for Account::" + contactPkeyMap);
			String contactPkeys = StringUtils.collectionToDelimitedString(contactPkeyMap.keySet(), Constant.STR_COMMA,
					Constant.STR_SINGLE_QUOTE, Constant.STR_SINGLE_QUOTE);
			List<CntctPkeyRowIdRelData> existingContactRowidList = prospectPartyDAO
					.getContactRowIdsFromPkeys(contactPkeys,false);
			List<String> pkeysToDeleteFromTempTable = new ArrayList<String>();
			List<String> pkeysToInsertIntoTempTable = new ArrayList<String>();
			if (!CollectionUtils.isEmpty(existingContactRowidList)) {
				List<PutResponseDataHolder> actnCntctDataHolderList = cleansePutAccountContactRel(upsertResponse,
						existingContactRowidList, rowIdParty, srcSystem, srcPkey, null);
				// for (PutResponseDataHolder actnCntctDataHolder :
				// actnCntctDataHolderList) {
				for (CntctPkeyRowIdRelData existingContactRowid : existingContactRowidList) {
					if (existingContactRowid.getIsCleansePut()) {
						String curContactPkey = existingContactRowid.getContactPkey();
						if (contactPkeyMap.containsKey(curContactPkey) && contactPkeyMap.get(curContactPkey)) {
							pkeysToDeleteFromTempTable.add(curContactPkey);
						}
						contactPkeyMap.remove(curContactPkey);
					}
				}
			}
			for (String pkey : contactPkeyMap.keySet()) {
				if (!contactPkeyMap.get(pkey)) {
					pkeysToInsertIntoTempTable.add(pkey);
				}
			}
			prospectPartyDAO.insertPkeysInTempTable(pkeysToInsertIntoTempTable, srcSystem, srcPkey, rowIdParty,false);
			prospectPartyDAO
					.deletePkeysFromTempTable(
							StringUtils.collectionToDelimitedString(pkeysToDeleteFromTempTable, Constant.STR_COMMA,
									Constant.STR_SINGLE_QUOTE, Constant.STR_SINGLE_QUOTE),
							srcSystem, srcPkey, Boolean.TRUE,Boolean.FALSE);
		}
		// For Person Contact
		if (CollectionUtils.isEmpty(acctPkeyRowidMap.keySet())) {
			LOG.debug("[processAcntCntctRel] No Account Rel to process");
		} else {
			List<CntctPkeyRowIdRelData> existingAcctRowidList = new ArrayList<CntctPkeyRowIdRelData>();
			;
			for (Map.Entry<String, String> acctMap : acctPkeyRowidMap.entrySet()) {
				String accntRowid = acctMap.getValue();// Account_Rowid_Object
				String accntPkey = acctMap.getKey();// Account_Pkey_Src_Object
				CntctPkeyRowIdRelData cntctPkeyRowIdRelData = null;

				if (!Util.isNullOrEmpty(accntRowid)) {
					cntctPkeyRowIdRelData = new CntctPkeyRowIdRelData();
					cntctPkeyRowIdRelData.setContactPkey(accntPkey);
					cntctPkeyRowIdRelData.setContactRowId(accntRowid);
					cntctPkeyRowIdRelData.setIsCleansePut(Boolean.FALSE);
					existingAcctRowidList.add(cntctPkeyRowIdRelData);
				} else {
					String acctPkeys = StringUtils.collectionToDelimitedString(acctPkeyRowidMap.keySet(),
							Constant.STR_COMMA, Constant.STR_SINGLE_QUOTE, Constant.STR_SINGLE_QUOTE);
					existingAcctRowidList = prospectPartyDAO.getContactRowIdsFromPkeys(acctPkeys,false);
				}
				List<String> pkeysToDeleteFromTempTable = new ArrayList<String>();
				if (!CollectionUtils.isEmpty(existingAcctRowidList)) {
					List<PutResponseDataHolder> actnCntctDataHolderList = cleansePutContactAccountRel(upsertResponse,
							existingAcctRowidList, rowIdParty, srcSystem, srcPkey, null);
					// for (PutResponseDataHolder actnCntctDataHolder :
					// actnCntctDataHolderList) {
					for (CntctPkeyRowIdRelData existingAcctRowid : existingAcctRowidList) {
						if (existingAcctRowid.getIsCleansePut()) {
							String curAcctPkey = existingAcctRowid.getContactPkey();
							if (acctPkeyRowidMap.containsKey(curAcctPkey)) {
								pkeysToDeleteFromTempTable.add(curAcctPkey);
							}
						}
					}
					prospectPartyDAO.deletePkeysFromTempTable(
							StringUtils.collectionToDelimitedString(pkeysToDeleteFromTempTable, Constant.STR_COMMA,
									Constant.STR_SINGLE_QUOTE, Constant.STR_SINGLE_QUOTE),
							srcSystem, srcPkey, Boolean.FALSE,Boolean.FALSE);
				}
			} // end for loop
		}
		LOG.debug("[processAcntCntctRel] EXIT::");
	}

	/**
	 * The method prepares and executes CleansePutRequest on PARTY_REL landing
	 * table for the given Contact profiles.
	 * 
	 * @param upsertResponse
	 * @param existingContactRowidList
	 * @param rowIdAccount
	 * @param srcSystem
	 * @param srcPkey
	 * @param relLastUpdateDate
	 * @return putResponseActnCntctDataHolder
	 * @throws ServiceProcessingException
	 */
	private List<PutResponseDataHolder> cleansePutAccountContactRel(UpsertPartyResponse upsertResponse,
			List<CntctPkeyRowIdRelData> existingContactRowidList, String rowIdAccount, String srcSystem, String srcPkey,
			String relLastUpdateDate) throws ServiceProcessingException {
		LOG.debug("[cleansePutAccountContactRel] ENTER");
		List<PutResponseDataHolder> putResponseActnCntctDataHolder = new ArrayList<PutResponseDataHolder>();
		try {
			for (CntctPkeyRowIdRelData existingContactRowid : existingContactRowidList) {
				
			/** US478 : Retry on cleanse Put Start**/
				int cleansePutAccountContactcountOfRetry = Integer.parseInt(configProps.getProperty("NoOfRetries"));
				boolean iscleansePutRetrySuccess = false;
				PutResponseDataHolder responseDataHolder =null;
				try{
					Map<String, String> deactiveRelationMap = checkRelationship(existingContactRowid.getContactRowId(), rowIdAccount);
					if(!deactiveRelationMap.isEmpty()){
						for(Map.Entry<String, String> dm : deactiveRelationMap.entrySet()){
							restoreAccountContactRel(dm.getValue(), dm.getKey());
						}
						
					}else{
						responseDataHolder = cleansePutAccountContactRel(upsertResponse,
								existingContactRowid.getContactRowId(), rowIdAccount, srcSystem, srcPkey, relLastUpdateDate);
					}
					
				}catch (Exception servExcp) {
					LOG.error("Exception occured while cleansePut AccountContact: " , servExcp);
					for(int i = 0; i<cleansePutAccountContactcountOfRetry; i++)	{
						try{
							LOG.debug("Retrying cleansePut AccountContact for "+ (i+1) +"th time");
							responseDataHolder = cleansePutAccountContactRel(upsertResponse,
									existingContactRowid.getContactRowId(), rowIdAccount, srcSystem, srcPkey, relLastUpdateDate);
							LOG.debug("Retry cleansePut AccountContact is successful on attempt no. "+ (i+1));
							iscleansePutRetrySuccess = true;
							break;
						} catch (Exception excp) {
							LOG.error("Exception occured in cleansePut AccountContact Retry on attempt no. "+ (i+1));
							LOG.error("Exception occured in cleansePut AccountContact RetryMechanism...");
						}
						
					}if(!iscleansePutRetrySuccess){
						upsertResponse.setErrorMsg("CleansePut operation failed for Account - Contact Rel" + srcPkey);
						ServiceProcessingException customException = new ServiceProcessingException(servExcp);
						customException.setMessage("SIF exception occured while processing cleansePut AccountContact : " + customException.getMessage());
						throw customException;
					}					
				}
				
			/** US478 : Retry on cleanse Put END**/
				
				putResponseActnCntctDataHolder.add(responseDataHolder);
				existingContactRowid.setIsCleansePut(Boolean.TRUE);
			}
		}catch (ServiceProcessingException ex) {
			throw ex;
		} catch (Exception ex) {
			upsertResponse.setErrorMsg("CleansePut operation failed for Account - Contact Rel" + srcPkey);
			LOG.error("Exception occured while preparing/processing cleansePut requests: ", ex);
			ServiceProcessingException customException = new ServiceProcessingException(ex);
			customException.setMessage("Failed to process cleansePut SIF request." + customException.getMessage());
			throw customException;
		}
		LOG.debug("[cleansePutAccountContactRel] EXIT");
		return putResponseActnCntctDataHolder;
	}

	/**
	 * The method prepares and executes CleansePutRequest on PARTY_REL landing
	 * table for the given Contact profiles.
	 * 
	 * @param upsertResponse
	 * @param existingContactRowidList
	 * @param rowIdAccount
	 * @param srcSystem
	 * @param srcPkey
	 * @param relLastUpdateDate
	 * @return putResponseActnCntctDataHolder
	 * @throws ServiceProcessingException
	 */
	private List<PutResponseDataHolder> cleansePutContactAccountRel(UpsertPartyResponse upsertResponse,
			List<CntctPkeyRowIdRelData> existingAcctRowidList, String rowIdContact, String srcSystem, String srcPkey,
			String relLastUpdateDate) throws ServiceProcessingException {
		LOG.debug("[cleansePutContactAccountRel] ENTER");
		List<PutResponseDataHolder> putResponseActnCntctDataHolder = new ArrayList<PutResponseDataHolder>();
		try {
			for (CntctPkeyRowIdRelData existingAcctRowid : existingAcctRowidList) {
				
				/*PutResponseDataHolder responseDataHolder = cleansePutAccountContactRel(upsertResponse, rowIdContact,
						existingAcctRowid.getContactRowId(), srcSystem, srcPkey, relLastUpdateDate);*/
				/** US478 : Retry on cleanse Put Start**/
				int cleansePutAccountContactcountOfRetry = Integer.parseInt(configProps.getProperty("NoOfRetries"));
				boolean iscleansePutRetrySuccess = false;
				PutResponseDataHolder responseDataHolder =null;
				try{
					Map<String, String> deactiveRelationMap = checkRelationship(rowIdContact, existingAcctRowid.getContactRowId());
					if(!deactiveRelationMap.isEmpty()){
						for(Map.Entry<String, String> dm : deactiveRelationMap.entrySet()){
							restoreAccountContactRel(dm.getValue(), dm.getKey());
						}
						
					}else{
						responseDataHolder = cleansePutAccountContactRel(upsertResponse, rowIdContact,
								existingAcctRowid.getContactRowId(), srcSystem, srcPkey, relLastUpdateDate);
					}
					
				}catch (Exception servExcp) {
					LOG.error("Exception occured while cleansePut AccountContact: " , servExcp);
					for(int i = 0; i<cleansePutAccountContactcountOfRetry; i++)	{
						try{
							LOG.debug("Retrying cleansePut AccountContact for "+ (i+1) +"th time");
							responseDataHolder = cleansePutAccountContactRel(upsertResponse, rowIdContact,
									existingAcctRowid.getContactRowId(), srcSystem, srcPkey, relLastUpdateDate);
							LOG.debug("Retry cleansePut AccountContact is successful on attempt no. "+ (i+1));
							iscleansePutRetrySuccess = true;
							break;
						} catch (Exception excp) {
							LOG.error("Exception occured in cleansePut AccountContact Retry on attempt no. "+ (i+1));
							LOG.error("Exception occured in cleansePut AccountContact RetryMechanism...");
						}
						
					}if(!iscleansePutRetrySuccess){
						upsertResponse.setErrorMsg("CleansePut operation failed for Account - Contact Rel" + srcPkey);
						ServiceProcessingException customException = new ServiceProcessingException(servExcp);
						customException.setMessage("SIF exception occured while processing cleansePut AccountContact : " + customException.getMessage());
						throw customException;
					}					
				}
				
			/** US478 : Retry on cleanse Put END**/
				putResponseActnCntctDataHolder.add(responseDataHolder);
				existingAcctRowid.setIsCleansePut(Boolean.TRUE);
			}
		} catch (ServiceProcessingException ex) {
			throw ex;
		} catch (Exception ex) {
			upsertResponse.setErrorMsg("CleansePut operation failed for Account - Contact Rel" + srcPkey);
			LOG.error("Exception occured while preparing/processing cleansePut requests: ", ex);
			ServiceProcessingException customException = new ServiceProcessingException(ex);
			customException.setMessage("Failed to process cleansePut SIF request." + customException.getMessage());
			throw customException;
		}
		LOG.debug("[cleansePutContactAccountRel] EXIT");
		return putResponseActnCntctDataHolder;
	}

	/**
	 * The method prepares and executes CleansePutRequest on PARTY_REL landing
	 * table for the given Contact profiles.
	 * 
	 * @param upsertResponse
	 * @param contactRowid
	 * @param rowIdAccount
	 * @param srcSystem
	 * @param srcPkey
	 * @param relLastUpdateDate
	 * @return putResponseActnCntctDataHolder
	 * @throws ServiceProcessingException
	 */
	private PutResponseDataHolder cleansePutAccountContactRel(UpsertPartyResponse upsertResponse, String contactRowid,
			String rowIdAccount, String srcSystem, String srcPkey, String relLastUpdateDate)
			throws ServiceProcessingException {
		LOG.debug("[cleansePutAccountContactRel] ENTER");
		LOG.debug("[cleansePutAccountContactRel] contactRowid::" + contactRowid + ", rowIdAccount::" + rowIdAccount +
				", srcSystem::" + srcSystem + ", srcPkey::" + srcPkey + ", relLastUpdateDate::" + relLastUpdateDate);
		UserTransaction transaction = null;
		SiperianClient siperianClient = null;
		lastUpdateDate = Util.getCurrentTimeZone();
		PutResponseDataHolder responseDataHolder = new PutResponseDataHolder();
		try {
			siperianClient = (SiperianClient) checkOut();
			transaction = ((EjbSiperianClient) siperianClient).createTX(300000);
			transaction.begin();
			CleansePutRequest cleansePutRequest = new CleansePutRequest();
			Record record = new Record();
			record.setSiperianObjectUid(Util.getMappingObjectUid(srcSystem, MDMAttributeNames.ENTITY_RELATION));
			if (Util.isNullOrEmpty(relLastUpdateDate)) {
				LOG.info("Performing cleansePutParty with sysdate from HUB: " + lastUpdateDate);
				record.setField(new Field(MDMAttributeNames.LAST_UPDATE_DATE, lastUpdateDate));
			} else {
				record.setField(new Field(MDMAttributeNames.LAST_UPDATE_DATE, relLastUpdateDate));
			}
			record.setField(new Field(MDMAttributeNames.SRC_SYSTEM, srcSystem));
			record.setField(new Field(MDMAttributeNames.SRC_SYS_KEY, srcPkey));
			record.setField(new Field(MDMAttributeNames.PARENT_ID, rowIdAccount));
			record.setField(new Field(MDMAttributeNames.CHILD_ID, contactRowid));
			record.setField(new Field(MDMAttributeNames.HIERARCHY_CODE, Constant.ROWID_CONTACT_HIERARCHY_TYPE));
			record.setField(new Field(MDMAttributeNames.REL_TYPE_CODE, Constant.ROWID_CONTACT_REL_TYPE));
			cleansePutRequest.setRecord(record);
			CleansePutResponse cleansePutResponse = (CleansePutResponse) siperianClient.process(cleansePutRequest);
			LOG.info("Account Contact Rel Put request processed successfully: " + cleansePutResponse.getMessage());
			RecordKey recordKey = cleansePutResponse.getRecordKey();
			responseDataHolder.setActionType(cleansePutResponse.getActionType());
			responseDataHolder.setActionMessage(cleansePutResponse.getMessage());
			responseDataHolder.setRowidObject(recordKey.getRowid());
			responseDataHolder.setRowidXREF(recordKey.getRowidXref());
			responseDataHolder.setSourceKey(recordKey.getSourceKey());
			responseDataHolder.setSystemName(recordKey.getSystemName());
			LOG.info("ROWID_OBJECT of created Party Account Rel record = " + recordKey.getRowid()
					+ "\nPKEY_SRC  of created Party Account Rel record = " + recordKey.getSourceKey());
			transaction.commit();
		} catch (Exception ex) {
			
			LOG.error("Exception occured while preparing/processing cleansePut requests: ", ex);
			try {
				transaction.rollback();
			} catch (SystemException txExcp) {
				LOG.error("Failed to rollback transaction for cleansePut requests : ", txExcp);
			}
			ServiceProcessingException customException = new ServiceProcessingException(ex);
			customException.setMessage("Failed to process cleansePut SIF request." + customException.getMessage());
			throw customException;
		} finally {
			checkIn(siperianClient);
		}
		LOG.debug("[cleansePutAccountContactRel] EXIT");
		return responseDataHolder;
	}

	/**
	 * The method prepares and executes PutRequest on PARTY_REL landing table
	 * for the given Contact profiles.
	 * 
	 * @param relRowidObj
	 * @throws ServiceProcessingException
	 */
	private void putContactRel(String relRowidObj) throws ServiceProcessingException {
		LOG.debug("[DummyUpdate] ENTER putContactRel");
		UserTransaction transaction = null;
		SiperianClient siperianClient = null;
		lastUpdateDate = Util.getCurrentTimeZone();
		try {
			PutRequest putRequest = new PutRequest();
			PutResponse putResponse = null;
			// String systemUser = "Admin";
			String srcSystem = "ELQ"; // trimming not required
			String srcPkey = null; // trimming not required
			String srcRowid = relRowidObj; // trimming not required
			LOG.info("Executing PutRequest with src_system=" + srcSystem + " | scr_pkey=" + srcPkey + " | rowid_object="
					+ srcRowid);

			// Fetch Siperian Object from
			siperianClient = (SiperianClient) checkOut();
			// create transaction - commit if Delete and Put requests both
			// succeeded
			transaction = ((EjbSiperianClient) siperianClient).createTX(1200); // in
																				// seconds
			transaction.begin();

			// prepare PutRequest
			RecordKey recordKey = new RecordKey();
			recordKey.setRowid(srcRowid);
			recordKey.setSystemName(srcSystem);
			putRequest.setRecordKey(recordKey);

			Record record = new Record();
			record.setSiperianObjectUid(SiperianObjectType.BASE_OBJECT.makeUid(MDMAttributeNames.PARTY_REL_BO));
			record.setField(new Field(MDMAttributeNames.LOAD_DT, lastUpdateDate));

			putRequest.setRecord(record);
			// execute Put request
			putResponse = (PutResponse) siperianClient.process(putRequest);

			LOG.info("Committing DummyUpdate in C_B_PARTY_REL");
			transaction.commit();
			LOG.info("DummyUpdate in C_B_PARTY_REL processed successfully: Action Type = " + putResponse.getActionType()
					+ " | Msg = " + putResponse.getMessage());
		} catch (Exception ex) {
			LOG.error("Exception occured while processing DummyUpdate in C_B_PARTY_REL: ", ex);
			try {
				transaction.rollback();
			} catch (SystemException txExcp) {
				LOG.error("Failed to rollback transaction for DummyUpdate in C_B_PARTY_REL : ", txExcp);
			}
			ServiceProcessingException customException = new ServiceProcessingException(ex);
			customException.setMessage("Failed to process cleansePut SIF request." + customException.getMessage());
		} finally {
			checkIn(siperianClient);
		}
		LOG.debug("[DummyUpdate] putContactRel EXIT");
	}
	
	/* Added for US68-Throughput Tracker START */
	
	/**
	 * Updating Msg Tracking ID in Party Table
	 * 
	 * @param rowidObject
	 * @param msgTrackingId
	 * @throws ServiceProcessingException
	 */
	private void putMsgTrackingId(String rowidObject, String msgTrackingId) throws ServiceProcessingException {
		LOG.debug("[putMsgTrackingId] ENTER");

		SiperianClient siperianClient = null;
		UserTransaction transaction = null;
		String systemUser = "admin";

		try {
			PutRequest putRequest = new PutRequest();
			PutResponse putResponse = null;
			String srcSystem = "Admin";
			LOG.debug("[putMsgTrackingId]Executing PutRequest with src_system=" + srcSystem 
					+ " | rowid_object=" + rowidObject);

			// Fetch Siperian Object from
			siperianClient = (SiperianClient) checkOut();
			// create transaction - commit if Delete and Put requests both
			// succeeded
			transaction = ((EjbSiperianClient) siperianClient).createTX(1200); // in
																				// seconds
			transaction.begin();

			// prepare PutRequest
			RecordKey recordKey = new RecordKey();
			recordKey.setRowid(rowidObject);
			recordKey.setSystemName(srcSystem);
			putRequest.setRecordKey(recordKey);

			Record record = new Record();
			record.setSiperianObjectUid(SiperianObjectType.BASE_OBJECT.makeUid(MDMAttributeNames.PARTY_BO));
			record.setField(new Field(MDMAttributeNames.SRC_UPDT_BY, systemUser));
			record.setField(new Field(PartyAttributes.MSG_TRKN_ID, msgTrackingId));

			putRequest.setRecord(record);
			// execute Put request
			putResponse = (PutResponse) siperianClient.process(putRequest);

			LOG.debug("[putMsgTrackingId]Committing MSG_TRKN_ID transaction");
			transaction.commit();
			LOG.debug("[putMsgTrackingId]Put request for MSG_TRKN_ID assignment processed successfully: "
					+ "Action Type = " + putResponse.getActionType() + " | Msg = " + putResponse.getMessage());

		} catch (SiperianServerException sifExcp) {
			LOG.error("[putMsgTrackingId]SiperianServerException occured while assigning MSG_TRKN_ID"
					+ " by Put request: ", sifExcp);
			ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
			customException.setMessage(
					"SiperianServerException occured while assigning UCN by Put request: " + sifExcp.getMessage());
			throw customException;
		} catch (Exception excp) {
			LOG.error("[putMsgTrackingId]Exception occured while assigning MSG_TRKN_ID by Put request: ", excp);
			ServiceProcessingException customException = new ServiceProcessingException(excp);
			customException.setMessage("Exception occured while assigning MSG_TRKN_ID by Put request: " 
											+ excp.getMessage());
			throw customException;
		} finally {
			checkIn(siperianClient);
		}

		LOG.debug("[putMsgTrackingId] EXIT");
	}
	
	/* Added for US68-Throughput Tracker END */

	/**
	 * Create error response for account upsert
	 * 
	 * @param upsertResponse
	 * @param errorPropId
	 * @param srcPkey
	 */
	private void createAccountUpsertErrorResponse(UpsertPartyResponse upsertResponse, String errorPropId,
			String srcPkey) {
		LOG.debug("[createAccountUpsertErrorResponse] START::srcPkey::" + srcPkey + ", errorPropId::" + errorPropId);
		PartyUpsertRespType partyUpsertRespType = new PartyUpsertRespType();
		if (srcPkey == null) {
			partyUpsertRespType.setErrorMsg(messagesProp.getProperty(errorPropId));
		} else {
			partyUpsertRespType.setSRCSYSTEMID(srcPkey);
			partyUpsertRespType
					.setErrorMsg("Error in SRC PKEY::" + srcPkey + "::" + messagesProp.getProperty(errorPropId));
		}
		upsertResponse.getParty().add(partyUpsertRespType);
		LOG.debug("[createAccountUpsertErrorResponse] EXIT::Error Message::" + partyUpsertRespType.getErrorMsg());
	}

	/**
	 * Create error response for account upsert
	 * 
	 * @param upsertResponse
	 * @param errorPropId
	 * @param srcPkey
	 * @param e
	 */
	private void createAccountUpsertErrorResponse(UpsertPartyResponse upsertResponse, String errorPropId,
			String srcPkey, Exception e) {
		LOG.debug("[createAccountUpsertErrorResponse] START::srcPkey::" + srcPkey + ", errorPropId::" + errorPropId);
		PartyUpsertRespType partyUpsertRespType = new PartyUpsertRespType();
		if (srcPkey == null) {
			partyUpsertRespType.setErrorMsg(messagesProp.getProperty(errorPropId));
		} else {
			partyUpsertRespType.setSRCSYSTEMID(srcPkey);
			partyUpsertRespType
					.setErrorMsg("Error in SRC PKEY::" + srcPkey + "::" + messagesProp.getProperty(errorPropId));
		}
		if (e != null) {
			partyUpsertRespType.setErrorMsg(partyUpsertRespType.getErrorMsg() + e.getMessage());
		}
		upsertResponse.getParty().add(partyUpsertRespType);
		LOG.debug("[createAccountUpsertErrorResponse] EXIT::Error Message::" + partyUpsertRespType.getErrorMsg());
	}

	/**
	 * Create Info messages for account upsert
	 * 
	 * @param upsertResponse
	 * @param errorPropId
	 * @param srcPkey
	 */
	private void createAccountUpsertInfoMessage(UpsertPartyResponse upsertResponse, String infoPropId, String srcPkey) {
		LOG.debug("[createAccountUpsertInfoMessage] START::srcPkey::" + srcPkey);
		String respMsg = null;
		if (srcPkey == null) {
			respMsg = messagesProp.getProperty(infoPropId);
		} else {
			respMsg = "SRC PKEY::" + srcPkey + "::" + messagesProp.getProperty(infoPropId);
		}
		if (Util.isNullOrEmpty(upsertResponse.getStatus())) {
			upsertResponse.setStatus(respMsg);
		} else {
			upsertResponse.setStatus(upsertResponse.getStatus() + "\n" + respMsg);
		}
		LOG.debug("[createAccountUpsertInfoMessage] EXIT");
	}

	private void processUpsertRequestForIndividualContact(PartyXrefType partyXrefType,
			UpsertPartyResponse upsertContactResponse) throws ServiceProcessingException {
		LOG.debug("Executing processUpsertRequestForIndividualContact()");
		PerformanceLoggerUtil perfLog = new PerformanceLoggerUtil();
		String srcSystem = partyXrefType.getXREF().get(0).getSRCSYSTEM();
		String srcPkey = partyXrefType.getXREF().get(0).getSRCPKEY();
		String rowidParty = null;
		
		perfLog.printLog(Constant.PERF_LOG_FLOW_UPSERT_ELQ_CONTACT, srcPkey, 
				"STEP 3", "Validation Done");

		// Data structures for handling Match & Merge
		HashMap<Integer, HighestScoreRecordHolder> mergeSorceHolderMap = new HashMap<Integer, HighestScoreRecordHolder>();
		HighestScoreRecordHolder highestScoreRecordHoldertgt = new HighestScoreRecordHolder();

		// execute cleansePut SIF requests
		Map<String, Object> putRespDataHolderMap = processCleansePutRequest(partyXrefType, upsertContactResponse);
		// process response
		PutResponseDataHolder putRespDataParty = (PutResponseDataHolder) putRespDataHolderMap
				.get(MDMAttributeNames.ENTITY_PARTY);

		rowidParty = putRespDataParty.getRowidObject();
		//
		List<CommunicationXrefType> contactCommList = null;
		CommunicationXrefType commXrefType = null;

		PartyXrefType insertedContactData = new PartyXrefType();

		try {
			// insertedPartyData =
			// getPartyDAO.getParty(putRespDataParty.getRowidObject());
			insertedContactData = getPartyDAO.fetchContactXrefTypeFromORS(putRespDataParty.getSystemName(),
					putRespDataParty.getSourceKey());
			sipPopVal = getPartyDAO.getSipPopFromXref();
			LOG.info("Got insertedContactData from GetPartyDAO for ContactID: " + insertedContactData.getROWIDOBJECT());
			LOG.info("sipPopVal is: " + sipPopVal);

			// Assuming that 1 Contact record will have 1 Email Value
			contactCommList = insertedContactData.getCommunication();
			for (int indx = 0; indx < contactCommList.size(); indx++) {
				commXrefType = contactCommList.get(indx);
				if (commXrefType.getCOMMTYPE().equalsIgnoreCase("Email")) {
					commEmlVal = commXrefType.getCOMMVALUE();
					isEmailValExists = Boolean.TRUE;
				}
			}
		} catch (ServiceProcessingException servExcp) {
			LOG.error("Exception occurred while invoking GetPartyDAO: " + servExcp.toString());

		} catch (Exception exp) {
			LOG.error("Caught exception while Fetching newly inserted Contact Record: " + exp);
		}

		if ("Insert".equalsIgnoreCase(putRespDataParty.getActionType())) {

			try {
				if (isEmailValExists) {
					// If Contact has minimum 1 Email then only proceed for
					// match & merge
					mergeProcessContact(putRespDataHolderMap, mergeSorceHolderMap, upsertContactResponse,
							highestScoreRecordHoldertgt, insertedContactData);
					LOG.debug("Merge is successful on ELQ_Contact PARTY & ACCOUNT entities !!");
				}
			} catch (ServiceProcessingException servExcp) {

				LOG.error("Caught ServiceProcessingException in mergeProcessContact: ", servExcp);
				LOG.error("Root Exception Message: " + servExcp.getRootExceptionMsg());
				LOG.error("Localized Message: " + servExcp.getCause().getLocalizedMessage());
				LOG.error(" Message: " + servExcp.getCause().getMessage());
			} catch (Exception Excp) {
				LOG.error("Caught exception in mergeProcessContact: ", Excp);
			}

			// Checking whether Match and Merge Operation Done or not
			if (matchInd) {
				upsertContactResponse
						.setStatus(upsertContactResponse.getStatus() + " Matching record found for Contact.");
				matchInd = false;
			} else {
				upsertContactResponse
						.setStatus(upsertContactResponse.getStatus() + " No matching record found for Contact.");
			}
			if (mergeInd) {
				upsertContactResponse.setStatus(
						upsertContactResponse.getStatus() + " Merge operation successful for Party and Contact "
								+ putRespDataParty.getSourceKey() + ". Surviving rowid_object = "
								+ upsertContactResponse.getParty().get(partyCount - 1).getROWIDOBJECT());
			} else {
				upsertContactResponse.setStatus(upsertContactResponse.getStatus() + " Merge not done for Contact "
						+ putRespDataParty.getSourceKey());
			}
		} // End If("Insert")

		PartyType survivingContactProfileFromBO = null;
		String survivingContactRowid = upsertContactResponse.getParty().get(partyCount - 1).getROWIDOBJECT();
		LOG.info("Party rowid_object of merged/newly created record = " + survivingContactRowid);

		/**GTM#1: US335 : Retry on Multi-Merge Indicator**/
		int multiMergecountOfRetry = Integer.parseInt(configProps.getProperty("NoOfRetries"));
		boolean isMergeRetrySuccess = false;
		// Fetch base object records for new party or surviving party using
		// canonical structure
		if ("Update".equalsIgnoreCase(putRespDataParty.getActionType())
				|| "Insert".equalsIgnoreCase(putRespDataParty.getActionType())) {
				survivingContactProfileFromBO = getPartyDAO.getBOContact(survivingContactRowid);
			try {
				// Merge address, communication and classification child
				// entities
				mergeProcessMultipleChild(survivingContactProfileFromBO, upsertContactResponse);
				LOG.debug("Multi-Merge is successful on ELQ_Contact - Address & Communication child entities");
			} catch (Exception servExcp) {
				//	mergeInd = false;
				LOG.error("Exception occured while Multi-Merge on ELQ_Contact - Address, Communication: " , servExcp);
				for(int i = 0; i<multiMergecountOfRetry; i++)	{
				try{
					LOG.debug("Retrying Multi-Merge process in ELQ_Contact for "+ (i+1) +"th time");
					mergeProcessMultipleChild(survivingContactProfileFromBO, upsertContactResponse);
					LOG.debug("Multi-Merge in ELQ_Contact is successful on attempt no. "+ (i+1));
					isMergeRetrySuccess = true;
				//	mergeInd = true;
					break;
				} catch (Exception excp) {
					LOG.error("Exception occured in Multi-Merge Retry in ELQ_Contact on attempt no. "+ (i+1));
					LOG.error("Exception occured in Multi-Merge in ELQ_Contact RetryMechanism...");
				}
				}
				if(!isMergeRetrySuccess){
					ServiceProcessingException customException = new ServiceProcessingException(servExcp);
					customException.setMessage("SIF exception occured while processing Multi-Merge on ELQ_Contact Address/Communication : " + customException.getMessage());
					throw customException;
				}
			//	LOG.debug("Caught exception while executing GetPartyDAO For Contact OR in method- mergeProcessMultipleChild()",servExcp);
			}
		}

		// UCN Assignment Process
		if ("Insert".equalsIgnoreCase(putRespDataParty.getActionType())) {
			try {

				String existingUCN = prospectPartyDAO.checkifUCNExists(survivingContactRowid);
				// Setting UCN value by Calling GET_UCN
				if (Util.isNullOrEmpty(existingUCN)) {

					if (survivingContactProfileFromBO != null) {
						LOG.info("UCN for the surviving/new party is Null.");
						setContactUCNSeq(survivingContactRowid);
						LOG.debug("UCN value successfully assigned.");
						upsertContactResponse
								.setStatus(upsertContactResponse.getStatus() + " UCN value assigned successfully.");
					}
				} else {
					LOG.info("Surviving Record rowID: " + survivingContactRowid + "  has UCN present: " + existingUCN);

				}
			} catch (ServiceProcessingException spExcp) {

				LOG.error("Failed to set UCN: ", spExcp);
			} catch (Exception Excp) {

				LOG.error("Caught exception while updating UCN: ", Excp);
			}
		}

		/** Dummy Update on C_B_PARTY_REL for already existing Contact Rowid **/
		if ("Insert".equalsIgnoreCase(putRespDataParty.getActionType())) {
			try {

				String relRowid = prospectPartyDAO.checkifCntctRelExists(survivingContactRowid);
				/*
				 * If Contact_Id exists in PARTY_REL table, then do Dummy Update
				 * on PARTY_REL table
				 */
				if (!Util.isNullOrEmpty(relRowid)) {

					LOG.info("Perform Dummy Update on PARTY_REL table for REL_ROWID_OBJECT: " + relRowid);
					putContactRel(relRowid);
					
					/** Modified for US68-Throughput Tracker START */
					try {
						putMsgTrackingId(survivingContactRowid, partyXrefType.getMSGTRKNID());
					} catch (ServiceProcessingException spExcp) {
						LOG.error("Failed to set MSG_TRKN_ID: ", spExcp);
						upsertContactResponse.setStatus(upsertContactResponse.getStatus() + 
								"\nMSG_TRKN_ID update failed");
					} catch (Exception Excp) {
						LOG.error("Caught exception while updating MSG_TRKN_ID: ", Excp);
						upsertContactResponse.setStatus(upsertContactResponse.getStatus() + 
								"\nMSG_TRKN_ID update failed");
					}
					/** Modified for US68-Throughput Tracker END */
				} else {
					LOG.info("Surviving Contact Record rowID: " + survivingContactRowid
							+ " does not have Relation with any Prospect/Account in PARTY_REL.");
				}
			} catch (ServiceProcessingException spExcp) {

				LOG.error("Failed to Dummy Update on C_B_PARTY_REL: ", spExcp);
			} catch (Exception Excp) {

				LOG.error("Caught exception while Dummy Update on C_B_PARTY_REL: ", Excp);
			}
		}

		/*
		 * Process pending Contact-Account Relationship for both Insert & Update
		 * Contact operations
		 */
		if ("Update".equalsIgnoreCase(putRespDataParty.getActionType())
				|| "Insert".equalsIgnoreCase(putRespDataParty.getActionType())) {
			processAcntCntctRel(upsertContactResponse, null, rowidParty, srcSystem, srcPkey,
					Constant.BO_CLASS_CODE_PERSON);
		}
		//BO to Xref for ELQ Contact
		List<String> sendToSrcList = null;
		sendToSrcList = getPartyDAO.getSentToList(putRespDataParty.getActionType(), putRespDataParty.getSystemName(),true);
		
		LOG.debug("Check for which source system to send Done");

		// Invoking processUpdateRequest() for Dummy Update process.
		try {
			LOG.info("Invoking processUpdateRequest() to get BO to Xref update Record.");
			/** changes for Sales Force Integration  */
			upsertContactDAO.processUpdateRequest(partyXrefType, insertedContactData, sendToSrcList, rowidParty,
					survivingContactProfileFromBO);

		} catch (ServiceProcessingException Excp) {
			LOG.error("Caught Service Exception while updating BO to Xref Record: ", Excp);


		} catch (Exception Excp) {
			LOG.error("Caught Generic Exception while updating BO to Xref  Record: ", Excp);

		}
		LOG.debug("Completed processUpsertRequestForIndividualContact()");
	}

	
	/**
	 * The method process cleansePut SIF requests for entire Party profile
	 * (Party and child entities) in the request. It handles transaction as per
	 * business need. After successful put calls, it stores the created
	 * rowid_object of the entities into respective response object
	 *
	 * @param UpsertPartyRequest
	 *            The web service request object
	 * @param UpsertPartyResponse
	 *            response object for web service
	 * @return Map<String, Object> a collection of entity-wise cleansePut
	 *         response values clubbed in PutResponseDataHolder object
	 * @throws ServiceProcessingException
	 */
	private Map<String, Object> processCleansePutRequest(PartyXrefType upsertParty, UpsertPartyResponse upsertResponse)
			throws ServiceProcessingException {

		LOG.info("Executing processCleansePutRequest()");

		SiperianClient siperianClient = null;
		UserTransaction transaction = null;

		PartyXrefType partyParam = upsertParty;
		PutResponseDataHolder putRespDataParty = null;
		List<PutResponseDataHolder> putRespDataProspectList = null;
		List<PutResponseDataHolder> putRespDataAddressList = null;
		List<PutResponseDataHolder> putRespDataCommunicationList = null;
		List<PutResponseDataHolder> putRespDataPartyPrsnList = null;
		Map<String, Object> putRespDataHolderMap = new HashMap<String, Object>();

		try {
			siperianClient = (SiperianClient) checkOut();

			// create transaction - commit if cleansePut requests succeed for
			// Party and all the child entities
			transaction = ((EjbSiperianClient) siperianClient).createTX(300000);
			transaction.begin();

			lastUpdateDate = Util.getCurrentTimeZone();

			// Create Party
			putRespDataParty = cleansePutParty(partyParam, siperianClient);

			// Create Prospect
			List<AccountXrefType> prospectXrefTypeList = partyParam.getAccount();
			if (!CollectionUtils.isEmpty(prospectXrefTypeList)) {
				putRespDataProspectList = cleansePutProspect(prospectXrefTypeList, partyParam, siperianClient);
			}

			// Create Address
			List<AddressXrefType> addressXrefTypeList = partyParam.getAddress();
			if (!CollectionUtils.isEmpty(addressXrefTypeList)) {
				putRespDataAddressList = cleansePutAddress(addressXrefTypeList, partyParam, siperianClient);
			}

			// Create Communication
			List<CommunicationXrefType> commXrefTypeList = partyParam.getCommunication();
			if (!CollectionUtils.isEmpty(commXrefTypeList)) {
				putRespDataCommunicationList = cleansePutCommunication(commXrefTypeList, partyParam, siperianClient);
			}

			// Create Party Person
			List<PartyPersonXrefType> partyPersonXrefTypeList = partyParam.getPartyPerson();
			if (!CollectionUtils.isEmpty(partyPersonXrefTypeList)) {
				putRespDataPartyPrsnList = cleansePutPerson(partyPersonXrefTypeList, partyParam, siperianClient);
			}

			LOG.info("Control back in processCleansePut().");

			// commit transaction
			transaction.commit();
			LOG.info("Transaction Commited in processCleansePut().");
			partyCount++;

			// set response status
			upsertResponse.setStatus(Util.isNullOrEmpty(upsertResponse.getStatus())? 
					"" : upsertResponse.getStatus() + "\n");
			upsertResponse.setStatus(upsertResponse.getStatus() + putRespDataParty.getActionType()
					+ " operation successful for Party " + putRespDataParty.getSourceKey());

		} catch (ServiceProcessingException excp) {
			upsertResponse.setErrorMsg(excp.getRootExceptionMsg());
			upsertParty.setErrorMsg("CleansePut operation failed");

			LOG.error("Exception occured while preparing/processing cleansePut requests: ", excp);
			try {
				transaction.rollback();

			} catch (SystemException txExcp) {
				LOG.error("Failed to rollback transaction for cleansePut requests : " + txExcp.toString());
			}
			throw excp;
		} catch (Exception ex) {
			upsertResponse.setErrorMsg("CleansePut operation failed for Party " + putRespDataParty.getSourceKey());
			upsertParty.setErrorMsg("CleansePut operation failed");

			LOG.error("Exception occured while preparing/processing cleansePut requests: ", ex);
			ex.printStackTrace();
			try {
				transaction.rollback();
			} catch (SystemException txExcp) {
				LOG.error("Failed to rollback transaction for cleansePut requests : " + txExcp.toString());
				txExcp.printStackTrace();
			}
			ServiceProcessingException customException = new ServiceProcessingException(ex);
			customException.setMessage("Failed to process cleansePut SIF request." + customException.getMessage());
			throw customException;
		} finally {
			checkIn(siperianClient);
		}
		try {
			// set rowid_object of created records into response and
			// set the PutResponseDataHolder object/list of object into Map
			// against corresponding entity name
			// set rowid_object of Party into response
			PartyUpsertRespType partyUpsertResp = new PartyUpsertRespType();
			List<Account> prospectList = new ArrayList<Account>();
			List<Address> addressList = new ArrayList<Address>();
			List<Communication> commList = new ArrayList<Communication>();
			List<PartyPerson> partyPersonList = new ArrayList<PartyPerson>();

			// set rowid_object of Party into response
			if (putRespDataParty != null) {
				partyUpsertResp.setROWIDOBJECT(putRespDataParty.getRowidObject());
				partyUpsertResp.setSRCSYSTEM(putRespDataParty.getSystemName());
				partyUpsertResp.setSRCSYSTEMID(putRespDataParty.getSourceKey());
				putRespDataHolderMap.put(MDMAttributeNames.ENTITY_PARTY, putRespDataParty);
			}

			// set rowid_object of Prospect into response
			if (!CollectionUtils.isEmpty(putRespDataProspectList)) {
				putRespDataHolderMap.put(MDMAttributeNames.ENTITY_PROSPECT, putRespDataProspectList);
				for (PutResponseDataHolder putRespDataProspect : putRespDataProspectList) {
					Account prospect = new Account();
					prospect.setROWIDACCOUNT(putRespDataProspect.getRowidObject());
					prospect.setSRCSYSTEM(putRespDataProspect.getSystemName());
					prospect.setSRCSYSTEMID(putRespDataProspect.getSourceKey());
					prospectList.add(prospect);
				}
			}

			// set rowid_object of Address into response
			if (!CollectionUtils.isEmpty(putRespDataAddressList)) {
				putRespDataHolderMap.put(MDMAttributeNames.ENTITY_ADDRESS, putRespDataAddressList);
				for (PutResponseDataHolder putRespDataAddress : putRespDataAddressList) {
					Address address = new Address();
					address.setROWIDADDRESS(putRespDataAddress.getRowidObject());
					address.setSRCSYSTEM(putRespDataAddress.getSystemName());
					address.setSRCSYSTEMID(putRespDataAddress.getSourceKey());
					addressList.add(address);
				}
			}

			// set rowid_object of Communication into response
			if (!CollectionUtils.isEmpty(putRespDataCommunicationList)) {
				putRespDataHolderMap.put(MDMAttributeNames.ENTITY_COMM, putRespDataCommunicationList);
				for (PutResponseDataHolder putRespDataCommunication : putRespDataCommunicationList) {
					Communication comm = new Communication();
					comm.setROWIDCOMMUNICATION(putRespDataCommunication.getRowidObject());
					comm.setSRCSYSTEM(putRespDataCommunication.getSystemName());
					comm.setSRCSYSTEMID(putRespDataCommunication.getSourceKey());
					commList.add(comm);
				}
			}
			// set rowid_object of Classification into response
			if (!CollectionUtils.isEmpty(putRespDataPartyPrsnList)) {
				putRespDataHolderMap.put(MDMAttributeNames.ENTITY_PARTY_PRSN, putRespDataPartyPrsnList);
				for (PutResponseDataHolder putRespDataPartyPrsn : putRespDataPartyPrsnList) {
					PartyPerson partyPerson = new PartyPerson();
					partyPerson.setROWIDPERSON(putRespDataPartyPrsn.getRowidObject());
					partyPerson.setSRCSYSTEM(putRespDataPartyPrsn.getSystemName());
					partyPerson.setSRCSYSTEMID(putRespDataPartyPrsn.getSourceKey());
					partyPersonList.add(partyPerson);
				}
			}
			partyUpsertResp.getAccount().addAll(prospectList);
			partyUpsertResp.getAddress().addAll(addressList);
			partyUpsertResp.getCommunication().addAll(commList);
			partyUpsertResp.getPartyPerson().addAll(partyPersonList);
			upsertResponse.getParty().add(partyUpsertResp);
		} catch (Exception excp) {
			LOG.error("Exception occured while processing CleansePut response for Party "
					+ putRespDataParty.getSourceKey(), excp);
			ServiceProcessingException customException = new ServiceProcessingException(excp);
			customException.setMessage("Exception occured while processing CleansePut response for Party. "
					+ customException.getMessage());
		}

		try {

			processTokenizeRequest(putRespDataParty);

			upsertResponse.setStatus(upsertResponse.getStatus() + "\nTokenization operation successful for Party "
					+ putRespDataParty.getSourceKey());
		} catch (SiperianServerException sifExcp) {
			LOG.error("SiperianServerException occured while processing TokenizeRequest for Party");
			ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
			customException.setMessage("SIF exception occured while processing Tokenize request for Party. "
					+ customException.getMessage());
		} catch (Exception excp) {
			LOG.error("Exception occured while processing TokenizeRequest for Party");
			ServiceProcessingException customException = new ServiceProcessingException(excp);
			customException.setMessage(
					"Exception occured while processing Tokenize request for Party." + customException.getMessage());
		}

		LOG.info("Executed processCleansePutRequest()");
		return putRespDataHolderMap;
	}

	/**
	 * The method prepares and executes CleansePutRequest on PARTY landing table
	 * for the given Party profile.
	 *
	 * @param partyParam
	 *            Party profile provided to the web service request
	 * @param siperianClient
	 *            SiperianClient SIF connection to MDM Hub
	 * @return PutResponseDataHolder object containing processing results
	 * @throws ServiceProcessingException
	 */
	private PutResponseDataHolder cleansePutParty(PartyXrefType partyParam, SiperianClient siperianClient)
			throws ServiceProcessingException {
		LOG.info("Executing cleansePutParty()");
		int itemIndex = 0;
		CleansePutRequest cleansePutRequest = new CleansePutRequest();
		CleansePutResponse cleansePutResponse = null;
		PutResponseDataHolder responseDataHolder = null;

		try {

			// prepare CleansePutRequest
			Record record = new Record();
			// set mapping name
			record.setSiperianObjectUid(Util.getMappingObjectUid(partyParam.getXREF().get(itemIndex).getSRCSYSTEM(),
					MDMAttributeNames.ENTITY_PARTY));
			// set input values
			if (partyParam.getLASTUPDATEDATE() != null && partyParam.getLASTUPDATEDATE().length() > 0) {
				record.setField(new Field(MDMAttributeNames.LAST_UPDATE_DATE, partyParam.getLASTUPDATEDATE()));
			} else {
				LOG.info("Performing cleansePutParty with sysdate from HUB: " + lastUpdateDate);
				record.setField(new Field(MDMAttributeNames.LAST_UPDATE_DATE, lastUpdateDate));
			}
			record.setField(new Field(MDMAttributeNames.SRC_CREATE_DT, partyParam.getSRCCREATEDT()));

			record.setField(new Field(MDMAttributeNames.SRC_UPDT_BY, partyParam.getUPDATEBY()));
			record.setField(
					new Field(MDMAttributeNames.SRC_SYSTEM, (partyParam.getXREF().get(itemIndex)).getSRCSYSTEM()));
			record.setField(
					new Field(MDMAttributeNames.SRC_SYS_KEY, (partyParam.getXREF().get(itemIndex)).getSRCPKEY()));
			record.setField(new Field(PartyAttributes.ENTITY_TYPE, partyParam.getBOCLASSCODE()));
			record.setField(new Field(PartyAttributes.PARTY_NAME, partyParam.getPARTYNAME()));
			record.setField(new Field(PartyAttributes.PARTY_TYPE, partyParam.getPARTYTYPE()));
			record.setField(new Field(PartyAttributes.GEO, partyParam.getGEO()));
			record.setField(new Field(PartyAttributes.REGION, partyParam.getREGION()));
			record.setField(new Field(PartyAttributes.SALES_BLOCK_CD, partyParam.getSALESBLOCKCD()));
			record.setField(new Field(PartyAttributes.TAX_JURSDCTN_CD, partyParam.getTAXJURSDCTNCD()));
			record.setField(new Field(PartyAttributes.VAT_REG_NBR, partyParam.getVATREGNBR()));

			record.setField(new Field(PartyAttributes.STATUS_CD, partyParam.getSTATUSCD()));

			// No UCN for ELQ Contact records
			/*
			 * if (!Util.isNullOrEmpty(partyParam.getUCN())) {
			 * record.setField(new Field(PartyAttributes.UCN, partyParam
			 * .getUCN())); }
			 */
			record.setField(new Field(PartyAttributes.COUNTRY_CD, partyParam.getAddress().get(0).getCOUNTRYCD()));

			record.setField(new Field(PartyAttributes.ENGLISH_NAME, partyParam.getENGLISHNAME()));
			
			/** Modified for US68-Throughput Tracker START */
			record.setField(new Field(PartyAttributes.MSG_TRKN_ID, partyParam.getMSGTRKNID()));
			/** Modified for US68-Throughput Tracker END */

			cleansePutRequest.setRecord(record);
			// execute Put request
			cleansePutResponse = (CleansePutResponse) siperianClient.process(cleansePutRequest);
			LOG.info("Party cleansePut request processed successfully: " + cleansePutResponse.getMessage());
			// extract result
			RecordKey recordKey = cleansePutResponse.getRecordKey();

			responseDataHolder = new PutResponseDataHolder();
			responseDataHolder.setActionType(cleansePutResponse.getActionType());
			responseDataHolder.setActionMessage(cleansePutResponse.getMessage());
			responseDataHolder.setRowidObject(recordKey.getRowid());
			responseDataHolder.setRowidXREF(recordKey.getRowidXref());
			responseDataHolder.setSourceKey(recordKey.getSourceKey());
			responseDataHolder.setSystemName(recordKey.getSystemName());
			LOG.info("ROWID_OBJECT of created Party record = " + recordKey.getRowid());

			LOG.debug("Action Type = " + responseDataHolder.getActionType());
			LOG.debug("Action Msg = " + responseDataHolder.getActionMessage());
			LOG.debug("Rowid_xref = " + responseDataHolder.getRowidXREF());
			LOG.debug("Src key = " + responseDataHolder.getSourceKey());
			LOG.debug("System = " + responseDataHolder.getSystemName());

		} catch (SiperianServerException sifExcp) {
			LOG.error("SiperianServerException occured while processing CleansePutRequest for Party: ", sifExcp);
			LOG.error("Get Message: " + sifExcp.getMessage());
			LOG.error("sifExcp msg " + sifExcp);
			sifExcp.printStackTrace();
			ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
			customException.setRootExceptionMsg(sifExcp + " CleansePut operation failed for Party "
					+ (partyParam.getXREF().get(itemIndex)).getSRCPKEY());
			customException.setMessage(
					"SIF exception occured while processing Put request for Party." + customException.getMessage());
			throw customException;
		} catch (Exception excp) {
			LOG.error("Exception occured while processing CleansePutRequest for Party: ", excp);
			LOG.error("excp msg " + excp);
			ServiceProcessingException customException = new ServiceProcessingException(excp);
			customException.setMessage(
					"Exception occured while processing Put request for Party." + customException.getMessage());
			customException.setRootExceptionMsg(excp + " CleansePut operation failed for Party "
					+ (partyParam.getXREF().get(itemIndex)).getSRCPKEY());
			throw customException;
		}

		LOG.info("Executed cleansePutParty()");
		return responseDataHolder;
	}

	/**
	 * The method prepares and executes CleansePutRequest on PARTY_PROSPECT
	 * landing table for the given Account profiles.
	 *
	 * @param prospectList
	 *            List of Accounts provided to the web service request
	 * @param partyParam
	 *            Party profile provided to the web service request
	 * @param siperianClient
	 *            SiperianClient SIF connection to MDM Hub
	 * @return List of PutResponseDataHolder object containing processing
	 *         results
	 * @throws ServiceProcessingException
	 */
	private List<PutResponseDataHolder> cleansePutProspect(List<AccountXrefType> prospectList, PartyXrefType partyParam,
			SiperianClient siperianClient) throws ServiceProcessingException {
		LOG.debug("[cleansePutProspect] ENTER");
		CleansePutRequest cleansePutRequest = null;
		CleansePutResponse cleansePutResponse = null;
		List<PutResponseDataHolder> responseDataHolderList = new ArrayList<PutResponseDataHolder>(prospectList.size());
		for (AccountXrefType prospectParam : prospectList) {
			try {
				cleansePutRequest = new CleansePutRequest();
				// prepare CleansePutRequest
				Record record = new Record();
				// set mapping name
				record.setSiperianObjectUid(
						Util.getMappingObjectUid(prospectParam.getSRCSYSTEM(), MDMAttributeNames.ENTITY_PROSPECT));
				// set input values
				if (partyParam.getLASTUPDATEDATE() != null && partyParam.getLASTUPDATEDATE().length() > 0) {
					record.setField(new Field(MDMAttributeNames.LAST_UPDATE_DATE, partyParam.getLASTUPDATEDATE()));
				} else {
					LOG.info("[cleansePutProspect]Performing cleansePutProspect with sysdate from HUB: "
							+ lastUpdateDate);
					record.setField(new Field(MDMAttributeNames.LAST_UPDATE_DATE, lastUpdateDate));
				}
				record.setField(new Field(MDMAttributeNames.SRC_SYSTEM, prospectParam.getSRCSYSTEM()));
				if (Util.isNullOrEmpty(prospectParam.getSRCPKEY())) {
					record.setField(new Field(MDMAttributeNames.SRC_SYS_KEY, partyParam.getXREF().get(0).getSRCPKEY()));
				} else {
					record.setField(new Field(MDMAttributeNames.SRC_SYS_KEY, prospectParam.getSRCPKEY()));
				}
				record.setField(new Field(ProspectAttributes.PROSPECT_GEO, prospectParam.getACCOUNTGEO()));
				record.setField(new Field(ProspectAttributes.PROSPECT_REGION, prospectParam.getACCOUNTREGION()));
				record.setField(new Field(ProspectAttributes.PROSPECT_NAME, partyParam.getPARTYNAME()));
				if (Util.isNullOrEmpty(prospectParam.getACCTSTATUS())) {
					record.setField(new Field(ProspectAttributes.PROSPECT_STATUS, Constant.DEAFULT_PROSPECT_STATUS));
				} else {
					record.setField(new Field(ProspectAttributes.PROSPECT_STATUS, prospectParam.getACCTSTATUS()));
				}
				record.setField(new Field(ProspectAttributes.PROSPECT_TYPE, prospectParam.getACCTTYPE()));
				record.setField(new Field(ProspectAttributes.ALIAS_NAME, prospectParam.getALIASNAME()));
				record.setField(new Field(ProspectAttributes.NON_VAL_ACCT_IND, prospectParam.getNONVALACCTIND()));
				record.setField(new Field(ProspectAttributes.DATA_SRC_SYSTEM, prospectParam.getDATASRCSYSTEM()));
				record.setField(new Field(ProspectAttributes.NAME_QUALITY_IDENTIFIER, prospectParam.getNAMEQUALITYIDENTIFIER()));
				
				/*Change for MDMP-2885 :: START*/
				record.setField(new Field(ProspectAttributes.IS_DENIED_FLG, prospectParam.getISDENIEDFLG()));
				/*Change for MDMP-2885 :: END*/
				
				record.setField(
						new Field(MDMAttributeNames.PARTY_SRC_SYS_KEY, partyParam.getXREF().get(0).getSRCPKEY()));

				cleansePutRequest.setRecord(record);
				LOG.info("request NAME_QUALITY_IDENTIFIER:: "+ prospectParam.getNAMEQUALITYIDENTIFIER());
				// execute Put request
				cleansePutResponse = (CleansePutResponse) siperianClient.process(cleansePutRequest);
				LOG.info("Prospect cleansePut request processed successfully: " + cleansePutResponse.getMessage());
				// extract result
				RecordKey recordKey = cleansePutResponse.getRecordKey();

				PutResponseDataHolder responseDataHolder = new PutResponseDataHolder();
				responseDataHolder.setActionType(cleansePutResponse.getActionType());
				responseDataHolder.setActionMessage(cleansePutResponse.getMessage());
				responseDataHolder.setRowidObject(recordKey.getRowid());
				responseDataHolder.setRowidXREF(recordKey.getRowidXref());
				responseDataHolder.setSourceKey(recordKey.getSourceKey());
				responseDataHolder.setSystemName(recordKey.getSystemName());
				responseDataHolderList.add(responseDataHolder);
				LOG.info("ROWID_OBJECT of created Account record = " + recordKey.getRowid());
				LOG.debug("Action Type = " + responseDataHolder.getActionType());
				LOG.debug("Action Msg = " + responseDataHolder.getActionMessage());
			} catch (SiperianServerException sifExcp) {
				LOG.error("SiperianServerException occured while processing CleansePutRequest for Account: " + sifExcp);
				LOG.error("Root Cause: " + sifExcp.getCause().getMessage());
				LOG.error("msg ", sifExcp);
				sifExcp.printStackTrace();
				ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
				customException.setMessage("SIF exception occured while processing Put request for Account. "
						+ customException.getMessage());
				customException.setRootExceptionMsg(
						sifExcp + " CleansePut operation failed for Account " + prospectParam.getSRCPKEY());
				throw customException;
			} catch (Exception excp) {
				LOG.error("Exception occured while processing CleansePutRequest for Party: " + excp);
				excp.printStackTrace();
				ServiceProcessingException customException = new ServiceProcessingException(excp);
				customException.setMessage(
						"Exception occured while processing Put request for Account. " + customException.getMessage());
				customException.setRootExceptionMsg(
						excp + " CleansePut operation failed for Account " + prospectParam.getSRCPKEY());
				throw customException;
			}
		}

		LOG.debug("[cleansePutProspect] EXIT");
		return responseDataHolderList;
	}

	/**
	 * The method prepares and executes CleansePutRequest on ADDRESS landing
	 * table for the given Address profiles.
	 *
	 * @param addressList
	 *            List of Addresses provided to the web service request
	 * @param partyParam
	 *            Party profile provided to the web service request
	 * @param siperianClient
	 *            SiperianClient SIF connection to MDM Hub
	 * @return List of PutResponseDataHolder object containing processing
	 *         results
	 * @throws ServiceProcessingException
	 */
	private List<PutResponseDataHolder> cleansePutAddress(List<AddressXrefType> addressList, PartyXrefType partyParam,
			SiperianClient siperianClient) throws ServiceProcessingException {
		LOG.info("Executing cleansePutAddress()");

		CleansePutRequest cleansePutRequest = null;
		CleansePutResponse cleansePutResponse = null;
		List<PutResponseDataHolder> responseDataHolderList = new ArrayList<PutResponseDataHolder>(addressList.size());
		for (AddressXrefType addressParam : addressList) {
			try {
				cleansePutRequest = new CleansePutRequest();
				// prepare CleansePutRequest
				Record record = new Record();
				// set mapping name
				record.setSiperianObjectUid(
						Util.getMappingObjectUid(addressParam.getSRCSYSTEM(), MDMAttributeNames.ENTITY_ADDRESS));
				// set input values
				if (partyParam.getLASTUPDATEDATE() != null && partyParam.getLASTUPDATEDATE().length() > 0) {
					record.setField(new Field(MDMAttributeNames.LAST_UPDATE_DATE, partyParam.getLASTUPDATEDATE()));
				} else {
					LOG.info("Performing cleansePutAddress with sysdate from HUB: " + lastUpdateDate);
					record.setField(new Field(MDMAttributeNames.LAST_UPDATE_DATE, lastUpdateDate));
				}
				record.setField(new Field(MDMAttributeNames.SRC_UPDT_BY, addressParam.getUPDATEBY()));
				record.setField(new Field(MDMAttributeNames.SRC_SYSTEM, addressParam.getSRCSYSTEM()));
				if (Util.isNullOrEmpty(addressParam.getSRCPKEY())) {
					record.setField(new Field(MDMAttributeNames.SRC_SYS_KEY, partyParam.getXREF().get(0).getSRCPKEY()));
				} else {
					record.setField(new Field(MDMAttributeNames.SRC_SYS_KEY, addressParam.getSRCPKEY()));
				}
				record.setField(new Field(AddressAttributes.ADDR_LN1, addressParam.getADDRLN1()));
				record.setField(new Field(AddressAttributes.ADDR_LN2, addressParam.getADDRLN2()));
				record.setField(new Field(AddressAttributes.ADDR_LN3, addressParam.getADDRLN3()));
				record.setField(new Field(AddressAttributes.ADDR_LN4, addressParam.getADDRLN4()));
				record.setField(new Field(AddressAttributes.ADDR_STATUS, addressParam.getADDRSTATUS()));
				record.setField(new Field(AddressAttributes.ADDR_TYPE, Constant.ADDRESS_TYPE_MAILING));

				record.setField(new Field(AddressAttributes.CITY, addressParam.getCITY()));
				LOG.debug("addressParam.getCOUNTRYCD(): " + addressParam.getCOUNTRYCD());
				record.setField(new Field(AddressAttributes.COUNTRY_CD, addressParam.getCOUNTRYCD()));
				record.setField(new Field(AddressAttributes.COUNTY, addressParam.getCOUNTY()));
				record.setField(new Field(AddressAttributes.DISTRICT, addressParam.getDISTRICT()));
				record.setField(new Field(AddressAttributes.LANG_CD, addressParam.getLANGCD()));
				record.setField(new Field(AddressAttributes.LATITUDE, addressParam.getLATITUDE()));
				record.setField(new Field(AddressAttributes.LONGITUDE, addressParam.getLONGITUDE()));
				record.setField(new Field(AddressAttributes.POSTAL_CD, addressParam.getPOSTALCD()));
				LOG.debug("addressParam.getSTATECD(): " + addressParam.getSTATECD());
				record.setField(new Field(AddressAttributes.STATE_CD, addressParam.getSTATECD()));
				record.setField(new Field(AddressAttributes.ADDRESS_QUALITY_IDENTIFIER, addressParam.getADDRESSQUALITYIDENTIFIER()));
				// record.setField(new Field(AddressAttributes.ADDR_MKTG_PREF,
				// addressParam.getADDRMKTGPREF()));
				record.setField(
						new Field(MDMAttributeNames.PARTY_SRC_SYS_KEY, partyParam.getXREF().get(0).getSRCPKEY()));				

				cleansePutRequest.setRecord(record);
				// execute Put request
				cleansePutResponse = (CleansePutResponse) siperianClient.process(cleansePutRequest);
				LOG.info("Address cleansePut request processed successfully: " + cleansePutResponse.getMessage());
				// extract result
				RecordKey recordKey = cleansePutResponse.getRecordKey();

				PutResponseDataHolder responseDataHolder = new PutResponseDataHolder();
				responseDataHolder.setActionType(cleansePutResponse.getActionType());
				responseDataHolder.setActionMessage(cleansePutResponse.getMessage());
				responseDataHolder.setRowidObject(recordKey.getRowid());
				responseDataHolder.setRowidXREF(recordKey.getRowidXref());
				responseDataHolder.setSourceKey(recordKey.getSourceKey());
				responseDataHolder.setSystemName(recordKey.getSystemName());
				responseDataHolderList.add(responseDataHolder);
				LOG.info("ROWID_OBJECT of created Address record = " + recordKey.getRowid());
				LOG.debug("Action Type = " + responseDataHolder.getActionType());
				LOG.debug("Action Msg = " + responseDataHolder.getActionMessage());
			} catch (SiperianServerException sifExcp) {
				LOG.error("SiperianServerException occured while processing CleansePutRequest for Address: ", sifExcp);
				ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
				customException.setMessage("SIF exception occured while processing Put request for Address. "
						+ customException.getMessage());
				customException.setRootExceptionMsg(
						sifExcp + " CleansePut operation failed for Address " + addressParam.getSRCPKEY());
				throw customException;
			} catch (Exception excp) {
				LOG.error("Exception occured while processing CleansePutRequest for Address: ", excp);
				ServiceProcessingException customException = new ServiceProcessingException(excp);
				customException.setMessage(
						"Exception occured while processing Put request for Address. " + customException.getMessage());
				customException.setRootExceptionMsg(
						excp + " CleansePut operation failed for Address " + addressParam.getSRCPKEY());
				throw customException;
			}
		}

		LOG.info("Executed cleansePutAddress()");
		return responseDataHolderList;
	}

	/**
	 * The method prepares and executes CleansePutRequest on COMMUNICATION
	 * landing table for the given Communication profiles.
	 *
	 * @param commList
	 *            List of Communications provided to the web service request
	 * @param partyParam
	 *            Party profile provided to the web service request
	 * @param siperianClient
	 *            SiperianClient SIF connection to MDM Hub
	 * @return List of PutResponseDataHolder object containing processing
	 *         results
	 * @throws ServiceProcessingException
	 */
	private List<PutResponseDataHolder> cleansePutCommunication(List<CommunicationXrefType> commList,
			PartyXrefType partyParam, SiperianClient siperianClient) throws ServiceProcessingException {
		LOG.info("Executing cleansePutCommunication()");
		CleansePutRequest cleansePutRequest = null;
		CleansePutResponse cleansePutResponse = null;
		List<PutResponseDataHolder> responseDataHolderList = new ArrayList<PutResponseDataHolder>(commList.size());
		for (CommunicationXrefType commParam : commList) {
			try {
				cleansePutRequest = new CleansePutRequest();
				// prepare CleansePutRequest
				Record record = new Record();
				// set mapping name
				record.setSiperianObjectUid(
						Util.getMappingObjectUid(commParam.getSRCSYSTEM(), MDMAttributeNames.ENTITY_COMM));
				// set input values
				if (partyParam.getLASTUPDATEDATE() != null && partyParam.getLASTUPDATEDATE().length() > 0) {
					record.setField(new Field(MDMAttributeNames.LAST_UPDATE_DATE, partyParam.getLASTUPDATEDATE()));
				} else {
					LOG.info("Performing cleansePutCommunication with sysdate from HUB: " + lastUpdateDate);
					record.setField(new Field(MDMAttributeNames.LAST_UPDATE_DATE, lastUpdateDate));
				}
				record.setField(new Field(MDMAttributeNames.SRC_UPDT_BY, commParam.getUPDATEBY()));
				record.setField(new Field(MDMAttributeNames.SRC_SYSTEM, commParam.getSRCSYSTEM()));
				record.setField(new Field(MDMAttributeNames.SRC_SYS_KEY, commParam.getSRCPKEY()));

				record.setField(new Field(CommunicationAttributes.COMM_STATUS, commParam.getCOMMSTATUS()));

				if (commParam.getCOMMTYPE() != null && commParam.getCOMMTYPE().length() > 0) {
					record.setField(new Field(CommunicationAttributes.COMM_TYPE, commParam.getCOMMTYPE()));
				}
				record.setField(new Field(CommunicationAttributes.COMM_VALUE, commParam.getCOMMVALUE()));
				LOG.debug("commParam.getCOMMVALUE() is: " + commParam.getCOMMVALUE());
				record.setField(new Field(CommunicationAttributes.PRFRD_COMM_IND, commParam.getPRFRDCOMMIND()));
				record.setField(new Field(CommunicationAttributes.WEB_DOMAIN, commParam.getWEBDOMAIN()));
				// record.setField(new
				// Field(CommunicationAttributes.COMM_MKTG_PREF,
				// commParam.getCOMMMKTGPREF()));

				record.setField(new Field(CommunicationAttributes.COMM_EXTN, commParam.getCOMMEXTN()));
				record.setField(
						new Field(MDMAttributeNames.PARTY_SRC_SYS_KEY, partyParam.getXREF().get(0).getSRCPKEY()));

				cleansePutRequest.setRecord(record);
				// execute Put request
				cleansePutResponse = (CleansePutResponse) siperianClient.process(cleansePutRequest);
				LOG.info("Communication cleansePut request processed successfully: " + cleansePutResponse.getMessage());
				// extract result
				RecordKey recordKey = cleansePutResponse.getRecordKey();

				PutResponseDataHolder responseDataHolder = new PutResponseDataHolder();
				responseDataHolder.setActionType(cleansePutResponse.getActionType());
				responseDataHolder.setActionMessage(cleansePutResponse.getMessage());
				responseDataHolder.setRowidObject(recordKey.getRowid());
				responseDataHolder.setRowidXREF(recordKey.getRowidXref());
				responseDataHolder.setSourceKey(recordKey.getSourceKey());
				responseDataHolder.setSystemName(recordKey.getSystemName());
				responseDataHolderList.add(responseDataHolder);
				LOG.info("ROWID_OBJECT of created Communication record = " + recordKey.getRowid());
				LOG.debug("Action Type = " + responseDataHolder.getActionType());
				LOG.debug("Action Msg = " + responseDataHolder.getActionMessage());
			} catch (SiperianServerException sifExcp) {
				LOG.error("SiperianServerException occured while processing CleansePutRequest for Communication: "
						+ sifExcp);
				LOG.error("sifExcp msg " + sifExcp);
				ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
				customException.setMessage("SIF exception occured while processing Put request for Communication. "
						+ customException.getMessage());
				customException.setRootExceptionMsg(
						sifExcp + " CleansePut operation failed for Communication " + commParam.getSRCPKEY());
				sifExcp.printStackTrace();
				throw customException;
			} catch (Exception excp) {
				LOG.error("Exception occured while processing CleansePutRequest for Communication: " + excp);
				excp.printStackTrace();
				ServiceProcessingException customException = new ServiceProcessingException(excp);
				customException.setMessage("Exception occured while processing Put request for Communication. "
						+ customException.getMessage());
				customException.setRootExceptionMsg(
						excp + " CleansePut operation failed for Communication " + commParam.getSRCPKEY());
				excp.printStackTrace();
				throw customException;
			}
		}

		LOG.info("Executed cleansePutCommunication()");
		return responseDataHolderList;
	}

	/**
	 * The method prepares and executes CleansePutRequest on COMMUNICATION
	 * landing table for the given Communication profiles.
	 *
	 * @param commList
	 *            List of Communications provided to the web service request
	 * @param partyParam
	 *            Party profile provided to the web service request
	 * @param siperianClient
	 *            SiperianClient SIF connection to MDM Hub
	 * @return List of PutResponseDataHolder object containing processing
	 *         results
	 * @throws ServiceProcessingException
	 */
	private List<PutResponseDataHolder> cleansePutPerson(List<PartyPersonXrefType> personList, PartyXrefType partyParam,
			SiperianClient siperianClient) throws ServiceProcessingException {
		LOG.info("Executing cleansePutPerson()");
		CleansePutRequest cleansePutRequest = null;
		CleansePutResponse cleansePutResponse = null;
		List<PutResponseDataHolder> responseDataHolderList = new ArrayList<PutResponseDataHolder>(personList.size());
		for (PartyPersonXrefType personParam : personList) {
			try {
				cleansePutRequest = new CleansePutRequest();
				// prepare CleansePutRequest
				Record record = new Record();
				// set mapping name
				record.setSiperianObjectUid(
						Util.getMappingObjectUid(personParam.getSRCSYSTEM(), MDMAttributeNames.ENTITY_PARTY_PRSN));
				// set input values
				if (partyParam.getLASTUPDATEDATE() != null && partyParam.getLASTUPDATEDATE().length() > 0) {
					record.setField(new Field(MDMAttributeNames.LAST_UPDATE_DATE, partyParam.getLASTUPDATEDATE()));
				} else {
					LOG.info("Performing cleansePutPerson with sysdate from HUB: " + lastUpdateDate);
					record.setField(new Field(MDMAttributeNames.LAST_UPDATE_DATE, lastUpdateDate));
				}
				record.setField(new Field(PartyPersonAttributes.SRC_UPD_BY, personParam.getUPDATEBY()));
				record.setField(new Field(MDMAttributeNames.SRC_SYSTEM, personParam.getSRCSYSTEM()));
				record.setField(new Field(MDMAttributeNames.SRC_SYS_KEY, personParam.getSRCPKEY()));

				record.setField(new Field(PartyPersonAttributes.PREFIX, personParam.getPREFIX()));

				record.setField(new Field(PartyPersonAttributes.FIRST_NAME, personParam.getFIRSTNAME()));
				record.setField(new Field(PartyPersonAttributes.MIDDLE_NAME, personParam.getMIDDLENAME()));
				record.setField(new Field(PartyPersonAttributes.LAST_NAME, personParam.getLASTNAME()));
				record.setField(new Field(PartyPersonAttributes.SUFFIX, personParam.getSUFFIX()));
				record.setField(new Field(PartyPersonAttributes.JOB_TITLE, personParam.getJOBTITLE()));
				record.setField(new Field(PartyPersonAttributes.JOB_FUNCTION, personParam.getJOBFUNCTION()));
				record.setField(new Field(PartyPersonAttributes.PERSON_STATUS, personParam.getPERSONSTATUS()));
				// record.setField(new Field(
				// PartyPersonAttributes.SAP_INTEGRATION_ID, personParam));
				record.setField(new Field(PartyPersonAttributes.PERSON_TYPE, personParam.getPERSONTYPE()));
				record.setField(new Field(PartyPersonAttributes.PREF_LANGUAGE, personParam.getPREFLANGUAGE()));
				record.setField(new Field(PartyPersonAttributes.LIST_SOURCE, personParam.getLISTSOURCE()));
				record.setField(new Field(PartyPersonAttributes.DATA_SRC_SYS, personParam.getDATASOURCESYSTEM()));
				record.setField(new Field(PartyPersonAttributes.LATTICE_SCORE, personParam.getLATTICESCORE()));
				record.setField(new Field(PartyPersonAttributes.REPTD_COMP_NAME, personParam.getREPORTEDCOMPANYNAME()));
				record.setField(new Field(PartyPersonAttributes.JOB_LEVEL, personParam.getJOBLEVEL()));
				record.setField(
						new Field(MDMAttributeNames.PARTY_SRC_SYS_KEY, partyParam.getXREF().get(0).getSRCPKEY()));

				cleansePutRequest.setRecord(record);
				// execute Put request
				cleansePutResponse = (CleansePutResponse) siperianClient.process(cleansePutRequest);
				LOG.info("Party_Person cleansePut request processed successfully: " + cleansePutResponse.getMessage());
				// extract result
				RecordKey recordKey = cleansePutResponse.getRecordKey();

				PutResponseDataHolder responseDataHolder = new PutResponseDataHolder();
				responseDataHolder.setActionType(cleansePutResponse.getActionType());
				responseDataHolder.setActionMessage(cleansePutResponse.getMessage());
				responseDataHolder.setRowidObject(recordKey.getRowid());
				responseDataHolder.setRowidXREF(recordKey.getRowidXref());
				responseDataHolder.setSourceKey(recordKey.getSourceKey());
				responseDataHolder.setSystemName(recordKey.getSystemName());
				responseDataHolderList.add(responseDataHolder);
				LOG.info("ROWID_OBJECT of created Party_Person record = " + recordKey.getRowid());
				LOG.debug("Action Type = " + responseDataHolder.getActionType());
				LOG.debug("Action Msg = " + responseDataHolder.getActionMessage());
			} catch (SiperianServerException sifExcp) {
				LOG.error("SiperianServerException occured while processing CleansePutRequest for Party_Person: "
						+ sifExcp);
				LOG.error("sifExcp msg " + sifExcp);
				ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
				customException.setMessage("SIF exception occured while processing Put request for Party_Person. "
						+ customException.getMessage());
				customException.setRootExceptionMsg(
						sifExcp + " CleansePut operation failed for Party_Person " + personParam.getSRCPKEY());
				sifExcp.printStackTrace();
				throw customException;
			} catch (Exception excp) {
				LOG.error("Exception occured while processing CleansePutRequest for Party_Person: " + excp);
				excp.printStackTrace();
				ServiceProcessingException customException = new ServiceProcessingException(excp);
				customException.setMessage("Exception occured while processing Put request for Party_Person. "
						+ customException.getMessage());
				customException.setRootExceptionMsg(
						excp + " CleansePut operation failed for Party_Person " + personParam.getSRCPKEY());
				excp.printStackTrace();
				throw customException;
			}
		}

		LOG.info("Executed cleansePutPerson()");
		return responseDataHolderList;
	}

	// generate match token for the party record
	private void processTokenizeRequest(PutResponseDataHolder putRespDataParty) throws ServiceProcessingException {

		LOG.debug("Executing processTokenizeRequest()");
		SiperianClient siperianClient = null;

		try {
			siperianClient = (SiperianClient) checkOut();

			TokenizeRequest tokenizeRequest = new TokenizeRequest();
			tokenizeRequest.setSiperianObjectUid(SiperianObjectType.BASE_OBJECT.makeUid("C_B_PARTY"));
			RecordKey recordKey = new RecordKey();
			recordKey.setRowid(putRespDataParty.getRowidObject());

			tokenizeRequest.setRecordKey(recordKey);
			tokenizeRequest.setActionType(putRespDataParty.getActionType());

			TokenizeResponse tokenizeResponse = (TokenizeResponse) siperianClient.process(tokenizeRequest);
			LOG.info("Match Token generated for ContactID: " + putRespDataParty.getRowidObject() + " Token msg: "
					+ tokenizeResponse.getMessage());

			LOG.debug("Executed processTokenizeRequest()");
		} catch (Exception excp) {
			LOG.error("Caught exception within processTokenizeRequest() " + excp.getMessage());
			ServiceProcessingException customExcp = new ServiceProcessingException(excp);
			throw customExcp;
		} finally {
			checkIn(siperianClient);
		}
	}

	// Contact Match & Merge process
	public HashMap<Integer, HighestScoreRecordHolder> mergeProcessContact(Map<String, Object> putRespDataHolderMap,
			HashMap<Integer, HighestScoreRecordHolder> mergeSorceHolderMap, UpsertPartyResponse upsertPartyResponse,
			HighestScoreRecordHolder highestScoreRecordHoldertgt, PartyXrefType insertedPartyData)
			throws ServiceProcessingException {
		// execute Match and Merge on newly created records only; for update,
		// match & merge not required
		// for Party Match will be based on Party_name, party_type, UCN etc,
		// whereas, for other BO, match will be based on rowid_party
		LOG.info("Executing mergeProcessContact() method.");
		PutResponseDataHolder putRespDataParty = (PutResponseDataHolder) putRespDataHolderMap
				.get(MDMAttributeNames.ENTITY_PARTY);
		List<PutResponseDataHolder> putRespDataPersonList = (List<PutResponseDataHolder>) putRespDataHolderMap
				.get(MDMAttributeNames.ENTITY_PARTY_PRSN);
		String survivorRowidObject = null;
		UserTransaction transaction = null;
		SiperianClient siperianClient = null;
		String targetRowid = null;

		boolean isMergedWithSBLContact = Boolean.FALSE;
		List<String> acctRowidCountryCdList = new ArrayList<String>();
		// execute Match and Merge SIF operation
		
		/**GTM:Sprint#1- US335 */
		int countOfRetry = Integer.parseInt(configProps.getProperty("NoOfRetries"));
		boolean isMergeRetrySuccess = false;
		List<String> rowidList = new ArrayList<String>();
		
		
		try {

			siperianClient = checkOut();
			transaction = ((EjbSiperianClient) siperianClient).createTX(300000);
			transaction.begin();

			try {
				mergeSorceHolderMap = processMatchAndMergeContact(putRespDataParty.getRowidObject(),
						(PartyXrefType) insertedPartyData, siperianClient);
				LOG.debug(" Control returned after processMatchAndMergeContact()");
			} catch (Exception excp) {
				LOG.error("Caught exception within mergeProcessParty: ", excp);
				throw excp;
			}

			if (mergeInd && mergeSorceHolderMap != null && mergeSorceHolderMap.size() > 0) {
				// Merge SIF operation for Child Tables
				for (Iterator<PutResponseDataHolder> iter = putRespDataPersonList.iterator(); iter.hasNext();) {
					if ("Insert".equalsIgnoreCase(((PutResponseDataHolder) iter.next()).getActionType())
							&& highestScoreRecordHoldertgt != null) {
						// processMatchAndMergeChildEntity(MDMAttributeNames.ENTITY_ACCOUNT,
						// putRespDataParty, (PartyXrefType) insertedPartyData,
						// upsertPartyResponse,
						// mergeSorceHolderMap, highestScoreRecordHoldertgt,
						// siperianClient);
						// existing record will survive
						for (HighestScoreRecordHolder hsrh : mergeSorceHolderMap.values()) {
							targetRowid = hsrh.getRowidPerson();
						}
						// newly created record will merge to existing record
						String sourceRowid = upsertPartyResponse.getParty().get(0).getPartyPerson().get(0)
								.getROWIDPERSON();

						LOG.debug("PersonSorce Key: " + sourceRowid + " | PersonTarget Key: " + targetRowid);

						String siperianObjectUid = "BASE_OBJECT.C_B_PARTY_PERSON";
						try {
						//	throw new ServiceProcessingException("Throwing manual exception in C_B_PARTY_PERSON Merge !! ");
							mergeProcessChild(siperianObjectUid, sourceRowid, targetRowid, siperianClient);
							LOG.debug("ELQ Person Merge is successful !!");
						}	catch (Exception sifExcp) {
							//mergeInd = false;
							LOG.error("Exception occured while processing Merge operation on C_B_PARTY_PERSON: " , sifExcp);
							for(int i = 0; i<countOfRetry; i++)	{
							try{
								LOG.debug("Retrying C_B_PARTY_PERSON Merge process for "+ (i+1) +"th time");
								rowidList.add(sourceRowid);
								rowidList.add(targetRowid);
								updateCI(rowidList, "C_B_PARTY_PERSON");
								mergeProcessChild(siperianObjectUid, sourceRowid, targetRowid, siperianClient);
								LOG.debug("Person Merge is successful on attempt no. "+ (i+1));
								isMergeRetrySuccess = true;
								//mergeInd = true;
								break;
							} catch (Exception ex) {
								LOG.error("Exception occured in C_B_PARTY_PERSON Merge RetryMechanism on attempt no. "+ (i+1));
								LOG.error("Exception occured in Merge RetryMechanism on C_B_PARTY_PERSON");
							}
							}
							if(!isMergeRetrySuccess){
								ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
								customException.setMessage("SIF exception occured while processing Merge request on C_B_PARTY_PERSON: " + customException.getMessage());
								throw customException;
							}
						}//end try/catch
					}//end If Insert
				}//for loop

			}
			transaction.commit();

			// if newly created record got merged, set rowid_object of it to
			// that
			// of surviving target record
			if (mergeInd) {
				// String survivorRowidObject = null;
				for (HighestScoreRecordHolder hsrh : mergeSorceHolderMap.values()) {
					survivorRowidObject = hsrh.getPartyRowIDObject();
				}
				LOG.info(
						"Setting rowid_object of new record to that of surviving target record " + survivorRowidObject);
				upsertPartyResponse.getParty().get(partyCount - 1).setROWIDOBJECT(survivorRowidObject.trim());
			
				/**SWAT EPBI: Remove MDM_FLAG -7 logic**/
			/*	 US55- Sprint# 5 Code Change 
				isMergedWithSBLContact = prospectPartyDAO.isMergedWithSBLContact(survivorRowidObject.trim());
				
				if(isMergedWithSBLContact){
					String contactCountryCd = insertedPartyData.getAddress().get(0).getCOUNTRYCD();
					 Fetch Existing ACCOUNT_ROWID & COUNTRY_CD 
					acctRowidCountryCdList = prospectPartyDAO.getExistingSBLAccountCountryCd(insertedPartyData.getXREF().get(0).getSRCPKEY());
					if(!acctRowidCountryCdList.isEmpty()){
						LOG.debug("acctRowidCountryCdList is Not Empty !!");
						for(String acctRowidCountry: acctRowidCountryCdList){
							String temp[] = acctRowidCountry.split("\\|");
							String acctRowid = temp[0]; 
							String acctCountryCd = temp[1];
							if(!acctCountryCd.equalsIgnoreCase(contactCountryCd)){
								LOG.debug("New ELQ Contact CountryCd: "+contactCountryCd+" is not matching with SBL Account CountryCd: "+acctCountryCd
										+ " having SBL Account Rowid: "+acctRowid);
								createContactUpsertInfoMessage(upsertPartyResponse, Constant.INFO_CONTACT_COUNTRY_DIFF_ACCT_COUNTRY_CREATE, 
										insertedPartyData.getXREF().get(0).getSRCPKEY());
								break;
							}
						}//end for-loop
					}else{
						LOG.debug("No Associated SBL-Account/SBL-Account-CountryCd is Found for Contact: "+insertedPartyData.getXREF().get(0).getSRCPKEY());
					}
				}*/
				
				
			}
		} catch (ServiceProcessingException excp) {
			LOG.error("Caught exception in processMatchAndMergeContact operation.", excp);
	//		upsertPartyResponse.setErrorMsg(
	//				"processMatchAndMergeContact operation failed for PartyID: " + putRespDataParty.getSourceKey());

			try {
				transaction.rollback();

			} catch (SystemException txExcp) {
				LOG.error("Failed to rollback transaction for processMatchAndMergeContact operation : "
						+ txExcp.toString());
			}
			throw excp;
		} catch (Exception ex) {
			LOG.error("Exception occured while processMatchAndMergeContact operation requests: ", ex);
			try {
				transaction.rollback();
			} catch (SystemException txExcp) {
				LOG.error("Failed to rollback transaction for processMatchAndMergeContact operation: "
						+ txExcp.toString());
				// txExcp.printStackTrace();
			}
			ServiceProcessingException customException = new ServiceProcessingException(ex);
			customException.setMessage(
					"Failed to process processMatchAndMergeContact operation. " + customException.getMessage());
			// customException.printStackTrace();
			throw customException;
		} finally {
			checkIn(siperianClient);
		}

		try {

			// Perform Tokenization after Match & Merge
			PutResponseDataHolder putTokenizeDataParty = new PutResponseDataHolder();
			String survivorRowid = null;
			if (mergeInd) {
				for (HighestScoreRecordHolder hsrh : mergeSorceHolderMap.values()) {
					survivorRowid = hsrh.getPartyRowIDObject();
				}

				if (!Util.isNullOrEmpty(survivorRowid)) {
					putTokenizeDataParty.setRowidObject(survivorRowid);
					putTokenizeDataParty.setActionType("Merge");

					processTokenizeRequest(putTokenizeDataParty);
				}
			}
		} catch (SiperianServerException sifExcp) {
			LOG.error("SiperianServerException occured while processing TokenizeRequest for Contact after MatchMerge.",
					sifExcp);
			// ServiceProcessingException customException = new
			// ServiceProcessingException(sifExcp);
			// customException.setMessage("SIF exception occured while
			// processing Tokenize request for Party after MatchMerge. "
			// + customException.getMessage());

		} catch (Exception excp) {
			LOG.error("Exception occured while processing TokenizeRequest for Contact after MatchMerge.", excp);
			ServiceProcessingException customException = new ServiceProcessingException(excp);
			customException
					.setMessage("Exception occured while processing Tokenize request for Contact after MatchMerge. "
							+ customException.getMessage());
		}

		LOG.info("Executed mergeProcessContact() method.");
		return mergeSorceHolderMap;
	}

	private void mergeProcessChild(String siperianObjectUid, String sourceRowid, String targetRowid,
			SiperianClient siperianClient) throws ServiceProcessingException {

		LOG.info("Executing mergeProcessChild()");
		// SiperianClient siperianClient = null;

		try {

			// siperianClient = (SiperianClient) checkOut();

			if (sourceRowid != null && sourceRowid.length() > 0 && targetRowid != null && targetRowid.length() > 0) {
				MergeRequest request = new MergeRequest();
				MergeResponse response = null;
				request.setSiperianObjectUid(siperianObjectUid);
				// newly created record will merged into existing one
				request.setSourceRecordKey(RecordKey.rowid(sourceRowid));
				// existing rec will survive
				request.setTargetRecordKey(RecordKey.rowid(targetRowid));
				// LOG.info("Child Target Key: "+ request.getTargetRecordKey());
				LOG.info(" Before executing Party_Person Merge process ");
				LOG.info("siperianObjectUid: " + siperianObjectUid + ", ChildSourceRowid: " + sourceRowid
						+ ", ChildTargetRowid: " + targetRowid);
				response = (MergeResponse) siperianClient.process(request);
				mergeInd = true;
				LOG.debug(" After executing Party_Person Merge process ");
				String msg = response.getMessage();
				LOG.debug(" Message from MergeResponse :" + msg);
			} else {
				LOG.info("Either SourceRowID or TargetRowID is null");
			}
		} catch (SiperianServerException sifExcp) {
			mergeInd = false;
			LOG.error("SiperianServerException occured while processing Party_Person operation: ", sifExcp);
			// sifExcp.printStackTrace();
			ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
			customException.setMessage("SIF exception occured while processing Party_Person request for Child. "
					+ customException.getMessage());
			throw customException;
		} catch (Exception ex) {
			mergeInd = false;
			LOG.error("Party_Person Merge operation failed with exception: ", ex);
			// ex.printStackTrace();
			ServiceProcessingException customException = new ServiceProcessingException(ex);
			customException
					.setMessage("Failed to process Merge request for Party_Person. " + customException.getMessage());
			throw customException;
		} finally {
			// checkIn(siperianClient);
		}
		LOG.info("Executed mergeProcessChild()");
	}

	/* Perform Match & Merge operation for each Contact Record */
	// HashMap<Integer, HighestScoreRecordHolder>
	public HashMap<Integer, HighestScoreRecordHolder> processMatchAndMergeContact(String newPartyRowid,
			PartyXrefType partyTypeParam, SiperianClient siperianClient) throws ServiceProcessingException {

		LOG.info("Executing processMatchAndMergeContact()");
		String contactRuleSetName = configProps.getProperty("contactRuleSetName");// Party Person Fuzzy Rule Set New
																					
		// String sorceRowidObject = null;

		// SiperianClient siperianClient = null;
		HighestScoreRecordHolder highestScoreRecordHolder = null;
		/**GTM Sprint#1 US335*/
		int matchCountOfRetry = Integer.parseInt(configProps.getProperty("NoOfRetries"));
		boolean isMatchRetrySuccess = false;
		List searchRecords = new ArrayList();

		HashMap<Integer, HighestScoreRecordHolder> highestScoreRecordHolderMap = new HashMap<Integer, HighestScoreRecordHolder>();
		SearchMatchRequest searchMatchRequest = new SearchMatchRequest();
		SearchMatchResponse searchMatchResponse = null;
		List<Object> tempkeyList = new ArrayList<Object>();

		HighestScoreRecordHolder finalMatchedRecord = new HighestScoreRecordHolder();

		try {

			try {

				/*searchMatchRequest.setRecordsToReturn(100); // Required
				// searchMatchRequest.setSiperianObjectUid("PKG_PARTY_JMS_MQ_PUB");//
				// Required
				searchMatchRequest.setSiperianObjectUid("PKG_BO_PERSON_SEARCH");// Required//PKG_BO_PERSON_SEARCH
				// searchMatchRequest.setMatchRuleSetUid(SiperianObjectType.MATCH_RULE_SET.makeUid("Org_addr_fuzzy_RealTime"));//

				searchMatchRequest.setMatchRuleSetUid(
						SiperianObjectType.MATCH_RULE_SET.makeUid("Party Person Fuzzy Rule Set New"));// Party
																										// Person
																										// Fuzzy
																										// Rule
																										// Set
																										// New

				searchMatchRequest.setMatchType(MatchType.BOTH);

				LOG.info("Match Rule Set: " + searchMatchRequest.getMatchRuleSetUid());
				LOG.info("Match Type :" + searchMatchRequest.getMatchType());

				Field org_name = new Field("Organization_Name");
				if (!Util.isNullOrEmpty(partyTypeParam.getPARTYNAME())) {
					org_name.setStringValue(partyTypeParam.getPARTYNAME());
					LOG.info("Field to search for :" + org_name.getName() + ':' + org_name.getStringValue());
					searchMatchRequest.addMatchColumnField(org_name);
				}

				Field field_name = new Field("Person_Name");
				if (!Util.isNullOrEmpty(partyTypeParam.getPARTYNAME())) {
					field_name.setStringValue(partyTypeParam.getPARTYNAME());
					LOG.info("Field to search for :" + field_name.getName() + ':' + field_name.getStringValue());
					searchMatchRequest.addMatchColumnField(field_name);
				}

				// Setting Ex_Comm_Typ_Type
				Field field_Eml_Type = new Field("Ex_Comm_Type_Email");
				field_Eml_Type.setStringValue("Email");
				searchMatchRequest.addMatchColumnField(field_Eml_Type);

				LOG.info("Field to search for :" + field_Eml_Type.getName() + ':' + field_Eml_Type.getStringValue());

				// Setting Ex_Comm_Val_Eml
				Field field_Eml_Val = new Field("Ex_Comm_Val_Email");
				StringBuilder contEmlVal = new StringBuilder();
				if (!Util.isNullOrEmpty(commEmlVal)) {
					// contEmlVal.append("taylord@schaeferadvertising.com");//commEmlVal
					contEmlVal.append(commEmlVal);
					field_Eml_Val.setStringValue(contEmlVal.toString());

					searchMatchRequest.addMatchColumnField(field_Eml_Val);
				}

				LOG.info("Field to search for :" + field_Eml_Val.getName() + ':' + field_Eml_Val.getStringValue());

				// Setting field_Entity_Type
				Field field_Entity_Type = new Field("Ex_Entity_Type");
				field_Entity_Type.setStringValue("Person");
				searchMatchRequest.addMatchColumnField(field_Entity_Type);

				LOG.info("Field to search for :" + field_Entity_Type.getName() + ':'
						+ field_Entity_Type.getStringValue());

				// Adding SIP_POP
				Field field_SIPPOP = new Field("SIP_POP");
				field_SIPPOP.setStringValue(sipPopVal);// sipPopVal
				searchMatchRequest.addMatchColumnField(field_SIPPOP);
				LOG.info("Field to match for :" + field_SIPPOP.getName() + ':' + field_SIPPOP.getStringValue());

				StringBuffer criteria = new StringBuffer();
				boolean firstParam = true;

				
				 * if (firstParam) { criteria.append(" HUB_STATE_IND = '" + 1 +
				 * "'"); firstParam = false; } else { criteria.append(
				 * " AND HUB_STATE_IND = '" + 1 + "'"); }
				 

				LOG.info("Filter Criteria: " + criteria.toString());

				searchMatchRequest.setFilterCriteria(criteria.toString());

				LOG.info("processing SearchMatchRequest");
				searchMatchResponse = (SearchMatchResponse) siperianClient.process(searchMatchRequest);

				List searchRecords = searchMatchResponse.getRecords();*/
				
				try {
					searchRecords = matchELQContact(partyTypeParam, siperianClient);
		//			throw new ServiceProcessingException("SearchMatchRequest on ELQ_Contact threw Exception !!");
					LOG.debug("ELQ_Contact SearchMatch is successful !!");
					
				} catch (Exception sifExcp) {
					matchInd = false;
					LOG.error("Exception occured while processing SearchMatchRequest on ELQ_Contact: " , sifExcp);
					for(int i = 0; i<matchCountOfRetry; i++)	{
						try{
							LOG.debug("Retrying SearchMatchRequest ELQ_Contact process for "+ (i+1) +"th time");
							searchRecords = matchELQContact(partyTypeParam, siperianClient);
							LOG.debug("SearchMatchRequest on ELQ_Contact is successful on attempt no. "+ (i+1));
							isMatchRetrySuccess = true;
							matchInd = true;
							break;
						} catch (Exception ex) {
							LOG.error("Exception occured in SearchMatchRequest[ELQ_Contact] RetryMechanism on attempt no. "+ (i+1));
							LOG.error("Exception occured in SearchMatchRequest[ELQ_Contact] RetryMechanism on PARTY_BO");
						}
					}
					if(!isMatchRetrySuccess){
						ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
						customException.setMessage("Exception occured in SearchMatchRequest[ELQ_Contact]"
								+ " RetryMechanism on PARTY_BO: " + customException.getMessage());
						throw customException;
					}
				} 
				
				// Store Match Score
				HashMap<Integer, Integer> matchScoreMap = new HashMap<Integer, Integer>();
				List<Integer> resultMatchScoreList = null;
				List<Integer> rowidList = null;

				if (searchRecords != null && searchRecords.size() > 0) {
					for (Iterator iter = searchRecords.iterator(); iter.hasNext();) {
						Record record = (Record) iter.next();
						highestScoreRecordHolder = null;
						String recRowid = record.getField("ROWID_OBJECT").getStringValue().trim();
						// Excluding self-matching record
						if (!recRowid.equals(newPartyRowid)) {
							int rowidKey = Integer.parseInt(recRowid);

							if (!highestScoreRecordHolderMap.containsKey(rowidKey)) {

								LOG.debug("Populate highestScoreRecordHolderMap for matched PARTY_ROWID " + recRowid);
								highestScoreRecordHolderMap.put(rowidKey, new HighestScoreRecordHolder());
							}

							highestScoreRecordHolder = highestScoreRecordHolderMap.get(rowidKey);

							if (record.getField("ROWID_OBJECT").getStringValue() != null) {
								highestScoreRecordHolder
										.setPartyRowIDObject(record.getField("ROWID_OBJECT").getStringValue().trim());
							}
							if (record.getField("PERSON_ROWID_OBJECT").getStringValue() != null) {
								highestScoreRecordHolder
										.setRowidPerson(record.getField("PERSON_ROWID_OBJECT").getStringValue().trim());
							}
							if (record.getField("ROWID_COMMUNICATION").getStringValue() != null) {
								// highestScoreRecordHolder.setRowidCommunication(record.getField("ROWID_COMMUNICATION").getStringValue().trim());
								// comm = new CommunicationType();
								// comm.setCOMMTYPE(record.getField("COMM_TYPE").getStringValue());
								highestScoreRecordHolder.getCommMap().put(
										record.getField("ROWID_COMMUNICATION").getStringValue().trim(),
										record.getField("COMM_TYPE").getStringValue());
							}
							if (record.getField("ROWID_ADDRESS").getStringValue() != null) {
								highestScoreRecordHolder.getAddrMap().put(
										record.getField("ROWID_ADDRESS").getStringValue().trim(),
										record.getField("ADDR_TYPE").getStringValue());
								// highestScoreRecordHolder.setRowidAddress(record.getField("ROWID_ADDRESS").getStringValue().trim());
							}
							// Populate Match Score Map
							String mtchScore = record.getField("MATCH_SCORE").getValue().toString().trim();
							int mtchValue = Integer.parseInt(mtchScore);
							LOG.info("MatchScoreMap rowid_object :" + rowidKey + " scoreValue :" + mtchValue);
							matchScoreMap.put(rowidKey, mtchValue);

							// highestScoreRecordHolderMap.put(rowidKey,highestScoreRecordHolder);
						} else {
							LOG.debug("Self Matching record found with rowidOb: " + recRowid);
						}
					}
					// }
					// Variables for tie-breaker
					int highestScore = 0;
					int olderRowid = 0;
					// HighestScoreRecordHolder finalMatchedRecord = null;

					if (matchScoreMap != null && matchScoreMap.size() > 0) {
						if (matchScoreMap.size() > 1) {
							highestScore = highestMatchScore(matchScoreMap);

							int matchScoreThreshold = Integer.parseInt(configProps.getProperty("matchScore-Threshold"));

							if (matchScoreThreshold > highestScore) {
								LOG.info(" Highest Match Score of MatchedRecords is smaller than ThresholdValue");
								return null;
								// return false;
							} else {
								matchInd = true;

								// Method invocation for fetching Records/Rowids
								// with
								// Highest Match Score
								if (matchScoreMap != null && matchScoreMap.size() > 0) {
									resultMatchScoreList = maxMatchScore(matchScoreMap);
								}
								// If Multiple Records/Rowids have Highest Match
								// Score
								if ((resultMatchScoreList != null && resultMatchScoreList.size() > 0)
										&& (highestScoreRecordHolderMap.size() > 1)) {

									// Removing Lower MatchScore Records
									for (Entry<Integer, HighestScoreRecordHolder> entry : highestScoreRecordHolderMap
											.entrySet()) {
										if (!resultMatchScoreList.contains(entry.getKey())) {
											LOG.info("Removing Record with RowID: " + entry.getKey());
											tempkeyList.add(entry.getKey());
										}
									}
									for (Object obj : tempkeyList) {
										highestScoreRecordHolderMap.remove(obj);
									}
									tempkeyList.clear();

									// If Multiple Records in HolderMap after
									// Removing Lower MatchScores
									if (highestScoreRecordHolderMap.size() > 1) {
										// Collection<Integer> rowidSet =
										// highestScoreRecordHolderMap.keySet();
										olderRowid = Collections.min(highestScoreRecordHolderMap.keySet());

										LOG.debug("Oldest RowidObject value is: " + olderRowid);

										// Removing Higher RowidObject Records
										for (Entry<Integer, HighestScoreRecordHolder> entry : highestScoreRecordHolderMap
												.entrySet()) {
											if (olderRowid != entry.getKey()) {
												LOG.info("Removing Record with RowID: " + entry.getKey());
												tempkeyList.add(entry.getKey());
											}
										}
										for (Object obj : tempkeyList) {
											highestScoreRecordHolderMap.remove(obj);
										}
										tempkeyList.clear();

										finalMatchedRecord = highestScoreRecordHolderMap.get(olderRowid);
										LOG.debug("finalMatchedRecord is: " + finalMatchedRecord.getPartyRowIDObject());
									} else {
										// highestScoreRecordHolderMap contains
										// only 1 Matching Record
										LOG.debug("highestScoreRecordHolderMap contains only 1 Matching Record -->"
												+ highestScoreRecordHolderMap.keySet());
										for (Map.Entry<Integer, HighestScoreRecordHolder> recMapEntry : highestScoreRecordHolderMap
												.entrySet()) {
											finalMatchedRecord = recMapEntry.getValue();
											LOG.debug("finalMatchedRecord value is: " + finalMatchedRecord);
										}
									}
								} else {
									// highestScoreRecordHolderMap contains only
									// 1 Matching Record
									LOG.debug("highestScoreRecordHolderMap contains only 1 Matching Record -->"
											+ highestScoreRecordHolderMap.keySet());
									for (Map.Entry<Integer, HighestScoreRecordHolder> recMapEntry : highestScoreRecordHolderMap
											.entrySet()) {
										finalMatchedRecord = recMapEntry.getValue();
										LOG.debug("finalMatchedRecord value is: " + finalMatchedRecord);
									}
								}
							}

							LOG.info("Final Map Size: " + highestScoreRecordHolderMap.size());
							LOG.info("Target RecordKey is found: " + finalMatchedRecord);
						} else {

							// Entry<Integer, HighestScoreRecordHolder>
							// recMapEntry = (Entry<Integer,
							// HighestScoreRecordHolder>)
							// highestScoreRecordHolderMap.entrySet();
							LOG.info("Final Map Size: " + highestScoreRecordHolderMap.size());
							LOG.info("Record holder map contains only 1 matched record: "
									+ highestScoreRecordHolderMap.keySet());
							for (Map.Entry<Integer, HighestScoreRecordHolder> recMapEntry : highestScoreRecordHolderMap
									.entrySet()) {
								finalMatchedRecord = recMapEntry.getValue();
								LOG.debug("finalMatchedRecord value is: " + finalMatchedRecord);
							}
						}
					} else {
						LOG.info("No matching record found after searchMatch resultset processing");
						return null;
						// return false;
					}

				} else {
					LOG.info("No matching record found by searchMatch");
					return null;
					// return false;
				}
			} catch (SiperianServerException sifExcp) {
				LOG.error("SiperianServerException occured while processing Contact Match operation: ", sifExcp);
				ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
				customException.setMessage("SIF exception occured while processing Match request for Contact. "
						+ customException.getMessage());

				throw customException;
			} catch (Exception ex) {
				LOG.error("Contact Match operation failed with exception: ", ex);
				ServiceProcessingException customException = new ServiceProcessingException(ex);
				customException
						.setMessage("Failed to process Match request for Contact. " + customException.getMessage());

				throw customException;
			}
			
			
			int countOfRetry = Integer.parseInt(configProps.getProperty("NoOfRetries"));
			boolean isMergeRetrySuccess = false;
			String rowidHighestMtchTgt = null;
			
			try	{
				/* get rowid_object of record which has highest match score */
				if (!Util.isNullOrEmpty(finalMatchedRecord.getPartyRowIDObject())) {
					rowidHighestMtchTgt = finalMatchedRecord.getPartyRowIDObject();
					LOG.info("Target party rowid_object for merge: " + rowidHighestMtchTgt);
				//	throw new ServiceProcessingException("Throwing exception during ELQ_Contact_Merge !!");
					mergeELQContact(newPartyRowid, rowidHighestMtchTgt, siperianClient);
					LOG.debug("ELQ_Contact Merge is successful !!");
				} else {
					LOG.info("No matched target record key found. Merge Operation not done");
					// mergeInd = false;
					return null;
					// return false;
				}
			} catch (Exception ex) {
				mergeInd = false;
				LOG.error("Exception occured while processing Merge operation on ELQ_Contact: " , ex);
				for(int i = 0; i<countOfRetry; i++)	{
				try{
					LOG.debug("Retrying Merge on ELQ_Contact process for "+ (i+1) +"th time");
					mergeELQContact(newPartyRowid, rowidHighestMtchTgt, siperianClient);
					LOG.debug("ELQ_Contact Merge is successful on attempt no. "+ (i+1));
					isMergeRetrySuccess = true;
					mergeInd = true;
					break;
				} catch (Exception excp) {
					LOG.error("Exception occured in ELQ_Contact Merge RetryMechanism on attempt no. "+ (i+1));
					LOG.error("Exception occured in ELQ_Contact Merge RetryMechanism on PARTY_BO");
				}
				}
				if(!isMergeRetrySuccess){
					ServiceProcessingException customException = new ServiceProcessingException(ex);
					customException.setMessage("SIF exception occured in ELQ_Contact Merge request on PARTY BO: " + customException.getMessage());
					throw customException;
				}
			}

		} catch (SiperianServerException sifExcp) {
			LOG.error("SiperianServerException occured while processing Contact Merge operation: ", sifExcp);
			ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
			customException.setMessage("SIF exception occured while processing Merge request for Contact. "
					+ customException.getMessage());
			throw customException;
		} catch (ServiceProcessingException excp) {
			LOG.error("Contact Merge operation failed due to ServiceProcessingException with exception: ", excp);
			throw excp;
		} catch (Exception ex) {
			LOG.error("Contact Merge operation failed with exception: ", ex);
			ServiceProcessingException customException = new ServiceProcessingException(ex);
			customException.setMessage("Failed to process Merge request for Contact. " + customException.getMessage());
			throw customException;
		}

		return highestScoreRecordHolderMap;
		// return true;
	}
	
	/*Execute SearchMatch API on Party & Person BO Table*/
	private List matchELQContact(PartyXrefType partyTypeParam, SiperianClient siperianClient ) throws ServiceProcessingException	{
		
		LOG.info("Executing matchELQContact()...");
		String contactRuleSetName = configProps.getProperty("contactRuleSetName");
		List searchRecords = new ArrayList();
		
		try{
			SearchMatchRequest searchMatchRequest = new SearchMatchRequest();
			SearchMatchResponse searchMatchResponse = null;
			searchMatchRequest.setRecordsToReturn(100); // Required
			// searchMatchRequest.setSiperianObjectUid("PKG_PARTY_JMS_MQ_PUB");//
			// Required
			searchMatchRequest.setSiperianObjectUid("PKG_BO_PERSON_SEARCH");// Required//PKG_BO_PERSON_SEARCH
			// searchMatchRequest.setMatchRuleSetUid(SiperianObjectType.MATCH_RULE_SET.makeUid("Org_addr_fuzzy_RealTime"));//
	
			searchMatchRequest.setMatchRuleSetUid(
					SiperianObjectType.MATCH_RULE_SET.makeUid("Party Person Fuzzy Rule Set New"));
	
			searchMatchRequest.setMatchType(MatchType.BOTH);
	
			LOG.info("Match Rule Set: " + searchMatchRequest.getMatchRuleSetUid());
			LOG.info("Match Type :" + searchMatchRequest.getMatchType());
	
			Field org_name = new Field("Organization_Name");
			if (!Util.isNullOrEmpty(partyTypeParam.getPARTYNAME())) {
				org_name.setStringValue(partyTypeParam.getPARTYNAME());
				LOG.info("Field to search for :" + org_name.getName() + ':' + org_name.getStringValue());
				searchMatchRequest.addMatchColumnField(org_name);
			}
	
			Field field_name = new Field("Person_Name");
			if (!Util.isNullOrEmpty(partyTypeParam.getPARTYNAME())) {
				field_name.setStringValue(partyTypeParam.getPARTYNAME());
				LOG.info("Field to search for :" + field_name.getName() + ':' + field_name.getStringValue());
				searchMatchRequest.addMatchColumnField(field_name);
			}
	
			// Setting Ex_Comm_Typ_Type
			Field field_Eml_Type = new Field("Ex_Comm_Type_Email");
			field_Eml_Type.setStringValue("Email");
			searchMatchRequest.addMatchColumnField(field_Eml_Type);
	
			LOG.info("Field to search for :" + field_Eml_Type.getName() + ':' + field_Eml_Type.getStringValue());
	
			// Setting Ex_Comm_Val_Eml
			Field field_Eml_Val = new Field("Ex_Comm_Val_Email");
			StringBuilder contEmlVal = new StringBuilder();
			if (!Util.isNullOrEmpty(commEmlVal)) {
				// contEmlVal.append("taylord@schaeferadvertising.com");//commEmlVal
				contEmlVal.append(commEmlVal);
				field_Eml_Val.setStringValue(contEmlVal.toString());
	
				searchMatchRequest.addMatchColumnField(field_Eml_Val);
			}
	
			LOG.info("Field to search for :" + field_Eml_Val.getName() + ':' + field_Eml_Val.getStringValue());
	
			// Setting field_Entity_Type
			Field field_Entity_Type = new Field("Ex_Entity_Type");
			field_Entity_Type.setStringValue("Person");
			searchMatchRequest.addMatchColumnField(field_Entity_Type);
	
			LOG.info("Field to search for :" + field_Entity_Type.getName() + ':'
					+ field_Entity_Type.getStringValue());
	
			// Adding SIP_POP
			Field field_SIPPOP = new Field("SIP_POP");
			field_SIPPOP.setStringValue(sipPopVal);// sipPopVal
			searchMatchRequest.addMatchColumnField(field_SIPPOP);
			LOG.info("Field to match for :" + field_SIPPOP.getName() + ':' + field_SIPPOP.getStringValue());
	
			StringBuffer criteria = new StringBuffer();
			boolean firstParam = true;
	
			/*
			 * if (firstParam) { criteria.append(" HUB_STATE_IND = '" + 1 +
			 * "'"); firstParam = false; } else { criteria.append(
			 * " AND HUB_STATE_IND = '" + 1 + "'"); }
			 */
	
			LOG.info("Filter Criteria: " + criteria.toString());
	
			searchMatchRequest.setFilterCriteria(criteria.toString());
	
			LOG.info("processing SearchMatchRequest in matchELQContact");
			searchMatchResponse = (SearchMatchResponse) siperianClient.process(searchMatchRequest);
	
			searchRecords = searchMatchResponse.getRecords();
		} catch (SiperianServerException sifExcp) {
		//		matchInd = false;
				LOG.error("[matchELQContact]:SiperianServerException occured while processing SearchMatchRequest on PARTY BO: " , sifExcp);
		//		sifExcp.printStackTrace();
				ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
				customException.setMessage("[matchELQContact]:SIF exception occured while processing SearchMatchRequest on PARTY BO: " + customException.getMessage());
				throw customException;
		} catch (Exception ex) {
		//		matchInd = false;
				LOG.error("[matchELQContact]:PARTY BO Merge operation failed with exception: " , ex);
		//		ex.printStackTrace();
				ServiceProcessingException customException = new ServiceProcessingException(ex);
				customException.setMessage("[matchELQContact]:Failed to process SearchMatchRequest on PARTY BO: " + customException.getMessage());
				throw customException;
		}
		LOG.info("Completed matchELQContact()...");
		return searchRecords;
	}
	
	/*Execute Merge API on Party BO Table*/
	private void mergeELQContact(String newPartyRowid, String rowidHighestMtchTgt, SiperianClient siperianClient) throws ServiceProcessingException	{
		
		LOG.debug("Inside mergeELQContact for PARTY BO...");
		
		try	{
			MergeRequest request = new MergeRequest();
			request.setSiperianObjectUid("BASE_OBJECT.C_B_PARTY");
			// newly created record will be merged to the existing record
			request.setSourceRecordKey(RecordKey.rowid(newPartyRowid));
			// existing record will be the survivor
			request.setTargetRecordKey(RecordKey.rowid(rowidHighestMtchTgt));
			LOG.info(" Before executing Merge process ");
			MergeResponse response = (MergeResponse) siperianClient.process(request);
			LOG.info(" After executing Merge process. Message from MergeResponse: " + response.getMessage());
			matchInd = true;
			mergeInd = true;
				
		} catch (SiperianServerException sifExcp) {
		//	mergeInd = false;
			LOG.error("SiperianServerException occured while processing mergeELQContact on PARTY BO: " , sifExcp);
	//		sifExcp.printStackTrace();
			ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
			customException.setMessage("SIF exception occured while processing mergeELQContact on PARTY BO: " + customException.getMessage());
			throw customException;
		} catch (Exception ex) {
		//	mergeInd = false;
			LOG.error("PARTY_BO mergeELQContact failed with exception: " , ex);
	//		ex.printStackTrace();
			ServiceProcessingException customException = new ServiceProcessingException(ex);
			customException.setMessage("Failed to process mergeELQContact request on PARTY BO: " + customException.getMessage());
			throw customException;
		}
		LOG.debug("Completed mergeELQContact for PARTY BO...");
	}

	public void mergeProcessMultipleChild(PartyType partyType, UpsertPartyResponse upsertPartyResponse)
			throws ServiceProcessingException {

		LOG.info("Executing mergeProcessMultipleChild()");

		Map<String, List<String>> addrTypeMap = new HashMap<String, List<String>>();
		Map<String, List<String>> commTypeMap = new HashMap<String, List<String>>();
		List<String> addrRowidList = null;
		List<String> commRowidList = null;

		UserTransaction transaction = null;
		SiperianClient siperianClient = null;

		try {
			LOG.info("Preparing type-wise rowid_object list for Address/Communication");
			// create type-wise rowid_object list for address, communication and
			// classification
			for (int indx = 0; indx < partyType.getAddress().size(); indx++) {
				String addrType = partyType.getAddress().get(indx).getADDRTYPE();
				if (!addrTypeMap.containsKey(addrType)) {
					addrRowidList = new ArrayList<String>();
					addrTypeMap.put(addrType, addrRowidList);
				}
				addrTypeMap.get(addrType).add(partyType.getAddress().get(indx).getROWIDADDRESS());
			}

			for (int indx = 0; indx < partyType.getCommunication().size(); indx++) {
				String commType = partyType.getCommunication().get(indx).getCOMMTYPE();
				if (!commTypeMap.containsKey(commType)) {
					commRowidList = new ArrayList<String>();
					commTypeMap.put(commType, commRowidList);
				}
				commTypeMap.get(commType).add(partyType.getCommunication().get(indx).getROWIDCOMMUNICATION());
			}

			LOG.info("Type-wise rowid_object list for Addr/Communication created");
		} catch (Exception ex) {
			LOG.error("Exception occured while preparing child entiry records for merge: ", ex);
			ServiceProcessingException customException = new ServiceProcessingException(ex);
			customException.setMessage("Failed to prepare child entiry records for merge: " + ex.getMessage());
			throw customException;
		}

		try {

			siperianClient = checkOut();
			transaction = ((EjbSiperianClient) siperianClient).createTX(300000);
			transaction.begin();

			LOG.info("Calling multi-merge process for Addr/Comm/Classifictn");
			// call multi-merge for each child
			Map<String, String> typeToSurvivingRowidMapAddr = multiMergeProcessChild(MDMAttributeNames.ADDRESS_BO,
					addrTypeMap, siperianClient);
			Map<String, String> typeToSurvivingRowidMapComm = multiMergeProcessChild(MDMAttributeNames.COMM_BO,
					commTypeMap, siperianClient);

			transaction.commit();
			LOG.info("Multi-merge process for Addr/Comm/Classifictn completed");

			if (upsertPartyResponse != null) {
				upsertPartyResponse.setStatus(upsertPartyResponse.getStatus() + "\n ");
				if (typeToSurvivingRowidMapAddr != null && typeToSurvivingRowidMapAddr.size() > 1) {
					upsertPartyResponse.setStatus(upsertPartyResponse.getStatus() + "Address records got merged.");
				}
				if (typeToSurvivingRowidMapComm != null && typeToSurvivingRowidMapComm.size() > 1) {
					upsertPartyResponse
							.setStatus(upsertPartyResponse.getStatus() + "Communication records got merged.");
				}
			}
		} catch (ServiceProcessingException excp) {
			LOG.error("Exception in Merge operation for child entities: ", excp);

			try {
				transaction.rollback();
				LOG.debug("Transaction rolled back successfully.");
			} catch (SystemException txExcp) {
				LOG.error("Failed to rollback transaction for Merge operation : " + txExcp.toString());
			}
			throw excp;
		} catch (Exception ex) {
			LOG.error("Exception occured in Merge operation for child entities: ", ex);
			try {
				transaction.rollback();
				LOG.debug("Transaction rolled back successfully.");
			} catch (SystemException txExcp) {
				LOG.error("Failed to rollback transaction for Merge operation: " + txExcp.toString());
				txExcp.printStackTrace();
			}
			ServiceProcessingException customException = new ServiceProcessingException(ex);
			customException.setMessage("Failed to process Merge operation for child entities: " + ex.getMessage());
			throw customException;
		} finally {
			checkIn(siperianClient);
		}

		LOG.info("Executed mergeProcessMultipleChild()");
	}

	private Map<String, String> multiMergeProcessChild(String baseObjTable, Map<String, List<String>> childTypeMap,
			SiperianClient siperianClient) throws ServiceProcessingException {
		LOG.info("Executing multiMergeProcessChild()");
		List<String> recordList = null;
		// Modified code
		List<Integer> intRecordList = null;
		String childRecType = null;
		Map<String, String> recIdToSurvivingRowidMap = new HashMap<String, String>();
		String survivingRowid = null;

		try {
			LOG.info("Before executing child multi-merge process on " + baseObjTable);
			for (Entry<String, List<String>> entry : childTypeMap.entrySet()) {
				childRecType = entry.getKey().toString();
				recordList = (List<String>) entry.getValue();

				// if more than one rowid in list, go for multi-merge
				if (recordList != null && recordList.size() > 1) {
					updateCI(recordList, baseObjTable);
					MultiMergeRequest request = new MultiMergeRequest();
					ArrayList<RecordKey> recordKeys = new ArrayList<RecordKey>();
					StringBuilder rowIds = new StringBuilder();

					intRecordList = new ArrayList<Integer>();
					for (String str : recordList) {
						intRecordList.add(new Integer(str.trim()));
					}
					Collections.sort(intRecordList); // To make sure existing
														// rowid survives

					for (int indx = 0; indx < intRecordList.size(); indx++) {
						RecordKey key = new RecordKey();
						key.setRowid(Util.padSpace(intRecordList.get(indx).toString(), 14));
						recordKeys.add(key);
						rowIds.append(intRecordList.get(indx));
						rowIds.append(", ");
						if (indx == 0) {
							survivingRowid = intRecordList.get(indx).toString();
						}
						recIdToSurvivingRowidMap.put(intRecordList.get(indx).toString(), survivingRowid);
					}
					request.setRecordKeyList(recordKeys);

					Record record = new Record();
					record.setSiperianObjectUid(SiperianObjectType.BASE_OBJECT.makeUid(baseObjTable));
					request.setRecord(record);

					LOG.info("To multi-merge on record_type: " + childRecType + " | Rowid_objects to merge: "
							+ rowIds.toString());

					MultiMergeResponse response = (MultiMergeResponse) siperianClient.process(request);

					childMergeInd = true;
					LOG.debug(" Message from MultiMergeResponse :" + response.getMessage());
				} else {
					LOG.info("Sufficient records not found for multi-merge for type " + childRecType);
				}
			} // Modified code
		} catch (SiperianServerException sifExcp) {
			childMergeInd = false;
			LOG.error("SiperianServerException occured while processing Child multi-Merge operation: ", sifExcp);
			ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
			customException.setMessage("SIF exception occured while processing muti-Merge request for " + baseObjTable
					+ ": " + sifExcp.getMessage());
			throw customException;
		} catch (Exception ex) {
			childMergeInd = false;
			LOG.error("Child Merge operation failed with exception for " + baseObjTable, ex);
			ServiceProcessingException customException = new ServiceProcessingException(ex);
			customException.setMessage("Failed to process Merge request for " + baseObjTable + ": " + ex.getMessage());
			throw customException;
		}
		LOG.info("Executed multiMergeProcessChild()");

		return recIdToSurvivingRowidMap;
	}

	private void updateCI(List<String> recordList, String baseObjTable)  throws ServiceProcessingException{
		LOG.debug("Inside updateCI()");
		Connection jdbcConn = null;
		Statement statement = null;
		JDBCConnectionProvider jDBCConnectionProvider = null;
		int rowCnt = 0;
		StringBuilder sqlQry = new StringBuilder();

		sqlQry.append("UPDATE "); 
		sqlQry.append(baseObjTable);
		sqlQry.append(" SET CONSOLIDATION_IND = '4' WHERE ROWID_OBJECT in (");
		for (String partyRowId : recordList) {
			sqlQry.append("'" + partyRowId.trim() + "',");
		}
		sqlQry.deleteCharAt(sqlQry.length() - 1).toString();
		sqlQry.append(")");

		LOG.debug("SQL in updateCI()--> " + sqlQry);

		try{
			jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
			jdbcConn = jDBCConnectionProvider.getJdbcConnectionFromDS();
			statement = jdbcConn.createStatement();
			rowCnt = statement.executeUpdate(sqlQry.toString());

			jdbcConn.commit();
			LOG.debug("RowidObject Updated for CI : " + rowCnt);
		//	LOG.debug("APPRVD_FOR_MERGE value updated to N in C_B_PARTY for partyID: " + survivingRowidObject);

		} catch(SQLException exp) {
			LOG.error("Caught SQLException in updateCI() " ,exp);

		} finally	{
			try {
				//Closing connections
			//	if (resultSet != null)	resultSet.close();
				if (statement != null) statement.close();
				if (jdbcConn != null) jdbcConn.close();
				} catch (SQLException exp) {
					LOG.error("SQLexp caught in updateCI(): " , exp);
				}

		}

		LOG.debug(" Executed updateCI() successfully ");
	}
	
	private void setUCNSeq(String rowidObject, String partyType) throws ServiceProcessingException {

		String ucnValue = null;
		try {
			// Get the next UCN value from Sequence Function
			ucnValue = prospectPartyDAO.getNextUCNValue(partyType);
			if (!Util.isNullOrEmpty(ucnValue)) {
				// Put the fetched UCN into
				putUCNRequest(rowidObject, ucnValue);
			}

		} catch (ServiceProcessingException spExcp) {
			LOG.error("Error in setUCNSeq(): " + spExcp.getMessage());
			throw spExcp;
		}
	}

	private void setContactUCNSeq(String rowidObject) throws ServiceProcessingException {

		String ucnValue = null;
		try {
			// Get the next UCN value from Sequence Function
			ucnValue = prospectPartyDAO.getNextContactUCNValue();
			if (!Util.isNullOrEmpty(ucnValue)) {
				// Put the fetched UCN into
				putUCNRequest(rowidObject, ucnValue);
			}

		} catch (ServiceProcessingException spExcp) {
			LOG.error("Error in setUCNSeq(): " + spExcp.getMessage());
			throw spExcp;
		}
	}

	// Put UCN in base object & XREF tables.
	public void putUCNRequest(String rowidObject, String ucnValue) throws ServiceProcessingException {
		LOG.info("Executing putUCNRequest()");

		SiperianClient siperianClient = null;
		UserTransaction transaction = null;
		String systemUser = "admin";

		try {
			PutRequest putRequest = new PutRequest();
			PutResponse putResponse = null;
			// String systemUser = "Admin";
			String srcSystem = "Admin"; // trimming not required
			String srcPkey = null; // trimming not required
			String srcRowid = rowidObject; // trimming not required
			LOG.info("Executing PutRequest with src_system=" + srcSystem + " | scr_pkey=" + srcPkey + " | rowid_object="
					+ srcRowid);

			// Fetch Siperian Object from
			siperianClient = (SiperianClient) checkOut();
			// create transaction - commit if Delete and Put requests both
			// succeeded
			transaction = ((EjbSiperianClient) siperianClient).createTX(1200); // in
																				// seconds
			transaction.begin();

			// prepare PutRequest
			RecordKey recordKey = new RecordKey();
			recordKey.setRowid(srcRowid);
			recordKey.setSystemName(srcSystem);
			putRequest.setRecordKey(recordKey);

			Record record = new Record();
			record.setSiperianObjectUid(SiperianObjectType.BASE_OBJECT.makeUid(MDMAttributeNames.PARTY_BO));
			record.setField(new Field(MDMAttributeNames.SRC_UPDT_BY, systemUser));
			record.setField(new Field(PartyAttributes.UCN, ucnValue));
			record.setField(new Field(PartyAttributes.STATUS_CD, "A"));

			putRequest.setRecord(record);
			// execute Put request
			putResponse = (PutResponse) siperianClient.process(putRequest);

			LOG.info("Committing UCN transaction");
			transaction.commit();
			LOG.info("Put request for UCN assignment processed successfully: Action Type = "
					+ putResponse.getActionType() + " | Msg = " + putResponse.getMessage());

		} catch (SiperianServerException sifExcp) {
			LOG.error("SiperianServerException occured while assigning UCN by Put request: ", sifExcp);
			ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
			customException.setMessage(
					"SiperianServerException occured while assigning UCN by Put request: " + sifExcp.getMessage());
			throw customException;
		} catch (Exception excp) {
			LOG.error("Exception occured while assigning UCN by Put request: ", excp);
			ServiceProcessingException customException = new ServiceProcessingException(excp);
			customException.setMessage("Exception occured while assigning UCN by Put request: " + excp.getMessage());
			throw customException;
		} finally {
			checkIn(siperianClient);
		}

		LOG.info("Executed putUCNRequest()");

	}

	// Method to calculate HighestMatchScore
	private Integer highestMatchScore(Map<Integer, Integer> matchScoreMap) {
		Collection<Integer> collVal = matchScoreMap.values();
		List<Integer> scoreList = new ArrayList<Integer>(collVal);
		// Collections.sort(scoreList);
		// Object maxScore = scoreList.get(scoreList.size()-1);
		Integer maxScore = Collections.max(scoreList);
		LOG.debug("Highest Match score " + maxScore);

		return maxScore;
	}

	// Method to calculate highest/maximum Match Score
	private List<Integer> maxMatchScore(Map<Integer, Integer> matchScoreMap) {
		Collection<Integer> collVal = matchScoreMap.values();
		List<Integer> scoreList = new ArrayList<Integer>(collVal);
		List<Integer> rowidObjs = new ArrayList<Integer>(); //
		// Collections.sort(scoreList);
		// Object maxScore = scoreList.get(scoreList.size()-1);
		Integer maxScore = Collections.max(scoreList);
		int cnt = 0;
		// for (Iterator itr = scoreList.iterator(); itr.hasNext();) {
		for (Entry<Integer, Integer> entry : matchScoreMap.entrySet()) {
			if (maxScore.equals(entry.getValue())) {
				cnt++;
				rowidObjs.add(entry.getKey());
			}
		}
		LOG.debug("No of records having highest match score " + maxScore + ": " + cnt);
		return rowidObjs;
	}
	
	// Method to check Relationship present but did not activate
	private Map<String, String> checkRelationship(String contactRowid, String rowIdAccount) throws ServiceProcessingException{
		
		Connection jdbcConn = null;
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		JDBCConnectionProvider jDBCConnectionProvider = null;
		Map<String, String> dataMap = new HashMap<String, String>();
		
		LOG.debug("[checkRelationship] check deactivated relation for ROWID_PARTY ="+rowIdAccount+" and ROWID_PARTY_2 ="+contactRowid);
		StringBuilder sqlQry = new StringBuilder();
		sqlQry.append("SELECT PLX.PKEY_SRC_OBJECT, PLX.ROWID_SYSTEM FROM C_B_PARTY_REL PL,  C_B_PARTY_REL_XREF PLX WHERE ");
		sqlQry.append(" PL.ROWID_OBJECT = PLX.ROWID_OBJECT AND PL.ROWID_PARTY=? AND PL.ROWID_PARTY_2=? ");
		sqlQry.append(" AND PL.ROWID_HIERARCHY='4' AND PL.ROWID_REL_TYPE='25' AND PL.HUB_STATE_IND =-1");
		
		try{
			jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
			jdbcConn = jDBCConnectionProvider.getJdbcConnectionFromDS();
			statement = jdbcConn.prepareStatement(sqlQry.toString());
			statement.setString(1, rowIdAccount);
			statement.setString(2, contactRowid);
			resultSet = statement.executeQuery();
			while(resultSet.next()){
				dataMap.put(resultSet.getString("PKEY_SRC_OBJECT"), resultSet.getString("ROWID_SYSTEM"));
			}
		      
		} catch(SQLException exp) {
			LOG.error("Caught SQLException in checkRelationship() " ,exp);
		} finally	{
			try {
				//Closing connections
				if (resultSet != null)	resultSet.close();
				if (statement != null) statement.close();
				if (jdbcConn != null) jdbcConn.close();
				} catch (SQLException exp) {
					LOG.error("SQLexp caught in checkRelationship(): " , exp);
				}

		}
		LOG.debug("[checkRelationship] check deactivated relation present "+dataMap.isEmpty());
		return dataMap;
	}
	
	/**
	 * The method restore deactivated relationship on PARTY_REL landing
	 * table for the given Contact profiles.
	 * 
	 * @param srcSystem
	 * @param srcPkey
	 * @return void
	 * @throws ServiceProcessingException
	 */
	private void restoreAccountContactRel(String srcSystem, String srcPkey) throws ServiceProcessingException{
		
		LOG.debug("[restoreAccountContactRel] ENTER");
		LOG.debug("[restoreAccountContactRel] srcSystem::" + srcSystem + ", srcPkey::" + srcPkey );
		UserTransaction transaction = null;
		SiperianClient siperianClient = null;
		try {
			siperianClient = (SiperianClient) checkOut();
			transaction = ((EjbSiperianClient) siperianClient).createTX(300000);
			transaction.begin();
			RestoreRequest request = new RestoreRequest();
			XrefKey xrefKey = new XrefKey();
			xrefKey.setSourceKey(srcPkey.trim());
			xrefKey.setSystemName(srcSystem.trim());
			ArrayList xrefKeys = new ArrayList();
			xrefKeys.add(xrefKey);
			request.setXrefKeys(xrefKeys);
			request.setSiperianObjectUid(SiperianObjectType.BASE_OBJECT.makeUid("C_B_PARTY_REL"));
			RestoreResponse response = (RestoreResponse) siperianClient.process(request);
			LOG.debug("[restoreAccountContactRel] response message::" + response.getMessage());
			transaction.commit();
		}catch(Exception ex){
			
			LOG.error("Exception occured while Restore requests: ", ex);
			try {
				transaction.rollback();
			} catch (SystemException txExcp) {
				LOG.error("Failed to rollback transaction for Restor requests : ", txExcp);
			}
			ServiceProcessingException customException = new ServiceProcessingException(ex);
			customException.setMessage("Failed to process RestorRequest SIF request." + customException.getMessage());
			throw customException;
		} finally {
			checkIn(siperianClient);
		}
		
	}
}