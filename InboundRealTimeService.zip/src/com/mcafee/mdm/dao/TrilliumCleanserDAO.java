package com.mcafee.mdm.dao;

import java.io.IOException;
import java.io.StringWriter;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Properties;

import javax.annotation.Resource;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.namespace.QName;
import javax.xml.ws.BindingProvider;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.mcafee.mdm.constants.Constant;
import com.mcafee.mdm.exception.ServiceProcessingException;
import com.mcafee.mdm.generated.AddressXrefType;
import com.mcafee.mdm.generated.PartySearchCriteriaType;
import com.mcafee.mdm.generated.PartyXrefType;
import com.mcafee.mdm.util.Util;
import com.trillium.director.soap.CleanseUnicode;
import com.trillium.director.soap.ObjectFactory;
import com.trillium.director.soap.TrilliumDirectorSOAP;
import com.trillium.director.soap.TrilliumDirectorSOAPPortType;
import com.trillium.director.soap.xsd.TrilliumFieldValue;
import com.trillium.director.soap.xsd.TrilliumRecord;

/**
 * Used to call Trillium Cleanser functionality to cleanse and standardize Name
 * and Address input attributes. Cleanser web service exposed by Trillium
 * Director project is consumed here.
 *
 */
@Component
public class TrilliumCleanserDAO {
	private static final Logger LOG = Logger.getLogger(TrilliumCleanserDAO.class.getName());

	@Resource(name = "configProp")
	private Properties configProps;

	private QName qname = new QName("http://soap.director.trillium.com", "TrilliumDirectorSOAP");

	/**
	 * FuzzySearch Trillium Call Method to call Cleanser functionality with
	 * input values, pre-defined rules and Trillium column name mappings. Output
	 * of the cleanser service is used to update input attributes.
	 * 
	 * @param partyrequest
	 *            PartyType object represents request Party profile
	 */
	public boolean callTrilliumCleanser(PartySearchCriteriaType partyrequest) throws ServiceProcessingException {

		LOG.info("[callTrilliumCleanser] ENTER");
		boolean setTrilliumValue = false;
		try {
			String systemID = configProps.getProperty("trillium-account-systemid");
			String trilURL = configProps.getProperty("trillium-ws.url");
			String responseTimeOut = configProps.getProperty("trillium-ws.timeout");

			LOG.debug("[callCleanseUnicode] systemID::" + systemID + "\ntrilURL Account::" + trilURL + "\nResponse TimeOut::" + responseTimeOut);

			TrilliumDirectorSOAP service = new TrilliumDirectorSOAP(new URL(trilURL), qname);
			TrilliumDirectorSOAPPortType port = service.getTrilliumDirectorSOAPHttpSoap11Endpoint();
			if (!Util.isNullOrEmpty(responseTimeOut)) {
				((BindingProvider) port).getRequestContext().put("javax.xml.ws.client.receiveTimeout", responseTimeOut);
			}

			ObjectFactory requestObjectFactory = new ObjectFactory();
			com.trillium.director.soap.xsd.ObjectFactory xsdObjectFactory = new com.trillium.director.soap.xsd.ObjectFactory();
			CleanseUnicode request = requestObjectFactory.createCleanseUnicode();
			TrilliumRecord inputRecord = xsdObjectFactory.createTrilliumRecord();

			TrilliumFieldValue fieldValue = xsdObjectFactory.createTrilliumFieldValue();
			fieldValue.setTrilliumField(xsdObjectFactory.createTrilliumFieldValueTrilliumField("Account_Name"));
			fieldValue.setTrilliumValue(
					xsdObjectFactory.createTrilliumFieldValueTrilliumValue(partyrequest.getPARTYNAME()));
			inputRecord.getTrilliumFieldValues().add(fieldValue);

			fieldValue = xsdObjectFactory.createTrilliumFieldValue();
			fieldValue.setTrilliumField(xsdObjectFactory.createTrilliumFieldValueTrilliumField("Address1"));
			fieldValue.setTrilliumValue(
					xsdObjectFactory.createTrilliumFieldValueTrilliumValue(partyrequest.getADDRLN1()));
			inputRecord.getTrilliumFieldValues().add(fieldValue);

			fieldValue = xsdObjectFactory.createTrilliumFieldValue();
			fieldValue.setTrilliumField(xsdObjectFactory.createTrilliumFieldValueTrilliumField("Address2"));
			fieldValue.setTrilliumValue(
					xsdObjectFactory.createTrilliumFieldValueTrilliumValue(partyrequest.getADDRLN2()));
			inputRecord.getTrilliumFieldValues().add(fieldValue);

			fieldValue = xsdObjectFactory.createTrilliumFieldValue();
			fieldValue.setTrilliumValue(
					xsdObjectFactory.createTrilliumFieldValueTrilliumValue(partyrequest.getADDRLN3()));
			fieldValue = xsdObjectFactory.createTrilliumFieldValue();
			inputRecord.getTrilliumFieldValues().add(fieldValue);

			fieldValue = xsdObjectFactory.createTrilliumFieldValue();
			fieldValue.setTrilliumField(xsdObjectFactory.createTrilliumFieldValueTrilliumField("City"));
			fieldValue.setTrilliumValue(xsdObjectFactory.createTrilliumFieldValueTrilliumValue(partyrequest.getCITY()));
			inputRecord.getTrilliumFieldValues().add(fieldValue);

			fieldValue = xsdObjectFactory.createTrilliumFieldValue();
			fieldValue.setTrilliumField(xsdObjectFactory.createTrilliumFieldValueTrilliumField("State"));
			fieldValue.setTrilliumValue(
					xsdObjectFactory.createTrilliumFieldValueTrilliumValue(partyrequest.getSTATECD()));
			inputRecord.getTrilliumFieldValues().add(fieldValue);

			fieldValue = xsdObjectFactory.createTrilliumFieldValue();
			fieldValue.setTrilliumField(xsdObjectFactory.createTrilliumFieldValueTrilliumField("Postal_Cd"));
			fieldValue.setTrilliumValue(
					xsdObjectFactory.createTrilliumFieldValueTrilliumValue(partyrequest.getPOSTALCD()));
			inputRecord.getTrilliumFieldValues().add(fieldValue);

			fieldValue = xsdObjectFactory.createTrilliumFieldValue();
			fieldValue.setTrilliumField(xsdObjectFactory.createTrilliumFieldValueTrilliumField("Country"));
			fieldValue.setTrilliumValue(
					xsdObjectFactory.createTrilliumFieldValueTrilliumValue(partyrequest.getCOUNTRYCD()));
			inputRecord.getTrilliumFieldValues().add(fieldValue);

			request.setInputRecord(requestObjectFactory.createCleanseUnicodeInputRecord(inputRecord));
			String outputField = "NEW_DR_NAME";
			request.getOutputFields().add(outputField);
			outputField = "NEW_DR_ADDRESS1";
			request.getOutputFields().add(outputField);
			outputField = "NEW_DR_ADDRESS2";
			request.getOutputFields().add(outputField);
			outputField = "NEW_DR_ADDRESS3";
			request.getOutputFields().add(outputField);
			outputField = "NEW_DR_CITY_NAME";
			request.getOutputFields().add(outputField);
			outputField = "STATE_CODE";
			request.getOutputFields().add(outputField);
			outputField = "NEW_DR_POSTAL_CODE";
			request.getOutputFields().add(outputField);
			outputField = "COUNTRY";
			request.getOutputFields().add(outputField);
			outputField = "MATCH_LEVEL";
			request.getOutputFields().add(outputField);
			outputField = "NAME_QUALITY_IDENTIFIER";
			request.getOutputFields().add(outputField);
			request.setServerName(requestObjectFactory.createCleanseUnicodeServerName("Cleanser"));
			request.setSystemID(requestObjectFactory.createCleanseUnicodeSystemID(systemID));
			JAXBContext jaxbContext = JAXBContext.newInstance(CleanseUnicode.class);
			Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
			jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
			StringWriter strWriter = new StringWriter();
			jaxbMarshaller.marshal(request, strWriter);
			String msgTxt = strWriter.getBuffer().toString();
			LOG.debug("[callCleanseUnicode] Request::\n" + msgTxt);
			TrilliumRecord response = port.cleanseUnicode(request.getSystemID().getValue(),
					request.getServerName().getValue(), inputRecord, request.getOutputFields());
			LOG.debug("[callCleanseUnicode]--------------OUTPUT----------------");
			for (TrilliumFieldValue respFieldValue : response.getTrilliumFieldValues()) {
				LOG.debug(respFieldValue.getTrilliumField().getValue() + "::"
						+ respFieldValue.getTrilliumValue().getValue());

			}

			if (CollectionUtils.isEmpty(response.getTrilliumFieldValues())) {
				LOG.debug("Empty Trillium Field Value in response");
			} else if (response.getTrilliumFieldValues().get(0) != null
					&& response.getTrilliumFieldValues().get(0).getTrilliumField() != null && "ECS_ERROR_CODE"
							.equalsIgnoreCase(response.getTrilliumFieldValues().get(0).getTrilliumField().getValue())) {
				LOG.debug("ERROR in Trillium Response::"
						+ response.getTrilliumFieldValues().get(0).getTrilliumField().getValue() + "::"
						+ response.getTrilliumFieldValues().get(0).getTrilliumValue().getValue() + ", "
						+ response.getTrilliumFieldValues().get(1).getTrilliumField().getValue() + "::"
						+ response.getTrilliumFieldValues().get(1).getTrilliumValue().getValue());
			} else if (response.getTrilliumFieldValues().get(0) != null
					&& response.getTrilliumFieldValues().get(0).getTrilliumValue() != null
					&& !Util.isNullOrEmpty(response.getTrilliumFieldValues().get(0).getTrilliumValue().getValue())
					&& !(response.getTrilliumFieldValues().get(0).getTrilliumValue().getValue()
							.equalsIgnoreCase("XX"))) {
				LOG.debug("[callCleanseUnicode]-------------AFTER SETTING CLEANSED VALUES--------------- ");
				// Setting NEW_DR_NAME
				partyrequest.setPARTYNAME(response.getTrilliumFieldValues().get(0).getTrilliumValue().getValue());
				LOG.debug("[callCleanseUnicode]NEW_DR_NAME: " + partyrequest.getPARTYNAME());
				// Setting NEW_DR_ADDRESS1
				partyrequest.setADDRLN1(response.getTrilliumFieldValues().get(1).getTrilliumValue().getValue());
				LOG.debug("[callCleanseUnicode]NEW_DR_ADDRESS1: " + partyrequest.getADDRLN1());
				// Setting NEW_DR_ADDRESS2
				partyrequest.setADDRLN2(response.getTrilliumFieldValues().get(2).getTrilliumValue().getValue());
				LOG.debug("[callCleanseUnicode]NEW_DR_ADDRESS2: " + partyrequest.getADDRLN2());
				// Setting NEW_DR_ADDRESS3
				partyrequest.setADDRLN3(response.getTrilliumFieldValues().get(3).getTrilliumValue().getValue());
				LOG.debug("[callCleanseUnicode]NEW_DR_ADDRESS3: " + partyrequest.getADDRLN3());
				// Setting NEW_DR_CITY_NAME
				partyrequest.setCITY(response.getTrilliumFieldValues().get(4).getTrilliumValue().getValue());
				LOG.debug("[callCleanseUnicode]NEW_DR_CITY_NAME: " + partyrequest.getCITY());
				// Setting STATE_CODE
				partyrequest.setSTATECD(response.getTrilliumFieldValues().get(5).getTrilliumValue().getValue());
				LOG.debug("[callCleanseUnicode]STATE_CODE: " + partyrequest.getSTATECD());
				// Setting NEW_DR_POSTAL_CODE
				partyrequest.setPOSTALCD(response.getTrilliumFieldValues().get(6).getTrilliumValue().getValue());
				LOG.debug("[callCleanseUnicode]NEW_DR_POSTAL_CODE: " + partyrequest.getPOSTALCD());
				// Setting COUNTRY
				partyrequest.setCOUNTRYCD(response.getTrilliumFieldValues().get(7).getTrilliumValue().getValue());
				LOG.debug("[callCleanseUnicode]COUNTRY: " + partyrequest.getCOUNTRYCD());

				setTrilliumValue = true;
			}
		} catch (IOException ioExcp) {
			LOG.error("Failed to create Trillium WS: " + ioExcp);
			ServiceProcessingException customException = new ServiceProcessingException(ioExcp);
			customException.setMessage("Trillium Cleanser service call failed." + customException.getMessage());
			throw customException;
		} catch (JAXBException e) {
			LOG.error("Failed to create JAXB Context / Marshller: " + e);
			ServiceProcessingException customException = new ServiceProcessingException(e);
			customException.setMessage("Trillium Cleanser service call failed. " + customException.getMessage());
			throw customException;
		} catch (Exception ex) {
			LOG.error("Failed to cleanse data from Trillium: " + ex);
			ServiceProcessingException customException = new ServiceProcessingException(ex);
			customException.setMessage("Trillium Cleanser service call failed. " + customException.getMessage());
			throw customException;
		}
		return setTrilliumValue;
	}

	/**
	 * Trillium Cleanser call for Upsert process
	 * 
	 * @param partyrequest
	 * @param isContact
	 * @return
	 * @throws ServiceProcessingException
	 */
	public boolean callTrilliumCleanser(PartyXrefType partyrequest, Boolean isContact)
			throws ServiceProcessingException {

		LOG.info("[callTrilliumCleanser] ENTER");
		boolean setTrilliumValue = Boolean.FALSE;

		try {
			callCleanseUnicode(partyrequest, isContact);
			setTrilliumValue = Boolean.TRUE;
		} catch (Exception ex) {
			LOG.error("[callTrilliumCleanser] Failed to cleanse data from Trillium: ", ex);
		}
		LOG.debug("[callTrilliumCleanser] EXIT:: setTrilliumValue::" + setTrilliumValue);
		return setTrilliumValue;
	}

	/**
	 * 
	 * @param partyrequest
	 * @param isContact
	 * @throws JAXBException
	 * @throws MalformedURLException
	 */
	private void callCleanseUnicode(PartyXrefType partyrequest, Boolean isContact)
			throws JAXBException, MalformedURLException {

		LOG.debug("[callCleanseUnicode] ENTER");
		String systemID = configProps.getProperty("trillium-account-systemid");
		String trilURL = configProps.getProperty("trillium-ws.url");
		String responseTimeOut = configProps.getProperty("trillium-ws.timeout");

		LOG.debug("[callCleanseUnicode] systemID::" + systemID + "\ntrilURL Contact::" + trilURL + "\nResponse TimeOut::" + responseTimeOut);

		TrilliumDirectorSOAP service = new TrilliumDirectorSOAP(new URL(trilURL), qname);
		TrilliumDirectorSOAPPortType port = service.getTrilliumDirectorSOAPHttpSoap11Endpoint();
		if (!Util.isNullOrEmpty(responseTimeOut)) {
			((BindingProvider) port).getRequestContext().put("javax.xml.ws.client.receiveTimeout", responseTimeOut);
		}

		String partyNm = partyrequest.getPARTYNAME();
		String srcSystem = partyrequest.getXREF().get(0).getSRCSYSTEM();
		if (isContact) {
			if (partyrequest.getXREF().get(0).getSRCSYSTEM().equalsIgnoreCase("SFC")){
				if (!Util.isNullOrEmpty(partyrequest.getPartyPerson().get(0).getSRCACCOUNTNAME())) {
					partyNm = partyrequest.getPartyPerson().get(0).getSRCACCOUNTNAME();
				
				}
				else{
					partyNm = partyrequest.getPARTYNAME();
				}
				
			}else if (Constant.SRC_SYSTEM_ADB.equalsIgnoreCase(srcSystem)){
				partyNm = partyrequest.getPARTYNAME();
			}
			else{
			partyNm = partyrequest.getPartyPerson().get(0).getREPORTEDCOMPANYNAME();
			}
		}

		for (AddressXrefType curAddress : partyrequest.getAddress()) {
			ObjectFactory requestObjectFactory = new ObjectFactory();
			com.trillium.director.soap.xsd.ObjectFactory xsdObjectFactory = new com.trillium.director.soap.xsd.ObjectFactory();

			CleanseUnicode request = requestObjectFactory.createCleanseUnicode();
			TrilliumRecord inputRecord = xsdObjectFactory.createTrilliumRecord();

			TrilliumFieldValue fieldValue = xsdObjectFactory.createTrilliumFieldValue();
			fieldValue.setTrilliumField(xsdObjectFactory.createTrilliumFieldValueTrilliumField("Account_Name"));
			fieldValue.setTrilliumValue(xsdObjectFactory.createTrilliumFieldValueTrilliumValue(partyNm));
			inputRecord.getTrilliumFieldValues().add(fieldValue);

			fieldValue = xsdObjectFactory.createTrilliumFieldValue();
			fieldValue.setTrilliumField(xsdObjectFactory.createTrilliumFieldValueTrilliumField("Address1"));
			fieldValue
					.setTrilliumValue(xsdObjectFactory.createTrilliumFieldValueTrilliumValue(curAddress.getADDRLN1()));
			inputRecord.getTrilliumFieldValues().add(fieldValue);

			fieldValue = xsdObjectFactory.createTrilliumFieldValue();
			fieldValue.setTrilliumField(xsdObjectFactory.createTrilliumFieldValueTrilliumField("Address2"));
			fieldValue
					.setTrilliumValue(xsdObjectFactory.createTrilliumFieldValueTrilliumValue(curAddress.getADDRLN2()));
			inputRecord.getTrilliumFieldValues().add(fieldValue);

			fieldValue = xsdObjectFactory.createTrilliumFieldValue();
			fieldValue.setTrilliumField(xsdObjectFactory.createTrilliumFieldValueTrilliumField("Address3"));
			fieldValue
					.setTrilliumValue(xsdObjectFactory.createTrilliumFieldValueTrilliumValue(curAddress.getADDRLN3()));
			inputRecord.getTrilliumFieldValues().add(fieldValue);

			fieldValue = xsdObjectFactory.createTrilliumFieldValue();
			fieldValue.setTrilliumField(xsdObjectFactory.createTrilliumFieldValueTrilliumField("City"));
			fieldValue.setTrilliumValue(xsdObjectFactory.createTrilliumFieldValueTrilliumValue(curAddress.getCITY()));
			inputRecord.getTrilliumFieldValues().add(fieldValue);

			fieldValue = xsdObjectFactory.createTrilliumFieldValue();
			fieldValue.setTrilliumField(xsdObjectFactory.createTrilliumFieldValueTrilliumField("State"));
			fieldValue
					.setTrilliumValue(xsdObjectFactory.createTrilliumFieldValueTrilliumValue(curAddress.getSTATECD()));
			inputRecord.getTrilliumFieldValues().add(fieldValue);

			fieldValue = xsdObjectFactory.createTrilliumFieldValue();
			fieldValue.setTrilliumField(xsdObjectFactory.createTrilliumFieldValueTrilliumField("Postal_Cd"));
			fieldValue
					.setTrilliumValue(xsdObjectFactory.createTrilliumFieldValueTrilliumValue(curAddress.getPOSTALCD()));
			inputRecord.getTrilliumFieldValues().add(fieldValue);

			fieldValue = xsdObjectFactory.createTrilliumFieldValue();
			fieldValue.setTrilliumField(xsdObjectFactory.createTrilliumFieldValueTrilliumField("Country"));
			fieldValue.setTrilliumValue(
					xsdObjectFactory.createTrilliumFieldValueTrilliumValue(curAddress.getCOUNTRYCD()));
			inputRecord.getTrilliumFieldValues().add(fieldValue);

			request.setInputRecord(requestObjectFactory.createCleanseUnicodeInputRecord(inputRecord));
			String outputField = "NEW_DR_NAME";
			request.getOutputFields().add(outputField);
			outputField = "NEW_DR_ADDRESS1";
			request.getOutputFields().add(outputField);
			outputField = "NEW_DR_ADDRESS2";
			request.getOutputFields().add(outputField);
			outputField = "NEW_DR_ADDRESS3";
			request.getOutputFields().add(outputField);
			outputField = "NEW_DR_CITY_NAME";
			request.getOutputFields().add(outputField);
			outputField = "STATE_CODE";
			request.getOutputFields().add(outputField);
			outputField = "NEW_DR_POSTAL_CODE";
			request.getOutputFields().add(outputField);
			outputField = "COUNTRY";
			request.getOutputFields().add(outputField);
			outputField = "MATCH_LEVEL";
			request.getOutputFields().add(outputField);
			outputField = "NAME_QUALITY_IDENTIFIER";
			request.getOutputFields().add(outputField);
			request.setServerName(requestObjectFactory.createCleanseUnicodeServerName("Cleanser"));
			request.setSystemID(requestObjectFactory.createCleanseUnicodeSystemID(systemID));
			JAXBContext jaxbContext = JAXBContext.newInstance(CleanseUnicode.class);
			Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
			jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
			StringWriter strWriter = new StringWriter();
			jaxbMarshaller.marshal(request, strWriter);
			String msgTxt = strWriter.getBuffer().toString();
			LOG.debug("[callCleanseUnicode] Request::\n" + msgTxt);
			TrilliumRecord response = port.cleanseUnicode(request.getSystemID().getValue(),
					request.getServerName().getValue(), inputRecord, request.getOutputFields());
			LOG.debug("[callCleanseUnicode]--------------OUTPUT----------------");
			for (TrilliumFieldValue respFieldValue : response.getTrilliumFieldValues()) {
				LOG.debug(respFieldValue.getTrilliumField().getValue() + "::"
						+ respFieldValue.getTrilliumValue().getValue());

			}

			if (CollectionUtils.isEmpty(response.getTrilliumFieldValues())) {
				LOG.debug("Empty Trillium Field Value in response");
			} else if (response.getTrilliumFieldValues().get(0) != null
					&& response.getTrilliumFieldValues().get(0).getTrilliumField() != null && "ECS_ERROR_CODE"
							.equalsIgnoreCase(response.getTrilliumFieldValues().get(0).getTrilliumField().getValue())) {
				LOG.debug("ERROR in Trillium Response::"
						+ response.getTrilliumFieldValues().get(0).getTrilliumField().getValue() + "::"
						+ response.getTrilliumFieldValues().get(0).getTrilliumValue().getValue() + ", "
						+ response.getTrilliumFieldValues().get(1).getTrilliumField().getValue() + "::"
						+ response.getTrilliumFieldValues().get(1).getTrilliumValue().getValue());
			} else if (response.getTrilliumFieldValues().get(0) != null
					&& response.getTrilliumFieldValues().get(0).getTrilliumValue() != null
					&& !Util.isNullOrEmpty(response.getTrilliumFieldValues().get(0).getTrilliumValue().getValue())
					&& !(response.getTrilliumFieldValues().get(0).getTrilliumValue().getValue()
							.equalsIgnoreCase("XX"))) {
				LOG.debug("[callCleanseUnicode]-------------AFTER SETTING CLEANSED VALUES--------------- ");
				// Setting NEW_DR_NAME
				if (isContact) {
					// Setting Reported Company Name
					partyrequest.getPartyPerson().get(0).setREPORTEDCOMPANYNAME(
							response.getTrilliumFieldValues().get(0).getTrilliumValue().getValue());
					LOG.debug("[callCleanseUnicode]NEW_DR_NAME: "
							+ partyrequest.getPartyPerson().get(0).getREPORTEDCOMPANYNAME());
				} else {
					// Setting Party Name
					partyrequest.setPARTYNAME(response.getTrilliumFieldValues().get(0).getTrilliumValue().getValue());
					LOG.debug("[callCleanseUnicode]NEW_DR_NAME: " + partyrequest.getPARTYNAME());
					if(partyrequest.getAccount()!=null && partyrequest.getAccount().size()>0){
					partyrequest.getAccount().get(0).setNAMEQUALITYIDENTIFIER(
							response.getTrilliumFieldValues().get(9).getTrilliumValue().getValue());
					LOG.debug("[callCleanseUnicode]NAME_QUALITY_IDENTIFIER: "
							+ partyrequest.getAccount().get(0).getNAMEQUALITYIDENTIFIER());
					}
				}
				// Setting NEW_DR_ADDRESS1
				curAddress.setADDRLN1(response.getTrilliumFieldValues().get(1).getTrilliumValue().getValue());
				LOG.debug("[callCleanseUnicode]NEW_DR_ADDRESS1: " + curAddress.getADDRLN1());
				// Setting NEW_DR_ADDRESS2
				curAddress.setADDRLN2(response.getTrilliumFieldValues().get(2).getTrilliumValue().getValue());
				LOG.debug("[callCleanseUnicode]NEW_DR_ADDRESS2: " + curAddress.getADDRLN2());
				// Setting NEW_DR_ADDRESS3
				curAddress.setADDRLN3(response.getTrilliumFieldValues().get(3).getTrilliumValue().getValue());
				LOG.debug("[callCleanseUnicode]NEW_DR_ADDRESS3: " + curAddress.getADDRLN3());
				// Setting NEW_DR_CITY_NAME
				curAddress.setCITY(response.getTrilliumFieldValues().get(4).getTrilliumValue().getValue());
				LOG.debug("[callCleanseUnicode]NEW_DR_CITY_NAME: " + curAddress.getCITY());
				// Setting STATE_CODE
				curAddress.setSTATECD(response.getTrilliumFieldValues().get(5).getTrilliumValue().getValue());
				LOG.debug("[callCleanseUnicode]STATE_CODE: " + curAddress.getSTATECD());
				// Setting NEW_DR_POSTAL_CODE
				curAddress.setPOSTALCD(response.getTrilliumFieldValues().get(6).getTrilliumValue().getValue());
				LOG.debug("[callCleanseUnicode]NEW_DR_POSTAL_CODE: " + curAddress.getPOSTALCD());
				// Setting COUNTRY
				curAddress.setCOUNTRYCD(response.getTrilliumFieldValues().get(7).getTrilliumValue().getValue());
				LOG.debug("[callCleanseUnicode]COUNTRY: " + curAddress.getCOUNTRYCD());
				// Setting ADDRESS_QUALITY_IDENTIFIER
				curAddress.setADDRESSQUALITYIDENTIFIER(
						response.getTrilliumFieldValues().get(8).getTrilliumValue().getValue());
				LOG.debug(
						"[callCleanseUnicode]ADDRESS_QUALITY_IDENTIFIER: " + curAddress.getADDRESSQUALITYIDENTIFIER());
			}
		}
		LOG.debug("[callCleanseUnicode] EXIT");
	}
}
