package com.mcafee.mdm.dao;

import org.apache.log4j.Logger;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.mcafee.mdm.exception.ServiceProcessingException;
import com.mcafee.mdm.generated.MdmUpsertPartyRequest;
import com.mcafee.mdm.generated.MdmUpsertPartyResponse;
import com.mcafee.mdm.generated.PartyXrefType;

/**
 * 
 * This class is used to call Customer creation in MDM.
 *
 */

public class UpsertCustomerDAO extends SFDCUpsertPartyDAO {

	private static final Logger LOG = Logger.getLogger(UpsertCustomerDAO.class.getName());
	
	public void processUpsertRequestForIndividualCustomer(String methodName, PartyXrefType upsertParty,
			MdmUpsertPartyResponse upsertPartyResponse) throws ServiceProcessingException, SecurityException, ClassNotFoundException {
		LOG.info("Executing processUpsertRequestForIndividualCustomer()");
		// TODO Auto-generated method stub
		processUpsertRequestForIndividualParty(methodName, upsertParty, upsertPartyResponse);
	}
	
	
}
