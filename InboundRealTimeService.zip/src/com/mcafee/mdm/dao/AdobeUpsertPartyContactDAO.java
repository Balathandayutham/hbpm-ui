package com.mcafee.mdm.dao;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;


import javax.annotation.Resource;
import javax.transaction.SystemException;
import javax.transaction.UserTransaction;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.mcafee.mdm.constants.AddressAttributes;
import com.mcafee.mdm.constants.CommunicationAttributes;
import com.mcafee.mdm.constants.Constant;
import com.mcafee.mdm.constants.MDMAttributeNames;
import com.mcafee.mdm.constants.PartyAttributes;
import com.mcafee.mdm.constants.PartyPersonAttributes;
import com.mcafee.mdm.dao.pojo.AcntCntctRelData;
import com.mcafee.mdm.dao.pojo.CntctPkeyRowIdRelData;
import com.mcafee.mdm.dao.pojo.HighestScoreRecordHolder;
import com.mcafee.mdm.dao.pojo.PutResponseDataHolder;
import com.mcafee.mdm.exception.ServiceProcessingException;
import com.mcafee.mdm.generated.Address;
import com.mcafee.mdm.generated.AddressType;
import com.mcafee.mdm.generated.AddressXrefType;
import com.mcafee.mdm.generated.Communication;
import com.mcafee.mdm.generated.CommunicationType;
import com.mcafee.mdm.generated.CommunicationXrefType;
import com.mcafee.mdm.generated.MdmUpsertPartyRequest;
import com.mcafee.mdm.generated.MdmUpsertPartyResponse;
import com.mcafee.mdm.generated.PartyContactMDMRelationshipType;
import com.mcafee.mdm.generated.PartyPerson;
import com.mcafee.mdm.generated.PartyPersonMDMRelationshipType;
import com.mcafee.mdm.generated.PartyPersonType;
import com.mcafee.mdm.generated.PartyPersonXrefType;
import com.mcafee.mdm.generated.PartyRel;
import com.mcafee.mdm.generated.PartyType;
import com.mcafee.mdm.generated.PartyUpsertRespType;
import com.mcafee.mdm.generated.PartyXrefType;
import com.mcafee.mdm.generated.StatusType;
import com.mcafee.mdm.generated.XREFCopy;
import com.mcafee.mdm.generated.XREFType;
import com.mcafee.mdm.util.CommonUtil;
import com.mcafee.mdm.util.JDBCConnectionProvider;
import com.mcafee.mdm.util.ObjectPool;
import com.mcafee.mdm.util.PerformanceLoggerUtil;
import com.mcafee.mdm.util.PropertyUtil;
import com.mcafee.mdm.util.Util;
import com.mcafee.mdm.util.ValidatorUtil;
import com.siperian.sif.client.EjbSiperianClient;
import com.siperian.sif.client.SiperianClient;
import com.siperian.sif.client.SiperianServerException;
import com.siperian.sif.message.Field;
import com.siperian.sif.message.MatchType;
import com.siperian.sif.message.Record;
import com.siperian.sif.message.RecordKey;
import com.siperian.sif.message.RecordState;
import com.siperian.sif.message.SiperianObjectType;
import com.siperian.sif.message.TaskData;
import com.siperian.sif.message.TaskRecord;
import com.siperian.sif.message.mrm.CleansePutRequest;
import com.siperian.sif.message.mrm.CleansePutResponse;
import com.siperian.sif.message.mrm.CreateTaskRequest;
import com.siperian.sif.message.mrm.CreateTaskResponse;
import com.siperian.sif.message.mrm.GetRequest;
import com.siperian.sif.message.mrm.GetResponse;
import com.siperian.sif.message.mrm.MergeRequest;
import com.siperian.sif.message.mrm.MergeResponse;
import com.siperian.sif.message.mrm.MultiMergeRequest;
import com.siperian.sif.message.mrm.MultiMergeResponse;
import com.siperian.sif.message.mrm.PutRequest;
import com.siperian.sif.message.mrm.PutResponse;
import com.siperian.sif.message.mrm.SearchMatchRequest;
import com.siperian.sif.message.mrm.SearchMatchResponse;
import com.siperian.sif.message.mrm.SetRecordStateRequest;
import com.siperian.sif.message.mrm.SetRecordStateResponse;
import com.siperian.sif.message.mrm.TokenizeRequest;
import com.siperian.sif.message.mrm.TokenizeResponse;

import oracle.jdbc.OracleTypes;

@Component
@Scope("prototype")
public class AdobeUpsertPartyContactDAO extends ObjectPool {

	private static final Logger LOG = Logger.getLogger(AdobeUpsertPartyContactDAO.class.getName());

	Properties configProps = PropertyUtil.getPropertiesFromFile("configProp");
	int partyCount = 0;
	Date lastUpdateDate = null;
	String sipPopVal = null;
	boolean isEmailValExists = false;
	String commEmlVal = null;
	boolean mergeInd = false;
	boolean childMergeInd = false;
	boolean matchInd = false;
	String tgtRowidObj = null;
	
	StringBuilder warning = new StringBuilder();
	
	@Autowired
	private CommonUtil commonUtil;
	@Autowired
	private GetPartyDAO getPartyDAO;
	@Autowired
	private SearchContactDAO searchContactDAO;
	@Autowired
	private ProspectPartyDAO prospectPartyDAO;
	@Autowired
	SearchPartyDAO searchDao;
	@Autowired
	private TrilliumCleanserDAO trilliumCleanserDAO;
	@Autowired
	private TrilliumLookUpDAO trilliumLookUpDAO;
	@Resource(name = "m4mMessagesProp")
	private Properties messagesProp;
	@Autowired
	private TrilliumContactCleanserDAO trilcontactCleanserDAO;
	@Autowired
	private ValidatorUtil validatorUtil;
	@Autowired
	private UpsertPartyContactDAO upsertContactDAO;

	public MdmUpsertPartyResponse processUpsertContactRequest(MdmUpsertPartyRequest upsertPartyRequest)
			throws ServiceProcessingException {
		LOG.info("Executing processUpsertContactRequest()");
		MdmUpsertPartyResponse upsertPartyResponse = new MdmUpsertPartyResponse();

		String methodName = null;
		int sizeInputParty = upsertPartyRequest.getParty().size();
		for (int index = 0; index < sizeInputParty; index++) {
			try {
				// lastUpdateDate = Util.getCurrentTimeZone();
				PartyXrefType upsertParty = upsertPartyRequest.getParty().get(index);
				validatorUtil.validateMsgTrackingId(upsertParty, upsertPartyResponse,true);
				if (upsertPartyRequest.getUpsertStatus() != null
						&& (upsertPartyRequest.getUpsertStatus().getErrorCode() != null)) {
					methodName = configProps.getProperty(upsertPartyRequest.getUpsertStatus().getErrorCode() + "_API");
				}
				LOG.info("Executing method ");
				StatusType status = new StatusType();
				upsertPartyResponse.setUpsertStatus(status);
				
				
				String srcPkey = upsertParty.getXREF().get(0).getSRCPKEY();
				srcPkey = Constant.ADB_CNT_PREFIX+srcPkey;
				upsertParty.getXREF().remove(0);
				XREFType xrefType = new XREFType();
				xrefType.setSRCPKEY(srcPkey);
				xrefType.setSRCSYSTEM(Constant.SRC_SYSTEM_ADB);
				upsertParty.getXREF().add(xrefType);
				
				if(!CollectionUtils.isEmpty(upsertParty.getPartyPerson()) && upsertParty.getPartyPerson().size()>0){
					upsertParty.getPartyPerson().get(0).setSRCPKEY(srcPkey);
				}
				if(!CollectionUtils.isEmpty(upsertParty.getAddress()) && upsertParty.getAddress().size()>0){
					upsertParty.getAddress().get(0).setSRCPKEY(srcPkey);
				}
				if(!CollectionUtils.isEmpty(upsertParty.getCommunication()) && upsertParty.getCommunication().size()>0){
					for(int i = 0; i<upsertParty.getCommunication().size();i++){
						upsertParty.getCommunication().get(i).setSRCPKEY(srcPkey);
					}
				}
				processUpsertRequestForIndividualContact(methodName, upsertParty, upsertPartyResponse);
			} catch (ServiceProcessingException servexp) {
				LOG.error("Caught ServiceProcessingException in processUpsertContactRequest()", servexp);

			} catch (Exception exp) {
				LOG.error("Caught exception in processUpsertContactRequest()", exp);
				// exp.printStackTrace();
			}
		}
		upsertPartyResponse.setStatus(upsertPartyResponse.getStatus() == null ? "" : "\n");
		upsertPartyResponse.setStatus(
				upsertPartyResponse.getStatus() + "\n Processing completed for " + partyCount + " party(ies).");

		return upsertPartyResponse;
	}

	public void processUpsertRequestForIndividualContact(String methodName, PartyXrefType upsertParty,
			MdmUpsertPartyResponse upsertPartyResponse)
			throws ServiceProcessingException, SecurityException, ClassNotFoundException {

		LOG.info("Executing processUpsertRequestForIndividualParty()");

		String rowidObject = null;
		boolean retry = false;
		boolean execNext = false;

		if (null != methodName) {
			partyCount = 1;
			retry = true;
			execNext = true;
			try {
				LOG.info("Before reflection Method name : " + methodName.trim());
				Class<? extends AdobeUpsertPartyContactDAO> cls = this.getClass();
				LOG.info("Class : " + cls.toString());

				Method method = cls.getMethod(new String(methodName.trim()), new Class[] { PartyXrefType.class,
						MdmUpsertPartyResponse.class, boolean.class, boolean.class, String.class });
				LOG.info("After get Method : " + method.toString());
				Object[] args = new Object[5];
				args[0] = upsertParty;
				args[1] = upsertPartyResponse;
				args[2] = retry;
				args[3] = execNext;
				args[4] = rowidObject;
				LOG.info("Before invoke");
				method.invoke(this, args);
				LOG.info("After Invoke");
			} catch (NoSuchMethodException e) {
				LOG.error(e);
				throw new ServiceProcessingException(e);
			} catch (IllegalAccessException e) {
				LOG.error(e);
				throw new ServiceProcessingException(e);
			} catch (IllegalArgumentException e) {
				LOG.error(e);
				throw new ServiceProcessingException(e);
			} catch (InvocationTargetException e) {
				LOG.error(e);
				throw new ServiceProcessingException(e);
			}
		} else {
			retry = false;
			execNext = false;

			upsertDataValidation(upsertParty, upsertPartyResponse, false, false, rowidObject);

			upsertTrilliumProcessing(upsertParty, upsertPartyResponse, false, false, rowidObject);

			checkDataQualityUpsert(upsertParty, upsertPartyResponse, false, false, rowidObject);

			processCleansePutRequest(upsertParty, upsertPartyResponse, false, false, rowidObject);

			upsertTokenize(upsertParty, upsertPartyResponse, false, false, rowidObject);

			upsertMatchMergeProcess(upsertParty, upsertPartyResponse, false, false, rowidObject);

			upsertUCNStampProcess(upsertParty, upsertPartyResponse, false, false, rowidObject);

			processAcntCntctRel(upsertParty, upsertPartyResponse, false, false, rowidObject);

			upsertDataSyncProcess(upsertParty, upsertPartyResponse, false, false, rowidObject);

		}

		populateUpsertResponse(upsertParty, upsertPartyResponse);

		LOG.info("Executed processUpsertRequestForIndividualParty()");

	}

	public void upsertDataValidation(PartyXrefType upsertParty, MdmUpsertPartyResponse upsertPartyResponse,
			boolean excuteNextStep, boolean executeFromStart, String rowidObject) throws ServiceProcessingException {

		LOG.info("Executing upsertDataValidation()");

		// Check for Account Record Type
		try {

			if ((Util.isNullOrEmpty(upsertParty.getPARTYTYPE()))
					|| (!Constant.BO_CLASS_CODE_PERSON.equalsIgnoreCase(upsertParty.getPARTYTYPE()))) {

				LOG.info("Contact is not created since it's PARTY_TYPE is not in ('Person')");
				upsertPartyResponse
						.setStatus("Contact blocking successful for invalid PARTY_TYPE. Account with PARTY_TYPE = '"
								+ upsertParty.getPARTYTYPE() + "' not created in MDM");
				upsertPartyResponse
						.setErrorMsg("Contact blocking successful for invalid PARTY_TYPE. Contact with PARTY_TYPE = '"
								+ upsertParty.getPARTYTYPE() + "' not created in MDM");
				throw new ServiceProcessingException(Constant.ERROR_CONTACT_INVALID_PTY_TYP);
			}
			
			//Adobe Contact - Japanese records should not be processed - ODOM-2449
			//(MDMP-3355) Enable Japan contact in MDM from Adobe
			/*List<AddressXrefType> addressXrefTypeList = upsertParty.getAddress();
			if (!CollectionUtils.isEmpty(addressXrefTypeList)) {
				String countryCd = addressXrefTypeList.get(0).getCOUNTRYCD();
				if ("Japan".equalsIgnoreCase(countryCd) || "JPN".equalsIgnoreCase(countryCd)
						|| "JP".equalsIgnoreCase(countryCd)) {
					LOG.info("Contact is from Japan");
					upsertPartyResponse.setStatus("Contact is from Japan");
					upsertPartyResponse.setErrorMsg("Contact is from Japan");
					throw new ServiceProcessingException(Constant.ERROR_ACCOUNT_JP_COUNTRY_FAILED);
					
				}
			}*/
			
			String srcPkey = upsertParty.getXREF().get(0).getSRCPKEY();
			/*
			 * Checking if Email_Address from Communication is NULL OR NOT NULL
			 */
			List<CommunicationXrefType> commXrefTypeList = upsertParty.getCommunication();
			if (CollectionUtils.isEmpty(commXrefTypeList)) {
				validatorUtil.createUpsertInfoMessage(upsertPartyResponse, Constant.INFO_CONTACT_EMPTY_EMAIL_ADDR, srcPkey);
				upsertPartyResponse.setErrorCd(prospectPartyDAO.getErrorCodeByDescription(messagesProp
						.getProperty(Constant.INFO_CONTACT_EMPTY_EMAIL_ADDR)));
				throw new ServiceProcessingException(Constant.ERROR_CONTACT_EMPTY_EMAIL_ADDR);
			} else {
				Boolean isEmailValuePresent = Boolean.FALSE;
				for (CommunicationXrefType commXrefType : commXrefTypeList) {
					if ("Email".equalsIgnoreCase(commXrefType.getCOMMTYPE())) {
						if (!Util.isNullOrEmpty(commXrefType.getCOMMVALUE())) {
							isEmailValuePresent = Boolean.TRUE;
							break;
						}
					}
				}
				if (!isEmailValuePresent) {
					validatorUtil.createUpsertInfoMessage(upsertPartyResponse, Constant.INFO_CONTACT_EMPTY_EMAIL_ADDR, srcPkey);
					upsertPartyResponse.setErrorCd(prospectPartyDAO.getErrorCodeByDescription(messagesProp
							.getProperty(Constant.INFO_CONTACT_EMPTY_EMAIL_ADDR)));
					throw new ServiceProcessingException(Constant.ERROR_CONTACT_EMPTY_EMAIL_ADDR);
				}
			}

		} catch (ServiceProcessingException e) {
			LOG.error("Data validation check failed Due to Invalid Input: " + e.getMessage());
			if (Constant.ERROR_CONTACT_INVALID_PTY_TYP.equals(e.getMessage())) {
				commonUtil.updateErrorStatus(upsertParty, upsertPartyResponse, Constant.ERROR_CONTACT_INVALID_PTY_TYP,
						"0");
			} else if (Constant.ERROR_CONTACT_EMPTY_EMAIL_ADDR.equals(e.getMessage())) {
				commonUtil.updateErrorStatus(upsertParty, upsertPartyResponse, Constant.ERROR_CONTACT_EMPTY_EMAIL_ADDR,
						"0");
			}else if (Constant.ERROR_ACCOUNT_JP_COUNTRY_FAILED.equals(e.getMessage())) {
				commonUtil.updateErrorStatus(upsertParty, upsertPartyResponse, Constant.ERROR_ACCOUNT_JP_COUNTRY_FAILED,
						"0");
			} else {
				commonUtil.updateErrorStatus(upsertParty, upsertPartyResponse, Constant.ERROR_CONTACT_DATA_VALID_FAIL,
						"0");
			}
			throw new ServiceProcessingException(e);
		} catch (Exception excp) {
			LOG.error("Data validation check failed: " + excp.getMessage());

			upsertPartyResponse.setErrorMsg("Data validation check failed Due to Error: " + excp.getMessage());

			commonUtil.updateErrorStatus(upsertParty, upsertPartyResponse, Constant.ERROR_CONTACT_DATA_VALID_FAIL, "0");
			throw new ServiceProcessingException(Constant.ERROR_CONTACT_DATA_VALID_FAIL);
		}

		// Execute next step in upsert flow
		String rowidObj = null;
		if (excuteNextStep)
			upsertTrilliumProcessing(upsertParty, upsertPartyResponse, true, true, rowidObj);

		LOG.info("Executed upsertDataValidation()");
		return;
	}


	public void upsertTrilliumProcessing(PartyXrefType curParty, MdmUpsertPartyResponse upsertPartyResponse,
			boolean excuteNextStep, boolean executeFromStart, String rowidObject) throws ServiceProcessingException {
		LOG.info("Executing upsertTrilliumProcessing()");

		// Execute next step in upsert flow
		String rowidObj = null;
		boolean isInTrilliumList = false;
		boolean setTrilliumValue = false;
		PerformanceLoggerUtil perfLog = new PerformanceLoggerUtil();
		String companyName ="";
		try{
			
		companyName = curParty.getPartyPerson().get(0).getREPORTEDCOMPANYNAME();
		LOG.info("getREPORTEDCOMPANYNAME::"+companyName);
		trilcontactCleanserDAO.trilliumContactCleanser(curParty);
		
		isInTrilliumList = trilliumLookUpDAO.checkInTrilliumCountryProjectMapForProspect(curParty,Constant.SRC_SYSTEM_ADB);
		LOG.debug("isInTrilliumList::" + isInTrilliumList);
		
		// Convert from ADB to Trillium format
		trilliumLookUpDAO.convertToTrilliumUpsert(curParty,isInTrilliumList,Constant.SRC_SYSTEM_ADB);
		
		if (isInTrilliumList) {
			// Trillium Cleansing for Contact Physical Address
			
			setTrilliumValue = trilliumCleanserDAO.callTrilliumCleanser(curParty, Boolean.TRUE);
			perfLog.printLog(Constant.PERF_LOG_FLOW_UPSERT_ADB_CONTACT,curParty.getXREF().get(0).getSRCPKEY(), "STEP 1", "Trillium Call done");
			LOG.debug("setTrilliumValue -->" + setTrilliumValue);
			
			// After Trillium LookUP Process
			trilliumLookUpDAO.convertTrilliumToSRCStateProspect(
					setTrilliumValue, curParty, curParty.getXREF()
							.get(0).getSRCSYSTEM());
		} else {
			perfLog.printLog(Constant.PERF_LOG_FLOW_UPSERT_ADB_CONTACT, 
					curParty.getXREF().get(0).getSRCPKEY(), "STEP 1", "Trillium Call done");
		}
		
		perfLog.printLog(Constant.PERF_LOG_FLOW_UPSERT_ADB_CONTACT, curParty.getXREF().get(0).getSRCPKEY()
				, "STEP 2", "Transformation after trillium call to source state and country value");
		
		}catch(Exception excp){
			LOG.error("Trillim cleanse failed: ", excp);
			upsertPartyResponse = new MdmUpsertPartyResponse();
			upsertPartyResponse.setErrorMsg("Trillim cleanse failed: "+ excp.getMessage());

			PartyUpsertRespType partyResp = new PartyUpsertRespType();
			partyResp.setROWIDOBJECT("0");
			upsertPartyResponse.getParty().add(partyResp);
			try {
				trilliumLookUpDAO.convertToTrilliumUpsert(curParty,Boolean.FALSE,Constant.SRC_SYSTEM_ADB);
			} catch (Exception e) {
				LOG.error("convertToTrilliumUpsert failed after Trillim cleanse failure:: ",e);
			}
		}
		LOG.info("companyName::"+companyName);
		curParty.getPartyPerson().get(0).setREPORTEDCOMPANYNAME(companyName);
		if (excuteNextStep)
			checkDataQualityUpsert(curParty, upsertPartyResponse, true, true, rowidObj);

		LOG.info("Executed upsertTrilliumProcessing()");
		return;
	}

	public void checkDataQualityUpsert(PartyXrefType upsertParty, MdmUpsertPartyResponse upsertPartyResponse,
			boolean retry, boolean executeNextStep, String rowidObject) throws ServiceProcessingException {

		LOG.info("Executing checkDataQualityUpsert()");
		String emailValueFrmPayload = null;
		List<String> commPkeyEmlList = null;
		String commPkeyAppndEml = null;
		String existingPkey = null;
		String existingEmail = null;
		boolean isEmailProcssd = false;
		if(!validatorUtil.validateCompanyName(upsertParty, upsertPartyResponse))	{
			//REPORTED_COMPANY_NAME is NOT VALID NAME OR INVALID
			LOG.debug(
					"Contact record does not have Valid REPORTED_COMPANY_NAME, hence bypassing Contact insertion: "
							+ upsertParty.getXREF().get(0).getSRCPKEY());
			upsertPartyResponse.setErrorMsg("CONTACT_NAME is UNKNOWN OR Junk Value. Request is not processed");
			upsertPartyResponse.setErrorCd(prospectPartyDAO.getErrorCodeByDescription(messagesProp
					.getProperty(Constant.INFO_CONTACT_NAME_UNKWN)));
			commonUtil.updateErrorStatus(upsertParty, upsertPartyResponse, Constant.ERROR_CONTACT_NAME_UNKWN,"0");
			throw new ServiceProcessingException(upsertPartyResponse.getStatus());
		}
		String srcPkey = upsertParty.getXREF().get(0).getSRCPKEY();
		/*Checking	IF (FIRSTNAME is NOT NULL OR LASTNAME is NOT NULL) AND (REPORTED_COMPANY_NAME is NOT NULL)	*/
		LOG.debug("[checkDataQualityUpsert] check for fname, lname, reptComname Null or Unknown");
		if (upsertParty.getPartyPerson() != null) {
			String fName = upsertParty.getPartyPerson().get(0).getFIRSTNAME();
			String lName = upsertParty.getPartyPerson().get(0).getLASTNAME();
			String reptdCompName = upsertParty.getPartyPerson().get(0).getREPORTEDCOMPANYNAME();
			if (Util.isNullOrEmpty(fName) && Util.isNullOrEmpty(lName)) {
				validatorUtil.createUpsertInfoMessage(upsertPartyResponse, Constant.INFO_CONTACT_EMPTY_FNAME_LNAME, srcPkey);
				upsertPartyResponse.setErrorCd(prospectPartyDAO.getErrorCodeByDescription(messagesProp
						.getProperty(Constant.INFO_CONTACT_EMPTY_FNAME_LNAME)));
				commonUtil.updateErrorStatus(upsertParty, upsertPartyResponse, Constant.ERROR_CONTACT_EMPTY_FNAME_LANME, "0");
				throw new ServiceProcessingException(Constant.ERROR_CONTACT_EMPTY_FNAME_LANME);
			}else if(Util.isNullOrEmpty(reptdCompName)){
				validatorUtil.createUpsertInfoMessage(upsertPartyResponse, Constant.INFO_CONTACT_EMPTY_REPTD_COMP_NAME, srcPkey);
				upsertPartyResponse.setErrorCd(prospectPartyDAO.getErrorCodeByDescription(messagesProp
						.getProperty(Constant.INFO_CONTACT_EMPTY_REPTD_COMP_NAME)));
				commonUtil.updateErrorStatus(upsertParty, upsertPartyResponse, Constant.ERROR_CONTACT_NAME_UNKWN, "0");
				throw new ServiceProcessingException(Constant.ERROR_CONTACT_NAME_UNKWN);
			}
		} else {
			validatorUtil.createUpsertInfoMessage(upsertPartyResponse, Constant.INFO_CONTACT_EMPTY_REPTD_COMP_NAME, srcPkey);
			upsertPartyResponse.setErrorCd(prospectPartyDAO.getErrorCodeByDescription(messagesProp
					.getProperty(Constant.INFO_CONTACT_EMPTY_REPTD_COMP_NAME)));
			throw new ServiceProcessingException(Constant.INFO_CONTACT_EMPTY_REPTD_COMP_NAME);
		}
		LOG.debug("[checkDataQualityUpsert] check for Contact Address for Null or Unknown");
		if (!validatorUtil.validateAccountAddressNullUnknown(upsertParty, upsertPartyResponse, "Addressline1")) {
			// REPORTED ADDRESS OR CITY HAVE null or unknown
			LOG.debug("Adobe Contact record have NULL or Unknown addressline1"
					+ upsertParty.getXREF().get(0).getSRCPKEY());
			upsertPartyResponse
			.setErrorCd(prospectPartyDAO.getErrorCodeByDescription(messagesProp
					.getProperty(Constant.INFO_ADDRESS_UNKNOWN_JUNK)));
			upsertPartyResponse.setErrorMsg("Address is blank or Unknown or Junk Value");
			commonUtil.updateErrorStatus(upsertParty, upsertPartyResponse, Constant.ERROR_CONTACT_ADDR_LN1_UNKWN, "0");
			throw new ServiceProcessingException(upsertPartyResponse.getStatus());
		}
		// check for Contact Address(City) for Empty, Null or Unknown
		LOG.debug("[checkDataQualityUpsert] check for Contact City for Null or Unknown");
		if (!validatorUtil.validateAccountAddressNullUnknown(upsertParty, upsertPartyResponse, "City")) {
			// REPORTED CITY HAVE null or unknown
			LOG.debug("Adobe Account record have NULL or Unknown City " + upsertParty.getXREF().get(0).getSRCPKEY());
			upsertPartyResponse.setErrorMsg("City is blank or Unknown or Junk Value");
			upsertPartyResponse
			.setErrorCd(prospectPartyDAO.getErrorCodeByDescription(messagesProp
					.getProperty(Constant.INFO_ADDRESS_UNKNOWN_JUNK)));
			commonUtil.updateErrorStatus(upsertParty, upsertPartyResponse, Constant.ERROR_CONTACT_CITY_UNKWN, "0");
			throw new ServiceProcessingException(upsertPartyResponse.getStatus());
		}
		// check for Account Address(Country) for Empty, Null or Unknown
		LOG.debug("[checkDataQualityUpsert] check for Address Country for Null or Unknown");
		if (!validatorUtil.validateAccountAddressNullUnknown(upsertParty, upsertPartyResponse, "Country")) {
			// REPORTED CITY HAVE null or unknown
			LOG.debug("Adobe contact record have NULL or Unknown Country" + upsertParty.getXREF().get(0).getSRCPKEY());
			upsertPartyResponse.setErrorMsg("Country is blank or Unknown or Junk Value");
			upsertPartyResponse
			.setErrorCd(prospectPartyDAO.getErrorCodeByDescription(messagesProp
					.getProperty(Constant.INFO_ADDRESS_UNKNOWN_JUNK)));
			commonUtil.updateErrorStatus(upsertParty, upsertPartyResponse, Constant.ERROR_CONTACT_EMPTY_COUNTRY, "0");
			throw new ServiceProcessingException(upsertPartyResponse.getStatus());
		}
		LOG.debug("[checkDataQualityUpsert] check for Contact Address for Junk");
		// check for Contact Address for Junk and reject the account request
		if (!validatorUtil.validateAccountAddressJunk(upsertParty, upsertPartyResponse)) {
			LOG.debug("Adobe Contact record have AddressLn1 or city junk ::Rejecting"
					+ upsertParty.getXREF().get(0).getSRCPKEY());
			upsertPartyResponse.setErrorMsg("AddressLn1 or city has Junk Value");
			upsertPartyResponse
			.setErrorCd(prospectPartyDAO.getErrorCodeByDescription(messagesProp
					.getProperty(Constant.INFO_ADDRESS_UNKNOWN_JUNK)));
			commonUtil.updateErrorStatus(upsertParty, upsertPartyResponse, Constant.ERROR_CONTACT_ADDR_INVALID, "0");
			throw new ServiceProcessingException(upsertPartyResponse.getStatus());

		}
		for (CommunicationXrefType commXrefType : upsertParty.getCommunication()) {
			if (commXrefType.getCOMMTYPE().equalsIgnoreCase("Email")) {
				LOG.info("Email value exists");
				emailValueFrmPayload = commXrefType.getCOMMVALUE();
			}
		}
		/*
		 * Validate to see IF same CONTACT_PKEY contains
		 * same EMAIL_ADDRESS or not
		 */
		/* Fetch Existing Email ID & CONTACT_ID */
		commPkeyEmlList = prospectPartyDAO
				.getContactEmailByContactPkey(upsertParty.getXREF().get(0).getSRCPKEY());
		if (!commPkeyEmlList.isEmpty()) {
			commPkeyAppndEml = commPkeyEmlList.get(0);
			LOG.debug("[getContactEmailByContactPkey] Contact Pkey Value is::" + commPkeyAppndEml);
			String tmpArr[] = commPkeyAppndEml.split("\\|");
			// Contact Pkey from MDM DB
			existingPkey = tmpArr[0];
			// Contact Email ID from MDM DB
			existingEmail = tmpArr[1];
			LOG.debug("Existing Contact PKEY_SRC_OBJECT-->" + existingPkey
					+ " Existing Email Value is-->" + existingEmail);
		}
		if (Util.isNullOrEmpty(existingPkey)) {
			/* Creating New Contact Record */
			LOG.debug("Creating New Contact Record");
		} else {
			if ((Util.isNullOrEmpty(existingEmail) || "null".equalsIgnoreCase(existingEmail))
					&& emailValueFrmPayload != null) {
				LOG.debug("existingEmail: " + existingEmail);
				LOG.debug("Incoming emailValueFrmPayload: " + emailValueFrmPayload);
				isEmailProcssd = true;
				/*
				 * Update Existing NULL Email id with Non-NULL Incoming Email value
				 */
				LOG.debug("Update Existing NULL Email id with Non-NULL Incoming Email value");
			}

			if (!Util.isNullOrEmpty(existingEmail)) {
				if (existingEmail.equalsIgnoreCase(emailValueFrmPayload)) {
					/* Updating Existing Contact Record */
					LOG.debug("Updating Existing Contact Record");
				} else if (!isEmailProcssd) {
					LOG.debug("Incoming Email value->" + emailValueFrmPayload
							+ " is different from Existing Email value->" + existingEmail
							+ ",hence bypassing Contact Update.");
					upsertPartyResponse.setStatus("Incoming Email value->" + emailValueFrmPayload
							+ " is different from Existing Email value->" + existingEmail
							+ ",hence bypassing Contact Update.");
					throw new ServiceProcessingException(upsertPartyResponse.getStatus());
				}
			} else {
				LOG.debug(
						"No Existing Email Address for Existing Contact record ->" + existingPkey);
			}
		}
		LOG.info("Executed checkDataQualityUpsert()");
		if (executeNextStep)
			processCleansePutRequest(upsertParty, upsertPartyResponse, retry, executeNextStep, rowidObject);
	}
	
	
	
	
	/**
	 * The method process cleansePut SIF requests for entire Party profile
	 * (Party and child entities) in the request. It handles transaction as per
	 * business need. After successful put calls, it stores the created
	 * rowid_object of the entities into respective response object
	 *
	 * @param UpsertPartyRequest
	 *            The web service request object
	 * @param UpsertPartyResponse
	 *            response object for web service
	 * @return Map<String, Object> a collection of entity-wise cleansePut
	 *         response values clubbed in PutResponseDataHolder object
	 * @throws ServiceProcessingException
	 */
	public void processCleansePutRequest(PartyXrefType upsertParty, MdmUpsertPartyResponse upsertResponse,
			boolean retry, boolean executeNextStpe, String rowidObject) throws ServiceProcessingException {

		LOG.info("Executing processCleansePutRequest()");
		
		SiperianClient siperianClient = null;
		UserTransaction transaction = null;

		PartyXrefType partyParam = upsertParty;
		PutResponseDataHolder putRespDataParty = null;
	//	List<PutResponseDataHolder> putRespDataProspectList = null;
		List<PutResponseDataHolder> putRespDataAddressList = null;
		List<PutResponseDataHolder> putRespDataCommunicationList = null;
		List<PutResponseDataHolder> putRespDataPartyPrsnList = null;
		Map<String, Object>  putRespDataHolderMap = new HashMap<String, Object>();

		try {
			siperianClient = (SiperianClient) checkOut();

			// create transaction - commit if cleansePut requests succeed for
			// Party and all the child entities
			transaction = ((EjbSiperianClient) siperianClient).createTX(300000);
			transaction.begin();

			lastUpdateDate = Util.getCurrentTimeZone();

			
			//getSipPop
			List<AddressXrefType> addressList = partyParam.getAddress();
			if (!CollectionUtils.isEmpty(addressList)) {
			getSipPop(addressList);
			}
			// Create Party
			putRespDataParty = cleansePutParty(partyParam, siperianClient);
			// Create Party Person
			List<PartyPersonXrefType> partyPersonXrefTypeList = partyParam.getPartyPerson();
			if (!CollectionUtils.isEmpty(partyPersonXrefTypeList)) {
				putRespDataPartyPrsnList = cleansePutPerson(partyPersonXrefTypeList, partyParam, siperianClient);
			}

			/*// Create Prospect
			List<AccountXrefType> prospectXrefTypeList = partyParam.getAccount();
			if (!CollectionUtils.isEmpty(prospectXrefTypeList)) {
				putRespDataProspectList = cleansePutProspect(prospectXrefTypeList, partyParam, siperianClient);
			}*/

			// Create Address
			if ((!Util.isNullOrEmpty(partyParam.getAddress().get(0).getADDRLN1()))) {
			List<AddressXrefType> addressXrefTypeList = partyParam.getAddress();
			if (!CollectionUtils.isEmpty(addressXrefTypeList)) {
				putRespDataAddressList = cleansePutAddress(addressXrefTypeList, partyParam, siperianClient);
			}
			}
			// Create Communication
			List<CommunicationXrefType> commXrefTypeList = partyParam.getCommunication();
			if (!CollectionUtils.isEmpty(commXrefTypeList)) {
				putRespDataCommunicationList = cleansePutCommunication(commXrefTypeList, partyParam, siperianClient);
			}

			

			LOG.info("Control back in processCleansePut().");

			// commit transaction
			transaction.commit();
			LOG.info("Transaction Commited in processCleansePut().");
			partyCount++;

			// set response status
			upsertResponse.setStatus(Util.isNullOrEmpty(upsertResponse.getStatus())? 
					"" : upsertResponse.getStatus() + "\n");
			upsertResponse.setStatus(upsertResponse.getStatus() + putRespDataParty.getActionType()
					+ " operation successful for Party " + putRespDataParty.getSourceKey().replaceAll(Constant.ADB_CNT_PREFIX, Constant.STR_BLANK));

		} catch (ServiceProcessingException excp) {
			boolean isDataError = commonUtil.fetchErrorMsg(excp.getRootExceptionMsg());
			upsertResponse.setErrorMsg(excp.getRootExceptionMsg());
			upsertParty.setErrorMsg("CleansePut operation failed");
			if(isDataError){
				commonUtil.updateErrorStatus(upsertParty, upsertResponse, Constant.ERROR_LOV_LOOKUP_FAILED, "0");
			}else{
				commonUtil.updateErrorStatus(upsertParty, upsertResponse, Constant.ERROR_ACC_EXT_ACC_PUT_FAIL, "0");	
			}
			LOG.error("Exception occured while preparing/processing cleansePut requests: ", excp);
			try {
				transaction.rollback();

			} catch (SystemException txExcp) {
				LOG.error("Failed to rollback transaction for cleansePut requests : " + txExcp.toString());
			}
			throw excp;
		} catch (Exception ex) {
			upsertResponse.setErrorMsg("CleansePut operation failed for Party " + putRespDataParty.getSourceKey());
			upsertParty.setErrorMsg("CleansePut operation failed");
			commonUtil.updateErrorStatus(upsertParty, upsertResponse, Constant.ERROR_CONTACT_CLEANSE_PUT_FAIL, "0");
			LOG.error("Exception occured while preparing/processing cleansePut requests: ", ex);
			ex.printStackTrace();
			try {
				transaction.rollback();
			} catch (SystemException txExcp) {
				LOG.error("Failed to rollback transaction for cleansePut requests : " + txExcp.toString());
				txExcp.printStackTrace();
			}
			ServiceProcessingException customException = new ServiceProcessingException(ex);
			customException.setMessage("Failed to process cleansePut SIF request." + customException.getMessage());
			throw customException;
		} finally {
			checkIn(siperianClient);
		}
		try {
			// set rowid_object of created records into response and
			// set the PutResponseDataHolder object/list of object into Map
			// against corresponding entity name
			// set rowid_object of Party into response
			PartyUpsertRespType partyUpsertResp = new PartyUpsertRespType();
			List<Address> addressList = new ArrayList<Address>();
			List<Communication> commList = new ArrayList<Communication>();
			List<PartyPerson> partyPersonList = new ArrayList<PartyPerson>();

			// set rowid_object of Party into response
			if (putRespDataParty != null) {
				partyUpsertResp.setROWIDOBJECT(putRespDataParty.getRowidObject());
				partyUpsertResp.setSRCSYSTEM(putRespDataParty.getSystemName());
				partyUpsertResp.setSRCSYSTEMID(putRespDataParty.getSourceKey().replaceAll(Constant.ADB_CNT_PREFIX, ""));
				putRespDataHolderMap.put(MDMAttributeNames.ENTITY_PARTY, putRespDataParty);
			}

			/*// set rowid_object of Prospect into response
			if (!CollectionUtils.isEmpty(putRespDataProspectList)) {
				putRespDataHolderMap.put(MDMAttributeNames.ENTITY_PROSPECT, putRespDataProspectList);
				for (PutResponseDataHolder putRespDataProspect : putRespDataProspectList) {
					Account prospect = new Account();
					prospect.setROWIDACCOUNT(putRespDataProspect.getRowidObject());
					prospect.setSRCSYSTEM(putRespDataProspect.getSystemName());
					prospect.setSRCSYSTEMID(putRespDataProspect.getSourceKey());
					prospectList.add(prospect);
				}
			}*/

			// set rowid_object of Address into response
			if (!CollectionUtils.isEmpty(putRespDataAddressList)) {
				putRespDataHolderMap.put(MDMAttributeNames.ENTITY_ADDRESS, putRespDataAddressList);
				for (PutResponseDataHolder putRespDataAddress : putRespDataAddressList) {
					Address address = new Address();
					address.setROWIDADDRESS(putRespDataAddress.getRowidObject());
					address.setSRCSYSTEM(putRespDataAddress.getSystemName());
					address.setSRCSYSTEMID(putRespDataAddress.getSourceKey().replaceAll(Constant.ADB_CNT_PREFIX, ""));
					addressList.add(address);
				}
			}

			// set rowid_object of Communication into response
			if (!CollectionUtils.isEmpty(putRespDataCommunicationList)) {
				putRespDataHolderMap.put(MDMAttributeNames.ENTITY_COMM, putRespDataCommunicationList);
				for (PutResponseDataHolder putRespDataCommunication : putRespDataCommunicationList) {
					Communication comm = new Communication();
					comm.setROWIDCOMMUNICATION(putRespDataCommunication.getRowidObject());
					comm.setSRCSYSTEM(putRespDataCommunication.getSystemName());
					comm.setSRCSYSTEMID(putRespDataCommunication.getSourceKey().replaceAll(Constant.ADB_CNT_PREFIX, ""));
					commList.add(comm);
				}
			}
			// set rowid_object of Person into response
			if (!CollectionUtils.isEmpty(putRespDataPartyPrsnList)) {
				putRespDataHolderMap.put(MDMAttributeNames.ENTITY_PARTY_PRSN, putRespDataPartyPrsnList);
				for (PutResponseDataHolder putRespDataPartyPrsn : putRespDataPartyPrsnList) {
					PartyPerson partyPerson = new PartyPerson();
					partyPerson.setROWIDPERSON(putRespDataPartyPrsn.getRowidObject());
					partyPerson.setSRCSYSTEM(putRespDataPartyPrsn.getSystemName());
					partyPerson.setSRCSYSTEMID(putRespDataPartyPrsn.getSourceKey().replaceAll(Constant.ADB_CNT_PREFIX, ""));
					partyPersonList.add(partyPerson);
				}
			}
			partyUpsertResp.getAddress().addAll(addressList);
			partyUpsertResp.getCommunication().addAll(commList);
			partyUpsertResp.getPartyPerson().addAll(partyPersonList);
			upsertResponse.getParty().add(partyUpsertResp);
		} catch (Exception excp) {
			LOG.error("Exception occured while processing CleansePut response for Party "
					+ putRespDataParty.getSourceKey().replaceAll(Constant.ADB_CNT_PREFIX, ""), excp);
			ServiceProcessingException customException = new ServiceProcessingException(excp);
			customException.setMessage("Exception occured while processing CleansePut response for Party. "
					+ customException.getMessage());
		}
		
		if (executeNextStpe)
			upsertTokenize(upsertParty, upsertResponse, true, true, rowidObject);

		LOG.info("Executed processCleansePutRequest()");
		return;
	}
	
	private void getSipPop(List<AddressXrefType> addressList) {
		LOG.info("Executing getSipPop()");
		int itemIndex = 0;

		AddressXrefType addressParam = null;

		try {
			for (itemIndex = 0; itemIndex < addressList.size(); itemIndex++) {
				addressParam = addressList.get(itemIndex);

				LOG.debug("addressParam.getCOUNTRYCD(): " + addressParam.getCOUNTRYCD());
				if (!Util.isNullOrEmpty(addressParam.getCOUNTRYCD()) && Util.isNullOrEmpty(sipPopVal)) {
					sipPopVal = addressParam.getCOUNTRYCD();
					if ((!Util.isNullOrEmpty(sipPopVal)) && (!(sipPopVal.length() > 2))) {
						sipPopVal = getADBCountryName(sipPopVal);
					}
				}
				LOG.debug("SIP_POP = " + sipPopVal);
			}
		} catch (Exception excp) {
			LOG.error("Exception occured while processing getSipPop for Address: " + excp);
			excp.printStackTrace();

		}

		LOG.info("Executed getSipPop()");
	}
	
	public String getADBCountryName(String countrycd) {
		LOG.debug("Inside getADBCountryName()");
		PreparedStatement statement = null;
		Connection jdbcConn = null;
		ResultSet resultSet = null;
		String countryName = null;
		JDBCConnectionProvider jDBCConnectionProvider = null;
		try {
			jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
			jdbcConn = jDBCConnectionProvider.getJdbcConnectionFromDS();
			LOG.info("getADBCountryName  countrycode : " + countrycd);
			StringBuilder sql = new StringBuilder();
			sql.append("select ADB_COUNTRY_NM from MDM_COUNTRY where ADB_COUNTRY_CD= ?");
			LOG.debug("SQL Generated is : " + sql.toString());
			statement = jdbcConn.prepareStatement(sql.toString());
			statement.setString(1, countrycd);
			resultSet = statement.executeQuery();
			if (resultSet.next()) {
				countryName = resultSet.getString(1);
			}
			LOG.debug("countryName value is: " + countryName);
		} catch (Exception exp) {
			exp.printStackTrace();
		} finally {
			try {
				if (resultSet != null)
					resultSet.close();
				if (statement != null)
					statement.close();
				if (jdbcConn != null)
					jdbcConn.close();
			} catch (SQLException exp) {
				LOG.error("Caught SQLException in getFNOCountryCName().");
			}

		}
		return countryName;
	}
	
	/**
	 * The method prepares and executes CleansePutRequest on PARTY landing table
	 * for the given Party profile.
	 *
	 * @param partyParam
	 *            Party profile provided to the web service request
	 * @param siperianClient
	 *            SiperianClient SIF connection to MDM Hub
	 * @return PutResponseDataHolder object containing processing results
	 * @throws ServiceProcessingException
	 */
	private PutResponseDataHolder cleansePutParty(PartyXrefType partyParam, SiperianClient siperianClient) throws ServiceProcessingException {
		LOG.info("Executing cleansePutParty()");
		int itemIndex = 0;
		CleansePutRequest cleansePutRequest = new CleansePutRequest();
		CleansePutResponse cleansePutResponse = null;
		PutResponseDataHolder responseDataHolder = null;
		try {
		
			// prepare CleansePutRequest
			Record record = new Record();
			// set mapping name
			record.setSiperianObjectUid(Util.getMappingObjectUid(partyParam.getXREF().get(itemIndex).getSRCSYSTEM(), MDMAttributeNames.ENTITY_PARTY));
			// set input values
			if (partyParam.getLASTUPDATEDATE() != null && partyParam.getLASTUPDATEDATE().length() > 0) {
				record.setField(new Field(MDMAttributeNames.LAST_UPDATE_DATE, partyParam.getLASTUPDATEDATE()));
			} else {
				LOG.info("Performing cleansePutParty with sysdate from HUB: " + lastUpdateDate);
				record.setField(new Field(MDMAttributeNames.LAST_UPDATE_DATE, lastUpdateDate));
			}
			
			if (partyParam.getSRCCREATEDT() != null && partyParam.getSRCCREATEDT().length() > 0) {
				record.setField(new Field(MDMAttributeNames.SRC_CREATE_DT, partyParam.getSRCCREATEDT()));
			}else{
				record.setField(new Field(MDMAttributeNames.SRC_CREATE_DT, lastUpdateDate));
			}
			record.setField(new Field(MDMAttributeNames.SRC_UPDT_BY, partyParam.getUPDATEBY()));
			record.setField(new Field(MDMAttributeNames.SRC_SYSTEM, (partyParam.getXREF().get(itemIndex)).getSRCSYSTEM()));
			record.setField(new Field(MDMAttributeNames.SRC_SYS_KEY, (partyParam.getXREF().get(itemIndex)).getSRCPKEY()));
			if (!Util.isNullOrEmpty(partyParam.getROWIDOBJECT())) {
				record.setField(new Field(MDMAttributeNames.ROWID_OBJECT, partyParam.getROWIDOBJECT()));
			}
			record.setField(new Field(PartyAttributes.ENTITY_TYPE, partyParam.getBOCLASSCODE()));
			record.setField(new Field(PartyAttributes.PARTY_NAME, partyParam.getPARTYNAME()));
			record.setField(new Field(PartyAttributes.PARTY_TYPE, partyParam.getPARTYTYPE()));
			record.setField(new Field(PartyAttributes.GEO, partyParam.getGEO()));
			record.setField(new Field(PartyAttributes.REGION, partyParam.getREGION()));
			record.setField(new Field(PartyAttributes.SALES_BLOCK_CD, partyParam.getSALESBLOCKCD()));
			record.setField(new Field(PartyAttributes.TAX_JURSDCTN_CD, partyParam.getTAXJURSDCTNCD()));
			record.setField(new Field(PartyAttributes.VAT_REG_NBR, partyParam.getVATREGNBR()));
			record.setField(new Field(PartyAttributes.STATUS_CD, partyParam.getSTATUSCD()));

			if(!Util.isNullOrEmpty(partyParam.getUCN()))	{
				record.setField(new Field(PartyAttributes.UCN, partyParam.getUCN()));
			}
			if(!Util.isNullOrEmpty(sipPopVal))	{
			record.setField(new Field(PartyAttributes.COUNTRY_CD, sipPopVal));
			}
			record.setField(new Field(PartyAttributes.ENGLISH_NAME, partyParam.getENGLISHNAME()));
			record.setField(new Field(PartyAttributes.MSG_TRKN_ID, partyParam.getMSGTRKNID()));
			
			cleansePutRequest.setRecord(record);
			// execute Put request
			cleansePutResponse = (CleansePutResponse) siperianClient.process(cleansePutRequest);
			LOG.info("Party cleansePut request processed successfully: " + cleansePutResponse.getMessage());
			// extract result
			RecordKey recordKey = cleansePutResponse.getRecordKey();

			responseDataHolder = new PutResponseDataHolder();
			responseDataHolder.setActionType(cleansePutResponse.getActionType());
			responseDataHolder.setActionMessage(cleansePutResponse.getMessage());
			responseDataHolder.setRowidObject(recordKey.getRowid());
			responseDataHolder.setRowidXREF(recordKey.getRowidXref());
			responseDataHolder.setSourceKey(recordKey.getSourceKey());
			responseDataHolder.setSystemName(recordKey.getSystemName());
			LOG.info("ROWID_OBJECT of created Party record = " + recordKey.getRowid());

			LOG.debug("Action Type = " + responseDataHolder.getActionType());
			LOG.debug("Action Msg = " + responseDataHolder.getActionMessage());
			LOG.debug("Rowid_xref = " + responseDataHolder.getRowidXREF());
			LOG.debug("Src key = " + responseDataHolder.getSourceKey());
			LOG.debug("System = " + responseDataHolder.getSystemName());

		} catch (SiperianServerException sifExcp) {
			LOG.error("SiperianServerException occured while processing CleansePutRequest for Party: ", sifExcp);
			LOG.error("Get Message: " + sifExcp.getMessage());
			LOG.error("sifExcp msg " + sifExcp);
			sifExcp.printStackTrace();
			ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
			customException.setRootExceptionMsg(sifExcp + " CleansePut operation failed for Party " + (partyParam.getXREF().get(itemIndex)).getSRCPKEY());
			customException.setMessage("SIF exception occured while processing Put request for Party." + customException.getMessage());
			throw customException;
		} catch (Exception excp) {
			LOG.error("Exception occured while processing CleansePutRequest for Party: ", excp);
			LOG.error("excp msg " + excp);
			ServiceProcessingException customException = new ServiceProcessingException(excp);
			customException.setMessage("Exception occured while processing Put request for Party." + customException.getMessage());
			customException.setRootExceptionMsg(excp + " CleansePut operation failed for Party " + (partyParam.getXREF().get(itemIndex)).getSRCPKEY());
			throw customException;
		}

		LOG.info("Executed cleansePutParty()");
		return responseDataHolder;
	}
	/**
	 * The method prepares and executes CleansePutRequest on PERSON
	 * landing table for the given Communication profiles.
	 *
	 * @param personList
	 *            List of Person provided to the web service request
	 * @param partyParam
	 *            Party profile provided to the web service request
	 * @param siperianClient
	 *            SiperianClient SIF connection to MDM Hub
	 * @return List of PutResponseDataHolder object containing processing
	 *         results
	 * @throws ServiceProcessingException
	 */
	private List<PutResponseDataHolder> cleansePutPerson(List<PartyPersonXrefType> personList, PartyXrefType partyParam,
			SiperianClient siperianClient) throws ServiceProcessingException {
		LOG.info("Executing cleansePutPerson()");
		CleansePutRequest cleansePutRequest = null;
		CleansePutResponse cleansePutResponse = null;
		List<PutResponseDataHolder> responseDataHolderList = new ArrayList<PutResponseDataHolder>(personList.size());
		for (PartyPersonXrefType personParam : personList) {
			try {
				cleansePutRequest = new CleansePutRequest();
				// prepare CleansePutRequest
				Record record = new Record();
				// set mapping name
				record.setSiperianObjectUid(
						Util.getMappingObjectUid(personParam.getSRCSYSTEM(), MDMAttributeNames.ENTITY_PARTY_PRSN));
				// set input values
				if (partyParam.getLASTUPDATEDATE() != null && partyParam.getLASTUPDATEDATE().length() > 0) {
					record.setField(new Field(MDMAttributeNames.LAST_UPDATE_DATE, partyParam.getLASTUPDATEDATE()));
				} else {
					LOG.info("Performing cleansePutPerson with sysdate from HUB: " + lastUpdateDate);
					record.setField(new Field(MDMAttributeNames.LAST_UPDATE_DATE, lastUpdateDate));
				}
				record.setField(new Field(PartyPersonAttributes.REPTD_COMP_NAME, personParam.getREPORTEDCOMPANYNAME()));
				record.setField(new Field(PartyPersonAttributes.SRC_UPD_BY, personParam.getUPDATEBY()));
				record.setField(new Field(MDMAttributeNames.SRC_SYSTEM, personParam.getSRCSYSTEM()));
				record.setField(new Field(MDMAttributeNames.SRC_SYS_KEY, personParam.getSRCPKEY()));

				record.setField(new Field(PartyPersonAttributes.PREFIX, personParam.getPREFIX()));

				record.setField(new Field(PartyPersonAttributes.FIRST_NAME, personParam.getFIRSTNAME()));
				record.setField(new Field(PartyPersonAttributes.MIDDLE_NAME, personParam.getMIDDLENAME()));
				record.setField(new Field(PartyPersonAttributes.LAST_NAME, personParam.getLASTNAME()));
				record.setField(new Field(PartyPersonAttributes.SUFFIX, personParam.getSUFFIX()));
				record.setField(new Field(PartyPersonAttributes.JOB_TITLE, personParam.getJOBTITLE()));
				record.setField(new Field(PartyPersonAttributes.JOB_FUNCTION, personParam.getJOBFUNCTION()));
				if(!Util.isNullOrEmpty(personParam.getPERSONSTATUS()) && personParam.getPERSONSTATUS().trim().length()>1){
					record.setField(new Field(PartyPersonAttributes.PERSON_STATUS, getStatusCode(personParam.getPERSONSTATUS())));	
				}else{
					record.setField(new Field(PartyPersonAttributes.PERSON_STATUS, personParam.getPERSONSTATUS()));
				}
				// record.setField(new Field(
				// PartyPersonAttributes.SAP_INTEGRATION_ID, personParam));
				record.setField(new Field(PartyPersonAttributes.PERSON_TYPE, Constant.PARTY_TYPE_PERSON));
				record.setField(new Field(PartyPersonAttributes.PREF_LANGUAGE, personParam.getPREFLANGUAGE()));
				record.setField(new Field(PartyPersonAttributes.LIST_SOURCE, personParam.getLISTSOURCE()));
				record.setField(new Field(PartyPersonAttributes.DATA_SRC_SYS, personParam.getDATASOURCESYSTEM()));
				record.setField(new Field(PartyPersonAttributes.LATTICE_SCORE, personParam.getLATTICESCORE()));
				record.setField(new Field(PartyPersonAttributes.JOB_LEVEL, personParam.getJOBLEVEL()));
				record.setField(new Field(MDMAttributeNames.PARTY_SRC_SYS_KEY, partyParam.getXREF().get(0).getSRCPKEY()));
				if(!Util.isNullOrEmpty(personParam.getSRCACCOUNTID())){
					record.setField(new Field(PartyPersonAttributes.SRC_ACCOUNT_ID, Constant.ADB_ACT_PREFIX+personParam.getSRCACCOUNTID()));
				}
				record.setField(new Field(PartyPersonAttributes.JOB_ROLE, personParam.getJOBROLE()));
				cleansePutRequest.setRecord(record);
				// execute Put request
				cleansePutResponse = (CleansePutResponse) siperianClient.process(cleansePutRequest);
				LOG.info("Party_Person cleansePut request processed successfully: " + cleansePutResponse.getMessage());
				// extract result
				RecordKey recordKey = cleansePutResponse.getRecordKey();

				PutResponseDataHolder responseDataHolder = new PutResponseDataHolder();
				responseDataHolder.setActionType(cleansePutResponse.getActionType());
				responseDataHolder.setActionMessage(cleansePutResponse.getMessage());
				responseDataHolder.setRowidObject(recordKey.getRowid());
				responseDataHolder.setRowidXREF(recordKey.getRowidXref());
				responseDataHolder.setSourceKey(recordKey.getSourceKey());
				responseDataHolder.setSystemName(recordKey.getSystemName());
				responseDataHolderList.add(responseDataHolder);
				LOG.info("ROWID_OBJECT of created Party_Person record = " + recordKey.getRowid());
				LOG.debug("Action Type = " + responseDataHolder.getActionType());
				LOG.debug("Action Msg = " + responseDataHolder.getActionMessage());
			} catch (SiperianServerException sifExcp) {
				LOG.error("SiperianServerException occured while processing CleansePutRequest for Party_Person: "
						+ sifExcp);
				LOG.error("sifExcp msg " + sifExcp);
				ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
				customException.setMessage("SIF exception occured while processing Put request for Party_Person. "
						+ customException.getMessage());
				customException.setRootExceptionMsg(
						sifExcp + " CleansePut operation failed for Party_Person " + personParam.getSRCPKEY());
				sifExcp.printStackTrace();
				throw customException;
			} catch (Exception excp) {
				LOG.error("Exception occured while processing CleansePutRequest for Party_Person: " + excp);
				excp.printStackTrace();
				ServiceProcessingException customException = new ServiceProcessingException(excp);
				customException.setMessage("Exception occured while processing Put request for Party_Person. "
						+ customException.getMessage());
				customException.setRootExceptionMsg(
						excp + " CleansePut operation failed for Party_Person " + personParam.getSRCPKEY());
				excp.printStackTrace();
				throw customException;
			}
		}

		LOG.info("Executed cleansePutPerson()");
		return responseDataHolderList;
	}
	

	/**
	 * The method prepares and executes CleansePutRequest on ADDRESS landing
	 * table for the given Address profiles.
	 *
	 * @param addressList
	 *            List of Addresses provided to the web service request
	 * @param partyParam
	 *            Party profile provided to the web service request
	 * @param siperianClient
	 *            SiperianClient SIF connection to MDM Hub
	 * @return List of PutResponseDataHolder object containing processing
	 *         results
	 * @throws ServiceProcessingException
	 */
	private List<PutResponseDataHolder> cleansePutAddress(List<AddressXrefType> addressList, PartyXrefType partyParam, SiperianClient siperianClient) throws ServiceProcessingException {
		LOG.info("Executing cleansePutAddress()");
		int itemIndex = 0;
		CleansePutRequest cleansePutRequest = null;
		CleansePutResponse cleansePutResponse = null;
		
		List<PutResponseDataHolder> responseDataHolderList = new ArrayList<PutResponseDataHolder>(addressList.size());
		AddressXrefType addressParam = null;

		try {
			for (itemIndex = 0; itemIndex < addressList.size(); itemIndex++) {
				cleansePutRequest = new CleansePutRequest();
				addressParam = addressList.get(itemIndex);
				// prepare CleansePutRequest
				Record record = new Record();
				// set mapping name
				record.setSiperianObjectUid(Util.getMappingObjectUid(addressParam.getSRCSYSTEM(), MDMAttributeNames.ENTITY_ADDRESS));
				// set input values
				if (partyParam.getLASTUPDATEDATE() != null && partyParam.getLASTUPDATEDATE().length() > 0) {
					record.setField(new Field(MDMAttributeNames.LAST_UPDATE_DATE, partyParam.getLASTUPDATEDATE()));
				} else {
					LOG.info("Performing cleansePutAddress with sysdate from HUB: " + lastUpdateDate);
					record.setField(new Field(MDMAttributeNames.LAST_UPDATE_DATE, lastUpdateDate));
				}
				record.setField(new Field(MDMAttributeNames.SRC_UPDT_BY, addressParam.getUPDATEBY()));
				record.setField(new Field(MDMAttributeNames.SRC_SYSTEM, addressParam.getSRCSYSTEM()));
				record.setField(new Field(MDMAttributeNames.SRC_SYS_KEY, addressParam.getSRCPKEY()));
				record.setField(new Field(AddressAttributes.ADDR_LN1, addressParam.getADDRLN1()));
				record.setField(new Field(AddressAttributes.ADDR_LN2, addressParam.getADDRLN2()));
				record.setField(new Field(AddressAttributes.ADDR_LN3, addressParam.getADDRLN3()));
				record.setField(new Field(AddressAttributes.ADDR_LN4, addressParam.getADDRLN4()));
				record.setField(new Field(AddressAttributes.ADDR_STATUS, addressParam.getADDRSTATUS()));
				record.setField(new Field(AddressAttributes.ADDR_TYPE, Constant.ADDRESS_TYPE_MAILING));
				record.setField(new Field(AddressAttributes.CITY, addressParam.getCITY()));
				LOG.debug("addressParam.getCOUNTRYCD(): " + addressParam.getCOUNTRYCD());
				if (!Util.isNullOrEmpty(addressParam.getCOUNTRYCD())
						&& addressParam.getCOUNTRYCD().trim().length() == 2) {
					record.setField(new Field(AddressAttributes.COUNTRY_CD, getADBCountryName(addressParam.getCOUNTRYCD())));
				} else {
					record.setField(new Field(AddressAttributes.COUNTRY_CD, addressParam.getCOUNTRYCD()));
				}
				record.setField(new Field(AddressAttributes.COUNTY, addressParam.getCOUNTY()));
				record.setField(new Field(AddressAttributes.DISTRICT, addressParam.getDISTRICT()));
				record.setField(new Field(AddressAttributes.LANG_CD, addressParam.getLANGCD()));
				record.setField(new Field(AddressAttributes.LATITUDE, addressParam.getLATITUDE()));
				record.setField(new Field(AddressAttributes.LONGITUDE, addressParam.getLONGITUDE()));
				record.setField(new Field(AddressAttributes.POSTAL_CD, addressParam.getPOSTALCD()));
				LOG.debug("addressParam.getSTATECD(): " + addressParam.getSTATECD());
				record.setField(new Field(AddressAttributes.STATE_CD, addressParam.getSTATECD()));
				record.setField(new Field(MDMAttributeNames.PARTY_SRC_SYS_KEY, partyParam.getXREF().get(0).getSRCPKEY()));
				record.setField(new Field(AddressAttributes.ADDRESS_QUALITY_IDENTIFIER, addressParam.getADDRESSQUALITYIDENTIFIER()));
				cleansePutRequest.setRecord(record);
				// execute Put request
				LOG.debug("Incoming Address Type" + addressParam.getADDRTYPE());
				 /*if ((!Util.isNullOrEmpty(addressParam.getADDRTYPE())) && (addressParam.getADDRTYPE().equals("Account_Address"))) {
					 putFlag = "N";
				 }
				 LOG.debug("putFlag" + putFlag);
				if (putFlag.equals("Y")){*/
					
				cleansePutResponse = (CleansePutResponse) siperianClient.process(cleansePutRequest);
				
				LOG.info("Address cleansePut request processed successfully: " + cleansePutResponse.getMessage());
				// extract result
				RecordKey recordKey = cleansePutResponse.getRecordKey();

				PutResponseDataHolder responseDataHolder = new PutResponseDataHolder();
				responseDataHolder.setActionType(cleansePutResponse.getActionType());
				responseDataHolder.setActionMessage(cleansePutResponse.getMessage());
				responseDataHolder.setRowidObject(recordKey.getRowid());
				responseDataHolder.setRowidXREF(recordKey.getRowidXref());
				responseDataHolder.setSourceKey(recordKey.getSourceKey());
				responseDataHolder.setSystemName(recordKey.getSystemName());
				responseDataHolderList.add(responseDataHolder);
				LOG.info("ROWID_OBJECT of created Address record = " + recordKey.getRowid());
				LOG.debug("Action Type = " + responseDataHolder.getActionType());
				LOG.debug("Action Msg = " + responseDataHolder.getActionMessage());
				// }
			}
		} catch (SiperianServerException sifExcp) {
			LOG.error("SiperianServerException occured while processing CleansePutRequest for Address: " + sifExcp);
			sifExcp.printStackTrace();
			ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
			customException.setMessage("SIF exception occured while processing Put request for Address. " + customException.getMessage());
			customException.setRootExceptionMsg(sifExcp + " CleansePut operation failed for Address " + addressParam.getSRCPKEY());
			throw customException;
		} catch (Exception excp) {
			LOG.error("Exception occured while processing CleansePutRequest for Address: " + excp);
			excp.printStackTrace();
			ServiceProcessingException customException = new ServiceProcessingException(excp);
			customException.setMessage("Exception occured while processing Put request for Address. " + customException.getMessage());
			customException.setRootExceptionMsg(excp + " CleansePut operation failed for Address " + addressParam.getSRCPKEY());
			throw customException;
		}

		LOG.info("Executed cleansePutAddress()");
		return responseDataHolderList;
	}

	/**
	 * The method prepares and executes CleansePutRequest on COMMUNICATION
	 * landing table for the given Communication profiles.
	 *
	 * @param commList
	 *            List of Communications provided to the web service request
	 * @param partyParam
	 *            Party profile provided to the web service request
	 * @param siperianClient
	 *            SiperianClient SIF connection to MDM Hub
	 * @return List of PutResponseDataHolder object containing processing
	 *         results
	 * @throws ServiceProcessingException
	 */
	private List<PutResponseDataHolder> cleansePutCommunication(List<CommunicationXrefType> commList, PartyXrefType partyParam, SiperianClient siperianClient) throws ServiceProcessingException {
		LOG.info("Executing cleansePutCommunication()");
		int itemIndex = 0;
		CleansePutRequest cleansePutRequest = null;
		CleansePutResponse cleansePutResponse = null;
		List<PutResponseDataHolder> responseDataHolderList = new ArrayList<PutResponseDataHolder>(commList.size());
		CommunicationXrefType commParam = null;

		try {
			for (itemIndex = 0; itemIndex < commList.size(); itemIndex++) {
				cleansePutRequest = new CleansePutRequest();
				commParam = commList.get(itemIndex);
				// prepare CleansePutRequest
				Record record = new Record();
				// set mapping name
				record.setSiperianObjectUid(Util.getMappingObjectUid(commParam.getSRCSYSTEM(), MDMAttributeNames.ENTITY_COMM));
				// set input values
				if (partyParam.getLASTUPDATEDATE() != null && partyParam.getLASTUPDATEDATE().length() > 0) {
					record.setField(new Field(MDMAttributeNames.LAST_UPDATE_DATE, partyParam.getLASTUPDATEDATE()));
				} else {
					LOG.info("Performing cleansePutCommunication with sysdate from HUB: " + lastUpdateDate);
					record.setField(new Field(MDMAttributeNames.LAST_UPDATE_DATE, lastUpdateDate));
				}
				record.setField(new Field(MDMAttributeNames.SRC_UPDT_BY, commParam.getUPDATEBY()));
				record.setField(new Field(MDMAttributeNames.SRC_SYSTEM, commParam.getSRCSYSTEM()));
				record.setField(new Field(MDMAttributeNames.SRC_SYS_KEY, commParam.getSRCPKEY()));
				record.setField(new Field(CommunicationAttributes.COMM_STATUS, commParam.getCOMMSTATUS()));
				String commType = "";
				if (commParam.getCOMMTYPE() != null && commParam.getCOMMTYPE().length() > 0) {
					commType = commParam.getCOMMTYPE().trim();
					record.setField(new Field(CommunicationAttributes.COMM_TYPE, commParam.getCOMMTYPE()));
				}
				if(commType.equalsIgnoreCase("email")){
					record.setField(new Field(CommunicationAttributes.COMM_VALUE, commParam.getCOMMVALUE().toLowerCase()));	
				}else{
					record.setField(new Field(CommunicationAttributes.COMM_VALUE, commParam.getCOMMVALUE()));
				}
				
				record.setField(new Field(CommunicationAttributes.COMM_EXTN, commParam.getCOMMEXTN()));
				record.setField(new Field(CommunicationAttributes.PRFRD_COMM_IND, commParam.getPRFRDCOMMIND()));
				record.setField(new Field(CommunicationAttributes.WEB_DOMAIN, commParam.getWEBDOMAIN()));
				record.setField(new Field(MDMAttributeNames.PARTY_SRC_SYS_KEY, partyParam.getXREF().get(0).getSRCPKEY()));
				cleansePutRequest.setRecord(record);
				// execute Put request
				cleansePutResponse = (CleansePutResponse) siperianClient.process(cleansePutRequest);
				LOG.info("Communication cleansePut request processed successfully: " + cleansePutResponse.getMessage());
				// extract result
				RecordKey recordKey = cleansePutResponse.getRecordKey();

				PutResponseDataHolder responseDataHolder = new PutResponseDataHolder();
				responseDataHolder.setActionType(cleansePutResponse.getActionType());
				responseDataHolder.setActionMessage(cleansePutResponse.getMessage());
				responseDataHolder.setRowidObject(recordKey.getRowid());
				responseDataHolder.setRowidXREF(recordKey.getRowidXref());
				responseDataHolder.setSourceKey(recordKey.getSourceKey());
				responseDataHolder.setSystemName(recordKey.getSystemName());
				responseDataHolderList.add(responseDataHolder);
				LOG.info("ROWID_OBJECT of created Communication record = " + recordKey.getRowid());
				LOG.debug("Action Type = " + responseDataHolder.getActionType());
				LOG.debug("Action Msg = " + responseDataHolder.getActionMessage());
			}
		} catch (SiperianServerException sifExcp) {
			LOG.error("SiperianServerException occured while processing CleansePutRequest for Communication: " + sifExcp);
			LOG.error("sifExcp msg " + sifExcp);
			ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
			customException.setMessage("SIF exception occured while processing Put request for Communication. " + customException.getMessage());
			customException.setRootExceptionMsg(sifExcp + " CleansePut operation failed for Communication " + commParam.getSRCPKEY());
			sifExcp.printStackTrace();
			throw customException;
		} catch (Exception excp) {
			LOG.error("Exception occured while processing CleansePutRequest for Communication: " + excp);
			excp.printStackTrace();
			ServiceProcessingException customException = new ServiceProcessingException(excp);
			customException.setMessage("Exception occured while processing Put request for Communication. " + customException.getMessage());
			customException.setRootExceptionMsg(excp + " CleansePut operation failed for Communication " + commParam.getSRCPKEY());
			excp.printStackTrace();
			throw customException;
		}

		LOG.info("Executed cleansePutCommunication()");
		return responseDataHolderList;
	}

	public void upsertTokenize(PartyXrefType ptyXrefType, MdmUpsertPartyResponse upsertPartyResponse, boolean retry,
			boolean executeNextStep, String rowidObjectRequest) throws ServiceProcessingException {
		LOG.info("Executing upsertTokenize()");

		PerformanceLoggerUtil perfLog = new PerformanceLoggerUtil();
		SiperianClient siperianClient = null;
		String rowidObject = null;
		String rowidPerson = null;
		int maxCountOfRetry = Integer.parseInt(configProps.getProperty("NoOfRetries"));
		boolean isMaxRetrySuccess = false;
		XREFType xref = null;

		try {

			xref = ptyXrefType.getXREF().get(0);
			siperianClient = (SiperianClient) checkOut();
			rowidObject = getRowidFromPkey(xref, "C_B_PARTY");
			rowidPerson = getRowidFromPkey(xref, "C_B_PARTY_PERSON");
			LOG.info("Calling Party processTokenizeRequest() rowidObject::" + rowidObject);
			processTokenizeRequest(rowidObject, "C_B_PARTY");
			LOG.info("Calling Person processTokenizeRequest() rowidPerson::" + rowidPerson);
			processTokenizeRequest(rowidPerson, "C_B_PARTY_PERSON");
			perfLog.printLog(Constant.PERF_LOG_FLOW_UPSERT_SAP_SBL, xref.getSRCPKEY(), "STEP 11", "Tokenization Done");

			upsertPartyResponse.setStatus(upsertPartyResponse.getStatus()
					+ "\nTokenization operation successful for Party " + xref.getSRCPKEY().replaceAll(Constant.ADB_CNT_PREFIX, Constant.STR_BLANK));
		} catch (SiperianServerException sifExcp) {
			LOG.error("SiperianServerException occured while processing TokenizeRequest for Party");
			ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
			customException.setMessage("SIF exception occured while processing Tokenize request for Party. "
					+ customException.getMessage());
			try {
				if (rowidObject != null) {

					for (int i = 0; i < maxCountOfRetry;) {
						try {
							processTokenizeRequest(rowidObject, "C_B_PARTY");
						} catch (Exception e) {
							i++;
						}
						isMaxRetrySuccess = true;
						break;
					}
				}

			} catch (Exception exp) {
				LOG.error("SiperianServerException occured while retrying TokenizeRequest for Party");

				isMaxRetrySuccess = false;
			}
			if (!isMaxRetrySuccess) {
				upsertPartyResponse = new MdmUpsertPartyResponse();
				upsertPartyResponse.setErrorMsg("Tokenization failed: " + sifExcp.getMessage());

				commonUtil.updateErrorStatus(ptyXrefType, upsertPartyResponse, Constant.ERROR_CONTACT_TOKENIZE_FAIL,
						rowidObject);

			}

			// throw customException;
		} catch (Exception excp) {
			LOG.error("Exception occured while processing TokenizeRequest for Party");
			ServiceProcessingException customException = new ServiceProcessingException(excp);
			customException.setMessage(
					"Exception occured while processing Tokenize request for Party." + customException.getMessage());

			upsertPartyResponse.setErrorMsg("Tokenization failed: " + excp.getMessage());
			commonUtil.updateErrorStatus(ptyXrefType, upsertPartyResponse, Constant.ERROR_CONTACT_TOKENIZE_FAIL,
					rowidObject);
			throw new ServiceProcessingException(Constant.ERROR_CONTACT_TOKENIZE_FAIL);
		} finally {
			checkIn(siperianClient);
		}
		LOG.info("Executed upsertTokenize()");

		if (executeNextStep)
			upsertMatchMergeProcess(ptyXrefType, upsertPartyResponse, true, true, rowidObject);

	}

	// generate match token for the party record
	private void processTokenizeRequest(String rowidObject, String BO) throws ServiceProcessingException {

		if (!Util.isNullOrEmpty(rowidObject)) {
			rowidObject = rowidObject.trim();
		}
		LOG.debug("Executing processTokenizeRequest()" + rowidObject);
		SiperianClient siperianClient = null;

		try {
			siperianClient = (SiperianClient) checkOut();

			TokenizeRequest tokenizeRequest = new TokenizeRequest();
			tokenizeRequest.setSiperianObjectUid(SiperianObjectType.BASE_OBJECT.makeUid(BO));
			RecordKey recordKey = new RecordKey();
			recordKey.setRowid(rowidObject);
			tokenizeRequest.setRecordKey(recordKey);
			tokenizeRequest.setActionType("Update");
			TokenizeResponse tokenizeResponse = (TokenizeResponse) siperianClient.process(tokenizeRequest);
			LOG.info("Match Token generated for PartyID: " + rowidObject + " Token msg: "
					+ tokenizeResponse.getMessage());
			// Delete Junk token after Tokenize
			if (BO.equalsIgnoreCase("C_B_PARTY")) {
			prospectPartyDAO.deleteJunkToken(rowidObject);
			}
			LOG.info("Junk Token has deleted Successfully");
			LOG.debug("Executed processTokenizeRequest()");
		} catch (Exception excp) {
			LOG.error("Caught exception within processTokenizeRequest() " + excp.getMessage());

			ServiceProcessingException customExcp = new ServiceProcessingException(excp);
			throw customExcp;
		} finally {
			checkIn(siperianClient);
		}
	}

	private String getRowidFromPkey(XREFType xref, String BO) {
		LOG.info("Execute getRowidFromPkey()");
		String rowidObject = null;
		try {
			GetRequest getReq = new GetRequest();
			getReq.setSiperianObjectUid(SiperianObjectType.BASE_OBJECT.makeUid(BO));
			RecordKey recordKey = new RecordKey();
			recordKey.setSourceKey(xref.getSRCPKEY());
			recordKey.setSystemName(xref.getSRCSYSTEM());
			getReq.setRecordKey(recordKey);
			SiperianClient siperianClient = (SiperianClient) checkOut();
			GetResponse getResp = (GetResponse) siperianClient.process(getReq);
			rowidObject = getResp.getRecordKey().getRowid();
			LOG.info("Party rowid_object of newly created record = " + rowidObject);

		} catch (Exception exp) {
			LOG.error("Error getting rowidObject for pkey " + xref.getSRCPKEY());
			// return null;
		}
		return rowidObject;
	}

	public void upsertMatchMergeProcess(PartyXrefType upsertParty, MdmUpsertPartyResponse upsertPartyResponse,
			boolean retry, boolean executeNextStep, String rowidObject) throws ServiceProcessingException {
		LOG.info("Executing upsertMatchMergeProcess");
		PerformanceLoggerUtil perfLog = new PerformanceLoggerUtil();
		PutResponseDataHolder putRespDataParty = null;
		//putRespDataParty = (PutResponseDataHolder) putRespDataHolderMap.get(MDMAttributeNames.ENTITY_PARTY);
		
		try {
			//Check match exclusion and process match and merge the party
			matchMergeProcessContact(upsertParty,upsertPartyResponse);
			// Merge child records
			childMultiMergeParty(upsertParty,upsertPartyResponse, putRespDataParty );
			
		} catch (ServiceProcessingException e) {
			commonUtil.updateErrorStatus(upsertParty,upsertPartyResponse , Constant.ERROR_CONTACT_MERGE_FAIL,rowidObject);
			throw e;
		}
		catch (Exception exp) {
			commonUtil.updateErrorStatus(upsertParty,upsertPartyResponse , Constant.ERROR_CONTACT_MERGE_FAIL,rowidObject);
			throw exp;
		}
		perfLog.printLog(Constant.PERF_LOG_FLOW_UPSERT_SAP_SBL, upsertParty.getXREF().get(0).getSRCPKEY(), 
				"STEP 14", "Stamp MDM LegacyID Done");			
		
		if (executeNextStep)
			upsertUCNStampProcess(upsertParty, upsertPartyResponse, retry, executeNextStep, rowidObject);
		LOG.info("Executed upsertMatchMergeProcess");
	}
	
	public void matchMergeProcessContact(PartyXrefType upsertParty,MdmUpsertPartyResponse upsertPartyResponse ){
		LOG.info("Executing matchMergeProcessContact");
		// fetch inserted party details and use that for match and merge
		PartyXrefType insertedContactData = new PartyXrefType();
		String rowidObject = null;
		HashMap<Integer, HighestScoreRecordHolder> mergeSorceHolderMap = new HashMap<Integer, HighestScoreRecordHolder>();
		HighestScoreRecordHolder highestScoreRecordHoldertgt = new HighestScoreRecordHolder();
		boolean exclusionPatternExists = false;
		PerformanceLoggerUtil perfLog = new PerformanceLoggerUtil();
		List<CommunicationXrefType> contactCommList = null;
		CommunicationXrefType commXrefType = null;
		String status = upsertPartyResponse.getStatus();
		boolean isInsert =false;
		LOG.debug("upsert response status :"+ status+":");
		if(status.contains("Insert operation successful")){
			isInsert = true;
		} 
		try {
			
			try {
				LOG.info("Fetching insertedContactData");
				//PutResponseDataHolder putRespDataParty = (PutResponseDataHolder) putRespDataHolderMap.get(MDMAttributeNames.ENTITY_PARTY);
				insertedContactData = getPartyDAO.fetchContactXrefTypeFromORS(upsertParty.getXREF().get(0).getSRCSYSTEM(), upsertParty.getXREF().get(0).getSRCPKEY());
				
				LOG.info("Got insertedContactData from GetPartyDAO for ContactID: " + insertedContactData.getROWIDOBJECT());
				sipPopVal = getPartyDAO.getSipPopFromXref();
				LOG.info("sipPopVal is: " + sipPopVal);
				rowidObject = insertedContactData.getROWIDOBJECT();
				perfLog.printLog(Constant.PERF_LOG_FLOW_UPSERT_SAP_SBL, upsertParty.getXREF().get(0).getSRCPKEY(), 
						"STEP 12", "Create canonical format Done");
				// Assuming that 1 Contact record will have 1 Email Value
				contactCommList = insertedContactData.getCommunication();
				LOG.debug("Communication size :"+contactCommList.size()+":");
				for (int indx = 0; indx < contactCommList.size(); indx++) {
					commXrefType = contactCommList.get(indx);
					if (commXrefType.getCOMMTYPE().equalsIgnoreCase("Email")) {
						LOG.debug("Inserted data has Email communication");
						commEmlVal = commXrefType.getCOMMVALUE();
						isEmailValExists = Boolean.TRUE;
					}
				}
				LOG.debug("email exists :"+isEmailValExists);
			} catch (ServiceProcessingException servExcp) {
				LOG.error("Exception occurred while invoking GetPartyDAO: " + servExcp.toString());

			} catch (Exception exp) {
				LOG.error("Caught exception while Fetching newly inserted Contact Record: " + exp);
			}
		if (isInsert) {	
			LOG.info("Match and merge for insert operation");
			try {
			
				if (isEmailValExists) {
					// If Contact has minimum 1 Email then only proceed for
					// match & merge
					LOG.debug("matchMergeProcessContact  !!");
					exclusionPatternExists = isMatchExclusionPatternExists(rowidObject);
					if (exclusionPatternExists) {
						LOG.info("Match exclusion pattern exists for the party, bypassing match & merge process and creating task for DS");
						
						String title = "Match Exclusion";
						String comment = "Match Exclusion pattern is present for the PartyID: " + rowidObject;
						processCreateTaskRequest(null, rowidObject, "FinalReview", title, comment);
						
					} else {
					mergeProcessContact(mergeSorceHolderMap, upsertPartyResponse, highestScoreRecordHoldertgt, insertedContactData,rowidObject);
					LOG.debug("Merge is successful on PARTY & PERSON entities !!");
				}
				}
			} catch (ServiceProcessingException servExcp) {

				LOG.error("Caught ServiceProcessingException in mergeProcessContact: " , servExcp);
				LOG.error("Root Exception Message: " + servExcp.getRootExceptionMsg());
				LOG.error("Localized Message: " + servExcp.getCause().getLocalizedMessage());
				LOG.error(" Message: " + servExcp.getCause().getMessage());
				throw servExcp;
			} catch (Exception Excp) {
				LOG.error("Caught exception in mergeProcessContact: " , Excp);
				warning.append("Merge Process failed. \n");					

				// Checking whether Match and Merge Operation Done or not
				if (matchInd) {
					upsertPartyResponse.setStatus(upsertPartyResponse.getStatus() + " Matching record found for Party.");
					matchInd = false;
				} else {
					upsertPartyResponse.setStatus(upsertPartyResponse.getStatus() + " No matching record found for Party.");
				}
				if (mergeInd) {
					upsertPartyResponse.setStatus(upsertPartyResponse.getStatus() + " Merge operation successful for Party and Account " + upsertParty.getXREF().get(0).getSRCPKEY().replaceAll(Constant.ADB_CNT_PREFIX, Constant.STR_BLANK) + ". Surviving rowid_object = "
							+ upsertPartyResponse.getParty().get(0).getROWIDOBJECT());
				} else {
					upsertPartyResponse.setStatus(upsertPartyResponse.getStatus() + " Merge not done for Party " + upsertParty.getXREF().get(0).getSRCPKEY().replaceAll(Constant.ADB_CNT_PREFIX, Constant.STR_BLANK));
				}
				throw Excp;
		
			}
		}
		}catch(Exception exp){
			LOG.error("Caught ServiceProcessingException in mergeProcessParty: " , exp);
			LOG.error("Root Exception Message: " + exp.getMessage());
			
		}
		LOG.info("Executed matchMergeProcessContact");
		return ;	
		}
	
	private boolean isMatchExclusionPatternExists(String rowidobject) throws ServiceProcessingException {

		boolean exclusionPatternExists = false;
		int patternExist = getPartyDAO.checkExclusionPatternProspect(rowidobject);
		if (patternExist > 0) {
			exclusionPatternExists = true;
			getPartyDAO.updatePartyConsolidationInd(rowidobject);
		}

		return exclusionPatternExists;
	}

	// Method for CreatingTask for Administrator
	private void processCreateTaskRequest(String tgtPartyRowId, String rowIdObject, String taskType, String title, String comment) {

		LOG.info("Executing processCreateTaskRequest()");
		SiperianClient siperianClient = null;

		try {
			String mergeOwnerUID = configProps.getProperty("mergeOwnerUID");
			String ownerUid = configProps.getProperty("ownerUID");
			String subjectAreaUID = configProps.getProperty("subjectAreaUID");

			CreateTaskResponse response = null;
			CreateTaskRequest request = new CreateTaskRequest();
			TaskData taskData = new TaskData();

			if (taskType.equalsIgnoreCase("Merge"))	{
				taskData.setOwnerUid(mergeOwnerUID);

			} else {
				taskData.setOwnerUid(ownerUid);

			}

			TaskRecord taskRecord = new TaskRecord();
			RecordKey recordKey = new RecordKey();
			taskRecord.setSiperianObjectUid(SiperianObjectType.BASE_OBJECT.makeUid(MDMAttributeNames.PARTY_BO));
			recordKey.setRowid(rowIdObject);
			LOG.debug("rowIdObject: " + rowIdObject);
			taskRecord.setRecordKey(recordKey);
			List<TaskRecord> recordList = new ArrayList<TaskRecord>();
			recordList.add(taskRecord);

			if (taskType.equalsIgnoreCase("Merge")) {

			//	for (HighestScoreRecordHolder srcRecHolder : mergeSorceHolderMap.values())
			//		tgtPartyRowId = srcRecHolder.getPartyRowIDObject();

				TaskRecord taskRecord2 = new TaskRecord();
				taskRecord2.setSiperianObjectUid(SiperianObjectType.BASE_OBJECT.makeUid(MDMAttributeNames.PARTY_BO));
				RecordKey recordKey2 = new RecordKey();
				recordKey2.setRowid(tgtPartyRowId);
				LOG.debug("tgtPartyRowId :" + tgtPartyRowId);
				taskRecord2.setRecordKey(recordKey2);
				recordList.add(0, taskRecord2);
			}

			taskData.setTaskRecords(recordList);
			request.setTaskData(taskData);
			taskData.setTitle(title);
			taskData.setComment(comment);

			Calendar cal = Calendar.getInstance();
			cal.setTime(new Date(System.currentTimeMillis()));
			cal.add(Calendar.DATE, 7);

			taskData.setDueDate(cal.getTime());
			// taskData.setSubjectAreaUid("SUBJECT_AREA.test|Person");
			taskData.setSubjectAreaUid(subjectAreaUID);
			// taskData.setTaskType("ReviewNoApprove");
			taskData.setTaskType(taskType);

			siperianClient = (SiperianClient) checkOut();

			LOG.info("processing CreateTaskRequest");
			response = (CreateTaskResponse) siperianClient.process(request);
			LOG.info("CreateTaskResponse result: " + response.getMessage());
			LOG.info("CreateTaskResponse taskId: " + response.getTaskId());
			LOG.info("CreateTaskResponse interactionId: " + response.getInteractionId());
			LOG.info("after response");
		} catch (Exception excp) {
			LOG.error("Caught Exception in CreateTaskRequest Error Message: " + excp);
		} finally {
			checkIn(siperianClient);
		}
		LOG.info("Executed processCreateTaskRequest()");
	}

	public HashMap<Integer, HighestScoreRecordHolder> mergeProcessContact(HashMap<Integer, HighestScoreRecordHolder> mergeSorceHolderMap,
			MdmUpsertPartyResponse upsertPartyResponse,HighestScoreRecordHolder highestScoreRecordHoldertgt,PartyXrefType insertedPartyData, String rowidObject) throws ServiceProcessingException {
		
		// execute Match and Merge on newly created records only; 
		// for Party Match will be based on Party_name, party_type, UCN etc,
		// whereas, for other BO, match will be based on rowid_party
		LOG.info("Executing mergeProcessContact() method.");
		//PutResponseDataHolder putRespDataParty = (PutResponseDataHolder) putRespDataHolderMap.get(MDMAttributeNames.ENTITY_PARTY);
		//List<PutResponseDataHolder> putRespDataAccountList = (List<PutResponseDataHolder>) putRespDataHolderMap.get(MDMAttributeNames.ENTITY_ACCOUNT);
		String survivorRowidObject = null;
		UserTransaction transaction = null;
		SiperianClient siperianClient = null;
		boolean isError = false;
		String targetRowid = null;

		int countOfRetry = Integer.parseInt(configProps.getProperty("NoOfRetries"));
		boolean isMergeRetrySuccess = false;
		List<String> rowidList = new ArrayList<String>();
		// execute Match and Merge SIF operation
		try {

			siperianClient = checkOut();
			transaction = ((EjbSiperianClient) siperianClient).createTX(300000);
			transaction.begin();

			
			try {
				mergeSorceHolderMap = processMatchAndMergeContact(insertedPartyData.getROWIDOBJECT(),
						(PartyXrefType) insertedPartyData, siperianClient);
				LOG.debug(" Controlled returned after processMatchAndMergeContact");
			} catch (Exception excp) {
				LOG.error("Caught exception within mergeProcessParty: ", excp);
				isError = true;
				throw excp;
			}
			
			if (mergeInd && mergeSorceHolderMap != null && mergeSorceHolderMap.size() > 0) {
			for (HighestScoreRecordHolder hsrh : mergeSorceHolderMap.values()) {
				targetRowid = hsrh.getRowidPerson();
			}
			// newly created record will merge to existing record
			String sourceRowid = insertedPartyData.getPartyPerson().get(0)
					.getROWIDOBJECT();

			LOG.debug("PersonSorce Key: " + sourceRowid + " | PersonTarget Key: " + targetRowid);

			String siperianObjectUid = "BASE_OBJECT.C_B_PARTY_PERSON";
			try {
			//	throw new ServiceProcessingException("Throwing manual exception in C_B_PARTY_PERSON Merge !! ");
				mergeProcessChild(siperianObjectUid, sourceRowid, targetRowid, siperianClient);
				LOG.debug("Contact Person Merge is successful !!");
			}	catch (Exception sifExcp) {
				//mergeInd = false;
				LOG.error("Exception occured while processing Merge operation on C_B_PARTY_PERSON: " , sifExcp);
				for(int i = 0; i<countOfRetry; i++)	{
				try{
					LOG.debug("Retrying C_B_PARTY_PERSON Merge process for "+ (i+1) +"th time");
					rowidList.add(sourceRowid);
					rowidList.add(targetRowid);
					updateCI(rowidList, "C_B_PARTY_PERSON",siperianClient);
					mergeProcessChild(siperianObjectUid, sourceRowid, targetRowid, siperianClient);
					LOG.debug("Person Merge is successful on attempt no. "+ (i+1));
					isMergeRetrySuccess = true;
					//mergeInd = true;
					break;
				} catch (Exception ex) {
					LOG.error("Exception occured in C_B_PARTY_PERSON Merge RetryMechanism on attempt no. "+ (i+1));
					LOG.error("Exception occured in Merge RetryMechanism on C_B_PARTY_PERSON");
				}
				}
				if(!isMergeRetrySuccess){
					ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
					customException.setMessage("SIF exception occured while processing Merge request on C_B_PARTY_PERSON: " + customException.getMessage());
					throw customException;
				}
			}//end try/catch
		
			}
			transaction.commit();

			// if newly created record got merged, set rowid_object of it to that
			// of surviving target record
			if (mergeInd) {
		//		String survivorRowidObject = null;
				for (HighestScoreRecordHolder hsrh : mergeSorceHolderMap.values()) {
					survivorRowidObject = hsrh.getPartyRowIDObject();
				}
				LOG.info("Setting rowid_object of new record to that of surviving target record " + survivorRowidObject);
				upsertPartyResponse.getParty().get(0).setROWIDOBJECT(survivorRowidObject.trim());
			}
		} catch (ServiceProcessingException excp) {
			LOG.error("Caught exception in ProcessMatchAndMerge operation." , excp);
			isError = true;
			//upsertPartyResponse.setErrorMsg("ProcessMatchAndMerge operation failed for PartyID: " + upsertPartyResponse.getParty().get(0).getSRCSYSTEMID());

			try {
				transaction.rollback();

			} catch (SystemException txExcp) {
				LOG.error("Failed to rollback transaction for ProcessMatchAndMerge operation : " + txExcp.toString());
			}
			throw excp;
		} catch (Exception ex) {
			LOG.error("Exception occured while ProcessMatchAndMerge operation requests: " , ex);
			isError = true;

			try {
				transaction.rollback();
			} catch (SystemException txExcp) {
				LOG.error("Failed to rollback transaction for ProcessMatchAndMerge operation: " + txExcp.toString());
	//			txExcp.printStackTrace();
			}
			ServiceProcessingException customException = new ServiceProcessingException(ex);
			customException.setMessage("Failed to process ProcessMatchAndMerge operation. " + customException.getMessage());
	//		customException.printStackTrace();
			throw customException;
		} finally {
			checkIn(siperianClient);
			if(isError)	{
				tgtRowidObj = targetRowid;
			}
		}

		try {

			//Updating APPRVD_FOR_MERGE to N after Party & Account Match & Merge
			if (mergeInd) {
				updateApprvdForMerge(survivorRowidObject);
			}

			// Perform Tokenization after Match & Merge
			PutResponseDataHolder putTokenizeDataParty = new PutResponseDataHolder();
			String sorceRowidObject = null;
			if (mergeInd) {
				for (HighestScoreRecordHolder hsrh : mergeSorceHolderMap.values()) {
					sorceRowidObject = hsrh.getPartyRowIDObject();
				}

				if (!Util.isNullOrEmpty(sorceRowidObject)) {
					putTokenizeDataParty.setRowidObject(sorceRowidObject);
					putTokenizeDataParty.setActionType("Merge");
					processTokenizeRequest(sorceRowidObject,"C_B_PARTY");
				}
			}
		} catch (SiperianServerException sifExcp) {
			LOG.error("SiperianServerException occured while processing TokenizeRequest for Party after MatchMerge." , sifExcp);
			ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
			customException.setMessage("SIF exception occured while processing Tokenize request for Party after MatchMerge. " + customException.getMessage());

		
		} catch (Exception excp) {
			LOG.error("Exception occured while processing TokenizeRequest for Party after MatchMerge." , excp);
			ServiceProcessingException customException = new ServiceProcessingException(excp);
			customException.setMessage("Exception occured while processing Tokenize request for Party after MatchMerge. " + customException.getMessage());

			
		}

		LOG.info("Executed mergeProcessParty() method.");
		return mergeSorceHolderMap;
	}
	
	/*Execute Merge API on Account BO Table*/
	private void mergeProcessChild(String siperianObjectUid, String sourceRowid, String targetRowid, SiperianClient siperianClient) throws ServiceProcessingException {

		LOG.info("Executing mergeProcessChild()");
		// SiperianClient siperianClient = null;

		try {

			// siperianClient = (SiperianClient) checkOut();

			if (sourceRowid != null && sourceRowid.length() > 0 && targetRowid != null && targetRowid.length() > 0) {
				MergeRequest request = new MergeRequest();
				MergeResponse response = null;
				request.setSiperianObjectUid(siperianObjectUid);
				//request.setOrsId(configProps.getProperty("orsId"));
				// newly created record will merged into existing one
				request.setSourceRecordKey(RecordKey.rowid(sourceRowid));
				// existing rec will survive
				request.setTargetRecordKey(RecordKey.rowid(targetRowid));
				// LOG.info("Child Target Key: "+ request.getTargetRecordKey());
				LOG.info(" Before executing Child Merge process ");
				LOG.info("siperianObjectUid: " + siperianObjectUid + ", ChildSourceRowid: " + sourceRowid + ", ChildTargetRowid: " + targetRowid);
				response = (MergeResponse) siperianClient.process(request);
				mergeInd = true;
				LOG.debug(" After executing Child Merge process ");
				String msg = response.getMessage();
				LOG.debug(" Message from MergeResponse :" + msg);
			} else {
				LOG.info("Either SourceRowID or TargetRowID is null");
			}
		} catch (SiperianServerException sifExcp) {
			mergeInd = false;
			LOG.error("SiperianServerException occured while processing Child Merge operation: " , sifExcp);
	//		sifExcp.printStackTrace();
			ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
			customException.setMessage("SIF exception occured while processing Merge request for Child. " + customException.getMessage());
			throw customException;
		} catch (Exception ex) {
			mergeInd = false;
			LOG.error("Child Merge operation failed with exception: " , ex);
	//		ex.printStackTrace();
			ServiceProcessingException customException = new ServiceProcessingException(ex);
			customException.setMessage("Failed to process Merge request for Child. " + customException.getMessage());
			throw customException;
		} finally {
			// checkIn(siperianClient);
		}
		LOG.info("Executed mergeProcessChild()");
	}

	
	private void childMultiMergeParty(PartyXrefType upsertParty ,MdmUpsertPartyResponse upsertPartyResponse,PutResponseDataHolder putRespDataParty ) throws ServiceProcessingException{
		LOG.info("Executing childMultiMergeParty");
		PartyType survivingPartyProfileFromBO = null;
		String survivingPartyRowid = upsertPartyResponse.getParty().get(0).getROWIDOBJECT();
		LOG.info("Party rowid_object of merged/newly created record = " + survivingPartyRowid);
		PerformanceLoggerUtil perfLog = new PerformanceLoggerUtil();
		
		
		int multiMergecountOfRetry = Integer.parseInt(configProps.getProperty("NoOfRetries"));
		boolean isMergeRetrySuccess = false;
		
		//Fetch base object records for new party or surviving party using canonical structure
		//if ("Update".equalsIgnoreCase(putRespDataParty.getActionType()) || "Insert".equalsIgnoreCase(putRespDataParty.getActionType())) {
			survivingPartyProfileFromBO = getPartyDAO.getBOContact(survivingPartyRowid);

			// Merge address and communication child entities
			try {
				mergeProcessMultipleChild(survivingPartyProfileFromBO, upsertPartyResponse);
				LOG.debug("Multi-Merge is successful on Address and Communication child entities");
			} catch (Exception servExcp) {
			//	mergeInd = false;
				LOG.error("Exception occured while Multi-Merge on Address and Communication: " , servExcp);
				for(int i = 0; i<multiMergecountOfRetry; i++)	{
				try{
					LOG.debug("Retrying Multi-Merge process for "+ (i+1) +"th time");
					mergeProcessMultipleChild(survivingPartyProfileFromBO, upsertPartyResponse);
					LOG.debug("Multi-Merge is successful on attempt no. "+ (i+1));
					isMergeRetrySuccess = true;
				//	mergeInd = true;
					break;
				} catch (Exception excp) {
					LOG.error("Exception occured in Multi-Merge Retry on attempt no. "+ (i+1));
					LOG.error("Exception occured in Multi-Merge RetryMechanism...");
				}
				}
				if(!isMergeRetrySuccess){
					ServiceProcessingException customException = new ServiceProcessingException(servExcp);
					customException.setMessage("SIF exception occured while processing Multi-Merge on Address and Communication : " + customException.getMessage());
					commonUtil.updateErrorStatus(upsertParty, upsertPartyResponse, Constant.ERROR_CONTACT_MERGE_FAIL, survivingPartyRowid);
					throw customException;
				}
				
			
			}
		//}
		
		perfLog.printLog(Constant.PERF_LOG_FLOW_UPSERT_SAP_SBL, upsertParty.getXREF().get(0).getSRCPKEY(), 	"STEP 13", "Match and Merge process Done");
		
	}
	
	public void mergeProcessMultipleChild(PartyType partyType, MdmUpsertPartyResponse upsertPartyResponse) throws ServiceProcessingException {

		LOG.info("Executing mergeProcessMultipleChild()");
		Map<String, List<String>> addrTypeMap = new HashMap<String, List<String>>();
		Map<String, List<String>> commTypeMap = new HashMap<String, List<String>>();
		List<String> addrRowidList = null;
		List<String> commRowidList = null;

		UserTransaction transaction = null;
		SiperianClient siperianClient = null;

		try {
			//rowidObject = upsertPartyResponse.getParty().get(partyCount - 1).getROWIDOBJECT();

			LOG.info("Preparing type-wise rowid_object list for Addr/Comm");
			//create type-wise rowid_object list for address, communication and classification
			for (int indx = 0; indx < partyType.getAddress().size(); indx++) {
				String addrType = partyType.getAddress().get(indx).getADDRTYPE();
				if (!addrTypeMap.containsKey(addrType)) {
					addrRowidList = new ArrayList<String>();
					addrTypeMap.put(addrType, addrRowidList);
				}
				addrTypeMap.get(addrType).add(partyType.getAddress().get(indx).getROWIDADDRESS());
			}

			for (int indx = 0; indx < partyType.getCommunication().size(); indx++) {
				String commType = partyType.getCommunication().get(indx).getCOMMTYPE();
				if (!commTypeMap.containsKey(commType)) {
					commRowidList = new ArrayList<String>();
					commTypeMap.put(commType, commRowidList);
				}
				commTypeMap.get(commType).add(partyType.getCommunication().get(indx).getROWIDCOMMUNICATION());
			}

			LOG.info("Type-wise rowid_object list for Addr/Comm");
		} catch (Exception ex) {
			LOG.error("Exception occured while preparing child entity records for Multi-merge: ", ex);
			ServiceProcessingException customException = new ServiceProcessingException(ex);
			customException.setMessage("Failed to prepare child entity records for Multi-merge: " + ex.getMessage());
			throw customException;
		}

		try {

			siperianClient = checkOut();
			transaction = ((EjbSiperianClient) siperianClient).createTX(300000);
			transaction.begin();

			LOG.info("Calling multi-merge process for Addr/Comm");
			//call multi-merge for each child
			Map<String, String> typeToSurvivingRowidMapAddr =  multiMergeProcessChild(MDMAttributeNames.ADDRESS_BO, addrTypeMap, siperianClient);
			Map<String, String> typeToSurvivingRowidMapComm = multiMergeProcessChild(MDMAttributeNames.COMM_BO, commTypeMap, siperianClient);

			transaction.commit();
			LOG.info("Multi-merge process for Addr/Comm completed");

			if (upsertPartyResponse != null) {
				upsertPartyResponse.setStatus(upsertPartyResponse.getStatus() + "\n ");
				if (typeToSurvivingRowidMapAddr != null && typeToSurvivingRowidMapAddr.size() > 1) {
					upsertPartyResponse.setStatus(upsertPartyResponse.getStatus() + "Address records got merged.");
				}
				if (typeToSurvivingRowidMapComm != null && typeToSurvivingRowidMapComm.size() > 1) {
					upsertPartyResponse.setStatus(upsertPartyResponse.getStatus() + "Communication records got merged.");
				}
			}
		} catch (ServiceProcessingException excp) {
			LOG.error("Exception in Merge operation for child entities: ", excp);

			try {
				transaction.rollback();
				LOG.debug("Transaction rolled back successfully.");
			} catch (SystemException txExcp) {
				LOG.error("Failed to rollback transaction for Merge operation : " + txExcp.toString());
			}
			throw excp;
		} catch (Exception ex) {
			LOG.error("Exception occured in Merge operation for child entities: ", ex);
			try {
				transaction.rollback();
				LOG.debug("Transaction rolled back successfully.");
			} catch (SystemException txExcp) {
				LOG.error("Failed to rollback transaction for Merge operation: " + txExcp.toString());
				txExcp.printStackTrace();
			}
			ServiceProcessingException customException = new ServiceProcessingException(ex);
			customException.setMessage("Failed to process Merge operation for child entities: " + ex.getMessage());
			throw customException;
		} finally {
			checkIn(siperianClient);
		}

		LOG.info("Executed mergeProcessMultipleChild()");
	}
	
	private Map<String, String> multiMergeProcessChild(String baseObjTable, Map<String, List<String>> childTypeMap, SiperianClient siperianClient) throws ServiceProcessingException {
		LOG.info("Executing multiMergeProcessChild()");
		List<String> recordList = null;
		//Modified code
		List<Integer> intRecordList = null;
		String childRecType = null;
		Map<String, String> recIdToSurvivingRowidMap = new HashMap<String, String>();
		String survivingRowid = null;

		try {
			LOG.info("Before executing child multi-merge process on " + baseObjTable);
			for (Entry entry : childTypeMap.entrySet()) {
				childRecType = entry.getKey().toString();
				recordList = (List<String>) entry.getValue();

				//if more than one rowid in list, go for multi-merge
				if (recordList != null && recordList.size() > 1) {
					updateCI(recordList, baseObjTable,siperianClient);
					MultiMergeRequest request = new MultiMergeRequest();
					//request.setOrsId(configProps.getProperty("orsId"));
					ArrayList<RecordKey> recordKeys = new ArrayList<RecordKey>();
					StringBuilder rowIds = new StringBuilder();

					intRecordList = new ArrayList<Integer>();
					for(String str : recordList)	{
						intRecordList.add(new Integer(str.trim()));
					}
					Collections.sort(intRecordList); //To make sure existing rowid survives

					for (int indx = 0; indx < intRecordList.size(); indx++) {
						RecordKey key = new RecordKey();
						key.setRowid(Util.padSpace(intRecordList.get(indx).toString(), 14));
						recordKeys.add(key);
						rowIds.append(intRecordList.get(indx));
						rowIds.append(", ");
						if (indx == 0) {
							survivingRowid = intRecordList.get(indx).toString();
						}
						recIdToSurvivingRowidMap.put(intRecordList.get(indx).toString(), survivingRowid);
					}

					request.setRecordKeyList(recordKeys);

					Record record = new Record();
					record.setSiperianObjectUid(SiperianObjectType.BASE_OBJECT.makeUid(baseObjTable));
					request.setRecord (record);

					LOG.info("To multi-merge on record_type: " + childRecType + " | Rowid_objects to merge: " + rowIds.toString());
					LOG.info("============================================================================================");
					ArrayList recList = request.getRecordKeyList();
					LOG.info("RecordKeyList:");
					for(Object ob : recList){
						LOG.info(ob.toString());
					}
					LOG.info("SiperianObjectUid:"+request.getSiperianObjectUid());
					LOG.info("============================================================================================");
					
					MultiMergeResponse response = (MultiMergeResponse) siperianClient.process(request);

					childMergeInd = true;
					LOG.debug(" Message from MultiMergeResponse :" + response.getMessage());
				} else {
					LOG.info("Sufficient records not found for multi-merge for type " + childRecType);
				}
			} //Modified code
		} catch (SiperianServerException sifExcp) {
			childMergeInd = false;
			LOG.error("SiperianServerException occured while processing Child multi-Merge operation: ", sifExcp);
			ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
			customException.setMessage("SIF exception occured while processing muti-Merge request for " + baseObjTable + ": " + sifExcp.getMessage());
			throw customException;
		} catch (Exception ex) {
			childMergeInd = false;
			LOG.error("Child Merge operation failed with exception for " + baseObjTable, ex);
			ServiceProcessingException customException = new ServiceProcessingException(ex);
			customException.setMessage("Failed to process Merge request for " + baseObjTable + ": " + ex.getMessage());
			throw customException;
		}
		LOG.info("Executed multiMergeProcessChild()");

		return recIdToSurvivingRowidMap;
	}
	
	private void updateCI(List<String> recordList, String baseObjTable,String consolidationInd)  throws ServiceProcessingException{
		LOG.debug("Inside updateCI()");
		Connection jdbcConn = null;
		Statement statement = null;
		JDBCConnectionProvider jDBCConnectionProvider = null;
		int rowCnt = 0;
		StringBuilder sqlQry = new StringBuilder();

		sqlQry.append("UPDATE "); 
		sqlQry.append(baseObjTable);
		sqlQry.append(" SET CONSOLIDATION_IND = '"+consolidationInd+"' WHERE ROWID_OBJECT in (");
		for (String partyRowId : recordList) {
			sqlQry.append("'" + partyRowId.trim() + "',");
		}
		sqlQry.deleteCharAt(sqlQry.length() - 1).toString();
		sqlQry.append(")");

		LOG.debug("SQL in updateCI()--> " + sqlQry);

		try{
			jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
			jdbcConn = jDBCConnectionProvider.getJdbcConnectionFromDS();
			statement = jdbcConn.createStatement();
			rowCnt = statement.executeUpdate(sqlQry.toString());

			//jdbcConn.commit();
			LOG.debug("RowidObject Updated for CI : " + rowCnt);
		//	LOG.debug("APPRVD_FOR_MERGE value updated to N in C_B_PARTY for partyID: " + survivingRowidObject);

		} catch(SQLException exp) {
			LOG.error("Caught SQLException in updateCI() " ,exp);

		} finally	{
			try {
				//Closing connections
			//	if (resultSet != null)	resultSet.close();
				if (statement != null) statement.close();
				if (jdbcConn != null) jdbcConn.close();
				} catch (SQLException exp) {
					LOG.error("SQLexp caught in updateCI(): " , exp);
				}

		}

		LOG.debug(" Executed updateCI() successfully ");
	}
	
	

	/* Perform Match & Merge operation for each Contact Record */
	// HashMap<Integer, HighestScoreRecordHolder>
	public HashMap<Integer, HighestScoreRecordHolder> processMatchAndMergeContact(String newPartyRowid,
			PartyXrefType partyTypeParam, SiperianClient siperianClient) throws ServiceProcessingException {

		LOG.info("Executing processMatchAndMergeContact()");
																					
		HighestScoreRecordHolder highestScoreRecordHolder = null;
		int matchCountOfRetry = Integer.parseInt(configProps.getProperty("NoOfRetries"));
		boolean isMatchRetrySuccess = false;
		List searchRecords = new ArrayList();

		HashMap<Integer, HighestScoreRecordHolder> highestScoreRecordHolderMap = new HashMap<Integer, HighestScoreRecordHolder>();
		List<Object> tempkeyList = new ArrayList<Object>();

		HighestScoreRecordHolder finalMatchedRecord = new HighestScoreRecordHolder();

		try {

			try {
				try {
					searchRecords = matchContact(partyTypeParam, siperianClient);
		//			throw new ServiceProcessingException("SearchMatchRequest on Contact threw Exception !!");
					LOG.debug("Contact SearchMatch is successful !!");
					
				} catch (Exception sifExcp) {
					matchInd = false;
					LOG.error("Exception occured while processing SearchMatchRequest on Contact: " , sifExcp);
					for(int i = 0; i<matchCountOfRetry; i++)	{
						try{
							LOG.debug("Retrying SearchMatchRequest Contact process for "+ (i+1) +"th time");
							searchRecords = matchContact(partyTypeParam, siperianClient);
							LOG.debug("SearchMatchRequest on Contact is successful on attempt no. "+ (i+1));
							isMatchRetrySuccess = true;
							matchInd = true;
							break;
						} catch (Exception ex) {
							LOG.error("Exception occured in SearchMatchRequest[Contact] RetryMechanism on attempt no. "+ (i+1));
							LOG.error("Exception occured in SearchMatchRequest[Contact] RetryMechanism on PARTY_BO");
						}
					}
					if(!isMatchRetrySuccess){
						ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
						customException.setMessage("Exception occured in SearchMatchRequest[Contact]"
								+ " RetryMechanism on PARTY_BO: " + customException.getMessage());
						throw customException;
					}
				} 
				
				// Store Match Score
				HashMap<Integer, Integer> matchScoreMap = new HashMap<Integer, Integer>();
				List<Integer> resultMatchScoreList = null;
				
				HashMap<Integer, Long> ucnCustNumMap = new HashMap<Integer, Long>();
				List<Integer> ucnCustNumMapList = null;

				if (searchRecords != null && searchRecords.size() > 0) {
					for (Iterator iter = searchRecords.iterator(); iter.hasNext();) {
						Record record = (Record) iter.next();
						highestScoreRecordHolder = null;
						String recRowid = record.getField("ROWID_OBJECT").getStringValue().trim();
						LOG.debug("Source PARTY_ROWID " + newPartyRowid);
						// Excluding self-matching record
						if (!recRowid.equals(newPartyRowid.trim())) {
							int rowidKey = Integer.parseInt(recRowid);

							if (!highestScoreRecordHolderMap.containsKey(rowidKey)) {

								LOG.debug("Populate highestScoreRecordHolderMap for matched PARTY_ROWID " + recRowid);
								highestScoreRecordHolderMap.put(rowidKey, new HighestScoreRecordHolder());
							}

							highestScoreRecordHolder = highestScoreRecordHolderMap.get(rowidKey);

							if (record.getField("ROWID_OBJECT").getStringValue() != null) {
								highestScoreRecordHolder
										.setPartyRowIDObject(record.getField("ROWID_OBJECT").getStringValue().trim());
							}
							if (record.getField("PERSON_ROWID_OBJECT").getStringValue() != null) {
								highestScoreRecordHolder
										.setRowidPerson(record.getField("PERSON_ROWID_OBJECT").getStringValue().trim());
							}
							if (record.getField("ROWID_COMMUNICATION").getStringValue() != null) {
								// highestScoreRecordHolder.setRowidCommunication(record.getField("ROWID_COMMUNICATION").getStringValue().trim());
								// comm = new CommunicationType();
								// comm.setCOMMTYPE(record.getField("COMM_TYPE").getStringValue());
								highestScoreRecordHolder.getCommMap().put(
										record.getField("ROWID_COMMUNICATION").getStringValue().trim(),
										record.getField("COMM_TYPE").getStringValue());
							}
							if (record.getField("ROWID_ADDRESS").getStringValue() != null) {
								highestScoreRecordHolder.getAddrMap().put(
										record.getField("ROWID_ADDRESS").getStringValue().trim(),
										record.getField("ADDR_TYPE").getStringValue());
								// highestScoreRecordHolder.setRowidAddress(record.getField("ROWID_ADDRESS").getStringValue().trim());
							}
							if (record.getField("UCN").getStringValue() != null) {
								highestScoreRecordHolder.setUCN(record.getField("UCN").getStringValue().trim());
							}
							// Populate Match Score Map
							String mtchScore = record.getField("MATCH_SCORE").getValue().toString().trim();
							int mtchValue = Integer.parseInt(mtchScore);
							LOG.info("MatchScoreMap rowid_object :" + rowidKey + " scoreValue :" + mtchValue);
							matchScoreMap.put(rowidKey, mtchValue);

							// highestScoreRecordHolderMap.put(rowidKey,highestScoreRecordHolder);
						} else {
							LOG.debug("Self Matching record found with rowidOb: " + recRowid);
						}
					}
					// }
					// Variables for tie-breaker
					int highestScore = 0;
					// HighestScoreRecordHolder finalMatchedRecord = null;

					if (matchScoreMap != null && matchScoreMap.size() > 0) {
						if (matchScoreMap.size() > 1) {
							highestScore = highestMatchScore(matchScoreMap);

							int matchScoreThreshold = Integer.parseInt(configProps.getProperty("matchScore-Threshold"));

							if (matchScoreThreshold > highestScore) {
								LOG.info(" Highest Match Score of MatchedRecords is smaller than ThresholdValue");
								return null;
								// return false;
							} else {
								matchInd = true;

								// Method invocation for fetching Records/Rowids
								// with
								// Highest Match Score
								if (matchScoreMap != null && matchScoreMap.size() > 0) {
									resultMatchScoreList = maxMatchScore(matchScoreMap);
								}
								// If Multiple Records/Rowids have Highest Match
								// Score
								if ((resultMatchScoreList != null && resultMatchScoreList.size() > 0)
										&& (highestScoreRecordHolderMap.size() > 1)) {

									// Removing Lower MatchScore Records
									for (Entry<Integer, HighestScoreRecordHolder> entry : highestScoreRecordHolderMap
											.entrySet()) {
										if (!resultMatchScoreList.contains(entry.getKey())) {
											LOG.info("Removing Record with RowID: " + entry.getKey());
											tempkeyList.add(entry.getKey());
										}
									}
									for (Object obj : tempkeyList) {
										highestScoreRecordHolderMap.remove(obj);
									}
									tempkeyList.clear();
									HighestScoreRecordHolder highestScoreRecordHolder3 = null;
									// If Multiple Records in HolderMap after
									// Removing Lower MatchScores
									if (highestScoreRecordHolderMap.size() > 1) {
	
										for (Entry entry : highestScoreRecordHolderMap.entrySet()) {
											highestScoreRecordHolder3 = (HighestScoreRecordHolder) entry.getValue();
											// Populate ucn Map
											if (highestScoreRecordHolder3.getUCN() != null && highestScoreRecordHolder3.getUCN().length() > 0) {
												int rowidKey = Integer.parseInt(highestScoreRecordHolder3.getPartyRowIDObject());
												long ucnValue = Long.parseLong(highestScoreRecordHolder3.getUCN());
												LOG.info("UCNCustMap rowid_object :" + rowidKey + " UCNValue :" + ucnValue);
												ucnCustNumMap.put(rowidKey, ucnValue);
											} else {
												LOG.info("Null ucnCustNum is: " + highestScoreRecordHolder3.getUCN());
											}
										}

										// Method invocation for fetching
										// Records with Lowest UCN
										if (ucnCustNumMap != null && ucnCustNumMap.size() > 0)
											ucnCustNumMapList = minUCNCustNum(ucnCustNumMap);
										
										//Taking the record with lower UCN
										if(ucnCustNumMapList != null && ucnCustNumMapList.size() > 0){
											finalMatchedRecord = highestScoreRecordHolderMap.get(ucnCustNumMapList.get(0));
											LOG.debug("finalMatchedRecord is: " + finalMatchedRecord.getPartyRowIDObject());
										}
										
										// Removing Records having highest UCN
										for (Entry<Integer, HighestScoreRecordHolder> entry : highestScoreRecordHolderMap
												.entrySet()) {
											if (!ucnCustNumMapList.contains(entry.getKey())) {
												LOG.info("Removing Record with RowID: " + entry.getKey());
												tempkeyList.add(entry.getKey());
											}
										}
										for (Object obj : tempkeyList) {
											highestScoreRecordHolderMap.remove(obj);
										}
										tempkeyList.clear();
										
									
									} else {
										// highestScoreRecordHolderMap contains
										// only 1 Matching Record
										LOG.debug("highestScoreRecordHolderMap contains only 1 Matching Record -->"
												+ highestScoreRecordHolderMap.keySet());
										for (Map.Entry<Integer, HighestScoreRecordHolder> recMapEntry : highestScoreRecordHolderMap
												.entrySet()) {
											finalMatchedRecord = recMapEntry.getValue();
											LOG.debug("finalMatchedRecord value is: " + finalMatchedRecord);
										}
									}
								} else {
									// highestScoreRecordHolderMap contains only
									// 1 Matching Record
									LOG.debug("highestScoreRecordHolderMap contains only 1 Matching Record -->"
											+ highestScoreRecordHolderMap.keySet());
									for (Map.Entry<Integer, HighestScoreRecordHolder> recMapEntry : highestScoreRecordHolderMap
											.entrySet()) {
										finalMatchedRecord = recMapEntry.getValue();
										LOG.debug("finalMatchedRecord value is: " + finalMatchedRecord);
									}
								}
							}

							LOG.info("Final Map Size: " + highestScoreRecordHolderMap.size());
							LOG.info("Target RecordKey is found: " + finalMatchedRecord);
						} else {

							// Entry<Integer, HighestScoreRecordHolder>
							// recMapEntry = (Entry<Integer,
							// HighestScoreRecordHolder>)
							// highestScoreRecordHolderMap.entrySet();
							LOG.info("Final Map Size: " + highestScoreRecordHolderMap.size());
							LOG.info("Record holder map contains only 1 matched record: "
									+ highestScoreRecordHolderMap.keySet());
							for (Map.Entry<Integer, HighestScoreRecordHolder> recMapEntry : highestScoreRecordHolderMap
									.entrySet()) {
								finalMatchedRecord = recMapEntry.getValue();
								LOG.debug("finalMatchedRecord value is: " + finalMatchedRecord);
							}
						}
					} else {
						//write logic to update consolidation indicator to 1
						try{
							commonUtil.updateCI(newPartyRowid.trim(),true);
							}catch(Exception e){
								LOG.info("Exception occured while updating CONSOLIDATION_IND");
							}
						LOG.info("No matching record found after searchMatch resultset processing");
						return null;
						// return false;
					}

				} else {
					try{
						commonUtil.updateCI(newPartyRowid.trim(),true);
						}catch(Exception e){
							LOG.info("Exception occured while updating CONSOLIDATION_IND");
						}
					//write logic to update consolidation indicator to 1
					LOG.info("No matching record found by searchMatch");
					return null;
					// return false;
				}
			} catch (SiperianServerException sifExcp) {
				LOG.error("SiperianServerException occured while processing Contact Match operation: ", sifExcp);
				ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
				customException.setMessage("SIF exception occured while processing Match request for Contact. "
						+ customException.getMessage());

				throw customException;
			} catch (Exception ex) {
				LOG.error("Contact Match operation failed with exception: ", ex);
				ServiceProcessingException customException = new ServiceProcessingException(ex);
				customException
						.setMessage("Failed to process Match request for Contact. " + customException.getMessage());

				throw customException;
			}
			
			
			int countOfRetry = Integer.parseInt(configProps.getProperty("NoOfRetries"));
			boolean isMergeRetrySuccess = false;
			String rowidHighestMtchTgt = null;
			
			try	{
				/* get rowid_object of record which has highest match score */
				if (!Util.isNullOrEmpty(finalMatchedRecord.getPartyRowIDObject())) {
					rowidHighestMtchTgt = finalMatchedRecord.getPartyRowIDObject();
					LOG.info("Target party rowid_object for merge: " + rowidHighestMtchTgt);
				//	throw new ServiceProcessingException("Throwing exception during Contact_Merge !!");
					mergeContact(newPartyRowid, rowidHighestMtchTgt, siperianClient);
					LOG.debug("Contact Merge is successful !!");
				} else {
					LOG.info("No matched target record key found. Merge Operation not done");
					// mergeInd = false;
					return null;
					// return false;
				}
			} catch (Exception ex) {
				mergeInd = false;
				LOG.error("Exception occured while processing Merge operation on Contact: " , ex);
				for(int i = 0; i<countOfRetry; i++)	{
				try{
					LOG.debug("Retrying Merge on Contact process for "+ (i+1) +"th time");
					mergeContact(newPartyRowid, rowidHighestMtchTgt, siperianClient);
					LOG.debug("Contact Merge is successful on attempt no. "+ (i+1));
					isMergeRetrySuccess = true;
					mergeInd = true;
					break;
				} catch (Exception excp) {
					LOG.error("Exception occured in Contact Merge RetryMechanism on attempt no. "+ (i+1));
					LOG.error("Exception occured in Contact Merge RetryMechanism on PARTY_BO");
				}
				}
				if(!isMergeRetrySuccess){
					ServiceProcessingException customException = new ServiceProcessingException(ex);
					customException.setMessage("SIF exception occured in Contact Merge request on PARTY BO: " + customException.getMessage());
					throw customException;
				}
			}

		} catch (SiperianServerException sifExcp) {
			LOG.error("SiperianServerException occured while processing Contact Merge operation: ", sifExcp);
			ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
			customException.setMessage("SIF exception occured while processing Merge request for Contact. "
					+ customException.getMessage());
			throw customException;
		} catch (ServiceProcessingException excp) {
			LOG.error("Contact Merge operation failed due to ServiceProcessingException with exception: ", excp);
			throw excp;
		} catch (Exception ex) {
			LOG.error("Contact Merge operation failed with exception: ", ex);
			ServiceProcessingException customException = new ServiceProcessingException(ex);
			customException.setMessage("Failed to process Merge request for Contact. " + customException.getMessage());
			throw customException;
		}

		return highestScoreRecordHolderMap;
		// return true;
	}
	
	
	// Method to calculate Lowest/minimum UCNCustNbr
	private List<Integer> minUCNCustNum(Map<Integer, Long> UCNCustNumMap) {
		Collection<Long> collVal = UCNCustNumMap.values();
		List<Long> uCNList = new ArrayList<Long>(collVal);
		List rowidObjs = new ArrayList(); //
		// Collections.sort(scoreList);
		// Object maxScore = scoreList.get(scoreList.size()-1);
		Long minUCN = Collections.min(uCNList);
		LOG.debug("Lowest UCNno: " + minUCN);
		int cnt = 0;
		// for (Iterator itr = scoreList.iterator(); itr.hasNext();) {
		for (Entry entry : UCNCustNumMap.entrySet()) {
			if (minUCN.equals(entry.getValue())) {
				cnt++;
				rowidObjs.add(entry.getKey());
			}
		}
		LOG.debug("No of records having lowest UCNtNo :" + cnt);
		return rowidObjs;
	}
	
	/*Execute Merge API on Party BO Table*/
	private void mergeContact(String newPartyRowid, String rowidHighestMtchTgt, SiperianClient siperianClient) throws ServiceProcessingException	{
		
		LOG.debug("Inside mergeContact for PARTY BO...");
		
		try	{
			MergeRequest request = new MergeRequest();
			request.setSiperianObjectUid("BASE_OBJECT.C_B_PARTY");
			// newly created record will be merged to the existing record
			request.setSourceRecordKey(RecordKey.rowid(newPartyRowid));
			// existing record will be the survivor
			request.setTargetRecordKey(RecordKey.rowid(rowidHighestMtchTgt));
			LOG.info(" Before executing Merge process ");
			MergeResponse response = (MergeResponse) siperianClient.process(request);
			LOG.info(" After executing Merge process. Message from MergeResponse: " + response.getMessage());
			matchInd = true;
			mergeInd = true;
				
		} catch (SiperianServerException sifExcp) {
		//	mergeInd = false;
			LOG.error("SiperianServerException occured while processing mergeContact on PARTY BO: " , sifExcp);
	//		sifExcp.printStackTrace();
			ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
			customException.setMessage("SIF exception occured while processing mergeContact on PARTY BO: " + customException.getMessage());
			throw customException;
		} catch (Exception ex) {
		//	mergeInd = false;
			LOG.error("PARTY_BO mergeContact failed with exception: " , ex);
	//		ex.printStackTrace();
			ServiceProcessingException customException = new ServiceProcessingException(ex);
			customException.setMessage("Failed to process mergeContact request on PARTY BO: " + customException.getMessage());
			throw customException;
		}
		LOG.debug("Completed mergeContact for PARTY BO...");
	}

	//Updating APPRVD_FOR_MERGE = N in C_B_PARTY for Survivor Record if APPRVD_FOR_MERGE is set
	private void updateApprvdForMerge(String survivingRowidObject) throws ServiceProcessingException	{

		LOG.debug("Inside updateApprvdForMerge()");
		Connection jdbcConn = null;
		Statement statement = null;
		JDBCConnectionProvider jDBCConnectionProvider = null;
		int rowCnt = 0;

		String sql = "UPDATE C_B_PARTY SET APPRVD_FOR_MERGE = 'N' WHERE APPRVD_FOR_MERGE = 'Y' AND ROWID_OBJECT = '" + survivingRowidObject + "'";

		LOG.debug("SQL in updateApprvdForMerge()--> " + sql);

		try{
			jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
			jdbcConn = jDBCConnectionProvider.getJdbcConnectionFromDS();
			statement = jdbcConn.createStatement();
			rowCnt = statement.executeUpdate(sql);

			jdbcConn.commit();
			LOG.debug("No of records Updated with APPRVD_FOR_MERGE : " + rowCnt);
			LOG.debug("APPRVD_FOR_MERGE value updated to N in C_B_PARTY for partyID: " + survivingRowidObject);

		} catch(SQLException exp) {
			LOG.error("Caught SQLException in updateApprvdForMerge() " ,exp);

		} finally	{
			try {
				//Closing connections
			//	if (resultSet != null)	resultSet.close();
				if (statement != null) statement.close();
				if (jdbcConn != null) jdbcConn.close();
				} catch (SQLException exp) {
					LOG.error("SQLexp caught in updateApprvdForMerge(): " , exp);
				}

		}

		LOG.debug(" Executed updateApprvdForMerge() successfully ");
	}

	// Method to calculate highest/maximum Match Score
	private List<Integer> maxMatchScore(Map<Integer, Integer> matchScoreMap) {
		Collection<Integer> collVal = matchScoreMap.values();
		List<Integer> scoreList = new ArrayList<Integer>(collVal);
		List rowidObjs = new ArrayList(); //
		// Collections.sort(scoreList);
		// Object maxScore = scoreList.get(scoreList.size()-1);
		Integer maxScore = Collections.max(scoreList);
		int cnt = 0;
		// for (Iterator itr = scoreList.iterator(); itr.hasNext();) {
		for (Entry entry : matchScoreMap.entrySet()) {
			if (maxScore.equals(entry.getValue())) {
				cnt++;
				rowidObjs.add(entry.getKey());
			}
		}
		LOG.debug("No of records having highest match score " + maxScore + ": " + cnt);
		return rowidObjs;
	}

	// Method to calculate HighestMatchScore
	private Integer highestMatchScore(Map<Integer, Integer> matchScoreMap) {
		Collection<Integer> collVal = matchScoreMap.values();
		List<Integer> scoreList = new ArrayList<Integer>(collVal);
		// Collections.sort(scoreList);
		// Object maxScore = scoreList.get(scoreList.size()-1);
		Integer maxScore = Collections.max(scoreList);
		LOG.debug("Highest Match score " + maxScore);

		return maxScore;
	}
	
	private List matchContact(PartyXrefType partyTypeParam, SiperianClient siperianClient ) throws ServiceProcessingException	{
		
		LOG.info("Executing matchContact()...");
		List searchRecords = new ArrayList();
		List<CommunicationXrefType> contactCommList = null;
		CommunicationXrefType commXrefType = null;
		String commEmlVal = null;
		
		try{
			SearchMatchRequest searchMatchRequest = new SearchMatchRequest();
			SearchMatchResponse searchMatchResponse = null;
			searchMatchRequest.setRecordsToReturn(100); // Required
			searchMatchRequest.setSiperianObjectUid("PKG_BO_PERSON_SEARCH");// Required//PKG_BO_PERSON_SEARCH
	
			searchMatchRequest.setMatchRuleSetUid(
					SiperianObjectType.MATCH_RULE_SET.makeUid("Party Person Fuzzy Rule Set New"));
	
			searchMatchRequest.setMatchType(MatchType.BOTH);
	
			LOG.info("Match Rule Set: " + searchMatchRequest.getMatchRuleSetUid());
			LOG.info("Match Type :" + searchMatchRequest.getMatchType());
	
			Field org_name = new Field("Organization_Name");
			if (!Util.isNullOrEmpty(partyTypeParam.getPARTYNAME())) {
				org_name.setStringValue(partyTypeParam.getPARTYNAME());
				LOG.info("Field to search for :" + org_name.getName() + ':' + org_name.getStringValue());
				searchMatchRequest.addMatchColumnField(org_name);
			}
	
			Field field_name = new Field("Person_Name");
			if (!Util.isNullOrEmpty(partyTypeParam.getPARTYNAME())) {
				field_name.setStringValue(partyTypeParam.getPARTYNAME());
				LOG.info("Field to search for :" + field_name.getName() + ':' + field_name.getStringValue());
				searchMatchRequest.addMatchColumnField(field_name);
			}
	
			// Setting Ex_Comm_Typ_Type
			Field field_Eml_Type = new Field("Ex_Comm_Type_Email");
			field_Eml_Type.setStringValue("Email");
			searchMatchRequest.addMatchColumnField(field_Eml_Type);
	
			LOG.info("Field to search for :" + field_Eml_Type.getName() + ':' + field_Eml_Type.getStringValue());
	
			// Setting Ex_Comm_Val_Eml
			
			contactCommList = partyTypeParam.getCommunication();
			for (int indx = 0; indx < contactCommList.size(); indx++) {
				commXrefType = contactCommList.get(indx);
				if (commXrefType.getCOMMTYPE().equalsIgnoreCase("Email")) {
					commEmlVal = commXrefType.getCOMMVALUE();
				}
			}
			
			Field field_Eml_Val = new Field("Ex_Comm_Val_Email");
			StringBuilder contEmlVal = new StringBuilder();
			if (!Util.isNullOrEmpty(commEmlVal)) {
				// contEmlVal.append("taylord@schaeferadvertising.com");//commEmlVal
				contEmlVal.append(commEmlVal);
				field_Eml_Val.setStringValue(contEmlVal.toString());
	
				searchMatchRequest.addMatchColumnField(field_Eml_Val);
			}
	
			LOG.info("Field to search for :" + field_Eml_Val.getName() + ':' + field_Eml_Val.getStringValue());
	
			// Setting field_Entity_Type
			Field field_Entity_Type = new Field("Ex_Entity_Type");
			field_Entity_Type.setStringValue("Person");
			searchMatchRequest.addMatchColumnField(field_Entity_Type);
	
			LOG.info("Field to search for :" + field_Entity_Type.getName() + ':'
					+ field_Entity_Type.getStringValue());
	
			// Adding SIP_POP
			Field field_SIPPOP = new Field("SIP_POP");
			field_SIPPOP.setStringValue(sipPopVal);// sipPopVal
			searchMatchRequest.addMatchColumnField(field_SIPPOP);
			LOG.info("Field to match for :" + field_SIPPOP.getName() + ':' + field_SIPPOP.getStringValue());
	
			StringBuffer criteria = new StringBuffer();
	
			/*
			 * if (firstParam) { criteria.append(" HUB_STATE_IND = '" + 1 +
			 * "'"); firstParam = false; } else { criteria.append(
			 * " AND HUB_STATE_IND = '" + 1 + "'"); }
			 */
	
			LOG.info("Filter Criteria: " + criteria.toString());
	
			searchMatchRequest.setFilterCriteria(criteria.toString());
	
			LOG.info("processing SearchMatchRequest in matchContact");
			searchMatchResponse = (SearchMatchResponse) siperianClient.process(searchMatchRequest);
	
			searchRecords = searchMatchResponse.getRecords();
			LOG.info("================================================================================================");
			for(int i =0 ; i< searchRecords.size();i++){
				Record record = (Record) searchRecords.get(i);
				record.getFields();
				Collection<String> fields = record.getFields();
				Iterator iterator = fields.iterator();
				 
		        // while loop
		        while (iterator.hasNext()) {
		        Field field = (Field)iterator.next();
		        if(field.getName().equals("BO_CLASS_CODE"))
		        	LOG.info("field name : " + field.getName() + " field value :" + field.getValue()+":");
		        else if(field.getName().equals("PARTY_TYPE"))
		        	LOG.info("field name : " + field.getName() + " field value :" + field.getValue()+":");
		        else if(field.getName().equals("PARTY_NAME"))
		        	LOG.info("field name : " + field.getName() + " field value :" + field.getValue()+":");
		        else if(field.getName().equals("ADDR_LN1"))
		        	LOG.info("field name : " + field.getName() + " field value :" + field.getValue()+":");
		        else if(field.getName().equals("ADDR_LN2"))
		        	LOG.info("field name : " + field.getName() + " field value :" + field.getValue()+":");
		        else if(field.getName().equals("CITY"))
		        	LOG.info("field name : " + field.getName() + " field value :" + field.getValue()+":");
		        else if(field.getName().equals("STATE_CD"))
		        	LOG.info("field name : " + field.getName() + " field value :" + field.getValue()+":");
		        else if(field.getName().equals("COUNTRY_CD"))
		        	LOG.info("field name : " + field.getName() + " field value :" + field.getValue()+":");
		        else if(field.getName().equals("ROWID_OBJECT"))
		        	LOG.info("field name : " + field.getName() + " field value :" + field.getValue()+":");
		        else if(field.getName().equals("UCN"))
		        	LOG.info("field name : " + field.getName() + " field value :" + field.getValue()+":");
		        else if(field.getName().equals("SIP_POP"))
		        	LOG.info("field name : " + field.getName() + " field value :" + field.getValue()+":");
		        else if(field.getName().equals("ROWID_ADDRESS"))
		        	LOG.info("field name : " + field.getName() + " field value :" + field.getValue()+":");
		        else if(field.getName().equals("RULE_NUMBER"))
		        	LOG.info("field name : " + field.getName() + " field value :" + field.getValue()+":");
		        else if(field.getName().equals("RULESET_NAME"))
		        	LOG.info("field name : " + field.getName() + " field value :" + field.getValue()+":");
		        else if(field.getName().equals("DEFINITE_MATCH_IND"))
		        	LOG.info("field name : " + field.getName() + " field value :" + field.getValue()+":");
		        else if(field.getName().equals("MATCH_SCORE"))
		        	LOG.info("field name : " + field.getName() + " field value :" + field.getValue()+":");
		        }
		        LOG.info("================================================================================================"); 
			}
		} catch (SiperianServerException sifExcp) {
		//		matchInd = false;
				LOG.error("[matchContact]:SiperianServerException occured while processing SearchMatchRequest on PARTY BO: " , sifExcp);
		//		sifExcp.printStackTrace();
				ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
				customException.setMessage("[matchContact]:SIF exception occured while processing SearchMatchRequest on PARTY BO: " + customException.getMessage());
				throw customException;
		} catch (Exception ex) {
		//		matchInd = false;
				LOG.error("[matchContact]:PARTY BO Merge operation failed with exception: " , ex);
		//		ex.printStackTrace();
				ServiceProcessingException customException = new ServiceProcessingException(ex);
				customException.setMessage("[matchContact]:Failed to process SearchMatchRequest on PARTY BO: " + customException.getMessage());
				throw customException;
		}
		LOG.info("Completed matchContact()...");
		return searchRecords;
	}
	
	
	
	public void upsertUCNStampProcess(PartyXrefType ptyXrefType, MdmUpsertPartyResponse upsertPartyResponse,
			boolean excuteNextStep, boolean retry, String rowidObject) throws ServiceProcessingException {
		LOG.info("Executing upsertUCNStampProcess()");
		String survivingContactRowid = "";
		int maxCountOfRetry = Integer.parseInt(configProps.getProperty("NoOfRetries"));
		boolean isMaxRetrySuccess = false;
		PerformanceLoggerUtil perfLog = new PerformanceLoggerUtil();	
		PartyType survivingContactProfileFromBO = null;
		XREFType xref = ptyXrefType.getXREF().get(0);
		String existingUCN  = null;
		survivingContactRowid = getRowidFromPkey(xref,"C_B_PARTY");
		
		if(!Util.isNullOrEmpty(survivingContactRowid)){
			survivingContactProfileFromBO = getPartyDAO.getBOContact(survivingContactRowid);
		}
		
			try {
				
				existingUCN  = prospectPartyDAO.checkifUCNExists(survivingContactRowid);
				//Setting UCN value by Calling GET_UCN
				if(Util.isNullOrEmpty(existingUCN)) {
					
					if (survivingContactProfileFromBO != null) {
					LOG.info("UCN for the surviving/new party is Null. Creating UCN for PartyType Person");
					setContactUCNSeq(survivingContactRowid);
					LOG.debug("UCN value successfully assigned.");
					upsertPartyResponse.setStatus(upsertPartyResponse.getStatus() + " UCN value assigned successfully.");
					}
				}
			} catch (ServiceProcessingException spExcp) {

				LOG.error("Failed to set UCN: ", spExcp);
				warning.append("UCN update process failed, Retry \n");
				try{
					if(survivingContactRowid != null){
				
						for(int i = 0 ; i < maxCountOfRetry;){
							try{
								setContactUCNSeq(survivingContactRowid);
							}catch(Exception e){
								i ++;
							}
							isMaxRetrySuccess= true;
							break;
						}
					}
					
				}catch(Exception exp){
					LOG.error("SiperianServerException occured while retrying UCN Stamping for Party");
				
					isMaxRetrySuccess = false;
				}
				if(!isMaxRetrySuccess){
					upsertPartyResponse = new MdmUpsertPartyResponse();
					upsertPartyResponse.setErrorMsg("UCN Stamp Process failed: "
							+ spExcp.getMessage());
					commonUtil.updateErrorStatus(ptyXrefType,upsertPartyResponse , Constant.ERROR_CONTACT_UCN_STAMP_FAIL,rowidObject);
					throw new ServiceProcessingException(Constant.ERROR_CONTACT_UCN_STAMP_FAIL);
				}

			} catch (Exception Excp) {

				LOG.error("Caught exception while updating UCN: ", Excp);

				warning.append("UCN update process failed, Retry \n");
				try{
					if(rowidObject != null){
				
						for(int i = 0 ; i < maxCountOfRetry; i++){
							try{
									setContactUCNSeq(survivingContactRowid);
							}catch(Exception e){
								i ++;
							}
							isMaxRetrySuccess= true;
							break;
						}
					}
					
				}catch(Exception exp){
					LOG.error("SiperianServerException occured while retrying TokenizeRequest for Party");
				
					isMaxRetrySuccess = false;
				}
				if(!isMaxRetrySuccess){
					upsertPartyResponse = new MdmUpsertPartyResponse();
					upsertPartyResponse.setErrorMsg("UCN update process failed: "+ Excp.getMessage());
					commonUtil.updateErrorStatus(ptyXrefType,upsertPartyResponse , Constant.ERROR_CONTACT_UCN_STAMP_FAIL,rowidObject);
					throw new ServiceProcessingException(Constant.ERROR_CONTACT_UCN_STAMP_FAIL);
					
				}
			}
			perfLog.printLog(Constant.PERF_LOG_FLOW_UPSERT_ADB, ptyXrefType.getXREF().get(0).getSRCPKEY(), 
					"STEP 15", "Stamp UCN / Legacy UCN Done");
		
		
		
		LOG.info("Executed upsertUCNStampProcess()");
		if (excuteNextStep)
			processAcntCntctRel(ptyXrefType, upsertPartyResponse, retry, excuteNextStep, survivingContactRowid);
	}
	
	private void setContactUCNSeq(String rowidObject) throws ServiceProcessingException {

		String ucnValue = null;
		try {
			// Get the next UCN value from Sequence Function
			ucnValue = prospectPartyDAO.getNextContactUCNValue();
			if (!Util.isNullOrEmpty(ucnValue)) {
				// Put the fetched UCN into
				putUCNRequest(rowidObject, ucnValue);
			}

		} catch (ServiceProcessingException spExcp) {
			LOG.error("Error in setUCNSeq(): " + spExcp.getMessage());
			throw spExcp;
		}
	}
	
	
	// Put UCN in base object & XREF tables.
		public void putUCNRequest(String rowidObject, String ucnValue) throws ServiceProcessingException {
			LOG.info("Executing putUCNRequest()");

			SiperianClient siperianClient = null;
			UserTransaction transaction = null;
			String systemUser = "admin";

			try {
				PutRequest putRequest = new PutRequest();
				PutResponse putResponse = null;
				String srcSystem = "Admin"; // trimming not required
				String srcPkey = null; // trimming not required
				String srcRowid = rowidObject; // trimming not required
				LOG.info("Executing PutRequest with src_system=" + srcSystem + " | scr_pkey=" + srcPkey + " | rowid_object="
						+ srcRowid);

				// Fetch Siperian Object from
				siperianClient = (SiperianClient) checkOut();
				// create transaction - commit if Delete and Put requests both succeeded
				transaction = ((EjbSiperianClient) siperianClient).createTX(1200); // in seconds
				transaction.begin();

				// prepare PutRequest
				RecordKey recordKey = new RecordKey();
				recordKey.setRowid(srcRowid);
				recordKey.setSystemName(srcSystem);
				putRequest.setRecordKey(recordKey);

				Record record = new Record();
				record.setSiperianObjectUid(SiperianObjectType.BASE_OBJECT.makeUid(MDMAttributeNames.PARTY_BO));
				record.setField(new Field(MDMAttributeNames.SRC_UPDT_BY, systemUser));
				record.setField(new Field(PartyAttributes.UCN, ucnValue));
				record.setField(new Field(PartyAttributes.STATUS_CD, "A"));

				putRequest.setRecord(record);
				// execute Put request
				putResponse = (PutResponse) siperianClient.process(putRequest);

				LOG.info("Committing UCN transaction");
				transaction.commit();
				LOG.info("Put request for UCN assignment processed successfully: Action Type = "
						+ putResponse.getActionType() + " | Msg = " + putResponse.getMessage());

			} catch (SiperianServerException sifExcp) {
				LOG.error("SiperianServerException occured while assigning UCN by Put request: ", sifExcp);
				ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
				customException.setMessage(
						"SiperianServerException occured while assigning UCN by Put request: " + sifExcp.getMessage());
				throw customException;
			} catch (Exception excp) {
				LOG.error("Exception occured while assigning UCN by Put request: ", excp);
				ServiceProcessingException customException = new ServiceProcessingException(excp);
				customException.setMessage("Exception occured while assigning UCN by Put request: " + excp.getMessage());
				throw customException;
			} finally {
				checkIn(siperianClient);
			}

			LOG.info("Executed putUCNRequest()");

		}

	/**
	 * Processing Account-Contact Relation mapping
	 * <ol>
	 * <li>Retrieve data from temp table MDM_RTS_MRKT_ACC_CONTACT_REL</li>
	 * <li>Create composite list of contact PKEY from incoming data & temp table
	 * data</li>
	 * <li>Check in XRef for those Pkeys</li>
	 * <li>If found then CleasePut in Golden record and delete from temp table
	 * </li>
	 * <li>Else insert data in temp table for any new incoming data</li>
	 * </ol>
	 * 
	 * @param upsertResponse
	 * @param partyContactRelList
	 * @param rowIdParty
	 * @param srcSystem
	 * @param srcPkey
	 * @throws ServiceProcessingException
	 */
	private void processAcntCntctRel(PartyXrefType ptyXrefType, MdmUpsertPartyResponse upsertResponse,
			boolean excuteNextStep, boolean retry, String rowidObject) throws ServiceProcessingException {
		LOG.debug("[processAcntCntctRel] ENTER");
		XREFType xref = ptyXrefType.getXREF().get(0);
		String rowIdContact = getRowidFromPkey(xref,"C_B_PARTY");
		String srcSystem = ptyXrefType.getXREF().get(0).getSRCSYSTEM();
		String srcPkey = ptyXrefType.getXREF().get(0).getSRCPKEY();
		String accountsrcPkey = ptyXrefType.getPartyPerson().get(0).getSRCACCOUNTID();
		if(!Util.isNullOrEmpty(accountsrcPkey)){
			accountsrcPkey = "ACT-"+accountsrcPkey;
		}
		XREFType accountXref = new XREFType ();
		accountXref.setSRCPKEY(accountsrcPkey);
		accountXref.setSRCSYSTEM("ADB");
		String accountRowid = getRowidFromPkey(accountXref,"C_B_PARTY");
		List<String> pkeysToInsertIntoTempTable = new ArrayList<String>();
		boolean accountExist = false;
		boolean accountRelExist = false;
		boolean contactRelExist = false;
	

		//Check if   Account is  existing  ,insert entry in temp table.
		if (!Util.isNullOrEmpty(accountsrcPkey)) {
			accountExist = checkAccountExist(accountsrcPkey);
			LOG.debug("[processAcntCntctRel]  Account Rel to process" + accountExist);
		}
		if (!accountExist) {
			// check count from MDM_RTS_MRKT_ACC_CONTACT_REL
			contactRelExist = checkContactAccountRelExist(rowIdContact);
			if (!contactRelExist) {

				pkeysToInsertIntoTempTable.add(srcPkey);
				prospectPartyDAO.insertPkeysInTempTable(pkeysToInsertIntoTempTable, srcSystem, accountsrcPkey,
						rowIdContact, false);
			}
			else{
				LOG.debug("[processAcntCntctRel]  Account Contact Pending Rel present");
			}
		}
		
		else{
			
			/*
			 * Check If Contact_Id exists in PARTY_REL table
			 */
			accountRelExist = prospectPartyDAO.checkifCntctRelationExists(accountRowid,rowIdContact);
			
			if (!accountRelExist) {
				// Create  Person Contact relation
				try{
					LOG.debug("[cleansePutAccountContactRel] ENTER");
					cleansePutAccountContactRel(ptyXrefType,upsertResponse, rowIdContact,
							accountRowid, srcSystem, srcPkey, null);
					LOG.debug("cleansePut AccountContact is successful");
				} catch (Exception excp) {
					LOG.error("Exception occured in cleansePut AccountContact");
				}
			
		}
		}
		LOG.debug("[processAcntCntctRel] EXIT::");
		
		if (excuteNextStep)
			upsertDataSyncProcess(ptyXrefType, upsertResponse, retry, excuteNextStep, rowIdContact);
	}
	
	/**
	 * The method prepares and executes CleansePutRequest on PARTY_REL landing
	 * table for the given Contact profiles.
	 * 
	 * @param upsertResponse
	 * @param contactRowid
	 * @param rowIdAccount
	 * @param srcSystem
	 * @param srcPkey
	 * @param relLastUpdateDate
	 * @return putResponseActnCntctDataHolder
	 * @throws ServiceProcessingException
	 */
	private PutResponseDataHolder cleansePutAccountContactRel(PartyXrefType partyXrefType,MdmUpsertPartyResponse upsertResponse, String contactRowid,
			String rowIdAccount, String srcSystem, String srcPkey, String relLastUpdateDate)
			throws ServiceProcessingException {
		LOG.debug("[cleansePutAccountContactRel] ENTER");
		LOG.debug("[cleansePutAccountContactRel] contactRowid::" + contactRowid + ", rowIdAccount::" + rowIdAccount +
				", srcSystem::" + srcSystem + ", srcPkey::" + srcPkey + ", relLastUpdateDate::" + relLastUpdateDate);
		UserTransaction transaction = null;
		SiperianClient siperianClient = null;
		lastUpdateDate = Util.getCurrentTimeZone();
		PutResponseDataHolder responseDataHolder = new PutResponseDataHolder();
		try {
			siperianClient = (SiperianClient) checkOut();
			transaction = ((EjbSiperianClient) siperianClient).createTX(300000);
			transaction.begin();
			CleansePutRequest cleansePutRequest = new CleansePutRequest();
			Record record = new Record();
			record.setSiperianObjectUid(Util.getMappingObjectUid(srcSystem, MDMAttributeNames.ENTITY_RELATION));
			if (Util.isNullOrEmpty(relLastUpdateDate)) {
				LOG.info("Performing cleansePutParty with sysdate from HUB: " + lastUpdateDate);
				record.setField(new Field(MDMAttributeNames.LAST_UPDATE_DATE, lastUpdateDate));
			} else {
				record.setField(new Field(MDMAttributeNames.LAST_UPDATE_DATE, relLastUpdateDate));
			}
			record.setField(new Field(MDMAttributeNames.SRC_SYSTEM, srcSystem));
			record.setField(new Field(MDMAttributeNames.SRC_SYS_KEY, srcPkey));
			record.setField(new Field(MDMAttributeNames.PARENT_ID, rowIdAccount));
			record.setField(new Field(MDMAttributeNames.CHILD_ID, contactRowid));
			record.setField(new Field(MDMAttributeNames.HIERARCHY_CODE, Constant.ROWID_CONTACT_HIERARCHY_TYPE));
			record.setField(new Field(MDMAttributeNames.REL_TYPE_CODE, Constant.ROWID_CONTACT_REL_TYPE));
			cleansePutRequest.setRecord(record);
			CleansePutResponse cleansePutResponse = (CleansePutResponse) siperianClient.process(cleansePutRequest);
			LOG.info("Account Contact Rel Put request processed successfully: " + cleansePutResponse.getMessage());
			RecordKey recordKey = cleansePutResponse.getRecordKey();
			responseDataHolder.setActionType(cleansePutResponse.getActionType());
			responseDataHolder.setActionMessage(cleansePutResponse.getMessage());
			responseDataHolder.setRowidObject(recordKey.getRowid());
			responseDataHolder.setRowidXREF(recordKey.getRowidXref());
			responseDataHolder.setSourceKey(recordKey.getSourceKey());
			responseDataHolder.setSystemName(recordKey.getSystemName());
			LOG.info("ROWID_OBJECT of created Party Account Rel record = " + recordKey.getRowid()
					+ "\nPKEY_SRC  of created Party Account Rel record = " + recordKey.getSourceKey());
			transaction.commit();
		} catch (Exception ex) {
			
			LOG.error("Exception occured while preparing/processing cleansePut requests: ", ex);
			try {
				transaction.rollback();
			} catch (SystemException txExcp) {
				LOG.error("Failed to rollback transaction for cleansePut requests : ", txExcp);
			}
			ServiceProcessingException customException = new ServiceProcessingException(ex);
			customException.setMessage("Failed to process Account Contact Rel cleansePut SIF request." + customException.getMessage());
			upsertResponse.setStatus("Failed to process Account Contact Rel cleansePut SIF request." + customException.getMessage());
			commonUtil.updateErrorStatus(partyXrefType, upsertResponse, Constant.ERROR_ACTCNTREL_CLEANSE_PUT_FAIL, srcPkey);
			throw customException;
		} finally {
			checkIn(siperianClient);
		}
		LOG.debug("[cleansePutAccountContactRel] EXIT");
		return responseDataHolder;
	}
	
	/**
	 * The method prepares and executes CleansePutRequest on PARTY_REL landing
	 * table for the given Contact profiles.
	 * 
	 * @param upsertResponse
	 * @param existingContactRowidList
	 * @param rowIdAccount
	 * @param srcSystem
	 * @param srcPkey
	 * @param relLastUpdateDate
	 * @return putResponseActnCntctDataHolder
	 * @throws ServiceProcessingException
	 */
	private List<PutResponseDataHolder> cleansePutContactAccountRel(MdmUpsertPartyResponse upsertResponse,
			List<CntctPkeyRowIdRelData> existingAcctRowidList, String rowIdContact, String srcSystem, String srcPkey,
			String relLastUpdateDate) throws ServiceProcessingException {
		LOG.debug("[cleansePutContactAccountRel] ENTER");
		List<PutResponseDataHolder> putResponseActnCntctDataHolder = new ArrayList<PutResponseDataHolder>();
		try {
			for (CntctPkeyRowIdRelData existingAcctRowid : existingAcctRowidList) {
				
				/*PutResponseDataHolder responseDataHolder = cleansePutAccountContactRel(upsertResponse, rowIdContact,
						existingAcctRowid.getContactRowId(), srcSystem, srcPkey, relLastUpdateDate);*/
				/** US478 : Retry on cleanse Put Start**/
				int cleansePutAccountContactcountOfRetry = Integer.parseInt(configProps.getProperty("NoOfRetries"));
				boolean iscleansePutRetrySuccess = false;
				PutResponseDataHolder responseDataHolder =null;
				try{
					responseDataHolder = cleansePutAccountContactRel(null,upsertResponse, rowIdContact,
							existingAcctRowid.getContactRowId(), srcSystem, srcPkey, relLastUpdateDate);
				}catch (Exception servExcp) {
					LOG.error("Exception occured while cleansePut AccountContact: " , servExcp);
					for(int i = 0; i<cleansePutAccountContactcountOfRetry; i++)	{
						try{
							LOG.debug("Retrying cleansePut AccountContact for "+ (i+1) +"th time");
							responseDataHolder = cleansePutAccountContactRel(null,upsertResponse, rowIdContact,
									existingAcctRowid.getContactRowId(), srcSystem, srcPkey, relLastUpdateDate);
							LOG.debug("Retry cleansePut AccountContact is successful on attempt no. "+ (i+1));
							iscleansePutRetrySuccess = true;
							break;
						} catch (Exception excp) {
							LOG.error("Exception occured in cleansePut AccountContact Retry on attempt no. "+ (i+1));
							LOG.error("Exception occured in cleansePut AccountContact RetryMechanism...");
						}
						
					}if(!iscleansePutRetrySuccess){
						upsertResponse.setErrorMsg("CleansePut operation failed for Account - Contact Rel" + srcPkey);
						ServiceProcessingException customException = new ServiceProcessingException(servExcp);
						customException.setMessage("SIF exception occured while processing cleansePut AccountContact : " + customException.getMessage());
						throw customException;
					}					
				}
				
			/** US478 : Retry on cleanse Put END**/
				putResponseActnCntctDataHolder.add(responseDataHolder);
				existingAcctRowid.setIsCleansePut(Boolean.TRUE);
			}
		} catch (ServiceProcessingException ex) {
			throw ex;
		} catch (Exception ex) {
			upsertResponse.setErrorMsg("CleansePut operation failed for Account - Contact Rel" + srcPkey);
			LOG.error("Exception occured while preparing/processing cleansePut requests: ", ex);
			ServiceProcessingException customException = new ServiceProcessingException(ex);
			customException.setMessage("Failed to process cleansePut SIF request." + customException.getMessage());
			throw customException;
		}
		LOG.debug("[cleansePutContactAccountRel] EXIT");
		return putResponseActnCntctDataHolder;
	}

	public void upsertDataSyncProcess(PartyXrefType partyXrefType, MdmUpsertPartyResponse upsertPartyResponse,
			boolean excuteNextStep, boolean retry, String rowidObject) {

		LOG.info("Executing upsertDataSyncProcess()");
		String survivingContactRowid = rowidObject;
		String status = upsertPartyResponse.getStatus();
		String actionType = "";
		try {
			XREFType xref = partyXrefType.getXREF().get(0);
			PartyXrefType insertedContactData = new PartyXrefType();
			insertedContactData = getPartyDAO.fetchContactXrefTypeFromORS(Constant.SRC_SYSTEM_ADB, xref.getSRCPKEY());

			if (status.contains("Insert operation successful")) {
				actionType = "Insert";
			} else if (status.contains("Update operation successful")) {
				actionType = "Update";
			}

			if (StringUtils.isEmpty(survivingContactRowid)) {
				survivingContactRowid = getRowidFromPkey(xref, "C_B_PARTY");
			}
			// Dummy Update on C_B_PARTY_REL for already existing Contact Rowid
			if ("Insert".equalsIgnoreCase(actionType)) {
				String relRowid = prospectPartyDAO.checkifCntctRelExists(survivingContactRowid);

				// If Contact_Id exists in PARTY_REL table, then do Dummy Update on PARTY_REL table
				if (!Util.isNullOrEmpty(relRowid)) {
					LOG.info("Perform Dummy Update on PARTY_REL table for REL_ROWID_OBJECT: " + relRowid);
					putContactRel(relRowid);
					putMsgTrackingId(survivingContactRowid, partyXrefType.getMSGTRKNID());
				} else {
					LOG.info("Surviving Contact Record rowID: " + survivingContactRowid
							+ " does not have Relation with any Prospect/Account in PARTY_REL.");
				}
			}

			List<String> sendToSrcList = null;
			sendToSrcList = getPartyDAO.getSentToList(actionType, Constant.SRC_SYSTEM_ADB, true);
			PartyType survivingContactProfileFromBO = null;
			survivingContactProfileFromBO = getPartyDAO.getBOContact(survivingContactRowid);
			upsertContactDAO.processUpdateRequest(partyXrefType, insertedContactData, sendToSrcList,
					survivingContactRowid, survivingContactProfileFromBO);

		} catch (ServiceProcessingException Excp) {
			LOG.error("Caught Service Exception while updating LegayID Ref Record: ", Excp);
			upsertPartyResponse.setErrorMsg("Process failed while Updating LegayID Ref Record \n");
			commonUtil.updateErrorStatus(partyXrefType, upsertPartyResponse, Constant.ERROR_CONTACT_XREF_UPDATE_FAIL,
					"0");
		} catch (Exception Excp) {
			LOG.error("Caught Generic Exception while updating LegayID Ref Record: ", Excp);
			upsertPartyResponse.setErrorMsg("Process failed while Updating LegayID Ref Record \n");
			commonUtil.updateErrorStatus(partyXrefType, upsertPartyResponse, Constant.ERROR_CONTACT_XREF_UPDATE_FAIL,
					"0");
		}

		LOG.info("Executed upsertDataSyncAccSegAssignProcess()");
		return;

	}

	/**
	 * The method prepares and executes PutRequest on PARTY_REL landing table
	 * for the given Contact profiles.
	 * 
	 * @param relRowidObj
	 * @throws ServiceProcessingException
	 */
	private void putContactRel(String relRowidObj) throws ServiceProcessingException {
		LOG.debug("[DummyUpdate] ENTER putContactRel");
		UserTransaction transaction = null;
		SiperianClient siperianClient = null;
		lastUpdateDate = Util.getCurrentTimeZone();
		try {
			PutRequest putRequest = new PutRequest();
			PutResponse putResponse = null;
			String srcSystem = "ADB"; // trimming not required
			String srcPkey = null; // trimming not required
			String srcRowid = relRowidObj; // trimming not required
			LOG.info("Executing PutRequest with src_system=" + srcSystem + " | scr_pkey=" + srcPkey + " | rowid_object="
					+ srcRowid);

			// Fetch Siperian Object from
			siperianClient = (SiperianClient) checkOut();
			// create transaction - commit if Delete and Put requests both succeeded
			transaction = ((EjbSiperianClient) siperianClient).createTX(1200); // in seconds
			transaction.begin();

			// prepare PutRequest
			RecordKey recordKey = new RecordKey();
			recordKey.setRowid(srcRowid);
			recordKey.setSystemName(srcSystem);
			putRequest.setRecordKey(recordKey);

			Record record = new Record();
			record.setSiperianObjectUid(SiperianObjectType.BASE_OBJECT.makeUid(MDMAttributeNames.PARTY_REL_BO));
			record.setField(new Field(MDMAttributeNames.LOAD_DT, lastUpdateDate));

			putRequest.setRecord(record);
			// execute Put request
			putResponse = (PutResponse) siperianClient.process(putRequest);

			LOG.info("Committing DummyUpdate in C_B_PARTY_REL");
			transaction.commit();
			LOG.info("DummyUpdate in C_B_PARTY_REL processed successfully: Action Type = " + putResponse.getActionType()
					+ " | Msg = " + putResponse.getMessage());
		} catch (Exception ex) {
			LOG.error("Exception occured while processing DummyUpdate in C_B_PARTY_REL: ", ex);
			try {
				transaction.rollback();
			} catch (SystemException txExcp) {
				LOG.error("Failed to rollback transaction for DummyUpdate in C_B_PARTY_REL : ", txExcp);
			}
			ServiceProcessingException customException = new ServiceProcessingException(ex);
			customException.setMessage("Failed to process cleansePut SIF request." + customException.getMessage());
		} finally {
			checkIn(siperianClient);
		}
		LOG.debug("[DummyUpdate] putContactRel EXIT");
	}

	/**
	 * Updating Msg Tracking ID in Party Table
	 * 
	 * @param rowidObject
	 * @param msgTrackingId
	 * @throws ServiceProcessingException
	 */
	private void putMsgTrackingId(String rowidObject, String msgTrackingId) throws ServiceProcessingException {
		LOG.debug("[putMsgTrackingId] ENTER");

		SiperianClient siperianClient = null;
		UserTransaction transaction = null;
		String systemUser = "admin";

		try {
			PutRequest putRequest = new PutRequest();
			PutResponse putResponse = null;
			String srcSystem = "Admin";
			LOG.debug("[putMsgTrackingId]Executing PutRequest with src_system=" + srcSystem + " | rowid_object="
					+ rowidObject);

			// Fetch Siperian Object from
			siperianClient = (SiperianClient) checkOut();
			// create transaction - commit if Delete and Put requests both succeeded
			transaction = ((EjbSiperianClient) siperianClient).createTX(1200); // in seconds
			transaction.begin();

			// prepare PutRequest
			RecordKey recordKey = new RecordKey();
			recordKey.setRowid(rowidObject);
			recordKey.setSystemName(srcSystem);
			putRequest.setRecordKey(recordKey);

			Record record = new Record();
			record.setSiperianObjectUid(SiperianObjectType.BASE_OBJECT.makeUid(MDMAttributeNames.PARTY_BO));
			record.setField(new Field(MDMAttributeNames.SRC_UPDT_BY, systemUser));
			record.setField(new Field(PartyAttributes.MSG_TRKN_ID, msgTrackingId));

			putRequest.setRecord(record);
			// execute Put request
			putResponse = (PutResponse) siperianClient.process(putRequest);

			LOG.debug("[putMsgTrackingId]Committing MSG_TRKN_ID transaction");
			transaction.commit();
			LOG.debug("[putMsgTrackingId]Put request for MSG_TRKN_ID assignment processed successfully: "
					+ "Action Type = " + putResponse.getActionType() + " | Msg = " + putResponse.getMessage());

		} catch (SiperianServerException sifExcp) {
			LOG.error("[putMsgTrackingId]SiperianServerException occured while assigning MSG_TRKN_ID"
					+ " by Put request: ", sifExcp);
			ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
			customException.setMessage(
					"SiperianServerException occured while assigning UCN by Put request: " + sifExcp.getMessage());
			throw customException;
		} catch (Exception excp) {
			LOG.error("[putMsgTrackingId]Exception occured while assigning MSG_TRKN_ID by Put request: ", excp);
			ServiceProcessingException customException = new ServiceProcessingException(excp);
			customException
					.setMessage("Exception occured while assigning MSG_TRKN_ID by Put request: " + excp.getMessage());
			throw customException;
		} finally {
			checkIn(siperianClient);
		}

		LOG.debug("[putMsgTrackingId] EXIT");
	}
	
	public void populateUpsertResponse(PartyXrefType upsertParty, MdmUpsertPartyResponse upsertPartyResponse) {

		
		//set Response Structure
		try{
			
			PartyType goldenPartyData = null;
			 XREFCopy xrefCopy = null;
			 Map<String, List<PartyXrefType>> partyXrefMap = null;
			 XREFType xref = upsertParty.getXREF().get(0);
			String survivingPartyRowid = getRowidFromPkey(xref,"C_B_PARTY");
			LOG.info("populateUpsertResponse for RowidObject" + survivingPartyRowid);
			//Update C_REPOS_MQ_DATA_CHANGE table to sent flag 99 for ADB records for which ADB record has created
			 if (survivingPartyRowid !=null){
				LOG.info("Update C_REPOS_MQ_DATA_CHANGE table to sent flag 99");
				commonUtil.setMsgSentFlagInTable(survivingPartyRowid,Constant.SRC_SYSTEM_ADB);
			} else {
				LOG.error("----------No update on C_REPOS_MQ_DATA_CHANGE ------------");
			}
			 if (survivingPartyRowid !=null){
			 goldenPartyData =  getPartyDAO.getBOContact(survivingPartyRowid);
			 partyXrefMap = searchContactDAO.getAdobeContactXrefRec(survivingPartyRowid);
			
			 }
						

			 
			if (goldenPartyData != null){
				if (upsertPartyResponse.getParty().size() > 0) {
					upsertPartyResponse.getParty().clear();
			    }
				PartyUpsertRespType partyUpsertResp = new PartyUpsertRespType();
				PartyPerson personInfo = null;
				List<PartyPerson> personList = new ArrayList<PartyPerson>();
				Address address = null;
				List<Address> addressList = new ArrayList<Address>();
				Communication communication = null;
				List<Communication> commList = new ArrayList<Communication>();
				PartyRel partyRel = null;
				int itemIndex = 0;
				// set all column of Party into response
				if (goldenPartyData != null) {
					// partyUpsertResp = new PartyUpsertRespType();
					partyUpsertResp.setROWIDOBJECT(goldenPartyData.getROWIDOBJECT().trim());
					partyUpsertResp.setSRCSYSTEM(upsertParty.getXREF().get(0).getSRCSYSTEM()); 
					partyUpsertResp.setSRCSYSTEMID(upsertParty.getXREF().get(0).getSRCPKEY().replaceAll(Constant.ADB_CNT_PREFIX, Constant.STR_BLANK));
					partyUpsertResp.setBOCLASSCODE(goldenPartyData.getBOCLASSCODE());
					partyUpsertResp.setPARTYTYPE(goldenPartyData.getPARTYTYPE());
					partyUpsertResp.setPARTYNAME(goldenPartyData.getPARTYNAME());
					partyUpsertResp.setGEO(goldenPartyData.getGEO());
					partyUpsertResp.setREGION(goldenPartyData.getREGION());
					partyUpsertResp.setSTATUSCD(goldenPartyData.getSTATUSCD());
					partyUpsertResp.setVATREGNBR(goldenPartyData.getVATREGNBR());
					partyUpsertResp.setTAXJURSDCTNCD(goldenPartyData.getTAXJURSDCTNCD());
					partyUpsertResp.setSALESBLOCKCD(goldenPartyData.getSALESBLOCKCD());
					partyUpsertResp.setUCN(goldenPartyData.getUCN());
					partyUpsertResp.setMSGTRKNID(upsertParty.getMSGTRKNID());
					partyUpsertResp.setPHYSICALGEO(goldenPartyData.getPHYSICALGEO());
					partyUpsertResp.setPHYSICALREGION(goldenPartyData.getPHYSICALREGION());
					//retrive child from goldenPartyData
					PartyPersonType personParam = null;
					for (itemIndex = 0; itemIndex < goldenPartyData.getPartyPerson().size(); itemIndex++) {
						personParam = goldenPartyData.getPartyPerson().get(itemIndex);
                     if (personParam.getROWIDOBJECT() != null ) {
							
							LOG.debug("============setting Person");
							
							personInfo = new PartyPerson();
							personInfo.setROWIDPERSON(personParam.getROWIDOBJECT().trim());
							personInfo.setPREFIX(personParam.getPREFIX());
							personInfo.setSUFFIX(personParam.getSUFFIX());
							personInfo.setFIRSTNAME(personParam.getFIRSTNAME());
							personInfo.setLASTNAME(personParam.getLASTNAME());
							personInfo.setMIDDLENAME(personParam.getMIDDLENAME());
							personInfo.setJOBTITLE(personParam.getJOBTITLE());
							personInfo.setJOBLEVEL(personParam.getJOBLEVEL());
							personInfo.setJOBFUNCTION(personParam.getJOBFUNCTION());
							personInfo.setPREFLANGUAGE(personParam.getPREFLANGUAGE());
							personInfo.setPERSONSTATUS(personParam.getPERSONSTATUS());
							personInfo.setPERSONTYPE(personParam.getPERSONTYPE());
							personInfo.setLISTSOURCE(personParam.getLISTSOURCE());
							personInfo.setDATASOURCESYSTEM(personParam.getDATASOURCESYSTEM());
							personInfo.setLATTICESCORE(personParam.getLATTICESCORE());
							personInfo.setREPORTEDCOMPANYNAME(personParam.getREPORTEDCOMPANYNAME());
							//personInfo.setSalesForceID(personParam.getSalesForceID());
							if(!Util.isNullOrEmpty(personParam.getSRCACCOUNTID())){
								personInfo.setSRCACCOUNTID(personParam.getSRCACCOUNTID().replaceAll(Constant.ADB_ACT_PREFIX, Constant.STR_BLANK));	
							}
							personInfo.setJOBROLE(personParam.getJOBROLE());
							personInfo.setCLEANSEIND(personParam.getCLEANSEIND());
							personInfo.setPARTNERCONTACTFLG(personParam.getPARTNERCONTACTFLG());
							LOG.debug("===Inserting into Person List===");
							personList.add(personInfo);
                     }
					}
					
					
					AddressType addrParam = null;
					for (itemIndex = 0; itemIndex < goldenPartyData.getAddress().size(); itemIndex++) {
						addrParam = goldenPartyData.getAddress().get(itemIndex);
						if (addrParam.getROWIDADDRESS() != null ) {
							
							LOG.debug("============setting Address");
							address = new Address();
						
							address.setROWIDADDRESS(addrParam.getROWIDADDRESS().trim());
							address.setADDRLN1(addrParam.getADDRLN1());
							address.setADDRLN2(addrParam.getADDRLN2());
							address.setADDRLN3(addrParam.getADDRLN3());
							address.setADDRLN4(addrParam.getADDRLN4());
							address.setCITY(addrParam.getCITY());
							address.setCOUNTY(addrParam.getCOUNTY());
							address.setDISTRICT(addrParam.getDISTRICT());
							address.setSTATECD(addrParam.getSTATECD());
							address.setPOSTALCD(addrParam.getPOSTALCD());
							address.setCOUNTRYCD(addrParam.getCOUNTRYCD());
							address.setLANGCD(addrParam.getLANGCD());
							address.setLONGITUDE(addrParam.getLONGITUDE());
							address.setLATITUDE(addrParam.getLATITUDE());
							address.setADDRTYPE(addrParam.getADDRTYPE());
							address.setADDRSTATUS(addrParam.getADDRSTATUS());

							LOG.debug("===Inserting into Address List===");
							addressList.add(address);

						}	
						
						}
					CommunicationType commParam = null;
					for (itemIndex = 0; itemIndex < goldenPartyData.getCommunication().size(); itemIndex++) {
						commParam = goldenPartyData.getCommunication().get(itemIndex);
						if (commParam.getROWIDCOMMUNICATION() != null ) {
							
							LOG.debug("============setting communication");
						
							communication = new Communication();

							communication.setROWIDCOMMUNICATION(commParam.getROWIDCOMMUNICATION().trim());
							communication.setCOMMTYPE(commParam.getCOMMTYPE());
							communication.setCOMMVALUE(commParam.getCOMMVALUE());
							communication.setCOMMSTATUS(commParam.getCOMMSTATUS());
							communication.setPRFRDCOMMIND(commParam.getPRFRDCOMMIND());
							communication.setWEBDOMAIN(commParam.getWEBDOMAIN());
							communication.setCOMMEXTN(commParam.getCOMMEXTN());
							communication.setCOMMMKTGPREF(commParam.getCOMMMKTGPREF());
							communication.setCOMMSALESPREF(commParam.getCOMMSALESPREF());
							LOG.debug("===Inserting into communication List===");
							commList.add(communication);

						}	
						
						}
					partyUpsertResp.getPartyPerson().addAll(personList);
					partyUpsertResp.getAddress().addAll(addressList);
					partyUpsertResp.getCommunication().addAll(commList);
					 //set UPDATE_DATE
					//LOG.debug("Adding update date in  master response " + goldenPartyData.getUPDATEDATE());
					upsertPartyResponse.setUPDATEDATE(goldenPartyData.getUPDATEDATE());
					
					LOG.debug("Get Party Rel for child id  "+goldenPartyData.getROWIDOBJECT().trim());
					//ResultSet resultSet = getPartyRel(goldenPartyData.getROWIDOBJECT(), null);
					
					//required more analysis in this part
					Map<String,PartyContactMDMRelationshipType> contactRelMap = getContactRelInfo(goldenPartyData.getROWIDOBJECT(),upsertParty.getXREF());		
					List<PartyContactMDMRelationshipType> listPartContactRel = new ArrayList<PartyContactMDMRelationshipType>();
					LOG.debug("Get Party Rel size  "+contactRelMap.size());
					partyRel = new PartyRel();
					for(String rowidRel : contactRelMap.keySet()){
						PartyContactMDMRelationshipType relationship = contactRelMap.get(rowidRel);
						listPartContactRel.add(relationship);
						//LOG.debug(relationship.getMDMPARENTID().getID());
					}
					LOG.debug(partyUpsertResp.getPartyRel());
					partyRel.getPARTYPERSONMDMREL().addAll(listPartContactRel);
					partyUpsertResp.setPartyRel(partyRel);
					
					
					LOG.debug("Added contact rel ");
					
					if(partyXrefMap.containsKey(survivingPartyRowid))	{
						xrefCopy = new XREFCopy();
					LOG.debug("Adding XREF Copies in master response ");
					 xrefCopy.getPartyXref().addAll(partyXrefMap.get(survivingPartyRowid));
                   //xrefCopyList.add(xrefCopy);
					 upsertPartyResponse.getXREFCopy().add(xrefCopy);
					}
					upsertPartyResponse.getParty().add(partyUpsertResp);					
				}					
			}
			} catch (Exception excp) {
			LOG.error("Exception occured while processing mdmUpsertPartyResponse  for Party " + upsertParty.getXREF().get(0).getSRCPKEY(),excp);
			ServiceProcessingException customException = new ServiceProcessingException(excp);
			customException.setMessage("Exception occured while processing mdmUpsertPartyResponsefor Party. " + customException.getMessage());
		//	throw customException;
		}
		
		if (warning != null && warning.length() > 0) {
			upsertPartyResponse.setWarningMsg(warning.toString());
		}
	}
	
	private Map<String,PartyContactMDMRelationshipType> getContactRelInfo(String partyId, 				
			List<XREFType> listXref) throws SQLException, ServiceProcessingException {
		Connection jdbcConn = null;
		JDBCConnectionProvider jDBCConnectionProvider = null;
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		ResultSet resultSetXref = null;
		Map<String,PartyContactMDMRelationshipType> contactRelMap = new HashMap<String,PartyContactMDMRelationshipType>();
				
		try {
			LOG.debug("Calling proc to get xref details");
			jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
			jdbcConn = jDBCConnectionProvider.getJdbcConnectionFromDS();
			
			StringBuilder sql = new StringBuilder();
			sql.append("select * from (select  rel.rowid_object,rowid_party, rowid_party_2,pty.create_date party_dt, "
					+ "rel.create_date rel_dt, rel.last_update_date,pty.pkey_src_object,pty.rowid_system,party.UCN,pty.party_type");
			sql.append(" from c_b_party_rel rel inner join  c_b_party_xref pty on pty.rowid_object=rel.rowid_party inner join c_b_party party on party.rowid_object=rel.rowid_party");
			sql.append(" where pty.party_type in ('Customer','Prospect Customer')");
			sql.append(" and rowid_party_2 = '"+partyId+"'");
			sql.append(" and rel.hub_state_ind=1 and pty.hub_state_ind=1 and rowid_system='ADB'");
			sql.append(" order by rel.last_update_date desc,rel.create_date desc, pty.create_date desc ) rn where rownum < 2");
			statement = jdbcConn.prepareStatement(sql.toString());
			resultSetXref = statement.executeQuery();
			
			LOG.debug("resultSetXref "+resultSetXref);
			PartyPersonMDMRelationshipType partyPersonChild = new PartyPersonMDMRelationshipType();
			partyPersonChild.setID(partyId.trim());
			partyPersonChild.getXREF().addAll(listXref);
			
			
			if(resultSetXref != null/* && !resultSetXref.isClosed()*/){
				LOG.debug("Processing result set");
				
				while(resultSetXref.next()){
					PartyContactMDMRelationshipType partyCntcRel =  null;
					String rowidRel = resultSetXref.getString(1);
					String rowidParent = resultSetXref.getString(2);
					String pkeyParent = resultSetXref.getString(7);
					String rowidSystemParent = resultSetXref.getString(8);
					String parentUCN = resultSetXref.getString(9); 
					String parentpartyType = resultSetXref.getString(10); 
					LOG.debug("rowidRel "+rowidRel);
					LOG.debug("rowidParent "+rowidParent);
					LOG.debug("pkeyParent "+pkeyParent);
					LOG.debug("rowidSystemParent "+rowidSystemParent);
					if(contactRelMap.get(rowidRel) == null){
						LOG.debug(" Contact rel not found ");
						partyCntcRel = new PartyContactMDMRelationshipType();
						PartyPersonMDMRelationshipType partyPersonNew = new PartyPersonMDMRelationshipType();
						XREFType xrefType = new XREFType();
						xrefType.setSRCPKEY(pkeyParent);
						if(rowidSystemParent != null){
						xrefType.setSRCSYSTEM(rowidSystemParent.trim());
						}
						partyPersonNew.getXREF().add(xrefType);
						partyPersonNew.setID(rowidParent.trim());
						partyPersonNew.setMDMUCN(parentUCN);
						partyPersonNew.setPARTYTYPE(parentpartyType);
						partyCntcRel.setMDMPARENTID(partyPersonNew);
						LOG.debug(" new parent xref added in new contact rel ");
						partyCntcRel.getMDMCHILDID().add(partyPersonChild);
						LOG.debug(" new child xref added in new contact rel ");
						partyCntcRel.setHIERARCHYTYPE("4");
						partyCntcRel.setRELTYPE("25");
						contactRelMap.put(rowidRel, partyCntcRel);
						LOG.debug(" Contact rel put in map for rel id "+partyCntcRel);
						
					}else{
						PartyPersonMDMRelationshipType partyPerson = contactRelMap.get(rowidRel).getMDMPARENTID();
						String parntId = partyPerson.getID();
						if(rowidParent.equalsIgnoreCase(parntId)){
							List<XREFType> xrefList = partyPerson.getXREF();
							List<XREFType> xrefListNew  = new ArrayList<XREFType>();
							for(XREFType xrefParent : xrefList){
								if(pkeyParent.equalsIgnoreCase(xrefParent.getSRCPKEY()) && 
										rowidSystemParent.equalsIgnoreCase(xrefParent.getSRCSYSTEM())){
										continue;
								}else{
									XREFType xrefNew = new XREFType();
									xrefNew.setSRCPKEY(pkeyParent);
									if(rowidSystemParent != null){
									xrefNew.setSRCSYSTEM(rowidSystemParent.trim());
									}
									xrefListNew.add(xrefNew);
								}
							}
							if(xrefListNew.size() > 0){
								partyPerson.getXREF().addAll(xrefListNew);									
								LOG.debug(" new xref list added in existing contact rel ");
							}
						}
						//contactRelMap.get(rowidRel).getMDMCHILDID().add(partyPersonChild);
						LOG.debug(" new child xref added in existing contact rel ");
						
					}							
									
				}
				
			}
			
		} catch (SQLException exp) {
			LOG.error("Caught exception in getPartyXref ", exp);
		//	throw exp;
		} finally {
			// Closing connections
					if (resultSet != null)	resultSet.close();
					if (statement != null)	statement.close();
					if (jdbcConn != null)	jdbcConn.close();
		}
		return contactRelMap;
	}

	private String getStatusCode(String statusDesc) {
		String status = "";
		if ("Active".equals(statusDesc)) {
			status = "A";
		} else if ("Inactive".equals(statusDesc)) {
			status = "I";
		} else if ("Merger".equals(statusDesc)) {
			status = "M";
		}

		return status;
	}
	
	private void updateCI(List<String> recordList, String baseObjTable, SiperianClient siperianClient){
		LOG.info("updateCI usinf siperianClient");
		for(String rowid : recordList){
		SetRecordStateRequest srsReq = new SetRecordStateRequest();              
		srsReq.addRecordKey(RecordKey.rowid(rowid));
		srsReq.setRecordState(RecordState.NEWLY_LOADED); //This sets the consolidation_ind to 4
		srsReq.setSiperianObjectUid(SiperianObjectType.BASE_OBJECT.makeUid(baseObjTable));
		SetRecordStateResponse srsResp = (SetRecordStateResponse) siperianClient.process(srsReq);
		}
		LOG.info("updateCI using siperianClient end");
	}
	
	public boolean checkAccountExist(String pkeyscrAccount) throws ServiceProcessingException {
		LOG.info("Executing checkAccountExist()");
		
		
		Statement statement = null;
		StringBuilder sqlQry = new StringBuilder();
		JDBCConnectionProvider jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();;
		Connection jdbcConnection = null;
		ResultSet resultSet = null;		
		int recordCount = 0;
		boolean accountExist = false;
		
		try {
			sqlQry.append(Constant.QUERY_GET_ID_IN_PARTY_BY_PKEY_ADB);
			sqlQry.append("'"+pkeyscrAccount + "'");
			jdbcConnection = jDBCConnectionProvider.getJdbcConnectionFromDS();
			//statement = jdbcConnection.prepareStatement(Constant.COUNT_FROM_PARTY_XREF);
			statement = jdbcConnection.createStatement();
			resultSet = statement.executeQuery(sqlQry.toString());
				LOG.info("Query to fetch presence of SFC Account record: " + sqlQry);

			
				while (resultSet.next()) {
					recordCount = resultSet.getInt(1);
				}	
				LOG.info("Record count with Account  = " + recordCount);
				if (recordCount > 0) {
					accountExist = true;
				}
			
			
		} catch (SQLException sqlEx) {
			LOG.error("Exception occurred while checking the presence of Account Record: ", sqlEx);
			//sqlEx.printStackTrace();
			ServiceProcessingException customException = new ServiceProcessingException(sqlEx);
			customException.setMessage("Failed to check the presence of of Account Record: " + sqlEx.getMessage());
			throw customException;
		} finally {
			try {
					if( resultSet != null)	resultSet.close();
					if( statement != null) statement.close();
					if(jdbcConnection != null) jdbcConnection.close();
				} catch (SQLException e) {
					
					e.printStackTrace();
				}
		}
		
		LOG.info("Executed checkAccountExist()");
		
		return accountExist;
	}

	
	private boolean checkContactAccountRelExist(String contatcRowId) throws ServiceProcessingException {
		LOG.info("Executing checkContactAccountRelExist()");
		
		
		Statement statement = null;
		StringBuilder sqlQry = new StringBuilder();
		JDBCConnectionProvider jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();;
		Connection jdbcConnection = null;
		ResultSet resultSet = null;		
		int recordCount = 0;
		boolean accountRelExist = false;
		
		try {
			sqlQry.append(Constant.QUERY_GET_REL_IN_TEMP);
			sqlQry.append("'"+contatcRowId + "'");
			jdbcConnection = jDBCConnectionProvider.getJdbcConnectionFromDS();
			//statement = jdbcConnection.prepareStatement(Constant.COUNT_FROM_PARTY_XREF);
			statement = jdbcConnection.createStatement();
			resultSet = statement.executeQuery(sqlQry.toString());
				LOG.info("Query to fetch presence of Rel record in Temp Table: " + sqlQry);

			
				while (resultSet.next()) {
					recordCount = resultSet.getInt(1);
				}	
				LOG.info("Record count with Account  = " + recordCount);
				if (recordCount > 0) {
					accountRelExist = true;
				}
			
			
		} catch (SQLException sqlEx) {
			LOG.error("Exception occurred while checking the presence of Account Record: ", sqlEx);
			//sqlEx.printStackTrace();
			ServiceProcessingException customException = new ServiceProcessingException(sqlEx);
			customException.setMessage("Failed to check the presence of of Account Record: " + sqlEx.getMessage());
			throw customException;
		} finally {
			try {
					if( resultSet != null)	resultSet.close();
					if( statement != null) statement.close();
					if(jdbcConnection != null) jdbcConnection.close();
				} catch (SQLException e) {
					
					e.printStackTrace();
				}
		}
		
		LOG.info("Executed checkContactAccountRelExist()");
		
		return accountRelExist;
	}
}