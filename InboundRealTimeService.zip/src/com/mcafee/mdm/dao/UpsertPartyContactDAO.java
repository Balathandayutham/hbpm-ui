package com.mcafee.mdm.dao;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;
import java.util.TreeSet;

import javax.annotation.Resource;
import javax.transaction.SystemException;
import javax.transaction.UserTransaction;

//import org.apache.axis.utils.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.mcafee.mdm.constants.AddressAttributes;
import com.mcafee.mdm.constants.CommunicationAttributes;
import com.mcafee.mdm.constants.Constant;
import com.mcafee.mdm.constants.MDMAttributeNames;
import com.mcafee.mdm.constants.PartyAttributes;
import com.mcafee.mdm.constants.PartyPersonAttributes;
import com.mcafee.mdm.dao.pojo.HighestScoreRecordHolder;
import com.mcafee.mdm.dao.pojo.PutResponseDataHolder;
import com.mcafee.mdm.dao.pojo.SearchedXrefRecordCollection;
import com.mcafee.mdm.exception.ServiceProcessingException;
import com.mcafee.mdm.generated.Account;
import com.mcafee.mdm.generated.Address;
import com.mcafee.mdm.generated.AddressType;
import com.mcafee.mdm.generated.AddressXrefType;
import com.mcafee.mdm.generated.Communication;
import com.mcafee.mdm.generated.CommunicationType;
import com.mcafee.mdm.generated.CommunicationXrefType;
import com.mcafee.mdm.generated.MdmUpsertPartyRequest;
import com.mcafee.mdm.generated.MdmUpsertPartyResponse;
import com.mcafee.mdm.generated.PartyAccountRelationshipType;
import com.mcafee.mdm.generated.PartyContactMDMRelationshipType;
import com.mcafee.mdm.generated.PartyPerson;
import com.mcafee.mdm.generated.PartyPersonMDMRelationshipType;
import com.mcafee.mdm.generated.PartyPersonType;
import com.mcafee.mdm.generated.PartyPersonXrefType;
import com.mcafee.mdm.generated.PartyRel;
import com.mcafee.mdm.generated.PartyType;
import com.mcafee.mdm.generated.PartyUpsertRespType;
import com.mcafee.mdm.generated.PartyXrefType;
import com.mcafee.mdm.generated.StatusType;
import com.mcafee.mdm.generated.UpsertPartyRequest;
import com.mcafee.mdm.generated.UpsertPartyResponse;
import com.mcafee.mdm.generated.XREFCopy;
import com.mcafee.mdm.generated.XREFType;
import com.mcafee.mdm.util.JDBCConnectionProvider;
import com.mcafee.mdm.util.ObjectPool;
import com.mcafee.mdm.util.PerformanceLoggerUtil;
import com.mcafee.mdm.util.PropertyUtil;
import com.mcafee.mdm.util.Util;
import com.siperian.sif.client.EjbSiperianClient;
import com.siperian.sif.client.SiperianClient;
import com.siperian.sif.client.SiperianServerException;
import com.siperian.sif.message.Field;
import com.siperian.sif.message.MatchType;
import com.siperian.sif.message.Record;
import com.siperian.sif.message.RecordKey;
import com.siperian.sif.message.SiperianObjectType;
import com.siperian.sif.message.TaskData;
import com.siperian.sif.message.TaskRecord;
import com.siperian.sif.message.mrm.CleansePutRequest;
import com.siperian.sif.message.mrm.CleansePutResponse;
import com.siperian.sif.message.mrm.CreateTaskRequest;
import com.siperian.sif.message.mrm.CreateTaskResponse;
import com.siperian.sif.message.mrm.GetRequest;
import com.siperian.sif.message.mrm.GetResponse;
import com.siperian.sif.message.mrm.MergeRequest;
import com.siperian.sif.message.mrm.MergeResponse;
import com.siperian.sif.message.mrm.MultiMergeRequest;
import com.siperian.sif.message.mrm.MultiMergeResponse;
import com.siperian.sif.message.mrm.PutRequest;
import com.siperian.sif.message.mrm.PutResponse;
import com.siperian.sif.message.mrm.SearchMatchRequest;
import com.siperian.sif.message.mrm.SearchMatchResponse;
import com.siperian.sif.message.mrm.TokenizeRequest;
import com.siperian.sif.message.mrm.TokenizeResponse;

import oracle.jdbc.OracleTypes;

/**
 *
 *
 */
@Component
@Scope("prototype")
public class UpsertPartyContactDAO extends ObjectPool {
	private static final Logger LOG = Logger.getLogger(UpsertPartyContactDAO.class.getName());
	
	@Autowired
	private DeleteChildDAO deleteChildDAO;
	@Autowired
	private GetPartyDAO getPartyDAO;
	@Autowired
	private SearchContactDAO searchContactDAO;
	@Autowired
	private ProspectPartyDAO prospectPartyDAO;
	@Autowired
	SearchPartyDAO searchDao;
	@Autowired
	private TrilliumCleanserDAO trilliumCleanserDAO;
	@Autowired
	private TrilliumLookUpDAO trilliumLookUpDAO;
	@Resource(name = "m4mMessagesProp")
	private Properties messagesProp;
	@Autowired
	private TrilliumContactCleanserDAO trilcontactCleanserDAO;

	
	boolean mergeInd = false;
	boolean matchInd = false;
	boolean childMergeInd = false;
	int partyCount = 0;
	String tgtRowidObj = null;
	String sipPopVal = null;
	String systemUser = "admin";
	String boXrefUser = "RT-BO-XREF";
	Properties configProps = PropertyUtil.getPropertiesFromFile("configProp");
	int matchScoreThres = Integer.parseInt(configProps.getProperty("matchScore-Threshold"));
	String getPkgName = configProps.getProperty("pkgName");
	StringBuilder warning = new StringBuilder();
	boolean isJapan = Boolean.FALSE;
	boolean isSFC = Boolean.FALSE;
	String commEmlVal = null;
	Date lastUpdateDate = null;


	public MdmUpsertPartyResponse processUpsertContactRequest(MdmUpsertPartyRequest upsertPartyRequest) throws ServiceProcessingException {
		LOG.info("Executing processUpsertContactRequest()");
		MdmUpsertPartyResponse upsertPartyResponse = new MdmUpsertPartyResponse();
		
		String methodName = null;
		int sizeInputParty=upsertPartyRequest.getParty().size();
		for (int index = 0; index < sizeInputParty; index++) {
			try {
				//lastUpdateDate = Util.getCurrentTimeZone();
				PartyXrefType upsertParty = upsertPartyRequest.getParty().get(index);
				if (upsertPartyRequest.getUpsertStatus() !=null && (upsertPartyRequest.getUpsertStatus().getErrorCode() !=null)){
				 methodName = configProps.getProperty(upsertPartyRequest.getUpsertStatus().getErrorCode()+"_API") ;
				}
				LOG.info("Executing method ");
				StatusType status = new StatusType();
                upsertPartyResponse.setUpsertStatus(status);
                processUpsertRequestForIndividualContact(methodName,upsertParty, upsertPartyResponse);
			} catch (ServiceProcessingException servexp) {
				LOG.error("Caught ServiceProcessingException in processUpsertContactRequest()" , servexp);

				
			} catch (Exception exp) {
				LOG.error("Caught exception in processUpsertContactRequest()" , exp);
				//exp.printStackTrace();
			}
		}
		upsertPartyResponse.setStatus(upsertPartyResponse.getStatus() == null ? "" : "\n");
		upsertPartyResponse.setStatus(upsertPartyResponse.getStatus() + "\n Processing completed for " + partyCount + " party(ies).");

		return upsertPartyResponse;
	}
	public void processUpsertRequestForIndividualContact(String methodName,PartyXrefType upsertParty, MdmUpsertPartyResponse upsertPartyResponse)
			throws ServiceProcessingException, SecurityException, ClassNotFoundException {

		LOG.info("Executing processUpsertRequestForIndividualParty()");
		
		PerformanceLoggerUtil perfLog = new PerformanceLoggerUtil();	
		
		String rowidObject = null;
		boolean retry = false;
		boolean execNext = false;
		PutResponseDataHolder putRespDataParty = null;
		//List searchRecords = new ArrayList();
	
		if(null != methodName){
			partyCount = 1;
			retry = true;
			execNext = true;
			try{
				LOG.info("Before reflection Method name : "+ methodName.trim());
				Class<? extends UpsertPartyContactDAO> cls= this.getClass();
				LOG.info("Class : "+cls.toString());
				
				Method method= cls.getMethod(new String(methodName.trim()), new Class[] { PartyXrefType.class,MdmUpsertPartyResponse.class,boolean.class,boolean.class, String.class});
				LOG.info("After get Method : "+method.toString());
				Object[] args = new Object[5];
				args[0] = upsertParty;
				args[1] = upsertPartyResponse;
				args[2] = retry;
				args[3] = execNext;
				args[4] = rowidObject;
				LOG.info("Before invoke");
				method.invoke(this, args);
				LOG.info("After Invoke");
			}catch(NoSuchMethodException e){
				LOG.error(e);
				throw new ServiceProcessingException(e);
			} catch (IllegalAccessException e) {
				LOG.error(e);
				throw new ServiceProcessingException(e);
			} catch (IllegalArgumentException e) {
				LOG.error(e);
				throw new ServiceProcessingException(e);
			} catch (InvocationTargetException e) {
				LOG.error(e);
				throw new ServiceProcessingException(e);
			}
		}else{
			retry = false;
			execNext = false;
			
			upsertDataValidation(upsertParty, upsertPartyResponse,false, false, rowidObject);		
			
			upsertTrilliumProcessing(upsertParty, upsertPartyResponse,false, false, rowidObject);
			
			checkDataQualityUpsert (upsertParty, upsertPartyResponse,false, false, rowidObject);	

			preUpsertMatchProcess(upsertParty, upsertPartyResponse,false, false,rowidObject);
			
			processCleansePutRequest(upsertParty, upsertPartyResponse,false, false,rowidObject);
			
			upsertTokenize(upsertParty, upsertPartyResponse,false, false, rowidObject);
			
			upsertMatchMergeProcess(upsertParty, upsertPartyResponse,false, false, rowidObject);
			
			upsertUCNStampProcess(upsertParty, upsertPartyResponse , false, false, rowidObject);
			
			processAcntCntctRel(upsertParty, upsertPartyResponse , false, false, rowidObject);
			
			upsertDataSyncProcess(upsertParty, upsertPartyResponse , false, false, rowidObject);
			
		
					
		}

		populateUpsertResponse(upsertParty,upsertPartyResponse);

				

		LOG.info("Executed processUpsertRequestForIndividualParty()");

	}
	

	/**
	 * validate input  ACCOUNT_NAME
	 * 
	 * @param curParty
	 * @param upsertResponse
	 * @throws ServiceProcessingException 
	 */
	private boolean validateContactName(PartyXrefType curParty, MdmUpsertPartyResponse upsertResponse) throws ServiceProcessingException {
		LOG.debug("[validateAccountName] START");
		Boolean isValid = Boolean.TRUE;
		boolean nameExclusionCond = Boolean.FALSE;
		
		try {
			
			if ( !Util.isNullOrEmpty(curParty.getPARTYNAME()) ) {
				String accountName = curParty.getPARTYNAME().trim();
				nameExclusionCond = prospectPartyDAO.isNameExclusionExists(accountName);
				if(nameExclusionCond)	{
					isValid = Boolean.FALSE;
					LOG.info("Junk Value in CONTACT_NAME is found :"+nameExclusionCond);
					createUpsertInfoMessage(upsertResponse, Constant.INFO_CONTACT_NAME_UNKWN);
					upsertResponse.setErrorCd( Constant.ERROR_CONTACT_NAME_UNKWN);
				}
			}else {
				isValid = Boolean.FALSE;
				createUpsertInfoMessage(upsertResponse, Constant.ERROR_ACCOUNT_EMPTY_NAME);
			}
		} catch (Exception sqlEx) {
			LOG.error("Exception occurred in validateAccountName: ", sqlEx);
			//sqlEx.printStackTrace();
			upsertResponse.setErrorMsg("DQ Check Fail On Account Name");
			ServiceProcessingException customException = new ServiceProcessingException(sqlEx);
			customException.setMessage("Custom Exception occurred in validateAccountName: " + sqlEx.getMessage());
			updateErrorStatus(curParty, upsertResponse, Constant.ERROR_ACCOUNT_DQ_CHECK_FAIL,"0");
			throw customException;
			
		} 
		LOG.debug("[validateAccountName] EXIT::isValid::" + isValid);
		return isValid;
	}
	
	
	private boolean validateContactNameNullUnknown(PartyXrefType curParty,
			MdmUpsertPartyResponse upsertResponse) throws ServiceProcessingException {
		LOG.debug("[validateContactNameNullUnknown] START");
		Boolean isValid = Boolean.TRUE;
		try {

			if ( !Util.isNullOrEmpty(curParty.getPARTYNAME()) ) {
				String contactName = curParty.getPARTYNAME();


				if ((!Util.isNullOrEmpty(contactName) )
						&& contactName.trim().contains("Unknown")
						) {
					isValid = Boolean.FALSE;
					LOG.info(" CONTACT_NAME null or UnKnown  found :" +isValid );
					createUpsertInfoMessage(upsertResponse, Constant.INFO_CONTACT_NAME_UNKWN);
					upsertResponse.setErrorCd( Constant.ERROR_CONTACT_NAME_UNKWN);

				}

			}

		} catch (Exception sqlEx) {
			LOG.error(
					"Exception occurred in validateContactNameNullUnknown : ",
					sqlEx);
			// sqlEx.printStackTrace();
			upsertResponse.setErrorMsg("DQ Check fail On Conatctname");
			upsertResponse.setErrorCd(Constant.ERROR_CONTACT_DQ_CHECK_FAIL);
			ServiceProcessingException customException = new ServiceProcessingException(
					sqlEx);
			customException
					.setMessage("Custom Exception occurred in Contact Name for null or UnKnown: "
							+ sqlEx.getMessage());
			updateErrorStatus(curParty, upsertResponse, Constant.ERROR_CONTACT_DQ_CHECK_FAIL,"0");
			 throw customException;
		}
		LOG.debug("[validateContactNameNullUnknown] EXIT::isValid::"
				+ isValid);
		return isValid;

	}
	
	
	// Validate account address for Junk condition
	private boolean validateAccountAddressJunk(PartyXrefType curParty,
			MdmUpsertPartyResponse upsertResponse) throws ServiceProcessingException {
		LOG.debug("[validateAccountAddressJunk] START");
		Boolean isValid = Boolean.TRUE;
		boolean junkAddressLn1 = Boolean.FALSE;
		boolean junkCity = Boolean.FALSE;

		try {
			String addressLn1 = curParty.getAddress().get(0).getADDRLN1();
			String city = curParty.getAddress().get(0).getCITY();
			if (!Util.isNullOrEmpty(addressLn1)) {
				junkAddressLn1 = prospectPartyDAO.isJunkAddressLn1(addressLn1);
				if (junkAddressLn1) {
					isValid = Boolean.FALSE;
					LOG.info(" Junk in AdressLn1 found : " + junkAddressLn1);
					createUpsertInfoMessage(upsertResponse,
							Constant.INFO_ADDRESS_UNKNOWN_JUNK);

					upsertResponse
							.setErrorCd(Constant.ERROR_CONTACT_ADDR_LN1_UNKWN);

				}
			} 
			if (!Util.isNullOrEmpty(city)) {
				junkCity = prospectPartyDAO.isJunkCity(city);
				if (junkCity) {
					isValid = Boolean.FALSE;
					LOG.info("Junk Value in CITY found : " + junkCity);
					createUpsertInfoMessage(upsertResponse,
							Constant.INFO_ADDRESS_UNKNOWN_JUNK);
					upsertResponse
							.setErrorCd(Constant.ERROR_CONTACT_CITY_UNKWN);
				}

			}
		} catch (Exception sqlEx) {
			LOG.error("Exception occurred in validateAccountAddressJunk: ",
					sqlEx);
			upsertResponse.setErrorMsg("DQ Check Fail On Address");
			upsertResponse.setErrorCd(Constant.ERROR_CONTACT_DQ_CHECK_FAIL);
			ServiceProcessingException customException = new ServiceProcessingException(
					sqlEx);
			customException
					.setMessage("Custom Exception occurred in validateAccountAddressJunk: "
							+ sqlEx.getMessage());
			updateErrorStatus(curParty, upsertResponse, Constant.ERROR_CONTACT_DQ_CHECK_FAIL,"0");
			 throw customException;
		}
		LOG.debug("[validateAccountAddressJunk] EXIT::isValid::" + isValid);
		return isValid;

	}
	

	// validateAccountAddressNullUnknown
	private boolean validateAccountAddressNullUnknown(PartyXrefType curParty,
			MdmUpsertPartyResponse upsertResponse) throws ServiceProcessingException {
		LOG.debug("[validateAccountAddressNullUnknown] START");
		Boolean isValid = Boolean.TRUE;
		try {

			List<AddressXrefType> addressXrefTypeList = curParty.getAddress();
			if (!CollectionUtils.isEmpty(addressXrefTypeList)) {

				String addressLn1 = curParty.getAddress().get(0).getADDRLN1();
				String city = curParty.getAddress().get(0).getCITY();
				String country = curParty.getAddress().get(0).getCOUNTRYCD();
				
				//Reject the request  if both address line 1 and city null
				
				if ((!Util.isNullOrEmpty(country)) && (Util.isNullOrEmpty(addressLn1)) && (Util.isNullOrEmpty(city)))
				{

					isValid = Boolean.FALSE;
					LOG.info(" Account AddressLn1  null or UnKnown  found :" +isValid );
					createUpsertInfoMessage(upsertResponse,
							Constant.INFO_ADDRESS_UNKNOWN_JUNK);
					upsertResponse
							.setErrorCd(Constant.ERROR_CONTACT_ADDR_INVALID);

				
				}
				
				//Reject the Request  if  address line 1 null and city present
				if ((Util.isNullOrEmpty(addressLn1)) && (!Util.isNullOrEmpty(city)))
				{

					isValid = Boolean.FALSE;
					LOG.info(" Account AddressLn1  null or UnKnown  found :" +isValid );
					createUpsertInfoMessage(upsertResponse,
							Constant.INFO_ADDRESS_UNKNOWN_JUNK);
					upsertResponse
							.setErrorCd(Constant.ERROR_CONTACT_ADDR_INVALID);

				
				}
				if ((!Util.isNullOrEmpty(addressLn1) )
						&& addressLn1.trim().equalsIgnoreCase("Unknown")
						) {
					isValid = Boolean.FALSE;
					LOG.info(" Account AddressLn1  null or UnKnown  found :" +isValid );
					createUpsertInfoMessage(upsertResponse,
							Constant.INFO_ADDRESS_UNKNOWN_JUNK);
					upsertResponse
							.setErrorCd(Constant.ERROR_CONTACT_ADDR_INVALID);

				}

			}

		} catch (Exception sqlEx) {
			LOG.error(
					"Exception occurred in validateAccountAddressNullUnknown : ",
					sqlEx);
			// sqlEx.printStackTrace();
			upsertResponse.setErrorMsg("DQ Check Fail On Address");
			upsertResponse.setErrorCd(Constant.ERROR_CONTACT_DQ_CHECK_FAIL);
			ServiceProcessingException customException = new ServiceProcessingException(
					sqlEx);
			customException
					.setMessage("Custom Exception occurred in Account validateAddress for null or UnKnown: "
							+ sqlEx.getMessage());
			updateErrorStatus(curParty, upsertResponse, Constant.ERROR_CONTACT_DQ_CHECK_FAIL,"0");
			 throw customException;
		}
		LOG.debug("[validateAccountAddressNullUnknown] EXIT::isValid::"
				+ isValid);
		return isValid;

	}

	private boolean validateAccountCitysNullUnknown(PartyXrefType curParty,
			MdmUpsertPartyResponse upsertResponse) throws ServiceProcessingException {
		LOG.debug("[validateAccountAddressNullUnknown] START");
		Boolean isValid = Boolean.TRUE;
		try {

			List<AddressXrefType> addressXrefTypeList = curParty.getAddress();
			if (!CollectionUtils.isEmpty(addressXrefTypeList)) {

				String addressLn1 = curParty.getAddress().get(0).getADDRLN1();
				String city = curParty.getAddress().get(0).getCITY();
				//Reject the Request  if  address line 1 present  and city null
				if ((!Util.isNullOrEmpty(addressLn1)) && (Util.isNullOrEmpty(city)))
				{
					isValid = Boolean.FALSE;
					LOG.info(" Account  city null or UnKnown  found :" +isValid );
					createUpsertInfoMessage(upsertResponse,
							Constant.INFO_ADDRESS_UNKNOWN_JUNK);
					upsertResponse
							.setErrorCd(Constant.ERROR_CONTACT_ADDR_INVALID);
				}
				if ((! Util.isNullOrEmpty(city)	)					
						&& city.trim().equalsIgnoreCase("Unknown")) {
					isValid = Boolean.FALSE;
					LOG.info(" Account  city null or UnKnown  found :" +isValid );
					createUpsertInfoMessage(upsertResponse,
							Constant.INFO_ADDRESS_UNKNOWN_JUNK);
					upsertResponse
							.setErrorCd(Constant.ERROR_CONTACT_ADDR_INVALID);

				}

			}

		} catch (Exception sqlEx) {
			LOG.error(
					"Exception occurred in validateAccountAddressNullUnknown : ",
					sqlEx);
			// sqlEx.printStackTrace();
			upsertResponse.setErrorMsg("DQ Check Fail On Address");
			upsertResponse.setErrorCd(Constant.ERROR_CONTACT_DQ_CHECK_FAIL);
			ServiceProcessingException customException = new ServiceProcessingException(
					sqlEx);
			customException
					.setMessage("Custom Exception occurred in Account validateAddress for null or UnKnown: "
							+ sqlEx.getMessage());
			updateErrorStatus(curParty, upsertResponse, Constant.ERROR_CONTACT_DQ_CHECK_FAIL,"0");
			throw customException;
		}
		LOG.debug("[validateAccountAddressNullUnknown] EXIT::isValid::"
				+ isValid);
		return isValid;

	}
	
	/**
	 * Create Info messages for  upsert
	 * 
	 * @param upsertResponse
	 * @param errorPropId
	 * @param srcPkey
	 */
	private void createUpsertInfoMessage(MdmUpsertPartyResponse upsertResponse, String infoPropId) {
		LOG.debug("[createUpsertInfoMessage] START::");
		String respMsg = null;
			respMsg = messagesProp.getProperty(infoPropId);
		if (Util.isNullOrEmpty(upsertResponse.getStatus())) {
			upsertResponse.setStatus(respMsg);
		} else {
			upsertResponse.setStatus(upsertResponse.getStatus() + "\n" + respMsg);
		}
		upsertResponse.setErrorMsg(respMsg);
		LOG.debug("[createUpsertInfoMessage] EXIT");
	}
	private boolean isMatchExclusionPatternExists(String rowidobject) throws ServiceProcessingException {

		boolean exclusionPatternExists = false;
		int patternExist = getPartyDAO.checkExclusionPatternProspect(rowidobject);
		if (patternExist > 0) {
			exclusionPatternExists = true;
			getPartyDAO.updatePartyConsolidationInd(rowidobject);
		}

		return exclusionPatternExists;
	}

	

	/**
	 * The method process cleansePut SIF requests for entire Party profile
	 * (Party and child entities) in the request. It handles transaction as per
	 * business need. After successful put calls, it stores the created
	 * rowid_object of the entities into respective response object
	 *
	 * @param UpsertPartyRequest
	 *            The web service request object
	 * @param UpsertPartyResponse
	 *            response object for web service
	 * @return Map<String, Object> a collection of entity-wise cleansePut
	 *         response values clubbed in PutResponseDataHolder object
	 * @throws ServiceProcessingException
	 */
	public void processCleansePutRequest(PartyXrefType upsertParty, MdmUpsertPartyResponse upsertResponse,boolean retry, boolean executeNextStpe, String rowidObject)
			throws ServiceProcessingException {

		LOG.info("Executing processCleansePutRequest()");
		SiperianClient siperianClient = null;
		UserTransaction transaction = null;

		PartyXrefType partyParam = upsertParty;
		PutResponseDataHolder putRespDataParty = null;
	//	List<PutResponseDataHolder> putRespDataProspectList = null;
		List<PutResponseDataHolder> putRespDataAddressList = null;
		List<PutResponseDataHolder> putRespDataCommunicationList = null;
		List<PutResponseDataHolder> putRespDataPartyPrsnList = null;
		Map<String, Object>  putRespDataHolderMap = new HashMap<String, Object>();

		try {
			siperianClient = (SiperianClient) checkOut();

			// create transaction - commit if cleansePut requests succeed for
			// Party and all the child entities
			transaction = ((EjbSiperianClient) siperianClient).createTX(300000);
			transaction.begin();

			lastUpdateDate = Util.getCurrentTimeZone();

			
			//getSipPop
			List<AddressXrefType> addressList = partyParam.getAddress();
			if (!CollectionUtils.isEmpty(addressList)) {
			getSipPop(addressList);
			}
			// Create Party
			putRespDataParty = cleansePutParty(partyParam, siperianClient);
			// Create Party Person
			List<PartyPersonXrefType> partyPersonXrefTypeList = partyParam.getPartyPerson();
			if (!CollectionUtils.isEmpty(partyPersonXrefTypeList)) {
				putRespDataPartyPrsnList = cleansePutPerson(partyPersonXrefTypeList, partyParam, siperianClient);
			}

			/*// Create Prospect
			List<AccountXrefType> prospectXrefTypeList = partyParam.getAccount();
			if (!CollectionUtils.isEmpty(prospectXrefTypeList)) {
				putRespDataProspectList = cleansePutProspect(prospectXrefTypeList, partyParam, siperianClient);
			}*/

			// Create Address
			if ((!Util.isNullOrEmpty(partyParam.getAddress().get(0).getADDRLN1()))) {
			List<AddressXrefType> addressXrefTypeList = partyParam.getAddress();
			if (!CollectionUtils.isEmpty(addressXrefTypeList)) {
				putRespDataAddressList = cleansePutAddress(addressXrefTypeList, partyParam, siperianClient);
			}
			}
			// Create Communication
			List<CommunicationXrefType> commXrefTypeList = partyParam.getCommunication();
			if (!CollectionUtils.isEmpty(commXrefTypeList)) {
				putRespDataCommunicationList = cleansePutCommunication(commXrefTypeList, partyParam, siperianClient);
			}

			

			LOG.info("Control back in processCleansePut().");

			// commit transaction
			transaction.commit();
			LOG.info("Transaction Commited in processCleansePut().");
			partyCount++;

			// set response status
			upsertResponse.setStatus(Util.isNullOrEmpty(upsertResponse.getStatus())? 
					"" : upsertResponse.getStatus() + "\n");
			upsertResponse.setStatus(upsertResponse.getStatus() + putRespDataParty.getActionType()
					+ " operation successful for Party " + putRespDataParty.getSourceKey());

		} catch (ServiceProcessingException excp) {
			upsertResponse.setErrorMsg(excp.getRootExceptionMsg());
			upsertParty.setErrorMsg("CleansePut operation failed");
			updateErrorStatus(upsertParty, upsertResponse, Constant.ERROR_CONTACT_CLEANSE_PUT_FAIL, "0");
			LOG.error("Exception occured while preparing/processing cleansePut requests: ", excp);
			try {
				transaction.rollback();

			} catch (SystemException txExcp) {
				LOG.error("Failed to rollback transaction for cleansePut requests : " + txExcp.toString());
			}
			throw excp;
		} catch (Exception ex) {
			upsertResponse.setErrorMsg("CleansePut operation failed for Party " + putRespDataParty.getSourceKey());
			upsertParty.setErrorMsg("CleansePut operation failed");
			updateErrorStatus(upsertParty, upsertResponse, Constant.ERROR_CONTACT_CLEANSE_PUT_FAIL, "0");
			LOG.error("Exception occured while preparing/processing cleansePut requests: ", ex);
			ex.printStackTrace();
			try {
				transaction.rollback();
			} catch (SystemException txExcp) {
				LOG.error("Failed to rollback transaction for cleansePut requests : " + txExcp.toString());
				txExcp.printStackTrace();
			}
			ServiceProcessingException customException = new ServiceProcessingException(ex);
			customException.setMessage("Failed to process cleansePut SIF request." + customException.getMessage());
			throw customException;
		} finally {
			checkIn(siperianClient);
		}
		try {
			// set rowid_object of created records into response and
			// set the PutResponseDataHolder object/list of object into Map
			// against corresponding entity name
			// set rowid_object of Party into response
			PartyUpsertRespType partyUpsertResp = new PartyUpsertRespType();
			List<Account> prospectList = new ArrayList<Account>();
			List<Address> addressList = new ArrayList<Address>();
			List<Communication> commList = new ArrayList<Communication>();
			List<PartyPerson> partyPersonList = new ArrayList<PartyPerson>();

			// set rowid_object of Party into response
			if (putRespDataParty != null) {
				partyUpsertResp.setROWIDOBJECT(putRespDataParty.getRowidObject());
				partyUpsertResp.setSRCSYSTEM(putRespDataParty.getSystemName());
				partyUpsertResp.setSRCSYSTEMID(putRespDataParty.getSourceKey());
				putRespDataHolderMap.put(MDMAttributeNames.ENTITY_PARTY, putRespDataParty);
			}

			/*// set rowid_object of Prospect into response
			if (!CollectionUtils.isEmpty(putRespDataProspectList)) {
				putRespDataHolderMap.put(MDMAttributeNames.ENTITY_PROSPECT, putRespDataProspectList);
				for (PutResponseDataHolder putRespDataProspect : putRespDataProspectList) {
					Account prospect = new Account();
					prospect.setROWIDACCOUNT(putRespDataProspect.getRowidObject());
					prospect.setSRCSYSTEM(putRespDataProspect.getSystemName());
					prospect.setSRCSYSTEMID(putRespDataProspect.getSourceKey());
					prospectList.add(prospect);
				}
			}*/

			// set rowid_object of Address into response
			if (!CollectionUtils.isEmpty(putRespDataAddressList)) {
				putRespDataHolderMap.put(MDMAttributeNames.ENTITY_ADDRESS, putRespDataAddressList);
				for (PutResponseDataHolder putRespDataAddress : putRespDataAddressList) {
					Address address = new Address();
					address.setROWIDADDRESS(putRespDataAddress.getRowidObject());
					address.setSRCSYSTEM(putRespDataAddress.getSystemName());
					address.setSRCSYSTEMID(putRespDataAddress.getSourceKey());
					addressList.add(address);
				}
			}

			// set rowid_object of Communication into response
			if (!CollectionUtils.isEmpty(putRespDataCommunicationList)) {
				putRespDataHolderMap.put(MDMAttributeNames.ENTITY_COMM, putRespDataCommunicationList);
				for (PutResponseDataHolder putRespDataCommunication : putRespDataCommunicationList) {
					Communication comm = new Communication();
					comm.setROWIDCOMMUNICATION(putRespDataCommunication.getRowidObject());
					comm.setSRCSYSTEM(putRespDataCommunication.getSystemName());
					comm.setSRCSYSTEMID(putRespDataCommunication.getSourceKey());
					commList.add(comm);
				}
			}
			// set rowid_object of Person into response
			if (!CollectionUtils.isEmpty(putRespDataPartyPrsnList)) {
				putRespDataHolderMap.put(MDMAttributeNames.ENTITY_PARTY_PRSN, putRespDataPartyPrsnList);
				for (PutResponseDataHolder putRespDataPartyPrsn : putRespDataPartyPrsnList) {
					PartyPerson partyPerson = new PartyPerson();
					partyPerson.setROWIDPERSON(putRespDataPartyPrsn.getRowidObject());
					partyPerson.setSRCSYSTEM(putRespDataPartyPrsn.getSystemName());
					partyPerson.setSRCSYSTEMID(putRespDataPartyPrsn.getSourceKey());
					partyPersonList.add(partyPerson);
				}
			}
			partyUpsertResp.getAddress().addAll(addressList);
			partyUpsertResp.getCommunication().addAll(commList);
			partyUpsertResp.getPartyPerson().addAll(partyPersonList);
			upsertResponse.getParty().add(partyUpsertResp);
		} catch (Exception excp) {
			LOG.error("Exception occured while processing CleansePut response for Party "
					+ putRespDataParty.getSourceKey(), excp);
			ServiceProcessingException customException = new ServiceProcessingException(excp);
			customException.setMessage("Exception occured while processing CleansePut response for Party. "
					+ customException.getMessage());
		}

	
		
		if(executeNextStpe)
			upsertTokenize(upsertParty,upsertResponse,true, true,rowidObject);
		

		LOG.info("Executed processCleansePutRequest()");
		return ;
	}

	/**
	 * The method prepares and executes CleansePutRequest on PARTY landing table
	 * for the given Party profile.
	 *
	 * @param partyParam
	 *            Party profile provided to the web service request
	 * @param siperianClient
	 *            SiperianClient SIF connection to MDM Hub
	 * @return PutResponseDataHolder object containing processing results
	 * @throws ServiceProcessingException
	 */
	private PutResponseDataHolder cleansePutParty(PartyXrefType partyParam, SiperianClient siperianClient) throws ServiceProcessingException {
		LOG.info("Executing cleansePutParty()");
		int itemIndex = 0;
		CleansePutRequest cleansePutRequest = new CleansePutRequest();
		CleansePutResponse cleansePutResponse = null;
		PutResponseDataHolder responseDataHolder = null;
		Calendar cal = null;
		try {
		
			// prepare CleansePutRequest
			Record record = new Record();
			// set mapping name
			record.setSiperianObjectUid(Util.getMappingObjectUid(partyParam.getXREF().get(itemIndex).getSRCSYSTEM(), MDMAttributeNames.ENTITY_PARTY));
			// set input values
			if (partyParam.getLASTUPDATEDATE() != null && partyParam.getLASTUPDATEDATE().length() > 0) {
				/*cal = convertStringToCalendar(partyParam.getLASTUPDATEDATE());
				record.setField(new Field(MDMAttributeNames.LAST_UPDATE_DATE, cal.getTime())); */
				record.setField(new Field(MDMAttributeNames.LAST_UPDATE_DATE, partyParam.getLASTUPDATEDATE()));
			} else {
				LOG.info("Performing cleansePutParty with sysdate from HUB: " + lastUpdateDate);
				record.setField(new Field(MDMAttributeNames.LAST_UPDATE_DATE, lastUpdateDate));
			}
			
			if (partyParam.getSRCCREATEDT() != null && partyParam.getSRCCREATEDT().length() > 0) {
			/*cal = convertStringToCalendar(partyParam.getSRCCREATEDT());
			record.setField(new Field(MDMAttributeNames.SRC_CREATE_DT, cal.getTime())); */
			record.setField(new Field(MDMAttributeNames.SRC_CREATE_DT, partyParam.getSRCCREATEDT()));
			}
			record.setField(new Field(MDMAttributeNames.SRC_UPDT_BY, partyParam.getUPDATEBY()));
			record.setField(new Field(MDMAttributeNames.SRC_SYSTEM, (partyParam.getXREF().get(itemIndex)).getSRCSYSTEM()));
			record.setField(new Field(MDMAttributeNames.SRC_SYS_KEY, (partyParam.getXREF().get(itemIndex)).getSRCPKEY()));
			if (!Util.isNullOrEmpty(partyParam.getROWIDOBJECT())) {
				record.setField(new Field(MDMAttributeNames.ROWID_OBJECT, partyParam.getROWIDOBJECT()));
			}
			record.setField(new Field(PartyAttributes.ENTITY_TYPE, partyParam.getBOCLASSCODE()));
			record.setField(new Field(PartyAttributes.PARTY_NAME, partyParam.getPARTYNAME()));
			record.setField(new Field(PartyAttributes.PARTY_TYPE, partyParam.getPARTYTYPE()));
			record.setField(new Field(PartyAttributes.GEO, partyParam.getGEO()));
			record.setField(new Field(PartyAttributes.REGION, partyParam.getREGION()));
			record.setField(new Field(PartyAttributes.SALES_BLOCK_CD, partyParam.getSALESBLOCKCD()));
			record.setField(new Field(PartyAttributes.TAX_JURSDCTN_CD, partyParam.getTAXJURSDCTNCD()));
			record.setField(new Field(PartyAttributes.VAT_REG_NBR, partyParam.getVATREGNBR()));
			if (partyParam.getXREF().get(itemIndex).getSRCSYSTEM().equalsIgnoreCase("SAP")) {
				String statusCd = null;
				if (!Util.isNullOrEmpty(partyParam.getSTATUSCD()) && partyParam.getSTATUSCD().equalsIgnoreCase("X")) {
					record.setField(new Field(PartyAttributes.STATUS_CD, statusCd));
				} else {
					record.setField(new Field(PartyAttributes.STATUS_CD, "X"));
				}
			} else {
				record.setField(new Field(PartyAttributes.STATUS_CD, partyParam.getSTATUSCD()));
			}

			// record.setField(new Field(MDMAttributeNames.PARTY.STATUS_CD,
			// partyParam.getSTATUSCD()));
			if(!Util.isNullOrEmpty(partyParam.getUCN()))	{
				record.setField(new Field(PartyAttributes.UCN, partyParam.getUCN()));
			}
			if(!Util.isNullOrEmpty(sipPopVal))	{
			record.setField(new Field(PartyAttributes.COUNTRY_CD, sipPopVal));
			}
			record.setField(new Field(PartyAttributes.ENGLISH_NAME, partyParam.getENGLISHNAME()));
			/** changes for Sales Force Integration -Start */
			
			record.setField(new Field(PartyAttributes.MSG_TRKN_ID, partyParam.getMSGTRKNID()));
			
			/** changes for Sales Force Integration -End */
			cleansePutRequest.setRecord(record);
			// execute Put request
			cleansePutResponse = (CleansePutResponse) siperianClient.process(cleansePutRequest);
			LOG.info("Party cleansePut request processed successfully: " + cleansePutResponse.getMessage());
			// extract result
			RecordKey recordKey = cleansePutResponse.getRecordKey();

			responseDataHolder = new PutResponseDataHolder();
			responseDataHolder.setActionType(cleansePutResponse.getActionType());
			responseDataHolder.setActionMessage(cleansePutResponse.getMessage());
			responseDataHolder.setRowidObject(recordKey.getRowid());
			responseDataHolder.setRowidXREF(recordKey.getRowidXref());
			responseDataHolder.setSourceKey(recordKey.getSourceKey());
			responseDataHolder.setSystemName(recordKey.getSystemName());
			LOG.info("ROWID_OBJECT of created Party record = " + recordKey.getRowid());

			LOG.debug("Action Type = " + responseDataHolder.getActionType());
			LOG.debug("Action Msg = " + responseDataHolder.getActionMessage());
			LOG.debug("Rowid_xref = " + responseDataHolder.getRowidXREF());
			LOG.debug("Src key = " + responseDataHolder.getSourceKey());
			LOG.debug("System = " + responseDataHolder.getSystemName());

		} catch (SiperianServerException sifExcp) {
			LOG.error("SiperianServerException occured while processing CleansePutRequest for Party: ", sifExcp);
			LOG.error("Get Message: " + sifExcp.getMessage());
			LOG.error("sifExcp msg " + sifExcp);
			sifExcp.printStackTrace();
			ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
			customException.setRootExceptionMsg(sifExcp + " CleansePut operation failed for Party " + (partyParam.getXREF().get(itemIndex)).getSRCPKEY());
			customException.setMessage("SIF exception occured while processing Put request for Party." + customException.getMessage());
			throw customException;
		} catch (Exception excp) {
			LOG.error("Exception occured while processing CleansePutRequest for Party: ", excp);
			LOG.error("excp msg " + excp);
			ServiceProcessingException customException = new ServiceProcessingException(excp);
			customException.setMessage("Exception occured while processing Put request for Party." + customException.getMessage());
			customException.setRootExceptionMsg(excp + " CleansePut operation failed for Party " + (partyParam.getXREF().get(itemIndex)).getSRCPKEY());
			throw customException;
		}

		LOG.info("Executed cleansePutParty()");
		return responseDataHolder;
	}
	/**
	 * The method prepares and executes CleansePutRequest on PERSON
	 * landing table for the given Communication profiles.
	 *
	 * @param personList
	 *            List of Person provided to the web service request
	 * @param partyParam
	 *            Party profile provided to the web service request
	 * @param siperianClient
	 *            SiperianClient SIF connection to MDM Hub
	 * @return List of PutResponseDataHolder object containing processing
	 *         results
	 * @throws ServiceProcessingException
	 */
	private List<PutResponseDataHolder> cleansePutPerson(List<PartyPersonXrefType> personList, PartyXrefType partyParam,
			SiperianClient siperianClient) throws ServiceProcessingException {
		LOG.info("Executing cleansePutPerson()");
		CleansePutRequest cleansePutRequest = null;
		CleansePutResponse cleansePutResponse = null;
		List<PutResponseDataHolder> responseDataHolderList = new ArrayList<PutResponseDataHolder>(personList.size());
		for (PartyPersonXrefType personParam : personList) {
			try {
				cleansePutRequest = new CleansePutRequest();
				// prepare CleansePutRequest
				Record record = new Record();
				// set mapping name
				record.setSiperianObjectUid(
						Util.getMappingObjectUid(personParam.getSRCSYSTEM(), MDMAttributeNames.ENTITY_PARTY_PRSN));
				// set input values
				if (partyParam.getLASTUPDATEDATE() != null && partyParam.getLASTUPDATEDATE().length() > 0) {
					record.setField(new Field(MDMAttributeNames.LAST_UPDATE_DATE, partyParam.getLASTUPDATEDATE()));
				} else {
					LOG.info("Performing cleansePutPerson with sysdate from HUB: " + lastUpdateDate);
					record.setField(new Field(MDMAttributeNames.LAST_UPDATE_DATE, lastUpdateDate));
				}
				record.setField(new Field(PartyPersonAttributes.SRC_UPD_BY, personParam.getUPDATEBY()));
				record.setField(new Field(MDMAttributeNames.SRC_SYSTEM, personParam.getSRCSYSTEM()));
				record.setField(new Field(MDMAttributeNames.SRC_SYS_KEY, personParam.getSRCPKEY()));

				record.setField(new Field(PartyPersonAttributes.PREFIX, personParam.getPREFIX()));

				record.setField(new Field(PartyPersonAttributes.FIRST_NAME, personParam.getFIRSTNAME()));
				record.setField(new Field(PartyPersonAttributes.MIDDLE_NAME, personParam.getMIDDLENAME()));
				record.setField(new Field(PartyPersonAttributes.LAST_NAME, personParam.getLASTNAME()));
				record.setField(new Field(PartyPersonAttributes.SUFFIX, personParam.getSUFFIX()));
				record.setField(new Field(PartyPersonAttributes.JOB_TITLE, personParam.getJOBTITLE()));
				record.setField(new Field(PartyPersonAttributes.JOB_FUNCTION, personParam.getJOBFUNCTION()));
				record.setField(new Field(PartyPersonAttributes.PERSON_STATUS, personParam.getPERSONSTATUS()));
				// record.setField(new Field(
				// PartyPersonAttributes.SAP_INTEGRATION_ID, personParam));
				record.setField(new Field(PartyPersonAttributes.PERSON_TYPE, personParam.getPERSONTYPE()));
				record.setField(new Field(PartyPersonAttributes.PREF_LANGUAGE, personParam.getPREFLANGUAGE()));
				record.setField(new Field(PartyPersonAttributes.LIST_SOURCE, personParam.getLISTSOURCE()));
				record.setField(new Field(PartyPersonAttributes.DATA_SRC_SYS, personParam.getDATASOURCESYSTEM()));
				record.setField(new Field(PartyPersonAttributes.LATTICE_SCORE, personParam.getLATTICESCORE()));
				record.setField(new Field(PartyPersonAttributes.JOB_LEVEL, personParam.getJOBLEVEL()));
				record.setField(
						new Field(MDMAttributeNames.PARTY_SRC_SYS_KEY, partyParam.getXREF().get(0).getSRCPKEY()));
				/** changes for Track-4 -Start */
				record.setField(new Field(PartyPersonAttributes.SRC_ACCOUNT_ID, personParam.getSRCACCOUNTID()));
				record.setField(new Field(PartyPersonAttributes.JOB_ROLE, personParam.getJOBROLE()));
				record.setField(new Field(PartyPersonAttributes.PARTNER_CONTACT_FLG, personParam.getPARTNERCONTACTFLG()));
				record.setField(new Field(PartyPersonAttributes.CLEANSE_IND, personParam.getCLEANSEIND()));
				/** changes for Track-4 -End */

				cleansePutRequest.setRecord(record);
				// execute Put request
				cleansePutResponse = (CleansePutResponse) siperianClient.process(cleansePutRequest);
				LOG.info("Party_Person cleansePut request processed successfully: " + cleansePutResponse.getMessage());
				// extract result
				RecordKey recordKey = cleansePutResponse.getRecordKey();

				PutResponseDataHolder responseDataHolder = new PutResponseDataHolder();
				responseDataHolder.setActionType(cleansePutResponse.getActionType());
				responseDataHolder.setActionMessage(cleansePutResponse.getMessage());
				responseDataHolder.setRowidObject(recordKey.getRowid());
				responseDataHolder.setRowidXREF(recordKey.getRowidXref());
				responseDataHolder.setSourceKey(recordKey.getSourceKey());
				responseDataHolder.setSystemName(recordKey.getSystemName());
				responseDataHolderList.add(responseDataHolder);
				LOG.info("ROWID_OBJECT of created Party_Person record = " + recordKey.getRowid());
				LOG.debug("Action Type = " + responseDataHolder.getActionType());
				LOG.debug("Action Msg = " + responseDataHolder.getActionMessage());
			} catch (SiperianServerException sifExcp) {
				LOG.error("SiperianServerException occured while processing CleansePutRequest for Party_Person: "
						+ sifExcp);
				LOG.error("sifExcp msg " + sifExcp);
				ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
				customException.setMessage("SIF exception occured while processing Put request for Party_Person. "
						+ customException.getMessage());
				customException.setRootExceptionMsg(
						sifExcp + " CleansePut operation failed for Party_Person " + personParam.getSRCPKEY());
				sifExcp.printStackTrace();
				throw customException;
			} catch (Exception excp) {
				LOG.error("Exception occured while processing CleansePutRequest for Party_Person: " + excp);
				excp.printStackTrace();
				ServiceProcessingException customException = new ServiceProcessingException(excp);
				customException.setMessage("Exception occured while processing Put request for Party_Person. "
						+ customException.getMessage());
				customException.setRootExceptionMsg(
						excp + " CleansePut operation failed for Party_Person " + personParam.getSRCPKEY());
				excp.printStackTrace();
				throw customException;
			}
		}

		LOG.info("Executed cleansePutPerson()");
		return responseDataHolderList;
	}
	

	/**
	 * The method prepares and executes CleansePutRequest on ADDRESS landing
	 * table for the given Address profiles.
	 *
	 * @param addressList
	 *            List of Addresses provided to the web service request
	 * @param partyParam
	 *            Party profile provided to the web service request
	 * @param siperianClient
	 *            SiperianClient SIF connection to MDM Hub
	 * @return List of PutResponseDataHolder object containing processing
	 *         results
	 * @throws ServiceProcessingException
	 */
	private List<PutResponseDataHolder> cleansePutAddress(List<AddressXrefType> addressList, PartyXrefType partyParam, SiperianClient siperianClient) throws ServiceProcessingException {
		LOG.info("Executing cleansePutAddress()");
		int itemIndex = 0;
		CleansePutRequest cleansePutRequest = null;
		CleansePutResponse cleansePutResponse = null;
		
		List<PutResponseDataHolder> responseDataHolderList = new ArrayList<PutResponseDataHolder>(addressList.size());
		AddressXrefType addressParam = null;

		try {
			for (itemIndex = 0; itemIndex < addressList.size(); itemIndex++) {
				cleansePutRequest = new CleansePutRequest();
				addressParam = addressList.get(itemIndex);
				String putFlag = "Y";
				// prepare CleansePutRequest
				Record record = new Record();
				// set mapping name
				record.setSiperianObjectUid(Util.getMappingObjectUid(addressParam.getSRCSYSTEM(), MDMAttributeNames.ENTITY_ADDRESS));
				// set input values
				if (partyParam.getLASTUPDATEDATE() != null && partyParam.getLASTUPDATEDATE().length() > 0) {
					record.setField(new Field(MDMAttributeNames.LAST_UPDATE_DATE, partyParam.getLASTUPDATEDATE()));
				} else {
					LOG.info("Performing cleansePutAddress with sysdate from HUB: " + lastUpdateDate);
					record.setField(new Field(MDMAttributeNames.LAST_UPDATE_DATE, lastUpdateDate));
				}
				record.setField(new Field(MDMAttributeNames.SRC_UPDT_BY, addressParam.getUPDATEBY()));
				record.setField(new Field(MDMAttributeNames.SRC_SYSTEM, addressParam.getSRCSYSTEM()));
				record.setField(new Field(MDMAttributeNames.SRC_SYS_KEY, addressParam.getSRCPKEY()));
				record.setField(new Field(AddressAttributes.ADDR_LN1, addressParam.getADDRLN1()));
				record.setField(new Field(AddressAttributes.ADDR_LN2, addressParam.getADDRLN2()));
				record.setField(new Field(AddressAttributes.ADDR_LN3, addressParam.getADDRLN3()));
				record.setField(new Field(AddressAttributes.ADDR_LN4, addressParam.getADDRLN4()));
				if (addressParam.getSRCSYSTEM().equalsIgnoreCase("SAP")) {
					String addrStatus = null;
					if (!Util.isNullOrEmpty(addressParam.getADDRSTATUS()) && addressParam.getADDRSTATUS().equalsIgnoreCase("X")) {
						record.setField(new Field(AddressAttributes.ADDR_STATUS, addrStatus));
					} else {
						record.setField(new Field(AddressAttributes.ADDR_STATUS, "X"));
					}
				} else {
					record.setField(new Field(AddressAttributes.ADDR_STATUS, addressParam.getADDRSTATUS()));
				}

				// record.setField(new
				// Field(MDMAttributeNames.ADDRESS.ADDR_STATUS,
				// addressParam.getADDRSTATUS()));
				// if (addressParam.getADDRTYPE() == null) {
				record.setField(new Field(AddressAttributes.ADDR_TYPE, Constant.ADDRESS_TYPE_MAILING));
				// }
				record.setField(new Field(AddressAttributes.CITY, addressParam.getCITY()));
				LOG.debug("addressParam.getCOUNTRYCD(): " + addressParam.getCOUNTRYCD());
				record.setField(new Field(AddressAttributes.COUNTRY_CD, addressParam.getCOUNTRYCD()));
				record.setField(new Field(AddressAttributes.COUNTY, addressParam.getCOUNTY()));
				record.setField(new Field(AddressAttributes.DISTRICT, addressParam.getDISTRICT()));
				record.setField(new Field(AddressAttributes.LANG_CD, addressParam.getLANGCD()));
				record.setField(new Field(AddressAttributes.LATITUDE, addressParam.getLATITUDE()));
				record.setField(new Field(AddressAttributes.LONGITUDE, addressParam.getLONGITUDE()));
				record.setField(new Field(AddressAttributes.POSTAL_CD, addressParam.getPOSTALCD()));
				LOG.debug("addressParam.getSTATECD(): " + addressParam.getSTATECD());
				record.setField(new Field(AddressAttributes.STATE_CD, addressParam.getSTATECD()));
				record.setField(new Field(MDMAttributeNames.PARTY_SRC_SYS_KEY, partyParam.getXREF().get(0).getSRCPKEY()));
				record.setField(new Field(AddressAttributes.ADDRESS_QUALITY_IDENTIFIER, addressParam.getADDRESSQUALITYIDENTIFIER()));
				// Added for SFDC Integration-- Start
				//record.setField(new Field(AddressAttributes.ADDRESS_DRAFT_FLAG, partyParam.getAccount().get(0).getDraftAccountFlag()));
				/*if(!Util.isNullOrEmpty(partyParam.getAccount().get(0).getPARTNERSHIPSTATUS()))	{
				record.setField(new Field(PartyAttributes.PARTNERSHIP_STATUS, partyParam.getAccount().get(0).getPARTNERSHIPSTATUS()));
				}*/
				// Added for SFDC Integration-- End
				cleansePutRequest.setRecord(record);
				// execute Put request
				LOG.debug("Incoming Address Type" + addressParam.getADDRTYPE());
				 if ((!Util.isNullOrEmpty(addressParam.getADDRTYPE())) && (addressParam.getADDRTYPE().equals("Account_Address"))) {
					 putFlag = "N";
				 }
				 LOG.debug("putFlag" + putFlag);
				if (putFlag.equals("Y")){
					
				cleansePutResponse = (CleansePutResponse) siperianClient.process(cleansePutRequest);
				
				LOG.info("Address cleansePut request processed successfully: " + cleansePutResponse.getMessage());
				// extract result
				RecordKey recordKey = cleansePutResponse.getRecordKey();

				PutResponseDataHolder responseDataHolder = new PutResponseDataHolder();
				responseDataHolder.setActionType(cleansePutResponse.getActionType());
				responseDataHolder.setActionMessage(cleansePutResponse.getMessage());
				responseDataHolder.setRowidObject(recordKey.getRowid());
				responseDataHolder.setRowidXREF(recordKey.getRowidXref());
				responseDataHolder.setSourceKey(recordKey.getSourceKey());
				responseDataHolder.setSystemName(recordKey.getSystemName());
				responseDataHolderList.add(responseDataHolder);
				LOG.info("ROWID_OBJECT of created Address record = " + recordKey.getRowid());
				LOG.debug("Action Type = " + responseDataHolder.getActionType());
				LOG.debug("Action Msg = " + responseDataHolder.getActionMessage());
				 }
			}
		} catch (SiperianServerException sifExcp) {
			LOG.error("SiperianServerException occured while processing CleansePutRequest for Address: " + sifExcp);
			sifExcp.printStackTrace();
			ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
			customException.setMessage("SIF exception occured while processing Put request for Address. " + customException.getMessage());
			customException.setRootExceptionMsg(sifExcp + " CleansePut operation failed for Address " + addressParam.getSRCPKEY());
			throw customException;
		} catch (Exception excp) {
			LOG.error("Exception occured while processing CleansePutRequest for Address: " + excp);
			excp.printStackTrace();
			ServiceProcessingException customException = new ServiceProcessingException(excp);
			customException.setMessage("Exception occured while processing Put request for Address. " + customException.getMessage());
			customException.setRootExceptionMsg(excp + " CleansePut operation failed for Address " + addressParam.getSRCPKEY());
			throw customException;
		}

		LOG.info("Executed cleansePutAddress()");
		return responseDataHolderList;
	}

	/**
	 * The method prepares and executes CleansePutRequest on COMMUNICATION
	 * landing table for the given Communication profiles.
	 *
	 * @param commList
	 *            List of Communications provided to the web service request
	 * @param partyParam
	 *            Party profile provided to the web service request
	 * @param siperianClient
	 *            SiperianClient SIF connection to MDM Hub
	 * @return List of PutResponseDataHolder object containing processing
	 *         results
	 * @throws ServiceProcessingException
	 */
	private List<PutResponseDataHolder> cleansePutCommunication(List<CommunicationXrefType> commList, PartyXrefType partyParam, SiperianClient siperianClient) throws ServiceProcessingException {
		LOG.info("Executing cleansePutCommunication()");
		int itemIndex = 0;
		CleansePutRequest cleansePutRequest = null;
		CleansePutResponse cleansePutResponse = null;
		List<PutResponseDataHolder> responseDataHolderList = new ArrayList<PutResponseDataHolder>(commList.size());
		CommunicationXrefType commParam = null;

		try {
			for (itemIndex = 0; itemIndex < commList.size(); itemIndex++) {
				cleansePutRequest = new CleansePutRequest();
				commParam = commList.get(itemIndex);
				// prepare CleansePutRequest
				Record record = new Record();
				// set mapping name
				record.setSiperianObjectUid(Util.getMappingObjectUid(commParam.getSRCSYSTEM(), MDMAttributeNames.ENTITY_COMM));
				// set input values
				if (partyParam.getLASTUPDATEDATE() != null && partyParam.getLASTUPDATEDATE().length() > 0) {
					record.setField(new Field(MDMAttributeNames.LAST_UPDATE_DATE, partyParam.getLASTUPDATEDATE()));
				} else {
					LOG.info("Performing cleansePutCommunication with sysdate from HUB: " + lastUpdateDate);
					record.setField(new Field(MDMAttributeNames.LAST_UPDATE_DATE, lastUpdateDate));
				}
				record.setField(new Field(MDMAttributeNames.SRC_UPDT_BY, commParam.getUPDATEBY()));
				record.setField(new Field(MDMAttributeNames.SRC_SYSTEM, commParam.getSRCSYSTEM()));
				record.setField(new Field(MDMAttributeNames.SRC_SYS_KEY, commParam.getSRCPKEY()));
				if (commParam.getSRCSYSTEM().equalsIgnoreCase("SAP")) {
					String commStatus = null;
					if (!Util.isNullOrEmpty(commParam.getCOMMSTATUS()) && commParam.getCOMMSTATUS().equalsIgnoreCase("X")) {
						record.setField(new Field(CommunicationAttributes.COMM_STATUS, commStatus));
					} else {
						record.setField(new Field(CommunicationAttributes.COMM_STATUS, "X"));
					}
				} else {
					record.setField(new Field(CommunicationAttributes.COMM_STATUS, commParam.getCOMMSTATUS()));
				}

				// record.setField(new
				// Field(MDMAttributeNames.COMMUNICATION.COMM_STATUS,
				// commParam.getCOMMSTATUS()));
				if (commParam.getCOMMTYPE() != null && commParam.getCOMMTYPE().length() > 0) {
					record.setField(new Field(CommunicationAttributes.COMM_TYPE, commParam.getCOMMTYPE()));
				}
				record.setField(new Field(CommunicationAttributes.COMM_VALUE, commParam.getCOMMVALUE()));
				record.setField(new Field(CommunicationAttributes.COMM_EXTN, commParam.getCOMMEXTN()));
				record.setField(new Field(CommunicationAttributes.PRFRD_COMM_IND, commParam.getPRFRDCOMMIND()));
				record.setField(new Field(CommunicationAttributes.WEB_DOMAIN, commParam.getWEBDOMAIN()));
				record.setField(new Field(MDMAttributeNames.PARTY_SRC_SYS_KEY, partyParam.getXREF().get(0).getSRCPKEY()));
				// Added for SFDC Integration-- Start
				//record.setField(new Field(CommunicationAttributes.COMM_DRAFT_FLAG, partyParam.getAccount().get(0).getDraftAccountFlag()));
				record.setField(new Field(CommunicationAttributes.COMM_SALES_PREF, commParam.getCOMMSALESPREF()));
				// Added for SFDC Integration-- End
				cleansePutRequest.setRecord(record);
				// execute Put request
				cleansePutResponse = (CleansePutResponse) siperianClient.process(cleansePutRequest);
				LOG.info("Communication cleansePut request processed successfully: " + cleansePutResponse.getMessage());
				// extract result
				RecordKey recordKey = cleansePutResponse.getRecordKey();

				PutResponseDataHolder responseDataHolder = new PutResponseDataHolder();
				responseDataHolder.setActionType(cleansePutResponse.getActionType());
				responseDataHolder.setActionMessage(cleansePutResponse.getMessage());
				responseDataHolder.setRowidObject(recordKey.getRowid());
				responseDataHolder.setRowidXREF(recordKey.getRowidXref());
				responseDataHolder.setSourceKey(recordKey.getSourceKey());
				responseDataHolder.setSystemName(recordKey.getSystemName());
				responseDataHolderList.add(responseDataHolder);
				LOG.info("ROWID_OBJECT of created Communication record = " + recordKey.getRowid());
				LOG.debug("Action Type = " + responseDataHolder.getActionType());
				LOG.debug("Action Msg = " + responseDataHolder.getActionMessage());
			}
		} catch (SiperianServerException sifExcp) {
			LOG.error("SiperianServerException occured while processing CleansePutRequest for Communication: " + sifExcp);
			LOG.error("sifExcp msg " + sifExcp);
			ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
			customException.setMessage("SIF exception occured while processing Put request for Communication. " + customException.getMessage());
			customException.setRootExceptionMsg(sifExcp + " CleansePut operation failed for Communication " + commParam.getSRCPKEY());
			sifExcp.printStackTrace();
			throw customException;
		} catch (Exception excp) {
			LOG.error("Exception occured while processing CleansePutRequest for Communication: " + excp);
			excp.printStackTrace();
			ServiceProcessingException customException = new ServiceProcessingException(excp);
			customException.setMessage("Exception occured while processing Put request for Communication. " + customException.getMessage());
			customException.setRootExceptionMsg(excp + " CleansePut operation failed for Communication " + commParam.getSRCPKEY());
			excp.printStackTrace();
			throw customException;
		}

		LOG.info("Executed cleansePutCommunication()");
		return responseDataHolderList;
	}


	
	/* Perform Match & Merge operation for each Contact Record */
	// HashMap<Integer, HighestScoreRecordHolder>
	public HashMap<Integer, HighestScoreRecordHolder> processMatchAndMergeContact(String newPartyRowid,
			PartyXrefType partyTypeParam, SiperianClient siperianClient) throws ServiceProcessingException {

		LOG.info("Executing processMatchAndMergeContact()");
																					
		HighestScoreRecordHolder highestScoreRecordHolder = null;
		int matchCountOfRetry = Integer.parseInt(configProps.getProperty("NoOfRetries"));
		boolean isMatchRetrySuccess = false;
		List searchRecords = new ArrayList();

		HashMap<Integer, HighestScoreRecordHolder> highestScoreRecordHolderMap = new HashMap<Integer, HighestScoreRecordHolder>();
		List<Object> tempkeyList = new ArrayList<Object>();

		HighestScoreRecordHolder finalMatchedRecord = new HighestScoreRecordHolder();

		try {

			try {

				
				
				try {
					searchRecords = matchContact(partyTypeParam, siperianClient);
		//			throw new ServiceProcessingException("SearchMatchRequest on Contact threw Exception !!");
					LOG.debug("Contact SearchMatch is successful !!");
					
				} catch (Exception sifExcp) {
					matchInd = false;
					LOG.error("Exception occured while processing SearchMatchRequest on Contact: " , sifExcp);
					for(int i = 0; i<matchCountOfRetry; i++)	{
						try{
							LOG.debug("Retrying SearchMatchRequest Contact process for "+ (i+1) +"th time");
							searchRecords = matchContact(partyTypeParam, siperianClient);
							LOG.debug("SearchMatchRequest on Contact is successful on attempt no. "+ (i+1));
							isMatchRetrySuccess = true;
							matchInd = true;
							break;
						} catch (Exception ex) {
							LOG.error("Exception occured in SearchMatchRequest[Contact] RetryMechanism on attempt no. "+ (i+1));
							LOG.error("Exception occured in SearchMatchRequest[Contact] RetryMechanism on PARTY_BO");
						}
					}
					if(!isMatchRetrySuccess){
						ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
						customException.setMessage("Exception occured in SearchMatchRequest[Contact]"
								+ " RetryMechanism on PARTY_BO: " + customException.getMessage());
						throw customException;
					}
				} 
				
				// Store Match Score
				HashMap<Integer, Integer> matchScoreMap = new HashMap<Integer, Integer>();
				List<Integer> resultMatchScoreList = null;
				List<Integer> rowidList = null;

				if (searchRecords != null && searchRecords.size() > 0) {
					for (Iterator iter = searchRecords.iterator(); iter.hasNext();) {
						Record record = (Record) iter.next();
						highestScoreRecordHolder = null;
						String recRowid = record.getField("ROWID_OBJECT").getStringValue().trim();
						LOG.debug("Source PARTY_ROWID " + newPartyRowid);
						// Excluding self-matching record
						if (!recRowid.equals(newPartyRowid.trim())) {
							int rowidKey = Integer.parseInt(recRowid);

							if (!highestScoreRecordHolderMap.containsKey(rowidKey)) {

								LOG.debug("Populate highestScoreRecordHolderMap for matched PARTY_ROWID " + recRowid);
								highestScoreRecordHolderMap.put(rowidKey, new HighestScoreRecordHolder());
							}

							highestScoreRecordHolder = highestScoreRecordHolderMap.get(rowidKey);

							if (record.getField("ROWID_OBJECT").getStringValue() != null) {
								highestScoreRecordHolder
										.setPartyRowIDObject(record.getField("ROWID_OBJECT").getStringValue().trim());
							}
							if (record.getField("PERSON_ROWID_OBJECT").getStringValue() != null) {
								highestScoreRecordHolder
										.setRowidPerson(record.getField("PERSON_ROWID_OBJECT").getStringValue().trim());
							}
							if (record.getField("ROWID_COMMUNICATION").getStringValue() != null) {
								// highestScoreRecordHolder.setRowidCommunication(record.getField("ROWID_COMMUNICATION").getStringValue().trim());
								// comm = new CommunicationType();
								// comm.setCOMMTYPE(record.getField("COMM_TYPE").getStringValue());
								highestScoreRecordHolder.getCommMap().put(
										record.getField("ROWID_COMMUNICATION").getStringValue().trim(),
										record.getField("COMM_TYPE").getStringValue());
							}
							if (record.getField("ROWID_ADDRESS").getStringValue() != null) {
								highestScoreRecordHolder.getAddrMap().put(
										record.getField("ROWID_ADDRESS").getStringValue().trim(),
										record.getField("ADDR_TYPE").getStringValue());
								// highestScoreRecordHolder.setRowidAddress(record.getField("ROWID_ADDRESS").getStringValue().trim());
							}
							// Populate Match Score Map
							String mtchScore = record.getField("MATCH_SCORE").getValue().toString().trim();
							int mtchValue = Integer.parseInt(mtchScore);
							LOG.info("MatchScoreMap rowid_object :" + rowidKey + " scoreValue :" + mtchValue);
							matchScoreMap.put(rowidKey, mtchValue);

							// highestScoreRecordHolderMap.put(rowidKey,highestScoreRecordHolder);
						} else {
							LOG.debug("Self Matching record found with rowidOb: " + recRowid);
						}
					}
					// }
					// Variables for tie-breaker
					int highestScore = 0;
					int olderRowid = 0;
					// HighestScoreRecordHolder finalMatchedRecord = null;

					if (matchScoreMap != null && matchScoreMap.size() > 0) {
						if (matchScoreMap.size() > 1) {
							highestScore = highestMatchScore(matchScoreMap);

							int matchScoreThreshold = Integer.parseInt(configProps.getProperty("matchScore-Threshold"));

							if (matchScoreThreshold > highestScore) {
								LOG.info(" Highest Match Score of MatchedRecords is smaller than ThresholdValue");
								return null;
								// return false;
							} else {
								matchInd = true;

								// Method invocation for fetching Records/Rowids
								// with
								// Highest Match Score
								if (matchScoreMap != null && matchScoreMap.size() > 0) {
									resultMatchScoreList = maxMatchScore(matchScoreMap);
								}
								// If Multiple Records/Rowids have Highest Match
								// Score
								if ((resultMatchScoreList != null && resultMatchScoreList.size() > 0)
										&& (highestScoreRecordHolderMap.size() > 1)) {

									// Removing Lower MatchScore Records
									for (Entry<Integer, HighestScoreRecordHolder> entry : highestScoreRecordHolderMap
											.entrySet()) {
										if (!resultMatchScoreList.contains(entry.getKey())) {
											LOG.info("Removing Record with RowID: " + entry.getKey());
											tempkeyList.add(entry.getKey());
										}
									}
									for (Object obj : tempkeyList) {
										highestScoreRecordHolderMap.remove(obj);
									}
									tempkeyList.clear();

									// If Multiple Records in HolderMap after
									// Removing Lower MatchScores
									if (highestScoreRecordHolderMap.size() > 1) {
										// Collection<Integer> rowidSet =
										// highestScoreRecordHolderMap.keySet();
										olderRowid = Collections.min(highestScoreRecordHolderMap.keySet());

										LOG.debug("Oldest RowidObject value is: " + olderRowid);

										// Removing Higher RowidObject Records
										for (Entry<Integer, HighestScoreRecordHolder> entry : highestScoreRecordHolderMap
												.entrySet()) {
											if (olderRowid != entry.getKey()) {
												LOG.info("Removing Record with RowID: " + entry.getKey());
												tempkeyList.add(entry.getKey());
											}
										}
										for (Object obj : tempkeyList) {
											highestScoreRecordHolderMap.remove(obj);
										}
										tempkeyList.clear();

										finalMatchedRecord = highestScoreRecordHolderMap.get(olderRowid);
										LOG.debug("finalMatchedRecord is: " + finalMatchedRecord.getPartyRowIDObject());
									} else {
										// highestScoreRecordHolderMap contains
										// only 1 Matching Record
										LOG.debug("highestScoreRecordHolderMap contains only 1 Matching Record -->"
												+ highestScoreRecordHolderMap.keySet());
										for (Map.Entry<Integer, HighestScoreRecordHolder> recMapEntry : highestScoreRecordHolderMap
												.entrySet()) {
											finalMatchedRecord = recMapEntry.getValue();
											LOG.debug("finalMatchedRecord value is: " + finalMatchedRecord);
										}
									}
								} else {
									// highestScoreRecordHolderMap contains only
									// 1 Matching Record
									LOG.debug("highestScoreRecordHolderMap contains only 1 Matching Record -->"
											+ highestScoreRecordHolderMap.keySet());
									for (Map.Entry<Integer, HighestScoreRecordHolder> recMapEntry : highestScoreRecordHolderMap
											.entrySet()) {
										finalMatchedRecord = recMapEntry.getValue();
										LOG.debug("finalMatchedRecord value is: " + finalMatchedRecord);
									}
								}
							}

							LOG.info("Final Map Size: " + highestScoreRecordHolderMap.size());
							LOG.info("Target RecordKey is found: " + finalMatchedRecord);
						} else {

							// Entry<Integer, HighestScoreRecordHolder>
							// recMapEntry = (Entry<Integer,
							// HighestScoreRecordHolder>)
							// highestScoreRecordHolderMap.entrySet();
							LOG.info("Final Map Size: " + highestScoreRecordHolderMap.size());
							LOG.info("Record holder map contains only 1 matched record: "
									+ highestScoreRecordHolderMap.keySet());
							for (Map.Entry<Integer, HighestScoreRecordHolder> recMapEntry : highestScoreRecordHolderMap
									.entrySet()) {
								finalMatchedRecord = recMapEntry.getValue();
								LOG.debug("finalMatchedRecord value is: " + finalMatchedRecord);
							}
						}
					} else {
						LOG.info("No matching record found after searchMatch resultset processing");
						return null;
						// return false;
					}

				} else {
					LOG.info("No matching record found by searchMatch");
					return null;
					// return false;
				}
			} catch (SiperianServerException sifExcp) {
				LOG.error("SiperianServerException occured while processing Contact Match operation: ", sifExcp);
				ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
				customException.setMessage("SIF exception occured while processing Match request for Contact. "
						+ customException.getMessage());

				throw customException;
			} catch (Exception ex) {
				LOG.error("Contact Match operation failed with exception: ", ex);
				ServiceProcessingException customException = new ServiceProcessingException(ex);
				customException
						.setMessage("Failed to process Match request for Contact. " + customException.getMessage());

				throw customException;
			}
			
			
			int countOfRetry = Integer.parseInt(configProps.getProperty("NoOfRetries"));
			boolean isMergeRetrySuccess = false;
			String rowidHighestMtchTgt = null;
			
			try	{
				/* get rowid_object of record which has highest match score */
				if (!Util.isNullOrEmpty(finalMatchedRecord.getPartyRowIDObject())) {
					rowidHighestMtchTgt = finalMatchedRecord.getPartyRowIDObject();
					LOG.info("Target party rowid_object for merge: " + rowidHighestMtchTgt);
				//	throw new ServiceProcessingException("Throwing exception during Contact_Merge !!");
					mergeContact(newPartyRowid, rowidHighestMtchTgt, siperianClient);
					LOG.debug("Contact Merge is successful !!");
				} else {
					LOG.info("No matched target record key found. Merge Operation not done");
					// mergeInd = false;
					return null;
					// return false;
				}
			} catch (Exception ex) {
				mergeInd = false;
				LOG.error("Exception occured while processing Merge operation on Contact: " , ex);
				for(int i = 0; i<countOfRetry; i++)	{
				try{
					LOG.debug("Retrying Merge on Contact process for "+ (i+1) +"th time");
					mergeContact(newPartyRowid, rowidHighestMtchTgt, siperianClient);
					LOG.debug("Contact Merge is successful on attempt no. "+ (i+1));
					isMergeRetrySuccess = true;
					mergeInd = true;
					break;
				} catch (Exception excp) {
					LOG.error("Exception occured in Contact Merge RetryMechanism on attempt no. "+ (i+1));
					LOG.error("Exception occured in Contact Merge RetryMechanism on PARTY_BO");
				}
				}
				if(!isMergeRetrySuccess){
					ServiceProcessingException customException = new ServiceProcessingException(ex);
					customException.setMessage("SIF exception occured in Contact Merge request on PARTY BO: " + customException.getMessage());
					throw customException;
				}
			}

		} catch (SiperianServerException sifExcp) {
			LOG.error("SiperianServerException occured while processing Contact Merge operation: ", sifExcp);
			ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
			customException.setMessage("SIF exception occured while processing Merge request for Contact. "
					+ customException.getMessage());
			throw customException;
		} catch (ServiceProcessingException excp) {
			LOG.error("Contact Merge operation failed due to ServiceProcessingException with exception: ", excp);
			throw excp;
		} catch (Exception ex) {
			LOG.error("Contact Merge operation failed with exception: ", ex);
			ServiceProcessingException customException = new ServiceProcessingException(ex);
			customException.setMessage("Failed to process Merge request for Contact. " + customException.getMessage());
			throw customException;
		}

		return highestScoreRecordHolderMap;
		// return true;
	}
	/*Execute Merge API on Party BO Table*/
	private void mergeContact(String newPartyRowid, String rowidHighestMtchTgt, SiperianClient siperianClient) throws ServiceProcessingException	{
		
		LOG.debug("Inside mergeContact for PARTY BO...");
		
		try	{
			MergeRequest request = new MergeRequest();
			request.setSiperianObjectUid("BASE_OBJECT.C_B_PARTY");
			// newly created record will be merged to the existing record
			request.setSourceRecordKey(RecordKey.rowid(newPartyRowid));
			// existing record will be the survivor
			request.setTargetRecordKey(RecordKey.rowid(rowidHighestMtchTgt));
			LOG.info(" Before executing Merge process ");
			MergeResponse response = (MergeResponse) siperianClient.process(request);
			LOG.info(" After executing Merge process. Message from MergeResponse: " + response.getMessage());
			matchInd = true;
			mergeInd = true;
				
		} catch (SiperianServerException sifExcp) {
		//	mergeInd = false;
			LOG.error("SiperianServerException occured while processing mergeContact on PARTY BO: " , sifExcp);
	//		sifExcp.printStackTrace();
			ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
			customException.setMessage("SIF exception occured while processing mergeContact on PARTY BO: " + customException.getMessage());
			throw customException;
		} catch (Exception ex) {
		//	mergeInd = false;
			LOG.error("PARTY_BO mergeContact failed with exception: " , ex);
	//		ex.printStackTrace();
			ServiceProcessingException customException = new ServiceProcessingException(ex);
			customException.setMessage("Failed to process mergeContact request on PARTY BO: " + customException.getMessage());
			throw customException;
		}
		LOG.debug("Completed mergeContact for PARTY BO...");
	}
	/*Execute SearchMatch API on Party & Person BO Table*/
	private List matchContact(PartyXrefType partyTypeParam, SiperianClient siperianClient ) throws ServiceProcessingException	{
		
		LOG.info("Executing matchContact()...");
		List searchRecords = new ArrayList();
		List<CommunicationXrefType> contactCommList = null;
		CommunicationXrefType commXrefType = null;
		String commEmlVal = null;
		
		try{
			SearchMatchRequest searchMatchRequest = new SearchMatchRequest();
			SearchMatchResponse searchMatchResponse = null;
			searchMatchRequest.setRecordsToReturn(100); // Required
			// searchMatchRequest.setSiperianObjectUid("PKG_PARTY_JMS_MQ_PUB");//
			// Required
			searchMatchRequest.setSiperianObjectUid("PKG_BO_PERSON_SEARCH");// Required//PKG_BO_PERSON_SEARCH
			// searchMatchRequest.setMatchRuleSetUid(SiperianObjectType.MATCH_RULE_SET.makeUid("Org_addr_fuzzy_RealTime"));//
	
			searchMatchRequest.setMatchRuleSetUid(
					SiperianObjectType.MATCH_RULE_SET.makeUid("Party Person Fuzzy Rule Set New"));
	
			searchMatchRequest.setMatchType(MatchType.BOTH);
	
			LOG.info("Match Rule Set: " + searchMatchRequest.getMatchRuleSetUid());
			LOG.info("Match Type :" + searchMatchRequest.getMatchType());
	
			Field org_name = new Field("Organization_Name");
			if (!Util.isNullOrEmpty(partyTypeParam.getPARTYNAME())) {
				org_name.setStringValue(partyTypeParam.getPARTYNAME());
				LOG.info("Field to search for :" + org_name.getName() + ':' + org_name.getStringValue());
				searchMatchRequest.addMatchColumnField(org_name);
			}
	
			Field field_name = new Field("Person_Name");
			if (!Util.isNullOrEmpty(partyTypeParam.getPARTYNAME())) {
				field_name.setStringValue(partyTypeParam.getPARTYNAME());
				LOG.info("Field to search for :" + field_name.getName() + ':' + field_name.getStringValue());
				searchMatchRequest.addMatchColumnField(field_name);
			}
	
			// Setting Ex_Comm_Typ_Type
			Field field_Eml_Type = new Field("Ex_Comm_Type_Email");
			field_Eml_Type.setStringValue("Email");
			searchMatchRequest.addMatchColumnField(field_Eml_Type);
	
			LOG.info("Field to search for :" + field_Eml_Type.getName() + ':' + field_Eml_Type.getStringValue());
	
			// Setting Ex_Comm_Val_Eml
			
			contactCommList = partyTypeParam.getCommunication();
			for (int indx = 0; indx < contactCommList.size(); indx++) {
				commXrefType = contactCommList.get(indx);
				if (commXrefType.getCOMMTYPE().equalsIgnoreCase("Email")) {
					commEmlVal = commXrefType.getCOMMVALUE();
				}
			}
			
			Field field_Eml_Val = new Field("Ex_Comm_Val_Email");
			StringBuilder contEmlVal = new StringBuilder();
			if (!Util.isNullOrEmpty(commEmlVal)) {
				// contEmlVal.append("taylord@schaeferadvertising.com");//commEmlVal
				contEmlVal.append(commEmlVal);
				field_Eml_Val.setStringValue(contEmlVal.toString());
	
				searchMatchRequest.addMatchColumnField(field_Eml_Val);
			}
	
			LOG.info("Field to search for :" + field_Eml_Val.getName() + ':' + field_Eml_Val.getStringValue());
	
			// Setting field_Entity_Type
			Field field_Entity_Type = new Field("Ex_Entity_Type");
			field_Entity_Type.setStringValue("Person");
			searchMatchRequest.addMatchColumnField(field_Entity_Type);
	
			LOG.info("Field to search for :" + field_Entity_Type.getName() + ':'
					+ field_Entity_Type.getStringValue());
	
			// Adding SIP_POP
			Field field_SIPPOP = new Field("SIP_POP");
			field_SIPPOP.setStringValue(sipPopVal);// sipPopVal
			searchMatchRequest.addMatchColumnField(field_SIPPOP);
			LOG.info("Field to match for :" + field_SIPPOP.getName() + ':' + field_SIPPOP.getStringValue());
	
			StringBuffer criteria = new StringBuffer();
			boolean firstParam = true;
	
			/*
			 * if (firstParam) { criteria.append(" HUB_STATE_IND = '" + 1 +
			 * "'"); firstParam = false; } else { criteria.append(
			 * " AND HUB_STATE_IND = '" + 1 + "'"); }
			 */
	
			LOG.info("Filter Criteria: " + criteria.toString());
	
			searchMatchRequest.setFilterCriteria(criteria.toString());
	
			LOG.info("processing SearchMatchRequest in matchContact");
			searchMatchResponse = (SearchMatchResponse) siperianClient.process(searchMatchRequest);
	
			searchRecords = searchMatchResponse.getRecords();
		} catch (SiperianServerException sifExcp) {
		//		matchInd = false;
				LOG.error("[matchContact]:SiperianServerException occured while processing SearchMatchRequest on PARTY BO: " , sifExcp);
		//		sifExcp.printStackTrace();
				ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
				customException.setMessage("[matchContact]:SIF exception occured while processing SearchMatchRequest on PARTY BO: " + customException.getMessage());
				throw customException;
		} catch (Exception ex) {
		//		matchInd = false;
				LOG.error("[matchContact]:PARTY BO Merge operation failed with exception: " , ex);
		//		ex.printStackTrace();
				ServiceProcessingException customException = new ServiceProcessingException(ex);
				customException.setMessage("[matchContact]:Failed to process SearchMatchRequest on PARTY BO: " + customException.getMessage());
				throw customException;
		}
		LOG.info("Completed matchContact()...");
		return searchRecords;
	}
	

	
	
	
	
	/*Execute Merge API on Account BO Table*/
	private void mergeProcessChild(String siperianObjectUid, String sourceRowid, String targetRowid, SiperianClient siperianClient) throws ServiceProcessingException {

		LOG.info("Executing mergeProcessChild()");
		// SiperianClient siperianClient = null;

		try {

			// siperianClient = (SiperianClient) checkOut();

			if (sourceRowid != null && sourceRowid.length() > 0 && targetRowid != null && targetRowid.length() > 0) {
				MergeRequest request = new MergeRequest();
				MergeResponse response = null;
				request.setSiperianObjectUid(siperianObjectUid);
				// newly created record will merged into existing one
				request.setSourceRecordKey(RecordKey.rowid(sourceRowid));
				// existing rec will survive
				request.setTargetRecordKey(RecordKey.rowid(targetRowid));
				// LOG.info("Child Target Key: "+ request.getTargetRecordKey());
				LOG.info(" Before executing Child Merge process ");
				LOG.info("siperianObjectUid: " + siperianObjectUid + ", ChildSourceRowid: " + sourceRowid + ", ChildTargetRowid: " + targetRowid);
				response = (MergeResponse) siperianClient.process(request);
				mergeInd = true;
				LOG.debug(" After executing Child Merge process ");
				String msg = response.getMessage();
				LOG.debug(" Message from MergeResponse :" + msg);
			} else {
				LOG.info("Either SourceRowID or TargetRowID is null");
			}
		} catch (SiperianServerException sifExcp) {
			mergeInd = false;
			LOG.error("SiperianServerException occured while processing Child Merge operation: " , sifExcp);
	//		sifExcp.printStackTrace();
			ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
			customException.setMessage("SIF exception occured while processing Merge request for Child. " + customException.getMessage());
			throw customException;
		} catch (Exception ex) {
			mergeInd = false;
			LOG.error("Child Merge operation failed with exception: " , ex);
	//		ex.printStackTrace();
			ServiceProcessingException customException = new ServiceProcessingException(ex);
			customException.setMessage("Failed to process Merge request for Child. " + customException.getMessage());
			throw customException;
		} finally {
			// checkIn(siperianClient);
		}
		LOG.info("Executed mergeProcessChild()");
	}



	private Map<String, String> multiMergeProcessChild(String baseObjTable, Map<String, List<String>> childTypeMap, SiperianClient siperianClient) throws ServiceProcessingException {
		LOG.info("Executing multiMergeProcessChild()");
		List<String> recordList = null;
		//Modified code
		List<Integer> intRecordList = null;
		String childRecType = null;
		Map<String, String> recIdToSurvivingRowidMap = new HashMap<String, String>();
		String survivingRowid = null;

		try {
			LOG.info("Before executing child multi-merge process on " + baseObjTable);
			for (Entry entry : childTypeMap.entrySet()) {
				childRecType = entry.getKey().toString();
				recordList = (List<String>) entry.getValue();

				//if more than one rowid in list, go for multi-merge
				if (recordList != null && recordList.size() > 1) {
					updateCI(recordList, baseObjTable);
					MultiMergeRequest request = new MultiMergeRequest();
					ArrayList<RecordKey> recordKeys = new ArrayList<RecordKey>();
					StringBuilder rowIds = new StringBuilder();

					intRecordList = new ArrayList<Integer>();
					for(String str : recordList)	{
						intRecordList.add(new Integer(str.trim()));
					}
					Collections.sort(intRecordList); //To make sure existing rowid survives

					for (int indx = 0; indx < intRecordList.size(); indx++) {
						RecordKey key = new RecordKey();
						key.setRowid(Util.padSpace(intRecordList.get(indx).toString(), 14));
						recordKeys.add(key);
						rowIds.append(intRecordList.get(indx));
						rowIds.append(", ");
						if (indx == 0) {
							survivingRowid = intRecordList.get(indx).toString();
						}
						recIdToSurvivingRowidMap.put(intRecordList.get(indx).toString(), survivingRowid);
					}

					/* for (int indx = 0; indx < recordList.size(); indx++) {
						RecordKey key = new RecordKey();
						key.setRowid(recordList.get(indx));
						recordKeys.add(key);
						rowIds.append(recordList.get(indx));
						rowIds.append(", ");
					} */

					request.setRecordKeyList(recordKeys);

					Record record = new Record();
					record.setSiperianObjectUid(SiperianObjectType.BASE_OBJECT.makeUid(baseObjTable));
					request.setRecord (record);

					LOG.info("To multi-merge on record_type: " + childRecType + " | Rowid_objects to merge: " + rowIds.toString());

					MultiMergeResponse response = (MultiMergeResponse) siperianClient.process(request);

					childMergeInd = true;
					LOG.debug(" Message from MultiMergeResponse :" + response.getMessage());
				} else {
					LOG.info("Sufficient records not found for multi-merge for type " + childRecType);
				}
			} //Modified code
		} catch (SiperianServerException sifExcp) {
			childMergeInd = false;
			LOG.error("SiperianServerException occured while processing Child multi-Merge operation: ", sifExcp);
			ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
			customException.setMessage("SIF exception occured while processing muti-Merge request for " + baseObjTable + ": " + sifExcp.getMessage());
			throw customException;
		} catch (Exception ex) {
			childMergeInd = false;
			LOG.error("Child Merge operation failed with exception for " + baseObjTable, ex);
			ServiceProcessingException customException = new ServiceProcessingException(ex);
			customException.setMessage("Failed to process Merge request for " + baseObjTable + ": " + ex.getMessage());
			throw customException;
		}
		LOG.info("Executed multiMergeProcessChild()");

		return recIdToSurvivingRowidMap;
	}
	
	private void updateCI(List<String> recordList, String baseObjTable)  throws ServiceProcessingException{
		LOG.debug("Inside updateCI()");
		Connection jdbcConn = null;
		Statement statement = null;
		JDBCConnectionProvider jDBCConnectionProvider = null;
		int rowCnt = 0;
		StringBuilder sqlQry = new StringBuilder();

		sqlQry.append("UPDATE "); 
		sqlQry.append(baseObjTable);
		sqlQry.append(" SET CONSOLIDATION_IND = '4' WHERE ROWID_OBJECT in (");
		for (String partyRowId : recordList) {
			sqlQry.append("'" + partyRowId.trim() + "',");
		}
		sqlQry.deleteCharAt(sqlQry.length() - 1).toString();
		sqlQry.append(")");

		LOG.debug("SQL in updateCI()--> " + sqlQry);

		try{
			jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
			jdbcConn = jDBCConnectionProvider.getJdbcConnectionFromDS();
			statement = jdbcConn.createStatement();
			rowCnt = statement.executeUpdate(sqlQry.toString());

			//jdbcConn.commit();
			LOG.debug("RowidObject Updated for CI : " + rowCnt);
		//	LOG.debug("APPRVD_FOR_MERGE value updated to N in C_B_PARTY for partyID: " + survivingRowidObject);

		} catch(SQLException exp) {
			LOG.error("Caught SQLException in updateCI() " ,exp);

		} finally	{
			try {
				//Closing connections
			//	if (resultSet != null)	resultSet.close();
				if (statement != null) statement.close();
				if (jdbcConn != null) jdbcConn.close();
				} catch (SQLException exp) {
					LOG.error("SQLexp caught in updateCI(): " , exp);
				}

		}

		LOG.debug(" Executed updateCI() successfully ");
	}


	public HashMap<Integer, HighestScoreRecordHolder> mergeProcessContact(HashMap<Integer, HighestScoreRecordHolder> mergeSorceHolderMap,
			MdmUpsertPartyResponse upsertPartyResponse,HighestScoreRecordHolder highestScoreRecordHoldertgt,PartyXrefType insertedPartyData, String rowidObject) throws ServiceProcessingException {
		
		// execute Match and Merge on newly created records only; 
		// for Party Match will be based on Party_name, party_type, UCN etc,
		// whereas, for other BO, match will be based on rowid_party
		LOG.info("Executing mergeProcessContact() method.");
		//PutResponseDataHolder putRespDataParty = (PutResponseDataHolder) putRespDataHolderMap.get(MDMAttributeNames.ENTITY_PARTY);
		//List<PutResponseDataHolder> putRespDataAccountList = (List<PutResponseDataHolder>) putRespDataHolderMap.get(MDMAttributeNames.ENTITY_ACCOUNT);
		String survivorRowidObject = null;
		UserTransaction transaction = null;
		SiperianClient siperianClient = null;
		boolean isError = false;
		String targetRowid = null;
		List<String> targetRowidList = new ArrayList<String>();

		int countOfRetry = Integer.parseInt(configProps.getProperty("NoOfRetries"));
		boolean isMergeRetrySuccess = false;
		List<String> rowidList = new ArrayList<String>();
		// execute Match and Merge SIF operation
		try {

			siperianClient = checkOut();
			transaction = ((EjbSiperianClient) siperianClient).createTX(300000);
			transaction.begin();

			
			try {
				/*survivorRowidObject = processMatchAndMergeParty((PartyXrefType) insertedPartyData, 
						matchScoreThres, highestScoreRecordHoldertgt, rowidObject,siperianClient);*/
				mergeSorceHolderMap = processMatchAndMergeContact(insertedPartyData.getROWIDOBJECT(),
						(PartyXrefType) insertedPartyData, siperianClient);
				LOG.debug(" Controlled returned after processMatchAndMergeContact");
				//LOG.info("survivorRowidObject===" + survivorRowidObject);
				/*if (survivorRowidObject == null){
					survivorRowidObject = rowidObject;
				}*/
			} catch (Exception excp) {
				LOG.error("Caught exception within mergeProcessParty: ", excp);
				isError = true;
				throw excp;
			}
			

			// processMatchAndMergeChildEntity(MDMAttributeNames.ENTITY_ACCOUNT,
			// putRespDataParty, (PartyXrefType) insertedPartyData,
			// upsertPartyResponse,
			// mergeSorceHolderMap, highestScoreRecordHoldertgt,
			// siperianClient);
			// existing record will survive
			if (mergeInd && mergeSorceHolderMap != null && mergeSorceHolderMap.size() > 0) {
			for (HighestScoreRecordHolder hsrh : mergeSorceHolderMap.values()) {
				targetRowid = hsrh.getRowidPerson();
			}
			// newly created record will merge to existing record
			String sourceRowid = insertedPartyData.getPartyPerson().get(0)
					.getROWIDOBJECT();

			LOG.debug("PersonSorce Key: " + sourceRowid + " | PersonTarget Key: " + targetRowid);

			String siperianObjectUid = "BASE_OBJECT.C_B_PARTY_PERSON";
			try {
			//	throw new ServiceProcessingException("Throwing manual exception in C_B_PARTY_PERSON Merge !! ");
				mergeProcessChild(siperianObjectUid, sourceRowid, targetRowid, siperianClient);
				LOG.debug("Contact Person Merge is successful !!");
			}	catch (Exception sifExcp) {
				//mergeInd = false;
				LOG.error("Exception occured while processing Merge operation on C_B_PARTY_PERSON: " , sifExcp);
				for(int i = 0; i<countOfRetry; i++)	{
				try{
					LOG.debug("Retrying C_B_PARTY_PERSON Merge process for "+ (i+1) +"th time");
					rowidList.add(sourceRowid);
					rowidList.add(targetRowid);
					updateCI(rowidList, "C_B_PARTY_PERSON");
					mergeProcessChild(siperianObjectUid, sourceRowid, targetRowid, siperianClient);
					LOG.debug("Person Merge is successful on attempt no. "+ (i+1));
					isMergeRetrySuccess = true;
					//mergeInd = true;
					break;
				} catch (Exception ex) {
					LOG.error("Exception occured in C_B_PARTY_PERSON Merge RetryMechanism on attempt no. "+ (i+1));
					LOG.error("Exception occured in Merge RetryMechanism on C_B_PARTY_PERSON");
				}
				}
				if(!isMergeRetrySuccess){
					ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
					customException.setMessage("SIF exception occured while processing Merge request on C_B_PARTY_PERSON: " + customException.getMessage());
					throw customException;
				}
			}//end try/catch
		
			}
			transaction.commit();

			// if newly created record got merged, set rowid_object of it to that
			// of surviving target record
			if (mergeInd) {
		//		String survivorRowidObject = null;
				for (HighestScoreRecordHolder hsrh : mergeSorceHolderMap.values()) {
					survivorRowidObject = hsrh.getPartyRowIDObject();
				}
				LOG.info("Setting rowid_object of new record to that of surviving target record " + survivorRowidObject);
				upsertPartyResponse.getParty().get(0).setROWIDOBJECT(survivorRowidObject.trim());
			}
		} catch (ServiceProcessingException excp) {
			LOG.error("Caught exception in ProcessMatchAndMerge operation." , excp);
			isError = true;
			//upsertPartyResponse.setErrorMsg("ProcessMatchAndMerge operation failed for PartyID: " + upsertPartyResponse.getParty().get(0).getSRCSYSTEMID());

			try {
				transaction.rollback();

			} catch (SystemException txExcp) {
				LOG.error("Failed to rollback transaction for ProcessMatchAndMerge operation : " + txExcp.toString());
			}
			throw excp;
		} catch (Exception ex) {
			LOG.error("Exception occured while ProcessMatchAndMerge operation requests: " , ex);
			isError = true;

			try {
				transaction.rollback();
			} catch (SystemException txExcp) {
				LOG.error("Failed to rollback transaction for ProcessMatchAndMerge operation: " + txExcp.toString());
	//			txExcp.printStackTrace();
			}
			ServiceProcessingException customException = new ServiceProcessingException(ex);
			customException.setMessage("Failed to process ProcessMatchAndMerge operation. " + customException.getMessage());
	//		customException.printStackTrace();
			throw customException;
		} finally {
			checkIn(siperianClient);
			if(isError)	{
				tgtRowidObj = targetRowid;
			}
		}

		try {

			//Updating APPRVD_FOR_MERGE to N after Party & Account Match & Merge
			if (mergeInd) {
				updateApprvdForMerge(survivorRowidObject);
			}

			// Perform Tokenization after Match & Merge
			PutResponseDataHolder putTokenizeDataParty = new PutResponseDataHolder();
			String sorceRowidObject = null;
			if (mergeInd) {
				for (HighestScoreRecordHolder hsrh : mergeSorceHolderMap.values()) {
					sorceRowidObject = hsrh.getPartyRowIDObject();
				}

				if (!Util.isNullOrEmpty(sorceRowidObject)) {
					putTokenizeDataParty.setRowidObject(sorceRowidObject);
					putTokenizeDataParty.setActionType("Merge");
					processTokenizeRequest(sorceRowidObject,"C_B_PARTY");
				}
			}
		} catch (SiperianServerException sifExcp) {
			LOG.error("SiperianServerException occured while processing TokenizeRequest for Party after MatchMerge." , sifExcp);
			ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
			customException.setMessage("SIF exception occured while processing Tokenize request for Party after MatchMerge. " + customException.getMessage());

		
		} catch (Exception excp) {
			LOG.error("Exception occured while processing TokenizeRequest for Party after MatchMerge." , excp);
			ServiceProcessingException customException = new ServiceProcessingException(excp);
			customException.setMessage("Exception occured while processing Tokenize request for Party after MatchMerge. " + customException.getMessage());

			
		}

		LOG.info("Executed mergeProcessParty() method.");
		return mergeSorceHolderMap;
	}
	public void mergeProcessMultipleChild(PartyType partyType, MdmUpsertPartyResponse upsertPartyResponse) throws ServiceProcessingException {

		LOG.info("Executing mergeProcessMultipleChild()");
		//PutResponseDataHolder putRespDataParty = (PutResponseDataHolder) putRespDataHolderMap.get(MDMAttributeNames.ENTITY_PARTY);
		//List<PutResponseDataHolder> putRespDataAddressList = (List<PutResponseDataHolder>) putRespDataHolderMap.get(MDMAttributeNames.ENTITY_ADDRESS);
		//List<PutResponseDataHolder> putRespDataCommunicationList = (List<PutResponseDataHolder>) putRespDataHolderMap.get(MDMAttributeNames.ENTITY_COMM);
		//List<PutResponseDataHolder> putRespDataClassificationList = (List<PutResponseDataHolder>) putRespDataHolderMap.get(MDMAttributeNames.ENTITY_CLASSIF);
		//String rowidObject = null;
		Map<String, List<String>> addrTypeMap = new HashMap<String, List<String>>();
		Map<String, List<String>> commTypeMap = new HashMap<String, List<String>>();
	//	Map<String, List<String>> classifTypeMap = new HashMap<String, List<String>>();
		List<String> addrRowidList = null;
		List<String> commRowidList = null;
		List<String> classifRowidList = null;

		UserTransaction transaction = null;
		SiperianClient siperianClient = null;

		try {
			//rowidObject = upsertPartyResponse.getParty().get(partyCount - 1).getROWIDOBJECT();

			LOG.info("Preparing type-wise rowid_object list for Addr/Comm/Classifictn");
			//create type-wise rowid_object list for address, communication and classification
			for (int indx = 0; indx < partyType.getAddress().size(); indx++) {
				String addrType = partyType.getAddress().get(indx).getADDRTYPE();
				if (!addrTypeMap.containsKey(addrType)) {
					addrRowidList = new ArrayList<String>();
					addrTypeMap.put(addrType, addrRowidList);
				}
				addrTypeMap.get(addrType).add(partyType.getAddress().get(indx).getROWIDADDRESS());
			}

			for (int indx = 0; indx < partyType.getCommunication().size(); indx++) {
				String commType = partyType.getCommunication().get(indx).getCOMMTYPE();
				if (!commTypeMap.containsKey(commType)) {
					commRowidList = new ArrayList<String>();
					commTypeMap.put(commType, commRowidList);
				}
				commTypeMap.get(commType).add(partyType.getCommunication().get(indx).getROWIDCOMMUNICATION());
			}

			/*for (int indx = 0; indx < partyType.getClassification().size(); indx++) {
				String classType = partyType.getClassification().get(indx).getCLASSIFICTNTYPE();
				if (!classifTypeMap.containsKey(classType)) {
					classifRowidList = new ArrayList<String>();
					classifTypeMap.put(classType, classifRowidList);
				}
				classifTypeMap.get(classType).add(partyType.getClassification().get(indx).getROWIDCLASSIFICTN());
			}*/

			LOG.info("Type-wise rowid_object list for Addr/Comm/Classifictn created");
		} catch (Exception ex) {
			LOG.error("Exception occured while preparing child entity records for Multi-merge: ", ex);
			ServiceProcessingException customException = new ServiceProcessingException(ex);
			customException.setMessage("Failed to prepare child entity records for Multi-merge: " + ex.getMessage());
			throw customException;
		}

		try {

			siperianClient = checkOut();
			transaction = ((EjbSiperianClient) siperianClient).createTX(300000);
			transaction.begin();

			LOG.info("Calling multi-merge process for Addr/Comm/Classifictn");
			//call multi-merge for each child
			Map<String, String> typeToSurvivingRowidMapAddr =  multiMergeProcessChild(MDMAttributeNames.ADDRESS_BO, addrTypeMap, siperianClient);
			Map<String, String> typeToSurvivingRowidMapComm = multiMergeProcessChild(MDMAttributeNames.COMM_BO, commTypeMap, siperianClient);
			//Map<String, String> typeToSurvivingRowidMapClassif = multiMergeProcessChild(MDMAttributeNames.CLASS_BO, classifTypeMap, siperianClient);

			transaction.commit();
			LOG.info("Multi-merge process for Addr/Comm/Classifictn completed");

			if (upsertPartyResponse != null) {
				upsertPartyResponse.setStatus(upsertPartyResponse.getStatus() + "\n ");
				if (typeToSurvivingRowidMapAddr != null && typeToSurvivingRowidMapAddr.size() > 1) {
					upsertPartyResponse.setStatus(upsertPartyResponse.getStatus() + "Address records got merged.");
				}
				if (typeToSurvivingRowidMapComm != null && typeToSurvivingRowidMapComm.size() > 1) {
					upsertPartyResponse.setStatus(upsertPartyResponse.getStatus() + "Communication records got merged.");
				}
				/*if (typeToSurvivingRowidMapClassif != null && typeToSurvivingRowidMapClassif.size() > 1) {
					upsertPartyResponse.setStatus(upsertPartyResponse.getStatus() + "Classification records got merged.");
				}*/
			}
		} catch (ServiceProcessingException excp) {
			LOG.error("Exception in Merge operation for child entities: ", excp);

			try {
				transaction.rollback();
				LOG.debug("Transaction rolled back successfully.");
			} catch (SystemException txExcp) {
				LOG.error("Failed to rollback transaction for Merge operation : " + txExcp.toString());
			}
			throw excp;
		} catch (Exception ex) {
			LOG.error("Exception occured in Merge operation for child entities: ", ex);
			try {
				transaction.rollback();
				LOG.debug("Transaction rolled back successfully.");
			} catch (SystemException txExcp) {
				LOG.error("Failed to rollback transaction for Merge operation: " + txExcp.toString());
				txExcp.printStackTrace();
			}
			ServiceProcessingException customException = new ServiceProcessingException(ex);
			customException.setMessage("Failed to process Merge operation for child entities: " + ex.getMessage());
			throw customException;
		} finally {
			checkIn(siperianClient);
		}

		LOG.info("Executed mergeProcessMultipleChild()");
	}

	// Method to calculate highest/maximum Match Score
	private List<Integer> maxMatchScore(Map<Integer, Integer> matchScoreMap) {
		Collection<Integer> collVal = matchScoreMap.values();
		List<Integer> scoreList = new ArrayList<Integer>(collVal);
		List rowidObjs = new ArrayList(); //
		// Collections.sort(scoreList);
		// Object maxScore = scoreList.get(scoreList.size()-1);
		Integer maxScore = Collections.max(scoreList);
		int cnt = 0;
		// for (Iterator itr = scoreList.iterator(); itr.hasNext();) {
		for (Entry entry : matchScoreMap.entrySet()) {
			if (maxScore.equals(entry.getValue())) {
				cnt++;
				rowidObjs.add(entry.getKey());
			}
		}
		LOG.debug("No of records having highest match score " + maxScore + ": " + cnt);
		return rowidObjs;
	}


	// Method to calculate HighestMatchScore
	private Integer highestMatchScore(Map<Integer, Integer> matchScoreMap) {
		Collection<Integer> collVal = matchScoreMap.values();
		List<Integer> scoreList = new ArrayList<Integer>(collVal);
		// Collections.sort(scoreList);
		// Object maxScore = scoreList.get(scoreList.size()-1);
		Integer maxScore = Collections.max(scoreList);
		LOG.debug("Highest Match score " + maxScore);

		return maxScore;
	}


	private void setContactUCNSeq(String rowidObject) throws ServiceProcessingException {

		String ucnValue = null;
		try {
			// Get the next UCN value from Sequence Function
			ucnValue = prospectPartyDAO.getNextContactUCNValue();
			if (!Util.isNullOrEmpty(ucnValue)) {
				// Put the fetched UCN into
				putUCNRequest(rowidObject, ucnValue);
			}

		} catch (ServiceProcessingException spExcp) {
			LOG.error("Error in setUCNSeq(): " + spExcp.getMessage());
			throw spExcp;
		}
	}

	public String getNextUCNValue(String partyType) throws ServiceProcessingException {

		LOG.debug("Executing getNextUCNValue()");
		String ucnFunction = configProps.getProperty("MFE_GET_UCN_BY_PARTY_TYPE");
		Connection jdbcConn = null;
		Statement statement = null;
		ResultSet resultSet = null;
		JDBCConnectionProvider jDBCConnectionProvider = null;
		String ucn = null;
		StringBuilder sql = new StringBuilder();
		sql.append("SELECT " + ucnFunction + "('" + partyType + "') FROM DUAL");
		LOG.debug("SQL for getNextUCNValue()--> " + sql);

		try{
			jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
			jdbcConn = jDBCConnectionProvider.getJdbcConnectionFromDS();
			statement = jdbcConn.createStatement();
			resultSet = statement.executeQuery(sql.toString());

			while (resultSet.next()) {
				ucn = resultSet.getString(1);
			}

			LOG.info("UCN obtained from Sequence function: " + ucn);

		} catch(SQLException exp) {
			LOG.error("SQLException in getting UCN sequence: ", exp);
			ServiceProcessingException customException = new ServiceProcessingException(exp);
			customException.setMessage("SQLException occured in getting UCN sequence: " + exp.getMessage());
			throw customException;
		} finally {
			//Closing connections
			try {
				if (resultSet != null)  resultSet.close();
				if (statement != null) statement.close();
				if (jdbcConn != null) jdbcConn.close();
			} catch(SQLException sqlEx) {
				LOG.error("Error in closing resultSet/statement: " + sqlEx.getMessage());
			}
		//	if (jDBCConnectionProvider != null) jDBCConnectionProvider.closeJdbcConnection(jdbcConn);
		}

		LOG.debug("Executed getNextUCNValue()");
		return ucn;
	}

	//Put UCN in base object & XREF tables.
	public void putUCNRequest(String rowidObject, String ucnValue) throws ServiceProcessingException {
		LOG.info("Executing putUCNRequest()");

		SiperianClient siperianClient = null;
		UserTransaction transaction = null;
		String systemUser = "admin";

		try {
			PutRequest putRequest = new PutRequest();
			PutResponse putResponse = null;
			// String systemUser = "Admin";
			String srcSystem = "Admin"; // trimming not required
			String srcPkey = null; // trimming not required
			String srcRowid = rowidObject; // trimming not required
			LOG.info("Executing PutRequest with src_system=" + srcSystem + " | scr_pkey=" + srcPkey + " | rowid_object="
					+ srcRowid);

			// Fetch Siperian Object from
			siperianClient = (SiperianClient) checkOut();
			// create transaction - commit if Delete and Put requests both
			// succeeded
			transaction = ((EjbSiperianClient) siperianClient).createTX(1200); // in
																				// seconds
			transaction.begin();

			// prepare PutRequest
			RecordKey recordKey = new RecordKey();
			recordKey.setRowid(srcRowid);
			recordKey.setSystemName(srcSystem);
			putRequest.setRecordKey(recordKey);

			Record record = new Record();
			record.setSiperianObjectUid(SiperianObjectType.BASE_OBJECT.makeUid(MDMAttributeNames.PARTY_BO));
			record.setField(new Field(MDMAttributeNames.SRC_UPDT_BY, systemUser));
			record.setField(new Field(PartyAttributes.UCN, ucnValue));
			record.setField(new Field(PartyAttributes.STATUS_CD, "A"));

			putRequest.setRecord(record);
			// execute Put request
			putResponse = (PutResponse) siperianClient.process(putRequest);

			LOG.info("Committing UCN transaction");
			transaction.commit();
			LOG.info("Put request for UCN assignment processed successfully: Action Type = "
					+ putResponse.getActionType() + " | Msg = " + putResponse.getMessage());

		} catch (SiperianServerException sifExcp) {
			LOG.error("SiperianServerException occured while assigning UCN by Put request: ", sifExcp);
			ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
			customException.setMessage(
					"SiperianServerException occured while assigning UCN by Put request: " + sifExcp.getMessage());
			throw customException;
		} catch (Exception excp) {
			LOG.error("Exception occured while assigning UCN by Put request: ", excp);
			ServiceProcessingException customException = new ServiceProcessingException(excp);
			customException.setMessage("Exception occured while assigning UCN by Put request: " + excp.getMessage());
			throw customException;
		} finally {
			checkIn(siperianClient);
		}

		LOG.info("Executed putUCNRequest()");

	}

	

	// To check if UCN is already present in Surviving Record or not.
	public String checkifUCNExists(String survivingRowidObject) throws ServiceProcessingException {

			LOG.debug("Executing checkifUCNExists()");
			Connection jdbcConn = null;
			Statement statement = null;
			PreparedStatement pstatement = null;
			ResultSet resultSet = null;
			JDBCConnectionProvider jDBCConnectionProvider = null;
			String ucn = null;
			StringBuilder sql = new StringBuilder();
			sql.append("SELECT UCN FROM C_B_PARTY_XREF WHERE ROWID_OBJECT = '" + survivingRowidObject + "' AND ROWID_SYSTEM = 'SYS0' AND UCN IS NOT NULL ");
	//		sql.append("SELECT UCN FROM C_B_PARTY_XREF WHERE ROWID_OBJECT = ? AND ROWID_SYSTEM = 'SYS0' AND UCN IS NOT NULL ");
			LOG.debug("SQL for checkifUCNExists()--> " + sql);

			try{
				jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
				jdbcConn = jDBCConnectionProvider.getJdbcConnectionFromDS();
		//		pstatement = jdbcConn.prepareStatement(sql.toString());
		//		pstatement.setString(1, survivingRowidObject);
				
		//		resultSet = pstatement.executeQuery();
				statement = jdbcConn.createStatement();
				resultSet = statement.executeQuery(sql.toString());

				while (resultSet.next()) {
					ucn = resultSet.getString(1);
				}

				LOG.debug("UCN exists & value is: " + ucn);

			} catch(SQLException exp) {
				LOG.error("SQLException in checkifUCNExists: ", exp);
				ServiceProcessingException customException = new ServiceProcessingException(exp);
				customException.setMessage("SQLException occured checkifUCNExists: " + exp.getMessage());
				throw customException;
			} finally {
				//Closing connections
				try {
					if (resultSet != null)  resultSet.close();
					if (pstatement != null) pstatement.close();
					if (statement != null) statement.close();
					if(jdbcConn != null) jdbcConn.close();
				} catch(SQLException sqlEx) {
					LOG.error("Error in closing resultSet/statement: " + sqlEx.getMessage());
				}
			}

			LOG.debug("Executed checkifUCNExists()");
			return ucn;
		}

	// Search if Record exists in Hierarchy or not.
	private List<Integer> searchHierarchy(List<Integer> dunsNbrMapList) throws SQLException, ServiceProcessingException {
		Connection jdbcConn = null;
		Statement statement = null;
		ResultSet resultSet = null;
		JDBCConnectionProvider jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
		jdbcConn = jDBCConnectionProvider.getJdbcConnectionFromDS();

		Set<Integer> rowidSet = new HashSet<Integer>();
		StringBuilder sql = new StringBuilder();
		try{
			sql.append("select ROWID_PARTY,ROWID_PARTY_2 from C_B_PARTY_REL where TRIM(ROWID_PARTY) in (");

			for (Integer inVal : dunsNbrMapList) {
				sql.append(inVal + ",");
			}

			sql.deleteCharAt(sql.length() - 1).toString();

			sql.append(") or TRIM(ROWID_PARTY_2) in (");

			for (Integer inVal : dunsNbrMapList) {
				sql.append(inVal + ",");
			}

			sql.deleteCharAt(sql.length() - 1).toString();
			sql.append(")");

			LOG.info("SQL-->" + sql);

			statement = jdbcConn.createStatement();
			resultSet = statement.executeQuery(sql.toString());

			while (resultSet.next()) {

				rowidSet.add(Integer.parseInt(resultSet.getString("ROWID_PARTY").trim()));
				rowidSet.add(Integer.parseInt(resultSet.getString("ROWID_PARTY_2").trim()));
			}
		} finally {
			try{
				// Closing connections
				if (resultSet != null) resultSet.close();
				if (statement != null) statement.close();
				if (jdbcConn != null) jdbcConn.close();
			}catch(SQLException sqlEx) {
				LOG.error("Error in closing resultSet/statement: " + sqlEx);
			}
		}

		List<Integer> rowidList = new ArrayList<Integer>(rowidSet);

		return rowidList;
	}

	// Method for CreatingTask for Administrator
	private void processCreateTaskRequest(String tgtPartyRowId, String rowIdObject, String taskType, String title, String comment) {

		LOG.info("Executing processCreateTaskRequest()");
		SiperianClient siperianClient = null;

		try {
			String mergeOwnerUID = configProps.getProperty("mergeOwnerUID");
			String ownerUid = configProps.getProperty("ownerUID");
			String subjectAreaUID = configProps.getProperty("subjectAreaUID");

			CreateTaskResponse response = null;
			CreateTaskRequest request = new CreateTaskRequest();
			TaskData taskData = new TaskData();

			if (taskType.equalsIgnoreCase("Merge"))	{
				taskData.setOwnerUid(mergeOwnerUID);

			} else {
				taskData.setOwnerUid(ownerUid);

			}

			TaskRecord taskRecord = new TaskRecord();
			RecordKey recordKey = new RecordKey();
			taskRecord.setSiperianObjectUid(SiperianObjectType.BASE_OBJECT.makeUid(MDMAttributeNames.PARTY_BO));
			recordKey.setRowid(rowIdObject);
			LOG.debug("rowIdObject: " + rowIdObject);
			taskRecord.setRecordKey(recordKey);
			List<TaskRecord> recordList = new ArrayList<TaskRecord>();
			recordList.add(taskRecord);

			if (taskType.equalsIgnoreCase("Merge")) {

			//	for (HighestScoreRecordHolder srcRecHolder : mergeSorceHolderMap.values())
			//		tgtPartyRowId = srcRecHolder.getPartyRowIDObject();

				TaskRecord taskRecord2 = new TaskRecord();
				taskRecord2.setSiperianObjectUid(SiperianObjectType.BASE_OBJECT.makeUid(MDMAttributeNames.PARTY_BO));
				RecordKey recordKey2 = new RecordKey();
				recordKey2.setRowid(tgtPartyRowId);
				LOG.debug("tgtPartyRowId :" + tgtPartyRowId);
				taskRecord2.setRecordKey(recordKey2);
				recordList.add(0, taskRecord2);
			}

			taskData.setTaskRecords(recordList);
			request.setTaskData(taskData);
			taskData.setTitle(title);
			taskData.setComment(comment);

			Calendar cal = Calendar.getInstance();
			cal.setTime(new Date(System.currentTimeMillis()));
			cal.add(Calendar.DATE, 7);

			taskData.setDueDate(cal.getTime());
			// taskData.setSubjectAreaUid("SUBJECT_AREA.test|Person");
			taskData.setSubjectAreaUid(subjectAreaUID);
			// taskData.setTaskType("ReviewNoApprove");
			taskData.setTaskType(taskType);

			siperianClient = (SiperianClient) checkOut();

			LOG.info("processing CreateTaskRequest");
			response = (CreateTaskResponse) siperianClient.process(request);
			LOG.info("CreateTaskResponse result: " + response.getMessage());
			LOG.info("CreateTaskResponse taskId: " + response.getTaskId());
			LOG.info("CreateTaskResponse interactionId: " + response.getInteractionId());
			LOG.info("after response");
		} catch (Exception excp) {
			LOG.error("Caught Exception in CreateTaskRequest Error Message: " + excp);
		} finally {
			checkIn(siperianClient);
		}
		LOG.info("Executed processCreateTaskRequest()");
	}

	// generate match token for the party record
	private void processTokenizeRequest(String rowidObject,String BO) throws ServiceProcessingException {

		
		if (!Util.isNullOrEmpty(rowidObject)) {
			rowidObject = rowidObject.trim();
		}
		LOG.debug("Executing processTokenizeRequest()"+rowidObject);
		SiperianClient siperianClient = null;
		

		try {
			siperianClient = (SiperianClient) checkOut();

			TokenizeRequest tokenizeRequest = new TokenizeRequest();
			tokenizeRequest.setSiperianObjectUid(SiperianObjectType.BASE_OBJECT.makeUid(BO));
			RecordKey recordKey = new RecordKey();
			recordKey.setRowid(rowidObject);
			tokenizeRequest.setRecordKey(recordKey);		
			tokenizeRequest.setActionType("Update");
			TokenizeResponse tokenizeResponse = (TokenizeResponse) siperianClient.process(tokenizeRequest);
			LOG.info("Match Token generated for PartyID: " + rowidObject + " Token msg: " + tokenizeResponse.getMessage());
           //Delete Junk token after Tokenize
			if (BO.equalsIgnoreCase("C_B_PARTY")) {
			prospectPartyDAO.deleteJunkToken(rowidObject);
			}
			LOG.info("Junk Token has deleted Successfully");
			LOG.debug("Executed processTokenizeRequest()");
		} catch (Exception excp) {
			LOG.error("Caught exception within processTokenizeRequest() " + excp.getMessage());
			
			ServiceProcessingException customExcp = new ServiceProcessingException(excp);
			throw customExcp;
		} finally {
			checkIn(siperianClient);
		}
	}


	public PartyXrefType processUpdateRequest(PartyXrefType upsertParty, PartyXrefType insertedPartyData, List<String> sendToSrcList, 
			String survivingPartyRowid,PartyType survivingPartyProfileFromBO) throws ServiceProcessingException {
		LOG.info("Executing processUpdateRequest()");

		SiperianClient siperianClient = null;
		UserTransaction transaction = null;

		// PartyXrefType updatePartyParam = insertedPartyData;
		PartyXrefType legacyPartyData = null;
		UpsertPartyResponse upsertPartyResponse = new UpsertPartyResponse();
		int updatePartyCnt = 0;

		// UpdateRecordHolder updateRecordHolder = null;
		PutResponseDataHolder putRespDataParty = null;
		List<PutResponseDataHolder> putRespDataPersonList = null;
		List<PutResponseDataHolder> putRespDataAddressList = null;
		List<PutResponseDataHolder> putRespDataCommunicationList = null;
		Map<String, Object> putRespDataHolderMap = new HashMap<String, Object>();
		PartyXrefType upsertPartyPayload = null;
		List<PartyXrefType> partyList=new ArrayList<PartyXrefType>();

		try {
			if (insertedPartyData != null) {
				partyList = getLegacyRefRecords(insertedPartyData, sendToSrcList,survivingPartyProfileFromBO.getROWIDOBJECT());
			}
		} catch (SQLException sqlexp) {
			LOG.error("Caught exception during getLegacyRefRecords().", sqlexp);
		}//Checking for draft account
		/*String draftFlag = insertedPartyData.getAccount().get(0).getDraftAccountFlag();
		boolean isDraftAcc = Constant.STR_Y.equalsIgnoreCase(draftFlag) ? true : false;
		LOG.info("Is draft acount "+isDraftAcc);*/
        //checking JP country
		if(!(CollectionUtils.isEmpty(upsertParty.getAddress()) || upsertParty.getAddress().get(0) == null)){
		if( !Util.isNullOrEmpty(upsertParty.getAddress().get(0).getCOUNTRYCD()) )	{
			if(!upsertParty.getAddress().get(0).getCOUNTRYCD().equalsIgnoreCase("JAPAN") && !upsertParty.getAddress().get(0).getCOUNTRYCD().equalsIgnoreCase("JPN")
					&& !upsertParty.getAddress().get(0).getCOUNTRYCD().equalsIgnoreCase("JP") )	{
				LOG.info("Non JP Country exist");
			}else	{
				LOG.info("JP Country exist");
					isJapan = Boolean.TRUE;
			}
		}
		}
		try {

			
			
			siperianClient = (SiperianClient) checkOut();
			if (partyList != null && partyList.size() > 0) {
				for (int index = 0; index < partyList.size(); index++) {
					legacyPartyData = new PartyXrefType();
					legacyPartyData = partyList.get(index);

					// Setting
					if (legacyPartyData != null) {
						String sourceName = legacyPartyData.getXREF().get(0).getSRCSYSTEM();
						String sourceKey = legacyPartyData.getXREF().get(0).getSRCPKEY();
						LOG.debug("Checking the xref presence src system: " + sourceName + "PKEY  "+ sourceKey);
												
						// Party and children Of LegacyRef record overwritten
						// with inserted values
						//Condtion to check Source system is SFC and  Draft Flag is Y -
						
						
					//	if (!isDraftAcc){
							overwriteForOrchestration(insertedPartyData, legacyPartyData, survivingPartyProfileFromBO);
							LOG.debug("Populated Legacy Party: " + legacyPartyData.getROWIDOBJECT());
						//}
						
						lastUpdateDate = Util.getCurrentTimeZone();

						/*
						 * all the successful put calls will return rowid_object of newly
						 * created records and that will be set into corresponding response
						 * object. Response will also contain all the input values of Party
						 * and child entities. So before executing Put calls copy all
						 * request attributes to response
						 */

						// create transaction - commit if cleansePut requests succeed for
						// Party and all the child entities
						transaction = ((EjbSiperianClient) siperianClient).createTX(300000);
						transaction.begin();
						
						//if(!isDraftAcc){
							// Create Party
							putRespDataParty = putParty(legacyPartyData, siperianClient);
							// Create Person
							if (legacyPartyData.getPartyPerson() != null) {
								putRespDataPersonList = putPerson(legacyPartyData.getPartyPerson(), legacyPartyData, siperianClient);
							}
							// Create Address
							if (legacyPartyData.getAddress() != null) {
								putRespDataAddressList = putAddress(legacyPartyData.getAddress(), legacyPartyData, siperianClient);
							}
							// Create Communication
							if (legacyPartyData.getCommunication() != null) {
								putRespDataCommunicationList = putCommunication(legacyPartyData.getCommunication(), legacyPartyData, siperianClient);
							}
							LOG.info(updatePartyCnt + " LegacyRef Party/Address/Comm for non draft record has been updated");
						//}
						
					
						// commit transaction
						transaction.commit();
						updatePartyCnt++;
						LOG.info(updatePartyCnt + " count of record updated");
					} else {
						LOG.info("No MDM_LEGACY Ref Record Found. Hence Bypassing Put process.");
						return null;
					}
				}
			
			}	

			upsertPartyResponse.setStatus(upsertPartyResponse.getStatus() == null ? "" : "\n");
			
			upsertPartyResponse
					.setStatus(upsertPartyResponse.getStatus() + " Updated LegacyRef PartySrcPKEY: " + upsertParty.getXREF().get(0).getSRCPKEY() + " PartySrcSYS: " + upsertParty.getXREF().get(0).getSRCSYSTEM());
			
		} catch (ServiceProcessingException excp) {
			
			LOG.error("Exception occured while getting LegacyParty Put requests: ", excp);

			//warning.append("Process failed while Updating LegayID Ref Record.Task generated for Admin group for LegacyREF Update. \n");
			try {
				transaction.rollback();

			} catch (SystemException txExcp) {
				LOG.error("Failed to rollback transaction for Put requests : " + txExcp.toString());
			}
			throw excp;
		} catch (Exception ex) {

			LOG.error("Exception occured while getting LegacyParty Put requests: ", ex);

			//warning.append("Process failed while Updating LegayID Ref Record.Task generated for Admin group for LegacyREF Update. \n");
			try {
				transaction.rollback();
			} catch (SystemException txExcp) {
				LOG.error("Failed to rollback transaction for cleansePut requests : " + txExcp.toString());
				txExcp.printStackTrace();
			}
			ServiceProcessingException customException = new ServiceProcessingException(ex);
			customException.setMessage("Failed to process cleansePut SIF request. " + customException.getMessage());

			throw customException;
		} finally {
			checkIn(siperianClient);
		}
		try {
			// set rowid_object of created records into response and
			// set the PutResponseDataHolder object/list of object into Map
			// against corresponding entity name
			// set rowid_object of Party into response

			PartyUpsertRespType partyUpsertResp = new PartyUpsertRespType();
			PartyPerson person = null;
			List<PartyPerson> personList = new ArrayList<PartyPerson>();
			Address address = null;
			List<Address> addressList = new ArrayList<Address>();
			Communication comm = null;
			List<Communication> commList = new ArrayList<Communication>();

			// set rowid_object of Party into response
			if (putRespDataParty != null) {
				partyUpsertResp.setROWIDOBJECT(putRespDataParty.getRowidObject());
				partyUpsertResp.setSRCSYSTEM(putRespDataParty.getSystemName().trim());
				partyUpsertResp.setSRCSYSTEMID(putRespDataParty.getSourceKey());
				putRespDataHolderMap.put(MDMAttributeNames.ENTITY_PARTY, putRespDataParty);
			}

			// set rowid_object of Person into response
			if (putRespDataPersonList != null) {
				putRespDataHolderMap.put(MDMAttributeNames.ENTITY_PARTY_PRSN, putRespDataPersonList);

				for (int index = 0; index < putRespDataPersonList.size(); index++) {

					person = new PartyPerson();
					
					person.setROWIDPERSON(putRespDataPersonList.get(index).getRowidObject());
					person.setSRCSYSTEM(putRespDataPersonList.get(index).getSystemName().trim());
					person.setSRCSYSTEMID(putRespDataPersonList.get(index).getSourceKey());
					personList.add(person);

				}
			}
			// set rowid_object of Address into response
			if (putRespDataAddressList != null) {
				putRespDataHolderMap.put(MDMAttributeNames.ENTITY_ADDRESS, putRespDataAddressList);

				for (int index = 0; index < putRespDataAddressList.size(); index++) {
					address = new Address();
					address.setROWIDADDRESS(putRespDataAddressList.get(index).getRowidObject());
					address.setSRCSYSTEM(putRespDataAddressList.get(index).getSystemName().trim());
					address.setSRCSYSTEMID(putRespDataAddressList.get(index).getSourceKey());
					addressList.add(address);

				}
			}
			// set rowid_object of Communication into response
			if (putRespDataCommunicationList != null) {
				putRespDataHolderMap.put(MDMAttributeNames.ENTITY_COMM, putRespDataCommunicationList);

				for (int index = 0; index < putRespDataCommunicationList.size(); index++) {
					comm = new Communication();
					comm.setROWIDCOMMUNICATION(((PutResponseDataHolder) putRespDataCommunicationList.get(index)).getRowidObject());
					comm.setSRCSYSTEM(((PutResponseDataHolder) putRespDataCommunicationList.get(index)).getSystemName().trim());
					comm.setSRCSYSTEMID(((PutResponseDataHolder) putRespDataCommunicationList.get(index)).getSourceKey());
					commList.add(comm);

				}
			}
			
			partyUpsertResp.getPartyPerson().addAll(personList);
			partyUpsertResp.getAddress().addAll(addressList);
			partyUpsertResp.getCommunication().addAll(commList);
			upsertPartyResponse.getParty().add(partyUpsertResp);

			// Logging UpsertPartyResponse details
			LOG.debug("Printing DummyUpdate service response:-");
			Util.printObjectTreeInXML(UpsertPartyResponse.class, upsertPartyResponse);

			
		} catch (Exception excp) {
			LOG.error("Exception occured while getting LegacyParty Put response for Party "  );
			ServiceProcessingException customException = new ServiceProcessingException(excp);
			customException.setMessage("Exception occured while getting LegacyParty Put response for Party. " + customException.getMessage());
			throw customException;
		}

		try {
			
				LOG.info("Calling Tokenize process for LegacyRef Record.");
				processTokenizeRequest(survivingPartyProfileFromBO.getROWIDOBJECT(),"C_B_PARTY");
			
		} catch (SiperianServerException sifExcp) {
			LOG.error("SiperianServerException occured while processing TokenizeRequest for processUpdateRequest()");
			ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
			customException.setMessage("SIF exception occured while processing Tokenize request for processUpdateRequest(). " + customException.getMessage());

			throw customException;
		} catch (Exception excp) {
			LOG.error("Exception occured while processing TokenizeRequest for processUpdateRequest()");
			ServiceProcessingException customException = new ServiceProcessingException(excp);
			customException.setMessage("Exception occured while processing Tokenize request for processUpdateRequest(). " + customException.getMessage());
		}

		LOG.info("Executed processUpdateRequest()");
		return legacyPartyData;
	}

	

	// Overwriting LegacyRef Party with Original InsertedPartyData
	/*
	 * insertedPartyDataXref - SFDC Xref
	 * legacyPartyData - SAP,SBL,SFC xref
	 * insertedPartyData - BO copy
	 */
	public void overwriteForOrchestration(PartyXrefType insertedPartyDataXref, PartyXrefType legacyPartyData,PartyType insertedPartyData) throws ServiceProcessingException {
		LOG.info("Executing overwriteForOrchestration()");
		//Setting Party
		//replace the rowid object with orig rowidobject for legacy PUT call
		legacyPartyData.setROWIDOBJECT(insertedPartyData.getROWIDOBJECT());
		legacyPartyData.setPARTYNAME(insertedPartyData.getPARTYNAME());
		
		if (!Util.isNullOrEmpty(insertedPartyData.getUCN())) {
			legacyPartyData.setUCN(insertedPartyData.getUCN());
		}
		//Setting Person
		if (insertedPartyData.getPartyPerson() != null && insertedPartyData.getPartyPerson().size() > 0) {
			if (legacyPartyData.getPartyPerson() != null && legacyPartyData.getPartyPerson().size() > 0) {
			for(int index = 0; index < insertedPartyData.getPartyPerson().size(); index++)		{
				for(int index1 = 0; index1 < legacyPartyData.getPartyPerson().size(); index1++)		{

				legacyPartyData.getPartyPerson().get(index1).setFIRSTNAME(insertedPartyData.getPartyPerson().get(index).getFIRSTNAME());
				legacyPartyData.getPartyPerson().get(index1).setLASTNAME(insertedPartyData.getPartyPerson().get(index).getLASTNAME());
				legacyPartyData.getPartyPerson().get(index1).setJOBFUNCTION(insertedPartyData.getPartyPerson().get(index).getJOBFUNCTION());
				legacyPartyData.getPartyPerson().get(index1).setJOBTITLE(insertedPartyData.getPartyPerson().get(index).getJOBTITLE());
				legacyPartyData.getPartyPerson().get(index1).setJOBLEVEL(insertedPartyData.getPartyPerson().get(index).getJOBLEVEL());
				legacyPartyData.getPartyPerson().get(index1).setLATTICESCORE(insertedPartyData.getPartyPerson().get(index).getLATTICESCORE());
				legacyPartyData.getPartyPerson().get(index1).setPREFLANGUAGE(insertedPartyData.getPartyPerson().get(index).getPREFLANGUAGE());
				legacyPartyData.getPartyPerson().get(index1).setPREFIX(insertedPartyData.getPartyPerson().get(index).getPREFIX());
				
				
					}
				}
			}
		}
		
						
		//Setting Address
		for(int index = 0; index < insertedPartyData.getAddress().size(); index++)		{
			for(int index1 = 0; index1 < legacyPartyData.getAddress().size(); index1++)		{
				if(legacyPartyData.getAddress().get(index1).getADDRTYPE().equalsIgnoreCase(insertedPartyData.getAddress().get(index).getADDRTYPE()))	{

					if(!Util.isNullOrEmpty(insertedPartyData.getAddress().get(index).getADDRLN1()))	{
						legacyPartyData.getAddress().get(index1).setADDRLN1(insertedPartyData.getAddress().get(index).getADDRLN1());
					}
			//		if(!Util.isNullOrEmpty(insertedPartyData.getAddress().get(index).getADDRLN2()))	{
						legacyPartyData.getAddress().get(index1).setADDRLN2(insertedPartyData.getAddress().get(index).getADDRLN2());
			//		}
			//		if(!Util.isNullOrEmpty(insertedPartyData.getAddress().get(index).getADDRLN3()))	{
						legacyPartyData.getAddress().get(index1).setADDRLN3(insertedPartyData.getAddress().get(index).getADDRLN3());
			//		}
			//		if(!Util.isNullOrEmpty(insertedPartyData.getAddress().get(index).getADDRLN4()))	{
						legacyPartyData.getAddress().get(index1).setADDRLN4(insertedPartyData.getAddress().get(index).getADDRLN4());
			//		}
					if(!Util.isNullOrEmpty(insertedPartyData.getAddress().get(index).getCITY()))	{
						legacyPartyData.getAddress().get(index1).setCITY(insertedPartyData.getAddress().get(index).getCITY());
					}
		
					if(!Util.isNullOrEmpty(insertedPartyData.getAddress().get(index).getSTATECD()))	{
						legacyPartyData.getAddress().get(index1).setSTATECD(insertedPartyData.getAddress().get(index).getSTATECD());
					}
			//		if(!Util.isNullOrEmpty(insertedPartyData.getAddress().get(index).getPOSTALCD()))	{
						legacyPartyData.getAddress().get(index1).setPOSTALCD(insertedPartyData.getAddress().get(index).getPOSTALCD());
			//		}
					if(!Util.isNullOrEmpty(insertedPartyData.getAddress().get(index).getCOUNTRYCD()))	{
						legacyPartyData.getAddress().get(index1).setCOUNTRYCD(insertedPartyData.getAddress().get(index).getCOUNTRYCD());
					}
					legacyPartyData.getAddress().get(index1).setCOUNTY(insertedPartyData.getAddress().get(index).getCOUNTY());

				}
			}
		}

		//Setting Communication
		for(int index = 0; index < insertedPartyData.getCommunication().size(); index++)		{
			for(int index1 = 0; index1 < legacyPartyData.getCommunication().size(); index1++)		{
				if(legacyPartyData.getCommunication().get(index1).getCOMMTYPE().equalsIgnoreCase(insertedPartyData.getCommunication().get(index).getCOMMTYPE()))	{

				
				//		if(!Util.isNullOrEmpty(insertedPartyData.getCommunication().get(index).getCOMMVALUE()))	{
							legacyPartyData.getCommunication().get(index1).setCOMMVALUE(insertedPartyData.getCommunication().get(index).getCOMMVALUE());
				//		}
					
					
			//		if(!Util.isNullOrEmpty(insertedPartyData.getCommunication().get(index).getPRFRDCOMMIND()))	{
						legacyPartyData.getCommunication().get(index1).setPRFRDCOMMIND(insertedPartyData.getCommunication().get(index).getPRFRDCOMMIND());
			//		}
			//		if(!Util.isNullOrEmpty(insertedPartyData.getCommunication().get(index).getWEBDOMAIN()))	{
						legacyPartyData.getCommunication().get(index1).setWEBDOMAIN(insertedPartyData.getCommunication().get(index).getWEBDOMAIN());
			//		}
						legacyPartyData.getCommunication().get(index1).setCOMMEXTN(insertedPartyData.getCommunication().get(index).getCOMMEXTN());
						legacyPartyData.getCommunication().get(index1).setCOMMMKTGPREF(insertedPartyData.getCommunication().get(index).getCOMMMKTGPREF());
					// }
				}
			}
		}


		LOG.debug("Printing Legacy Update Request canonical structure:");
		UpsertPartyRequest legacyPartyRequest = new UpsertPartyRequest();
		legacyPartyRequest.getParty().add(legacyPartyData);
		Util.printObjectTreeInXML(UpsertPartyRequest.class, legacyPartyRequest );
		LOG.info("Executed overwriteForOrchestration()");
	}
	
	private PutResponseDataHolder putParty(PartyXrefType partyParam, SiperianClient siperianClient) throws ServiceProcessingException {
		LOG.info("Executing putParty()");
		PutRequest putRequest = new PutRequest();
		PutResponse putResponse = null;
		PutResponseDataHolder responseDataHolder = null;
		Calendar cal = null;
		try {
			RecordKey recordKey = new RecordKey();
			// recordKey.setRowid(partyParam.getROWIDOBJECT());
			recordKey.setSourceKey(partyParam.getXREF().get(0).getSRCPKEY());
			recordKey.setSystemName(partyParam.getXREF().get(0).getSRCSYSTEM());
			putRequest.setRecordKey(recordKey);
			// prepare CleansePutRequest
			Record record = new Record();
			// set mapping name
			// record.setSiperianObjectUid(SiperianObjectType.PACKAGE.makeUid(MDMAttributeNames.PARTY_PKG));
			record.setSiperianObjectUid(SiperianObjectType.BASE_OBJECT.makeUid(MDMAttributeNames.PARTY_BO));
			// set input values
			record.setField(new Field(MDMAttributeNames.SRC_UPDT_BY, boXrefUser));
			// record.setField(new Field(MDMAttributeNames.SRC_SYSTEM,
			// (partyParam.getXREF().get(itemIndex)).getSRCSYSTEM()));
			// record.setField(new Field(MDMAttributeNames.SRC_SYS_KEY,
			// (partyParam.getXREF().get(itemIndex)).getSRCPKEY()));
			record.setField(new Field(PartyAttributes.BO_CLASS_CODE, partyParam.getBOCLASSCODE()));
			record.setField(new Field(PartyAttributes.PARTY_NAME, partyParam.getPARTYNAME()));
			record.setField(new Field(PartyAttributes.PARTY_TYPE, partyParam.getPARTYTYPE()));
			record.setField(new Field(PartyAttributes.GEO, partyParam.getGEO()));
			record.setField(new Field(PartyAttributes.REGION, partyParam.getREGION()));
			record.setField(new Field(PartyAttributes.SALES_BLOCK_CD, partyParam.getSALESBLOCKCD()));
			record.setField(new Field(PartyAttributes.TAX_JURSDCTN_CD, partyParam.getTAXJURSDCTNCD()));
			record.setField(new Field(PartyAttributes.VAT_REG_NBR, partyParam.getVATREGNBR()));
			//record.setField(new Field(PartyAttributes.SIP_POP, sipPopVal));
			record.setField(new Field(PartyAttributes.PHYSICAL_GEO, partyParam.getPHYSICALGEO()));
			record.setField(new Field(PartyAttributes.PHYSICAL_REGION, partyParam.getPHYSICALREGION()));
			record.setField(new Field(PartyAttributes.STATUS_CD, partyParam.getSTATUSCD()));
			record.setField(new Field(PartyAttributes.UCN, partyParam.getUCN()));
			record.setField(new Field(PartyAttributes.ENGLISH_NAME, partyParam.getENGLISHNAME()));
			if (partyParam.getSRCCREATEDT() != null && partyParam.getSRCCREATEDT().length() >= 1) {
				cal = convertStringToCalendar(partyParam.getSRCCREATEDT());
				//LOG.info("SRC LUD  of updated Party record = " + cal.getTime());
				putRequest.setLastUpdateDate(cal.getTime());
			}
			putRequest.setRecord(record);
			// execute Put request
			putResponse = (PutResponse) siperianClient.process(putRequest);
			LOG.info("Party Put request processed successfully: " + putResponse.getMessage());
			// extract result
			RecordKey recordKey1 = putResponse.getRecordKey();

			responseDataHolder = new PutResponseDataHolder();
			responseDataHolder.setActionType(putResponse.getActionType());
			responseDataHolder.setActionMessage(putResponse.getMessage());
			responseDataHolder.setRowidObject(recordKey1.getRowid());
			responseDataHolder.setRowidXREF(recordKey1.getRowidXref());
			responseDataHolder.setSourceKey(recordKey1.getSourceKey());
			responseDataHolder.setSystemName(recordKey1.getSystemName());
			LOG.info("ROWID_OBJECT of updated Party record = " + recordKey1.getRowid());

			LOG.debug("Action Type = " + responseDataHolder.getActionType());
			LOG.debug("Action Msg = " + responseDataHolder.getActionMessage());
			LOG.debug("Rowid_xref = " + responseDataHolder.getRowidXREF());
			LOG.debug("Src key = " + responseDataHolder.getSourceKey());
			LOG.debug("System = " + responseDataHolder.getSystemName());

		} catch (SiperianServerException sifExcp) {
			LOG.error("SiperianServerException occured while processing PutRequest for Party: " + sifExcp);
			sifExcp.printStackTrace();
			ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
			customException.setRootExceptionMsg("Put operation failed for Party " + (partyParam.getXREF().get(0)).getSRCPKEY());
			customException.setMessage("SIF exception occured while processing Put request for Party. " + customException.getMessage());
			throw customException;
		} catch (Exception excp) {
			LOG.error("Exception occured while processing PutRequest for Party: " + excp);
			excp.printStackTrace();
			ServiceProcessingException customException = new ServiceProcessingException(excp);
			customException.setMessage("Exception occured while processing Put request for Party. " + customException.getMessage());
			customException.setRootExceptionMsg("Put operation failed for Party " + (partyParam.getXREF().get(0)).getSRCPKEY());
			throw customException;
		}

		LOG.info("Executed PutParty()");
		return responseDataHolder;
	}

	private List<PutResponseDataHolder> putPerson(List<PartyPersonXrefType> personList, PartyXrefType partyParam, SiperianClient siperianClient) throws ServiceProcessingException {
		LOG.info("Executing PutPerson()");
		//String systemUser = "admin";
		int itemIndex = 0;
		PutRequest putRequest = null;
		PutResponse putResponse = null;
		List<PutResponseDataHolder> responseDataHolderList = new ArrayList<PutResponseDataHolder>(personList.size());
		PartyPersonXrefType personParam = null;
		Calendar cal = null;
		try {
			for (itemIndex = 0; itemIndex < personList.size(); itemIndex++) {
				putRequest = new PutRequest();
				personParam = personList.get(itemIndex);
				RecordKey recordKey = new RecordKey();
				recordKey.setSourceKey(personParam.getSRCPKEY());
				recordKey.setSystemName(personParam.getSRCSYSTEM());
				putRequest.setRecordKey(recordKey);
				// prepare CleansePutRequest
				Record record = new Record();
				// set mapping name
				record.setSiperianObjectUid(SiperianObjectType.BASE_OBJECT.makeUid(MDMAttributeNames.PERSON_BO));
				// set input values
				record.setField(new Field(PartyPersonAttributes.SRC_UPD_BY, boXrefUser));
				record.setField(new Field(PartyPersonAttributes.PREFIX, personParam.getPREFIX()));

				record.setField(new Field(PartyPersonAttributes.FIRST_NAME, personParam.getFIRSTNAME()));
				record.setField(new Field(PartyPersonAttributes.MIDDLE_NAME, personParam.getMIDDLENAME()));
				record.setField(new Field(PartyPersonAttributes.LAST_NAME, personParam.getLASTNAME()));
				record.setField(new Field(PartyPersonAttributes.SUFFIX, personParam.getSUFFIX()));
				record.setField(new Field(PartyPersonAttributes.JOB_TITLE, personParam.getJOBTITLE()));
				record.setField(new Field(PartyPersonAttributes.JOB_FUNCTION, personParam.getJOBFUNCTION()));
				record.setField(new Field(PartyPersonAttributes.PERSON_STATUS, personParam.getPERSONSTATUS()));
				// record.setField(new Field(
				// PartyPersonAttributes.SAP_INTEGRATION_ID, personParam));
				record.setField(new Field(PartyPersonAttributes.PERSON_TYPE, personParam.getPERSONTYPE()));
				record.setField(new Field(PartyPersonAttributes.PREF_LANGUAGE, personParam.getPREFLANGUAGE()));
				record.setField(new Field(PartyPersonAttributes.LIST_SOURCE, personParam.getLISTSOURCE()));
				record.setField(new Field(PartyPersonAttributes.DATA_SRC_SYS, personParam.getDATASOURCESYSTEM()));
				record.setField(new Field(PartyPersonAttributes.LATTICE_SCORE, personParam.getLATTICESCORE()));
				record.setField(new Field(PartyPersonAttributes.REPTD_COMP_NAME, personParam.getREPORTEDCOMPANYNAME()));
				record.setField(new Field(PartyPersonAttributes.JOB_LEVEL, personParam.getJOBLEVEL()));
				record.setField(new Field(PartyPersonAttributes.SRC_ACCOUNT_ID, personParam.getSRCACCOUNTID()));
				record.setField(new Field(PartyPersonAttributes.JOB_ROLE, personParam.getJOBROLE()));
				if (partyParam.getSRCCREATEDT() != null && partyParam.getSRCCREATEDT().length() >= 1) {
					cal = convertStringToCalendar(partyParam.getSRCCREATEDT());
					//LOG.info("SRC LUD  of updated Party record = " + cal.getTime());
					putRequest.setLastUpdateDate(cal.getTime());
				}
				putRequest.setRecord(record);
				// execute Put request
				putResponse = (PutResponse) siperianClient.process(putRequest);
				LOG.info("Person Put request processed successfully: " + putResponse.getMessage());
				// extract result
				RecordKey recordKey1 = putResponse.getRecordKey();

				PutResponseDataHolder responseDataHolder = new PutResponseDataHolder();
				responseDataHolder.setActionType(putResponse.getActionType());
				responseDataHolder.setActionMessage(putResponse.getMessage());
				responseDataHolder.setRowidObject(recordKey1.getRowid());
				responseDataHolder.setRowidXREF(recordKey1.getRowidXref());
				responseDataHolder.setSourceKey(recordKey1.getSourceKey());
				responseDataHolder.setSystemName(recordKey1.getSystemName());
				responseDataHolderList.add(responseDataHolder);
				LOG.info("ROWID_OBJECT of updated Person record = " + recordKey1.getRowid());
			}
		} catch (SiperianServerException sifExcp) {
			LOG.error("SiperianServerException occured while processing PutRequest for Person: " + sifExcp);
			LOG.error("Root Cause: " + sifExcp.getCause().getMessage());
			sifExcp.printStackTrace();
			ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
			customException.setMessage("SIF exception occured while processing Put request for Person. " + customException.getMessage());
			customException.setRootExceptionMsg("Put operation failed for Person " + (partyParam.getXREF().get(0)).getSRCPKEY());
			throw customException;
		} catch (Exception excp) {
			LOG.error("Exception occured while processing CleansePutRequest for Party: " + excp);
			excp.printStackTrace();
			ServiceProcessingException customException = new ServiceProcessingException(excp);
			customException.setMessage("Exception occured while processing Put request for Person. " + customException.getMessage());
			customException.setRootExceptionMsg("Put operation failed for Person " + (partyParam.getXREF().get(0)).getSRCPKEY());
			throw customException;
		}

		LOG.info("Executed PutPerson()");
		return responseDataHolderList;
	}

	/**
	 * The method prepares and executes CleansePutRequest on ADDRESS landing
	 * table for the given Address profiles.
	 *
	 * @param addressList
	 *            List of Addresses provided to the web service request
	 * @param partyParam
	 *            Party profile provided to the web service request
	 * @param siperianClient
	 *            SiperianClient SIF connection to MDM Hub
	 * @return List of PutResponseDataHolder object containing processing
	 *         results
	 * @throws ServiceProcessingException
	 */
	private List<PutResponseDataHolder> putAddress(List<AddressXrefType> addressList, PartyXrefType partyParam, SiperianClient siperianClient) throws ServiceProcessingException {
		LOG.info("Executing PutAddress()");
		//String systemUser = "admin";
		int itemIndex = 0;
		PutRequest putRequest = null;
		PutResponse putResponse = null;
		List<PutResponseDataHolder> responseDataHolderList = new ArrayList<PutResponseDataHolder>(addressList.size());
		AddressXrefType addressParam = null;
		Calendar cal = null;
		try {
			for (itemIndex = 0; itemIndex < addressList.size(); itemIndex++) {
				putRequest = new PutRequest();
				addressParam = addressList.get(itemIndex);
				RecordKey recordKey = new RecordKey();
				// recordKey.setRowid(addressParam.getROWIDADDRESS());
				recordKey.setSourceKey(addressParam.getSRCPKEY());
				recordKey.setSystemName(addressParam.getSRCSYSTEM());
				putRequest.setRecordKey(recordKey);
				// prepare CleansePutRequest
				Record record = new Record();
				// set mapping name
				// record.setSiperianObjectUid(SiperianObjectType.PACKAGE.makeUid(MDMAttributeNames.ADDRESS_PKG));
				record.setSiperianObjectUid(SiperianObjectType.BASE_OBJECT.makeUid(MDMAttributeNames.ADDRESS_BO));
				// set input values
				record.setField(new Field(MDMAttributeNames.SRC_UPDT_BY, boXrefUser));
				// record.setField(new Field(MDMAttributeNames.SRC_SYSTEM,
				// addressParam.getSRCSYSTEM()));
				// record.setField(new Field(MDMAttributeNames.SRC_SYS_KEY,
				// addressParam.getSRCPKEY()));
				record.setField(new Field(AddressAttributes.ADDR_LN1, addressParam.getADDRLN1()));
				record.setField(new Field(AddressAttributes.ADDR_LN2, addressParam.getADDRLN2()));
				record.setField(new Field(AddressAttributes.ADDR_LN3, addressParam.getADDRLN3()));
				record.setField(new Field(AddressAttributes.ADDR_LN4, addressParam.getADDRLN4()));
				record.setField(new Field(AddressAttributes.ADDR_STATUS, addressParam.getADDRSTATUS()));
				// if (addressParam.getADDRTYPE() != null &
				// addressParam.getADDRTYPE().length() > 0) {
				record.setField(new Field(AddressAttributes.ADDR_TYPE,Constant.ADDRESS_TYPE_MAILING));
				// }
				record.setField(new Field(AddressAttributes.CITY, addressParam.getCITY()));
				record.setField(new Field(AddressAttributes.COUNTRY_CD, addressParam.getCOUNTRYCD()));
				record.setField(new Field(AddressAttributes.COUNTY, addressParam.getCOUNTY()));
				record.setField(new Field(AddressAttributes.DISTRICT, addressParam.getDISTRICT()));
				record.setField(new Field(AddressAttributes.LANG_CD, addressParam.getLANGCD()));
				record.setField(new Field(AddressAttributes.LATITUDE, addressParam.getLATITUDE()));
				record.setField(new Field(AddressAttributes.LONGITUDE, addressParam.getLONGITUDE()));
				record.setField(new Field(AddressAttributes.POSTAL_CD, addressParam.getPOSTALCD()));
				record.setField(new Field(AddressAttributes.STATE_CD, addressParam.getSTATECD()));
				// record.setField(new
				// Field(MDMAttributeNames.PARTY_SRC_SYS_KEY, ((XREFType)
				// partyParam.getXREF().get(itemIndex)).getSRCPKEY()));
				if (partyParam.getSRCCREATEDT() != null && partyParam.getSRCCREATEDT().length() >= 1) {
					cal = convertStringToCalendar(partyParam.getSRCCREATEDT());
					//LOG.info("SRC LUD  of updated Party record = " + cal.getTime());
					putRequest.setLastUpdateDate(cal.getTime());
				}
				putRequest.setRecord(record);
				// execute Put request
				putResponse = (PutResponse) siperianClient.process(putRequest);
				LOG.info("Address Put request processed successfully: " + putResponse.getMessage());
				// extract result
				RecordKey recordKey1 = putResponse.getRecordKey();

				PutResponseDataHolder responseDataHolder = new PutResponseDataHolder();
				responseDataHolder.setActionType(putResponse.getActionType());
				responseDataHolder.setActionMessage(putResponse.getMessage());
				responseDataHolder.setRowidObject(recordKey1.getRowid());
				responseDataHolder.setRowidXREF(recordKey1.getRowidXref());
				responseDataHolder.setSourceKey(recordKey1.getSourceKey());
				responseDataHolder.setSystemName(recordKey1.getSystemName());
				responseDataHolderList.add(responseDataHolder);
				LOG.info("ROWID_OBJECT of updated Address record = " + recordKey1.getRowid());
			}
		} catch (SiperianServerException sifExcp) {
			LOG.error("SiperianServerException occured while processing PutRequest for Address: " + sifExcp);
			sifExcp.printStackTrace();
			ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
			customException.setMessage("SIF exception occured while processing Put request for Address. " + customException.getMessage());
			customException.setRootExceptionMsg("Put operation failed for Address " + addressParam.getSRCPKEY());
			throw customException;
		} catch (Exception excp) {
			LOG.error("Exception occured while processing PutRequest for Address: " + excp);
			excp.printStackTrace();
			ServiceProcessingException customException = new ServiceProcessingException(excp);
			customException.setMessage("Exception occured while processing Put request for Address. " + customException.getMessage());
			customException.setRootExceptionMsg("Put operation failed for Address " + addressParam.getSRCPKEY());
			throw customException;
		}

		LOG.info("Executed PutAddress()");
		return responseDataHolderList;
	}

	/**
	 * The method prepares and executes CleansePutRequest on COMMUNICATION
	 * landing table for the given Communication profiles.
	 *
	 * @param commList
	 *            List of Communications provided to the web service request
	 * @param partyParam
	 *            Party profile provided to the web service request
	 * @param siperianClient
	 *            SiperianClient SIF connection to MDM Hub
	 * @return List of PutResponseDataHolder object containing processing
	 *         results
	 * @throws ServiceProcessingException
	 */
	private List<PutResponseDataHolder> putCommunication(List<CommunicationXrefType> commList, PartyXrefType partyParam, SiperianClient siperianClient) throws ServiceProcessingException {
		
		
		LOG.info("Executing PutCommunication()");
	
		int itemIndex = 0;
		PutRequest putRequest = null;
		PutResponse putResponse = null;
		List<PutResponseDataHolder> responseDataHolderList = new ArrayList<PutResponseDataHolder>(commList.size());
		CommunicationXrefType commParam = null;
		Calendar cal = null;
		try {
			for (itemIndex = 0; itemIndex < commList.size(); itemIndex++) {
				putRequest = new PutRequest();
				commParam = commList.get(itemIndex);
				RecordKey recordKey = new RecordKey();
				//recordKey.setRowid(commParam.getROWIDCOMMUNICATION());
				recordKey.setSourceKey(commParam.getSRCPKEY());
				recordKey.setSystemName(commParam.getSRCSYSTEM());
				putRequest.setRecordKey(recordKey);
				// prepare CleansePutRequest
				Record record = new Record();
				// set mapping name
				
				record.setSiperianObjectUid(SiperianObjectType.BASE_OBJECT.makeUid(MDMAttributeNames.COMM_BO));
				// set input values
				record.setField(new Field(MDMAttributeNames.SRC_UPDT_BY, boXrefUser));
				
				record.setField(new Field(CommunicationAttributes.COMM_STATUS, commParam.getCOMMSTATUS()));
				
				record.setField(new Field(CommunicationAttributes.COMM_TYPE, commParam.getCOMMTYPE()));
				record.setField(new Field(CommunicationAttributes.COMM_VALUE, commParam.getCOMMVALUE()));

				record.setField(new Field(CommunicationAttributes.PRFRD_COMM_IND, commParam.getPRFRDCOMMIND()));
				record.setField(new Field(CommunicationAttributes.WEB_DOMAIN, commParam.getWEBDOMAIN()));
				record.setField(new Field(CommunicationAttributes.COMM_EXTN, commParam.getCOMMEXTN()));
				if (partyParam.getSRCCREATEDT() != null && partyParam.getSRCCREATEDT().length() >= 1) {
					cal = convertStringToCalendar(partyParam.getSRCCREATEDT());
				//	LOG.info("SRC LUD  of updated Party record = " + cal.getTime());
					putRequest.setLastUpdateDate(cal.getTime());
				}
				// record.setField(new
				// Field(MDMAttributeNames.PARTY_SRC_SYS_KEY, ((XREFType)
				// partyParam.getXREF().get(itemIndex)).getSRCPKEY()));
				//LOG.debug("lastUpdateDate for communication in PUT "+ lastUpdateDate);

				//putRequest.setLastUpdateDate(lastUpdateDate);
				putRequest.setRecord(record);
				// execute Put request
				putResponse = (PutResponse) siperianClient.process(putRequest);
				LOG.info("Communication Put request processed successfully: " + putResponse.getMessage());
				// extract result
				RecordKey recordKey1 = putResponse.getRecordKey();

				PutResponseDataHolder responseDataHolder = new PutResponseDataHolder();
				responseDataHolder.setActionType(putResponse.getActionType());
				responseDataHolder.setActionMessage(putResponse.getMessage());
				responseDataHolder.setRowidObject(recordKey1.getRowid());
				responseDataHolder.setRowidXREF(recordKey1.getRowidXref());
				responseDataHolder.setSourceKey(recordKey1.getSourceKey());
				responseDataHolder.setSystemName(recordKey1.getSystemName());
				responseDataHolderList.add(responseDataHolder);
				LOG.info("ROWID_OBJECT of updated Communication record = " + recordKey1.getRowid());
			}
		} catch (SiperianServerException sifExcp) {
			LOG.error("SiperianServerException occured while processing PutRequest for Communication: " + sifExcp);
			sifExcp.printStackTrace();
			ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
			customException.setMessage("SIF exception occured while processing Put request for Communication. " + customException.getMessage());
			customException.setRootExceptionMsg("Put operation failed for Communication " + commParam.getSRCPKEY());
			throw customException;
		} catch (Exception excp) {
			LOG.error("Exception occured while processing PutRequest for Communication: " + excp);
			excp.printStackTrace();
			ServiceProcessingException customException = new ServiceProcessingException(excp);
			customException.setMessage("Exception occured while processing Put request for Communication. " + customException.getMessage());
			customException.setRootExceptionMsg("Put operation failed for Communication " + commParam.getSRCPKEY());
			throw customException;
		}

		LOG.info("Executed PutCommunication()");
		return responseDataHolderList;
	}
	
	private  List<PartyXrefType> getLegacyRefRecords(PartyXrefType insertedPartyData, List<String> sendToSrcList,String survivingPartyRowid) throws SQLException, ServiceProcessingException {

		LOG.debug("Inside getLegacyRefRecords().");
		PartyXrefType legacyPartyData = null;
		Connection jdbcConn = null;
		Statement statement = null;
		PreparedStatement pstatement = null;
		ResultSet resultSet = null;
		JDBCConnectionProvider jDBCConnectionProvider = null;
		List<PartyXrefType> partyList=new ArrayList<PartyXrefType>();
		StringBuilder sql = new StringBuilder();
	
		sql.append("SELECT * FROM PKG_XREF_PERSON_SEARCH WHERE PARTY_ROWID_OBJECT = ");
		sql.append("'" + survivingPartyRowid.trim() + "'");
		//Added condition to prevent orchestration for merged record
		//sql.append(" and STATUS_CD = 'A'");
		//Change for MDMP-2796 - Added condition to prevent orchestration for Merged and Purged record
		sql.append(" and STATUS_CD IN ('A')");
		sql.append(" and PARTY_ROWID_SYSTEM in (");
		for (String sentTo : sendToSrcList) {
			sql.append("'" + sentTo + "',");
		}
		sql.deleteCharAt(sql.length() - 1).toString();
		sql.append(")");
 			
		LOG.debug("SQL for getLegacyRefRecords()-->" + sql);
		
		try {
			jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
			jdbcConn = jDBCConnectionProvider.getJdbcConnectionFromDS();
			statement = jdbcConn.createStatement();
			resultSet = statement.executeQuery(sql.toString());
			partyList = createXrefCanonicalForm(resultSet);
			//Fetching SAP,SBL,SFDC Xref copies
			//xrefRecMap = searchPartyDAO.createXrefCanonicalFormMultipleParty(resultSet);
		} catch (SQLException exp) {
			exp.getMessage();
		} catch (ServiceProcessingException sexcp) {
			LOG.error("Caught exception in getLegacyRefRecords()" + sexcp);
		} finally {
			// Closing connections
			if (resultSet != null) resultSet.close();
			if (pstatement != null) pstatement.close();
			if (statement != null) statement.close();
			if (jdbcConn != null) jdbcConn.close();// jDBCConnectionProvider.closeJdbcConnection(jdbcConn);
		}

		LOG.debug("Executed getLegacyRefRecords().");
		return partyList;
	}

	private List<PartyXrefType> createXrefCanonicalForm(ResultSet resultSet) throws SQLException {
		LOG.info("Executing Local createXrefCanonicalForm()");
		PartyXrefType party = null;
		ArrayList<PartyXrefType> partyList=new ArrayList<PartyXrefType>();
		XREFType xref = null;
		CommunicationXrefType communication = null;
		PartyPersonXrefType partyPerson = null;
		AddressXrefType address = null;
		

		ArrayList<XREFType> listXref = null;

		Map<String, SearchedXrefRecordCollection> searchedRecCollMap = new HashMap<String, SearchedXrefRecordCollection>();
		SearchedXrefRecordCollection searchedRecCollObj = null;
		boolean bUniqueRec = false;

		while (resultSet.next()) {
			String partyRowId = resultSet.getString("ORIG_ROWID_OBJECT");

			if (!searchedRecCollMap.containsKey(partyRowId)) {

				LOG.debug("Populate searchedXrefRecCollMap for new ORIG_ROWID_OBJECT " + partyRowId);
				searchedRecCollMap.put(partyRowId, new SearchedXrefRecordCollection());
				bUniqueRec = true;
			}

			searchedRecCollObj = searchedRecCollMap.get(partyRowId);

			if (bUniqueRec) {

				// LOG.debug("============setting Xref Copy");

				party = new PartyXrefType();
				party.setROWIDOBJECT(resultSet.getString("PARTY_ROWID_OBJECT"));
				searchedRecCollObj.setParty_rowid(resultSet.getString("PARTY_ROWID_OBJECT"));
				party.setROWIDOBJECT(resultSet.getString("ORIG_ROWID_OBJECT"));
				searchedRecCollObj.setOrig_rowid(resultSet.getString("ORIG_ROWID_OBJECT"));
				party.setBOCLASSCODE(resultSet.getString("BO_CLASS_CODE"));
				searchedRecCollObj.setBo_class(resultSet.getString("BO_CLASS_CODE"));
				party.setPARTYTYPE(resultSet.getString("PARTY_TYPE"));
				searchedRecCollObj.setParty_type(resultSet.getString("PARTY_TYPE"));
				party.setPARTYNAME(resultSet.getString("PARTY_NAME"));
				searchedRecCollObj.setParty_name(resultSet.getString("PARTY_NAME"));
				party.setGEO(resultSet.getString("PARTY_GEO"));
				searchedRecCollObj.setGeo(resultSet.getString("PARTY_GEO"));
				party.setREGION(resultSet.getString("PARTY_REGION"));
				searchedRecCollObj.setRegion(resultSet.getString("PARTY_REGION"));
				party.setSTATUSCD(resultSet.getString("STATUS_CD"));
				searchedRecCollObj.setStatus_cd(resultSet.getString("STATUS_CD"));
				party.setVATREGNBR(resultSet.getString("PARTY_VAT_REG_NBR"));
				searchedRecCollObj.setVat_regno(resultSet.getString("PARTY_VAT_REG_NBR"));
				party.setTAXJURSDCTNCD(resultSet.getString("PARTY_TAX_JURSDCTN_CD"));
				searchedRecCollObj.setTax_jd_cd(resultSet.getString("PARTY_TAX_JURSDCTN_CD"));
				party.setSALESBLOCKCD(resultSet.getString("SALES_BLOCK_CD"));
				searchedRecCollObj.setSales_cd(resultSet.getString("SALES_BLOCK_CD"));
				party.setUCN(resultSet.getString("UCN"));
				searchedRecCollObj.setUcn(resultSet.getString("UCN"));
				party.setENGLISHNAME(resultSet.getString("ENGLISH_NAME"));
				searchedRecCollObj.setEnglish_name(resultSet.getString("ENGLISH_NAME"));
				 Date updateDate = resultSet.getDate("SRC_LUD");
                 if(updateDate != null) {
                     String formatedStartDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(updateDate);     
                    // LOG.debug("============setting PartyXREFType formatedStartDate " + formatedStartDate);
                     searchedRecCollObj.setSrcLudDate(formatedStartDate);    
                     party.setSRCCREATEDT(formatedStartDate);
                 }

				LOG.debug("============setting PartyXREFType");
				xref = new XREFType();
				xref.setSRCSYSTEM(resultSet.getString("PARTY_ROWID_SYSTEM"));
				xref.setSRCPKEY(resultSet.getString("PARTY_PKEY_SRC_OBJECT"));

				// LOG.debug("===Inserting into XREFType list===");
				listXref = new ArrayList<XREFType>();
				listXref.add(xref);
				party.getXREF().addAll(listXref);

			}

				if (resultSet.getString("PERSON_ROWID_OBJECT") != null &&
						!searchedRecCollObj.getPartyPersonXrefMap().containsKey(resultSet.getString("PERSON_ROWID_OBJECT"))) {
					LOG.debug("============setting PartyPerson");
				
					partyPerson = new PartyPersonXrefType();
					partyPerson.setROWIDOBJECT(resultSet.getString("PERSON_ROWID_OBJECT"));
					partyPerson.setSRCSYSTEM(resultSet.getString("PERSON_ROWID_SYSTEM"));
					partyPerson.setSRCPKEY(resultSet.getString("PERSON_PKEY_SRC_OBJECT"));
					partyPerson.setJOBLEVEL(resultSet.getString("JOB_LEVEL"));
					partyPerson.setLATTICESCORE(resultSet.getString("LATTICE_SCORE"));
					partyPerson.setREPORTEDCOMPANYNAME(resultSet.getString("REPTD_COMP_NAME"));
					partyPerson.setLISTSOURCE(resultSet.getString("LIST_SOURCE"));
					partyPerson.setDATASOURCESYSTEM(resultSet.getString("DATA_SRC_SYS"));
					partyPerson.setPREFLANGUAGE(resultSet.getString("PREF_LANGUAGE"));
					partyPerson.setPREFIX(resultSet.getString("PREFIX"));
					partyPerson.setFIRSTNAME(resultSet.getString("FIRST_NAME"));
					partyPerson.setMIDDLENAME(resultSet.getString("MIDDLE_NAME"));
					partyPerson.setLASTNAME(resultSet.getString("LAST_NAME"));
					partyPerson.setPERSONSTATUS(resultSet.getString("PERSON_STATUS"));
					partyPerson.setSUFFIX(resultSet.getString("SUFFIX"));
					partyPerson.setJOBFUNCTION(resultSet.getString("JOB_FUNCTION"));
					partyPerson.setJOBTITLE(resultSet.getString("JOB_TITLE"));
					partyPerson.setPERSONTYPE(resultSet.getString("PERSON_TYPE"));
					/** Modified for SFDC-Track4 START */
					partyPerson.setSRCACCOUNTID(resultSet.getString("SRC_ACCOUNT_ID"));
					partyPerson.setJOBROLE(resultSet.getString("JOB_ROLE"));
					/** Modified for SFDC-Track4 End */
					LOG.debug("===Inserting into PartyPerson Map===");
					searchedRecCollObj.getPartyPersonXrefMap().put(partyPerson.getROWIDOBJECT(), partyPerson);
				}

			if (resultSet.getString("ADDRESS_ROWID_OBJECT") != null && !searchedRecCollObj.getAddressMap().containsKey(resultSet.getString("ADDRESS_ROWID_OBJECT"))) {
				LOG.debug("============setting Address");

				address = new AddressXrefType();
				address.setROWIDADDRESS(resultSet.getString("ADDRESS_ROWID_OBJECT"));
				address.setSRCSYSTEM(resultSet.getString("ADDRESS_ROWID_SYSTEM"));
				address.setSRCPKEY(resultSet.getString("ADDRESS_PKEY_SRC_OBJECT"));
				address.setADDRLN1(resultSet.getString("ADDR_LN1"));
				address.setADDRLN2(resultSet.getString("ADDR_LN2"));
				address.setADDRLN3(resultSet.getString("ADDR_LN3"));
				address.setADDRLN4(resultSet.getString("ADDR_LN4"));
				address.setCITY(resultSet.getString("CITY"));
				address.setCOUNTY(resultSet.getString("COUNTY"));
				address.setDISTRICT(resultSet.getString("DISTRICT"));
				address.setSTATECD(resultSet.getString("STATE_CD"));
				address.setPOSTALCD(resultSet.getString("POSTAL_CD"));
				address.setCOUNTRYCD(resultSet.getString("COUNTRY_CD"));
				address.setLANGCD(resultSet.getString("LANG_CD"));
				address.setLONGITUDE(resultSet.getString("LONGITUDE"));
				address.setLATITUDE(resultSet.getString("LATITUDE"));
				address.setADDRTYPE(resultSet.getString("ADDR_TYPE"));
				address.setADDRSTATUS(resultSet.getString("ADDR_STATUS"));
				address.setADDRMKTGPREF(resultSet.getString("ADDR_MKTG_PREF"));

				LOG.debug("===Inserting into Address Map===");
				searchedRecCollObj.getAddressMap().put(address.getROWIDADDRESS(), address);
			}

			if (resultSet.getString("COMMUNICATION_ROWID_OBJECT") != null && !searchedRecCollObj.getCommMap().containsKey(resultSet.getString("COMMUNICATION_ROWID_OBJECT"))) {
				communication = new CommunicationXrefType();
				LOG.debug("============adding Communication");

				communication.setROWIDCOMMUNICATION(resultSet.getString("COMMUNICATION_ROWID_OBJECT"));
				communication.setSRCSYSTEM(resultSet.getString("COMMUNICATION_ROWID_SYSTEM"));
				communication.setSRCPKEY(resultSet.getString("COMMUNICATION_PKEY_SRC_OBJECT"));
				communication.setCOMMTYPE(resultSet.getString("COMM_TYPE"));
				communication.setCOMMVALUE(resultSet.getString("COMM_VALUE"));
				communication.setCOMMSTATUS(resultSet.getString("COMM_STATUS"));
				communication.setPRFRDCOMMIND(resultSet.getString("PRFRD_COMM_IND"));
				communication.setWEBDOMAIN(resultSet.getString("WEB_DOMAIN"));
				communication.setCOMMEXTN(resultSet.getString("COMM_EXTN"));
				communication.setCOMMMKTGPREF(resultSet.getString("COMM_MKTG_PREF"));
				/** Modified for SFDC-Track4 START */
				communication.setCOMMSALESPREF(resultSet.getString("COMM_SALES_PREF"));
				/** Modified for SFDC-Track4 End */
				LOG.debug("===Inserting into Communication Map===");
				searchedRecCollObj.getCommMap().put(communication.getROWIDCOMMUNICATION(), communication);
			}


			bUniqueRec = false;
			LOG.debug("====Populating Party records");
			if (party != null && searchedRecCollObj != null) {
				party.getPartyPerson().addAll(searchedRecCollObj.getPartyPersonXrefMap().values());
				party.getAddress().addAll(searchedRecCollObj.getAddressMap().values());
				party.getCommunication().addAll(searchedRecCollObj.getCommMap().values());
			}
			partyList.add(party);
		//}
	}
	
		LOG.info("Executed Local createXrefCanonicalForm()");
		return partyList;

	}

	

	//Updating APPRVD_FOR_MERGE = N in C_B_PARTY for Survivor Record if APPRVD_FOR_MERGE is set
	private void updateApprvdForMerge(String survivingRowidObject) throws ServiceProcessingException	{

		LOG.debug("Inside updateApprvdForMerge()");
		Connection jdbcConn = null;
		Statement statement = null;
		JDBCConnectionProvider jDBCConnectionProvider = null;
		int rowCnt = 0;

		String sql = "UPDATE C_B_PARTY SET APPRVD_FOR_MERGE = 'N' WHERE APPRVD_FOR_MERGE = 'Y' AND ROWID_OBJECT = '" + survivingRowidObject + "'";

		LOG.debug("SQL in updateApprvdForMerge()--> " + sql);

		try{
			jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
			jdbcConn = jDBCConnectionProvider.getJdbcConnectionFromDS();
			statement = jdbcConn.createStatement();
			rowCnt = statement.executeUpdate(sql);

			jdbcConn.commit();
			LOG.debug("No of records Updated with APPRVD_FOR_MERGE : " + rowCnt);
			LOG.debug("APPRVD_FOR_MERGE value updated to N in C_B_PARTY for partyID: " + survivingRowidObject);

		} catch(SQLException exp) {
			LOG.error("Caught SQLException in updateApprvdForMerge() " ,exp);

		} finally	{
			try {
				//Closing connections
			//	if (resultSet != null)	resultSet.close();
				if (statement != null) statement.close();
				if (jdbcConn != null) jdbcConn.close();
				} catch (SQLException exp) {
					LOG.error("SQLexp caught in updateApprvdForMerge(): " , exp);
				}

		}

		LOG.debug(" Executed updateApprvdForMerge() successfully ");
	}

	public static Calendar convertStringToCalendar(String inputDate)	{
		LOG.debug(" Executing convertStringToCalendar()."+inputDate);
		String dateformat = null;
		if(!Util.isNullOrEmpty(inputDate) && inputDate.length() == 10)	{
			dateformat = "yyyy-MM-dd";
		} else if(!Util.isNullOrEmpty(inputDate) && inputDate.length() > 10) {
			dateformat = "yyyy-MM-dd HH:mm:ss";
		}
		DateFormat sdf = new SimpleDateFormat(dateformat);
	//	DateFormat sdf = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
	//	String convertedDate = null;
		Calendar cal = Calendar.getInstance();
		Date dateObject = null;

		if (!Util.isNullOrEmpty(inputDate))	{
				LOG.debug("InputDate from request: " + inputDate);
				try {
					dateObject = sdf.parse(inputDate);
					cal.setTime(dateObject);
				//	convertedDate = sdf.format(dateObject);
					LOG.debug("Converted dateObject: " + cal.getTime());
				} catch (ParseException pexp) {
					LOG.error("Parse Exception in convertStringToCalendar(): " , pexp);
				}
		}
		LOG.debug(" Executed convertStringToCalendar().");
		return cal;
	}
	

	/** Modified for SFDC END */
	

	
	/**
	 * validate input MSG_TRKN_ID
	 * 
	 * @param curParty
	 * @param upsertResponse
	 */
	private void validateMsgTrackingId(PartyXrefType curParty, MdmUpsertPartyResponse upsertResponse)  throws ServiceProcessingException {
		LOG.debug("[validateMsgTrackingId] ENTER");
		try {
		if(Util.isNullOrEmpty(curParty.getMSGTRKNID())) {
			String respMsg = "No Message Tracking ID found";//messagesProp.getProperty(Constant.INFO_MSG_TRKN_ID_VALIDATION);
			if (Util.isNullOrEmpty(upsertResponse.getStatus())) {
				upsertResponse.setStatus(respMsg);
			} else {
				upsertResponse.setStatus(upsertResponse.getStatus() + "\n" + respMsg);
			}
				upsertResponse.setErrorCd(Constant.ERROR_CONTACT_MSG_TRKN_ID_VALIDATION);
				upsertResponse.setErrorMsg(respMsg);
				updateErrorStatus(curParty, upsertResponse, Constant.ERROR_CONTACT_MSG_TRKN_ID_VALIDATION,"0");
				
				throw new ServiceProcessingException(Constant.ERROR_CONTACT_MSG_TRKN_ID_VALIDATION);
				 
			}
		}
		catch (ServiceProcessingException e) {
			 if(Constant.ERROR_CONTACT_MSG_TRKN_ID_VALIDATION.equals(e.getMessage())){
				 updateErrorStatus(curParty, upsertResponse, Constant.ERROR_CONTACT_MSG_TRKN_ID_VALIDATION,"0");
				} 
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (Exception exp) {
			 if(Constant.ERROR_CONTACT_MSG_TRKN_ID_VALIDATION.equals(exp.getMessage())){
				 updateErrorStatus(curParty, upsertResponse, Constant.ERROR_CONTACT_MSG_TRKN_ID_VALIDATION,"0");
				} 
			// TODO Auto-generated catch block
			 exp.printStackTrace();
		}
		LOG.debug("[validateMsgTrackingId] EXIT");
		return;
	}
	
	
	//Fetch Party Pkeys for party-Rowid
		public List<String> getPartyPkeys(String partyID) throws ServiceProcessingException	{
			LOG.debug("Inside getPartyPkeys");
			Connection jdbcConn = null;
			Statement statement = null;
			ResultSet resultSet = null;
			List<String> pkeyList = new ArrayList<String>();
			
			StringBuilder sql = new StringBuilder();
			sql.append("select PKEY_SRC_OBJECT from C_B_PARTY_XREF where ROWID_OBJECT = (");
			sql.append("'" + partyID.trim() + "'");
			sql.append(") and ROWID_SYSTEM in ('SFC')");
			
			LOG.debug("Query for getPartyPkeys: "+sql.toString());
			
			try {
					JDBCConnectionProvider jDBCConnectionProvider =  JDBCConnectionProvider.getSingleInstance();
					jdbcConn = jDBCConnectionProvider.getJdbcConnectionFromDS();
					statement = jdbcConn.createStatement();
					resultSet = statement.executeQuery(sql.toString());
		
					while (resultSet.next()) {
						pkeyList.add(resultSet.getString(1));
					}
			 } catch(SQLException sqlex) {
				 LOG.error("Caught sql exception in getPartyPkeys()." + sqlex);
			 } finally {
				try {	//Closing connections
						if (resultSet != null) resultSet.close();
						if (statement != null) statement.close();
						if (jdbcConn != null) jdbcConn.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
			 }
			LOG.debug("Executed getPartyPkeys");
			return pkeyList;	
		}
		
		public boolean checkAccountExist(String pkeyscrAccount) throws ServiceProcessingException {
			LOG.info("Executing checkAccountExist()");
			
			
			Statement statement = null;
			StringBuilder sqlQry = new StringBuilder();
			JDBCConnectionProvider jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();;
			Connection jdbcConnection = null;
			ResultSet resultSet = null;		
			int recordCount = 0;
			boolean accountExist = false;
			
			try {
				sqlQry.append(Constant.QUERY_GET_ID_IN_PARTY_BY_PKEY);
				sqlQry.append("'"+pkeyscrAccount + "'");
				jdbcConnection = jDBCConnectionProvider.getJdbcConnectionFromDS();
				//statement = jdbcConnection.prepareStatement(Constant.COUNT_FROM_PARTY_XREF);
				statement = jdbcConnection.createStatement();
				resultSet = statement.executeQuery(sqlQry.toString());
					LOG.info("Query to fetch presence of SFC Account record: " + sqlQry);

				
					while (resultSet.next()) {
						recordCount = resultSet.getInt(1);
						
					}	
					LOG.info("Record count with Account  = " + recordCount);
					if (recordCount > 0) {
						accountExist = true;
					}
				
				
			} catch (SQLException sqlEx) {
				LOG.error("Exception occurred while checking the presence of Account Record: ", sqlEx);
				//sqlEx.printStackTrace();
				ServiceProcessingException customException = new ServiceProcessingException(sqlEx);
				customException.setMessage("Failed to check the presence of of Account Record: " + sqlEx.getMessage());
				throw customException;
			} finally {
				try {
						if( resultSet != null)	resultSet.close();
						if( statement != null) statement.close();
						if(jdbcConnection != null) jdbcConnection.close();
					} catch (SQLException e) {
						
						e.printStackTrace();
					}
			}
			
			LOG.info("Executed checkAccountExist()");
			
			return accountExist;
		}
		public List<String> getRowidsByPartyRowId(List<String> rowidXrefList,String BO) throws ServiceProcessingException	{
			LOG.debug("[getRowidsByPartyRowId] ENTER");
			Connection jdbcConn = null;
			Statement statement = null;
			ResultSet resultSet = null;
			List<String> RowIdList = new ArrayList<String>();
			
			StringBuilder sqlQuery = new StringBuilder();
			if (BO.equalsIgnoreCase(MDMAttributeNames.PARTY_BO))
			{
				sqlQuery.append(Constant.QUERY_GET_PARTY_ROWID_QUERY);
			}
			if (BO.equalsIgnoreCase(MDMAttributeNames.PARTY_ORG_BO))
			{
				sqlQuery.append(Constant.QUERY_GET_ORGEXTN_ROWID_QUERY);
			}
			else if (BO.equalsIgnoreCase(MDMAttributeNames.CLASS_BO))
			{
				sqlQuery.append(Constant.QUERY_GET_CLSFN_ROWID_QUERY);
			}
			else if (BO.equalsIgnoreCase(MDMAttributeNames.ADDRESS_BO))
			{
				sqlQuery.append(Constant.QUERY_GET_ADDR_ROWID_QUERY);
			}
			else if (BO.equalsIgnoreCase(MDMAttributeNames.COMM_BO))
			{
				sqlQuery.append(Constant.QUERY_GET_COMM_ROWID_QUERY);
			}
			else if (BO.equalsIgnoreCase(MDMAttributeNames.PARTY_PROSPECT_BO))
			{
				sqlQuery.append(Constant.QUERY_GET_PROSPECT_ROWID_QUERY);
			}
			//sqlQuery.append("'" + partyID.trim() + "'" +")");
			for (String rowidXref : rowidXrefList) {
				sqlQuery.append("'" + rowidXref + "',");
			}
			sqlQuery.deleteCharAt(sqlQuery.length() - 1).toString();
			sqlQuery.append(")");
			
			LOG.debug("Query for getRowidsByPartyRowId: "+sqlQuery.toString());
			
			try {
					JDBCConnectionProvider jDBCConnectionProvider =  JDBCConnectionProvider.getSingleInstance();
					jdbcConn = jDBCConnectionProvider.getJdbcConnectionFromDS();
					statement = jdbcConn.createStatement();
					resultSet = statement.executeQuery(sqlQuery.toString());
		
					while (resultSet.next()) {
						RowIdList.add(resultSet.getString(1));
					}
			 } catch(SQLException sqlex) {
				 LOG.error("Caught sql exception in getRowidsByPartyRowId()." + sqlex);
			 } finally {
				try {	//Closing connections
						if (resultSet != null) resultSet.close();
						if (statement != null) statement.close();
						if (jdbcConn != null) jdbcConn.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
			 }
			LOG.debug("Executed getRowidsByPartyRowId");
			return RowIdList;	
		}
		
		
		public String  checkUnMergeByDS(String rowid,String matchedrowid)
				throws ServiceProcessingException {
			LOG.debug("[checkUnMerge] Enter");
			String unmergeFlag = null;
			Connection jdbcConn = null;
				
				if (rowid != null && matchedrowid!=null) {
						CallableStatement callStmt = null;
						try {
							JDBCConnectionProvider jDBCConnectionProvider =  JDBCConnectionProvider.getSingleInstance();
							jdbcConn = jDBCConnectionProvider.getJdbcConnectionFromDS();
							callStmt = jdbcConn.prepareCall("{call CHECK_IF_USER_IN_DS_ROLE_RT(?,?,?,?)}");
							callStmt.setString(1, rowid);
							callStmt.setString(2, matchedrowid);
							callStmt.registerOutParameter(3, OracleTypes.VARCHAR);
							callStmt.registerOutParameter(4, OracleTypes.VARCHAR);
							LOG.debug("[checkUnMerge] Calling   CHECK_IF_USER_IN_DS_ROLE_RT"
									+ " for ROWID::" + rowid);
							callStmt.execute();
							 unmergeFlag = callStmt.getString(4);
							LOG.debug("[checkUnMerge] Calling   CHECK_IF_USER_IN_DS_ROLE_RT"
									+ " for unmergeFlag::" + unmergeFlag);
						}catch(SQLException sqlex) {
							 LOG.error("Caught sql exception in checkUnMergeByDS()." + sqlex);
						 }  finally {
							if (callStmt != null) {
								try {
									callStmt.close();
								} catch (SQLException e) {
								}
							}
						}
					
				}
				LOG.debug("[checkUnMerge] Exit");
				return unmergeFlag;
			} 
		//Update C_REPOS_MQ_DATA_CHANGE table to set flag 9 for SFDC records for which record has created
		private void setMsgSentFlagInTable(String rowidobject) throws ServiceProcessingException {
			LOG.info("Executing setMsgSentFlagInTable()");
			String sql = null;
			LOG.debug("Inside setMsgSentFlagInTable()");
			Connection jdbcConn = null;
			Statement statement = null;
			PreparedStatement pstmt = null;
			JDBCConnectionProvider jDBCConnectionProvider = null;
			int rowCnt = 0;
			if (rowidobject != null)
			{
				
			 sql = "update C_REPOS_MQ_DATA_CHANGE set SENT_STATE_ID = 9 where rowid_object = '" + rowidobject + "' and src_rowid_system = 'SFC' and tgt_rowid_system IN('SAP','SBL','SFC','ELQ') and SENT_STATE_ID = 0 ";
			}
			LOG.debug("SQL in setMsgSentFlagInTable()--> " + sql);
			try {
			jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
			jdbcConn = jDBCConnectionProvider.getJdbcConnectionFromDS();
			
			statement = jdbcConn.createStatement();
			rowCnt = statement.executeUpdate(sql);

			jdbcConn.commit();
			LOG.debug("Commited & No Of Records Updated: " + rowCnt);
			LOG.debug("Flag value updated in C_REPOS_MQ_DATA_CHANGE for party: " + rowidobject);
			}  catch(SQLException exp) {
				LOG.error("Caught SQLException in setMsgSentFlagInTable() " ,exp);

			} finally	{
				try {
						//Closing connections
					//	if (resultSet != null) resultSet.close();
						if (pstmt != null) pstmt.close();
						if (statement != null) statement.close();
						if (jdbcConn != null) jdbcConn.close();
					} catch (SQLException exp) {
						LOG.error("SQLexp caught in setMsgSentFlagInTable().");
					}

			}
			LOG.info("Executed setMsgSentFlagInTable()");
		}
		public void checkDataQualityUpsert(PartyXrefType upsertParty,MdmUpsertPartyResponse upsertPartyResponse, boolean retry, boolean executeNextStep,String rowidObject) throws ServiceProcessingException {		
			
			LOG.info("Executing checkDataQualityUpsert()");
			
			PerformanceLoggerUtil perfLog = new PerformanceLoggerUtil();
			/** MDM service will reject  contact that comes with contact name of Unknown START*/
			if(!validateContactNameNullUnknown(upsertParty, upsertPartyResponse)){
				// contact name  is Not Valid
				LOG.debug("[validateContactNameNullUnknown] check for contact name for Null or Unknown");
				LOG.debug(
						"SFDC contact record does not have Valid PARTY_NAME, hence bypassing SFDC contact insertion: ");
				upsertPartyResponse.setErrorMsg("CONTACT_NAME is UNKNOWN OR Junk Value. Request is not processed");
				upsertPartyResponse.getUpsertStatus().setErrorCode( Constant.ERROR_CONTACT_NAME_UNKWN);
				upsertPartyResponse.getUpsertStatus().setErrorMsg(upsertPartyResponse.getStatus());
				updateErrorStatus(upsertParty, upsertPartyResponse, Constant.ERROR_CONTACT_NAME_UNKWN,"0");
				throw new ServiceProcessingException(upsertPartyResponse.getStatus());
			}
			if(!validateContactName(upsertParty, upsertPartyResponse)){
				// contact name  is Not Valid
				LOG.debug(
						"SFDC contact record does not have Valid PARTY_NAME, hence bypassing SFDC contact insertion: ");
				upsertPartyResponse.setErrorMsg("CONTACT_NAME is UNKNOWN OR Junk Value. Request is not processed");
				upsertPartyResponse.getUpsertStatus().setErrorCode( Constant.ERROR_CONTACT_NAME_UNKWN);
				upsertPartyResponse.getUpsertStatus().setErrorMsg(upsertPartyResponse.getStatus());
				updateErrorStatus(upsertParty, upsertPartyResponse, Constant.ERROR_CONTACT_NAME_UNKWN,"0");
				throw new ServiceProcessingException(upsertPartyResponse.getStatus());
			}
			// check for Account Address for Null or Unknown  
			if(!(CollectionUtils.isEmpty(upsertParty.getAddress()) || upsertParty.getAddress().get(0) == null))
			{
			LOG.debug("[updateSFDCAccount] check for Account Address for Null or Unknown");
			if (!validateAccountAddressNullUnknown(upsertParty,
					upsertPartyResponse)) {
				// REPORTED ADDRESS OR CITY HAVE null or unknown
				LOG.debug("SFDC Account record have NULL or Unknown "
						+ upsertParty.getXREF().get(0).getSRCPKEY());
				upsertPartyResponse.setErrorMsg("Address is blank or Unknown or Junk Value");
				upsertPartyResponse.getUpsertStatus().setErrorCode(Constant.ERROR_CONTACT_ADDR_LN1_UNKWN);
				upsertPartyResponse.getUpsertStatus().setErrorMsg(upsertPartyResponse.getStatus());
				upsertPartyResponse.getUpsertStatus().setCURRENTPROCESSSTEP(configProps.getProperty(upsertPartyResponse.getStatus()+"_RETRY"));
				updateErrorStatus(upsertParty, upsertPartyResponse, Constant.ERROR_CONTACT_ADDR_LN1_UNKWN,"0");
				throw new ServiceProcessingException(upsertPartyResponse.getStatus());
			}
			LOG.debug("[updateSFDCAccount] check for Account City for Null or Unknown");
			if (!validateAccountCitysNullUnknown(upsertParty,
					upsertPartyResponse)) {
				// REPORTED  CITY HAVE null or unknown
				LOG.debug("SFDC Account record have NULL or Unknown "
						+ upsertParty.getXREF().get(0).getSRCPKEY());
				upsertPartyResponse.setErrorMsg("City is blank or Unknown or Junk Value");
				upsertPartyResponse.getUpsertStatus().setErrorCode(Constant.ERROR_CONTACT_CITY_UNKWN);
				upsertPartyResponse.getUpsertStatus().setErrorMsg(upsertPartyResponse.getStatus());
				upsertPartyResponse.getUpsertStatus().setCURRENTPROCESSSTEP(configProps.getProperty(upsertPartyResponse.getStatus()+"_RETRY"));
				updateErrorStatus(upsertParty, upsertPartyResponse, Constant.ERROR_CONTACT_CITY_UNKWN,"0");
				throw new ServiceProcessingException(upsertPartyResponse.getStatus());
			}
			LOG.debug("[updateSFDCAccount] check for Account Address for Junk");
			// check for Account Address for Junk and reject the account request
			if (!validateAccountAddressJunk(upsertParty, upsertPartyResponse)) {
				LOG.debug("SFDC Account record have AddressLn1 or city junk ::Rejecting"
						+ upsertParty.getXREF().get(0).getSRCPKEY());
				upsertPartyResponse.setErrorMsg("Address has Junk Value");
				upsertPartyResponse.getUpsertStatus().setErrorCode(Constant.ERROR_CONTACT_CITY_UNKWN);
				upsertPartyResponse.getUpsertStatus().setErrorMsg(upsertPartyResponse.getStatus());
				upsertPartyResponse.getUpsertStatus().setCURRENTPROCESSSTEP(configProps.getProperty(upsertPartyResponse.getStatus()+"_RETRY"));
				updateErrorStatus(upsertParty, upsertPartyResponse, Constant.ERROR_CONTACT_CITY_UNKWN,"0");
				throw new ServiceProcessingException(upsertPartyResponse.getStatus());

			}
			}
			/** MDM service will reject any  account that comes with company name of Unknown END*/
			
			// ReSetting PartyType = 'Partner' OR 'Prospective Partner'
			//resetPartyType(upsertParty);
			if(executeNextStep)
				preUpsertMatchProcess( upsertParty, upsertPartyResponse,  retry,  executeNextStep, rowidObject);

		}
		
		/**
		 * @param upsertParty
		 * @param upsertPartyResponse
		 * @throws ServiceProcessingException
		 */
		public void preUpsertMatchProcess(PartyXrefType upsertParty,MdmUpsertPartyResponse upsertPartyResponse, boolean retry, boolean executeNextStep, String rowidObject) throws ServiceProcessingException {
						
			String rowid_object = null;
			//Check if party exist
			rowid_object = searchDao.getPartyRowidObject(upsertParty.getXREF().get(0).getSRCPKEY(), upsertParty.getXREF().get(0).getSRCSYSTEM());
	        //self match rule call for existing party
			if (!Util.isNullOrEmpty(rowid_object)) {
				
				PartyXrefType insertedContactData = new PartyXrefType();
				if( (!upsertParty.getPARTYTYPE().equalsIgnoreCase(Constant.BO_CLASS_CODE_PERSON) &&
						(insertedContactData.getPARTYTYPE().equalsIgnoreCase(Constant.BO_CLASS_CODE_PERSON))))  {

					LOG.info("Contact is not updated since the  PARTY_TYPE is not matched with the existing PARTY_TYPE)");
					upsertPartyResponse.setStatus("Contact is not updated since the  PARTY_TYPE is not matched with the existing PARTY_TYPE");
					upsertPartyResponse.setErrorMsg("Contact is not updated since the  PARTY_TYPE is not matched with the existing PARTY_TYPE");
					upsertPartyResponse.getUpsertStatus().setErrorCode( Constant.ERROR_CONTACT_WRONG_CONTACT_TYP);
					updateErrorStatus(upsertParty, upsertPartyResponse, Constant.ERROR_CONTACT_WRONG_CONTACT_TYP,"0");
					throw new ServiceProcessingException(Constant.ERROR_CONTACT_WRONG_CONTACT_TYP);
				}
				
				
			}
			if(executeNextStep)
				processCleansePutRequest( upsertParty, upsertPartyResponse,  retry,  executeNextStep, rowidObject);
	}
		
		
		
	/*	public void upsertMatchMergeProcess(PartyXrefType upsertParty,MdmUpsertPartyResponse upsertPartyResponse, boolean retry, boolean executeNextStep, String rowidObject){
			
			PerformanceLoggerUtil perfLog = new PerformanceLoggerUtil();
			PutResponseDataHolder putRespDataParty = null;		

			//Process to Stamp the MDM_LEGACY_ID from C_B_ACCOUNT_XREF to C_B_PARTY_XREF			
			try {
				//putRespDataParty = (PutResponseDataHolder) putRespDataHolderMap.get(MDMAttributeNames.ENTITY_PARTY);
				//Check match exclusion and meat merge party
				//checkMatchExclusion(upsertParty,upsertPartyResponse,putRespDataHolderMap);
				// Murge child records
				//childMultiMergeParty(upsertParty,upsertPartyResponse, putRespDataParty );
				stampMdmLegacyId(putRespDataParty.getSourceKey());
			} catch (ServiceProcessingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			

			perfLog.printLog(Constant.PERF_LOG_FLOW_UPSERT_SAP_SBL, upsertParty.getXREF().get(0).getSRCPKEY(), 
					"STEP 14", "Stamp MDM LegacyID Done");
			
		}*/
		
		public void upsertMatchMergeProcess(PartyXrefType upsertParty,MdmUpsertPartyResponse upsertPartyResponse, boolean retry, boolean executeNextStep, String rowidObject) throws ServiceProcessingException{
			
			PerformanceLoggerUtil perfLog = new PerformanceLoggerUtil();
			PutResponseDataHolder putRespDataParty = null;
			//putRespDataParty = (PutResponseDataHolder) putRespDataHolderMap.get(MDMAttributeNames.ENTITY_PARTY);
			
			try {
				//Check match exclusion and process match and merge the party
				matchMergeProcessContact(upsertParty,upsertPartyResponse);
				// Murge child records
				//if (mergeInd){
				childMultiMergeParty(upsertParty,upsertPartyResponse, putRespDataParty );
				//}
				
			} catch (ServiceProcessingException e) {
				 updateErrorStatus(upsertParty,upsertPartyResponse , Constant.ERROR_CONTACT_MERGE_FAIL,rowidObject);
				throw e;
			}
			catch (Exception exp) {
				 updateErrorStatus(upsertParty,upsertPartyResponse , Constant.ERROR_CONTACT_MERGE_FAIL,rowidObject);
				throw exp;
			}
			perfLog.printLog(Constant.PERF_LOG_FLOW_UPSERT_SAP_SBL, upsertParty.getXREF().get(0).getSRCPKEY(), 
					"STEP 14", "Stamp MDM LegacyID Done");			
			if(executeNextStep)
				upsertUCNStampProcess(upsertParty,upsertPartyResponse, retry,executeNextStep,rowidObject);
			
			
		}
		
		public void matchMergeProcessContact(PartyXrefType upsertParty,MdmUpsertPartyResponse upsertPartyResponse ){
			// fetch inserted party details and use that for match and merge
			PartyXrefType insertedPartyData = new PartyXrefType();
			String rowidObject = null;
			HashMap<Integer, HighestScoreRecordHolder> mergeSorceHolderMap = new HashMap<Integer, HighestScoreRecordHolder>();
			HighestScoreRecordHolder highestScoreRecordHoldertgt = new HighestScoreRecordHolder();
			int matchCountOfRetry = Integer.parseInt(configProps.getProperty("NoOfRetries"));
			boolean exclusionPatternExists = false;
			PerformanceLoggerUtil perfLog = new PerformanceLoggerUtil();
			try {
				//PutResponseDataHolder putRespDataParty = (PutResponseDataHolder) putRespDataHolderMap.get(MDMAttributeNames.ENTITY_PARTY);
				insertedPartyData = getPartyDAO.fetchContactXrefTypeFromORS(upsertParty.getXREF().get(0).getSRCSYSTEM(), upsertParty.getXREF().get(0).getSRCPKEY());
				
				LOG.info("Got insertedContactData from GetPartyDAO for ContactID: " + insertedPartyData.getROWIDOBJECT());
				sipPopVal = getPartyDAO.getSipPopFromXref();
				LOG.info("sipPopVal is: " + sipPopVal);
				rowidObject = insertedPartyData.getROWIDOBJECT();
				perfLog.printLog(Constant.PERF_LOG_FLOW_UPSERT_SAP_SBL, upsertParty.getXREF().get(0).getSRCPKEY(), 
						"STEP 12", "Create canonical format Done");
				try {
					LOG.debug("matchMergeProcessContact  !!");
				/*	exclusionPatternExists = isMatchExclusionPatternExists(rowidObject);
					if (exclusionPatternExists) {
						LOG.info("Match exclusion pattern exists for the party, bypassing match & merge process and creating task for DS");
						
						String title = "Match Exclusion";
						String comment = "Match Exclusion pattern is present for the PartyID: " + rowidObject;
						processCreateTaskRequest(null, rowidObject, "FinalReview", title, comment);
						
					} else {*/
						mergeProcessContact(mergeSorceHolderMap, upsertPartyResponse, highestScoreRecordHoldertgt, insertedPartyData,rowidObject);
						LOG.debug("Merge is successful on PARTY & ACCOUNT entities !!");
					//}
				} catch (ServiceProcessingException servExcp) {

					LOG.error("Caught ServiceProcessingException in mergeProcessParty: " , servExcp);
					LOG.error("Root Exception Message: " + servExcp.getRootExceptionMsg());
					LOG.error("Localized Message: " + servExcp.getCause().getLocalizedMessage());
					LOG.error(" Message: " + servExcp.getCause().getMessage());
					throw servExcp;
				

					
				} catch (Exception Excp) {
					LOG.error("Caught exception in mergeProcessParty: " , Excp);
					warning.append("Merge Process failed. \n");					
	
					// Checking whether Match and Merge Operation Done or not
					if (matchInd) {
						upsertPartyResponse.setStatus(upsertPartyResponse.getStatus() + " Matching record found for Party.");
						matchInd = false;
					} else {
						upsertPartyResponse.setStatus(upsertPartyResponse.getStatus() + " No matching record found for Party.");
					}
					if (mergeInd) {
						upsertPartyResponse.setStatus(upsertPartyResponse.getStatus() + " Merge operation successful for Party and Account " + upsertParty.getXREF().get(0).getSRCPKEY() + ". Surviving rowid_object = "
								+ upsertPartyResponse.getParty().get(0).getROWIDOBJECT());
					} else {
						upsertPartyResponse.setStatus(upsertPartyResponse.getStatus() + " Merge not done for Party " + upsertParty.getXREF().get(0).getSRCPKEY());
					}
					throw Excp;
			
				}
			}catch(Exception exp){
				LOG.error("Caught ServiceProcessingException in mergeProcessParty: " , exp);
				LOG.error("Root Exception Message: " + exp.getMessage());
				
			}
			return ;	
			
			}

	public void upsertDataValidation(PartyXrefType upsertParty, MdmUpsertPartyResponse upsertPartyResponse,
			boolean excuteNextStep, boolean executeFromStart, String rowidObject) throws ServiceProcessingException{

		LOG.info("Executing upsertDataValidation()");

		PerformanceLoggerUtil perfLog = new PerformanceLoggerUtil();
		
		// Check for Account Record Type
		try {

			if ((!Util.isNullOrEmpty(upsertParty.getPARTYTYPE()))
					&& (!Constant.BO_CLASS_CODE_PERSON.equalsIgnoreCase(upsertParty.getPARTYTYPE()))) {

				LOG.info("Contact is not created since it's PARTY_TYPE is not in ('Person')");
				upsertPartyResponse
						.setStatus("Contact blocking successful for invalid PARTY_TYPE. Account with PARTY_TYPE = '"
								+ upsertParty.getPARTYTYPE() + "' not created in MDM");
				upsertPartyResponse
						.setErrorMsg("Contact blocking successful for invalid PARTY_TYPE. Contact with PARTY_TYPE = '"
								+ upsertParty.getPARTYTYPE() + "' not created in MDM");
				throw new ServiceProcessingException(Constant.ERROR_CONTACT_INVALID_PTY_TYP);
			}

			validateMsgTrackingId(upsertParty, upsertPartyResponse);
			// Contact minimum data criteria--> IF (FIRSTNAME is NOT NULL
			// OR LASTNAME is NOT NULL) AND (EMAIL_ADDRESS is NOT NULL)
			// AND (COUNTRY_CD is NOT NULL)
			// validateContactRequest(upsertParty, upsertPartyResponse);

			if (upsertParty.getPartyPerson() != null) {

				String fName = upsertParty.getPartyPerson().get(0).getFIRSTNAME();
				String lName = upsertParty.getPartyPerson().get(0).getLASTNAME();
				String accountId = upsertParty.getPartyPerson().get(0).getSRCACCOUNTID();

				if (Util.isNullOrEmpty(accountId)) {
					createUpsertInfoMessage(upsertPartyResponse, Constant.ERROR_CONTACT_EMPTY_SRC_CONTACT_ID);
					throw new ServiceProcessingException(Constant.ERROR_CONTACT_EMPTY_SRC_CONTACT_ID);
				}
				if (Util.isNullOrEmpty(fName) && Util.isNullOrEmpty(lName)) {
					createUpsertInfoMessage(upsertPartyResponse, Constant.INFO_CONTACT_EMPTY_FNAME_LNAME);
					throw new ServiceProcessingException(Constant.ERROR_CONTACT_EMPTY_FNAME_LANME);
				}
			} else {
				createUpsertInfoMessage(upsertPartyResponse, Constant.INFO_CONTACT_EMPTY_FNAME_LNAME);
				throw new ServiceProcessingException(Constant.ERROR_CONTACT_EMPTY_FNAME_LANME);
			}
			// if (Util.isNullOrEmpty(upsertParty.getPARTYNAME())) {
			/*
			 * Checking if Email_Address from Communication is NULL OR NOT NULL
			 */
			List<CommunicationXrefType> commXrefTypeList = upsertParty.getCommunication();
			if (CollectionUtils.isEmpty(commXrefTypeList)) {
				createUpsertInfoMessage(upsertPartyResponse, Constant.INFO_CONTACT_EMPTY_EMAIL_ADDR);
				throw new ServiceProcessingException(Constant.ERROR_CONTACT_EMPTY_EMAIL_ADDR);
			} else {
				Boolean isEmailValuePresent = Boolean.FALSE;
				for (CommunicationXrefType commXrefType : commXrefTypeList) {
					if (commXrefType.getCOMMTYPE().equalsIgnoreCase("Email")) {
						if (!Util.isNullOrEmpty(commXrefType.getCOMMVALUE())) {
							isEmailValuePresent = Boolean.TRUE;
							break;
						}
					}
				}
				if (!isEmailValuePresent) {
					createUpsertInfoMessage(upsertPartyResponse, Constant.INFO_CONTACT_EMPTY_EMAIL_ADDR);
					throw new ServiceProcessingException(Constant.ERROR_CONTACT_EMPTY_EMAIL_ADDR);
				}
			}
			// } else {
			/* Checking if Country_Cd from Address is NULL OR NOT NULL */
			List<AddressXrefType> addressXrefTypeList = upsertParty.getAddress();
			if (!CollectionUtils.isEmpty(addressXrefTypeList)) {
				/*
				 * createUpsertInfoMessage(upsertPartyResponse,
				 * Constant.ERROR_CONTACT_EMPTY_COUNTRY); throw new
				 * ServiceProcessingException(Constant.
				 * ERROR_CONTACT_EMPTY_COUNTRY); } else {
				 */
				Boolean isCountryFound = Boolean.FALSE;
				for (AddressXrefType addressXrefType : addressXrefTypeList) {
					LOG.debug("Address line1 in validation1:: " + addressXrefType.getADDRLN1());
					if ((!Util.isNullOrEmpty(addressXrefType.getADDRLN1()))) {
						if (!Util.isNullOrEmpty(addressXrefType.getCOUNTRYCD())) {
							LOG.debug("Address line1 in validation2:: " + addressXrefType.getADDRLN1());
							isCountryFound = Boolean.TRUE;
							break;
						}
					} else {
						isCountryFound = Boolean.TRUE;
					}
				}
				if (!isCountryFound) {
					createUpsertInfoMessage(upsertPartyResponse, Constant.INFO_CONTACT_EMPTY_COUNTRY);
					throw new ServiceProcessingException(Constant.ERROR_CONTACT_EMPTY_COUNTRY);
				}
			}

			// Incorrect State and Country combination
			if (!(CollectionUtils.isEmpty(upsertParty.getAddress()) || upsertParty.getAddress().get(0) == null)) {
				if (!Util.isNullOrEmpty(upsertParty.getAddress().get(0).getADDRLN1())) {
					if (!(Util.isNullOrEmpty(upsertParty.getAddress().get(0).getCOUNTRYCD())
							|| Util.isNullOrEmpty(upsertParty.getAddress().get(0).getSTATECD()))) {
						if (!prospectPartyDAO.isCountryStateComboValid(upsertParty.getAddress().get(0).getCOUNTRYCD(),
								upsertParty.getAddress().get(0).getSTATECD(), true)) {
							String respMsg = messagesProp.getProperty(Constant.INFO_COUNTRY_STATE_MISMATCH);
							// upsertPartyResponse = new
							// MdmUpsertPartyResponse();
							upsertPartyResponse.setStatus("Processing completed for 0 Party(ies).\n" + respMsg
									+ Constant.STR_SPACE + upsertParty.getAddress().get(0).getCOUNTRYCD() + "-"
									+ upsertParty.getAddress().get(0).getSTATECD());
							upsertPartyResponse.setErrorMsg(respMsg + Constant.STR_SPACE + upsertParty.getAddress().get(0).getCOUNTRYCD() + "-"
									+ upsertParty.getAddress().get(0).getSTATECD());
							upsertPartyResponse.setErrorCd(Constant.ERROR_CONTACT_COUNTRY_STATE_MISMATCH);
							Util.printObjectTreeInXML(UpsertPartyResponse.class, upsertPartyResponse);
							throw new ServiceProcessingException(Constant.ERROR_CONTACT_COUNTRY_STATE_MISMATCH);
						}
					}
				}
			}

		}
		catch (ServiceProcessingException e) {
			LOG.error("Data validation check failed Due to Invalid Input: " + e.getMessage());
			 if(Constant.ERROR_CONTACT_INVALID_PTY_TYP.equals(e.getMessage())){
				 updateErrorStatus(upsertParty, upsertPartyResponse, Constant.ERROR_CONTACT_INVALID_PTY_TYP,"0");
				}  
			 else if(Constant.ERROR_CONTACT_COUNTRY_STATE_MISMATCH.equals(e.getMessage())){
				 updateErrorStatus(upsertParty, upsertPartyResponse, Constant.ERROR_CONTACT_COUNTRY_STATE_MISMATCH,"0");
				}
			 else  if(Constant.ERROR_CONTACT_COUNTRY_STATE_MISMATCH.equals(e.getMessage())){
				 updateErrorStatus(upsertParty, upsertPartyResponse, Constant.ERROR_CONTACT_COUNTRY_STATE_MISMATCH,"0");
				} 
			 else  if(Constant.ERROR_CONTACT_EMPTY_SRC_CONTACT_ID.equals(e.getMessage())){
				 updateErrorStatus(upsertParty, upsertPartyResponse, Constant.ERROR_CONTACT_EMPTY_SRC_CONTACT_ID,"0");
				}
			 else if(Constant.ERROR_CONTACT_EMPTY_FNAME_LANME.equals(e.getMessage())){
				 updateErrorStatus(upsertParty, upsertPartyResponse, Constant.ERROR_CONTACT_EMPTY_FNAME_LANME,"0");
				} 
			 else if(Constant.ERROR_CONTACT_EMPTY_COUNTRY.equals(e.getMessage())){
				 updateErrorStatus(upsertParty, upsertPartyResponse, Constant.ERROR_CONTACT_EMPTY_COUNTRY,"0");
				}  
			 else if(Constant.ERROR_CONTACT_EMPTY_EMAIL_ADDR.equals(e.getMessage())){
				 updateErrorStatus(upsertParty, upsertPartyResponse, Constant.ERROR_CONTACT_EMPTY_EMAIL_ADDR,"0");
				} 
			  else {
				 updateErrorStatus(upsertParty, upsertPartyResponse, Constant.ERROR_CONTACT_DATA_VALID_FAIL,"0");
			 }
			 throw new ServiceProcessingException(e);
		}catch (Exception excp) {
			LOG.error("Data validation check failed: " + excp.getMessage());

			upsertPartyResponse.setErrorMsg("Data validation check failed Due to Error: " + excp.getMessage());

			updateErrorStatus(upsertParty, upsertPartyResponse, Constant.ERROR_CONTACT_DATA_VALID_FAIL, "0");
			throw new ServiceProcessingException(Constant.ERROR_CONTACT_DATA_VALID_FAIL);
		}

		// Execute next step in upsert flow
		String rowidObj = null;
		if(excuteNextStep)
			upsertTrilliumProcessing(upsertParty,upsertPartyResponse,true,true,rowidObj);

		LOG.info("Executed upsertDataValidation()");
		return;
	}
			
		
			
			public void upsertTrilliumProcessing(PartyXrefType curParty,MdmUpsertPartyResponse upsertPartyResponse,boolean excuteNextStep,boolean executeFromStart,String rowidObject)
			throws ServiceProcessingException{
				LOG.info("Executing upsertTrilliumProcessing()");
				
				PerformanceLoggerUtil perfLog = new PerformanceLoggerUtil();
				String mdmStateCountryArr[] = new String[10];
				boolean setTrilliumValue = false;
				boolean isInTrilliumList = false;
				String cleansFlag = "Y";
				try {			
					// call Trillium Cleanser service to cleanse Name and Address attributes in request.
					// original request attributes will be overwritten by the cleansed values
					
					if (!Util.isNullOrEmpty(curParty.getXREF().get(0).getSRCSYSTEM()) &&
							(!(CollectionUtils.isEmpty(curParty.getAddress()) || curParty.getAddress().get(0) == null))) {
						//get Cleanse flag
					 cleansFlag = getCleanseFlag(curParty.getPARTYTYPE(), curParty.getXREF().get(0).getSRCSYSTEM());
					LOG.info("Executing upsertTrilliumProcessing()  cleansFlag " + cleansFlag);
					//reset cleanse ind if null
					if(Util.isNullOrEmpty(curParty.getPartyPerson().get(0).getCLEANSEIND())){
						curParty.getPartyPerson().get(0).setCLEANSEIND(Constant.STR_Y);
					}
					if  ((curParty.getPartyPerson().get(0).getCLEANSEIND().equalsIgnoreCase(Constant.STR_Y))
							&& (cleansFlag.equalsIgnoreCase(Constant.STR_Y))) {	
					
						/* Trillium Cleansing for Contact */
						trilcontactCleanserDAO.trilliumContactCleanser(curParty);
						
						if (!Util.isNullOrEmpty(curParty.getAddress().get(0).getADDRLN1())) {	
							// Checking if Country_CD within list of 71 Countries.
							isInTrilliumList = trilliumLookUpDAO.checkInTrilliumCountryProjectMap(curParty);
							if (isInTrilliumList) {
								LOG.info("Going For TRILLIUM Procedure");
								// Before Trillium LookUP Process
								mdmStateCountryArr = trilliumLookUpDAO.convertSRCToMDMDataUpsert(curParty,curParty.getXREF().get(0).getSRCSYSTEM());
								// call Trillium Cleanser service to cleanse
								// Name and Address attributes in request
								if (!Util.isNullOrEmpty(mdmStateCountryArr[1])) {
									curParty.getAddress().get(0).setSTATECD(mdmStateCountryArr[0]);
									// parameters.getParty().get(index).getAddress().get(index).setCOUNTRYCD(mdmStateCountryArr[1]);
								}
								LOG.info("Trillium Call is being made.");
								/* Change for US427 START */
								setTrilliumValue = trilliumCleanserDAO.callTrilliumCleanser(curParty, Boolean.TRUE);
								perfLog.printLog(Constant.PERF_LOG_FLOW_UPSERT_SAP_SBL, curParty.getXREF().get(0).getSRCPKEY(), "STEP 1", "Trillium Call done");
								// After Trillium LookUP Process
								trilliumLookUpDAO.convertTrilliumToSRCData(setTrilliumValue, curParty, curParty.getXREF().get(0).getSRCSYSTEM());
								trilliumLookUpDAO.convertTrilliumToSRCCountry(curParty, curParty.getXREF().get(0).getSRCSYSTEM());
								perfLog.printLog(Constant.PERF_LOG_FLOW_UPSERT_SAP_SBL, curParty.getXREF().get(0).getSRCPKEY()
										, "STEP 2", "Transformation after trillium call to source state and country value");
								// }
							} 
					}
						//Changes for MDMP-3366	
						/*else {
								LOG.info("Input Country not within list of 71 Countries, So No TRILLIUM Call.");
								perfLog.printLog(Constant.PERF_LOG_FLOW_UPSERT_SAP_SBL, curParty.getXREF().get(0).getSRCPKEY()
										, "STEP 1-2", "Trillium call Skipped");
							}*/
						} 
					else {
						LOG.info("Reset Country code to country Name for non Trillium");
                        //Reset Country code to country Name 
						if(!Util.isNullOrEmpty(curParty.getAddress().get(0).getCOUNTRYCD())){
						curParty.getAddress().get(0).setCOUNTRYCD(getSFDCCountryCName(curParty.getAddress().get(0).getCOUNTRYCD()));
						}
						LOG.info("BY Passing TRILLIUM Call Since Required cleanse  indicator is N");
						perfLog.printLog(Constant.PERF_LOG_FLOW_UPSERT_SAP_SBL, curParty.getXREF().get(0).getSRCPKEY()
								, "STEP 1-2", "Trillium call Skipped");
						}
					}
					else {
						LOG.info("BY Passing TRILLIUM Call Since No SRC_SYSTEM OR No address");
						perfLog.printLog(Constant.PERF_LOG_FLOW_UPSERT_SAP_SBL, curParty.getXREF().get(0).getSRCPKEY()
								, "STEP 1-2", "Trillium call Skipped");
					}
				}
				catch (ServiceProcessingException e) {
					LOG.error("Trillium Cleanse failed Due to Invalid name identifier: " + e.getMessage());
					 if(Constant.ERROR_ACCOUNT_INVALID_TRL_NM_IND.equals(e.getMessage())){
						 upsertPartyResponse.setErrorMsg("Trillim cleanse failed: "
									+ e.getMessage());
						 upsertPartyResponse.setErrorCd(Constant.ERROR_CONTACT_DQ_CHECK_FAIL);
						 updateErrorStatus(curParty, upsertPartyResponse, Constant.ERROR_ACCOUNT_INVALID_TRL_NM_IND,"0");
						} 
					 else {
						 upsertPartyResponse.setErrorMsg("Trillim cleanse failed: "
									+ e.getMessage());
						 upsertPartyResponse.setErrorCd(Constant.ERROR_CONTACT_DQ_CHECK_FAIL);
						 updateErrorStatus(curParty, upsertPartyResponse, Constant.ERROR_CONTACT_DQ_CHECK_FAIL,"0");
					 }
					 throw new ServiceProcessingException(e);
				}catch (Exception excp) {
					LOG.error("Trillim cleanse failed: " + excp.getMessage());
					//upsertPartyResponse = new MdmUpsertPartyResponse();
					upsertPartyResponse.setErrorMsg("Trillim cleanse failed: "
							+ excp.getMessage());
					 upsertPartyResponse.setErrorCd(Constant.ERROR_CONTACT_DQ_CHECK_FAIL);
					updateErrorStatus(curParty, upsertPartyResponse, Constant.ERROR_CONTACT_DQ_CHECK_FAIL,"0");
					throw new ServiceProcessingException(Constant.ERROR_CONTACT_DQ_CHECK_FAIL);
				}	

				//Execute next step in upsert flow
				String rowidObj = null;
				if(excuteNextStep)
					checkDataQualityUpsert(curParty,upsertPartyResponse,true,true,rowidObj);
				
				LOG.info("Executed upsertTrilliumProcessing()");
				return ;
			}
		
			
				
			public void upsertTokenize(PartyXrefType ptyXrefType,MdmUpsertPartyResponse upsertPartyResponse,boolean retry,boolean executeNextStep, String rowidObjectRequest) throws ServiceProcessingException{
				LOG.info("Executing upsertTokenize()");
				
				PerformanceLoggerUtil perfLog = new PerformanceLoggerUtil();
				SiperianClient siperianClient = null;
				String rowidObject = null;
				String rowidPerson = null;
				int maxCountOfRetry = Integer.parseInt(configProps.getProperty("NoOfRetries"));
				boolean isMaxRetrySuccess = false;
				XREFType xref = null;
				
				try {	
					
					xref = ptyXrefType.getXREF().get(0);					
					siperianClient = (SiperianClient) checkOut();
					rowidObject = getRowidFromPkey(xref,"C_B_PARTY");
					rowidPerson = getRowidFromPkey(xref,"C_B_PARTY_PERSON");
					LOG.info("Calling Party processTokenizeRequest() rowidObject::"+ rowidObject);
					processTokenizeRequest(rowidObject,"C_B_PARTY");
					LOG.info("Calling Person processTokenizeRequest() rowidPerson::"+ rowidPerson);
					processTokenizeRequest(rowidPerson,"C_B_PARTY_PERSON");
					perfLog.printLog(Constant.PERF_LOG_FLOW_UPSERT_SAP_SBL, xref.getSRCPKEY(), 
							"STEP 11", "Tokenization Done");
					
					upsertPartyResponse.setStatus(upsertPartyResponse.getStatus() + "\nTokenization operation successful for Party " + xref.getSRCPKEY());
				} catch (SiperianServerException sifExcp) {
					LOG.error("SiperianServerException occured while processing TokenizeRequest for Party");
					ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
					customException.setMessage("SIF exception occured while processing Tokenize request for Party. " + customException.getMessage());
					try{
						if(rowidObject != null){
					
							for(int i = 0 ; i < maxCountOfRetry;){
								try{
									processTokenizeRequest(rowidObject,"C_B_PARTY");
								}catch(Exception e){
									i++;
								}
								isMaxRetrySuccess= true;
								break;
							}
						}
						
					}catch(Exception exp){
						LOG.error("SiperianServerException occured while retrying TokenizeRequest for Party");
					
						isMaxRetrySuccess = false;
					}
					if(!isMaxRetrySuccess){
						upsertPartyResponse = new MdmUpsertPartyResponse();
						upsertPartyResponse.setErrorMsg("Tokenization failed: "
								+ sifExcp.getMessage());
					
						updateErrorStatus(ptyXrefType,upsertPartyResponse , Constant.ERROR_CONTACT_TOKENIZE_FAIL,rowidObject);
				
					}

					//throw customException;
				} catch (Exception excp) {
					LOG.error("Exception occured while processing TokenizeRequest for Party");
					ServiceProcessingException customException = new ServiceProcessingException(excp);
					customException.setMessage("Exception occured while processing Tokenize request for Party." + customException.getMessage());
					
					upsertPartyResponse.setErrorMsg("Tokenization failed: "
							+ excp.getMessage());
					updateErrorStatus(ptyXrefType,upsertPartyResponse , Constant.ERROR_CONTACT_TOKENIZE_FAIL,rowidObject);
					throw new ServiceProcessingException(Constant.ERROR_CONTACT_TOKENIZE_FAIL);
				}finally {
					checkIn(siperianClient);
				}
				LOG.info("Executed upsertTokenize()");

				if(executeNextStep)
					upsertMatchMergeProcess(ptyXrefType,upsertPartyResponse,true, true,rowidObject);
				
			}
		
			
		
		
		
		
		public void upsertUCNStampProcess(PartyXrefType ptyXrefType,MdmUpsertPartyResponse upsertPartyResponse,boolean excuteNextStep,boolean retry, String rowidObject) throws ServiceProcessingException{
			
			LOG.info("Executing upsertUCNStampProcess()");
			int maxCountOfRetry = Integer.parseInt(configProps.getProperty("NoOfRetries"));
			boolean isMaxRetrySuccess = false;
			PerformanceLoggerUtil perfLog = new PerformanceLoggerUtil();	
			PartyUpsertRespType upsertParty = null;
			String draftAccFlg = null;
			String survivingPartyRowid;
			
			XREFType xref = ptyXrefType.getXREF().get(0);
		
			String existingUCN  = null;
			survivingPartyRowid = getRowidFromPkey(xref,"C_B_PARTY");
			boolean isLegacyUCN = false;
			//PartyType survivingPartyProfileFromBO = null;
			//UCN Assignment Process for End customer
			//if (!Constant.STR_Y.equals(draftAccFlg)) {			
			
				try {
					//survivingPartyProfileFromBO = getPartyDAO.getBOContact(survivingPartyRowid);
					existingUCN  = checkifUCNExists(survivingPartyRowid);
					//Setting UCN value by Calling GET_UCN
					if(Util.isNullOrEmpty(existingUCN)) {
						isLegacyUCN = false;
						//if(!Util.isNullOrEmpty(survivingPartyProfileFromBO.getPARTYTYPE())) {
						LOG.info("UCN for the surviving/new party is Null. Creating UCN for PartyType Person");
							setContactUCNSeq(survivingPartyRowid);
							LOG.debug("UCN value successfully assigned.");
							upsertPartyResponse.setStatus(upsertPartyResponse.getStatus() + " UCN value assigned successfully.");
						//}
					} /*else {
							isLegacyUCN  = true;
							LOG.info("Surviving Record rowID: " + survivingPartyRowid + "  has UCN present: " + existingUCN);
							LOG.debug("Stamping existingUCN as LegacyUCN for all XREFs in same Cluster.");
							//putLegacyUCN(survivingPartyRowid, existingUCN);
					}*/
				} catch (ServiceProcessingException spExcp) {

					LOG.error("Failed to set UCN: ", spExcp);
					warning.append("UCN update process failed, Retry \n");
					try{
						if(survivingPartyRowid != null){
					
							for(int i = 0 ; i < maxCountOfRetry;){
								try{
									if(isLegacyUCN){
										//putLegacyUCN(survivingPartyRowid, existingUCN);
									}
									else{
										setContactUCNSeq(survivingPartyRowid);
									}
								}catch(Exception e){
									i ++;
								}
								isMaxRetrySuccess= true;
								break;
							}
						}
						
					}catch(Exception exp){
						LOG.error("SiperianServerException occured while retrying UCN Stamping for Party");
					
						isMaxRetrySuccess = false;
					}
					if(!isMaxRetrySuccess){
						upsertPartyResponse = new MdmUpsertPartyResponse();
						upsertPartyResponse.setErrorMsg("UCN Stamp Process failed: "
								+ spExcp.getMessage());
						updateErrorStatus(ptyXrefType,upsertPartyResponse , Constant.ERROR_CONTACT_UCN_STAMP_FAIL,rowidObject);
						throw new ServiceProcessingException(Constant.ERROR_CONTACT_UCN_STAMP_FAIL);
					}

					//throw spExcp;
				} catch (Exception Excp) {

					LOG.error("Caught exception while updating UCN: ", Excp);

					warning.append("UCN update process failed, Retry \n");
					try{
						if(rowidObject != null){
					
							for(int i = 0 ; i < maxCountOfRetry; i++){
								try{
									if(isLegacyUCN){
										//putLegacyUCN(survivingPartyRowid, existingUCN);
									}
									else{
										setContactUCNSeq(survivingPartyRowid);
									}
								}catch(Exception e){
									i ++;
								}
								isMaxRetrySuccess= true;
								break;
							}
						}
						
					}catch(Exception exp){
						LOG.error("SiperianServerException occured while retrying TokenizeRequest for Party");
					
						isMaxRetrySuccess = false;
					}
					if(!isMaxRetrySuccess){
						upsertPartyResponse = new MdmUpsertPartyResponse();
						upsertPartyResponse.setErrorMsg("UCN update process failed: "
								+ Excp.getMessage());
						
						updateErrorStatus(ptyXrefType,upsertPartyResponse , Constant.ERROR_CONTACT_UCN_STAMP_FAIL,rowidObject);
						throw new ServiceProcessingException(Constant.ERROR_CONTACT_UCN_STAMP_FAIL);
						
					}
				}
				perfLog.printLog(Constant.PERF_LOG_FLOW_UPSERT_SAP_SBL, ptyXrefType.getXREF().get(0).getSRCPKEY(), 
						"STEP 15", "Stamp UCN / Legacy UCN Done");
			
		/*} else {
			perfLog.printLog(Constant.PERF_LOG_FLOW_UPSERT_SAP_SBL, ptyXrefType.getXREF().get(0).getSRCPKEY(), 
					"STEP 15", "Stamp UCN / Legacy UCN Skipped for draft Account");
		}*/
			LOG.info("Executed upsertUCNStampProcess()");
			if(excuteNextStep)
				processAcntCntctRel(ptyXrefType,upsertPartyResponse, retry,excuteNextStep,survivingPartyRowid);
		}
		
		
		
		public void upsertDataSyncProcess(PartyXrefType ptyXrefType,MdmUpsertPartyResponse upsertPartyResponse,boolean excuteNextStep,boolean retry, String rowidObject){
			
			
			LOG.info("Executing upsertDataSyncProcess()");
			
			PerformanceLoggerUtil perfLog = new PerformanceLoggerUtil();
			PartyType survivingPartyProfileFromBO = null;
			
			//Orchestration update legacy referenced record for SAP,SBL
			XREFType xref = ptyXrefType.getXREF().get(0);
			String sourceKey = xref.getSRCPKEY();
			String srcName = xref.getSRCSYSTEM();
			String survivingPartyRowid = rowidObject;
			
			//if ("Update".equalsIgnoreCase(putRespDataParty.getActionType()) || "Insert".equalsIgnoreCase(putRespDataParty.getActionType())) {

				PartyXrefType legacyRefParty = new PartyXrefType();
				List<String> sendToSrcList = null;
				
				
				
				perfLog.printLog(Constant.PERF_LOG_FLOW_UPSERT_SAP_SBL, sourceKey, 
						"STEP 16", "Check for which source system to send Done");

				// Invoking processUpdateRequest() for Dummy Update process.
				try {
					sendToSrcList = getPartyDAO.getSentToList(sourceKey, srcName,true);
					if(StringUtils.isEmpty(survivingPartyRowid)){
						survivingPartyRowid = getRowidFromPkey(xref,"C_B_PARTY");
					}
					survivingPartyProfileFromBO = getPartyDAO.getBOContact(survivingPartyRowid);
					PartyXrefType insertedPartyData = new PartyXrefType();
					insertedPartyData = getPartyDAO.fetchContactXrefTypeFromORS(ptyXrefType.getXREF().get(0).getSRCSYSTEM(), ptyXrefType.getXREF().get(0).getSRCPKEY());
					LOG.info("Invoking processUpdateRequest() to get LegecyRef Record.");
					legacyRefParty = processUpdateRequest(ptyXrefType, insertedPartyData, sendToSrcList, survivingPartyRowid,
					survivingPartyProfileFromBO);

				} catch (ServiceProcessingException Excp) {
					LOG.error("Caught Service Exception while updating LegayID Ref Record: ", Excp);

					upsertPartyResponse.setErrorMsg("Process failed while Updating LegayID Ref Record \n");
					updateErrorStatus(ptyXrefType, upsertPartyResponse, Constant.ERROR_CONTACT_XREF_UPDATE_FAIL,"0");
				} catch (Exception Excp) {
					LOG.error("Caught Generic Exception while updating LegayID Ref Record: ", Excp);
					upsertPartyResponse.setErrorMsg("Process failed while Updating LegayID Ref Record \n");
					updateErrorStatus(ptyXrefType, upsertPartyResponse, Constant.ERROR_CONTACT_XREF_UPDATE_FAIL,"0");
					
					
				}									
				
				
				perfLog.printLog(Constant.PERF_LOG_FLOW_UPSERT_SAP_SBL, sourceKey, 
						"STEP 17", "Get legacy ref record and orchestration Done");
			LOG.info("Executed upsertDataSyncAccSegAssignProcess()");
			return ;
		}
		
		
	
		
		
		private String getRowidFromPkey(XREFType xref,String BO){
			LOG.info("Execute getRowidFromPkey()");
			String rowidObject = null;
			try{
				GetRequest getReq = new GetRequest();
				getReq.setSiperianObjectUid(SiperianObjectType.BASE_OBJECT.makeUid(BO));
				RecordKey recordKey = new RecordKey();
				recordKey.setSourceKey(xref.getSRCPKEY());
				recordKey.setSystemName(xref.getSRCSYSTEM());
				getReq.setRecordKey(recordKey);
				SiperianClient siperianClient = (SiperianClient)checkOut();
				GetResponse  getResp = (GetResponse)siperianClient.process(getReq);
				 rowidObject = getResp.getRecordKey().getRowid();
				LOG.info("Party rowid_object of newly created record = " + rowidObject);
				
			}catch(Exception exp ){
				LOG.error("Error getting rowidObject for pkey "+xref.getSRCPKEY());
				//return null;
			}
			return rowidObject;
		}
		
		private void childMultiMergeParty(PartyXrefType upsertParty ,MdmUpsertPartyResponse upsertPartyResponse,PutResponseDataHolder putRespDataParty ) throws ServiceProcessingException{
					
			PartyType survivingPartyProfileFromBO = null;
			String survivingPartyRowid = upsertPartyResponse.getParty().get(0).getROWIDOBJECT();
			LOG.info("Party rowid_object of merged/newly created record = " + survivingPartyRowid);
			PerformanceLoggerUtil perfLog = new PerformanceLoggerUtil();
			SiperianClient siperianClient = null;
			String rowidObject = null;
			int maxCountOfRetry = Integer.parseInt(configProps.getProperty("NoOfRetries"));
			boolean isMaxRetrySuccess = false;
			
			int multiMergecountOfRetry = Integer.parseInt(configProps.getProperty("NoOfRetries"));
			boolean isMergeRetrySuccess = false;
			
			//Fetch base object records for new party or surviving party using canonical structure
			//if ("Update".equalsIgnoreCase(putRespDataParty.getActionType()) || "Insert".equalsIgnoreCase(putRespDataParty.getActionType())) {
				survivingPartyProfileFromBO = getPartyDAO.getBOContact(survivingPartyRowid);

				// Merge address, communication and classification child entities
				try {
					mergeProcessMultipleChild(survivingPartyProfileFromBO, upsertPartyResponse);
					LOG.debug("Multi-Merge is successful on Address, Communication and Classification child entities");
				} catch (Exception servExcp) {
				//	mergeInd = false;
					LOG.error("Exception occured while Multi-Merge on Address, Communication and Classification: " , servExcp);
					for(int i = 0; i<multiMergecountOfRetry; i++)	{
					try{
						LOG.debug("Retrying Multi-Merge process for "+ (i+1) +"th time");
						mergeProcessMultipleChild(survivingPartyProfileFromBO, upsertPartyResponse);
						LOG.debug("Multi-Merge is successful on attempt no. "+ (i+1));
						isMergeRetrySuccess = true;
					//	mergeInd = true;
						break;
					} catch (Exception excp) {
						LOG.error("Exception occured in Multi-Merge Retry on attempt no. "+ (i+1));
						LOG.error("Exception occured in Multi-Merge RetryMechanism...");
					}
					}
					if(!isMergeRetrySuccess){
						ServiceProcessingException customException = new ServiceProcessingException(servExcp);
						customException.setMessage("SIF exception occured while processing Multi-Merge on Address, Communication and Classification: " + customException.getMessage());
						updateErrorStatus(upsertParty, upsertPartyResponse, Constant.ERROR_CONTACT_MERGE_FAIL, survivingPartyRowid);
						throw customException;
					}
					
				
				}
			//}
			
			perfLog.printLog(Constant.PERF_LOG_FLOW_UPSERT_SAP_SBL, upsertParty.getXREF().get(0).getSRCPKEY(), 	"STEP 13", "Match and Merge process Done");
			
		}
		
		public void populateUpsertResponse(PartyXrefType upsertParty,MdmUpsertPartyResponse upsertPartyResponse){

			
			 //set Response Structure
			try{
				
				PartyType goldenPartyData = null;
				 XREFCopy xrefCopy = null;
				 Map<String, List<PartyXrefType>> partyXrefMap = null;
				 XREFType xref = upsertParty.getXREF().get(0);
				String survivingPartyRowid = getRowidFromPkey(xref,"C_B_PARTY");
				Set<String> contctRowidSet = new TreeSet<String>() ;
				LOG.info("populateUpsertResponse for RowidObject" + survivingPartyRowid);
				//Update C_REPOS_MQ_DATA_CHANGE table to sent flag 9 for SFDC records for which SFDC record has created
				 if (survivingPartyRowid !=null){
					LOG.info("Update C_REPOS_MQ_DATA_CHANGE table to sent flag 9");
					setMsgSentFlagInTable(survivingPartyRowid);
				} else {
					LOG.error("----------No update on C_REPOS_MQ_DATA_CHANGE ------------");
				}
				 if (survivingPartyRowid !=null){
				 goldenPartyData =  getPartyDAO.getBOContact(survivingPartyRowid);
					contctRowidSet.add(survivingPartyRowid);
					/*Contact Xref Record*/
					partyXrefMap = searchContactDAO.getContactXrefRec(contctRowidSet);
				
				 }
							

				 
				if (goldenPartyData != null){
					if (upsertPartyResponse.getParty().size() > 0) {
						upsertPartyResponse.getParty().clear();
				    }
					PartyUpsertRespType partyUpsertResp = new PartyUpsertRespType();
					PartyPerson personInfo = null;
					List<PartyPerson> personList = new ArrayList<PartyPerson>();
					/*Account accInfo = null;
					List<Account> accountList = new ArrayList<Account>();*/
					Address address = null;
					List<Address> addressList = new ArrayList<Address>();
					Communication communication = null;
					List<Communication> commList = new ArrayList<Communication>();
					PartyRel partyRel = null;
					PartyAccountRelationshipType partyAccountRelationship = null;
					List<PartyAccountRelationshipType> partyAccountRelList = new ArrayList<PartyAccountRelationshipType>();
					int itemIndex = 0;
					boolean sfcActiveExist = false;
					// set all column of Party into response
					if (goldenPartyData != null) {
						// partyUpsertResp = new PartyUpsertRespType();
						partyUpsertResp.setROWIDOBJECT(goldenPartyData.getROWIDOBJECT().trim());
						partyUpsertResp.setSRCSYSTEM(upsertParty.getXREF().get(0).getSRCSYSTEM()); 
						partyUpsertResp.setSRCSYSTEMID(upsertParty.getXREF().get(0).getSRCPKEY());
						partyUpsertResp.setBOCLASSCODE(goldenPartyData.getBOCLASSCODE());
						partyUpsertResp.setPARTYTYPE(goldenPartyData.getPARTYTYPE());
						partyUpsertResp.setPARTYNAME(goldenPartyData.getPARTYNAME());
						partyUpsertResp.setGEO(goldenPartyData.getGEO());
						partyUpsertResp.setREGION(goldenPartyData.getREGION());
						partyUpsertResp.setSTATUSCD(goldenPartyData.getSTATUSCD());
						partyUpsertResp.setVATREGNBR(goldenPartyData.getVATREGNBR());
						partyUpsertResp.setTAXJURSDCTNCD(goldenPartyData.getTAXJURSDCTNCD());
						partyUpsertResp.setSALESBLOCKCD(goldenPartyData.getSALESBLOCKCD());
						partyUpsertResp.setUCN(goldenPartyData.getUCN());
						partyUpsertResp.setMSGTRKNID(upsertParty.getMSGTRKNID());
						partyUpsertResp.setPHYSICALGEO(goldenPartyData.getPHYSICALGEO());
						partyUpsertResp.setPHYSICALREGION(goldenPartyData.getPHYSICALREGION());
						//retrive child from goldenPartyData
						PartyPersonType personParam = null;
						for (itemIndex = 0; itemIndex < goldenPartyData.getPartyPerson().size(); itemIndex++) {
							personParam = goldenPartyData.getPartyPerson().get(itemIndex);
                         if (personParam.getROWIDOBJECT() != null ) {
								
								LOG.debug("============setting Person");
								
								personInfo = new PartyPerson();
								personInfo.setROWIDPERSON(personParam.getROWIDOBJECT().trim());
								personInfo.setPREFIX(personParam.getPREFIX());
								personInfo.setSUFFIX(personParam.getSUFFIX());
								personInfo.setFIRSTNAME(personParam.getFIRSTNAME());
								personInfo.setLASTNAME(personParam.getLASTNAME());
								personInfo.setMIDDLENAME(personParam.getMIDDLENAME());
								personInfo.setJOBTITLE(personParam.getJOBTITLE());
								personInfo.setJOBLEVEL(personParam.getJOBLEVEL());
								personInfo.setJOBFUNCTION(personParam.getJOBFUNCTION());
								personInfo.setPREFLANGUAGE(personParam.getPREFLANGUAGE());
								personInfo.setPERSONSTATUS(personParam.getPERSONSTATUS());
								personInfo.setPERSONTYPE(personParam.getPERSONTYPE());
								personInfo.setLISTSOURCE(personParam.getLISTSOURCE());
								personInfo.setDATASOURCESYSTEM(personParam.getDATASOURCESYSTEM());
								personInfo.setLATTICESCORE(personParam.getLATTICESCORE());
								personInfo.setREPORTEDCOMPANYNAME(personParam.getREPORTEDCOMPANYNAME());
								//personInfo.setSalesForceID(personParam.getSalesForceID());
								personInfo.setSRCACCOUNTID(personParam.getSRCACCOUNTID());
								personInfo.setJOBROLE(personParam.getJOBROLE());
								personInfo.setCLEANSEIND(personParam.getCLEANSEIND());
								personInfo.setPARTNERCONTACTFLG(personParam.getPARTNERCONTACTFLG());
								if (!Util.isNullOrEmpty(survivingPartyRowid)) {
									sfcActiveExist = checkActiveSFCExist(survivingPartyRowid.trim());
								}
								if(sfcActiveExist){
								personInfo.setSalesForceID(personParam.getSalesForceID());
								}
								
								LOG.debug("===Inserting into Person List===");
								personList.add(personInfo);
                         }
						}
						
						
						AddressType addrParam = null;
						for (itemIndex = 0; itemIndex < goldenPartyData.getAddress().size(); itemIndex++) {
							addrParam = goldenPartyData.getAddress().get(itemIndex);
							if (addrParam.getROWIDADDRESS() != null ) {
								
								LOG.debug("============setting Address");
								address = new Address();
							
								address.setROWIDADDRESS(addrParam.getROWIDADDRESS().trim());
								address.setADDRLN1(addrParam.getADDRLN1());
								address.setADDRLN2(addrParam.getADDRLN2());
								address.setADDRLN3(addrParam.getADDRLN3());
								address.setADDRLN4(addrParam.getADDRLN4());
								address.setCITY(addrParam.getCITY());
								address.setCOUNTY(addrParam.getCOUNTY());
								address.setDISTRICT(addrParam.getDISTRICT());
								address.setSTATECD(addrParam.getSTATECD());
								address.setPOSTALCD(addrParam.getPOSTALCD());
								address.setCOUNTRYCD(addrParam.getCOUNTRYCD());
								address.setLANGCD(addrParam.getLANGCD());
								address.setLONGITUDE(addrParam.getLONGITUDE());
								address.setLATITUDE(addrParam.getLATITUDE());
								address.setADDRTYPE(addrParam.getADDRTYPE());
								address.setADDRSTATUS(addrParam.getADDRSTATUS());

								LOG.debug("===Inserting into Address List===");
								addressList.add(address);

							}	
							
							}
						CommunicationType commParam = null;
						for (itemIndex = 0; itemIndex < goldenPartyData.getCommunication().size(); itemIndex++) {
							commParam = goldenPartyData.getCommunication().get(itemIndex);
							if (commParam.getROWIDCOMMUNICATION() != null ) {
								
								LOG.debug("============setting communication");
							
								communication = new Communication();

								communication.setROWIDCOMMUNICATION(commParam.getROWIDCOMMUNICATION().trim());
								communication.setCOMMTYPE(commParam.getCOMMTYPE());
								communication.setCOMMVALUE(commParam.getCOMMVALUE());
								communication.setCOMMSTATUS(commParam.getCOMMSTATUS());
								communication.setPRFRDCOMMIND(commParam.getPRFRDCOMMIND());
								communication.setWEBDOMAIN(commParam.getWEBDOMAIN());
								communication.setCOMMEXTN(commParam.getCOMMEXTN());
								communication.setCOMMMKTGPREF(commParam.getCOMMMKTGPREF());
								communication.setCOMMSALESPREF(commParam.getCOMMSALESPREF());
								LOG.debug("===Inserting into communication List===");
								commList.add(communication);

							}	
							
							}
						partyUpsertResp.getPartyPerson().addAll(personList);
						partyUpsertResp.getAddress().addAll(addressList);
						partyUpsertResp.getCommunication().addAll(commList);
						 //set UPDATE_DATE
						//LOG.debug("Adding update date in  master response " + goldenPartyData.getUPDATEDATE());
						upsertPartyResponse.setUPDATEDATE(goldenPartyData.getUPDATEDATE());
						
						LOG.debug("Get Party Rel for child id  "+goldenPartyData.getROWIDOBJECT().trim());
						//ResultSet resultSet = getPartyRel(goldenPartyData.getROWIDOBJECT(), null);
						Map<String,PartyContactMDMRelationshipType> contactRelMap = getContactRelInfo(upsertParty,upsertPartyResponse,goldenPartyData.getROWIDOBJECT(),upsertParty.getXREF());		
						List<PartyContactMDMRelationshipType> listPartContactRel = new ArrayList<PartyContactMDMRelationshipType>();
						LOG.debug("Get Party Rel size  "+contactRelMap.size());
						partyRel = new PartyRel();
						for(String rowidRel : contactRelMap.keySet()){
							PartyContactMDMRelationshipType relationship = contactRelMap.get(rowidRel);
							listPartContactRel.add(relationship);
							//LOG.debug(relationship.getMDMPARENTID().getID());
						}
						LOG.debug(partyUpsertResp.getPartyRel());
						partyRel.getPARTYPERSONMDMREL().addAll(listPartContactRel);
						partyUpsertResp.setPartyRel(partyRel);
						LOG.debug("Added contact rel ");
						
						if(partyXrefMap.containsKey(survivingPartyRowid))	{
							xrefCopy = new XREFCopy();
						LOG.debug("Adding XREF Copies in master response ");
						 xrefCopy.getPartyXref().addAll(partyXrefMap.get(survivingPartyRowid));
                       //xrefCopyList.add(xrefCopy);
						 upsertPartyResponse.getXREFCopy().add(xrefCopy);
						}
						upsertPartyResponse.getParty().add(partyUpsertResp);					
					}					
				}
				} catch (Exception excp) {
				LOG.error("Exception occured while processing mdmUpsertPartyResponse  for Party " + upsertParty.getXREF().get(0).getSRCPKEY(),excp);
				LOG.info("excep iss "+excp.getMessage()+" "+excp.getLocalizedMessage());
				ServiceProcessingException customException = new ServiceProcessingException(excp);
				customException.setMessage("Exception occured while processing mdmUpsertPartyResponsefor Party " + upsertParty.getXREF().get(0).getSRCPKEY()+" "+customException.getRootExceptionMsg());
				if(upsertPartyResponse.getUpsertStatus().getErrorMsg().contains("Database Connection Failure Issue")){
					upsertPartyResponse.setErrorCd(Constant.DB_CONN_FAILURE);
				}else{
					upsertPartyResponse.setErrorCd(Constant.CUSTOM_PROCESS_ERROR);
				}
				upsertPartyResponse.setErrorMsg(customException.getMessage());
			//	throw customException;
			}
			
			if (warning != null && warning.length() > 0) {
				upsertPartyResponse.setWarningMsg(warning.toString());
			}
		}
		
		private void updateErrorStatus(PartyXrefType partyXrefType, MdmUpsertPartyResponse upsertPartyResponse ,String errorCode, String rowid){
			LOG.debug("Execute updateErrorStatus-->" + errorCode);
            upsertPartyResponse.getUpsertStatus().setErrorCode(errorCode);
            upsertPartyResponse.getUpsertStatus().setErrorMsg(upsertPartyResponse.getStatus());
            upsertPartyResponse.getUpsertStatus().setCURRENTPROCESSSTEP(configProps.getProperty(errorCode+"_RETRY"));  
            PartyUpsertRespType partyResp = new PartyUpsertRespType();
            partyResp.setROWIDOBJECT(rowid);
            partyResp.setMSGTRKNID(partyXrefType.getMSGTRKNID());
            upsertPartyResponse.getParty().add(partyResp);
            
        }
		
		public void UpdateProspectStatus(String partyId,List<String> RowIdXrefList) throws ServiceProcessingException{
			
			   SiperianClient siperianClient = null;
			    UserTransaction transaction = null;
			try {
				siperianClient = (SiperianClient) checkOut();
				transaction = ((EjbSiperianClient) siperianClient).createTX(300000);
				transaction.begin();
				
			//deleteChildDAO.partyUpdateStatus(partyId.trim(),MDMAttributeNames.PARTY_BO,siperianClient);
			List<String> partyXrefList = getRowidsByPartyRowId(RowIdXrefList, MDMAttributeNames.PARTY_BO);
			deleteChildDAO.updateChildProspectStatus(partyXrefList, MDMAttributeNames.PARTY_BO, siperianClient);
			LOG.debug("Party status  updated to C for P2C");
			//Get Prospect Ids
			List<String> prospectList = getRowidsByPartyRowId(RowIdXrefList, MDMAttributeNames.PARTY_PROSPECT_BO);
			deleteChildDAO.updateChildProspectStatus(prospectList, MDMAttributeNames.PARTY_PROSPECT_BO, siperianClient);
			LOG.debug(" Party propect Status updated to C for P2C");
			
			List<String> commList = getRowidsByPartyRowId(RowIdXrefList, MDMAttributeNames.ADDRESS_BO);
			deleteChildDAO.updateChildProspectStatus(commList, MDMAttributeNames.ADDRESS_BO, siperianClient);
			LOG.debug("Party Address status updated to C for P2C");
			List<String> addrist = getRowidsByPartyRowId(RowIdXrefList, MDMAttributeNames.COMM_BO);
			deleteChildDAO.updateChildProspectStatus(addrist, MDMAttributeNames.COMM_BO, siperianClient);
			LOG.debug(" Party Comm Status updated to C for P2C");
			
			transaction.commit();
			} catch (ServiceProcessingException excp) {

				LOG.error("Exception occured while UpdateProspectStatus: ", excp);

				try {
					transaction.rollback();

				} catch (SystemException txExcp) {
					LOG.error("Failed to rollback transaction for UpdateProspectStatus requests : " + txExcp.toString());
				}
				throw excp;
			} catch (Exception ex) {

				LOG.error("Exception occured while UpdateProspectStatus requests: ", ex);

				try {
					transaction.rollback();
				} catch (SystemException txExcp) {
					LOG.error("Failed to rollback transaction for UpdateProspectStatus requests : " + txExcp.toString());
					txExcp.printStackTrace();
				}
				ServiceProcessingException customException = new ServiceProcessingException(ex);
				customException.setMessage("Failed to process UpdateProspectStatus SIF request. " + customException.getMessage());

				throw customException;
			} finally {
				checkIn(siperianClient);
			}
		}
		
		
		
		public String getCleanseFlag(String partyType, String srcName) {
			LOG.debug("Inside getCleanseFlag()");
			PreparedStatement statement = null; 
			Connection jdbcConn = null;
			ResultSet resultSet = null;
			String cleansFlag = null;
			JDBCConnectionProvider jDBCConnectionProvider = null;
			try {
				jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
				jdbcConn = jDBCConnectionProvider.getJdbcConnectionFromDS();
				LOG.info("getCleanseFlag  partyType : " + partyType + " srcName is : "+ srcName);
				StringBuilder sql = new StringBuilder();
				sql.append("select CLEANSE_FLAG from DATA_FLOW_CLEANSE  where PARTY_TYPE = ? and SOURCE_SYSTEM = ?" );
				LOG.debug("SQL Generated is : "+ sql.toString());
				statement = jdbcConn.prepareStatement(sql.toString());
				statement.setString(1, partyType);
				statement.setString(2, srcName);
				resultSet = statement.executeQuery();
				if (resultSet.next()) {
					cleansFlag = resultSet.getString(1);
				}
				LOG.debug("cleansFlag value is: " + cleansFlag);
			}catch(Exception exp){
				exp.printStackTrace();			
			}
			finally{
				try {
					if (resultSet != null)	resultSet.close();
					if (statement != null) statement.close();
					if (jdbcConn != null) jdbcConn.close();
					} catch (SQLException exp) {
						LOG.error("Caught SQLException in getCleanseFlag().");	
					}
				
			}
			return 	cleansFlag;	
		}
		
		
		
		
		public void validateContactRequest(PartyXrefType upsertParty, MdmUpsertPartyResponse upsertResponse) throws ServiceProcessingException {
			LOG.debug("[validateContactRequest] START");
			Boolean isValid = Boolean.TRUE;
			String srcPkey = upsertParty.getXREF().get(0).getSRCPKEY();
			
		/*Checking	IF (FIRSTNAME is NOT NULL OR LASTNAME is NOT NULL)	*/
			try{
				if (upsertParty.getPartyPerson() != null) {
			
				
				String fName = upsertParty.getPartyPerson().get(0).getFIRSTNAME();
				String lName = upsertParty.getPartyPerson().get(0).getLASTNAME();
				if ( Util.isNullOrEmpty(fName) && Util.isNullOrEmpty(lName) ){
					isValid = Boolean.FALSE;
					createUpsertInfoMessage(upsertResponse, Constant.INFO_CONTACT_EMPTY_FNAME_LNAME);
					throw new ServiceProcessingException(Constant.ERROR_CONTACT_EMPTY_FNAME_LANME);
				}
			}/*else {
				isValid = Boolean.FALSE;
				createUpsertInfoMessage(upsertResponse, Constant.INFO_CONTACT_EMPTY_REPTD_COMP_NAME, srcPkey);
				throw new ServiceProcessingException(Constant.ERROR_CONTACT_EMPTY_FNAME_LANME);
			}*/
			
//			if (Util.isNullOrEmpty(upsertParty.getPARTYNAME())) {
			/*Checking if Email_Address from Communication is NULL OR NOT NULL*/
				List<CommunicationXrefType> commXrefTypeList = upsertParty.getCommunication();
				if (CollectionUtils.isEmpty(commXrefTypeList)) {
					isValid = Boolean.FALSE;
					createUpsertInfoMessage(upsertResponse, Constant.INFO_CONTACT_EMPTY_EMAIL_ADDR);
					throw new ServiceProcessingException(Constant.ERROR_CONTACT_EMPTY_EMAIL_ADDR);
				} else {
					Boolean isEmailValuePresent = Boolean.FALSE;
					for (CommunicationXrefType commXrefType : commXrefTypeList) {
						if (commXrefType.getCOMMTYPE().equalsIgnoreCase("Email")) {
								if( !Util.isNullOrEmpty(commXrefType.getCOMMVALUE()) ){
								isEmailValuePresent = Boolean.TRUE;
								break;
							}
						}
					}
					if (!isEmailValuePresent) {
						isValid = Boolean.FALSE;
						createUpsertInfoMessage(upsertResponse, Constant.INFO_CONTACT_EMPTY_EMAIL_ADDR);
						throw new ServiceProcessingException(Constant.ERROR_CONTACT_EMPTY_EMAIL_ADDR);
					}
				}
//			} else {
				/*Checking if Country_Cd from Address is NULL OR NOT NULL*/
				List<AddressXrefType> addressXrefTypeList = upsertParty.getAddress();
				if (CollectionUtils.isEmpty(addressXrefTypeList)) {
					isValid = Boolean.FALSE;
					createUpsertInfoMessage(upsertResponse, Constant.INFO_CONTACT_EMPTY_EMAIL_ADDR);
					throw new ServiceProcessingException(Constant.ERROR_CONTACT_EMPTY_COUNTRY);
				} else {
					Boolean isCountryFound = Boolean.FALSE;
					for (AddressXrefType addressXrefType : addressXrefTypeList) {
						if (!Util.isNullOrEmpty(addressXrefType.getCOUNTRYCD())) {
							isCountryFound = Boolean.TRUE;
							break;
						}
					}
					if (!isCountryFound) {
						isValid = Boolean.FALSE;
						createUpsertInfoMessage(upsertResponse, Constant.INFO_CONTACT_EMPTY_EMAIL_ADDR);
						throw new ServiceProcessingException(Constant.ERROR_CONTACT_EMPTY_COUNTRY);
					}
				}
//			}
		}
		catch (ServiceProcessingException e) {
			LOG.error("Data validation check failed Due to Invalid Input: " + e.getMessage());
			 if(Constant.ERROR_CONTACT_EMPTY_FNAME_LANME.equals(e.getMessage())){
				 updateErrorStatus(upsertParty, upsertResponse, Constant.ERROR_CONTACT_EMPTY_FNAME_LANME,"0");
				} 
			 else if(Constant.ERROR_CONTACT_EMPTY_COUNTRY.equals(e.getMessage())){
				 updateErrorStatus(upsertParty, upsertResponse, Constant.ERROR_CONTACT_EMPTY_COUNTRY,"0");
				}  
			 else if(Constant.ERROR_CONTACT_EMPTY_EMAIL_ADDR.equals(e.getMessage())){
				 updateErrorStatus(upsertParty, upsertResponse, Constant.ERROR_CONTACT_EMPTY_EMAIL_ADDR,"0");
				}  
			 else {
				 updateErrorStatus(upsertParty, upsertResponse, Constant.ERROR_CONTACT_EMPTY_FNAME_LANME,"0");
			 }
			 throw new ServiceProcessingException(e);
		}catch (Exception excp) {
			LOG.error("Data validation check failed: " + excp.getMessage());

			upsertResponse.setErrorMsg("Data validation check failed Due to Error: " + excp.getMessage());

			updateErrorStatus(upsertParty, upsertResponse, Constant.ERROR_CONTACT_EMPTY_FNAME_LANME, "0");
			throw new ServiceProcessingException(Constant.ERROR_CONTACT_EMPTY_FNAME_LANME);
		}
			LOG.debug("[validateContactRequest] EXIT::isValid::" + isValid);
			return ;
		}
		
		
		/**
		 * Processing Account-Contact Relation mapping
		 * <ol>
		 * <li>Retrieve data from temp table MDM_RTS_MRKT_ACC_CONTACT_REL</li>
		 * <li>Create composite list of contact PKEY from incoming data & temp table
		 * data</li>
		 * <li>Check in XRef for those Pkeys</li>
		 * <li>If found then CleasePut in Golden record and delete from temp table
		 * </li>
		 * <li>Else insert data in temp table for any new incoming data</li>
		 * </ol>
		 * 
		 * @param upsertResponse
		 * @param partyContactRelList
		 * @param rowIdParty
		 * @param srcSystem
		 * @param srcPkey
		 * @throws ServiceProcessingException
		 */
		private void processAcntCntctRel(PartyXrefType ptyXrefType,MdmUpsertPartyResponse upsertPartyResponse,boolean excuteNextStep,boolean retry, String rowidObject) throws ServiceProcessingException {
			LOG.debug("[processAcntCntctRel] ENTER");
			XREFType xref = ptyXrefType.getXREF().get(0);
			String rowIdContact = getRowidFromPkey(xref,"C_B_PARTY");
			String srcSystem = ptyXrefType.getXREF().get(0).getSRCSYSTEM();
			String srcPkey = ptyXrefType.getXREF().get(0).getSRCPKEY();
			String accountsrcPkey = ptyXrefType.getPartyPerson().get(0).getSRCACCOUNTID();
			XREFType accountXref = new XREFType ();
			accountXref.setSRCPKEY(accountsrcPkey);
			accountXref.setSRCSYSTEM("SFC");
			String accountRowid = getRowidFromPkey(accountXref,"C_B_PARTY");
			List<String> pkeysToInsertIntoTempTable = new ArrayList<String>();
			boolean accountExist = false;
			boolean accountRelExist = false;
		

			//Check if   Account is  existing  ,insert entry in temp table.
			if (!Util.isNullOrEmpty(accountsrcPkey)) {
				accountExist = checkAccountExist(accountsrcPkey);
				LOG.debug("[processAcntCntctRel]  Account Rel to process" + accountExist);
			}
			if(!accountExist){
			pkeysToInsertIntoTempTable.add(srcPkey);
			prospectPartyDAO.insertPkeysInTempTable(pkeysToInsertIntoTempTable, srcSystem, accountsrcPkey, rowIdContact,true);
			}
			
			else{
				
				/*
				 * Check If Contact_Id exists in PARTY_REL table
				 */
				accountRelExist = prospectPartyDAO.checkifCntctRelationExists(accountRowid,rowIdContact);
				
				if (!accountRelExist) {
					// Create  Person Contact relation
					try{
						LOG.debug("[cleansePutAccountContactRel] ENTER");
						cleansePutAccountContactRel(ptyXrefType,upsertPartyResponse, rowIdContact,
								accountRowid, srcSystem, srcPkey, null);
						LOG.debug("cleansePut AccountContact is successful");
					} catch (Exception excp) {
						LOG.error("Exception occured in cleansePut AccountContact");
					}
				
			}
			}
			LOG.debug("[processAcntCntctRel] EXIT::");
			if(excuteNextStep)
				upsertDataSyncProcess(ptyXrefType,upsertPartyResponse, retry,excuteNextStep,rowIdContact);
		}

		


		/**
		 * The method prepares and executes CleansePutRequest on PARTY_REL landing
		 * table for the given Contact profiles.
		 * 
		 * @param upsertResponse
		 * @param contactRowid
		 * @param rowIdAccount
		 * @param srcSystem
		 * @param srcPkey
		 * @param relLastUpdateDate
		 * @return putResponseActnCntctDataHolder
		 * @throws ServiceProcessingException
		 */
		private PutResponseDataHolder cleansePutAccountContactRel(PartyXrefType ptyXrefType,MdmUpsertPartyResponse upsertResponse, String contactRowid,
				String rowIdAccount, String srcSystem, String srcPkey, String relLastUpdateDate)
				throws ServiceProcessingException {
			LOG.debug("[cleansePutAccountContactRel] ENTER");
			LOG.debug("[cleansePutAccountContactRel] contactRowid::" + contactRowid + ", rowIdAccount::" + rowIdAccount +
					", srcSystem::" + srcSystem + ", srcPkey::" + srcPkey + ", relLastUpdateDate::" + relLastUpdateDate);
			UserTransaction transaction = null;
			SiperianClient siperianClient = null;
			lastUpdateDate = Util.getCurrentTimeZone();
			PutResponseDataHolder responseDataHolder = new PutResponseDataHolder();
			try {
				siperianClient = (SiperianClient) checkOut();
				transaction = ((EjbSiperianClient) siperianClient).createTX(300000);
				transaction.begin();
				CleansePutRequest cleansePutRequest = new CleansePutRequest();
				Record record = new Record();
				record.setSiperianObjectUid(Util.getMappingObjectUid(srcSystem, MDMAttributeNames.ENTITY_RELATION));
				if (Util.isNullOrEmpty(relLastUpdateDate)) {
					LOG.info("Performing cleansePutPartyRel with sysdate from HUB: " + lastUpdateDate);
					record.setField(new Field(MDMAttributeNames.LAST_UPDATE_DATE, lastUpdateDate));
				} else {
					record.setField(new Field(MDMAttributeNames.LAST_UPDATE_DATE, relLastUpdateDate));
				}
				record.setField(new Field(MDMAttributeNames.SRC_SYSTEM, srcSystem));
				record.setField(new Field(MDMAttributeNames.SRC_SYS_KEY, srcPkey));
				record.setField(new Field(MDMAttributeNames.PARENT_ID, rowIdAccount));
				record.setField(new Field(MDMAttributeNames.CHILD_ID, contactRowid));
				record.setField(new Field(MDMAttributeNames.HIERARCHY_CODE, Constant.ROWID_CONTACT_HIERARCHY_TYPE));
				record.setField(new Field(MDMAttributeNames.REL_TYPE_CODE, Constant.ROWID_CONTACT_REL_TYPE));
				cleansePutRequest.setRecord(record);
				CleansePutResponse cleansePutResponse = (CleansePutResponse) siperianClient.process(cleansePutRequest);
				LOG.info("Account Contact Rel Put request processed successfully: " + cleansePutResponse.getMessage());
				RecordKey recordKey = cleansePutResponse.getRecordKey();
				responseDataHolder.setActionType(cleansePutResponse.getActionType());
				responseDataHolder.setActionMessage(cleansePutResponse.getMessage());
				responseDataHolder.setRowidObject(recordKey.getRowid());
				responseDataHolder.setRowidXREF(recordKey.getRowidXref());
				responseDataHolder.setSourceKey(recordKey.getSourceKey());
				responseDataHolder.setSystemName(recordKey.getSystemName());
				LOG.info("ROWID_OBJECT of created Party Account Rel record = " + recordKey.getRowid()
						+ "\nPKEY_SRC  of created Party Account Rel record = " + recordKey.getSourceKey());
				transaction.commit();
			} catch (Exception ex) {
				
				LOG.error("Exception occured while preparing/processing cleansePut requests: ", ex);
				try {
					transaction.rollback();
				} catch (SystemException txExcp) {
					LOG.error("Failed to rollback transaction for cleansePut requests : ", txExcp);
				}
				ServiceProcessingException customException = new ServiceProcessingException(ex);
				customException.setMessage("Failed to process Account Contact Rel cleansePut SIF request." + customException.getMessage());
				upsertResponse.setStatus("Failed to process Account Contact Rel cleansePut SIF request." + customException.getMessage());
				upsertResponse.setErrorMsg("Failed to process Account Contact Rel cleansePut SIF request.");
				upsertResponse.setErrorCd(Constant.ERROR_CONTACT_COUNTRY_STATE_MISMATCH);
				updateErrorStatus(ptyXrefType, upsertResponse, Constant.ERROR_ACTCNTREL_CLEANSE_PUT_FAIL, srcPkey);
				throw customException;
			} finally {
				checkIn(siperianClient);
			}
			LOG.debug("[cleansePutAccountContactRel] EXIT");
			return responseDataHolder;
		}
		
		// Fetch relationship details
		protected ResultSet getPartyRel(String childPartyId, String parentId ) throws SQLException, ServiceProcessingException {
			Connection jdbcConn = null;
			JDBCConnectionProvider jDBCConnectionProvider = null;
			Statement statement = null;
			ResultSet resultSet = null;
			List<String> accountId = new ArrayList<String>();
			StringBuilder sql = new StringBuilder();
			//sql.append("select b.rowid_object as ROWID_OBJECT from c_b_party_xref a,c_b_account_xref b where a.pkey_src_object = b.s_rowid_party and a.hub_state_ind = 1 and b.hub_state_ind = 1 and a.rowid_object =  ");
			sql.append("SELECT PARTY_REL_ROWID, PARENT_PARTY_ROWID FROM PKG_PARTY_REL_FOR_M4M WHERE HUB_STATE_IND = 1 ");
			
			if(null != childPartyId){
				sql.append(" AND ROWID_PARTY_2='"+childPartyId+"'");
			}
			if(null != parentId){
				sql.append(" AND ROWID_PARTY='"+parentId+"'");
			}
			
			
					
			LOG.info("SQL in getPartyRel()->" + sql);
			try {
				jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
				jdbcConn = jDBCConnectionProvider.getJdbcConnectionFromDS();
				statement = jdbcConn.createStatement();
				resultSet = statement.executeQuery(sql.toString());

			} catch (SQLException exp) {
				LOG.error("Caught exception in getPartyRel ", exp);
			//	throw exp;
			} finally {
				// Closing connections
						if (resultSet != null)	resultSet.close();
						if (statement != null)	statement.close();
						if (jdbcConn != null)	jdbcConn.close();
					}
				return resultSet;
			}
		
		
		
		protected Map<String,PartyContactMDMRelationshipType> getContactRelInfo(PartyXrefType upsertParty,MdmUpsertPartyResponse upsertPartyResponse, String partyId, 				
				List<XREFType> listXref) throws SQLException, ServiceProcessingException {
			Connection jdbcConn = null;
			JDBCConnectionProvider jDBCConnectionProvider = null;
			Statement statement = null;
			ResultSet resultSet = null;
			ResultSet resultSetXref = null;
			List<String> accountId = new ArrayList<String>();
			Connection jdbcConnection = null;
			Map<String,PartyContactMDMRelationshipType> contactRelMap = new HashMap<String,PartyContactMDMRelationshipType>();
			PartyPersonMDMRelationshipType partyPersonChild=null;
					
			try {
				LOG.debug("Calling proc to get contactRelation details");
				jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
				jdbcConn = jDBCConnectionProvider.getJdbcConnectionFromDS();
				statement = jdbcConn.createStatement();
				jdbcConnection = jDBCConnectionProvider.getJdbcConnectionFromDS();	
				CallableStatement	callStmt = jdbcConnection.prepareCall("{call CALL_GET_CNTC_REL_DETAILS(?,?,?)}");
				callStmt.setString(1,"Customer" );
				callStmt.setString(2,partyId );
				callStmt.registerOutParameter(3, OracleTypes.CURSOR);
				boolean returnedResult = callStmt.execute();
				LOG.info("Stored proc executed with status: " + returnedResult);
				//if(returnedResult != false){
					resultSetXref = (ResultSet) callStmt.getObject(3);
				//}
				
				LOG.debug("resultSetXref "+resultSetXref);
				
				
				/*String sql = "select * from (select  rel.rowid_object,rowid_party, rowid_party_2,pty.create_date party_dt, rel.create_date rel_dt, rel.last_update_date,pty.pkey_src_object,pty.rowid_system from c_b_party_rel rel inner join "+ 
						"c_b_party_xref pty on pty.rowid_object=rel.rowid_party where pty.party_type in ('Customer','Prospect Customer') and rowid_party_2 = '"+partyId+"' and rel.hub_state_ind=1 and pty.hub_state_ind=1 "+
							"and rowid_system='SFC' order by rel.last_update_date asc,rel.create_date asc, pty.create_date asc ) rn where rownum < 2 union "+
							"select * from (select  rel.rowid_object,rowid_party, rowid_party_2,pty.create_date party_dt, rel.create_date rel_dt,"+
							"rel.last_update_date,pty.pkey_src_object,pty.rowid_system from c_b_party_rel rel inner join c_b_party_xref pty on pty.rowid_object=rel.rowid_party where pty.party_type in  ('Customer','Prospect Customer') "+
							"and rowid_party_2 = '"+partyId+"' and rel.hub_state_ind=1 and pty.hub_state_ind=1 and rowid_system='SBL' order by rel.last_update_date asc,rel.create_date asc, pty.create_date asc ) rn  where rownum < 2 "+
							"union select * from ( select  rel.rowid_object,rowid_party, rowid_party_2,pty.create_date party_dt, rel.create_date rel_dt, rel.last_update_date,pty.pkey_src_object,pty.rowid_system "+
							"from c_b_party_rel rel inner join  c_b_party_xref pty on pty.rowid_object=rel.rowid_party where pty.party_type in  ('Customer','Prospect Customer') "+
								"and rowid_party_2 = '"+partyId+"' and rel.hub_state_ind=1 and pty.hub_state_ind=1 and rowid_system='ELQ' order by rel.last_update_date asc,rel.create_date asc, pty.create_date asc ) rn where rownum < 2 "+
								"union select * from (select rel.rowid_object,rowid_party, rowid_party_2,pty.create_date party_dt, rel.create_date rel_dt, rel.last_update_date,pty.pkey_src_object,pty.rowid_system from c_b_party_rel rel inner join  c_b_party_xref pty on "+
								"pty.rowid_object=rel.rowid_party where pty.party_type in  ('Customer','Prospect Customer') and rowid_party_2 = '"+partyId+"' and rel.hub_state_ind=1 and pty.hub_state_ind=1 and rowid_system='SAP' order by rel.last_update_date asc,rel.create_date asc, pty.create_date asc ) rn where rownum < 2";
			
			
				LOG.debug("query "+sql);
				resultSetXref = statement.executeQuery(sql.toString());*/
				//LOG.debug("Executed query resultSet "+resultSetXref.isClosed());
				 partyPersonChild = new PartyPersonMDMRelationshipType();
				partyPersonChild.setID(partyId.trim());
				partyPersonChild.getXREF().addAll(listXref);
				
				
				if(resultSetXref != null/* && !resultSetXref.isClosed()*/){
					LOG.debug("Processing result set");
					
					while(resultSetXref.next()){
						PartyContactMDMRelationshipType partyCntcRel =  null;
						String rowidRel = resultSetXref.getString(1);
						String rowidParent = resultSetXref.getString(2);
						String pkeyParent = resultSetXref.getString(7);
						String rowidSystemParent = resultSetXref.getString(8);
						String parentUCN = resultSetXref.getString(9); 
						String parentpartyType = resultSetXref.getString(10); 
						LOG.debug("rowidRel "+rowidRel);
						LOG.debug("rowidParent "+rowidParent);
						LOG.debug("pkeyParent "+pkeyParent);
						LOG.debug("rowidSystemParent "+rowidSystemParent);
						if(contactRelMap.get(rowidRel) == null){
							LOG.debug(" Contact rel not found ");
							partyCntcRel = new PartyContactMDMRelationshipType();
							PartyPersonMDMRelationshipType partyPersonNew = new PartyPersonMDMRelationshipType();
							XREFType xrefType = new XREFType();
							xrefType.setSRCPKEY(pkeyParent);
							if(rowidSystemParent != null){
							xrefType.setSRCSYSTEM(rowidSystemParent.trim());
							}
							partyPersonNew.getXREF().add(xrefType);
							partyPersonNew.setID(rowidParent.trim());
							partyPersonNew.setMDMUCN(parentUCN);
							partyPersonNew.setPARTYTYPE(parentpartyType);
							partyCntcRel.setMDMPARENTID(partyPersonNew);
							LOG.debug(" new parent xref added in new contact rel ");
							partyCntcRel.getMDMCHILDID().add(partyPersonChild);
							LOG.debug(" new child xref added in new contact rel ");
							partyCntcRel.setHIERARCHYTYPE("4");
							partyCntcRel.setRELTYPE("25");
							contactRelMap.put(rowidRel, partyCntcRel);
							LOG.debug(" Contact rel put in map for rel id "+partyCntcRel);
							
						}else{
							PartyPersonMDMRelationshipType partyPerson = contactRelMap.get(rowidRel).getMDMPARENTID();
							String parntId = partyPerson.getID();
							if(rowidParent.equalsIgnoreCase(parntId)){
								List<XREFType> xrefList = partyPerson.getXREF();
								List<XREFType> xrefListNew  = new ArrayList<XREFType>();
								for(XREFType xrefParent : xrefList){
									if(pkeyParent.equalsIgnoreCase(xrefParent.getSRCPKEY()) && 
											rowidSystemParent.equalsIgnoreCase(xrefParent.getSRCSYSTEM())){
											continue;
									}else{
										XREFType xrefNew = new XREFType();
										xrefNew.setSRCPKEY(pkeyParent);
										if(rowidSystemParent != null){
										xrefNew.setSRCSYSTEM(rowidSystemParent.trim());
										}
										xrefListNew.add(xrefNew);
									}
								}
								if(xrefListNew.size() > 0){
									partyPerson.getXREF().addAll(xrefListNew);									
									LOG.debug(" new xref list added in existing contact rel ");
								}
							}
							//contactRelMap.get(rowidRel).getMDMCHILDID().add(partyPersonChild);
							LOG.debug(" new child xref added in existing contact rel ");
							
						}							
										
					}
					
				}
			}catch (SQLException sqlExp) {
				LOG.error("Database Issue :: Caught exception while data fetching in getPartyXref ", sqlExp);
				ServiceProcessingException customException = new ServiceProcessingException(sqlExp);
				LOG.info("Root Exception Message "+customException.getRootExceptionMsg()+" "+customException.getLocalizedMessage()+" "+customException.getMessage()+" "+sqlExp.getMessage());
				if(customException.getRootExceptionMsg().contains("Failed to create JDBC connection")){
					customException.setMessage(" Database Connection Failure Issue :: Caught exception while data fetching in getContactRelInfo " + customException.getRootExceptionMsg());
					
					upsertPartyResponse.setStatus(customException.getMessage());
					upsertPartyResponse.setErrorMsg(customException.getMessage());
					upsertPartyResponse.getUpsertStatus().setErrorCode(Constant.DB_CONN_FAILURE);
					updateErrorStatus(upsertParty, upsertPartyResponse, Constant.DB_CONN_FAILURE, "0");
				}
				
				throw customException;
			//	throw exp;
			}catch (Exception exp) {
				LOG.error("Caught exception while data fetching in getPartyXref ", exp);
				ServiceProcessingException customException = new ServiceProcessingException(exp);
				customException.setMessage("Caught exception while data fetching in getPartyXref " + exp.getMessage());
				throw customException;
			//	throw exp;
			}
			finally {
				// Closing connections
						if (resultSet != null)	resultSet.close();
						if (statement != null)	statement.close();
						if (jdbcConn != null)	jdbcConn.close();
			}
				try{
				jdbcConnection = jDBCConnectionProvider.getJdbcConnectionFromDS();	
				CallableStatement	callStmtPartner = jdbcConnection.prepareCall("{call CALL_GET_CNTC_REL_DETAILS(?,?,?)}");
				callStmtPartner.setString(1,"Partner" );
				callStmtPartner.setString(2,partyId );
				callStmtPartner.registerOutParameter(3, OracleTypes.CURSOR);
				boolean returnedResultPertner = callStmtPartner.execute();
				LOG.info("Stored proc executed with Partner: status: " + returnedResultPertner);
				//if(returnedResultPertner != false)
					resultSet = (ResultSet) callStmtPartner.getObject(3);
				
				LOG.debug("Partner resultSet "+resultSet);
				if(resultSet != null /*&& !resultSetXref.isClosed()*/){
					LOG.debug("Processing partner contact result set");					
					while(resultSet.next()){
						PartyContactMDMRelationshipType partyCntcRel =  null;
						String rowidRel = resultSet.getString(1);
						String rowidParent = resultSet.getString(2);
						String pkeyParent = resultSet.getString(7);
						String rowidSystemParent = resultSet.getString(8); 
						String parentUCN =   resultSet.getString(9); 
						String parentpartyType =   resultSet.getString(10); 
						LOG.debug("partner contact rowidRel "+rowidRel);
						LOG.debug("partner rowidParent "+rowidParent);
						LOG.debug("partner pkeyParent "+pkeyParent);
						LOG.debug("partner rowidSystemParent "+rowidSystemParent);
						if(contactRelMap.get(rowidRel) == null){
							LOG.debug("Partner Contact rel not found ");
							partyCntcRel = new PartyContactMDMRelationshipType();
							PartyPersonMDMRelationshipType partyPersonNew = new PartyPersonMDMRelationshipType();
							XREFType xrefType = new XREFType();
							xrefType.setSRCPKEY(pkeyParent);
							if(rowidSystemParent != null){
							xrefType.setSRCSYSTEM(rowidSystemParent.trim());}
							partyPersonNew.getXREF().add(xrefType);
							partyPersonNew.setID(rowidParent.trim());
							partyPersonNew.setMDMUCN(parentUCN);
							partyPersonNew.setPARTYTYPE(parentpartyType);
							partyCntcRel.setMDMPARENTID(partyPersonNew);
							partyCntcRel.getMDMCHILDID().add(partyPersonChild);
							partyCntcRel.setHIERARCHYTYPE("4");
							partyCntcRel.setRELTYPE("25");
							contactRelMap.put(rowidRel, partyCntcRel);
							LOG.debug(" Contact rel put in map for rel id "+partyCntcRel);
							
						}else{
							PartyPersonMDMRelationshipType partyPerson = contactRelMap.get(rowidRel).getMDMPARENTID();
							String parntId = partyPerson.getID();
							if(rowidParent.equalsIgnoreCase(parntId)){
								List<XREFType> xrefList = partyPerson.getXREF();
								List<XREFType> xrefListNew  = new ArrayList<XREFType>();
								for(XREFType xrefParent : xrefList){
									if(pkeyParent.equalsIgnoreCase(xrefParent.getSRCPKEY()) && 
											rowidSystemParent.equalsIgnoreCase(xrefParent.getSRCSYSTEM())){
											continue;
									}else{
										XREFType xrefNew = new XREFType();
										xrefNew.setSRCPKEY(pkeyParent);
										if(rowidSystemParent != null){
										xrefNew.setSRCSYSTEM(rowidSystemParent.trim());}
										xrefListNew.add(xrefNew);
									}
								}
								if(xrefListNew.size() > 0){
									partyPerson.getXREF().addAll(xrefListNew);
									LOG.debug(" new xref list added in existing contact rel ");
								}
							}
							
						}							
										
					}
				}
				
			} catch (SQLException sqlExp) {
				LOG.error("Database Issue :: Caught exception while data fetching in getPartyXref ", sqlExp);
				ServiceProcessingException customException = new ServiceProcessingException(sqlExp);
				LOG.info("Exception Msg-->>"+customException.getLocalizedMessage()+" "+customException.getMessage()+" "+customException.getRootExceptionMsg());
				if(customException.getRootExceptionMsg().contains("Failed to create JDBC connection")){
					customException.setMessage(" Database Connection Failure Issue :: Caught exception while data fetching in getContactRelInfo " + sqlExp.getMessage());
					upsertPartyResponse.setStatus(customException.getMessage());
					upsertPartyResponse.setErrorMsg(customException.getMessage());
					upsertPartyResponse.getUpsertStatus().setErrorCode(Constant.DB_CONN_FAILURE);
					updateErrorStatus(upsertParty, upsertPartyResponse, Constant.DB_CONN_FAILURE, "0");
				}
				throw customException;
			//	throw exp;
			}catch (Exception exp) {
				LOG.error("Caught exception while data fetching in getPartyXref ", exp);
				ServiceProcessingException customException = new ServiceProcessingException(exp);
				customException.setMessage("Caught exception while data fetching in getPartyXref " + exp.getMessage());
				throw customException;
			//	throw exp;
			}
			finally {
				// Closing connections
						if (resultSet != null)	resultSet.close();
						if (statement != null)	statement.close();
						if (jdbcConn != null)	jdbcConn.close();
			}
			return contactRelMap;
		}
	
		public boolean checkActiveSFCExist(String rowidObject) throws ServiceProcessingException {
			LOG.info("Executing checkActiveSFCExist()");
			
			
			Statement statement = null;
			StringBuilder sqlQry = new StringBuilder();
			JDBCConnectionProvider jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();;
			Connection jdbcConnection = null;
			ResultSet resultSet = null;		
			int recordCount = 0;
			boolean sfcExist = false;
			
			try {
				sqlQry.append(Constant.QUERY_GET_ACT_SFC_EXIST);
				sqlQry.append("'"+rowidObject + "'");
				jdbcConnection = jDBCConnectionProvider.getJdbcConnectionFromDS();
				//statement = jdbcConnection.prepareStatement(Constant.COUNT_FROM_PARTY_XREF);
				statement = jdbcConnection.createStatement();
				resultSet = statement.executeQuery(sqlQry.toString());
					LOG.info("Query to fetch presence of SFC Active record: " + sqlQry);

				
					while (resultSet.next()) {
						recordCount = resultSet.getInt(1);
						
					}	
					LOG.info("Record count with SFC  = " + recordCount);
					if (recordCount > 0) {
						sfcExist = true;
					}
				
				
			} catch (SQLException sqlEx) {
				LOG.error("Exception occurred while checking the presence of SFC Record: ", sqlEx);
				//sqlEx.printStackTrace();
				ServiceProcessingException customException = new ServiceProcessingException(sqlEx);
				customException.setMessage("Failed to check the presence of of SFC Record: " + sqlEx.getMessage());
				throw customException;
			} finally {
				try {
						if( resultSet != null)	resultSet.close();
						if( statement != null) statement.close();
						if(jdbcConnection != null) jdbcConnection.close();
					} catch (SQLException e) {
						
						e.printStackTrace();
					}
			}
			
			LOG.info("Executed checkSFCActiveExist()");
			
			return sfcExist;
		}
		public String getSFDCCountryCName(String countrycd) {
			LOG.debug("Inside getSFDCCountryCName()");
			PreparedStatement statement = null; 
			Connection jdbcConn = null;
			ResultSet resultSet = null;
			String countryName = null;
			JDBCConnectionProvider jDBCConnectionProvider = null;
			try {
				jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
				jdbcConn = jDBCConnectionProvider.getJdbcConnectionFromDS();
				LOG.info("getSFDCCountryCName  countrycode : " + countrycd );
				StringBuilder sql = new StringBuilder();
				sql.append("select SFDC_COUNTRY_NM from MDM_COUNTRY  WHERE SFDC_COUNTRY_CD = ?" );
				LOG.debug("SQL Generated is : "+ sql.toString());
				statement = jdbcConn.prepareStatement(sql.toString());
				statement.setString(1, countrycd);
				resultSet = statement.executeQuery();
				if (resultSet.next()) {
					countryName = resultSet.getString(1);
				}
				LOG.debug("countryName value is: " + countryName);
			}catch(Exception exp){
				exp.printStackTrace();			
			}
			finally{
				try {
					if (resultSet != null)	resultSet.close();
					if (statement != null) statement.close();
					if (jdbcConn != null) jdbcConn.close();
					} catch (SQLException exp) {
						LOG.error("Caught SQLException in getSFDCCountryCName().");	
					}
				
			}
			return 	countryName;	
		}
		
		
		
	private void getSipPop(List<AddressXrefType> addressList) {
		LOG.info("Executing getSipPop()");
		int itemIndex = 0;

		AddressXrefType addressParam = null;

		try {
			for (itemIndex = 0; itemIndex < addressList.size(); itemIndex++) {
				addressParam = addressList.get(itemIndex);

				LOG.debug("addressParam.getCOUNTRYCD(): " + addressParam.getCOUNTRYCD());
				if (!Util.isNullOrEmpty(addressParam.getCOUNTRYCD()) && Util.isNullOrEmpty(sipPopVal)) {
				sipPopVal=addressParam.getCOUNTRYCD();
				if ((!Util.isNullOrEmpty(sipPopVal)) && (!(sipPopVal.length() > 2))) {
					sipPopVal = getSFDCCountryCName(sipPopVal);
				}
				}
				LOG.debug("SIP_POP = " + sipPopVal);
			}
		} catch (Exception excp) {
			LOG.error("Exception occured while processing getSipPop for Address: " + excp);
			excp.printStackTrace();

		}

		LOG.info("Executed getSipPop()");
	}
	}