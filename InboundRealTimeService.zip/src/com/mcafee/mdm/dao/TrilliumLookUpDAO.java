package com.mcafee.mdm.dao;

import java.sql.Connection;
//import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
//import java.util.ArrayList;
//import java.util.List;



import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.mcafee.mdm.constants.Constant;
import com.mcafee.mdm.exception.ServiceProcessingException;
import com.mcafee.mdm.generated.PartySearchCriteriaType;
import com.mcafee.mdm.generated.PartyXrefType;
import com.mcafee.mdm.util.JDBCConnectionProvider;
import com.mcafee.mdm.util.Util;
//import com.mcafee.mdm.util.JdbcConn;

@Component
public class TrilliumLookUpDAO {

	private static final Logger LOG = Logger.getLogger(TrilliumLookUpDAO.class);
	@Autowired
	private JdbcTemplate jdbcTemplate;

	
	//Converting SRC specific values to MDM values during SearchRequest
	public String[] convertSRCToMDMDataSearch(Object objectType, String srcSystem) throws SQLException, ServiceProcessingException	{
		
		LOG.debug("Executing convertSRCToMDMDataSearch()");
		Connection jdbcConn = null;
		Statement statement = null;
		JDBCConnectionProvider jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
		ResultSet resultSet = null;
		String countryCd = null;
		String stateCd = null;
		String mdmCountryCd = null;
		String mdmStateCd = null;
		String mdmStateCountryArr [] = new String[10] ;
		StringBuilder sql = new StringBuilder();
		jdbcConn = jDBCConnectionProvider.getJdbcConnectionFromDS();
		
		if( objectType instanceof PartySearchCriteriaType) {
		
			countryCd = ((PartySearchCriteriaType) objectType).getCOUNTRYCD();
			stateCd = ((PartySearchCriteriaType) objectType).getSTATECD();
		}
		
		if (srcSystem.equalsIgnoreCase("SAP"))	{
			
			sql.append("SELECT STATE_CD,COUNTRY_CD FROM MDM_STATE WHERE upper(SAP_STATE_CD) = "); 
			sql.append("upper(q'$" + stateCd + "$')");
			sql.append(" AND COUNTRY_CD IN (SELECT COUNTRY_CD FROM MDM_COUNTRY WHERE upper(SAP_COUNTRY_CD) = ");
			sql.append("upper(q'$" + countryCd + "$')");
			sql.append(")");
		}
		if(srcSystem.equalsIgnoreCase("SBL") || srcSystem.equalsIgnoreCase("SIEBEL"))	{
			
			sql.append("SELECT STATE_CD,COUNTRY_CD FROM MDM_STATE WHERE upper(SIEBEL_STATE_CD) = "); 
			sql.append("upper(q'$" + stateCd + "$')");
			sql.append(" AND COUNTRY_CD IN (SELECT COUNTRY_CD FROM MDM_COUNTRY WHERE upper(SIEBEL_COUNTRY_NM) = ");
			sql.append("upper(q'$" + countryCd + "$')");
			sql.append(")");
		}
		
		/* changes for Sales Force Integration -Start */
        if (srcSystem.equalsIgnoreCase("SFC"))	{
			
			sql.append("SELECT STATE_CD,COUNTRY_CD FROM MDM_STATE WHERE upper(SFDC_STATE_CD) = "); 
			sql.append("upper(q'$" + stateCd + "$')");
			sql.append(" AND COUNTRY_CD IN (SELECT COUNTRY_CD FROM MDM_COUNTRY WHERE upper(SFDC_COUNTRY_CD) = ");
			sql.append("upper(q'$" + countryCd + "$')");
			sql.append(")");
		}
        /* changes for Sales Force Integration -End */
        /* changes for fno Integration -Start */
        if (srcSystem.equalsIgnoreCase("FNO"))	{
			
			sql.append("SELECT STATE_CD,COUNTRY_CD FROM MDM_STATE WHERE upper(FNO_STATE_CD) = "); 
			sql.append("upper(q'$" + stateCd + "$')");
			sql.append(" AND COUNTRY_CD IN (SELECT COUNTRY_CD FROM MDM_COUNTRY WHERE ");
			sql.append("upper(FNO_COUNTRY_CD) = upper(q'$" + countryCd + "$') OR");
			sql.append("upper(FNO_COUNTRY_NM) = upper(q'$" + countryCd + "$')");
			sql.append(")");
		}
        
        /* changes for fno Integration -Start */
        if (srcSystem.equalsIgnoreCase("ADB"))	{
			
			sql.append("SELECT STATE_CD,COUNTRY_CD FROM MDM_STATE WHERE upper(ADB_STATE_CD) = "); 
			sql.append("upper(q'$" + stateCd + "$')");
			sql.append(" AND COUNTRY_CD IN (SELECT COUNTRY_CD FROM MDM_COUNTRY WHERE ");
			sql.append("upper(ADB_COUNTRY_CD) = upper(q'$" + countryCd + "$') OR");
			sql.append("upper(ADB_COUNTRY_NM) = upper(q'$" + countryCd + "$')");
			sql.append(")");
		}
        /* changes for FNO Integration -End */
        
		LOG.debug("SQL for MDM_LOV--> "+sql);
		
		try{
			
			statement = jdbcConn.createStatement();
			resultSet = statement.executeQuery(sql.toString());
			
			while(resultSet.next())	{
				
				mdmStateCd = resultSet.getString(1);
				mdmCountryCd = resultSet.getString(2);
			}
			
	
			mdmStateCountryArr[0] = mdmStateCd;
			mdmStateCountryArr[1] = mdmCountryCd;
			
			LOG.info("Valid MDMStateCode returned is: " + mdmStateCountryArr[0]);
			LOG.info("Valid MDMCountryCode returned is: " + mdmStateCountryArr[1]);
			
		 	} catch(SQLException exp) {
		 		exp.getMessage();
		 		
		 	} finally	{
			//Closing connections
			if (resultSet != null)  resultSet.close();
			if (statement != null) statement.close();
			if (jdbcConn != null) jdbcConn.close();//jDBCConnectionProvider.closeJdbcConnection(jdbcConn);
		}
		
		LOG.debug("Executed convertSRCToMDMDataSearch() successfully!");
		return mdmStateCountryArr;	
	}
	
	//Method For Getting TRILLIUM InputData
	public String[] convertSRCToMDMDataUpsert(Object objectType, String srcSystem) throws SQLException, ServiceProcessingException	{
		
		LOG.debug("Executing convertSRCToMDMDataUpsert()");
		int indx = 0;
		Connection jdbcConn = null;
		Statement statement = null;
		JDBCConnectionProvider jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
		ResultSet resultSet = null;
		String countryCd = null;
		String stateCd = null;
		String mdmCountryCd = null;
		String mdmStateCd = null;
		String mdmStateCountryArr [] = new String[10] ;
		StringBuilder sql = new StringBuilder();
		
		
		
		if( objectType instanceof PartyXrefType)	{
			
			countryCd = ((PartyXrefType) objectType).getAddress().get(indx).getCOUNTRYCD();
			stateCd = ((PartyXrefType) objectType).getAddress().get(indx).getSTATECD();
		}
		
		if (srcSystem.equalsIgnoreCase("SAP"))	{
			
			sql.append("SELECT STATE.STATE_CD,COUNTRY.COUNTRY_CD FROM MDM_STATE STATE, MDM_COUNTRY COUNTRY "); 
			sql.append("WHERE STATE.COUNTRY_CD = COUNTRY.COUNTRY_CD ");
			if(stateCd != null && stateCd.length() > 0)	{
				sql.append(" AND upper(STATE.SAP_STATE_CD) = ");
				sql.append("upper(q'$" + stateCd + "$')");
			}
			sql.append(" AND STATE.COUNTRY_CD IN (SELECT COUNTRY_CD FROM MDM_COUNTRY WHERE upper(SAP_COUNTRY_CD) = ");
			sql.append("upper(q'$" + countryCd + "$')");
			sql.append(")");
		}
		if(srcSystem.equalsIgnoreCase("SBL") || srcSystem.equalsIgnoreCase("SIEBEL"))	{
			
			sql.append("SELECT STATE.STATE_CD,COUNTRY.COUNTRY_CD FROM MDM_STATE STATE, MDM_COUNTRY COUNTRY "); 
			sql.append("WHERE STATE.COUNTRY_CD = COUNTRY.COUNTRY_CD ");
			if(!Util.isNullOrEmpty(stateCd))	{
				sql.append(" AND upper(STATE.SIEBEL_STATE_NM) = ");
				sql.append("upper(q'$" + stateCd + "$')");
			}
			sql.append(" AND STATE.COUNTRY_CD IN (SELECT COUNTRY_CD FROM MDM_COUNTRY WHERE upper(SIEBEL_COUNTRY_NM) = ");
			sql.append("upper(q'$" + countryCd + "$')");
			sql.append(")");
		}
		
		/* changes for Sales Force Integration -Start */

        if (srcSystem.equalsIgnoreCase("SFC"))	{
			
			sql.append("SELECT STATE.STATE_CD,COUNTRY.COUNTRY_CD FROM MDM_STATE STATE, MDM_COUNTRY COUNTRY "); 
			sql.append("WHERE STATE.COUNTRY_CD = COUNTRY.COUNTRY_CD ");
			if(stateCd != null && stateCd.length() > 0)	{
				sql.append(" AND upper(STATE.SFDC_STATE_CD) = ");
				sql.append("upper(q'$" + stateCd + "$')");
			}
			sql.append(" AND STATE.COUNTRY_CD IN (SELECT COUNTRY_CD FROM MDM_COUNTRY WHERE upper(SFDC_COUNTRY_CD) = ");
			sql.append("upper(q'$" + countryCd + "$')");
			sql.append(")");
		}
        /* changes for Sales Force Integration -End */
        
        /* changes for FNO Integration -Start */

        if (srcSystem.equalsIgnoreCase("FNO"))	{
			
			sql.append("SELECT STATE.STATE_CD,COUNTRY.COUNTRY_CD FROM MDM_STATE STATE, MDM_COUNTRY COUNTRY "); 
			sql.append("WHERE STATE.COUNTRY_CD = COUNTRY.COUNTRY_CD ");
			if(stateCd != null && stateCd.length() > 0)	{
				sql.append(" AND ( upper(STATE.FNO_STATE_CD) =  upper(q'$" + stateCd + "$') OR upper(STATE.FNO_STATE_NM) =  upper(q'$" + stateCd + "$') )");
			}
			sql.append(" AND STATE.COUNTRY_CD IN (SELECT COUNTRY_CD FROM MDM_COUNTRY WHERE ");
			sql.append("upper(FNO_COUNTRY_CD) = upper(q'$" + countryCd + "$') OR ");
			sql.append("upper(FNO_COUNTRY_NM) = upper(q'$" + countryCd + "$') )");
		
			
		}
        /* changes for FNO Integration -End */
        
        /* changes for ADB Integration -Start */

        if (srcSystem.equalsIgnoreCase("ADB"))	{
			
			sql.append("SELECT STATE.STATE_CD,COUNTRY.COUNTRY_CD FROM MDM_STATE STATE, MDM_COUNTRY COUNTRY "); 
			sql.append("WHERE STATE.COUNTRY_CD = COUNTRY.COUNTRY_CD ");
			if(stateCd != null && stateCd.length() > 0)	{
				sql.append(" AND ( upper(STATE.ADB_STATE_CD) =  upper(q'$" + stateCd + "$') OR upper(STATE.ADB_STATE_NM) =  upper(q'$" + stateCd + "$') )");
				
			}
			sql.append(" AND STATE.COUNTRY_CD IN (SELECT COUNTRY_CD FROM MDM_COUNTRY WHERE ");
			sql.append("upper(ADB_COUNTRY_CD) = upper(q'$" + countryCd + "$') OR ");
			sql.append("upper(ADB_COUNTRY_NM) = upper(q'$" + countryCd + "$')");
			sql.append(")");
		}
        /* changes for FNO Integration -End */
		LOG.debug("SQL for MDM_LOV--> "+sql);
		
		try{
			jdbcConn = jDBCConnectionProvider.getJdbcConnectionFromDS();
			statement = jdbcConn.createStatement();
			resultSet = statement.executeQuery(sql.toString());
			
			while(resultSet.next())	{
				
				if(!Util.isNullOrEmpty(stateCd))	{
					mdmStateCd = resultSet.getString(1);
				}
				mdmCountryCd = resultSet.getString(2);
			}
							
			mdmStateCountryArr[0] = mdmStateCd;
			mdmStateCountryArr[1] = mdmCountryCd;
			
			LOG.info("Valid MDMStateCode returned is: " + mdmStateCountryArr[0]);
			LOG.info("Valid MDMCountryCode returned is: " + mdmStateCountryArr[1]);
			
		 	} catch(SQLException exp) {
		 		exp.getMessage();
		 		
		 	} finally	{
			//Closing connections
			if (resultSet != null)  resultSet.close();
			if (statement != null) statement.close();
			if (jdbcConn != null) jdbcConn.close();
		}
		
		LOG.debug("Executed convertSRCToMDMDataUpsert() successfully!");
		return mdmStateCountryArr;	
	}
	
	
		//Method For Getting MDM LANDING Data 
		public void convertTrilliumToSRCData(Boolean setTrilliumValue, Object objectType, String srcSystem) throws SQLException, ServiceProcessingException	{
			
			LOG.debug("Executing convertTrilliumToSRCData()");
			int indx = 0;
			Connection jdbcConn = null;
			Statement statement = null;
			JDBCConnectionProvider jDBCConnectionProvider2 = JDBCConnectionProvider.getSingleInstance();
			ResultSet resultSet = null;
			String trillCountryCd = null;
			String trillStateCd = null;
			String sblStateNm = null;
			String sblCountryNm = null;
			String sfdcStateNm = null;
			String sfdcCountryNm = null;
			String sapCountryCd = null;
			String sapStateCd = null;
			String fnoStateNm = null;
			String fnoCountryNm = null;
			String adbStateNm = null;
			String adbCountryNm = null;
			StringBuilder sql = new StringBuilder();
			
		
			jdbcConn = jDBCConnectionProvider2.getJdbcConnectionFromDS();
					
			try{	
					
					trillCountryCd = ((PartyXrefType) objectType).getAddress().get(indx).getCOUNTRYCD();
					trillStateCd = ((PartyXrefType) objectType).getAddress().get(indx).getSTATECD();
					
					if (srcSystem.equalsIgnoreCase("SAP"))	{
						
						if(setTrilliumValue)	{
							
							sql.append("SELECT STATE.SAP_STATE_CD, COUNTRY.SAP_COUNTRY_CD FROM MDM_STATE STATE, MDM_COUNTRY COUNTRY ");
							sql.append("WHERE STATE.COUNTRY_CD = COUNTRY.COUNTRY_CD ");
							if(!Util.isNullOrEmpty(trillStateCd))	{
								sql.append(" AND (TRIM(upper(STATE.TRILLIUM_STATE_CD)) = ");
								sql.append(" TRIM(upper(q'$" + trillStateCd + "$')) ");
								sql.append(" OR TRIM(upper(STATE.TRILLIUM_STATE_NM)) = ");
								sql.append(" TRIM(upper(q'$" + trillStateCd + "$')))"); 
							}
							sql.append(" AND STATE.COUNTRY_CD IN (SELECT SAP_COUNTRY_CD FROM MDM_COUNTRY WHERE TRIM(upper(TRILLIUM_COUNTRY_CD)) = ");
							sql.append(" TRIM(upper('" + trillCountryCd + "'))");
							sql.append(" OR TRIM(upper(COUNTRY_NM)) = TRIM(UPPER('" + trillCountryCd + "'))");
							sql.append(")");
							LOG.debug("SQL for Reverse MDM_LOVs--> "+sql);
							
						} else {
						
							sql.append("SELECT STATE.SAP_STATE_CD, COUNTRY.SAP_COUNTRY_CD FROM MDM_STATE STATE, MDM_COUNTRY COUNTRY ");
							sql.append("WHERE STATE.COUNTRY_CD = COUNTRY.COUNTRY_CD ");
							if(!Util.isNullOrEmpty(trillStateCd))	{
								sql.append(" AND (TRIM(upper(STATE.STATE_CD)) = ");
								sql.append(" TRIM(upper(q'$" + trillStateCd + "$')) ");
								sql.append(" OR TRIM(upper(STATE.STATE_NM)) = ");
								sql.append(" TRIM(upper(q'$" + trillStateCd + "$')))");
							}
							sql.append(" AND STATE.COUNTRY_CD IN (SELECT SAP_COUNTRY_CD FROM MDM_COUNTRY WHERE TRIM(upper(COUNTRY_CD)) = ");
							sql.append(" TRIM(upper('" + trillCountryCd + "'))");
							sql.append(" OR TRIM(upper(COUNTRY_NM)) = TRIM(UPPER('" + trillCountryCd + "'))");
							sql.append(")");
							LOG.debug("SQL for Reverse MDM_LOVs--> "+sql);
							
						}
						
					
						try{
							
							statement = jdbcConn.createStatement();
							resultSet = statement.executeQuery(sql.toString());
							
							
							while(resultSet.next())	{
								if(!Util.isNullOrEmpty(trillStateCd))	{
									sapStateCd = resultSet.getString(1);
								}
								sapCountryCd = resultSet.getString(2);	
							}
							
							
							
							if(sapCountryCd != null && sapCountryCd.length() > 0)	{
							
									((PartyXrefType) objectType).getAddress().get(indx).setCOUNTRYCD(sapCountryCd);
									((PartyXrefType) objectType).getAddress().get(indx).setSTATECD(sapStateCd);
								
							} else LOG.info("Since LookUp values are NULL hence Retaining Original Values.");
							
						 	} catch(SQLException exp) {
							 LOG.info(" Caught SQL Exception in convertTrilliumToSRCData " + exp.getMessage());
						 	}
						}
					
						if(srcSystem.equalsIgnoreCase("SBL") || srcSystem.equalsIgnoreCase("SIEBEL"))	{
						
							if(setTrilliumValue)	{
								
								sql.append("SELECT STATE.SIEBEL_STATE_NM, COUNTRY.SIEBEL_COUNTRY_NM FROM MDM_STATE STATE, MDM_COUNTRY COUNTRY ");
								sql.append("WHERE STATE.COUNTRY_CD = COUNTRY.COUNTRY_CD ");
								if(!Util.isNullOrEmpty(trillStateCd))	{
									sql.append(" AND (TRIM(upper(STATE.TRILLIUM_STATE_CD)) = ");
									sql.append(" TRIM(upper(q'$" + trillStateCd + "$')) ");
									sql.append(" OR TRIM(upper(STATE.TRILLIUM_STATE_NM)) = ");
									sql.append(" TRIM(upper(q'$" + trillStateCd + "$'))) "); 
								}
								sql.append(" AND STATE.COUNTRY_CD IN (SELECT SIEBEL_COUNTRY_CD FROM MDM_COUNTRY WHERE TRIM(upper(TRILLIUM_COUNTRY_CD)) = ");
								sql.append(" TRIM(upper('" + trillCountryCd + "'))");
								sql.append(" OR TRIM(upper(COUNTRY_NM)) = TRIM(UPPER('" + trillCountryCd + "'))");
								sql.append(")");
								LOG.debug("SQL for Reverse MDM_LOVs--> "+sql);
						
							} else {
							
								sql.append("SELECT STATE.SIEBEL_STATE_NM, COUNTRY.SIEBEL_COUNTRY_NM FROM MDM_STATE STATE, MDM_COUNTRY COUNTRY ");
								sql.append("WHERE STATE.COUNTRY_CD = COUNTRY.COUNTRY_CD ");
								if(!Util.isNullOrEmpty(trillStateCd))	{
									sql.append(" AND (TRIM(upper(STATE.STATE_CD)) = ");
									sql.append(" TRIM(upper(q'$" + trillStateCd + "$')) ");
									sql.append(" OR TRIM(upper(STATE.STATE_NM)) = ");
									sql.append(" TRIM(upper(q'$" + trillStateCd + "$')))"); 
								}
								sql.append(" AND STATE.COUNTRY_CD IN (SELECT SIEBEL_COUNTRY_CD FROM MDM_COUNTRY WHERE TRIM(upper(COUNTRY_CD)) = ");
								sql.append(" TRIM(upper('" + trillCountryCd + "'))");
								sql.append(" OR TRIM(upper(COUNTRY_NM)) = TRIM(UPPER('" + trillCountryCd + "'))");
								sql.append(")");
								LOG.debug("SQL for Reverse MDM_LOVs--> "+sql);
								
							}
							
							try{
								
									statement = jdbcConn.createStatement();
									resultSet = statement.executeQuery(sql.toString());
									
									while(resultSet.next())	{
										if(!Util.isNullOrEmpty(trillStateCd))	{
											sblStateNm = resultSet.getString(1);	
										}
										sblCountryNm = resultSet.getString(2);
									}
								
									if(sblCountryNm != null && sblCountryNm.length() > 0)	{
									
										((PartyXrefType) objectType).getAddress().get(indx).setCOUNTRYCD(sblCountryNm);
										((PartyXrefType) objectType).getAddress().get(indx).setSTATECD(sblStateNm);
									
									} else LOG.info("Since LookUp values are NULL hence Retaining Original Values.");
									
									
								
								} catch(SQLException exp) {
									LOG.info(" Caught SQL Exception in convertTrilliumToSRCData " + exp.getMessage());	
								}
							}
						/** changes for Sales Force Integration -Start */
						if(srcSystem.equalsIgnoreCase("SFC"))	{
							
							if(setTrilliumValue)	{
								
								sql.append("SELECT STATE.SFDC_STATE_NM, COUNTRY.SFDC_COUNTRY_NM FROM MDM_STATE STATE, MDM_COUNTRY COUNTRY ");
								sql.append("WHERE STATE.COUNTRY_CD = COUNTRY.COUNTRY_CD ");
								if(!Util.isNullOrEmpty(trillStateCd))	{
									sql.append(" AND (TRIM(upper(STATE.TRILLIUM_STATE_CD)) = ");
									sql.append(" TRIM(upper(q'$" + trillStateCd + "$')) ");
									sql.append(" OR TRIM(upper(STATE.TRILLIUM_STATE_NM)) = ");
									sql.append(" TRIM(upper(q'$" + trillStateCd + "$'))) "); 
								}
								sql.append(" AND STATE.COUNTRY_CD IN (SELECT SFDC_COUNTRY_CD FROM MDM_COUNTRY WHERE TRIM(upper(TRILLIUM_COUNTRY_CD)) = ");
								sql.append(" TRIM(upper('" + trillCountryCd + "'))");
								sql.append(" OR TRIM(upper(COUNTRY_NM)) = TRIM(UPPER('" + trillCountryCd + "'))");
								sql.append(")");
								LOG.debug("SQL for Reverse MDM_LOVs--> "+sql);
						
							} else {
							
								sql.append("SELECT STATE.SFDC_STATE_NM, COUNTRY.SFDC_COUNTRY_NM FROM MDM_STATE STATE, MDM_COUNTRY COUNTRY ");
								sql.append("WHERE STATE.COUNTRY_CD = COUNTRY.COUNTRY_CD ");
								if(!Util.isNullOrEmpty(trillStateCd))	{
									sql.append(" AND (TRIM(upper(STATE.STATE_CD)) = ");
									sql.append(" TRIM(upper(q'$" + trillStateCd + "$')) ");
									sql.append(" OR TRIM(upper(STATE.STATE_NM)) = ");
									sql.append(" TRIM(upper(q'$" + trillStateCd + "$')))"); 
								}
								sql.append(" AND STATE.COUNTRY_CD IN (SELECT SFDC_COUNTRY_CD FROM MDM_COUNTRY WHERE TRIM(upper(COUNTRY_CD)) = ");
								sql.append(" TRIM(upper('" + trillCountryCd + "'))");
								sql.append(" OR TRIM(upper(COUNTRY_NM)) = TRIM(UPPER('" + trillCountryCd + "'))");
								sql.append(")");
								LOG.debug("SQL for Reverse MDM_LOVs--> "+sql);
								
							}
							
							try{
								
									statement = jdbcConn.createStatement();
									resultSet = statement.executeQuery(sql.toString());
									
									while(resultSet.next())	{
										if(!Util.isNullOrEmpty(trillStateCd))	{
											sfdcStateNm = resultSet.getString(1);	
										}
										sfdcCountryNm = resultSet.getString(2);
									}
								
									if(sfdcCountryNm != null && sfdcCountryNm.length() > 0)	{
									
										((PartyXrefType) objectType).getAddress().get(indx).setCOUNTRYCD(sfdcCountryNm);
										((PartyXrefType) objectType).getAddress().get(indx).setSTATECD(sfdcStateNm);
									
									} else LOG.info("Since LookUp values are NULL hence Retaining Original Values.");
									
									
								
								} catch(SQLException exp) {
									LOG.info(" Caught SQL Exception in convertTrilliumToSRCData " + exp.getMessage());	
								}
							}
						/** changes for Sales Force Integration -End */
						
						/** changes for FNO Integration -Start */
						if(srcSystem.equalsIgnoreCase("FNO"))	{
							
							if(setTrilliumValue)	{
								
								sql.append("SELECT STATE.FNO_STATE_NM, COUNTRY.FNO_COUNTRY_NM FROM MDM_STATE STATE, MDM_COUNTRY COUNTRY ");
								sql.append("WHERE STATE.COUNTRY_CD = COUNTRY.COUNTRY_CD ");
								if(!Util.isNullOrEmpty(trillStateCd))	{
									sql.append(" AND (TRIM(upper(STATE.TRILLIUM_STATE_CD)) = ");
									sql.append(" TRIM(upper(q'$" + trillStateCd + "$')) ");
									sql.append(" OR TRIM(upper(STATE.TRILLIUM_STATE_NM)) = ");
									sql.append(" TRIM(upper(q'$" + trillStateCd + "$'))) "); 
								}
								sql.append(" AND STATE.COUNTRY_CD IN (SELECT FNO_COUNTRY_CD FROM MDM_COUNTRY WHERE TRIM(upper(TRILLIUM_COUNTRY_CD)) = ");
								sql.append(" TRIM(upper('" + trillCountryCd + "'))");
								sql.append(" OR TRIM(upper(COUNTRY_NM)) = TRIM(UPPER('" + trillCountryCd + "'))");
								sql.append(")");
								LOG.debug("SQL for Reverse MDM_LOVs--> "+sql);
						
							} else {
							
								sql.append("SELECT STATE.FNO_STATE_NM, COUNTRY.FNO_COUNTRY_NM FROM MDM_STATE STATE, MDM_COUNTRY COUNTRY ");
								sql.append("WHERE STATE.COUNTRY_CD = COUNTRY.COUNTRY_CD ");
								if(!Util.isNullOrEmpty(trillStateCd))	{
									sql.append(" AND (TRIM(upper(STATE.STATE_CD)) = ");
									sql.append(" TRIM(upper(q'$" + trillStateCd + "$')) ");
									sql.append(" OR TRIM(upper(STATE.STATE_NM)) = ");
									sql.append(" TRIM(upper(q'$" + trillStateCd + "$')))"); 
								}
								sql.append(" AND STATE.COUNTRY_CD IN (SELECT FNO_COUNTRY_CD FROM MDM_COUNTRY WHERE TRIM(upper(COUNTRY_CD)) = ");
								sql.append(" TRIM(upper('" + trillCountryCd + "'))");
								sql.append(" OR TRIM(upper(COUNTRY_NM)) = TRIM(UPPER('" + trillCountryCd + "'))");
								sql.append(")");
								LOG.debug("SQL for Reverse MDM_LOVs--> "+sql);
								
							}
							
							try{
								
									statement = jdbcConn.createStatement();
									resultSet = statement.executeQuery(sql.toString());
									
									while(resultSet.next())	{
										if(!Util.isNullOrEmpty(trillStateCd))	{
											fnoStateNm = resultSet.getString(1);	
										}
										fnoCountryNm = resultSet.getString(2);
									}
								
									if(fnoCountryNm != null && fnoCountryNm.length() > 0)	{
									
										((PartyXrefType) objectType).getAddress().get(indx).setCOUNTRYCD(fnoCountryNm);
										((PartyXrefType) objectType).getAddress().get(indx).setSTATECD(fnoStateNm);
									
									} else LOG.info("Since LookUp values are NULL hence Retaining Original Values.");
									
									
								
								} catch(SQLException exp) {
									LOG.info(" Caught SQL Exception in convertTrilliumToSRCData " + exp.getMessage());	
								}
							}
						/** changes for FNO Integration -End */
						
						/** changes for ADB Integration -Start */
						if(srcSystem.equalsIgnoreCase("ADB"))	{
							
							if(setTrilliumValue)	{
								
								sql.append("SELECT STATE.ADB_STATE_NM, COUNTRY.ADB_COUNTRY_NM FROM MDM_STATE STATE, MDM_COUNTRY COUNTRY ");
								sql.append("WHERE STATE.COUNTRY_CD = COUNTRY.COUNTRY_CD ");
								if(!Util.isNullOrEmpty(trillStateCd))	{
									sql.append(" AND (TRIM(upper(STATE.TRILLIUM_STATE_CD)) = ");
									sql.append(" TRIM(upper(q'$" + trillStateCd + "$')) ");
									sql.append(" OR TRIM(upper(STATE.TRILLIUM_STATE_NM)) = ");
									sql.append(" TRIM(upper(q'$" + trillStateCd + "$'))) "); 
								}
								sql.append(" AND STATE.COUNTRY_CD IN (SELECT ADB_COUNTRY_CD FROM MDM_COUNTRY WHERE TRIM(upper(TRILLIUM_COUNTRY_CD)) = ");
								sql.append(" TRIM(upper('" + trillCountryCd + "'))");
								sql.append(" OR TRIM(upper(COUNTRY_NM)) = TRIM(UPPER('" + trillCountryCd + "'))");
								sql.append(")");
								LOG.debug("SQL for Reverse MDM_LOVs--> "+sql);
						
							} else {
							
								sql.append("SELECT STATE.ADB_STATE_NM, COUNTRY.ADB_COUNTRY_NM FROM MDM_STATE STATE, MDM_COUNTRY COUNTRY ");
								sql.append("WHERE STATE.COUNTRY_CD = COUNTRY.COUNTRY_CD ");
								if(!Util.isNullOrEmpty(trillStateCd))	{
									sql.append(" AND (TRIM(upper(STATE.STATE_CD)) = ");
									sql.append(" TRIM(upper(q'$" + trillStateCd + "$')) ");
									sql.append(" OR TRIM(upper(STATE.STATE_NM)) = ");
									sql.append(" TRIM(upper(q'$" + trillStateCd + "$')))"); 
								}
								sql.append(" AND STATE.COUNTRY_CD IN (SELECT ADB_COUNTRY_CD FROM MDM_COUNTRY WHERE TRIM(upper(COUNTRY_CD)) = ");
								sql.append(" TRIM(upper('" + trillCountryCd + "'))");
								sql.append(" OR TRIM(upper(COUNTRY_NM)) = TRIM(UPPER('" + trillCountryCd + "'))");
								sql.append(")");
								LOG.debug("SQL for Reverse MDM_LOVs--> "+sql);
								
							}
							
							try{
								
									statement = jdbcConn.createStatement();
									resultSet = statement.executeQuery(sql.toString());
									
									while(resultSet.next())	{
										if(!Util.isNullOrEmpty(trillStateCd))	{
											adbStateNm = resultSet.getString(1);	
										}
										adbCountryNm = resultSet.getString(2);
									}
								
									if(adbCountryNm != null && adbCountryNm.length() > 0)	{
									
										((PartyXrefType) objectType).getAddress().get(indx).setCOUNTRYCD(adbCountryNm);
										((PartyXrefType) objectType).getAddress().get(indx).setSTATECD(adbStateNm);
									
									} else LOG.info("Since LookUp values are NULL hence Retaining Original Values.");
									
									
								
								} catch(SQLException exp) {
									LOG.info(" Caught SQL Exception in convertTrilliumToSRCData " + exp.getMessage());	
								}
							}
						/** changes for FNO Integration -End */
						
						LOG.info(("Actual SBLStateName before CleansePUT is: " + sblStateNm));
						LOG.info("Actual SBLCountryName before CleansePUT is: " + sblCountryNm);
						LOG.info(("Actual SAPStateCode before CleansePUT is: " + sapStateCd));
						LOG.info(("Actual SAPCountryCode before CleansePUT is: " + sapCountryCd));
						LOG.info(("Actual SFDCStateCode before CleansePUT is: " + sfdcStateNm));
						LOG.info(("Actual SFDCCountryCode before CleansePUT is: " + sfdcCountryNm));
						LOG.info(("Actual FNOStateCode before CleansePUT is: " + fnoStateNm));
						LOG.info(("Actual FNOCountryCode before CleansePUT is: " + fnoCountryNm));
						LOG.info(("Actual ADBStateCode before CleansePUT is: " + adbStateNm));
						LOG.info(("Actual ADBCountryCode before CleansePUT is: " + adbCountryNm));
							
				} finally	{
				//Closing connections
				if (resultSet != null)  resultSet.close();
				if (statement != null) statement.close();
				if (jdbcConn != null) jdbcConn.close();
			}
			
			LOG.debug("Executed convertTrilliumToSRCData()");
				
		}
		
		//Method For Getting MDM LANDING Data 
		public void convertTrilliumToSRCCountry(Object objectType, String srcSystem) throws SQLException, ServiceProcessingException	{
		
			LOG.debug("Inside convertTrilliumToSRCCountry().");	
			Connection jdbcConn = null;
			Statement statement = null;
			JDBCConnectionProvider jDBCConnection = JDBCConnectionProvider.getSingleInstance();
			ResultSet resultSet2 = null;
			String sapCountryCd = null;
			String sblCountryNm = null;
			String sfdcCountryNm = null;
			String trillCountryCd = null;
			String fnoCountryNm = null;
			String adbCountryNm = null;
			String sql2 = null;
			
			try	{
				
			trillCountryCd = ((PartyXrefType) objectType).getAddress().get(0).getCOUNTRYCD();
			
			if (srcSystem.equalsIgnoreCase("SAP"))	{
				sql2 = "SELECT SAP_COUNTRY_CD FROM MDM_COUNTRY WHERE TRIM(upper(COUNTRY_CD)) = TRIM(upper('" + trillCountryCd + 
					"')) OR TRIM(upper(TRILLIUM_COUNTRY_CD)) = TRIM(upper('" + trillCountryCd + "')) OR TRIM(upper(COUNTRY_NM)) = TRIM(UPPER('" + trillCountryCd + "')) ";
				
				LOG.debug("sql2 for fetching CountryCd: " + sql2);
				
				try{
					
						jdbcConn = jDBCConnection.getJdbcConnectionFromDS();
						statement = jdbcConn.createStatement();
						resultSet2 = statement.executeQuery(sql2);
						
						while(resultSet2.next()) {
							sapCountryCd = resultSet2.getString(1);
						}
					
						if(!Util.isNullOrEmpty(sapCountryCd))	{
						
							((PartyXrefType) objectType).getAddress().get(0).setCOUNTRYCD(sapCountryCd);
						
						} 
					
					} catch(SQLException exp) {
						LOG.info(" Caught SQL Exception in convertTrilliumToSRCCountry " + exp.getMessage());	
					}
				
			} else if(srcSystem.equalsIgnoreCase("SBL"))	{
				sql2 = "SELECT SIEBEL_COUNTRY_NM FROM MDM_COUNTRY WHERE TRIM(upper(TRILLIUM_COUNTRY_CD)) = TRIM(upper('" + trillCountryCd + 
						"')) OR TRIM(upper(COUNTRY_CD)) = TRIM(upper('" + trillCountryCd + "'))  OR TRIM(upper(COUNTRY_NM)) = TRIM(UPPER('" + trillCountryCd + "')) ";	
				
				LOG.debug("sql2 for fetching CountryCd: " + sql2);
				
				try{
					
					jdbcConn = jDBCConnection.getJdbcConnectionFromDS();
					statement = jdbcConn.createStatement();
					resultSet2 = statement.executeQuery(sql2);
					
					while(resultSet2.next()) {
						sblCountryNm = resultSet2.getString(1);
					}
				
					if(!Util.isNullOrEmpty(sblCountryNm))	{
					
						((PartyXrefType) objectType).getAddress().get(0).setCOUNTRYCD(sblCountryNm);
					
					}
				
					} catch(SQLException exp) {
						LOG.info(" Caught SQL Exception in convertTrilliumToSRCCountry " + exp.getMessage());	
					}
				
				}
			/** changes for Sales Force Integration -Start */
			else if(srcSystem.equalsIgnoreCase("SFC"))	{
				sql2 = "SELECT SFDC_COUNTRY_NM FROM MDM_COUNTRY WHERE TRIM(upper(TRILLIUM_COUNTRY_CD)) = TRIM(upper('" + trillCountryCd + 
						"')) OR TRIM(upper(COUNTRY_CD)) = TRIM(upper('" + trillCountryCd + "'))  OR TRIM(upper(COUNTRY_NM)) = TRIM(UPPER('" + trillCountryCd + "')) ";	
				
				LOG.debug("sql2 for fetching CountryCd: " + sql2);
				
				try{
					
					jdbcConn = jDBCConnection.getJdbcConnectionFromDS();
					statement = jdbcConn.createStatement();
					resultSet2 = statement.executeQuery(sql2);
					
					while(resultSet2.next()) {
						sfdcCountryNm = resultSet2.getString(1);
					}
				
					if(!Util.isNullOrEmpty(sfdcCountryNm))	{
					
						((PartyXrefType) objectType).getAddress().get(0).setCOUNTRYCD(sfdcCountryNm);
					
					}
				
					} catch(SQLException exp) {
						LOG.info(" Caught SQL Exception in convertTrilliumToSRCCountry " + exp.getMessage());	
					}
				
				}
			/** changes for Sales Force Integration -End */
			
			/** changes for FNO Integration -Start */
			else if(srcSystem.equalsIgnoreCase("FNO"))	{
				sql2 = "SELECT FNO_COUNTRY_NM FROM MDM_COUNTRY WHERE TRIM(upper(TRILLIUM_COUNTRY_CD)) = TRIM(upper('" + trillCountryCd + 
						"')) OR TRIM(upper(COUNTRY_CD)) = TRIM(upper('" + trillCountryCd + "'))  OR TRIM(upper(COUNTRY_NM)) = TRIM(UPPER('" + trillCountryCd + "')) ";	
				
				LOG.debug("sql2 for fetching CountryCd: " + sql2);
				
				try{
					
					jdbcConn = jDBCConnection.getJdbcConnectionFromDS();
					statement = jdbcConn.createStatement();
					resultSet2 = statement.executeQuery(sql2);
					
					while(resultSet2.next()) {
						fnoCountryNm = resultSet2.getString(1);
					}
				
					if(!Util.isNullOrEmpty(fnoCountryNm))	{
					
						((PartyXrefType) objectType).getAddress().get(0).setCOUNTRYCD(fnoCountryNm);
					
					}
				
					} catch(SQLException exp) {
						LOG.info(" Caught SQL Exception in convertTrilliumToSRCCountry " + exp.getMessage());	
					}
				
				}
			/** changes for FNO Integration -End */
			/** changes for ADB Integration -Start */
			else if(srcSystem.equalsIgnoreCase("ADB"))	{
				sql2 = "SELECT ADB_COUNTRY_NM FROM MDM_COUNTRY WHERE TRIM(upper(TRILLIUM_COUNTRY_CD)) = TRIM(upper('" + trillCountryCd + 
						"')) OR TRIM(upper(COUNTRY_CD)) = TRIM(upper('" + trillCountryCd + "'))  OR TRIM(upper(COUNTRY_NM)) = TRIM(UPPER('" + trillCountryCd + "')) ";	
				
				LOG.debug("sql2 for fetching CountryCd: " + sql2);
				
				try{
					
					jdbcConn = jDBCConnection.getJdbcConnectionFromDS();
					statement = jdbcConn.createStatement();
					resultSet2 = statement.executeQuery(sql2);
					
					while(resultSet2.next()) {
						adbCountryNm = resultSet2.getString(1);
					}
				
					if(!Util.isNullOrEmpty(adbCountryNm))	{
					
						((PartyXrefType) objectType).getAddress().get(0).setCOUNTRYCD(adbCountryNm);
					
					}
				
					} catch(SQLException exp) {
						LOG.info(" Caught SQL Exception in convertTrilliumToSRCCountry " + exp.getMessage());	
					}
				
				}
				LOG.info("Actual SBLCountryName before CleansePUT is: " + sblCountryNm);
				LOG.info(("Actual SAPCountryCode before CleansePUT is: " + sapCountryCd));
				LOG.info(("Actual SFDCCountryCode before CleansePUT is: " + sfdcCountryNm));
				LOG.info(("Actual fnoCountryCode before CleansePUT is: " + fnoCountryNm));
				LOG.info(("Actual adbCountryCode before CleansePUT is: " + adbCountryNm));
				
			} finally	{
				//Closing connections
				if (resultSet2 != null)  resultSet2.close();
				if (statement != null) statement.close();
				if (jdbcConn != null) jdbcConn.close();
			}
			
			
			LOG.debug("Executed convertTrilliumToSRCCountry().");	
			
		}
		
		//Method For Converting TrilliumResult To MDM specific values. 
		public void convertTrilliumToMDMData(boolean setTrilliumValue, PartySearchCriteriaType objectType) throws SQLException, ServiceProcessingException	{
			
			LOG.debug("Executing convertTrilliumToMDMData()");
			Connection jdbcConn = null;
			Statement statement = null;
			JDBCConnectionProvider jDBCConnectionProvider2 = JDBCConnectionProvider.getSingleInstance();
			ResultSet resultSet = null;
			String trillCountryCd = null;
			String trillStateCd = null;
			String countryCd = null;
			String stateNM = null;
			StringBuilder sql = new StringBuilder();
		
			jdbcConn = jDBCConnectionProvider2.getJdbcConnectionFromDS();
			
			trillCountryCd = ((PartySearchCriteriaType) objectType).getCOUNTRYCD();
			trillStateCd = ((PartySearchCriteriaType) objectType).getSTATECD();
			
			if(setTrilliumValue)	{
				sql.append("SELECT STATE.STATE_NM, COUNTRY.COUNTRY_CD FROM  MDM_STATE STATE, MDM_COUNTRY COUNTRY "); 
				sql.append("WHERE STATE.COUNTRY_CD = COUNTRY.COUNTRY_CD ");
				sql.append("AND (TRIM(upper(STATE.TRILLIUM_STATE_CD)) = "); 
				sql.append("TRIM(upper(q'$" + trillStateCd + "$'))");
				sql.append(" OR TRIM(upper(STATE.TRILLIUM_STATE_NM)) = ");
				sql.append("TRIM(upper(q'$" + trillStateCd + "$'))");
				sql.append(")");
				sql.append(" AND STATE.COUNTRY_CD IN (SELECT COUNTRY_CD FROM MDM_COUNTRY WHERE TRIM(upper(TRILLIUM_COUNTRY_CD)) = ");
				sql.append("TRIM(upper(q'$" + trillCountryCd + "$'))");
				sql.append(")");
				LOG.debug("SQL for Reverse MDM_LOVs--> "+sql);
			} else {
				sql.append("SELECT STATE.STATE_NM, COUNTRY.COUNTRY_CD FROM  MDM_STATE STATE, MDM_COUNTRY COUNTRY "); 
				sql.append("WHERE STATE.COUNTRY_CD = COUNTRY.COUNTRY_CD ");
				sql.append("AND (TRIM(upper(STATE.STATE_CD)) = "); 
				sql.append("TRIM(upper(q'$" + trillStateCd + "$'))");
				sql.append(" OR TRIM(upper(STATE.STATE_NM)) = ");
				sql.append("TRIM(upper(q'$" + trillStateCd + "$'))");
				sql.append(")");
				sql.append(" AND TRIM(upper(STATE.COUNTRY_CD)) = ");
				sql.append("TRIM(upper(q'$" + trillCountryCd + "$'))");
				
				LOG.debug("SQL for Reverse MDM_LOVs--> "+sql);
			}
					
			try{
				
				statement = jdbcConn.createStatement();
				resultSet = statement.executeQuery(sql.toString());
				
				while(resultSet.next())	{
					
					stateNM = resultSet.getString(1);
					countryCd = resultSet.getString(2);	
				}
				
				LOG.info(("Actual StateNM for Search is: " + stateNM));
				LOG.info(("Actual CountryCD for search is: " + countryCd));
		//		if(stateNM != null && stateNM.length() > 0)	{
						
			//			((PartySearchCriteriaType) objectType).setCOUNTRYCD(countryCd);
						((PartySearchCriteriaType) objectType).setSTATECD(stateNM);
					
		//		} else LOG.info("Since LookUp values are NULL hence Retaining Original Values.");
				
				
			 	} catch(SQLException exp) {
			 		LOG.info(" Caught SQL Exception in convertTrilliumToMDMData " + exp.getMessage());
				} finally	{
				//Closing connections
				if (resultSet != null)  resultSet.close();
				if (statement != null) statement.close();
				if (jdbcConn != null) jdbcConn.close();//jDBCConnectionProvider2.closeJdbcConnection(jdbcConn);
			}
			
			LOG.debug("Executed convertTrilliumToMDMData()");
				
		}
		
		//Converting CustGRP from Source to MDM specific values
		public void convertCustGrpToMdmLov(PartySearchCriteriaType partySearchCriteria, String srcSystem) throws SQLException, ServiceProcessingException	{
			
			LOG.debug("Executing convertCustGrpToMdmLov()");
			Connection jdbcConn = null;
			Statement statement = null;
			JDBCConnectionProvider jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
			ResultSet resultSet = null;
			String sapCd = null;
			String siebelCd = null;
			String sfdcCd = null;
			String custGrpLov = null;
			StringBuilder sql = new StringBuilder();
			jdbcConn = jDBCConnectionProvider.getJdbcConnectionFromDS();		
			
			if (srcSystem.equalsIgnoreCase("SAP"))	{
				
				sapCd = partySearchCriteria.getCUSTGROUP();
				sql.append("SELECT LOV_VALUE FROM MDM_LIST_OF_VALUES WHERE LOV_TYPE = 'CUSTOMER_GROUP' AND upper(SAP_CD) = "); 
				sql.append("upper('" + sapCd + "')");
			}
			if(srcSystem.equalsIgnoreCase("SBL") || srcSystem.equalsIgnoreCase("SIEBEL"))	{
				
				siebelCd = partySearchCriteria.getCUSTGROUP();
				sql.append("SELECT LOV_VALUE FROM MDM_LIST_OF_VALUES WHERE LOV_TYPE = 'CUSTOMER_GROUP' AND upper(SIEBEL_CD) = "); 
				sql.append("upper('" + siebelCd + "')");
			}
			/* changes for Sales Force Integration -Start */
			if(srcSystem.equalsIgnoreCase("SFC"))	{
				
				sfdcCd = partySearchCriteria.getCUSTGROUP();
				sql.append("SELECT LOV_VALUE FROM MDM_LIST_OF_VALUES WHERE LOV_TYPE = 'CUSTOMER_GROUP' AND upper(SFDC_CD) = "); 
				sql.append("upper('" + sfdcCd + "')");
			}
			/* changes for Sales Force Integration -End */
			LOG.debug("Query for CustGroup MDM_LOV--> "+sql);
			
			try{
				
				statement = jdbcConn.createStatement();
				resultSet = statement.executeQuery(sql.toString());
				
				while(resultSet.next())	{
					
					custGrpLov = resultSet.getString(1);
				}
				
				LOG.info("Valid MDM Cust_Group returned is: " + custGrpLov);
				
				if(custGrpLov != null && custGrpLov.length() > 0) {
					partySearchCriteria.setCUSTGROUP(custGrpLov);
				}
				
			 	} catch(SQLException exp) {
			 		LOG.error("Caught SQLexception in convertCustGrpToMdmLov()");
			 		exp.getMessage();
			 		
			 	} finally	{
				//Closing connections
				if (resultSet != null)  resultSet.close();
				if (statement != null) statement.close();
				if (jdbcConn != null) jdbcConn.close();//jDBCConnectionProvider.closeJdbcConnection(jdbcConn);
			}
			
			LOG.debug("Executing convertCustGrpToMdmLov() successfully!");
			
		}
		
		//
		public String[] fetchMDMData(PartySearchCriteriaType partySearchCriteria) throws ServiceProcessingException, SQLException {
			
			LOG.debug("Executing fetchMDMData()");
			Connection jdbcConn = null;
			Statement statement = null;
			JDBCConnectionProvider jDBCConnectionProvider2 = null ;
			ResultSet resultSet = null;
			String stateCd = null;
			String countryCd = null;
			String mdmStateCountryArr [] = new String[10] ;
			String sql = "SELECT STATE_CD,COUNTRY_CD FROM MDM_STATE WHERE upper(STATE_CD) = upper(q'$" 
			+ partySearchCriteria.getSTATECD() + "$') AND upper(COUNTRY_CD) = upper('"
			+ partySearchCriteria.getCOUNTRYCD() + "')";
			LOG.debug("Query for fetchMDMData: "+sql);
			
			try	{
				jDBCConnectionProvider2 = JDBCConnectionProvider.getSingleInstance();
				jdbcConn = jDBCConnectionProvider2.getJdbcConnectionFromDS();
				statement = jdbcConn.createStatement();
				resultSet = statement.executeQuery(sql);
				
				while(resultSet.next())	{
					stateCd = resultSet.getString(1);
					countryCd = resultSet.getString(2);
				}
				
				mdmStateCountryArr[0] = stateCd;
				mdmStateCountryArr[1] = countryCd;
						
			}	catch(SQLException exp) {
		 		exp.getMessage();
		 		
		 	} finally	{
			//Closing connections
			if (resultSet != null)  resultSet.close();
			if (statement != null) statement.close();
			if (jdbcConn != null) jdbcConn.close();//jDBCConnectionProvider2.closeJdbcConnection(jdbcConn);
		}
			LOG.debug("Executed fetchMDMData()");
			return mdmStateCountryArr;
		}
		
	//Check In List of 71 countries table TRILLIUM_COUNTRY_PROJECT_MAP
	public boolean checkInTrilliumCountryProjectMap(Object objectType) throws SQLException, ServiceProcessingException	{
		
		LOG.debug("Executing checkInTrilliumCountryProjectMap()");
		Connection jdbcConn = null;
		Statement statement = null;
		JDBCConnectionProvider jDBCConnectionProv = null ;
		ResultSet resultSet = null;
		String countryCd = null;
		String mdmStateCountryArr [] = new String[10] ;
		boolean isInTrilliumList = false;
		
		if( objectType instanceof PartySearchCriteriaType) {
			countryCd = ((PartySearchCriteriaType) objectType).getCOUNTRYCD();
		} else if (objectType instanceof PartyXrefType) {
			countryCd = ((PartyXrefType) objectType).getAddress().get(0).getCOUNTRYCD();
		}
		
		/** changes for Sales Force Integration  */
		String sql = "SELECT SAP_COUNTRY_CD,SIEBEL_COUNTRY,SFDC_COUNTRY_NM  FROM TRILLIUM_COUNTRY_PROJECT_MAP WHERE TRIM(upper(SAP_COUNTRY_CD)) = TRIM(upper('" 
		+ countryCd + "')) OR TRIM(upper(SIEBEL_COUNTRY)) = TRIM(upper('"+ countryCd + "')) OR TRIM(upper(SFDC_COUNTRY_NM)) = TRIM(upper('"+ countryCd + "'))";
		LOG.debug("Query for checkInTrilliumCountryProjectMap: " + sql);
		
		try	{
			jDBCConnectionProv = JDBCConnectionProvider.getSingleInstance();
			jdbcConn = jDBCConnectionProv.getJdbcConnectionFromDS();
			statement = jdbcConn.createStatement();
			resultSet = statement.executeQuery(sql);
			
			while(resultSet.next())	{
				mdmStateCountryArr[0] = resultSet.getString(1);
				mdmStateCountryArr[1] = resultSet.getString(2);
				mdmStateCountryArr[2] = resultSet.getString(3);
			}
			
			LOG.debug("SAP_COUNTRY_CD: " + mdmStateCountryArr[0]);
			LOG.debug("SIEBEL_COUNTRY: " + mdmStateCountryArr[1]);
			LOG.debug("SFDC_COUNTRY_NM: " + mdmStateCountryArr[2]);
			
			if(!Util.isNullOrEmpty(mdmStateCountryArr[0]) || !Util.isNullOrEmpty(mdmStateCountryArr[1]) || !Util.isNullOrEmpty(mdmStateCountryArr[2]))	{
				isInTrilliumList = true;
			}
			
					
		}	catch(SQLException exp) {
	 		LOG.error("Caught SQLexception in checkInTrilliumCountryProjectMap: " + exp);
	 		
	 	} finally	{
		//Closing connections
		if (resultSet != null)  resultSet.close();
		if (statement != null) statement.close();
		if (jdbcConn != null) jdbcConn.close();
	}
		LOG.debug("Executed checkInTrilliumCountryProjectMap()");
		return isInTrilliumList;
	}
		
	// Method For Getting TRILLIUM InputData
	public void convertToTrilliumUpsert(Object objectType, boolean isInTrilliumList,String srcSystem)
			throws SQLException, ServiceProcessingException {

		if(Util.isNullOrEmpty(srcSystem)){
			srcSystem = "ELQ";
		}
		
		LOG.debug("Executing convertELQToTrilliumUpsert()");
		int indx = 0;
		Connection jdbcConn = null;
		Statement statement = null;
		JDBCConnectionProvider jDBCConnectionProvider = JDBCConnectionProvider
				.getSingleInstance();
		ResultSet resultSet = null;
		String countryCd = null;
		String stateCd = null;
		String mdmCountryCd = null;
		String mdmStateCd = null;
		StringBuilder sql = new StringBuilder();
		Boolean isFound = Boolean.FALSE;

		if (objectType instanceof PartyXrefType) {

			countryCd = ((PartyXrefType) objectType).getAddress().get(indx)
					.getCOUNTRYCD();
			stateCd = ((PartyXrefType) objectType).getAddress().get(indx)
					.getSTATECD();
		}

		if (isInTrilliumList){
			sql.append("SELECT MDM_STATE_CODE, MDM_COUNTRY_CD FROM PROSPECT_COUNTRY_STATE_MAP");
		}else {
			sql.append("SELECT MDM_STATE_NM, MDM_COUNTRY_CD FROM PROSPECT_COUNTRY_STATE_MAP");
		}
		
		sql.append(" WHERE SRC_SYSTEM = '"+srcSystem+"'");
		
		
		if (stateCd != null && stateCd.length() > 0) {
			sql.append(" AND upper(PROSPECT_STATE) = ");
			sql.append("upper(q'$" + stateCd + "$')");
		}
		sql.append(" AND upper(PROSPECT_COUNTRY) = ");
		sql.append("upper(q'$" + countryCd + "$')");

		LOG.debug("SQL for MDM_LOV PROSPECT--> " + sql);

		try {
			jdbcConn = jDBCConnectionProvider.getJdbcConnectionFromDS();
			statement = jdbcConn.createStatement();
			resultSet = statement.executeQuery(sql.toString());

			while (resultSet.next()) {

				if (!Util.isNullOrEmpty(stateCd)) {
					mdmStateCd = resultSet.getString(1);
					((PartyXrefType) objectType).getAddress().get(indx)
							.setSTATECD(mdmStateCd);
				}
				mdmCountryCd = resultSet.getString(2);
				if(!Util.isNullOrEmpty(mdmCountryCd)) {
					isFound = Boolean.TRUE;
				}
			}
			
			LOG.debug("Country, State Found in PROSPECT_COUNTRY_STATE_MAP::" + isFound);
			
			if(!isFound) {
				sql = new StringBuilder();
				sql.append("SELECT DISTINCT MDM_COUNTRY_CD FROM PROSPECT_COUNTRY_STATE_MAP");
				sql.append(" WHERE SRC_SYSTEM = '"+srcSystem+"'");
				sql.append(" AND upper(PROSPECT_COUNTRY) = ");
				sql.append("upper(q'$" + countryCd + "$')");
				LOG.debug("SQL for MDM_LOV PROSPECT Country only::" + sql);
				resultSet = statement.executeQuery(sql.toString());
				
				while (resultSet.next()) {
					mdmCountryCd = resultSet.getString(1);
				}
			}
			
			if(!Util.isNullOrEmpty(mdmCountryCd)) {
				((PartyXrefType) objectType).getAddress().get(indx).setCOUNTRYCD(mdmCountryCd);
			}
			
			LOG.info("Converted MDMStateCode value is: " + mdmStateCd);
			LOG.info("Converted MDMCountryCode value is: " + mdmCountryCd);
			
			/*If Country_Cd is Non-Null && State_Cd is Null*/
			if(!Util.isNullOrEmpty(mdmCountryCd) && Util.isNullOrEmpty(mdmStateCd)) {
				/*Overwrite incoming STATE_CD with Null value*/
				LOG.debug("If Country_Cd is Non-Null but State_Cd is Null then Overwrite incoming STATE_CD with Null value");
				((PartyXrefType) objectType).getAddress().get(indx).setSTATECD(mdmStateCd);
			}

		} catch (SQLException exp) {
			exp.getMessage();

		} finally {
			// Closing connections
			if (resultSet != null)
				resultSet.close();
			if (statement != null)
				statement.close();
			if (jdbcConn != null)
				jdbcConn.close();
		}

		LOG.debug("Executed convertELQToTrilliumUpsert() successfully!");
	}
	
	
	// Check In List of 71 countries table TRILLIUM_COUNTRY_PROJECT_MAP
	public boolean checkInTrilliumCountryProjectMapForProspect(Object objectType,String srcSystem)
			throws SQLException, ServiceProcessingException {

		LOG.debug("Executing checkInTrilliumCountryProjectMapForProspect()");
		Connection jdbcConn = null;
		Statement statement = null;
		JDBCConnectionProvider jDBCConnectionProv = null;
		ResultSet resultSet = null;
		String countryCd = null;
		String mdmStateCountryArr[] = new String[10];
		boolean isInTrilliumList = false;

		if(Util.isNullOrEmpty(srcSystem)){
			srcSystem = "ELQ";
		}
		
		if (objectType instanceof PartySearchCriteriaType) {
			countryCd = ((PartySearchCriteriaType) objectType).getCOUNTRYCD();
		} else if (objectType instanceof PartyXrefType) {
			countryCd = ((PartyXrefType) objectType).getAddress().get(0)
					.getCOUNTRYCD();
		}

		String sql = "SELECT distinct(C.SAP_COUNTRY_CD),C.SIEBEL_COUNTRY "
				+ "FROM PROSPECT_COUNTRY_STATE_MAP A, MDM_COUNTRY B, TRILLIUM_COUNTRY_PROJECT_MAP C "
				+ "WHERE A.SRC_SYSTEM = '"+srcSystem+"' "
				+ "AND TRIM(upper(A.PROSPECT_COUNTRY)) = TRIM(upper('"+ countryCd + "')) "
				+ "AND A.MDM_COUNTRY_CD = B.COUNTRY_CD "
				+ "AND (B.SIEBEL_COUNTRY_NM = C.SIEBEL_COUNTRY "
				+ "		OR B.SAP_COUNTRY_NM = C.SAP_COUNTRY_CD)";

		LOG.debug("Query for checkInTrilliumCountryProjectMapForProspect: " + sql);

		try {
			jDBCConnectionProv = JDBCConnectionProvider.getSingleInstance();
			jdbcConn = jDBCConnectionProv.getJdbcConnectionFromDS();
			statement = jdbcConn.createStatement();
			resultSet = statement.executeQuery(sql);

			while (resultSet.next()) {
				mdmStateCountryArr[0] = resultSet.getString(1);
				mdmStateCountryArr[1] = resultSet.getString(2);
			}

			LOG.debug("SAP_COUNTRY_CD: " + mdmStateCountryArr[0]);
			LOG.debug("SIEBEL_COUNTRY: " + mdmStateCountryArr[1]);

			if (!Util.isNullOrEmpty(mdmStateCountryArr[0])
					|| !Util.isNullOrEmpty(mdmStateCountryArr[1])) {
				isInTrilliumList = true;
			}

		} catch (SQLException exp) {
			LOG.error("Caught SQLexception in checkInTrilliumCountryProjectMapForProspect: "
					+ exp);

		} finally {
			// Closing connections
			if (resultSet != null)
				resultSet.close();
			if (statement != null)
				statement.close();
			if (jdbcConn != null)
				jdbcConn.close();
		}
		LOG.debug("Executed checkInTrilliumCountryProjectMapForProspect()");
		return isInTrilliumList;
	}

	// Method For Getting MDM LANDING Data
	public void convertTrilliumToSRCStateProspect(Boolean setTrilliumValue,
			PartyXrefType partyXref, String srcSystem) throws SQLException,
			ServiceProcessingException {

		LOG.debug("Executing convertTrilliumToSRCStateProspect()");
		Connection jdbcConn = null;
		Statement statement = null;
		JDBCConnectionProvider jDBCConnectionProvider = JDBCConnectionProvider
				.getSingleInstance();
		ResultSet resultSet = null;
		String trillCountryCd = null;
		String trillStateCd = null;
		StringBuilder sql = new StringBuilder();

		jdbcConn = jDBCConnectionProvider.getJdbcConnectionFromDS();

		try {

			trillCountryCd = partyXref.getAddress()
					.get(0).getCOUNTRYCD();
			trillStateCd = partyXref.getAddress().get(0)
					.getSTATECD();

			if ("ELQ".equalsIgnoreCase(srcSystem) || Constant.SRC_SYSTEM_ADB.equalsIgnoreCase(srcSystem)) {
				String countryCd = null;
				String stateCd = null;
				if (setTrilliumValue) {
					sql.append("SELECT STATE.STATE_NM, COUNTRY.COUNTRY_CD FROM MDM_STATE STATE, MDM_COUNTRY COUNTRY ");
					sql.append("WHERE STATE.COUNTRY_CD = COUNTRY.COUNTRY_CD ");
					if (!Util.isNullOrEmpty(trillStateCd)) {
						sql.append(" AND (TRIM(upper(STATE.TRILLIUM_STATE_CD)) = ");
						sql.append(" TRIM(upper(q'$" + trillStateCd + "$')) ");
						sql.append(" OR TRIM(upper(STATE.TRILLIUM_STATE_NM)) = ");
						sql.append(" TRIM(upper(q'$" + trillStateCd + "$')))");
					}
					sql.append(" AND STATE.COUNTRY_CD IN (SELECT COUNTRY_CD FROM MDM_COUNTRY WHERE TRIM(upper(TRILLIUM_COUNTRY_CD)) = ");
					sql.append(" TRIM(upper('" + trillCountryCd + "'))");
					sql.append(" OR TRIM(upper(COUNTRY_NM)) = TRIM(UPPER('"
							+ trillCountryCd + "'))");
					sql.append(")");
					LOG.debug("SQL for Reverse MDM_LOVs--> " + sql);

				} else {

					sql.append("SELECT STATE.STATE_NM, COUNTRY.COUNTRY_CD FROM MDM_STATE STATE, MDM_COUNTRY COUNTRY ");
					sql.append("WHERE STATE.COUNTRY_CD = COUNTRY.COUNTRY_CD ");
					if (!Util.isNullOrEmpty(trillStateCd)) {
						sql.append(" AND (TRIM(upper(STATE.STATE_CD)) = ");
						sql.append(" TRIM(upper(q'$" + trillStateCd + "$')) ");
						sql.append(" OR TRIM(upper(STATE.STATE_NM)) = ");
						sql.append(" TRIM(upper(q'$" + trillStateCd + "$')))");
					}
					sql.append(" AND STATE.COUNTRY_CD IN (SELECT COUNTRY_CD FROM MDM_COUNTRY WHERE TRIM(upper(COUNTRY_CD)) = ");
					sql.append(" TRIM(upper('" + trillCountryCd + "'))");
					sql.append(" OR TRIM(upper(COUNTRY_NM)) = TRIM(UPPER('"
							+ trillCountryCd + "'))");
					sql.append(")");
					LOG.debug("SQL for Reverse MDM_LOVs--> " + sql);
				}

				try {
					statement = jdbcConn.createStatement();
					resultSet = statement.executeQuery(sql.toString());

					while (resultSet.next()) {
						if (!Util.isNullOrEmpty(trillStateCd)) {
							stateCd = resultSet.getString(1);
						}
						countryCd = resultSet.getString(2);
					}

					LOG.debug("State Code for Contact/Prospect :"+stateCd);
					LOG.debug("Country Code for Contact/Prospect :"+countryCd);
					
					if (countryCd != null && countryCd.length() > 0) {

						partyXref.getAddress().get(0)
								.setCOUNTRYCD(countryCd);
						partyXref.getAddress().get(0)
								.setSTATECD(stateCd);

					} else
						LOG.info("Since LookUp values are NULL hence Retaining Original Values.");

				} catch (SQLException exp) {
					LOG.info(" Caught SQL Exception in convertTrilliumToSRCStateProspect "
							+ exp.getMessage());
				}
			}

		} finally {
			// Closing connections
			if (resultSet != null)
				resultSet.close();
			if (statement != null)
				statement.close();
			if (jdbcConn != null)
				jdbcConn.close();
		}

		LOG.debug("Executed convertTrilliumToSRCStateProspect()");

	}

	// Method For Getting MDM LANDING Data
	public void convertTrilliumToSRCCountryProspect(PartyXrefType objectType, String srcSystem)
			throws SQLException, ServiceProcessingException {

		LOG.debug("Inside convertTrilliumToSRCCountryProspect().");
		Connection jdbcConn = null;
		Statement statement = null;
		JDBCConnectionProvider jDBCConnection = JDBCConnectionProvider
				.getSingleInstance();
		ResultSet resultSet2 = null;
		String sapCountryCd = null;
		String trillCountryCd = null;
		String sql2 = null;

		try {

			trillCountryCd = ((PartyXrefType) objectType).getAddress().get(0)
					.getCOUNTRYCD();

			if (srcSystem.equalsIgnoreCase("SAP")) {
				sql2 = "SELECT SAP_COUNTRY_CD FROM MDM_COUNTRY WHERE TRIM(upper(COUNTRY_CD)) = TRIM(upper('"
						+ trillCountryCd
						+ "')) OR TRIM(upper(TRILLIUM_COUNTRY_CD)) = TRIM(upper('"
						+ trillCountryCd
						+ "')) OR TRIM(upper(COUNTRY_NM)) = TRIM(UPPER('"
						+ trillCountryCd + "')) ";

				LOG.debug("sql2 for fetching CountryCd: " + sql2);

				try {

					jdbcConn = jDBCConnection.getJdbcConnectionFromDS();
					statement = jdbcConn.createStatement();
					resultSet2 = statement.executeQuery(sql2);

					while (resultSet2.next()) {
						sapCountryCd = resultSet2.getString(1);
					}

					if (!Util.isNullOrEmpty(sapCountryCd)) {

						((PartyXrefType) objectType).getAddress().get(0)
								.setCOUNTRYCD(sapCountryCd);

					}

				} catch (SQLException exp) {
					LOG.info(" Caught SQL Exception in convertTrilliumToSRCCountryProspect "
							+ exp.getMessage());
				}

			}

		} finally {
			// Closing connections
			if (resultSet2 != null)
				resultSet2.close();
			if (statement != null)
				statement.close();
			if (jdbcConn != null)
				jdbcConn.close();
		}

		LOG.debug("Executed convertTrilliumToSRCCountryProspect().");

	}
}