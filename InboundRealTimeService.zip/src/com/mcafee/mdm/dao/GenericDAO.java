package com.mcafee.mdm.dao;

import java.net.URL;
import java.util.Date;
import java.util.Properties;

import javax.annotation.Resource;
import javax.transaction.UserTransaction;

import org.apache.log4j.Logger;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.mcafee.mdm.constants.Constant;
import com.mcafee.mdm.constants.MDMAttributeNames;
import com.mcafee.mdm.constants.PartyGroupAttributes;
import com.mcafee.mdm.constants.PartyOrgExtAttributes;
import com.mcafee.mdm.exception.ServiceProcessingException;
import com.mcafee.mdm.generated.GenericUpsertResponse;
import com.mcafee.mdm.generated.PartyGroupXrefType;
import com.mcafee.mdm.generated.PartyOrgExtXrefType;
import com.mcafee.mdm.generated.PartyXrefType;
import com.mcafee.mdm.generated.UpsertPartyGroupRequest;
import com.mcafee.mdm.generated.UpsertPartyGroupResponse;
import com.mcafee.mdm.generated.UpsertPartyOrgExtnRequest;
import com.mcafee.mdm.generated.UpsertPartyOrgExtnResponse;
import com.mcafee.mdm.generated.UpsertPartyRequest;
import com.mcafee.mdm.util.ObjectPool;
import com.mcafee.mdm.util.Util;
import com.mcafee.services.embargovalidation._2009._06.IsDenied;
import com.siperian.sif.client.EjbSiperianClient;
import com.siperian.sif.client.SiperianClient;
import com.siperian.sif.client.SiperianServerException;
import com.siperian.sif.message.Field;
import com.siperian.sif.message.Record;
import com.siperian.sif.message.RecordKey;
import com.siperian.sif.message.SiperianObjectType;
import com.siperian.sif.message.mrm.CleansePutRequest;
import com.siperian.sif.message.mrm.CleansePutResponse;
import com.siperian.sif.message.mrm.TokenizeRequest;
import com.siperian.sif.message.mrm.TokenizeResponse;

@Component
@Scope("prototype")
public class GenericDAO extends ObjectPool {

	private static final Logger LOG = Logger.getLogger(GenericDAO.class);

	@Resource(name = "configProp")
	private Properties configProps;
	Date lastUpdateDate = null;

	/** Added for MDMP-2885 :: START */

	/**
	 * This method is to call Restricted Party Service WS
	 * 
	 * @param parameters
	 */
	public void callIsDeniedPartyService(UpsertPartyRequest parameters) {
		LOG.debug("[callIsDeniedPartyService] ENTER");
		for (PartyXrefType curParty : parameters.getParty()) {
			callIsDeniedPartyService(curParty);
		}
		LOG.debug("[callIsDeniedPartyService] EXIT");
	}

	/**
	 * This method is to call Restricted Party Service WS
	 * 
	 * @param curParty
	 */
	public void callIsDeniedPartyService(PartyXrefType curParty) {
		LOG.debug("[callIsDeniedPartyService (PARTY)] ENTER");
		String restrictedPartyWSUrl = configProps.getProperty(Constant.RESTRICTED_PARTY_WS_URL);
		try {
			IsDenied service = new IsDenied(new URL(restrictedPartyWSUrl));
			LOG.debug("[callIsDeniedPartyService] Calling Restricted Party Service -->" + "\nURL::"
					+ restrictedPartyWSUrl + "\nFirst Name::" + Constant.STR_BLANK + "\nLast Name::"
					+ Constant.STR_BLANK + "\nCompany Name::" + curParty.getPARTYNAME() + "\nAddress 1::"
					+ Util.setDefaultValueForNullOrEmptyString(curParty.getAddress().get(0).getADDRLN1(),
							Constant.STR_BLANK)
					+ "\nAddress 2::"
					+ Util.setDefaultValueForNullOrEmptyString(curParty.getAddress().get(0).getADDRLN2(),
							Constant.STR_BLANK)
					+ "\nAddress 3::"
					+ Util.setDefaultValueForNullOrEmptyString(curParty.getAddress().get(0).getADDRLN3(),
							Constant.STR_BLANK)
					+ "\nCity::"
					+ Util.setDefaultValueForNullOrEmptyString(curParty.getAddress().get(0).getCITY(),
							Constant.STR_BLANK)
					+ "\nState::"
					+ Util.setDefaultValueForNullOrEmptyString(curParty.getAddress().get(0).getSTATECD(),
							Constant.STR_BLANK)
					+ "\nCountry::"
					+ Util.setDefaultValueForNullOrEmptyString(curParty.getAddress().get(0).getCOUNTRYCD(),
							Constant.STR_BLANK)
					+ "\nRequested By::" + "MDM");
			Boolean result = service.getIsDeniedSoap().isDeniedParty(Constant.STR_BLANK, Constant.STR_BLANK,
					curParty.getPARTYNAME(),
					Util.setDefaultValueForNullOrEmptyString(curParty.getAddress().get(0).getADDRLN1(),
							Constant.STR_BLANK),
					Util.setDefaultValueForNullOrEmptyString(curParty.getAddress().get(0).getADDRLN2(),
							Constant.STR_BLANK),
					Util.setDefaultValueForNullOrEmptyString(curParty.getAddress().get(0).getADDRLN3(),
							Constant.STR_BLANK),
					Util.setDefaultValueForNullOrEmptyString(curParty.getAddress().get(0).getCITY(),
							Constant.STR_BLANK),
					Util.setDefaultValueForNullOrEmptyString(curParty.getAddress().get(0).getSTATECD(),
							Constant.STR_BLANK),
					Util.setDefaultValueForNullOrEmptyString(curParty.getAddress().get(0).getCOUNTRYCD(),
							Constant.STR_BLANK),
					"MDM");
			LOG.debug("[callIsDeniedPartyService] Response from Restricted Party Service for Party ::"
					+ curParty.getPARTYNAME() + " is::" + result);
			if(curParty.getAccount()!=null && curParty.getAccount().size()>0){
				curParty.getAccount().get(0).setISDENIEDFLG(result ? Constant.STR_Y : Constant.STR_N);
			}
		} catch (Exception excp) {
			LOG.error("Restricted Party Service Call failed: ", excp);
		}

		LOG.debug("[callIsDeniedPartyService (PARTY)] EXIT");
	}

	/** Added for MDMP-2885 :: END */
	public UpsertPartyOrgExtnResponse processUpsertPartyOrgExtn(UpsertPartyOrgExtnRequest upsertPartyOrgExtnRequest) {
		LOG.info("Executing processUpsertPartyOrgExtn()");
		UpsertPartyOrgExtnResponse upsertPartyOrgExtnResponse = new UpsertPartyOrgExtnResponse();
		SiperianClient siperianClient = null;
		UserTransaction transaction = null;
		GenericUpsertResponse upsertResponse = null;
		try {
			siperianClient = (SiperianClient) checkOut();
			transaction = ((EjbSiperianClient) siperianClient).createTX(300000);

			for (int index = 0; index < upsertPartyOrgExtnRequest.getPartyOrgExt().size(); index++) {
				PartyOrgExtXrefType partyOrgExtXrefType = upsertPartyOrgExtnRequest.getPartyOrgExt().get(index);
				if (validateOrgExtnRequestData(partyOrgExtXrefType)) {
					try {
						transaction.begin();
						upsertResponse = cleansePutPartyOrgExtn(partyOrgExtXrefType, siperianClient);
						transaction.commit();
					} catch (Exception e) {
						e.printStackTrace();
					}
					upsertPartyOrgExtnResponse.getUpsertResponse().add(upsertResponse);
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			checkIn(siperianClient);
		}

		LOG.info("Executed processUpsertPartyOrgExtn()");
		return upsertPartyOrgExtnResponse;
	}

	private boolean validateOrgExtnRequestData(PartyOrgExtXrefType partyOrgExtXrefType) {
		boolean validData = true;
		if (partyOrgExtXrefType.getPARTYSRCSYSKEY() == null || partyOrgExtXrefType.getPARTYSRCSYSKEY().equals("")) {
			validData = false;
		} else if (partyOrgExtXrefType.getSRCPKEY() == null || partyOrgExtXrefType.getSRCPKEY().equals("")) {
			validData = false;
		} else if (partyOrgExtXrefType.getSRCSYSTEM() == null || partyOrgExtXrefType.getSRCSYSTEM().equals("")) {
			validData = false;
		}
		return validData;
	}

	private GenericUpsertResponse cleansePutPartyOrgExtn(PartyOrgExtXrefType partyOrgExtParam,
			SiperianClient siperianClient) {

		LOG.info("Executing cleansePutPartyOrgExtn()");
		CleansePutRequest cleansePutRequest = new CleansePutRequest();
		CleansePutResponse cleansePutResponse = null;
		GenericUpsertResponse genericUpsertResponse = new GenericUpsertResponse();
		try {
			// prepare CleansePutRequest
			Record record = new Record();
			// set mapping name
			record.setSiperianObjectUid(
					Util.getMappingObjectUid(partyOrgExtParam.getSRCSYSTEM(), MDMAttributeNames.ENTITY_ORG_EXT));
			lastUpdateDate = Util.getCurrentTimeZone();
			record.setField(new Field(MDMAttributeNames.LAST_UPDATE_DATE, lastUpdateDate));
			record.setField(new Field(MDMAttributeNames.SRC_UPDT_BY, partyOrgExtParam.getUPDATEBY()));
			record.setField(new Field(MDMAttributeNames.SRC_SYSTEM, partyOrgExtParam.getSRCSYSTEM()));
			record.setField(new Field(MDMAttributeNames.SRC_SYS_KEY, partyOrgExtParam.getSRCPKEY()));
			record.setField(new Field(MDMAttributeNames.PARTY_SRC_SYS_KEY, partyOrgExtParam.getPARTYSRCSYSKEY()));

			record.setField(
					new Field(PartyOrgExtAttributes.MFE_PRTNR_PARENT_ORG, partyOrgExtParam.getMFEPRTNRPARENTORG()));
			record.setField(
					new Field(PartyOrgExtAttributes.MFE_WW_PARENT_PRTN_NM, partyOrgExtParam.getMFEWWPARENTPRTNNM()));
			/*record.setField(new Field(PartyOrgExtAttributes.MFE_SUBSDRY_PARENT_PRTN_NM,
					partyOrgExtParam.getMFESUBSDRYPARENTPRTNNM()));*/
			record.setField(new Field(PartyOrgExtAttributes.PTR_PARENT_UCN, partyOrgExtParam.getPTRPARENTUCN()));
			record.setField(new Field(PartyOrgExtAttributes.PTR_PARENT_NM, partyOrgExtParam.getPTRPARENTNM()));
			record.setField(
					new Field(PartyOrgExtAttributes.PTR_GLBL_PARENT_UCN, partyOrgExtParam.getPTRGLBLPARENTUCN()));

			cleansePutRequest.setRecord(record);
			// execute Put request
			cleansePutResponse = (CleansePutResponse) siperianClient.process(cleansePutRequest);
			LOG.info("PartyOrgExtn cleansePut request processed successfully: " + cleansePutResponse.getMessage());
			// extract result
			RecordKey recordKey = cleansePutResponse.getRecordKey();
			genericUpsertResponse.setSRCPKEY(recordKey.getSourceKey());
			genericUpsertResponse.setROWIDOBJECT(recordKey.getRowid());
			genericUpsertResponse.setStatus(cleansePutResponse.getMessage());
			LOG.info("ROWID_OBJECT of created PartyOrgExtn record = " + recordKey.getRowid());
			LOG.debug("Action Type = " + cleansePutResponse.getActionType());
			LOG.debug("Action Msg = " + cleansePutResponse.getMessage());

		} catch (SiperianServerException sifExcp) {
			LOG.error(
					"SiperianServerException occured while processing CleansePutRequest for PartyOrgExtn: " + sifExcp);
			sifExcp.printStackTrace();
			ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
			customException.setMessage("SIF exception occured while processing Put request for PartyOrgExtn. "
					+ customException.getMessage());
			customException.setRootExceptionMsg(
					sifExcp + " CleansePut operation failed for PartyOrgExtn " + partyOrgExtParam.getSRCPKEY());
			genericUpsertResponse.setSRCPKEY(partyOrgExtParam.getSRCPKEY());
			genericUpsertResponse.setStatus("Failed");
			genericUpsertResponse.setErrorMsg("CleansePut operation failed for PartyOrgExtn");
		} catch (Exception excp) {
			LOG.error("Exception occured while processing CleansePutRequest for PartyOrgExtn: " + excp);
			excp.printStackTrace();
			ServiceProcessingException customException = new ServiceProcessingException(excp);
			customException.setMessage(
					"Exception occured while processing Put request for PartyOrgExtn. " + customException.getMessage());
			customException.setRootExceptionMsg(
					excp + " CleansePut operation failed for PartyOrgExtn " + partyOrgExtParam.getSRCPKEY());
			genericUpsertResponse.setSRCPKEY(partyOrgExtParam.getSRCPKEY());
			genericUpsertResponse.setStatus("Failed");
			genericUpsertResponse.setErrorMsg("CleansePut operation failed for PartyOrgExtn");
		}

		LOG.info("Executed cleansePutPartyOrgExtn()");
		return genericUpsertResponse;

	}

	public UpsertPartyGroupResponse processUpsertPartyGroup(UpsertPartyGroupRequest upsertPartyGroupRequest) {
		LOG.info("Executing processUpsertPartyGroup()");
		UpsertPartyGroupResponse upsertPartyGroupResponse = new UpsertPartyGroupResponse();
		SFDCUpsertPartyDAO partyDao = new SFDCUpsertPartyDAO();
		SiperianClient siperianClient = null;
		UserTransaction transaction = null;
		GenericUpsertResponse upsertResponse = null;
		try {
			siperianClient = (SiperianClient) checkOut();
			transaction = ((EjbSiperianClient) siperianClient).createTX(300000);

			for (int index = 0; index < upsertPartyGroupRequest.getPartyGroupType().size(); index++) {
				PartyGroupXrefType partyGroupXrefType = upsertPartyGroupRequest.getPartyGroupType().get(index);
				if (validatePartyGroupRequestData(partyGroupXrefType)) {
					try {
						transaction.begin();
						upsertResponse = cleansePutPartyGroup(partyGroupXrefType, siperianClient);
						transaction.commit();
						LOG.info("Calling processTokenizeRequest() rowidObject::" + upsertResponse.getROWIDOBJECT());
						processTokenizeRequest(upsertResponse.getROWIDOBJECT());
						//stamp Party group UCN
						if (Util.isNullOrEmpty(partyGroupXrefType.getUCN())) {
							try{
								LOG.info("Calling stamping UCN() in party group rowidObject::" + upsertResponse.getROWIDOBJECT());
								partyDao.setUCNSeq(upsertResponse.getROWIDOBJECT(), null,MDMAttributeNames.PARTY_GROUP_BO);
							}catch (Exception spExcp) {
								LOG.error("Failed to set UCN in PartyGrpSaveHandler: ", spExcp);
								//throw spExcp;
							}
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
					upsertPartyGroupResponse.getUpsertResponse().add(upsertResponse);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			checkIn(siperianClient);
		}

		LOG.info("Executed processUpsertPartyGroup()");
		return upsertPartyGroupResponse;
	}

	private boolean validatePartyGroupRequestData(PartyGroupXrefType partyGroupXrefType) {
		boolean validData = true;
		if (partyGroupXrefType.getENTITYTYPE() == null || partyGroupXrefType.getENTITYTYPE().equals("")) {
			validData = false;
		} else if (partyGroupXrefType.getSRCPKEY() == null || partyGroupXrefType.getSRCPKEY().equals("")) {
			validData = false;
		} else if (partyGroupXrefType.getSRCSYSTEM() == null || partyGroupXrefType.getSRCSYSTEM().equals("")) {
			validData = false;
		}
		return validData;
	}

	private GenericUpsertResponse cleansePutPartyGroup(PartyGroupXrefType partyGroupParam,
			SiperianClient siperianClient) {

		LOG.info("Executing cleansePutPartyGroup()");
		CleansePutRequest cleansePutRequest = new CleansePutRequest();
		CleansePutResponse cleansePutResponse = null;
		GenericUpsertResponse genericUpsertResponse = new GenericUpsertResponse();
		try {
			// prepare CleansePutRequest
			Record record = new Record();
			// set mapping name
			record.setSiperianObjectUid(
					Util.getMappingObjectUid(partyGroupParam.getSRCSYSTEM(), MDMAttributeNames.ENTITY_PARTY_GROUP));
			lastUpdateDate = Util.getCurrentTimeZone();
			record.setField(new Field(MDMAttributeNames.LAST_UPDATE_DATE, lastUpdateDate));
			record.setField(new Field(MDMAttributeNames.SRC_SYSTEM, partyGroupParam.getSRCSYSTEM()));
			record.setField(new Field(MDMAttributeNames.SRC_SYS_KEY, partyGroupParam.getSRCPKEY()));

			record.setField(new Field(PartyGroupAttributes.ENTITY_TYPE, partyGroupParam.getENTITYTYPE()));
			record.setField(new Field(PartyGroupAttributes.PARTY_GROUP_NAME, partyGroupParam.getPARTYGROUPNAME()));
			record.setField(new Field(PartyGroupAttributes.ENTITY_TYPE_DESC, partyGroupParam.getENTITYTYPEDESC()));
			record.setField(new Field(PartyGroupAttributes.LEVEL_1, partyGroupParam.getLEVEL1()));
			cleansePutRequest.setRecord(record);
			// execute Put request
			cleansePutResponse = (CleansePutResponse) siperianClient.process(cleansePutRequest);
			LOG.info("PartyGroup cleansePut request processed successfully: " + cleansePutResponse.getMessage());
			// extract result
			RecordKey recordKey = cleansePutResponse.getRecordKey();
			genericUpsertResponse.setSRCPKEY(recordKey.getSourceKey());
			genericUpsertResponse.setStatus(cleansePutResponse.getMessage());
			genericUpsertResponse.setROWIDOBJECT(recordKey.getRowid());
			LOG.info("ROWID_OBJECT of created PartyGroup record = " + recordKey.getRowid());
			LOG.debug("Action Type = " + cleansePutResponse.getActionType());
			LOG.debug("Action Msg = " + cleansePutResponse.getMessage());

		} catch (SiperianServerException sifExcp) {
			LOG.error("SiperianServerException occured while processing CleansePutRequest for partyGroup: " + sifExcp);
			sifExcp.printStackTrace();
			ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
			customException.setMessage("SIF exception occured while processing Put request for partyGroup. "
					+ customException.getMessage());
			customException.setRootExceptionMsg(
					sifExcp + " CleansePut operation failed for partyGroup " + partyGroupParam.getSRCPKEY());
			genericUpsertResponse.setSRCPKEY(partyGroupParam.getSRCPKEY());
			genericUpsertResponse.setStatus("Failed");
			genericUpsertResponse.setErrorMsg("CleansePut operation failed for partyGroup");
		} catch (Exception excp) {
			LOG.error("Exception occured while processing CleansePutRequest for partyGroup: " + excp);
			excp.printStackTrace();
			ServiceProcessingException customException = new ServiceProcessingException(excp);
			customException.setMessage(
					"Exception occured while processing Put request for partyGroup. " + customException.getMessage());
			customException.setRootExceptionMsg(
					excp + " CleansePut operation failed for partyGroup " + partyGroupParam.getSRCPKEY());
			genericUpsertResponse.setSRCPKEY(partyGroupParam.getSRCPKEY());
			genericUpsertResponse.setStatus("Failed");
			genericUpsertResponse.setErrorMsg("CleansePut operation failed for partyGroup");
		}

		LOG.info("Executed cleansePutPartyGroup()");
		return genericUpsertResponse;

	}

	// generate match token for the partyGroup record
	private void processTokenizeRequest(String rowidObject) throws ServiceProcessingException {

		if (!Util.isNullOrEmpty(rowidObject)) {
			rowidObject = rowidObject.trim();
		}
		LOG.debug("Executing processTokenizeRequest()" + rowidObject);
		SiperianClient siperianClient = null;

		try {
			siperianClient = (SiperianClient) checkOut();

			TokenizeRequest tokenizeRequest = new TokenizeRequest();
			tokenizeRequest.setSiperianObjectUid(SiperianObjectType.BASE_OBJECT.makeUid("C_B_PARTY_GROUP"));
			RecordKey recordKey = new RecordKey();
			recordKey.setRowid(rowidObject);
			tokenizeRequest.setRecordKey(recordKey);
			tokenizeRequest.setActionType("Update");
			TokenizeResponse tokenizeResponse = (TokenizeResponse) siperianClient.process(tokenizeRequest);
			LOG.info("Match Token generated for PartyID: " + rowidObject + " Token msg: "
					+ tokenizeResponse.getMessage());

			LOG.debug("Executed processTokenizeRequest()");
		} catch (Exception excp) {
			LOG.error("Caught exception within processTokenizeRequest() " + excp.getMessage());

			ServiceProcessingException customExcp = new ServiceProcessingException(excp);
			throw customExcp;
		} finally {
			checkIn(siperianClient);
		}
	}
}
