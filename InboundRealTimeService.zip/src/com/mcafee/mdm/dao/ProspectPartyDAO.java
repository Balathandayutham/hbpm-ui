package com.mcafee.mdm.dao;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlParameterValue;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.mcafee.mdm.constants.Constant;
import com.mcafee.mdm.dao.pojo.AcntCntctRelData;
import com.mcafee.mdm.dao.pojo.CntctPkeyRowIdRelData;
import com.mcafee.mdm.dao.pojo.PartyChildRowIdData;
import com.mcafee.mdm.dao.pojo.SearchedRecordCollection;
import com.mcafee.mdm.exception.ServiceProcessingException;
import com.mcafee.mdm.util.JDBCConnectionProvider;
import com.mcafee.mdm.util.ObjectPool;
import com.mcafee.mdm.util.Util;

import oracle.jdbc.OracleTypes;

@Component
public class ProspectPartyDAO extends ObjectPool {
	private static final Logger LOG = Logger.getLogger(ProspectPartyDAO.class
			.getName());

	@Resource(name = "configProp")
	private Properties configProps;
	@Resource(name = "m4mQueryProp")
	private Properties queryProp;

	@Autowired
	private JdbcTemplate jdbcTemplate;

	public Boolean isContactAssociatedWithCustomerOrDNB(
			List<String> contactPkeyList) {
		LOG.debug("[isContactAssociatedWithCustomerOrDNB] START::contactPkeyList::"
				+ contactPkeyList);
		Boolean isContactFound = Boolean.FALSE;
		try {
			String sqlQuery = queryProp
					.getProperty(Constant.QUERY_CONTACT_ASSOCIATION_CHECK)
					+ StringUtils.collectionToDelimitedString(contactPkeyList,
							Constant.STR_COMMA, Constant.STR_SINGLE_QUOTE,
							Constant.STR_SINGLE_QUOTE) + Constant.STR_CLOSE_BRACKET;
			LOG.debug("[isContactAssociatedWithCustomerOrDNB] sqlQuery::"
					+ sqlQuery);
			List<SearchedRecordCollection> accountPartyList = jdbcTemplate
					.query(sqlQuery,
							new BeanPropertyRowMapper<SearchedRecordCollection>(
									SearchedRecordCollection.class));
			if(CollectionUtils.isEmpty(accountPartyList)) {
				LOG.debug("[isContactAssociatedWithCustomerOrDNB] no contact association found");
			} else {
				List<String> prospectDunsList = new ArrayList<String>();
				List<String> singletonDunsList = new ArrayList<String>();
				for(SearchedRecordCollection accountParty:accountPartyList) {
					if(Constant.PARTY_TYPE_CUSTOMER.equals(accountParty.getParty_type())) {
						LOG.debug("[isContactAssociatedWithCustomerOrDNB] contact association found for Customer::" + accountParty.getParty_rowid());
						isContactFound = Boolean.TRUE;
						break;
					} else if(Constant.PARTY_TYPE_PROSPECT_ACCOUNT.equals(accountParty.getParty_type())) {
						prospectDunsList.add(accountParty.getParty_rowid());
					} else {
						singletonDunsList.add(accountParty.getParty_rowid());
					}
				}
				if(!isContactFound && !CollectionUtils.isEmpty(prospectDunsList)) {
					if(!CollectionUtils.isEmpty(getRowIdsProspectAccountWithDuns(prospectDunsList))) {
						isContactFound = Boolean.TRUE;
					}
				}
				
				if(!isContactFound && !CollectionUtils.isEmpty(singletonDunsList)) {
					if(CollectionUtils.isEmpty(getRowIdsDnbSingletonAccounts(singletonDunsList))) {
						isContactFound = Boolean.TRUE;
					}
				}
			}
		} catch (Exception e) {
			LOG.error("[isContactAssociatedWithCustomerOrDNB] ERROR::", e);
		}
		LOG.debug("[isContactAssociatedWithCustomerOrDNB] EXIT::isContactFound::"
				+ isContactFound);
		return isContactFound;
	}

	/**
	 * Checks if Marketing XRef has any deleted cluster for the given PKEY and
	 * SRC_SYSTEM
	 * 
	 * @param srcPkey
	 * @param srcSystem
	 * @return
	 */
	public Boolean isDeletedExistForPkey(String srcPkey, String srcSystem) {
		LOG.debug("[isDeletedExistForPkey] START::srcPkey::" + srcPkey
				+ ", srcSystem::" + srcSystem);
		String sqlQuery = queryProp
				.getProperty(Constant.QUERY_ACCOUNT_DELETED_CHECK);
		Boolean isDeletedClusterExists = null;
		LOG.debug("[isDeletedExistForPkey] sqlQuery::" + sqlQuery);
		Integer dnbRowCount = jdbcTemplate.queryForObject(sqlQuery,
				Integer.class, srcSystem.trim(), srcPkey);
		isDeletedClusterExists = (dnbRowCount > 0);
		LOG.debug("[isDeletedExistForPkey] EXIT::mrktRowCount::"
				+ isDeletedClusterExists);
		return isDeletedClusterExists;
	}
	
	public List<String> isAccountAssociatedWithCustomerOrDNB(
			List<String> accountPkeyList) {
		LOG.debug("[isAccountAssociatedWithCustomerOrDNB] START::accountPkeyList::"
				+ accountPkeyList);
		Boolean isAccountFound = Boolean.FALSE;
		List<String> rowIDList = new ArrayList<String>();
		try {
			String sqlQuery = queryProp
					.getProperty(Constant.QUERY_ACCOUNT_ASSOCIATION_CHECK)
					+ StringUtils.collectionToDelimitedString(accountPkeyList,
							Constant.STR_COMMA, Constant.STR_SINGLE_QUOTE,
							Constant.STR_SINGLE_QUOTE) + Constant.STR_CLOSE_BRACKET;
			LOG.debug("[isAccountAssociatedWithCustomerOrDNB] sqlQuery::"
					+ sqlQuery);
			List<SearchedRecordCollection> accountPartyList = jdbcTemplate
					.query(sqlQuery,
							new BeanPropertyRowMapper<SearchedRecordCollection>(
									SearchedRecordCollection.class));
			if(CollectionUtils.isEmpty(accountPartyList)) {
				LOG.debug("[isAccountAssociatedWithCustomerOrDNB] no Account association found");
			} else {
				List<String> customerList = new ArrayList<String>();
				List<String> prospectDunsList = new ArrayList<String>();
				List<String> singletonDunsList = new ArrayList<String>();
				for(SearchedRecordCollection accountParty:accountPartyList) {
					if(Constant.PARTY_TYPE_CUSTOMER.equals(accountParty.getParty_type())) {
						LOG.debug("[isAccountAssociatedWithCustomerOrDNB] Account association found for Customer::" + accountParty.getParty_rowid());
						customerList.add(accountParty.getParty_rowid());
						rowIDList = customerList;
						isAccountFound = Boolean.TRUE;
						break;
					} else if(Constant.PARTY_TYPE_PROSPECT_ACCOUNT.equals(accountParty.getParty_type())) {
						prospectDunsList.add(accountParty.getParty_rowid());
					} else {
						singletonDunsList.add(accountParty.getParty_rowid());
					}
				}
				if(!isAccountFound && !CollectionUtils.isEmpty(prospectDunsList)) {
					if(!CollectionUtils.isEmpty(getRowIdsProspectAccountWithDuns(prospectDunsList))) {
						isAccountFound = Boolean.TRUE;
						rowIDList = prospectDunsList;
					}
				}
				
			/*	if(!isContactFound && !CollectionUtils.isEmpty(singletonDunsList)) {
					if(CollectionUtils.isEmpty(getRowIdsDnbSingletonAccounts(singletonDunsList))) {
						isContactFound = Boolean.TRUE;
					}
				}*/
			}
		} catch (Exception e) {
			LOG.error("[isAccountAssociatedWithCustomerOrDNB] ERROR::", e);
		}
		LOG.debug("[isAccountAssociatedWithCustomerOrDNB] EXIT::isAccountFound::"
				+ isAccountFound);
		return rowIDList;
	}

	/**
	 * Checks if Marketing XRef has any DNB cluster for the given PKEY and
	 * SRC_SYSTEM
	 * 
	 * @param srcPkey
	 * @param srcSystem
	 * @return
	 */
	public Boolean isDNBClusterExistForPkey(String srcPkey, String srcSystem) {
		LOG.debug("[isDNBClusterExistForPkey] START::srcPkey::" + srcPkey
				+ ", srcSystem::" + srcSystem);
		String sqlQuery = queryProp
				.getProperty(Constant.QUERY_ACCOUNT_DNB_CHECK);
		Boolean isDNBClusterExists = null;
		LOG.debug("[isDNBClusterExistForPkey] sqlQuery::" + sqlQuery);
		Integer dnbRowCount = jdbcTemplate.queryForObject(sqlQuery,
				Integer.class, srcSystem.trim(), srcPkey);
		isDNBClusterExists = (dnbRowCount > 0);
		LOG.debug("[isDNBClusterExistForPkey] EXIT::mrktRowCount::"
				+ isDNBClusterExists);
		return isDNBClusterExists;
	}

	/**
	 * Checks if Marketing XRef record exists for the given PKEY and SRC_SYSTEM
	 * <p>
	 * It returns ROWID_OBJECT and number of rows for given PKEY AND SRC_SYSTEM
	 * satisfying the above condition
	 * </p>
	 * 
	 * @param srcPkey
	 * @param srcSystem
	 * @return
	 */
	public Map<String, Integer> getExistingRowIdAndProspectRecordCount(
			String srcPkey, String srcSystem) {
		LOG.debug("[getExistingRowIdAndProspectRecordCount] START::srcPkey::"
				+ srcPkey + ", srcSystem::" + srcSystem);
		String sqlQuery = null;
		if("ADB".equalsIgnoreCase(srcSystem)){
			sqlQuery = queryProp
					.getProperty(Constant.QUERY_ADOBE_ACCOUNT_XREF_COUNT_CHECK);
		}else{
			sqlQuery = queryProp
					.getProperty(Constant.QUERY_ACCOUNT_XREF_COUNT_CHECK);
		}
	/*	String sqlQuery = queryProp
				.getProperty(Constant.QUERY_ACCOUNT_XREF_COUNT_CHECK);*/
		Map<String, Integer> rowIdCountMap = new HashMap<String, Integer>();
		LOG.debug("[getExistingRowIdAndProspectRecordCount] sqlQuery::"
				+ sqlQuery);
		List<Map<String, Object>> rowCountMapList = jdbcTemplate.queryForList(
				sqlQuery, srcSystem.trim(), srcPkey);
		if (CollectionUtils.isEmpty(rowCountMapList)) {
			LOG.debug("[getExistingRowIdAndProspectRecordCount] No Record found");
		} else {
			Map<String, Object> rowCountMapRecord = rowCountMapList.get(0);
			LOG.debug("[getExistingRowIdAndProspectRecordCount] rowCountMapRecord::"
					+ rowCountMapRecord);
			if (rowCountMapRecord == null || rowCountMapRecord.isEmpty()) {
				LOG.debug("[getExistingRowIdAndProspectRecordCount] No Record found");
			} else {
				String rowIdObject = (String) rowCountMapRecord
						.get(Constant.COLUMN_ROWID_OBJECT);
				BigDecimal rowIdObjectCount = (BigDecimal) rowCountMapRecord
						.get(Constant.COLUMN_ROWID_OBJECT_COUNT);
				if (Util.isNullOrEmpty(rowIdObject)) {
					LOG.debug("[getExistingRowIdAndProspectRecordCount] No ROWID Found");
				} else {
					if (rowIdObjectCount == null) {
						rowIdCountMap.put(rowIdObject, 0);
					} else {
						rowIdCountMap.put(rowIdObject,
								rowIdObjectCount.intValue());
					}
				}
			}
		}
		LOG.debug("[getExistingRowIdAndProspectRecordCount] EXIT::mrktRowCount::"
				+ rowIdCountMap);
		return rowIdCountMap;
	}

	/**
	 * Get RowID party from XRef table for the input source Pkey and System
	 * 
	 * @param srcPkey
	 * @param srcSystem
	 * @return rowIdParty
	 */
	public String getPartyRowIdBySrcPkey(String srcPkey, String srcSystem) {
		LOG.debug("[getPartyRowIdBySrcPkey] START::srcPkey::" + srcPkey
				+ ", srcSystem::" + srcSystem);
		String rowIdParty = null;
		String sqlQuery = queryProp
				.getProperty(Constant.QUERY_ROWID_PARTY_BY_SRC_PKEY);
		List<String> rowIdList = jdbcTemplate.queryForList(sqlQuery,
				String.class, srcPkey, srcSystem);
		if (CollectionUtils.isEmpty(rowIdList)) {
			LOG.debug("[getPartyRowIdBySrcPkey] No ROWID found::");
		} else {
			rowIdParty = rowIdList.get(0);
		}
		LOG.debug("[getPartyRowIdBySrcPkey] EXIT::rowIdParty::" + rowIdParty);
		return rowIdParty;
	}

	/**
	 * Check for root un-merge, checking rowIdParty with the source Pkey and
	 * System
	 * 
	 * @param srcPkey
	 * @param srcSystem
	 * @return rowIdParty
	 */
	public Boolean isRootUnmerge(String rowIdParty, String srcPkey,
			String srcSystem) {
		LOG.debug("[isRootUnmerge] START::srcPkey::" + srcPkey
				+ ", srcSystem::" + srcSystem);
		String sqlQuery = queryProp
				.getProperty(Constant.QUERY_ROOT_UNMERGE_CHECK_QUERY);
		Integer rowCount = jdbcTemplate.queryForObject(sqlQuery, Integer.class,
				rowIdParty, srcPkey, srcSystem);
		LOG.debug("[isRootUnmerge] EXIT::Root Unmerge::" + (rowCount == 0));
		return (rowCount == 0);
	}

	public List<PartyChildRowIdData> getPartyChildRowId(
			Set<String> matchedRowIds) {
		LOG.debug("[getPartyChildRowId]ENTER::matchedRowIds::" + matchedRowIds);
		List<PartyChildRowIdData> partyChildRowIdList = null;
		String sqlQuery = queryProp
				.getProperty(Constant.QUERY_PARTY_CHILD_TABLE_ROWID_QUERY)
				+ StringUtils.collectionToDelimitedString(matchedRowIds,
						Constant.STR_COMMA, Constant.STR_SINGLE_QUOTE,
						Constant.STR_SINGLE_QUOTE) + Constant.STR_CLOSE_BRACKET;
		partyChildRowIdList = jdbcTemplate.query(sqlQuery,
				new BeanPropertyRowMapper<PartyChildRowIdData>(
						PartyChildRowIdData.class));
		return partyChildRowIdList;
	}
	
	public List<CntctPkeyRowIdRelData> getAdobeContactRowIdsFromPkeys(
			String contactPkeys) {
		LOG.debug("[getAdobeContactRowIdsFromPkeys] ENTER::contactPkeys & acctPkeys::"
				+ contactPkeys);
		List<CntctPkeyRowIdRelData> contactRowIdList = null;
		String sqlQuery = null;
		if (!Util.isNullOrEmpty(contactPkeys)) {
			sqlQuery = queryProp
						.getProperty(Constant.QUERY_ROWID_ADOBE_PERSON_BY_SRC_PKEY)
						+ contactPkeys + Constant.STR_CLOSE_BRACKET;
			contactRowIdList = jdbcTemplate.query(sqlQuery,
					new BeanPropertyRowMapper<CntctPkeyRowIdRelData>(
							CntctPkeyRowIdRelData.class));
		}
		LOG.debug("[getAdobeContactRowIdsFromPkeys] EXIT::contactRowIdSet & acctPkeySet::"
				+ contactRowIdList);
		return contactRowIdList;
	}

	public List<CntctPkeyRowIdRelData> getContactRowIdsFromPkeys(
			String contactPkeys,boolean isContactSFCRec) {
		LOG.debug("[processAcntCntctRel] ENTER::contactPkeys & acctPkeys::"
				+ contactPkeys);
		List<CntctPkeyRowIdRelData> contactRowIdList = null;
		String sqlQuery = null;
		if (!Util.isNullOrEmpty(contactPkeys)) {
			if( isContactSFCRec){
			 sqlQuery = queryProp
					.getProperty(Constant.QUERY_ROWID_PERSON_BY_SRC_PKEY_SFC)
					+ contactPkeys + Constant.STR_CLOSE_BRACKET;
			}else{
				 sqlQuery = queryProp
						.getProperty(Constant.QUERY_ROWID_PERSON_BY_SRC_PKEY)
						+ contactPkeys + Constant.STR_CLOSE_BRACKET;
			}
			contactRowIdList = jdbcTemplate.query(sqlQuery,
					new BeanPropertyRowMapper<CntctPkeyRowIdRelData>(
							CntctPkeyRowIdRelData.class));
		}
		LOG.debug("[processAcntCntctRel] EXIT::contactRowIdSet & acctPkeySet::"
				+ contactRowIdList);
		return contactRowIdList;
	}
	
	public List<CntctPkeyRowIdRelData> getContactRowIdsFromPkeysAdb(String contactPkeys) {
		LOG.debug("[processAcntCntctRel] ENTER::contactPkeys & acctPkeys::"
				+ contactPkeys);
		List<CntctPkeyRowIdRelData> contactRowIdList = null;
		String sqlQuery = null;
		if (!Util.isNullOrEmpty(contactPkeys)) {
			
			 sqlQuery = queryProp
					.getProperty(Constant.QUERY_ROWID_PERSON_BY_SRC_PKEY_ADB)
					+ contactPkeys + Constant.STR_CLOSE_BRACKET;
			contactRowIdList = jdbcTemplate.query(sqlQuery,
					new BeanPropertyRowMapper<CntctPkeyRowIdRelData>(
							CntctPkeyRowIdRelData.class));
		}
		LOG.debug("[processAcntCntctRel] EXIT::contactRowIdSet & acctPkeySet::"
				+ contactRowIdList);
		return contactRowIdList;
	}

	public String getSipPopCountry(String mdmCountryCd)
			throws ServiceProcessingException {
		LOG.debug("[getSipPopCountry] ENTER");
		String sipPopCountry = null;
		String sql = queryProp.getProperty(Constant.QUERY_SIP_POP_QUERY);
		LOG.debug("[getSipPopCountry] SQL::" + sql);
		List<String> sipPopCountryList = jdbcTemplate.queryForList(sql,
				String.class, mdmCountryCd);
		LOG.debug("[getSipPopCountry] sipPopCountryList::" + sipPopCountryList);
		if (CollectionUtils.isEmpty(sipPopCountryList)) {
			LOG.debug("[getSipPopCountry] No SIPPOP Country Found");
		} else {
			sipPopCountry = sipPopCountryList.get(0);
		}
		LOG.debug("[getSipPopCountry] EXIT::sipPopCountry::" + sipPopCountry);
		return sipPopCountry;
	}

	@Transactional(rollbackFor = Exception.class)
	public void insertPkeysInTempTable(List<String> contactPkeyList,
			String srcSystem, String srcPkey, String rowIdAccount,boolean isContactSFCRec) {
		LOG.debug("[insertPkeysInTempTable] ENTER::contactPkeyList::"
				+ contactPkeyList);
		String sqlQuery = null;
		if (!CollectionUtils.isEmpty(contactPkeyList)) {
			if(isContactSFCRec){
				 sqlQuery = queryProp
						.getProperty(Constant.QUERY_ACNT_CNTCT_PENDING_REL_INSERT_SFC);
			}else{
			 sqlQuery = queryProp
					.getProperty(Constant.QUERY_ACNT_CNTCT_PENDING_REL_INSERT);
			}
			for (String contactPkey : contactPkeyList) {
				jdbcTemplate.update(sqlQuery, srcSystem, srcPkey, srcSystem,
						contactPkey, rowIdAccount);
			}
		}
		LOG.debug("[processAcntCntctRel] EXIT");
	}

	@Transactional(rollbackFor = Exception.class)
	public void deletePkeysFromTempTable(String contactPkeys, String srcSystem,
			String srcPkey, boolean isAccnt,boolean isContactSFCRec) {
		LOG.debug("[deletePkeysFromTempTable] ENTER::contactPkeyList::"
				+ contactPkeys);
		String sqlQuery = null;
		if (!Util.isNullOrEmpty(contactPkeys)) {
			if (isAccnt) {
				if (isContactSFCRec){
					sqlQuery = queryProp
							.getProperty(Constant.QUERY_ACNT_CNTCT_PENDING_REL_DELETE_SFC)
							+ contactPkeys + Constant.STR_CLOSE_BRACKET;
				}else{
				sqlQuery = queryProp
						.getProperty(Constant.QUERY_ACNT_CNTCT_PENDING_REL_DELETE)
						+ contactPkeys + Constant.STR_CLOSE_BRACKET;
				}
			} else {
				if (isContactSFCRec){
					sqlQuery = queryProp
							.getProperty(Constant.QUERY_CNTCT_ACNT_PENDING_REL_DELETE_SFC)
							+ contactPkeys + Constant.STR_CLOSE_BRACKET;
				}else{
				sqlQuery = queryProp
						.getProperty(Constant.QUERY_CNTCT_ACNT_PENDING_REL_DELETE)
						+ contactPkeys + ")";
				}
			}
			jdbcTemplate.update(sqlQuery, srcSystem, srcPkey);
		}
		LOG.debug("[deletePkeysFromTempTable] EXIT");
	}

	// To check if UCN is already present in Surviving Record or not.
	public String checkifUCNExists(String survivingRowidObject) {

		String ucn = null;
		try {
			LOG.debug("Executing checkifUCNExists()");
			StringBuilder sql = new StringBuilder();
			sql.append("SELECT UCN FROM C_B_PARTY_XREF WHERE ROWID_OBJECT = '"
					+ survivingRowidObject
					+ "' AND ROWID_SYSTEM = 'SYS0' AND UCN IS NOT NULL ");
			LOG.debug("SQL for checkifUCNExists()--> " + sql);
			// ucn = jdbcTemplate.queryForObject(sql.toString(), String.class);

			List<String> ucnList = jdbcTemplate.query(sql.toString(),
					new RowMapper<String>() {
						public String mapRow(ResultSet rs, int rowNum)
								throws SQLException {
							return rs.getString(1);
						}
					});

			if (!ucnList.isEmpty()) {
				ucn = ucnList.get(0);
				LOG.debug("UCN exists & value is: " + ucnList.get(0));
			}
			LOG.debug("Executed checkifUCNExists()");
		} catch (EmptyResultDataAccessException excp) {
			LOG.error("Caught exception in checkifUCNExists()", excp);
		}
		return ucn;
	}

	/** UCN Generation for SAP/SBL Accounts & Prospect Accounts **/
	public String getNextUCNValue(String partyType)
			throws ServiceProcessingException {
		LOG.debug("[getNextUCNValue] ENTER");
		String ucnFunction = configProps
				.getProperty(Constant.MFE_GET_UCN_BY_PARTY_TYPE);
		String ucn = null;
		String sql = "SELECT " + ucnFunction + "('" + partyType
				+ "') FROM DUAL";
		LOG.debug("[getNextUCNValue] SQL::" + sql);

		try {
			ucn = jdbcTemplate.queryForObject(sql, String.class);
		} catch (DataAccessException exp) {
			LOG.error("DataAccessException in getting UCN sequence: ", exp);
			ServiceProcessingException customException = new ServiceProcessingException(
					exp);
			customException
					.setMessage("SQLException occured in getting UCN sequence: "
							+ exp.getMessage());
			throw customException;
		}
		LOG.debug("[getNextUCNValue] EXIT::UCN::" + ucn);
		return ucn;
	}

	/** UCN Generation for M4M Contacts **/
	public String getNextContactUCNValue() throws ServiceProcessingException {
		LOG.debug("[getNextContactUCNValue] ENTER");

		String ucn = null;
		String sql = "SELECT UCN_CONTACT_SEQ.NEXTVAL UCN FROM DUAL";
		LOG.debug("[getNextContactUCNValue] SQL::" + sql);

		try {
			ucn = jdbcTemplate.queryForObject(sql, String.class);
		} catch (DataAccessException exp) {
			LOG.error("DataAccessException in getting Contact UCN sequence: ",
					exp);
			ServiceProcessingException customException = new ServiceProcessingException(
					exp);
			customException
					.setMessage("SQLException occured in getting Contact UCN sequence: "
							+ exp.getMessage());
			throw customException;
		}
		LOG.debug("[getNextContactUCNValue] EXIT::UCN::" + ucn);
		return ucn;
	}

	/**
	 * Retrieve pending Account-Contact Relation mapping from temp table
	 * MDM_RTS_MRKT_ACC_CONTACT_REL
	 * 
	 * @param srcSystem
	 * @param srcPkey
	 * @param boClassCd
	 * @return actnCntctRelDataList
	 */
	public List<AcntCntctRelData> getPendingAcntCntctRel(String srcSystem,
			String srcPkey, String boClassCd,boolean isContactSFCRec) {
		String sqlQuery = null;
		LOG.debug("[processPendingAcntCntctRel] ENTER");
		if (Constant.BO_CLASS_CODE_ORG.equalsIgnoreCase(boClassCd)) {
			 if (isContactSFCRec){
			sqlQuery = queryProp
					.getProperty(Constant.QUERY_ACNT_CNTCT_PENDING_REL_BY_ACNT_SFC);
			 }
			 else{
				 sqlQuery = queryProp
							.getProperty(Constant.QUERY_ACNT_CNTCT_PENDING_REL_BY_ACNT);
			 }
		} else if (Constant.BO_CLASS_CODE_PERSON.equalsIgnoreCase(boClassCd)) {
			if (isContactSFCRec){
				sqlQuery = queryProp
						.getProperty(Constant.QUERY_ACNT_CNTCT_PENDING_REL_BY_CNTCT_SFC);
			}else{
				sqlQuery = queryProp
						.getProperty(Constant.QUERY_ACNT_CNTCT_PENDING_REL_BY_CNTCT);
			}
			
		}
		List<AcntCntctRelData> actnCntctRelDataList = jdbcTemplate.query(
				sqlQuery, new BeanPropertyRowMapper<AcntCntctRelData>(
						AcntCntctRelData.class), srcPkey, srcSystem);
		LOG.debug("[processPendingAcntCntctRel] EXIT :: actnCntctRelDataList::"
				+ actnCntctRelDataList);
		return actnCntctRelDataList;
	}

	public List<String> getRowIdsProspectAccountWithDuns(
			List<String> matchedRowIds) {
		LOG.debug("[getRowIdsProspectAccountWithDuns]ENTER::matchedRowIds::"
				+ matchedRowIds);
		List<String> prospectRowIdsWithDuns = null;
		String sqlQuery = queryProp
				.getProperty(Constant.QUERY_ACCOUNT_PROSPECT_DNB_QUERY)
				+ StringUtils.collectionToDelimitedString(matchedRowIds,
						Constant.STR_COMMA, Constant.STR_SINGLE_QUOTE,
						Constant.STR_SINGLE_QUOTE) + Constant.STR_CLOSE_BRACKET;
		prospectRowIdsWithDuns = jdbcTemplate.queryForList(sqlQuery,
				String.class);
		return prospectRowIdsWithDuns;
	}

	public List<String> getRowIdsDnbSingletonAccounts(List<String> matchedRowIds) {
		LOG.debug("[getRowIdsProspectAccountWithDuns]ENTER::matchedRowIds::"
				+ matchedRowIds);
		List<String> singletonDunsRowIdList = null;
		String sqlQuery = queryProp
				.getProperty(Constant.QUERY_DNB_SINGLETON_QUERY)
				+ StringUtils.collectionToDelimitedString(matchedRowIds,
						Constant.STR_COMMA, Constant.STR_SINGLE_QUOTE,
						Constant.STR_SINGLE_QUOTE) + Constant.STR_CLOSE_BRACKET;
		singletonDunsRowIdList = jdbcTemplate.queryForList(sqlQuery,
				String.class);
		return singletonDunsRowIdList;
	}

	public List<String> getContactsByAccountRowId(String rowIdAccount) {
		LOG.debug("[getContactsByAccountRowId] ENTER");
		String sqlQuery = queryProp
				.getProperty(Constant.QUERY_ACCOUNT_CONTACT_REL_QUERY);
		List<String> contactRowIdList = jdbcTemplate.queryForList(sqlQuery,
				String.class, rowIdAccount);
		LOG.debug("[getContactsByAccountRowId] EXIT :: contactRowIdList::"
				+ contactRowIdList);
		return contactRowIdList;
	}
	
	public List<String> getContactRowIdsByAccountPkey(String accountSrcPkey) {
		LOG.debug("[getContactRowIdsByAccountPkey] ENTER");
		String sqlQuery = queryProp
				.getProperty(Constant.QUERY_FETCH_CONTACT_ROWID_BY_ACCT_PKEY);
		List<String> contactRowIdList = jdbcTemplate.queryForList(sqlQuery,
				String.class, accountSrcPkey);
		LOG.debug("[getContactRowIdsByAccountPkey] EXIT :: contactRowIdList::"
				+ contactRowIdList);
		return contactRowIdList;
	}

	public List<String> getContactEmailByContactPkey(String contactPkey)
			throws ServiceProcessingException {
		LOG.debug("[getContactEmailByContactPkey] ENTER");
		// List<String> commValue = null;
		// String commValue = null;
		List<String> commPkeyEmlList = null;
		String sql = queryProp
				.getProperty(Constant.QUERY_CNTCT_EML_BY_CNTCT_PKEY);
		LOG.debug("[getContactEmailByContactPkey] SQL::" + sql);

		try {
			commPkeyEmlList = jdbcTemplate.query(sql, new RowMapper<String>() {
				public String mapRow(ResultSet rs, int rowNum)
						throws SQLException {
					String cntcPkeyEml = null;
					cntcPkeyEml = rs.getString(1) + "|" + rs.getString(2);
					return cntcPkeyEml;
				}
			}, contactPkey);
			
		} catch (DataAccessException exp) {
			LOG.error("DataAccessException in getContactEmailByContactPkey: ",
					exp);
		}
		return commPkeyEmlList;
	}
	
	/**To Check if Surviving Contact Record Exists in PARTY_REL table or not**/
	public String checkifCntctRelExists(String contactRowidObject) {

		String relRowid = null;
		try {
			LOG.debug("Executing checkifCntctRelExists()");
			String sql = queryProp
					.getProperty(Constant.QUERY_CNTCT_RELATIONSHIP_EXISTS);
			LOG.debug("SQL for checkifCntctRelExists()--> " + sql);

			List<String> relRowidList = /*jdbcTemplate.query(sql.toString(),
					new RowMapper<String>() {
						public String mapRow(ResultSet rs, int rowNum)
								throws SQLException {
							return rs.getString(1);
						}
					}, contactRowidObject);*/
			jdbcTemplate.query(sql.toString(),
					new RowMapper<String>() {
						public String mapRow(ResultSet rs, int rowNum)
								throws SQLException {
							return rs.getString(1);
						}
					}, new SqlParameterValue(OracleTypes.FIXED_CHAR, contactRowidObject));

			if (!relRowidList.isEmpty()) {
				relRowid = relRowidList.get(0);
				LOG.debug("Contact Rel Exists & REL_ROWID_OBJECT is: " + relRowid);
			}
			LOG.debug("Executed checkifCntctRelExists()");
		} catch (EmptyResultDataAccessException excp) {
			LOG.error("Caught exception in checkifCntctRelExists()", excp);
		}
		return relRowid;
	}
		
	// Fetching List Of values from table PROSPECT_NAME_EXCLUSION_COND.
	public Boolean isNameExclusionExists(String partyName) {
		LOG.info("Executing getNameExclusionList()");
		String sql = queryProp.getProperty(Constant.QUERY_UNKNWN_PROSPECT_NAME_EXCLUSION);
		LOG.info("Query to fetch dynamic prospect_name exclusion conditions: " + sql);
		Integer returnVal = jdbcTemplate.queryForObject(sql, Integer.class, partyName.toUpperCase());
		LOG.info("Executed getNameExclusionList()");
		return returnVal > 0;
	}
	// Fetching List of junk value from table UNKNWN_ADDRESSLN1_EXCLUSION 
		public Boolean isJunkAddressLn1(String addressLn1){
			LOG.info("Executing Junk Address List");
			String sql=queryProp.getProperty(Constant.QUERY_ADDRESSlN1_EXCLUSION);
			LOG.info("Query to fetch junk addressln1 exlusion conditions: " + sql);
			Integer returnVal = jdbcTemplate.queryForObject(sql, Integer.class, addressLn1.toUpperCase());
			
			LOG.info("Executed junkAddressList()");
			return returnVal > 0;
		}
		// Fetching List Of values from table UNKNWN_CITY_EXCLUSION 
		public Boolean isJunkCity(String cityName){
			LOG.info("Executing Junk City");
			String sql=queryProp.getProperty(Constant.QUERY_CITY_EXCLUSION);
			LOG.info("Query to fetch dynamic city exclusion conditions: " + sql);
			Integer returnVal = jdbcTemplate.queryForObject(sql, Integer.class, cityName.toUpperCase());
			
			LOG.info("Executed isJunkCity()");
			return returnVal > 0;
		}
		
	/*US55- Sprint# 5 Code Change*/
	public List<String> getExistingAccountCountryCd(String contactPkey)
			throws ServiceProcessingException {
		LOG.debug("[getExistingAccountCountryCd] ENTER");
		List<String> acctRowidCountryCdList = null;
		String sql = queryProp
				.getProperty(Constant.QUERY_ACCT_ROWID_COUNTRY_CD);
		LOG.debug("[getExistingAccountCountryCd] SQL::" + sql);

		try {
			acctRowidCountryCdList = jdbcTemplate.query(sql, new RowMapper<String>() {
				public String mapRow(ResultSet rs, int rowNum)
						throws SQLException {
					String acctRowidCountryCd = rs.getString(1) + "|" + rs.getString(2);;
					//cntcPkeyEml = rs.getString(1) + "|" + rs.getString(2);
					return acctRowidCountryCd;
				}
			}, contactPkey);
			
		} catch (DataAccessException exp) {
			LOG.error("DataAccessException in getExistingAccountCountryCd: ",
					exp);
		}
		return acctRowidCountryCdList;
	}
	
	/* To Check Whether New ELQ Contact got Merged with SBL Contact or not. */
	public Boolean isMergedWithSBLContact(String contactRowid) {
		LOG.info("Executing isMergedWithSBLContact()");
		String sql = queryProp.getProperty(Constant.QUERY_IS_MERGED_WITH_SBL_CONTACT);
		LOG.info("Query to check isMergedWithSBLContact: " + sql);
		Integer returnVal = jdbcTemplate.queryForObject(sql, Integer.class, contactRowid.trim());
		LOG.info("Executed isMergedWithSBLContact()");
		return returnVal > 0;
	}
	
	/*US55- Sprint# 5 Code Change*/
/*	public List<String> getExistingSBLAccountCountryCd(String contactRowid)
			throws ServiceProcessingException {
		LOG.debug("[getExistingSBLAccountCountryCd] ENTER");
		List<String> acctRowidCountryCdList = new ArrayList<String>();
		String sql = queryProp
				.getProperty(Constant.QUERY_SBL_ACCT_ROWID_COUNTRY_CD);
		LOG.debug("[getExistingSBLAccountCountryCd] SQL::" + sql);

		try {
			acctRowidCountryCdList = jdbcTemplate.query(sql, new RowMapper<String>() {
				public String mapRow(ResultSet rs, int rowNum)
						throws SQLException {
					String acctRowidCountryCd = rs.getString(1) + "|" + rs.getString(2);;
					//cntcPkeyEml = rs.getString(1) + "|" + rs.getString(2);
					return acctRowidCountryCd;
				}
			}, contactRowid);
			
		} catch (DataAccessException exp) {
			LOG.error("DataAccessException in getExistingSBLAccountCountryCd: ",
					exp);
		}
		LOG.debug("[getExistingSBLAccountCountryCd] EXIT");
		if(acctRowidCountryCdList != null && acctRowidCountryCdList.size()>0){
			for(String acctRowidCountryCd: acctRowidCountryCdList){
				LOG.debug("acctRowidCountryCd: "+ acctRowidCountryCd);
			}
		}
		return acctRowidCountryCdList;
	}*/
	
	/*US55- Sprint# 5 Code Change*/
	public List<String> getExistingSBLAccountCountryCd(String contactPkey)
			throws ServiceProcessingException, SQLException {
		LOG.debug("[getExistingSBLAccountCountryCd] ENTER");
		List<String> acctRowidCountryCdList = new ArrayList<String>();
		
		Connection jdbcConn = null;
		Statement statement = null;
		ResultSet resultSet = null;
		JDBCConnectionProvider jDBCConnectionProvider = null;
		StringBuilder sql = new StringBuilder();

		sql.append("SELECT DISTINCT A.ROWID_PARTY ACCOUNT_ROWID, ADDR.COUNTRY_CD ACCOUNT_COUNTRY_CD FROM ");
		sql.append("(SELECT a.rowid_party_2, a.rowid_party, b.party_type, row_number() over(partition BY a.rowid_party_2 order by b.priority_party_type asc, a.last_update_date desc) rn ");
		sql.append("FROM (select distinct a.rowid_party, a.rowid_party_2, a.last_update_date from c_b_party_rel a, c_b_party_xref c ");
		sql.append("where a.ROWID_PARTY_2 = C.ROWID_OBJECT and c.pkey_src_object = ");
		sql.append("'" + contactPkey + "' ");
		sql.append("and a.rowid_hierarchy = 4 and a.hub_state_ind = 1) a, ");
		sql.append("(SELECT rowid_object,party_type, CASE WHEN party_type = 'Customer' THEN 1 WHEN party_type = 'Prospect Customer' THEN 2 ");
		sql.append("ELSE 3 END AS priority_party_type from C_B_PARTY where BO_CLASS_CODE = 'Organization' and HUB_STATE_IND = 1 and STATUS_CD = 'A' ");
		sql.append("and party_type in ('Customer','Prospect Customer') ) B WHERE A.ROWID_PARTY     = B.ROWID_OBJECT) A, C_B_ADDRESS ADDR ");
		sql.append("where a.ROWID_PARTY = ADDR.ROWID_PARTY and a.RN=1");
		

		LOG.debug("SQL for getExistingSBLAccountCountryCd()-->" + sql);

		try {
			jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
			jdbcConn = jDBCConnectionProvider.getJdbcConnectionFromDS();
			statement = jdbcConn.createStatement();
			resultSet = statement.executeQuery(sql.toString());

			while (resultSet.next()) {
				String str = resultSet.getString(1)+ "|" + resultSet.getString(2);
				acctRowidCountryCdList.add(str);
			}

		} catch (SQLException e) {
			LOG.info("Caught SQLException in getExistingSBLAccountCountryCd().");
		} finally {
			if (resultSet != null) resultSet.close();
			if (statement != null) statement.close();
			if (jdbcConn != null) jdbcConn.close();//jDBCConnectionProvider.closeJdbcConnection(jdbcConn);
		}
		LOG.debug("[getExistingSBLAccountCountryCd] EXIT");
		if(acctRowidCountryCdList != null && acctRowidCountryCdList.size()>0){
			for(String acctRowidCountryCd: acctRowidCountryCdList){
				LOG.debug("acctRowidCountryCd: "+ acctRowidCountryCd);
			}
		}

		
		return acctRowidCountryCdList;
	}
	
	/*Added for US449 START*/
	
	public boolean isCountryStateComboValid(String countryCd, String stateCd,boolean isContactSFCRec) {
		Boolean isValid = Boolean.TRUE;
		String sql = null;
		Integer recordCount = 0;
			try {
				LOG.info("[isCountryStateComboValid] START)");
				if(!isContactSFCRec){
				 sql = queryProp.getProperty(Constant.QUERY_CHECK_PROSPECT_COUNTRY_STATE);
				}
				else{
					 sql = queryProp.getProperty(Constant.QUERY_CHECK_SFDC_COUNTRY_STATE);
				}
				LOG.info("[isCountryStateComboValid]Query to check:" + sql);
				if(!isContactSFCRec){
				 recordCount = jdbcTemplate.queryForObject(sql, Integer.class, countryCd.trim().toUpperCase(), stateCd.trim().toUpperCase());
				}else{
					 recordCount = jdbcTemplate.queryForObject(sql, Integer.class, countryCd.trim().toUpperCase(), stateCd.trim());
				}
				
				isValid = (recordCount > 0);
				LOG.info("[isCountryStateComboValid] END");
			} catch(Exception e) {
				LOG.error("[isCountryStateComboValid] Error in execution", e);
			}
		return isValid;
	}
	
	public String getErrorCodeByDescription(String errorDesc) {
		String errorCd = null;
		if(!Util.isNullOrEmpty(errorDesc)) {
			try {
				LOG.info("[getErrorCodeByDescription] START)");
				String sql = queryProp.getProperty(Constant.QUERY_ERROR_CD_BY_ERROR_DESC);
				LOG.info("[getErrorCodeByDescription]Query to check:" + sql);
				errorCd = jdbcTemplate.queryForObject(sql, String.class, errorDesc);
				LOG.info("[getErrorCodeByDescription] END");
			} catch(Exception e) {
				LOG.error("[getErrorCodeByDescription] Error in execution", e);
			}
		}
		return errorCd;
	}
	
	/*Added for US449 END*/
	/**To Check if Surviving Contact Record Exists in PARTY_REL table for Account or not**/
	public Boolean checkifCntctRelationExists(String parentId, String childId) {
		LOG.debug("[checkifCntctRelationExists] START::parentId::" + parentId
				+ ", childId::" + childId);
		String sqlQuery = queryProp
				.getProperty(Constant.QUERY_CNTCT_RELATIONSHIP_EXISTS_SFC);
		Boolean accountRelExist = null;
		LOG.debug("[checkifCntctRelationExists] sqlQuery::" + sqlQuery);
		Integer dnbRowCount = jdbcTemplate.queryForObject(sqlQuery,
				Integer.class, parentId, childId);
		accountRelExist = (dnbRowCount > 0);
		LOG.debug("[checkifCntctRelationExists] EXIT::RelationshipRowCount::"
				+ accountRelExist);
		return accountRelExist;
	}
	@Transactional(rollbackFor = Exception.class)
	public void deleteJunkToken(String rowidObject) {
		LOG.debug("[deleteJunkToken] ENTER::rowidObject::"
				+ rowidObject);
		String sqlQuery = null;
		if (!Util.isNullOrEmpty(rowidObject)) {
			sqlQuery = Constant.QUERY_DELETE_JUNK_TOKEN;
			jdbcTemplate.update(sqlQuery,rowidObject);
		}
		LOG.debug("[deleteJunkToken] EXIT");
	}

}