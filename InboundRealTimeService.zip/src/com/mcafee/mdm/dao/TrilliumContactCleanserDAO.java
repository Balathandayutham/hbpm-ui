package com.mcafee.mdm.dao;

import java.io.StringWriter;
import java.net.URL;
import java.util.Properties;

import javax.annotation.Resource;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.namespace.QName;
import javax.xml.ws.BindingProvider;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.mcafee.mdm.generated.PartyXrefType;
import com.mcafee.mdm.util.Util;
import com.trillium.director.soap.CleanseUnicode;
import com.trillium.director.soap.ObjectFactory;
import com.trillium.director.soap.TrilliumDirectorSOAP;
import com.trillium.director.soap.TrilliumDirectorSOAPPortType;
import com.trillium.director.soap.xsd.TrilliumFieldValue;
import com.trillium.director.soap.xsd.TrilliumRecord;

/**
 * Used to call Trillium Cleanser functionality to cleanse and standardize Name and Address input attributes.
 * Cleanser web service exposed by Trillium Director project is consumed here. 
 *
 */
@Component
public class TrilliumContactCleanserDAO {
	private static final Logger LOG = Logger.getLogger(TrilliumContactCleanserDAO.class.getName());

	@Resource(name = "configProp")
	private Properties configProps;
	
	private QName qname = new QName("http://soap.director.trillium.com",
			"TrilliumDirectorSOAP");	

	//Trillium Call for Upsert Contact Method
	public boolean trilliumContactCleanser(PartyXrefType partyrequest) {
		
		LOG.info("Inside trilliumContactCleanser method()");
		boolean setTrilliumValue = Boolean.FALSE;

		try {
			callCleanseUnicode(partyrequest);
			setTrilliumValue = Boolean.TRUE;
		} catch (Exception ex) {
			LOG.error("Failed to cleanse data from Trillium: ", ex);
		}
		LOG.debug("Exit from trilliumContactCleanser()");
		return setTrilliumValue;
	}
	
	private void callCleanseUnicode(PartyXrefType partyrequest) throws JAXBException {
		
		LOG.debug("Inside callCleanseUnicode() method");
		
		String workPhone = null;
		int wrkPhnIndx = -1;
		String systemID = configProps.getProperty("trillium-contact-systemid");
		String trilURL = configProps.getProperty("trillium-ws.url");
		String responseTimeOut = configProps.getProperty("trillium-ws.timeout");
		
		LOG.debug("[callCleanseUnicode] systemID::" + systemID + "\ntrilURL Contact::" + trilURL + "\nResponse TimeOut::" + responseTimeOut);
		
		try {
		TrilliumDirectorSOAP service = new TrilliumDirectorSOAP(new URL(trilURL), qname);
		TrilliumDirectorSOAPPortType port = service
				.getTrilliumDirectorSOAPHttpSoap11Endpoint();
		
		if(!Util.isNullOrEmpty(responseTimeOut)) {
			((BindingProvider)port).getRequestContext().put("javax.xml.ws.client.receiveTimeout", responseTimeOut);
		}
		
		ObjectFactory requestObjectFactory = new ObjectFactory();
		com.trillium.director.soap.xsd.ObjectFactory xsdObjectFactory = new com.trillium.director.soap.xsd.ObjectFactory();
		CleanseUnicode request = requestObjectFactory.createCleanseUnicode();
		TrilliumRecord inputRecord = xsdObjectFactory.createTrilliumRecord();		
		for(int indx=0; indx < partyrequest.getCommunication().size(); indx++){
			//Setting WORK_PHONE_NUMBER //changed for MDMP-3310
			//if("Work_Phone".equalsIgnoreCase(partyrequest.getCommunication().get(indx).getCOMMTYPE()))	{
				if("Telephone".equalsIgnoreCase(partyrequest.getCommunication().get(indx).getCOMMTYPE()))	{
				workPhone = partyrequest.getCommunication().get(indx).getCOMMVALUE();//Getting WORK_PHONE_NUMBER
				wrkPhnIndx = indx;
			}
		}
		
		TrilliumFieldValue fieldValue = xsdObjectFactory
				.createTrilliumFieldValue();
		fieldValue.setTrilliumField(xsdObjectFactory
				.createTrilliumFieldValueTrilliumField("CONTACT_ID"));
		fieldValue.setTrilliumValue(xsdObjectFactory
				.createTrilliumFieldValueTrilliumValue(partyrequest.getXREF().get(0).getSRCPKEY()));//"1234";
		inputRecord.getTrilliumFieldValues().add(fieldValue);
		fieldValue = xsdObjectFactory.createTrilliumFieldValue();
		fieldValue.setTrilliumField(xsdObjectFactory
				.createTrilliumFieldValueTrilliumField("FIRST_NAME"));
		fieldValue.setTrilliumValue(xsdObjectFactory
				.createTrilliumFieldValueTrilliumValue(partyrequest.getPartyPerson().get(0).getFIRSTNAME()));//"May";
		inputRecord.getTrilliumFieldValues().add(fieldValue);
		fieldValue = xsdObjectFactory.createTrilliumFieldValue();
		fieldValue.setTrilliumField(xsdObjectFactory
				.createTrilliumFieldValueTrilliumField("MIDDLE_NAME"));
		fieldValue.setTrilliumValue(xsdObjectFactory
				.createTrilliumFieldValueTrilliumValue(partyrequest.getPartyPerson().get(0).getMIDDLENAME()));//"Jean"));
		fieldValue = xsdObjectFactory.createTrilliumFieldValue();
		inputRecord.getTrilliumFieldValues().add(fieldValue);
		fieldValue.setTrilliumField(xsdObjectFactory
				.createTrilliumFieldValueTrilliumField("LAST_NAME"));
		fieldValue.setTrilliumValue(xsdObjectFactory
				.createTrilliumFieldValueTrilliumValue(partyrequest.getPartyPerson().get(0).getLASTNAME()));//"Tyler"));
		fieldValue = xsdObjectFactory.createTrilliumFieldValue();
		inputRecord.getTrilliumFieldValues().add(fieldValue);
		fieldValue.setTrilliumField(xsdObjectFactory
				.createTrilliumFieldValueTrilliumField("JOB_TITLE"));
		fieldValue.setTrilliumValue(xsdObjectFactory
				.createTrilliumFieldValueTrilliumValue(partyrequest.getPartyPerson().get(0).getJOBTITLE()));//"CEO"));
		fieldValue = xsdObjectFactory.createTrilliumFieldValue();
		inputRecord.getTrilliumFieldValues().add(fieldValue);
		if(!Util.isNullOrEmpty(workPhone)){
			fieldValue.setTrilliumField(xsdObjectFactory
					.createTrilliumFieldValueTrilliumField("WORK_PHONE_NUMBER"));
			fieldValue.setTrilliumValue(xsdObjectFactory
					.createTrilliumFieldValueTrilliumValue(workPhone));//+97878584128244
		}
		fieldValue = xsdObjectFactory.createTrilliumFieldValue();
		inputRecord.getTrilliumFieldValues().add(fieldValue);
		fieldValue.setTrilliumField(xsdObjectFactory
				.createTrilliumFieldValueTrilliumField("COUNTRY"));
		fieldValue.setTrilliumValue(xsdObjectFactory
				.createTrilliumFieldValueTrilliumValue(partyrequest.getAddress().get(0).getCOUNTRYCD()));//"USA"));
		fieldValue = xsdObjectFactory.createTrilliumFieldValue();
		inputRecord.getTrilliumFieldValues().add(fieldValue);
		request.setInputRecord(requestObjectFactory
				.createCleanseUnicodeInputRecord(inputRecord));
		String outputField = "CONTACT_ID";
		request.getOutputFields().add(outputField);
		outputField = "DR_MRMRS";
		request.getOutputFields().add(outputField);
		outputField = "DR_FIRST_NAME";
		request.getOutputFields().add(outputField);
		outputField = "DR_MIDDLE_NAME";
		request.getOutputFields().add(outputField);
		outputField = "DR_LAST_NAME";
		request.getOutputFields().add(outputField);
		outputField = "JOB_TITLE";
		request.getOutputFields().add(outputField);
		outputField = "WORK_PHONE_NUMBER";
		request.getOutputFields().add(outputField);
		outputField = "COUNTRY";
		request.getOutputFields().add(outputField);
		outputField = "DR_COUNTRY_CODE";
		request.getOutputFields().add(outputField);
		outputField = "DR_COUNTRY_NAME";
		request.getOutputFields().add(outputField);
		request.setServerName(requestObjectFactory
				.createCleanseUnicodeServerName("Cleanser"));
		request.setSystemID(requestObjectFactory
				.createCleanseUnicodeSystemID(systemID));
		JAXBContext jaxbContext = JAXBContext.newInstance(CleanseUnicode.class);
		Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
		jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT,
				Boolean.TRUE);
		StringWriter strWriter = new StringWriter();
		jaxbMarshaller.marshal(request, strWriter);
		String msgTxt = strWriter.getBuffer().toString();
		LOG.debug("Request::\n" + msgTxt);
		TrilliumRecord response = port.cleanseUnicode(request.getSystemID()
				.getValue(), request.getServerName().getValue(), inputRecord,
				request.getOutputFields());
		LOG.debug("--------------OUTPUT----------------");
		for (TrilliumFieldValue respFieldValue : response
				.getTrilliumFieldValues()) {
			LOG.debug(respFieldValue.getTrilliumField().getValue()
					+ "::" + respFieldValue.getTrilliumValue().getValue());
			
		}
		
		if (CollectionUtils.isEmpty(response.getTrilliumFieldValues())) {
			LOG.debug("Empty Trillium Field Value in response");
		} else if (response.getTrilliumFieldValues().get(0) != null
				&& response.getTrilliumFieldValues().get(0).getTrilliumField() != null && "ECS_ERROR_CODE"
						.equalsIgnoreCase(response.getTrilliumFieldValues().get(0).getTrilliumField().getValue())) {
			LOG.debug("ERROR in Trillium Response::"
					+ response.getTrilliumFieldValues().get(0).getTrilliumField().getValue() + "::"
					+ response.getTrilliumFieldValues().get(0).getTrilliumValue().getValue() + ", "
					+ response.getTrilliumFieldValues().get(1).getTrilliumField().getValue() + "::"
					+ response.getTrilliumFieldValues().get(1).getTrilliumValue().getValue());
		} 
		//Changes for MDMP-3366
		/*else if((!Util.isNullOrEmpty(response.getTrilliumFieldValues().get(2).getTrilliumValue().getValue())  || 
				!Util.isNullOrEmpty(response.getTrilliumFieldValues().get(4).getTrilliumValue().getValue()))  
				&& !Util.isNullOrEmpty(response.getTrilliumFieldValues().get(7).getTrilliumValue().getValue()) )	{*/
		else if(!Util.isNullOrEmpty(response.getTrilliumFieldValues().get(2).getTrilliumValue().getValue())  || 
				!Util.isNullOrEmpty(response.getTrilliumFieldValues().get(4).getTrilliumValue().getValue()) )	{
			LOG.debug("-------------AFTER SETTING CLEANSED VALUES--------------- ");
			//Setting CONTACT_ID
			partyrequest.getXREF().get(0).setSRCPKEY(response.getTrilliumFieldValues().get(0).getTrilliumValue().getValue());//Setting CONTACT_ID
			LOG.debug("CONTACT_ID: "+partyrequest.getXREF().get(0).getSRCPKEY());
			//Setting DR_FIRST_NAME
			partyrequest.getPartyPerson().get(0).setFIRSTNAME(response.getTrilliumFieldValues().get(2).getTrilliumValue().getValue());//Setting DR_FIRST_NAME
			LOG.debug("DR_FIRST_NAME: "+partyrequest.getPartyPerson().get(0).getFIRSTNAME());
			//Setting DR_MIDDLE_NAME
			partyrequest.getPartyPerson().get(0).setMIDDLENAME(response.getTrilliumFieldValues().get(3).getTrilliumValue().getValue());//Setting DR_MIDDLE_NAME
			LOG.debug("DR_MIDDLE_NAME: "+partyrequest.getPartyPerson().get(0).getMIDDLENAME());
			//Setting DR_LAST_NAME
			partyrequest.getPartyPerson().get(0).setLASTNAME(response.getTrilliumFieldValues().get(4).getTrilliumValue().getValue());//Setting DR_LAST_NAME
			LOG.debug("DR_LAST_NAME: "+partyrequest.getPartyPerson().get(0).getLASTNAME());
			//Setting PARTY_NAME to DR_FIRST_NAME + ' ' + DR_LAST_NAME
			partyrequest.setPARTYNAME(partyrequest.getPartyPerson().get(0).getFIRSTNAME() + " " + partyrequest.getPartyPerson().get(0).getLASTNAME());
			LOG.debug("PARTY NAME: "+ partyrequest.getPartyPerson().get(0).getFIRSTNAME() + " " + partyrequest.getPartyPerson().get(0).getLASTNAME());
			//Setting JOB_TITLE
			partyrequest.getPartyPerson().get(0).setJOBTITLE(response.getTrilliumFieldValues().get(5).getTrilliumValue().getValue());//Setting JOB_TITLE
			LOG.debug("JOB_TITLE: "+partyrequest.getPartyPerson().get(0).getJOBTITLE());
			
			//Setting WORK_PHONE_NUMBER	
			if(wrkPhnIndx != -1){
				LOG.debug("WORK_PHONE_NUMBER index is: "+ wrkPhnIndx);
				partyrequest.getCommunication().get(wrkPhnIndx).setCOMMVALUE(response.getTrilliumFieldValues().get(6).getTrilliumValue().getValue());//Setting WORK_PHONE_NUMBER
				LOG.debug("WORK_PHONE_NUMBER: "+partyrequest.getCommunication().get(wrkPhnIndx).getCOMMVALUE());
			}
						
			//Setting COUNTRY
			if (!Util.isNullOrEmpty(response.getTrilliumFieldValues().get(7).getTrilliumValue().getValue())){
			partyrequest.getAddress().get(0).setCOUNTRYCD(response.getTrilliumFieldValues().get(7).getTrilliumValue().getValue());
			LOG.debug("COUNTRY: "+partyrequest.getAddress().get(0).getCOUNTRYCD());
			}
		}
		
		
		} catch (Exception ex) {
			LOG.error("Caught exception inside callCleanseUnicode: ", ex);
		}
		LOG.debug("Finished callCleanseUnicode() method");
	}
}
