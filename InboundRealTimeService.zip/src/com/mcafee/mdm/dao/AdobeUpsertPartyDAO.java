package com.mcafee.mdm.dao;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;

import javax.annotation.Resource;
import javax.transaction.SystemException;
import javax.transaction.UserTransaction;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.mcafee.mdm.constants.AccountAttributes;
import com.mcafee.mdm.constants.AddressAttributes;
import com.mcafee.mdm.constants.CommunicationAttributes;
import com.mcafee.mdm.constants.Constant;
import com.mcafee.mdm.constants.MDMAttributeNames;
import com.mcafee.mdm.constants.PartyAttributes;
import com.mcafee.mdm.constants.ProspectAttributes;
import com.mcafee.mdm.dao.pojo.AcntCntctRelData;
import com.mcafee.mdm.dao.pojo.CntctPkeyRowIdRelData;
import com.mcafee.mdm.dao.pojo.PartyChildRowIdData;
import com.mcafee.mdm.dao.pojo.PutResponseDataHolder;
import com.mcafee.mdm.exception.ServiceProcessingException;
import com.mcafee.mdm.generated.Account;
import com.mcafee.mdm.generated.AccountType;
import com.mcafee.mdm.generated.AccountXrefType;
import com.mcafee.mdm.generated.Address;
import com.mcafee.mdm.generated.AddressType;
import com.mcafee.mdm.generated.AddressXrefType;
import com.mcafee.mdm.generated.Classification;
import com.mcafee.mdm.generated.ClassificationType;
import com.mcafee.mdm.generated.Communication;
import com.mcafee.mdm.generated.CommunicationType;
import com.mcafee.mdm.generated.CommunicationXrefType;
import com.mcafee.mdm.generated.MdmUpsertPartyRequest;
import com.mcafee.mdm.generated.MdmUpsertPartyResponse;
import com.mcafee.mdm.generated.PartyAccountRelationshipType;
import com.mcafee.mdm.generated.PartyContactRelationshipXrefType;
import com.mcafee.mdm.generated.PartyOrgExt;
import com.mcafee.mdm.generated.PartyOrgExtType;
import com.mcafee.mdm.generated.PartyRel;
import com.mcafee.mdm.generated.PartyType;
import com.mcafee.mdm.generated.PartyUpsertRespType;
import com.mcafee.mdm.generated.PartyXrefType;
import com.mcafee.mdm.generated.StatusType;
import com.mcafee.mdm.generated.XREFCopy;
import com.mcafee.mdm.generated.XREFType;
import com.mcafee.mdm.util.CommonUtil;
import com.mcafee.mdm.util.JDBCConnectionProvider;
import com.mcafee.mdm.util.ObjectPool;
import com.mcafee.mdm.util.PerformanceLoggerUtil;
import com.mcafee.mdm.util.PropertyUtil;
import com.mcafee.mdm.util.Util;
import com.mcafee.mdm.util.ValidatorUtil;
import com.siperian.sif.client.EjbSiperianClient;
import com.siperian.sif.client.SiperianClient;
import com.siperian.sif.client.SiperianServerException;
import com.siperian.sif.message.Field;
import com.siperian.sif.message.Record;
import com.siperian.sif.message.RecordKey;
import com.siperian.sif.message.RecordState;
import com.siperian.sif.message.SiperianObjectType;
import com.siperian.sif.message.TaskData;
import com.siperian.sif.message.TaskRecord;
import com.siperian.sif.message.mrm.CleansePutRequest;
import com.siperian.sif.message.mrm.CleansePutResponse;
import com.siperian.sif.message.mrm.CreateTaskRequest;
import com.siperian.sif.message.mrm.CreateTaskResponse;
import com.siperian.sif.message.mrm.GetRequest;
import com.siperian.sif.message.mrm.GetResponse;
import com.siperian.sif.message.mrm.MultiMergeRequest;
import com.siperian.sif.message.mrm.MultiMergeResponse;
import com.siperian.sif.message.mrm.PutRequest;
import com.siperian.sif.message.mrm.PutResponse;
import com.siperian.sif.message.mrm.SetRecordStateRequest;
import com.siperian.sif.message.mrm.SetRecordStateResponse;
import com.siperian.sif.message.mrm.TokenizeRequest;
import com.siperian.sif.message.mrm.TokenizeResponse;
import com.siperian.sif.message.mrm.UnmergeResponse;

@Component
@Scope("prototype")
public class AdobeUpsertPartyDAO extends ObjectPool {

	private static final Logger LOG = Logger.getLogger(AdobeUpsertPartyDAO.class);

	@Autowired
	private ProspectPartyDAO prospectPartyDAO;
	@Resource(name = "m4mMessagesProp")
	private Properties messagesProp;
	@Autowired
	private ValidatorUtil validatorUtil;
	@Autowired
	private GetPartyDAO getPartyDAO;
	@Autowired
	private DeleteProspectPartyDAO deleteProspectPartyDAO;
	@Autowired
	private SearchProspectPartyDAO searchProspectDao;
	@Autowired
	private MergeProspectPartyDAO mergeProspectPartyDAO;
	@Autowired
	private GetMarketingPartyDAO getMarketingPartyDAO;
	@Autowired
	private TrilliumCleanserDAO trilliumCleanserDAO;
	@Autowired
	private TrilliumLookUpDAO trilliumLookUpDAO;
	@Autowired
	private SearchPartyDAO searchPartyDAO;

	@Autowired
	private GenericDAO genericDAO;

	@Autowired
	private CommonUtil commonUtil;

	boolean childMergeInd = false;
	boolean selfMatchFail = false;
	boolean isAccountAssociatedWithCustomerOrDNB = false;
	boolean dnbProcpect = false;
	Properties configProps = PropertyUtil.getPropertiesFromFile("configProp");
	int partyCount = 0;
	Date lastUpdateDate = null;
	Map<String, Object> dataHolderMap = new HashMap<String, Object>();
	StringBuilder warning = new StringBuilder();
	
	public MdmUpsertPartyResponse processUpsertPartyRequest(MdmUpsertPartyRequest upsertPartyRequest)
			throws ServiceProcessingException {
		LOG.info("Executing processUpsertPartyRequest()");
		MdmUpsertPartyResponse upsertPartyResponse = new MdmUpsertPartyResponse();
		String methodName = null;
		int sizeInputParty = upsertPartyRequest.getParty().size();
		for (int index = 0; index < sizeInputParty; index++) {
			try {
				upsertPartyResponse.setUpsertStatus(new StatusType());
				PartyXrefType upsertParty = upsertPartyRequest.getParty().get(index);

				validatorUtil.validateMsgTrackingId(upsertParty, upsertPartyResponse,false);
				if (upsertPartyRequest.getUpsertStatus() != null
						&& (upsertPartyRequest.getUpsertStatus().getErrorCode() != null)) {
					if(upsertPartyRequest.getUpsertStatus().getErrorCode().equals(Constant.ERROR_ACC_MERGE_FAIL)){
						upsertPartyRequest.getUpsertStatus().setErrorCode(Constant.ERROR_ACC_EXT_ACC_PUT_FAIL);
					}
					methodName = configProps.getProperty(upsertPartyRequest.getUpsertStatus().getErrorCode() + "_API");
					LOG.info("Retry method : " + methodName);
				}
				LOG.info("Executing method");
				StatusType status = new StatusType();
				upsertPartyResponse.setUpsertStatus(status);

				String srcPkey = upsertParty.getXREF().get(0).getSRCPKEY();
				srcPkey = Constant.ADB_ACT_PREFIX+srcPkey;
				upsertParty.getXREF().remove(0);
				XREFType xrefType = new XREFType();
				xrefType.setSRCPKEY(srcPkey);
				xrefType.setSRCSYSTEM(Constant.SRC_SYSTEM_ADB);
				upsertParty.getXREF().add(xrefType);
				
				if(!CollectionUtils.isEmpty(upsertParty.getAccount()) && upsertParty.getAccount().size()>0){
					upsertParty.getAccount().get(0).setSRCPKEY(srcPkey);
				}
				if(!CollectionUtils.isEmpty(upsertParty.getAddress()) && upsertParty.getAddress().size()>0){
					upsertParty.getAddress().get(0).setSRCPKEY(srcPkey);
				}
				if(!CollectionUtils.isEmpty(upsertParty.getCommunication()) && upsertParty.getCommunication().size()>0){
					for(int i = 0; i<upsertParty.getCommunication().size();i++){
						upsertParty.getCommunication().get(i).setSRCPKEY(srcPkey);
					}
				}
				if(upsertParty.getPartyRel()!=null){
					if(!CollectionUtils.isEmpty(upsertParty.getPartyRel().getPARTYPERSONREL()) && upsertParty.getPartyRel().getPARTYPERSONREL().size()>0){
						for(int i = 0; i<upsertParty.getPartyRel().getPARTYPERSONREL().size();i++){
							String contactPkey = upsertParty.getPartyRel().getPARTYPERSONREL().get(i).getSRCPKEY();
							upsertParty.getPartyRel().getPARTYPERSONREL().get(i).setSRCPKEY(Constant.ADB_CNT_PREFIX+contactPkey);
						}
					}
					
				}
				
				
				processUpsertRequestForIndividualParty(methodName, upsertParty, upsertPartyResponse);
			} catch (ServiceProcessingException servexp) {
				LOG.error("Caught ServiceProcessingException in processUpsertPartyRequest()", servexp);

			} catch (Exception exp) {
				LOG.error("Caught exception in processUpsertPartyRequest()", exp);
			}
		}
		upsertPartyResponse.setStatus(upsertPartyResponse.getStatus() == null ? ""
				: upsertPartyResponse.getStatus() + "\n Processing completed for " + partyCount + " party(ies).");

		return upsertPartyResponse;
	}

	public void processUpsertRequestForIndividualParty(String methodName, PartyXrefType upsertParty,
			MdmUpsertPartyResponse upsertPartyResponse)
			throws ServiceProcessingException, SecurityException, ClassNotFoundException {

		LOG.info("Executing processUpsertRequestForIndividualParty()");

		String rowidObject = null;
		boolean retry = false;
		boolean execNext = false;

		if (!Util.isNullOrEmpty(methodName)) {
			partyCount = 1;
			retry = true;
			execNext = true;
			try {
				LOG.info("Before reflection Method name : " + methodName.trim());
				Class<? extends AdobeUpsertPartyDAO> cls = this.getClass();
				LOG.info("Class : " + cls.toString());

				Method method = cls.getMethod(new String(methodName.trim()), new Class[] { PartyXrefType.class,
						MdmUpsertPartyResponse.class, boolean.class, boolean.class, String.class });
				LOG.info("After get Method : " + method.toString());
				Object[] args = new Object[5];
				args[0] = upsertParty;
				args[1] = upsertPartyResponse;
				args[2] = retry;
				args[3] = execNext;
				args[4] = rowidObject;
				LOG.info("Before invoke");
				method.invoke(this, args);
				LOG.info("After Invoke");
			} catch (NoSuchMethodException e) {
				LOG.error(e);
				throw new ServiceProcessingException(e);
			} catch (IllegalAccessException e) {
				LOG.error(e);
				throw new ServiceProcessingException(e);
			} catch (IllegalArgumentException e) {
				LOG.error(e);
				throw new ServiceProcessingException(e);
			} catch (InvocationTargetException e) {
				LOG.error(e);
				throw new ServiceProcessingException(e);
			}
		} else {
			retry = false;
			execNext = false;
			
			List<String> rowIdList = new ArrayList<String>();
			rowIdList = checkForUpdate(upsertParty);
			// both reject cases
			if (rowIdList.size() > 0) {
				isAccountAssociatedWithCustomerOrDNB = true;
				dnbProcpect = true;
				String existingRowId = rowIdList.get(0);
				upsertParty.setROWIDOBJECT(existingRowId);
			}else{
			
			upsertDataValidation(upsertParty, upsertPartyResponse, false, false, rowidObject);

			upsertTrilliumProcessing(upsertParty, upsertPartyResponse, false, false, rowidObject);

			genericDAO.callIsDeniedPartyService(upsertParty);

			// Check for data quality in Adobe input
			checkDataQualityUpsert(upsertParty, upsertPartyResponse, false, false, rowidObject);

			processCleansePutRequest(upsertParty, upsertPartyResponse, false, false, rowidObject);
			
			upsertUCNStampProcess(upsertParty, upsertPartyResponse, false, false, rowidObject);
			
			processAcntCntctRel(upsertParty, upsertPartyResponse, false, false, rowidObject);
			}
		}

		populateUpsertResponse(upsertParty, upsertPartyResponse);

		LOG.info("Executed processUpsertRequestForIndividualParty()");

	}

	// validate PartyType and BO_CLASS_CODE
	public void upsertDataValidation(PartyXrefType upsertParty, MdmUpsertPartyResponse upsertPartyResponse,
			boolean excuteNextStep, boolean executeFromStart, String rowidObject) throws ServiceProcessingException {

		LOG.info("Executing upsertDataValidation()");

		// Check for Account Record Type
		try {
			// Check if BO_CLASS_CODE == 'Organization'
			if (((!Util.isNullOrEmpty(upsertParty.getBOCLASSCODE()))
					&& upsertParty.getBOCLASSCODE().equalsIgnoreCase(Constant.BO_CLASS_CODE_ORG))) {
				LOG.info("Valid BO CLASS CODE ");
				
				//(MDMP-3355) Enable Japan contact in MDM from Adobe
				//Adobe Account - Japanese records should not be processed
			/*	List<AddressXrefType> addressXrefTypeList = upsertParty.getAddress();
				if (!CollectionUtils.isEmpty(addressXrefTypeList)) {
					String countryCd = addressXrefTypeList.get(0).getCOUNTRYCD();
					if ("Japan".equalsIgnoreCase(countryCd) || "JPN".equalsIgnoreCase(countryCd)
							|| "JP".equalsIgnoreCase(countryCd)) {
						LOG.info("Account is from Japan");
						upsertPartyResponse.setStatus("Account is from Japan");
						upsertPartyResponse.setErrorMsg("Account is from Japan");
						throw new ServiceProcessingException(Constant.ERROR_ACCOUNT_JP_COUNTRY_FAILED);
						
					}
				}*/
				
				// Check if PARTY_TYPE == Prospect_Customer
				if ((!Util.isNullOrEmpty(upsertParty.getPARTYTYPE()))
						&& (upsertParty.getPARTYTYPE().equalsIgnoreCase(Constant.PARTY_TYPE_PROSPECT_ACCOUNT)
								|| upsertParty.getPARTYTYPE().equalsIgnoreCase(Constant.PARTY_TYPE_CUSTOMER))) {
					LOG.info("Valid PartyType ");
					// Check if Adobe account is not empty
					String srcPkey = upsertParty.getXREF().get(0).getSRCPKEY();
					if (Util.isNullOrEmpty(srcPkey)) {
						LOG.info("Adobe account id is null or empty");
						validatorUtil.createUpsertInfoMessage(upsertPartyResponse, Constant.INFO_ACCOUNT_EMPTY_PKEY, null);
						upsertPartyResponse.setErrorCd(prospectPartyDAO
								.getErrorCodeByDescription(messagesProp.getProperty(Constant.INFO_ACCOUNT_EMPTY_PKEY)));
						throw new ServiceProcessingException(Constant.ERROR_ACCOUNT_DATA_VALID_FAIL);
					}
				} else {
					LOG.info("Account is not created since it's PARTY_TYPE is not in ('Prospect Customer','Customer')");
					upsertPartyResponse
							.setStatus("Account blocking successful for invalid PARTY_TYPE. Account with PARTY_TYPE = '"
									+ upsertParty.getPARTYTYPE() + "' not created in MDM");
					upsertPartyResponse.setErrorMsg(
							"Account blocking successful for invalid PARTY_TYPE. Account with PARTY_TYPE = '"
									+ upsertParty.getPARTYTYPE() + "' not created in MDM");
					throw new ServiceProcessingException(Constant.ERROR_ACCOUNT_INVALID_PTY_TYP);
				}

			} else {
				LOG.info("Account is not created since it's BO_CLASS_CODE != 'Organization'");
				upsertPartyResponse.setStatus(
						"Account blocking successful for invalid BO_CLASS_CODE. Account with BO_CLASS_CODE = '"
								+ upsertParty.getBOCLASSCODE() + "' not created in MDM");
				upsertPartyResponse.setErrorMsg(
						"Account blocking successful for invalid BO_CLASS_CODE. Account with BO_CLASS_CODE = '"
								+ upsertParty.getBOCLASSCODE() + "' not created in MDM");
				throw new ServiceProcessingException(Constant.ERROR_ACCOUNT_WRONG_ORG);

			}

		} catch (ServiceProcessingException e) {
			LOG.error("Data validation check failed Due to Invalid Input: " + e.getMessage());
			if (Constant.ERROR_ACCOUNT_INVALID_PTY_TYP.equals(e.getMessage())) {
				commonUtil.updateErrorStatus(upsertParty, upsertPartyResponse, Constant.ERROR_ACCOUNT_INVALID_PTY_TYP,
						"0");
			} else if (Constant.ERROR_ACCOUNT_WRONG_ORG.equals(e.getMessage())) {
				commonUtil.updateErrorStatus(upsertParty, upsertPartyResponse, Constant.ERROR_ACCOUNT_WRONG_ORG, "0");
			} else if (Constant.ERROR_ACCOUNT_JP_COUNTRY_FAILED.equals(e.getMessage())) {
				commonUtil.updateErrorStatus(upsertParty, upsertPartyResponse, Constant.ERROR_ACCOUNT_JP_COUNTRY_FAILED,
						"0");
			} else {
				commonUtil.updateErrorStatus(upsertParty, upsertPartyResponse, Constant.ERROR_ACCOUNT_DATA_VALID_FAIL,
						"0");
			}
			throw new ServiceProcessingException(e);
		} catch (Exception excp) {
			LOG.error("Data validation check failed: " + excp.getMessage());

			upsertPartyResponse.setErrorMsg("Data validation check failed Due to Error: " + excp.getMessage());

			commonUtil.updateErrorStatus(upsertParty, upsertPartyResponse, Constant.ERROR_ACCOUNT_DATA_VALID_FAIL, "0");
			throw new ServiceProcessingException(Constant.ERROR_ACCOUNT_DATA_VALID_FAIL);
		}

		// Execute next step in upsert flow
		String rowidObj = null;
		if (excuteNextStep)
			upsertTrilliumProcessing(upsertParty, upsertPartyResponse, true, true, rowidObj);

		LOG.info("Executed upsertDataValidation()");
		return;
	}

	public void upsertTrilliumProcessing(PartyXrefType upsertParty, MdmUpsertPartyResponse upsertPartyResponse,
			boolean excuteNextStep, boolean executeFromStart, String rowidObject) throws ServiceProcessingException {
		boolean isInTrilliumList = false;
		boolean setTrilliumValue = false;
		String mdmStateCountryArr[] = new String[10];
		PerformanceLoggerUtil perfLog = new PerformanceLoggerUtil();
		String pkey = upsertParty.getXREF().get(0).getSRCPKEY();
		if (pkey == null) {
			pkey = "";
		}

			try {
				/*if (!(CollectionUtils.isEmpty(upsertParty.getAddress()) || upsertParty.getAddress().get(0) == null
						|| Util.isNullOrEmpty(upsertParty.getAddress().get(0).getCOUNTRYCD())
						|| Util.isNullOrEmpty(upsertParty.getAddress().get(0).getSTATECD()))) {
					if (!prospectPartyDAO.isCountryStateComboValid(upsertParty.getAddress().get(0).getCOUNTRYCD(),
							upsertParty.getAddress().get(0).getSTATECD(), false)) {
						String respMsg = messagesProp.getProperty(Constant.INFO_COUNTRY_STATE_MISMATCH);
						upsertPartyResponse.setStatus("Processing completed for 0 Party(ies).\n" + respMsg
								+ Constant.STR_SPACE + upsertParty.getAddress().get(0).getCOUNTRYCD() + "-"
								+ upsertParty.getAddress().get(0).getSTATECD());
						upsertPartyResponse.setErrorCd(prospectPartyDAO.getErrorCodeByDescription(respMsg));
						throw new ServiceProcessingException(Constant.ERROR_ACCOUNT_DQ_CHECK_FAIL);
					}
				}*/

				// Trillium Cleansing for Prospect
				isInTrilliumList = trilliumLookUpDAO.checkInTrilliumCountryProjectMapForProspect(upsertParty,Constant.SRC_SYSTEM_ADB);
				LOG.debug("isInTrilliumList::" + isInTrilliumList);
				// Before Trillium LookUP Process
				trilliumLookUpDAO.convertToTrilliumUpsert(upsertParty, isInTrilliumList, Constant.SRC_SYSTEM_ADB);

				if (isInTrilliumList) {
					LOG.info("Going For TRILLIUM Procedure");
					// call Trillium Cleanser service to cleanseName and Address
					// attributes in request
					LOG.info("Trillium Call is being made.");

					setTrilliumValue = trilliumCleanserDAO.callTrilliumCleanser(upsertParty, Boolean.FALSE);
					perfLog.printLog(Constant.PERF_LOG_FLOW_UPSERT_ADB_PROSPECT_ACCOUNT, pkey, "STEP 1",
							"Trillium Call done");

					// After Trillium LookUP Process
					trilliumLookUpDAO.convertTrilliumToSRCStateProspect(setTrilliumValue, upsertParty,
							upsertParty.getXREF().get(0).getSRCSYSTEM());
					mdmStateCountryArr = trilliumLookUpDAO.convertSRCToMDMDataUpsert(upsertParty,upsertParty.getXREF().get(0).getSRCSYSTEM());
					if (!Util.isNullOrEmpty(upsertParty.getAddress().get(0).getSTATECD()) && Util.isNullOrEmpty(mdmStateCountryArr[0])) {
						upsertParty.getAddress().get(0).setSTATECD("");
					}
					perfLog.printLog(Constant.PERF_LOG_FLOW_UPSERT_ADB_PROSPECT_ACCOUNT, pkey, "STEP 2",
							"Transformation after trillium call to source state and country value");
				} else {
					mdmStateCountryArr = trilliumLookUpDAO.convertSRCToMDMDataUpsert(upsertParty,upsertParty.getXREF().get(0).getSRCSYSTEM());
					if (!Util.isNullOrEmpty(upsertParty.getAddress().get(0).getSTATECD()) && Util.isNullOrEmpty(mdmStateCountryArr[0])) {
						upsertParty.getAddress().get(0).setSTATECD("");
					}
					perfLog.printLog(Constant.PERF_LOG_FLOW_UPSERT_ADB_PROSPECT_ACCOUNT, pkey, "STEP 1-2",
							"Trillium Call skipped");
				}

			} catch (ServiceProcessingException e) {
				LOG.error("Trillium Cleanse failed Due to Invalid name identifier: " + e.getMessage());
				if (Constant.ERROR_ACCOUNT_INVALID_TRL_NM_IND.equals(e.getMessage())) {
					commonUtil.updateErrorStatus(upsertParty, upsertPartyResponse,
							Constant.ERROR_ACCOUNT_INVALID_TRL_NM_IND, "0");
				} else {
					commonUtil.updateErrorStatus(upsertParty, upsertPartyResponse, Constant.ERROR_ACCOUNT_DQ_CHECK_FAIL,
							"0");
				}

				try {
					// Convert from Adobe to Trillium format
					trilliumLookUpDAO.convertToTrilliumUpsert(upsertParty, Boolean.FALSE, Constant.SRC_SYSTEM_ADB);
				} catch (Exception ex) {
					LOG.error("convertToTrilliumUpsert failed after Trillim cleanse failure:: ", ex);
				}
				throw new ServiceProcessingException(e);
			} catch (Exception excp) {
				LOG.error("Trillim cleanse failed: " + excp.getMessage());
				upsertPartyResponse.setErrorMsg("Trillim cleanse failed: " + excp.getMessage());
				commonUtil.updateErrorStatus(upsertParty, upsertPartyResponse, Constant.ERROR_ACCOUNT_DQ_CHECK_FAIL,
						"0");
				try {
					// Convert from Adobe to Trillium format
					trilliumLookUpDAO.convertToTrilliumUpsert(upsertParty, Boolean.FALSE, Constant.SRC_SYSTEM_ADB);
				} catch (Exception e) {
					LOG.error("convertToTrilliumUpsert failed after Trillim cleanse failure:: ", e);
				}
				throw new ServiceProcessingException(Constant.ERROR_ACCOUNT_DQ_CHECK_FAIL);
			}
		
		// Execute next step in upsert flow
		String rowidObj = null;
		if (excuteNextStep)
			checkDataQualityUpsert(upsertParty, upsertPartyResponse, true, true, rowidObj);

		LOG.info("Executed upsertTrilliumProcessing()");

		return;

	}

	private void processCleansePut(PartyXrefType upsertParty, MdmUpsertPartyResponse upsertPartyResponse,
			boolean isCustomer) throws ServiceProcessingException {
		LOG.info("Executing processCleansePutRequest()");

		SiperianClient siperianClient = null;
		UserTransaction transaction = null;

		PartyXrefType partyParam = upsertParty;
		PutResponseDataHolder putRespDataParty = null;
		List<PutResponseDataHolder> putRespDataProspectOrAccountList = null;
		List<PutResponseDataHolder> putRespDataAddressList = null;
		List<PutResponseDataHolder> putRespDataCommunicationList = null;
		// Map<String, Object> dataHolderMap = new HashMap<String, Object>();

		try {
			siperianClient = (SiperianClient) checkOut();

			// create transaction - commit if cleansePut requests succeed for
			// Party and all the child entities
			transaction = ((EjbSiperianClient) siperianClient).createTX(300000);
			transaction.begin();

			lastUpdateDate = Util.getCurrentTimeZone();

			// Create Party
			putRespDataParty = cleansePutParty(partyParam, siperianClient,isCustomer);
			
			if (!isCustomer) {
				putRespDataProspectOrAccountList = cleansePutProspectCustomer(partyParam,
						siperianClient);
			}

			// Create Prospect or Account
			List<AccountXrefType> prospectOrAccountXrefTypeList = partyParam.getAccount();
			if (!CollectionUtils.isEmpty(prospectOrAccountXrefTypeList)) {

				if (isCustomer) {
				/*	putRespDataProspectOrAccountList = cleansePutProspectCustomer(partyParam,
							siperianClient);
				} else {*/
					putRespDataProspectOrAccountList = cleansePutAccount(prospectOrAccountXrefTypeList, partyParam,
					siperianClient);
				}
			}

			// Create Address
			List<AddressXrefType> addressXrefTypeList = partyParam.getAddress();
			if (!CollectionUtils.isEmpty(addressXrefTypeList)) {
				putRespDataAddressList = cleansePutAddress(addressXrefTypeList, partyParam, siperianClient,isCustomer);
			}

			// Create Communication
			List<CommunicationXrefType> commXrefTypeList = partyParam.getCommunication();
			if (!CollectionUtils.isEmpty(commXrefTypeList) && commXrefTypeList!=null) {
				putRespDataCommunicationList = cleansePutCommunication(commXrefTypeList, partyParam, siperianClient);
			}

			LOG.info("Control back in processCleansePut().");

			// commit transaction
			transaction.commit();
			LOG.info("Transaction Commited in processCleansePut().");
			partyCount++;

			// set response status
			upsertPartyResponse.setStatus(
					Util.isNullOrEmpty(upsertPartyResponse.getStatus()) ? "" : upsertPartyResponse.getStatus() + "\n");
			upsertPartyResponse.setStatus(upsertPartyResponse.getStatus() + putRespDataParty.getActionType()
					+ " operation successful for Party " + putRespDataParty.getSourceKey().replaceAll(Constant.ADB_ACT_PREFIX, Constant.STR_BLANK));

		} catch (ServiceProcessingException excp) {
			boolean isDataError = commonUtil.fetchErrorMsg(excp.getRootExceptionMsg());
			upsertPartyResponse.setErrorMsg(excp.getRootExceptionMsg());
			upsertPartyResponse.setStatus(excp.getRootExceptionMsg());
			upsertParty.setErrorMsg("CleansePut operation failed");
			if(isDataError){
				commonUtil.updateErrorStatus(upsertParty, upsertPartyResponse, Constant.ERROR_LOV_LOOKUP_FAILED, "0");
			}else{
				commonUtil.updateErrorStatus(upsertParty, upsertPartyResponse, Constant.ERROR_ACC_EXT_ACC_PUT_FAIL, "0");	
			}
			LOG.error("Exception occured while preparing/processing cleansePut requests: ", excp);
			try {
				transaction.rollback();

			} catch (SystemException txExcp) {
				LOG.error("Failed to rollback transaction for cleansePut requests : " + txExcp.toString());
			}
			throw excp;
		} catch (Exception ex) {
			upsertPartyResponse.setErrorMsg("CleansePut operation failed for Party " + putRespDataParty.getSourceKey().replaceAll(Constant.ADB_ACT_PREFIX, Constant.STR_BLANK));
			upsertParty.setErrorMsg("CleansePut operation failed");
			commonUtil.updateErrorStatus(upsertParty, upsertPartyResponse, Constant.ERROR_ACC_EXT_ACC_PUT_FAIL, "0");
			LOG.error("Exception occured while preparing/processing cleansePut requests: ", ex);
			ex.printStackTrace();
			try {
				transaction.rollback();
			} catch (SystemException txExcp) {
				LOG.error("Failed to rollback transaction for cleansePut requests : " + txExcp.toString());
				txExcp.printStackTrace();
			}
			ServiceProcessingException customException = new ServiceProcessingException(ex);
			customException.setMessage("Failed to process cleansePut SIF request." + customException.getMessage());
			// customException.printStackTrace();
			throw customException;
		} finally {
			checkIn(siperianClient);
		}
		try {
			// set rowid_object of created records into response and
			// set the PutResponseDataHolder object/list of object into Map
			// against corresponding entity name
			// set rowid_object of Party into response
			PartyUpsertRespType partyUpsertResp = new PartyUpsertRespType();
			List<Account> prospectList = new ArrayList<Account>();
			List<Address> addressList = new ArrayList<Address>();
			List<Communication> commList = new ArrayList<Communication>();

			// set rowid_object of Party into response
			if (putRespDataParty != null) {
				partyUpsertResp.setROWIDOBJECT(putRespDataParty.getRowidObject());
				partyUpsertResp.setSRCSYSTEM(putRespDataParty.getSystemName());
				partyUpsertResp.setSRCSYSTEMID(putRespDataParty.getSourceKey().replaceAll(Constant.ADB_ACT_PREFIX, Constant.STR_BLANK));
				dataHolderMap.put(MDMAttributeNames.ENTITY_PARTY, putRespDataParty);
			}

			// set rowid_object of Prospect into response
			if (!CollectionUtils.isEmpty(putRespDataProspectOrAccountList)) {
				if (isCustomer) {
					dataHolderMap.put(MDMAttributeNames.ENTITY_ACCOUNT, putRespDataProspectOrAccountList);
				} else {
					dataHolderMap.put(MDMAttributeNames.ENTITY_PROSPECT, putRespDataProspectOrAccountList);
				}
				for (PutResponseDataHolder putRespDataProspect : putRespDataProspectOrAccountList) {
					Account prospect = new Account();
					prospect.setROWIDACCOUNT(putRespDataProspect.getRowidObject());
					prospect.setSRCSYSTEM(putRespDataProspect.getSystemName());
					prospect.setSRCSYSTEMID(putRespDataProspect.getSourceKey().replaceAll(Constant.ADB_ACT_PREFIX, Constant.STR_BLANK));
					prospectList.add(prospect);
				}
			}

			// set rowid_object of Address into response
			if (!CollectionUtils.isEmpty(putRespDataAddressList)) {
				dataHolderMap.put(MDMAttributeNames.ENTITY_ADDRESS, putRespDataAddressList);
				for (PutResponseDataHolder putRespDataAddress : putRespDataAddressList) {
					Address address = new Address();
					address.setROWIDADDRESS(putRespDataAddress.getRowidObject());
					address.setSRCSYSTEM(putRespDataAddress.getSystemName());
					address.setSRCSYSTEMID(putRespDataAddress.getSourceKey().replaceAll(Constant.ADB_ACT_PREFIX, Constant.STR_BLANK));
					addressList.add(address);
				}
			}

			// set rowid_object of Communication into response
			if (!CollectionUtils.isEmpty(putRespDataCommunicationList)) {
				dataHolderMap.put(MDMAttributeNames.ENTITY_COMM, putRespDataCommunicationList);
				for (PutResponseDataHolder putRespDataCommunication : putRespDataCommunicationList) {
					Communication comm = new Communication();
					comm.setROWIDCOMMUNICATION(putRespDataCommunication.getRowidObject());
					comm.setSRCSYSTEM(putRespDataCommunication.getSystemName());
					comm.setSRCSYSTEMID(putRespDataCommunication.getSourceKey().replaceAll(Constant.ADB_ACT_PREFIX, Constant.STR_BLANK));
					commList.add(comm);
				}
			}

			partyUpsertResp.getAccount().addAll(prospectList);
			partyUpsertResp.getAddress().addAll(addressList);
			partyUpsertResp.getCommunication().addAll(commList);
			upsertPartyResponse.getParty().add(partyUpsertResp);
		} catch (Exception excp) {
			LOG.error("Exception occured while processing CleansePut response for Party "
					+ putRespDataParty.getSourceKey(), excp);
			ServiceProcessingException customException = new ServiceProcessingException(excp);
			customException.setMessage("Exception occured while processing CleansePut response for Party. "
					+ customException.getMessage());
		}

		try {

			processTokenizeRequest(putRespDataParty);

			upsertPartyResponse.setStatus(upsertPartyResponse.getStatus()
					+ "\nTokenization operation successful for Party " + putRespDataParty.getSourceKey().replaceAll(Constant.ADB_ACT_PREFIX, Constant.STR_BLANK));
		} catch (SiperianServerException sifExcp) {
			LOG.error("SiperianServerException occured while processing TokenizeRequest for Party");
			ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
			customException.setMessage("SIF exception occured while processing Tokenize request for Party. "
					+ customException.getMessage());
		} catch (Exception excp) {
			LOG.error("Exception occured while processing TokenizeRequest for Party");
			ServiceProcessingException customException = new ServiceProcessingException(excp);
			customException.setMessage(
					"Exception occured while processing Tokenize request for Party." + customException.getMessage());
		}

		LOG.info("Executed processCleansePutRequest()");

		return;
	}

	public void processTokenizeRequest(PutResponseDataHolder putRespDataParty) throws ServiceProcessingException {
		LOG.debug("Executing processTokenizeRequest()");
		SiperianClient siperianClient = null;

		try {
			siperianClient = (SiperianClient) checkOut();

			TokenizeRequest tokenizeRequest = new TokenizeRequest();
			tokenizeRequest.setSiperianObjectUid(SiperianObjectType.BASE_OBJECT.makeUid("C_B_PARTY"));
			RecordKey recordKey = new RecordKey();
			recordKey.setRowid(putRespDataParty.getRowidObject());

			tokenizeRequest.setRecordKey(recordKey);
			tokenizeRequest.setActionType(putRespDataParty.getActionType());

			TokenizeResponse tokenizeResponse = (TokenizeResponse) siperianClient.process(tokenizeRequest);
			LOG.info("Match Token generated for ContactID: " + putRespDataParty.getRowidObject() + " Token msg: "
					+ tokenizeResponse.getMessage());
			LOG.debug("Executed processTokenizeRequest()");
		} catch (Exception excp) {
			LOG.error("Caught exception within processTokenizeRequest() " + excp.getMessage());
			ServiceProcessingException customExcp = new ServiceProcessingException(excp);
			throw customExcp;
		} finally {
			checkIn(siperianClient);
		}
	}

	public void checkDataQualityUpsert(PartyXrefType upsertParty, MdmUpsertPartyResponse upsertPartyResponse,
			boolean retry, boolean executeNextStep, String rowidObject) throws ServiceProcessingException {
		LOG.info("Executing checkDataQualityUpsert()");
		/**
		 * MDM service will reject account that comes with party name of Unknown
		 * START
		 */
		if (!validatorUtil.validateAccountName(upsertParty, upsertPartyResponse)) {
			// Account name is Not Valid
			LOG.debug("Adobe Account does not have Valid PARTY_NAME, hence bypassing Adobe Account insertion: ");
			upsertPartyResponse
					.setErrorMsg("ACCOUNT_NAME is Empty or Null or UNKNOWN OR Junk Value. Request is not processed");
			commonUtil.updateErrorStatus(upsertParty, upsertPartyResponse, Constant.ERROR_ACCOUNT_NAME_UNKWN, "0");
			throw new ServiceProcessingException(upsertPartyResponse.getStatus());
		}
		LOG.debug("[checkDataQualityUpsert] check for Account Address for Null or Unknown");
		if (!validatorUtil.validateAccountAddressNullUnknown(upsertParty, upsertPartyResponse, "Addressline1")) {
			// REPORTED ADDRESS OR CITY HAVE null or unknown
			LOG.debug("Adobe Account record have NULL or Unknown addressline1"
					+ upsertParty.getXREF().get(0).getSRCPKEY());
			upsertPartyResponse.setErrorMsg("Address is blank or Unknown or Junk Value");
			// upsertPartyResponse.getUpsertStatus().setCURRENTPROCESSSTEP(configProps.getProperty(upsertPartyResponse.getStatus()
			// + "_RETRY"));
			commonUtil.updateErrorStatus(upsertParty, upsertPartyResponse, Constant.ERROR_ACCOUNT_ADDR_LN1_UNKWN, "0");
			throw new ServiceProcessingException(upsertPartyResponse.getStatus());
		}
		// check for Account Address(City) for Empty, Null or Unknown
		LOG.debug("[checkDataQualityUpsert] check for Account City for Null or Unknown");
		if (!validatorUtil.validateAccountAddressNullUnknown(upsertParty, upsertPartyResponse, "City")) {
			// REPORTED CITY HAVE null or unknown
			LOG.debug("Adobe Account record have NULL or Unknown City " + upsertParty.getXREF().get(0).getSRCPKEY());
			upsertPartyResponse.setErrorMsg("City is blank or Unknown or Junk Value");
			// upsertPartyResponse.getUpsertStatus().setCURRENTPROCESSSTEP(configProps.getProperty(upsertPartyResponse.getStatus()
			// + "_RETRY"));
			commonUtil.updateErrorStatus(upsertParty, upsertPartyResponse, Constant.ERROR_ACCOUNT_CITY_UNKWN, "0");
			throw new ServiceProcessingException(upsertPartyResponse.getStatus());
		}
		// check for Account Address(Country) for Empty, Null or Unknown
		LOG.debug("[checkDataQualityUpsert] check for Address Country for Null or Unknown");
		if (!validatorUtil.validateAccountAddressNullUnknown(upsertParty, upsertPartyResponse, "Country")) {
			// REPORTED CITY HAVE null or unknown
			LOG.debug("ADB Account record have NULL or Unknown Country" + upsertParty.getXREF().get(0).getSRCPKEY());
			upsertPartyResponse.setErrorMsg("Country is blank or Unknown or Junk Value");
			//upsertPartyResponse.getUpsertStatus().setCURRENTPROCESSSTEP(configProps.getProperty(upsertPartyResponse.getStatus() + "_RETRY"));
			commonUtil.updateErrorStatus(upsertParty, upsertPartyResponse, Constant.ERROR_ACCOUNT_COUNTRY_UNKWN, "0");
			throw new ServiceProcessingException(upsertPartyResponse.getStatus());
		}
		LOG.debug("[checkDataQualityUpsert] check for Account Address for Junk");
		// check for Account Address for Junk and reject the account request
		if (!validatorUtil.validateAccountAddressJunk(upsertParty, upsertPartyResponse)) {
			LOG.debug("Adobe Account record have AddressLn1 or city junk ::Rejecting"
					+ upsertParty.getXREF().get(0).getSRCPKEY());
			upsertPartyResponse.setErrorMsg("AddressLn1 or city has Junk Value");
			// upsertPartyResponse.getUpsertStatus().setCURRENTPROCESSSTEP(configProps.getProperty(upsertPartyResponse.getStatus()
			// + "_RETRY"));
			commonUtil.updateErrorStatus(upsertParty, upsertPartyResponse, Constant.ERROR_ACCOUNT_CITY_UNKWN, "0");
			throw new ServiceProcessingException(upsertPartyResponse.getStatus());

		}
		if (executeNextStep)
			processCleansePutRequest(upsertParty, upsertPartyResponse, retry, executeNextStep, rowidObject);
	}

	/**
	 * Validates input account data
	 * 
	 * @param partyXrefType
	 * @param upsertResponse
	 * @return isValid
	 */
	public boolean validateAccountRequest(PartyXrefType partyXrefType, MdmUpsertPartyResponse upsertResponse) {
		LOG.debug("[validateAccountRequest] START");
		Boolean isValid = Boolean.TRUE;
		String srcPkey = partyXrefType.getXREF().get(0).getSRCPKEY();
		if (!Util.isNullOrEmpty(partyXrefType.getUCN()) && Util.isNullOrEmpty(srcPkey)) {
			isValid = Boolean.FALSE;
			validatorUtil.createUpsertInfoMessage(upsertResponse, Constant.INFO_ACCOUNT_EMPTY_PKEY, null);
			// US#581 send error code 806 for SRC Pkey not found for account
			// with UCN
			upsertResponse.setErrorCd(prospectPartyDAO
					.getErrorCodeByDescription(messagesProp.getProperty(Constant.INFO_ACCOUNT_EMPTY_PKEY)));
			//
		} else if (Util.isNullOrEmpty(partyXrefType.getPARTYNAME())) {
			isValid = Boolean.FALSE;
			validatorUtil.createUpsertInfoMessage(upsertResponse, Constant.ERROR_ACCOUNT_EMPTY_NAME, srcPkey);
		} else {
			List<AddressXrefType> addressXrefTypeList = partyXrefType.getAddress();
			if (CollectionUtils.isEmpty(addressXrefTypeList)) {
				isValid = Boolean.FALSE;
				validatorUtil.createUpsertInfoMessage(upsertResponse, Constant.ERROR_ACCOUNT_EMPTY_COUNTRY, srcPkey);
			} else {
				Boolean isCountryFound = Boolean.FALSE;
				for (AddressXrefType addressXrefType : addressXrefTypeList) {
					if (!Util.isNullOrEmpty(addressXrefType.getCOUNTRYCD())) {
						isCountryFound = Boolean.TRUE;
						break;
					}
				}
				if (!isCountryFound) {
					isValid = Boolean.FALSE;
					validatorUtil.createUpsertInfoMessage(upsertResponse, Constant.ERROR_ACCOUNT_EMPTY_COUNTRY,
							srcPkey);
					commonUtil.updateErrorStatus(partyXrefType, upsertResponse, Constant.ERROR_ACCOUNT_COUNTRY_UNKWN, "0");
				}
			}
		}
		LOG.debug("[validateAccountRequest] EXIT::isValid::" + isValid);
		return isValid;
	}

	/**
	 * Retrieving and validating Account Pkey
	 * <ol>
	 * <li>Checks in pay-load for Pkey. if not found then creates Account PKey
	 * </li>
	 * <li>Validate if the Pkey already associated with a deleted party</li>
	 * <li>Validate if the Pkey already associated with a DNB Cluster</li>
	 * </ol>
	 * 
	 * @param partyXrefType
	 * @param upsertResponse
	 * @return accountPkeyList
	 */
	@SuppressWarnings("unused")
	private List<String> retrieveAndValidateAccountPkey(PartyXrefType partyXrefType,
			MdmUpsertPartyResponse upsertResponse) {
		LOG.debug("[retrieveAndValidateAccountPkey] START");
		List<String> accountPkeyList = new ArrayList<String>();
		String mdmUcn = partyXrefType.getUCN();
		String srcSystem = partyXrefType.getXREF().get(0).getSRCSYSTEM();
		if (Util.isNullOrEmpty(mdmUcn)) {
			if (partyXrefType.getPartyRel() != null) {
				List<PartyContactRelationshipXrefType> contactRelXrefTypeList = partyXrefType.getPartyRel()
						.getPARTYPERSONREL();
				if (CollectionUtils.isEmpty(contactRelXrefTypeList)) {
					LOG.debug("[retrieveAndValidateAccountPkey] No Contact Rel found");
					createAccountUpsertErrorResponse(upsertResponse, Constant.ERROR_CREATE_ACCOUNT_PKEY_NO_CONTACT,
							null);
				} else {
					for (PartyContactRelationshipXrefType contactRelationshipXrefType : contactRelXrefTypeList) {
						String accountPkey = createAccountPkey(contactRelationshipXrefType.getSRCPKEY());
						if (validateAccountPkey(accountPkey, srcSystem, upsertResponse)) {
							accountPkeyList.add(accountPkey);
						}
					}
				}
			} else {
				LOG.debug("[retrieveAndValidateAccountPkey] No Party Rel found");
				createAccountUpsertErrorResponse(upsertResponse, Constant.ERROR_CREATE_ACCOUNT_PKEY_NO_CONTACT, null);
			}
		} else {
			String accountPkey = partyXrefType.getXREF().get(0).getSRCPKEY();
			if (validateAccountPkey(accountPkey, srcSystem, upsertResponse)) {
				accountPkeyList.add(accountPkey);
			}
		}
		LOG.debug("[retrieveAndValidateAccountPkey] EXIT::accountPkeyList::" + accountPkeyList);
		return accountPkeyList;
	}

	/**
	 * Validates account PKey
	 * 
	 * @param srcPkey
	 * @param srcSystem
	 * @param upsertResponse
	 * @return isValid
	 */
	private boolean validateAccountPkey(String srcPkey, String srcSystem, MdmUpsertPartyResponse upsertResponse) {
		LOG.debug("[validateAccountPkey] START");
		Boolean isValid = Boolean.TRUE;
		if (prospectPartyDAO.isDeletedExistForPkey(srcPkey, srcSystem)) {
			isValid = Boolean.FALSE;
			validatorUtil.createUpsertInfoMessage(upsertResponse, Constant.INFO_ACCOUNT_EXISTING_DELETED_CLUSTER,
					srcPkey);
		} else if (prospectPartyDAO.isDNBClusterExistForPkey(srcPkey, srcSystem)) {
			isValid = Boolean.FALSE;
			validatorUtil.createUpsertInfoMessage(upsertResponse, Constant.INFO_ACCOUNT_EXISTING_DUNS_CLUSTER, srcPkey);
		}
		if (!isValid) {
			// US#581 send error code 805.Request is not processed.
			upsertResponse.setErrorCd(prospectPartyDAO
					.getErrorCodeByDescription(messagesProp.getProperty(Constant.INFO_CONTACT_ASSOCIATED)));
			//
		}
		LOG.debug("[validateAccountPkey] EXIT::isValid::" + isValid);
		return isValid;
	}

	/**
	 * Creates Account PKey for new account
	 * 
	 * @param partyXrefType
	 * @return accountPkey
	 */
	private String createAccountPkey(String contactPkey) {
		LOG.debug("[createAccountPkey] START");
		StringBuilder accountPkey = new StringBuilder(Constant.PROSPECT_ACCOUNT_PKEY_PREFIX);
		accountPkey.append(Constant.STR_DASH);
		accountPkey.append(contactPkey);
		LOG.debug("[createAccountPkey] EXIT::accountPkey::" + accountPkey.toString());
		return accountPkey.toString();
	}

	/* Added for US68-Throughput Tracker END */

	/**
	 * Create error response for account upsert
	 * 
	 * @param upsertResponse
	 * @param errorPropId
	 * @param srcPkey
	 */
	private void createAccountUpsertErrorResponse(MdmUpsertPartyResponse upsertResponse, String errorPropId,
			String srcPkey) {
		LOG.debug("[createAccountUpsertErrorResponse] START::srcPkey::" + srcPkey + ", errorPropId::" + errorPropId);
		PartyUpsertRespType partyUpsertRespType = new PartyUpsertRespType();
		if (srcPkey == null) {
			partyUpsertRespType.setErrorMsg(messagesProp.getProperty(errorPropId));
		} else {
			srcPkey = srcPkey.replaceAll(Constant.ADB_ACT_PREFIX, "");
			partyUpsertRespType.setSRCSYSTEMID(srcPkey);
			partyUpsertRespType
					.setErrorMsg("Error in SRC PKEY::" + srcPkey + "::" + messagesProp.getProperty(errorPropId));
		}
		upsertResponse.getParty().add(partyUpsertRespType);
		LOG.debug("[createAccountUpsertErrorResponse] EXIT::Error Message::" + partyUpsertRespType.getErrorMsg());
	}

	public void preUpsertMatchProcess(PartyXrefType upsertParty, MdmUpsertPartyResponse upsertPartyResponse,
			boolean retry, boolean executeNextStep, String rowidObject) throws ServiceProcessingException {

	}

	/**
	 * Upsert a marketing account
	 * 
	 * @param partyXrefType
	 * @param upsertResponse
	 */
	@SuppressWarnings("unchecked")
	public void processCleansePutRequest(PartyXrefType partyXrefType, MdmUpsertPartyResponse upsertResponse,
			boolean retry, boolean executeNextStpe, String rowidObject) throws ServiceProcessingException {
		LOG.debug("[processCleansePutRequest] START :: Processing for srcPkey::"
				+ partyXrefType.getXREF().get(0).getSRCPKEY());
		String srcPkey = null;
		int countOfRetry = Integer.parseInt(configProps.getProperty("NoOfRetries"));
		boolean isMultiGeoMatchSuccess = false;
		boolean isStrictMatchProspect = false;
		boolean isMergePartySuccess = false;
		//boolean isMergeAddressSuccess = false;
		boolean isMergeProspectSuccess = false;
		boolean isCustomer = false;
		boolean needProspectMatch = false;
		PartyXrefType newDunsPartyXrefType = null;
		try {
			String srcSystem = partyXrefType.getXREF().get(0).getSRCSYSTEM();
			// String mdmUcn = partyXrefType.getUCN();
			String rowIdParty = null;
			String rowIdProspect = null;
			String rowIdAddress = null;
			String rowIdAccount = null;
			
			srcPkey = partyXrefType.getXREF().get(0).getSRCPKEY();

			Map<String, Integer> mrktRowIdCountMap = null;
			Integer mrktRowCount = 0;
			String partyType="";
			if(retry){
				partyType = getPartyType(srcPkey, srcSystem);
			}
			
			if(!(Constant.PARTY_TYPE_CUSTOMER.equalsIgnoreCase(partyType))){
				mrktRowIdCountMap = prospectPartyDAO.getExistingRowIdAndProspectRecordCount(srcPkey, srcSystem);
			
			if (!mrktRowIdCountMap.isEmpty()) {
				rowIdParty = mrktRowIdCountMap.keySet().iterator().next();
				if (!Util.isNullOrEmpty(rowIdParty)) {
					mrktRowCount = mrktRowIdCountMap.get(rowIdParty);
				}
			}
			}
			// update flow
			if (mrktRowCount > 0) {
				LOG.debug("[processCleansePutRequest] Found Marketing XRef without DNB");
				// for both one record 3.5.7 and 3.5.8
				updateProspectAccount(partyXrefType, srcSystem, srcPkey, mrktRowCount, upsertResponse);
			}
			// create flow
			else {
				LOG.debug("[processCleansePutRequest] Marketing XRef without DNB not found");
				LOG.debug("[processCleansePutRequest] Marketing account without UCN");
				Boolean needToMerge = Boolean.FALSE;
				String targetRowId = null;
				String targetRowIdAddr = null;
				String targetRowIdProspect = null;
				String targetRowIdAccount = null;
				Map<String, List<String>> rowIdMap = null;
				
				boolean isVaildUcn = false;
				boolean isValidContactLikedAcct = false;
				if(!Util.isNullOrEmpty(partyXrefType.getUCN())){
					try{
					rowIdMap = 	fetchPartyRowIdByUcn(partyXrefType.getUCN());
					if(rowIdMap!=null && !rowIdMap.isEmpty()){
						
						if(!Util.isNullOrEmpty(rowIdMap.get(Constant.CURRENT_ACTIVE_PARTY).get(0))){
							isVaildUcn = true;
						}
					}
					}catch(Exception e){
					LOG.info("Exception occured while finding match with UCN");	
					}
				}
				if(!isVaildUcn){
					
					try{
					rowIdMap = fetchPartyRowIdByContact(srcPkey);
					if(rowIdMap!=null && !rowIdMap.isEmpty()){
						
						if(!Util.isNullOrEmpty(rowIdMap.get(Constant.CURRENT_ACTIVE_PARTY).get(0))){
							isValidContactLikedAcct = true;
						}
					}
					}catch(Exception e){
						LOG.info("Exception occured while finding match with contact details");	
					}
				}
				if(!isVaildUcn && !isValidContactLikedAcct){
				try {
					rowIdMap = searchProspectDao.findMultiGeoMatch(partyXrefType);
					
					if(rowIdMap != null && !CollectionUtils.isEmpty(rowIdMap)){
						if(!(CollectionUtils.isEmpty(rowIdMap.get(Constant.CURRENT_ACTIVE_PARTY))) || 
								!(CollectionUtils.isEmpty(rowIdMap.get(Constant.CURRENT_SINGLETON_OR_PROSPECT_DUNS_PARTY)))){
							LOG.debug("[processCleansePutRequest]: findMultiGeoMatch is Completed successfully and match found");
						}else{
							rowIdMap = null;
							LOG.debug("[processCleansePutRequest]: findMultiGeoMatch is Completed and match not found");
						}
					}
					
				} catch (Exception ex) {
					// mergeInd = false;
					LOG.error("[processCleansePutRequest]: Exception occured while findMultiGeoMatch: ", ex);
					for (int i = 0; i < countOfRetry; i++) {
						try {
							LOG.debug("[processCleansePutRequest]: Retrying findMultiGeoMatch for " + (i + 1)
									+ "th time");
							rowIdMap = searchProspectDao.findMultiGeoMatch(partyXrefType);
							LOG.debug("[processCleansePutRequest]: findMultiGeoMatch is successful on attempt no. "
									+ (i + 1));
							isMultiGeoMatchSuccess = true;
							// mergeInd = true;
							break;
						} catch (Exception excp) {
							LOG.error("[processCleansePutRequest]: Exception occured in findMultiGeoMatch"
									+ " RetryMechanism on attempt no. " + (i + 1));
							LOG.error(
									"[processCleansePutRequest]: Exception occured in findMultiGeoMatch RetryMechanism");
						}
					}
					if (!isMultiGeoMatchSuccess) {
						ServiceProcessingException customException = new ServiceProcessingException(ex);
						customException.setMessage("[processCleansePutRequest]: Exception occured in findMultiGeoMatch "
								+ "RetryMechanism: " + customException.getMessage());
						throw customException;
					}
				}
				}
				
				if(!isVaildUcn){
				if(rowIdMap != null && !CollectionUtils.isEmpty(rowIdMap)){
					if (rowIdMap.containsKey(Constant.CURRENT_ACTIVE_PARTY)) {
						String rowIdActiveParty = rowIdMap.get(Constant.CURRENT_ACTIVE_PARTY).get(0);
						if (isMatchExclusionPatternExists(rowIdActiveParty)) {
							rowIdMap = null;
						}
					}
				}
				}
				//New prospect account , No customer of DNB singleton match
				if (rowIdMap == null || rowIdMap.isEmpty()) {
					dnbProcpect = false;
					LOG.debug(
							"[processCleansePutRequest] No Multi Geo match found. Creating prospect account with input details");

					partyXrefType.setPARTYTYPE(Constant.PARTY_TYPE_PROSPECT_ACCOUNT);
					processCleansePut(partyXrefType, upsertResponse, isCustomer);

					rowIdParty = ((PutResponseDataHolder) dataHolderMap.get(MDMAttributeNames.ENTITY_PARTY))
							.getRowidObject();
					rowIdAddress = ((List<PutResponseDataHolder>) dataHolderMap.get(MDMAttributeNames.ENTITY_ADDRESS))
							.get(0).getRowidObject();
					rowIdProspect = ((List<PutResponseDataHolder>) dataHolderMap.get(MDMAttributeNames.ENTITY_PROSPECT))
							.get(0).getRowidObject();
					
					//PartyXrefType existingCustXref = getPartyDAO.getParty(rowIdParty);
					targetRowId = rowIdParty;
					targetRowIdAddr = rowIdAddress;
					targetRowIdProspect = rowIdProspect; //existingCustXref.getAccount().get(0).getROWIDACCOUNT();
					Set<String> rowIds = null;

						LOG.debug("Processing strict match for prospect account ");
						try {
							rowIds = searchProspectDao.findStrictMatchProspect(partyXrefType, rowIdParty);
							LOG.debug(
									"[processCleansePutRequest]: findStrictMatchProspect is Completed successfully !");
						} catch (Exception ex) {
							// mergeInd = false;
							LOG.error("[processCleansePutRequest]: Exception occured while findStrictMatchProspect: ",
									ex);
							for (int i = 0; i < countOfRetry; i++) {
								try {
									LOG.debug("[upsertIndividualAccount]: Retrying findStrictMatchProspect for "
											+ (i + 1) + "th time");
									rowIds = searchProspectDao.findStrictMatchProspect(partyXrefType, rowIdParty);
									LOG.debug(
											"[processCleansePutRequest]: findStrictMatchProspect is successful on attempt no. "
													+ (i + 1));
									isStrictMatchProspect = true;
									// mergeInd = true;
									break;
								} catch (Exception excp) {
									LOG.error("[processCleansePutRequest]: Exception occured in findStrictMatchProspect"
											+ " RetryMechanism on attempt no. " + (i + 1));
									LOG.error(
											"[processCleansePutRequest]: Exception occured in findStrictMatchProspect RetryMechanism");
								}
							}
							if (!isStrictMatchProspect) {
								ServiceProcessingException customException = new ServiceProcessingException(ex);
								customException.setMessage(
										"[processCleansePutRequest]: Exception occured in findStrictMatchProspect "
												+ "RetryMechanism: " + customException.getMessage());
								throw customException;
							}
						}
						if (CollectionUtils.isEmpty(rowIds)) {
							LOG.debug("[processCleansePutRequest] No Strict Match found");
						} else {
							List<PartyChildRowIdData> partyChildDataList = prospectPartyDAO.getPartyChildRowId(rowIds);
							if (CollectionUtils.isEmpty(partyChildDataList)) {
								LOG.debug("[processCleansePutRequest] No Address and Prospect RowID Found");
								targetRowId = rowIds.iterator().next();
							} else {
								PartyChildRowIdData partyChildData = partyChildDataList.get(0);
								targetRowId = partyChildData.getRowIdParty();
								targetRowIdAddr = partyChildData.getRowIdAddr();
								targetRowIdProspect = partyChildData.getRowIdProspect();
							}
							needToMerge = Boolean.TRUE;
						}

				} //end create Prospect
				// Match customer
				else if (rowIdMap.containsKey(Constant.CURRENT_ACTIVE_PARTY)) {
					dnbProcpect = false;
					// creating customer account using matched customer record
					LOG.debug("[processCleansePutRequest] Multi Geo match found for active party. Creating customer account");
					String rowIdActiveParty = rowIdMap.get(Constant.CURRENT_ACTIVE_PARTY).get(0);
					isCustomer = true;
					try {

						PartyType existingParty = getPartyDAO.getBOParty(rowIdActiveParty, false);

						if (existingParty != null) {
							PartyXrefType existingCustXref = preparePartyXref(existingParty,partyXrefType);
							targetRowId = rowIdMap.get(Constant.CURRENT_ACTIVE_PARTY).get(0);
							targetRowIdAccount = existingParty.getAccount().get(0).getROWIDACCOUNT();
							targetRowIdAddr = existingParty.getAddress().get(0).getROWIDADDRESS();
							existingCustXref.setMSGTRKNID(partyXrefType.getMSGTRKNID());
							processCleansePut(existingCustXref, upsertResponse, isCustomer);

							rowIdParty = ((PutResponseDataHolder) dataHolderMap.get(MDMAttributeNames.ENTITY_PARTY))
									.getRowidObject();
							rowIdAccount = ((List<PutResponseDataHolder>) dataHolderMap
									.get(MDMAttributeNames.ENTITY_ACCOUNT)).get(0).getRowidObject();
							rowIdAddress = ((List<PutResponseDataHolder>) dataHolderMap
									.get(MDMAttributeNames.ENTITY_ADDRESS)).get(0).getRowidObject();

							needToMerge = Boolean.TRUE;
						}

					} catch (ServiceProcessingException spExcp) {
						LOG.error("Caught exception while creating customer account: ", spExcp);
						throw new ServiceProcessingException(Constant.ERROR_ACC_EXT_ACC_PUT_FAIL);
						//upsertResponse.setStatus(upsertResponse.getStatus());
					} catch (Exception Excp) {
						LOG.error("Caught exception while creating customer account: ", Excp);
						//upsertResponse.setStatus(upsertResponse.getStatus());
						throw new ServiceProcessingException(Constant.ERROR_ACC_EXT_ACC_PUT_FAIL);
					}

				} //match customer end 
				// singleton DNB
				else if (rowIdMap.containsKey(Constant.CURRENT_SINGLETON_OR_PROSPECT_DUNS_PARTY)) {
					// creating prospect account with matched DNB
					isCustomer =false;
					dnbProcpect = true;
					LOG.debug(
							"[processCleansePutRequest] Multi Geo match found for party with DUNS. Creating account with Duns details");
					needToMerge = Boolean.TRUE;
					targetRowId = rowIdMap.get(Constant.CURRENT_SINGLETON_OR_PROSPECT_DUNS_PARTY).get(0);
					PartyXrefType dunsPartyXRef = getMarketingPartyDAO.getBOPartyForMrktActn(targetRowId, srcSystem,
							srcPkey);
					newDunsPartyXrefType = dunsPartyXRef;
					targetRowIdAddr = dunsPartyXRef.getAddress().get(0).getROWIDADDRESS();
					LOG.info("target rowid address : " + targetRowIdAddr);
					Set<String> rowIds = new HashSet<String>();
					rowIds.add(targetRowId);
					List<PartyChildRowIdData> partyChildDataList = prospectPartyDAO.getPartyChildRowId(rowIds);
					if (CollectionUtils.isEmpty(partyChildDataList)) {
						LOG.debug("[processCleansePutRequest] No Address and Prospect RowID Found");
						targetRowId = rowIds.iterator().next();
					} else {
						PartyChildRowIdData partyChildData = partyChildDataList.get(0);
						targetRowIdAddr = partyChildData.getRowIdAddr();
						LOG.info("target rowid address 1 : " + targetRowIdAddr);
						targetRowIdProspect = partyChildData.getRowIdProspect();
						LOG.info("target rowid prospect : " + targetRowIdProspect);
					}
					dunsPartyXRef.setPARTYTYPE(partyXrefType.getPARTYTYPE());
					dunsPartyXRef.getXREF().addAll(partyXrefType.getXREF());
					dunsPartyXRef.getAccount().addAll(partyXrefType.getAccount());

					processCleansePut(dunsPartyXRef, upsertResponse, isCustomer);

					rowIdParty = ((PutResponseDataHolder) dataHolderMap.get(MDMAttributeNames.ENTITY_PARTY))
							.getRowidObject();
					rowIdProspect = ((List<PutResponseDataHolder>) dataHolderMap.get(MDMAttributeNames.ENTITY_PROSPECT))
							.get(0).getRowidObject();
					rowIdAddress = ((List<PutResponseDataHolder>) dataHolderMap.get(MDMAttributeNames.ENTITY_ADDRESS))
							.get(0).getRowidObject();
					needToMerge = Boolean.TRUE;
					needProspectMatch = true;
				} else {
					LOG.debug("[processCleansePutRequest] Invalid Multi Geo match map::" + rowIdMap);
				}
                 //Restrict Merge for Ultimate Parent
				if (needToMerge) {
					String sourceUCN = null;
					String targetUCN = null;
					String parentExistFlag = "N";
					StringBuffer sBuffer = new StringBuffer(5);
					sBuffer = CommonUtil.checkBothDnbandParentExist(rowIdParty, targetRowId);
					parentExistFlag = sBuffer.substring(0, 1);
					
					LOG.debug("Before merge parentExistFlag:: " + parentExistFlag);
					
					if (parentExistFlag.equalsIgnoreCase("N")) {
						needToMerge = Boolean.TRUE;
						LOG.debug("Party need to be Merge!!");
					} 
					else if (parentExistFlag.equalsIgnoreCase("Y")) {
						needToMerge = Boolean.FALSE;
						
						 try {
							sourceUCN = prospectPartyDAO.checkifUCNExists(rowIdParty);
							 targetUCN = prospectPartyDAO.checkifUCNExists(targetRowId);
						} catch (Exception e) {
							LOG.error("Caught exception in checkifUCNExists()", e);
						}
							String title ="Auto Merge Restricted for Accounts  : " +sourceUCN +"  and " + targetUCN;
							String comment = "Auto Merge Restricted for Accounts : "+sourceUCN+" and "+ targetUCN + "  since both are having Active Parents. Please review and take action.";
							
						processCreateTaskRequest(targetRowId, rowIdParty, "Merge", title, comment);
					}
					else {
						LOG.info("needToMerge");
					}
				}
				
				
				if (needToMerge) {
					try {
						LOG.debug("Source rowid : "+rowIdParty+" Target rowid : "+ targetRowId);
						mergeProspectPartyDAO.mergeProspectParties(MDMAttributeNames.PARTY_BO, rowIdParty, targetRowId);
						upsertResponse
						.setStatus(upsertResponse.getStatus() + "Party records got merged.");
						LOG.debug("[processCleansePutRequest]: mergeProspectParties successful on C_B_PARTY..");
						isMergePartySuccess = true;
						/*LOG.debug(" Address Source rowid : "+rowIdAddress+" Target rowid : "+ targetRowIdAddr);
						mergeProspectPartyDAO.mergeProspectParties(MDMAttributeNames.ADDRESS_BO, rowIdAddress,
								targetRowIdAddr);
						upsertResponse
						.setStatus(upsertResponse.getStatus() + "Address records got merged.");
						LOG.debug("[processCleansePutRequest]: mergeProspectParties successful on C_B_ADDRESS..");
						isMergeAddressSuccess = true;*/
						if (!Util.isNullOrEmpty(targetRowIdProspect)) {
							LOG.debug(" Prospect Source rowid : "+rowIdProspect+" Target rowid : "+ targetRowIdProspect);
							mergeProspectPartyDAO.mergeProspectParties(MDMAttributeNames.PARTY_PROSPECT_BO,
									rowIdProspect, targetRowIdProspect);
							LOG.debug(
									"[processCleansePutRequest]: mergeProspectParties successful on C_B_PARTY_PROSPECT..");
							upsertResponse
							.setStatus(upsertResponse.getStatus() + "Prospect records got merged.");
							isMergeProspectSuccess = true;
						}
						
						if (!Util.isNullOrEmpty(targetRowIdAccount)) {
							LOG.debug(" Source Account rowid : "+rowIdAccount+" Target Account rowid : "+ targetRowIdAccount);
							mergeProspectPartyDAO.mergeProspectParties(MDMAttributeNames.ACCOUNT_BO, rowIdAccount,
									targetRowIdAccount);
							LOG.debug("[processCleansePutRequest]: mergeAccount successful on C_B_ACCOUNT..");
							isMergeProspectSuccess = true;
						}
						upsertResponse.getParty().get(0).setROWIDOBJECT(targetRowId.trim());
						
					} catch (Exception ex) {
						// mergeInd = false;
						LOG.error("[processCleansePutRequest]: Exception occured while mergeProspectParties: ", ex);
						for (int i = 0; i < countOfRetry; i++) {
							try {
								if (!isMergePartySuccess) {
									LOG.debug("[processCleansePutRequest]: Retrying mergeProspectParties for C_B_PARTY "
											+ (i + 1) + "th time");
									mergeProspectPartyDAO.mergeProspectParties(MDMAttributeNames.PARTY_BO, rowIdParty,
											targetRowId);
									LOG.debug(
											"[processCleansePutRequest]:mergeProspectParties successful on C_B_PARTY in attempt no. "
													+ (i + 1));
									isMergePartySuccess = true;
									break;
								}
							} catch (Exception excp) {
								LOG.error(
										"[processCleansePutRequest]: Exception occured in mergeProspectParties for C_B_PARTY"
												+ " RetryMechanism on attempt no. " + (i + 1));
								LOG.error(
										"[processCleansePutRequest]: Exception occured in mergeProspectParties RetryMechanism for C_B_PARTY");
							}
						}
						if (!isMergePartySuccess) {
							ServiceProcessingException customException = new ServiceProcessingException(ex);
							commonUtil.updateErrorStatus(partyXrefType, upsertResponse, Constant.ERROR_ACC_MERGE_FAIL, rowIdParty);
							customException.setMessage(
									"[processCleansePutRequest]: Exception occured in mergeProspectParties for C_B_PARTY "
											+ "RetryMechanism: " + customException.getMessage());
							throw customException;
						}

						/*for (int i = 0; i < countOfRetry; i++) {
							try {
								if (!isMergeAddressSuccess) {
									LOG.debug(
											"[processCleansePutRequest]: Retrying mergeProspectParties for C_B_ADDRESS "
													+ (i + 1) + "th time");
									mergeProspectPartyDAO.mergeProspectParties(MDMAttributeNames.ADDRESS_BO,
											rowIdAddress, targetRowIdAddr);
									LOG.debug(
											"[processCleansePutRequest]:mergeProspectParties successful on C_B_ADDRESS in attempt no. "
													+ (i + 1));
									isMergeAddressSuccess = true;
									// mergeInd = true;
									break;
								}
							} catch (Exception excp) {
								LOG.error(
										"[processCleansePutRequest]: Exception occured in mergeProspectParties for C_B_ADDRESS"
												+ " RetryMechanism on attempt no. " + (i + 1));
								LOG.error(
										"[processCleansePutRequest]: Exception occured in mergeProspectParties RetryMechanism for C_B_ADDRESS");
							}
						}
						if (!isMergeAddressSuccess) {
							ServiceProcessingException customException = new ServiceProcessingException(ex);
							commonUtil.updateErrorStatus(partyXrefType, upsertResponse, Constant.ERROR_ACC_MERGE_FAIL, rowIdParty);
							customException.setMessage(
									"[processCleansePutRequest]: Exception occured in mergeProspectParties for C_B_ADDRESS "
											+ "RetryMechanism: " + customException.getMessage());
							throw customEsxception;
						}*/

						for (int i = 0; i < countOfRetry; i++) {
							try {
								if (!isMergeProspectSuccess) {
									LOG.debug(
											"[processCleansePutRequest]: Retrying mergeProspectParties for C_B_PARTY_PROSPECT "
													+ (i + 1) + "th time");
									if (!Util.isNullOrEmpty(targetRowIdProspect)) {
										mergeProspectPartyDAO.mergeProspectParties(MDMAttributeNames.PARTY_PROSPECT_BO,
												rowIdProspect, targetRowIdProspect);
										LOG.debug(
												"[processCleansePutRequest]:mergeProspectParties successful on C_B_PARTY_PROSPECT in attempt no. "
														+ (i + 1));
										isMergeProspectSuccess = true;
									} else if (!Util.isNullOrEmpty(targetRowIdAccount)) {
										mergeProspectPartyDAO.mergeProspectParties(MDMAttributeNames.ACCOUNT_BO,
												rowIdAccount, targetRowIdAccount);
										LOG.debug(
												"[processCleansePutRequest]: mergeAccount successful on C_B_ACCOUNT..");
										isMergeProspectSuccess = true;
									}
									// mergeInd = true;
									break;
								}
							} catch (Exception excp) {
								LOG.error(
										"[processCleansePutRequest]: Exception occured in mergeProspectParties for C_B_PARTY_PROSPECT"
												+ " RetryMechanism on attempt no. " + (i + 1));
								LOG.error(
										"[processCleansePutRequest]: Exception occured in mergeProspectParties RetryMechanism for C_B_PARTY_PROSPECT");
							}
						}
						if (!isMergeProspectSuccess) {
							ServiceProcessingException customException = new ServiceProcessingException(ex);
							commonUtil.updateErrorStatus(partyXrefType, upsertResponse, Constant.ERROR_ACC_MERGE_FAIL, rowIdParty);
							customException.setMessage(
									"[processCleansePutRequest]: Exception occured in mergeProspectParties for C_B_PARTY_PROSPECT "
											+ "RetryMechanism: " + customException.getMessage());
							throw customException;
						}

					}
					PutResponseDataHolder putRespDataPartyChild = null;

					childMultiMergeParty(partyXrefType, upsertResponse, putRespDataPartyChild);

					try {
						// Perform Tokenization after Match & Merge
						PutResponseDataHolder putTokenizeDataParty = new PutResponseDataHolder();
						String survivorRowid = targetRowId;
						
							if (!Util.isNullOrEmpty(survivorRowid)) {
								putTokenizeDataParty.setRowidObject(survivorRowid);
								putTokenizeDataParty.setActionType("Merge");
								processTokenizeRequest(putTokenizeDataParty);
							}
					} catch (SiperianServerException sifExcp) {
						LOG.error("SiperianServerException occured while processing TokenizeRequest for Account after MatchMerge.",
								sifExcp);
					} catch (Exception excp) {
						LOG.error("Exception occured while processing TokenizeRequest for Account after MatchMerge.", excp);
						ServiceProcessingException customException = new ServiceProcessingException(excp);
						customException
								.setMessage("Exception occured while processing Tokenize request for Account after MatchMerge. "
										+ customException.getMessage());
					}
				}
				if(needProspectMatch){
					targetRowId = performProspectMatchAndMerge(newDunsPartyXrefType, targetRowId,
							upsertResponse);
				}
				rowIdParty = targetRowId;

			}
		} catch (ServiceProcessingException servexp) {
			LOG.error("[processCleansePutRequest]Caught ServiceProcessingException", servexp);
		} catch (Exception exp) {
			LOG.error("[processCleansePutRequest]Caught exception in processMarketingUpsertRequest()", exp);
			createAccountUpsertErrorResponse(upsertResponse, Constant.ERROR_UPSERT_ACCOUNT_EXCEPTION, srcPkey, exp);
		}
		LOG.debug("[processCleansePutRequest] EXIT");
	}


	private String getPartyType(String srcPkey, String srcSystem) {
		LOG.debug("Inside getPartyType()");
		Statement statement = null;
		Connection jdbcConn = null;
		ResultSet resultSet = null;
		String partyType = null;
		JDBCConnectionProvider jDBCConnectionProvider = null;
		try {
			jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
			jdbcConn = jDBCConnectionProvider.getJdbcConnectionFromDS();
			LOG.info("getPartyType  srcPkey : " + srcPkey+" srcSystem : "+srcSystem);
			StringBuilder sql = new StringBuilder();
			sql.append("select party.party_type from C_B_PARTY party, C_B_PARTY_XREF xref where "
					+ "party.rowid_object = xref.rowid_object and xref.pkey_src_object = '"+srcPkey+"' and xref.rowid_system='"+srcSystem+"'");
			sql.append(" order by xref.create_date desc");
			
			LOG.debug("SQL Generated is : " + sql.toString());
			statement = jdbcConn.createStatement();
			resultSet = statement.executeQuery(sql.toString());
			
			while(resultSet.next()){
				partyType = resultSet.getString(1);
				break;
			}
			LOG.debug("partyType: " + partyType);
		} catch (Exception exp) {
			exp.printStackTrace();
		} finally {
			try {
				if (resultSet != null)
					resultSet.close();
				if (statement != null)
					statement.close();
				if (jdbcConn != null)
					jdbcConn.close();
			} catch (SQLException exp) {
				LOG.error("Caught SQLException in getPartyType().");
			}

		}
		return partyType;
	}

	private PartyXrefType preparePartyXref(PartyType existingParty, PartyXrefType partyXrefType) {
		LOG.info("Inside preparePartyXref");
		String srcPkey = partyXrefType.getXREF().get(0).getSRCPKEY();
		PartyXrefType existingXrefType = new PartyXrefType();
		existingXrefType.setBOCLASSCODE(existingParty.getBOCLASSCODE());
		existingXrefType.setMSGTRKNID(partyXrefType.getMSGTRKNID());
		existingXrefType.setPARTYTYPE(Constant.PARTY_TYPE_CUSTOMER);
		existingXrefType.setSTATUSCD(Constant.STATUS_ACTIVE);
		existingXrefType.setREGION(existingParty.getREGION());
		existingXrefType.setPARTYNAME(existingParty.getPARTYNAME());
		existingXrefType.setSALESBLOCKCD(existingParty.getSALESBLOCKCD());
		existingXrefType.setGEO(existingParty.getGEO());
		existingXrefType.setPHYSICALGEO(existingParty.getPHYSICALGEO());
		existingXrefType.setPHYSICALREGION(existingParty.getPHYSICALREGION());
		existingXrefType.setENGLISHNAME(existingParty.getENGLISHNAME());
		existingXrefType.setUCN(existingParty.getUCN());
		existingXrefType.setLEGACYUCN(existingParty.getLEGACYUCN());
		existingXrefType.setSRCCREATEDT(partyXrefType.getSRCCREATEDT());
		LOG.info("Added party");
		XREFType xrefTye = new XREFType();
		xrefTye.setSRCPKEY(srcPkey);
		xrefTye.setSRCSYSTEM(Constant.SRC_SYSTEM_ADB);
		existingXrefType.getXREF().add(xrefTye);
		LOG.info("Added party xref");
		AccountXrefType xrefAccount =null;
		if(!CollectionUtils.isEmpty(existingParty.getAccount())){
			xrefAccount = new AccountXrefType();
			AccountType account =  existingParty.getAccount().get(0);
			xrefAccount.setSRCPKEY(srcPkey);
			xrefAccount.setSRCSYSTEM(Constant.SRC_SYSTEM_ADB);
			xrefAccount.setACCTNAME(account.getACCTNAME());
			xrefAccount.setACCTSTATUS(Constant.STATUS_ACTIVE);
			xrefAccount.setACCTTYPE(account.getACCTTYPE());
			xrefAccount.setCUSTGROUP(account.getCUSTGROUP());
			xrefAccount.setDATASRCSYSTEM(account.getDATASRCSYSTEM());
			xrefAccount.setACCOUNTGEO(account.getACCOUNTGEO());
			xrefAccount.setACCOUNTREGION(account.getACCOUNTREGION());
			existingXrefType.getAccount().add(xrefAccount);
			LOG.info("Added account xref");
		}
		
		AddressXrefType xrefAddress = null;
		if (!CollectionUtils.isEmpty(existingParty.getAddress())) {
			for (int i = 0; i < existingParty.getAddress().size(); i++) {
				xrefAddress = new AddressXrefType();
				AddressType address = existingParty.getAddress().get(i);
				xrefAddress.setADDRLN1(address.getADDRLN1());
				xrefAddress.setADDRLN2(address.getADDRLN2());
				xrefAddress.setADDRLN3(address.getADDRLN3());
				xrefAddress.setADDRLN4(address.getADDRLN4());
				xrefAddress.setADDRSTATUS(Constant.STATUS_ACTIVE);
				xrefAddress.setADDRTYPE(Constant.ADDRESS_TYPE_BILLING);
				xrefAddress.setCITY(address.getCITY());
				String countryName = "";
				if (!Util.isNullOrEmpty(address.getCOUNTRYCD()) && address.getCOUNTRYCD().trim().length() == 2) {
					countryName = getADBCountryName(address.getCOUNTRYCD().trim());
				} else {
					countryName = address.getCOUNTRYCD();
				}
				xrefAddress.setCOUNTRYCD(countryName);

				xrefAddress.setSTATECD(address.getSTATECD());
				xrefAddress.setCOUNTY(address.getCOUNTY());
				xrefAddress.setDISTRICT(address.getDISTRICT());
				xrefAddress.setADDRMKTGPREF(address.getADDRMKTGPREF());
				xrefAddress.setLANGCD(address.getLANGCD());
				xrefAddress.setPOSTALCD(address.getPOSTALCD());
				xrefAddress.setSRCPKEY(srcPkey);
				xrefAddress.setSRCSYSTEM(Constant.SRC_SYSTEM_ADB);
				xrefAddress.setLATITUDE(address.getLATITUDE());
				xrefAddress.setLONGITUDE(address.getLONGITUDE());
				existingXrefType.getAddress().add(xrefAddress);
				LOG.info("Added address xref");
			}
		}
		
		CommunicationXrefType xrefComm = null;
		
		if (!CollectionUtils.isEmpty(existingParty.getCommunication()) && existingParty.getCommunication() != null
				&& existingParty.getCommunication().size() > 0) {
			LOG.info("Adding CommunicationXrefType in request size : " + existingParty.getCommunication().size());
			for (int i = 0; i < existingParty.getCommunication().size(); i++) {
				CommunicationType commType = existingParty.getCommunication().get(i);
				if (commType != null && !Util.isNullOrEmpty(commType.getCOMMVALUE())) {
					xrefComm = new CommunicationXrefType();
					xrefComm.setWEBDOMAIN(commType.getWEBDOMAIN());
					xrefComm.setCOMMMKTGPREF(commType.getCOMMMKTGPREF());
					xrefComm.setCOMMSALESPREF(commType.getCOMMSALESPREF());
					xrefComm.setCOMMSTATUS(Constant.STATUS_ACTIVE);
					xrefComm.setCOMMTYPE(commType.getCOMMTYPE());
					xrefComm.setCOMMVALUE(commType.getCOMMVALUE());
					xrefComm.setPRFRDCOMMIND(commType.getPRFRDCOMMIND());
					xrefComm.setSRCPKEY(srcPkey);
					xrefComm.setSRCSYSTEM(Constant.SRC_SYSTEM_ADB);
					existingXrefType.getCommunication().add(xrefComm);
					LOG.info("Added communication xref");
				}
			}
		}
		LOG.info("end preparePartyXref");
		return existingXrefType;
	}

	// 3.5.7
	private List<String> checkForUpdate(PartyXrefType partyXrefType) {
		List<String> rowIdList = new ArrayList<String>();
		if (partyXrefType.getXREF() != null) {
			String srcPkey = partyXrefType.getXREF().get(0).getSRCPKEY();
			List<String> accountPkeyList = new ArrayList<String>();
			if (!Util.isNullOrEmpty(srcPkey)) {
				accountPkeyList.add(srcPkey);
				// if there is a rowIdList > 0, then it is update and associated
				// with Customer /DNB record
				rowIdList = prospectPartyDAO.isAccountAssociatedWithCustomerOrDNB(accountPkeyList);
			}
		}

		return rowIdList;
	}

	public boolean checkForMatchExclusionPatternAndMerge(PartyXrefType partyXrefType, MdmUpsertPartyResponse upsertResponse, String rowIdParty) {
		boolean needToMerge = Boolean.FALSE;
		LOG.debug("isMatchExclusionPatternExists for prospect account created");
		boolean exclusionPatternExists = Boolean.FALSE;
		try {
			exclusionPatternExists = isMatchExclusionPatternExists(rowIdParty);
		} catch (Exception Excp) {

			LOG.error("Caught exception in isMatchExclusionPatternExists: ", Excp);
			String title = "Creating GenericTask to manually update the consolidation_ind to 9.";
			String comment = "Failed while updating consolidation indicator of the Party with 9 for the PartyID: "
					+ rowIdParty;
			commonUtil.updateErrorStatus(partyXrefType, upsertResponse, Constant.ERROR_ACC_MATCH_EXCLUSION, rowIdParty);
			processCreateTaskRequest(null, rowIdParty, "FinalReview", title, comment);
		}
		if (exclusionPatternExists) {
			LOG.debug("[upsertIndividualAccount] By passing match merge process for " + rowIdParty);
			LOG.info(
					"Match exclusion pattern exists for the party, bypassing match & merge process and creating task for DS");

			String title = "Match Exclusion";
			String comment = "Match Exclusion pattern is present for the PartyID: " + rowIdParty;
			processCreateTaskRequest(null, rowIdParty, "FinalReview", title, comment);
			needToMerge = Boolean.FALSE;
		} else {
			needToMerge = Boolean.TRUE;
		}
		return needToMerge;
	}

	public String performProspectMatchAndMerge(PartyXrefType partyXrefType, String rowIdParty,
			MdmUpsertPartyResponse upsertResponse) throws ServiceProcessingException {
		LOG.info("[performProspectMatchAndMerge]: performProspectMatchAndMerge started !");
		String targetRowId = null;
		String targetRowIdAddr = null;
		String targetRowIdProspect = null;
		String rowIdProspect = null;
		String rowIdAddress = null;
		boolean isStrictMatchProspect = false;
		boolean isMergePartySuccess = false;
		boolean isMergeAddressSuccess = false;
		boolean isMergeProspectSuccess = false;
		/*rowIdParty = ((PutResponseDataHolder) dataHolderMap.get(MDMAttributeNames.ENTITY_PARTY)).getRowidObject();
		String rowIdProspect = ((List<PutResponseDataHolder>) dataHolderMap.get(MDMAttributeNames.ENTITY_PROSPECT))
				.get(0).getRowidObject();
		String rowIdAddress = ((List<PutResponseDataHolder>) dataHolderMap.get(MDMAttributeNames.ENTITY_ADDRESS)).get(0)
				.getRowidObject();*/

		Set<String> sourceRowIds = new HashSet<String>();
		sourceRowIds.add(rowIdParty);
		List<PartyChildRowIdData> partyChildDataList = prospectPartyDAO.getPartyChildRowId(sourceRowIds);
		if (CollectionUtils.isEmpty(partyChildDataList)) {
			LOG.debug("[performProspectMatchAndMerge] No Address and Prospect RowID Found");
			rowIdParty = sourceRowIds.iterator().next();
		} else {
			PartyChildRowIdData partyChildData = partyChildDataList.get(0);
			rowIdParty = partyChildData.getRowIdParty();
			rowIdAddress = partyChildData.getRowIdAddr();
			rowIdProspect = partyChildData.getRowIdProspect();
		}
		
		Set<String> rowIds = null;
		int countOfRetry = Integer.parseInt(configProps.getProperty("NoOfRetries"));
		LOG.debug("[performProspectMatchAndMerge] Processing strict match for prospect account ");
		try {
			rowIds = searchProspectDao.findStrictMatchProspect(partyXrefType, rowIdParty);
			LOG.debug("[performProspectMatchAndMerge]: findStrictMatchProspect is Completed successfully !");
		} catch (Exception ex) {
			// mergeInd = false;
			LOG.error("[performProspectMatchAndMerge]: Exception occured while findStrictMatchProspect: ", ex);
			for (int i = 0; i < countOfRetry; i++) {
				try {
					LOG.debug("[performProspectMatchAndMerge]: Retrying findStrictMatchProspect for " + (i + 1) + "th time");
					rowIds = searchProspectDao.findStrictMatchProspect(partyXrefType, rowIdParty);
					LOG.debug("[performProspectMatchAndMerge]: findStrictMatchProspect is successful on attempt no. "
							+ (i + 1));
					isStrictMatchProspect = true;
					// mergeInd = true;
					break;
				} catch (Exception excp) {
					LOG.error("[performProspectMatchAndMerge]: Exception occured in findStrictMatchProspect"
							+ " RetryMechanism on attempt no. " + (i + 1));
					LOG.error("[performProspectMatchAndMerge]: Exception occured in findStrictMatchProspect RetryMechanism");
				}
			}
			if (!isStrictMatchProspect) {
				ServiceProcessingException customException = new ServiceProcessingException(ex);
				customException.setMessage("[performProspectMatchAndMerge]: Exception occured in findStrictMatchProspect "
						+ "RetryMechanism: " + customException.getMessage());
				throw customException;
			}
		}
		if (CollectionUtils.isEmpty(rowIds)) {
			LOG.debug("[performProspectMatchAndMerge] No Strict Match found");
			return rowIdParty;
		} else {
			List<PartyChildRowIdData> partyChildDataListTarget = prospectPartyDAO.getPartyChildRowId(rowIds);
			if (CollectionUtils.isEmpty(partyChildDataListTarget)) {
				LOG.debug("[performProspectMatchAndMerge] No Address and Prospect RowID Found");
				targetRowId = rowIds.iterator().next();
			} else {
				PartyChildRowIdData partyChildData = partyChildDataListTarget.get(0);
				targetRowId = partyChildData.getRowIdParty();
				targetRowIdAddr = partyChildData.getRowIdAddr();
				targetRowIdProspect = partyChildData.getRowIdProspect();
			}
			// needToMerge = Boolean.TRUE;
		}

		try {
			mergeProspectPartyDAO.mergeProspectParties(MDMAttributeNames.PARTY_BO, rowIdParty, targetRowId);
			LOG.debug("[performProspectMatchAndMerge]: mergeProspectParties successful on C_B_PARTY..");
			isMergePartySuccess = true;
			mergeProspectPartyDAO.mergeProspectParties(MDMAttributeNames.ADDRESS_BO, rowIdAddress, targetRowIdAddr);
			LOG.debug("[performProspectMatchAndMerge]: mergeProspectParties successful on C_B_ADDRESS..");
			isMergeAddressSuccess = true;
			if (!Util.isNullOrEmpty(targetRowIdProspect)) {
				mergeProspectPartyDAO.mergeProspectParties(MDMAttributeNames.PARTY_PROSPECT_BO, rowIdProspect,
						targetRowIdProspect);
				LOG.debug("[performProspectMatchAndMerge]: mergeProspectParties successful on C_B_PARTY_PROSPECT..");
				isMergeProspectSuccess = true;
			}
			upsertResponse.getParty().get(0).setROWIDOBJECT(targetRowId.trim());
		} catch (Exception ex) {
			// mergeInd = false;
			LOG.error("[performProspectMatchAndMerge]: Exception occured while mergeProspectParties: ", ex);
			for (int i = 0; i < countOfRetry; i++) {
				try {
					if (!isMergePartySuccess) {
						LOG.debug("[performProspectMatchAndMerge]: Retrying mergeProspectParties for C_B_PARTY " + (i + 1)
								+ "th time");
						mergeProspectPartyDAO.mergeProspectParties(MDMAttributeNames.PARTY_BO, rowIdParty, targetRowId);
						LOG.debug(
								"[performProspectMatchAndMerge]:mergeProspectParties successful on C_B_PARTY in attempt no. "
										+ (i + 1));
						isMergePartySuccess = true;
						// mergeInd = true;
						break;
					}
				} catch (Exception excp) {
					LOG.error("[performProspectMatchAndMerge]: Exception occured in mergeProspectParties for C_B_PARTY"
							+ " RetryMechanism on attempt no. " + (i + 1));
					LOG.error(
							"[performProspectMatchAndMerge]: Exception occured in mergeProspectParties RetryMechanism for C_B_PARTY");
				}
			}
			if (!isMergePartySuccess) {
				ServiceProcessingException customException = new ServiceProcessingException(ex);
				commonUtil.updateErrorStatus(partyXrefType, upsertResponse, Constant.ERROR_ACC_MERGE_FAIL, rowIdParty);
				customException.setMessage(
						"[performProspectMatchAndMerge]: Exception occured in mergeProspectParties for C_B_PARTY "
								+ "RetryMechanism: " + customException.getMessage());
				throw customException;
			}

			for (int i = 0; i < countOfRetry; i++) {
				try {
					if (!isMergeAddressSuccess) {
						LOG.debug("[performProspectMatchAndMerge]: Retrying mergeProspectParties for C_B_ADDRESS " + (i + 1)
								+ "th time");
						mergeProspectPartyDAO.mergeProspectParties(MDMAttributeNames.ADDRESS_BO, rowIdAddress,
								targetRowIdAddr);
						LOG.debug(
								"[performProspectMatchAndMerge]:mergeProspectParties successful on C_B_ADDRESS in attempt no. "
										+ (i + 1));
						isMergeAddressSuccess = true;
						// mergeInd = true;
						break;
					}
				} catch (Exception excp) {
					LOG.error("[performProspectMatchAndMerge]: Exception occured in mergeProspectParties for C_B_ADDRESS"
							+ " RetryMechanism on attempt no. " + (i + 1));
					LOG.error(
							"[performProspectMatchAndMerge]: Exception occured in mergeProspectParties RetryMechanism for C_B_ADDRESS");
				}
			}
			if (!isMergeAddressSuccess) {
				ServiceProcessingException customException = new ServiceProcessingException(ex);
				commonUtil.updateErrorStatus(partyXrefType, upsertResponse, Constant.ERROR_ACC_MERGE_FAIL, rowIdParty);
				customException.setMessage(
						"[performProspectMatchAndMerge]: Exception occured in mergeProspectParties for C_B_ADDRESS "
								+ "RetryMechanism: " + customException.getMessage());
				throw customException;
			}

			for (int i = 0; i < countOfRetry; i++) {
				try {
					if (!isMergeProspectSuccess) {
						LOG.debug("[performProspectMatchAndMerge]: Retrying mergeProspectParties for C_B_PARTY_PROSPECT "
								+ (i + 1) + "th time");
						if (!Util.isNullOrEmpty(targetRowIdProspect)) {
							mergeProspectPartyDAO.mergeProspectParties(MDMAttributeNames.PARTY_PROSPECT_BO,
									rowIdProspect, targetRowIdProspect);
							LOG.debug(
									"[performProspectMatchAndMerge]:mergeProspectParties successful on C_B_PARTY_PROSPECT in attempt no. "
											+ (i + 1));
							isMergeProspectSuccess = true;
						}
						// mergeInd = true;
						break;
					}
				} catch (Exception excp) {
					LOG.error(
							"[performProspectMatchAndMerge]: Exception occured in mergeProspectParties for C_B_PARTY_PROSPECT"
									+ " RetryMechanism on attempt no. " + (i + 1));
					LOG.error(
							"[performProspectMatchAndMerge]: Exception occured in mergeProspectParties RetryMechanism for C_B_PARTY_PROSPECT");
				}
			}
			if (!isMergeProspectSuccess) {
				ServiceProcessingException customException = new ServiceProcessingException(ex);
				commonUtil.updateErrorStatus(partyXrefType, upsertResponse, Constant.ERROR_ACC_MERGE_FAIL, rowIdParty);
				customException.setMessage(
						"[performProspectMatchAndMerge]: Exception occured in mergeProspectParties for C_B_PARTY_PROSPECT "
								+ "RetryMechanism: " + customException.getMessage());
				throw customException;
			}

		}
		PutResponseDataHolder putRespDataPartyChild = null;
		childMultiMergeParty(partyXrefType, upsertResponse, putRespDataPartyChild);
		try {
			// Perform Tokenization after Match & Merge
			PutResponseDataHolder putTokenizeDataParty = new PutResponseDataHolder();
			String survivorRowid = targetRowId;
			
				if (!Util.isNullOrEmpty(survivorRowid)) {
					putTokenizeDataParty.setRowidObject(survivorRowid);
					putTokenizeDataParty.setActionType("Merge");
					processTokenizeRequest(putTokenizeDataParty);
				}
		} catch (SiperianServerException sifExcp) {
			LOG.error("SiperianServerException occured while processing TokenizeRequest for Account after MatchMerge.",
					sifExcp);
		} catch (Exception excp) {
			LOG.error("Exception occured while processing TokenizeRequest for Account after MatchMerge.", excp);
			ServiceProcessingException customException = new ServiceProcessingException(excp);
			customException
					.setMessage("Exception occured while processing Tokenize request for Account after MatchMerge. "
							+ customException.getMessage());
		}
		LOG.info("[performProspectMatchAndMerge]: performProspectMatchAndMerge EXIT !");
		return targetRowId;
	}

	/**
	 * Create error response for account upsert
	 * 
	 * @param upsertResponse
	 * @param errorPropId
	 * @param srcPkey
	 * @param e
	 */
	private void createAccountUpsertErrorResponse(MdmUpsertPartyResponse upsertResponse, String errorPropId,
			String srcPkey, Exception e) {
		LOG.debug("[createAccountUpsertErrorResponse] START::srcPkey::" + srcPkey + ", errorPropId::" + errorPropId);
		PartyUpsertRespType partyUpsertRespType = new PartyUpsertRespType();
		if (srcPkey == null) {
			partyUpsertRespType.setErrorMsg(messagesProp.getProperty(errorPropId));
		} else {
			srcPkey = srcPkey.replaceAll(Constant.ADB_ACT_PREFIX, "");
			partyUpsertRespType.setSRCSYSTEMID(srcPkey);
			partyUpsertRespType
					.setErrorMsg("Error in SRC PKEY::" + srcPkey + "::" + messagesProp.getProperty(errorPropId));
		}
		if (e != null) {
			partyUpsertRespType.setErrorMsg(partyUpsertRespType.getErrorMsg() + e.getMessage());
		}
		upsertResponse.getParty().add(partyUpsertRespType);
		LOG.debug("[createAccountUpsertErrorResponse] EXIT::Error Message::" + partyUpsertRespType.getErrorMsg());
	}

	private void childMultiMergeParty(PartyXrefType upsertParty, MdmUpsertPartyResponse upsertPartyResponse,
			PutResponseDataHolder putRespDataParty) throws ServiceProcessingException {

		PartyType survivingPartyProfileFromBO = null;
		String survivingPartyRowid = upsertPartyResponse.getParty().get(0).getROWIDOBJECT();
		LOG.info("Party rowid_object of merged/newly created record = " + survivingPartyRowid);
		PerformanceLoggerUtil perfLog = new PerformanceLoggerUtil();

		int multiMergecountOfRetry = Integer.parseInt(configProps.getProperty("NoOfRetries"));
		boolean isMergeRetrySuccess = false;

		// Fetch base object records for new party or surviving party using
		// canonical structure
		survivingPartyProfileFromBO = getPartyDAO.getBOPartyForAdobe(survivingPartyRowid);

		// Merge Address and Communication child entities
		try {
			mergeProcessMultipleChild(survivingPartyProfileFromBO, upsertPartyResponse);
			LOG.debug("Multi-Merge is successful on Address and Communication child entity");
		} catch (Exception servExcp) {
			// mergeInd = false;
			LOG.error("Exception occured while Multi-Merge on Address and Communication: ", servExcp);
			for (int i = 0; i < multiMergecountOfRetry; i++) {
				try {
					LOG.debug("Retrying Multi-Merge process for " + (i + 1) + "th time");
					mergeProcessMultipleChild(survivingPartyProfileFromBO, upsertPartyResponse);
					LOG.debug("Multi-Merge is successful on attempt no. " + (i + 1));
					isMergeRetrySuccess = true;
					// mergeInd = true;
					break;
				} catch (Exception excp) {
					LOG.error("Exception occured in Multi-Merge Retry on attempt no. " + (i + 1));
					LOG.error("Exception occured in Multi-Merge RetryMechanism...");
				}
			}
			if (!isMergeRetrySuccess) {
				ServiceProcessingException customException = new ServiceProcessingException(servExcp);
				customException.setMessage(
						"SIF exception occured while processing Multi-Merge on Address and Communication: "
								+ customException.getMessage());
				commonUtil.updateErrorStatus(upsertParty, upsertPartyResponse, Constant.ERROR_ACC_MERGE_FAIL,
						survivingPartyRowid);
				throw customException;
			}

		}
		// }

		perfLog.printLog(Constant.PERF_LOG_FLOW_UPSERT_ADB, upsertParty.getXREF().get(0).getSRCPKEY(), "STEP 13",
				"Match and Merge process Done");

	}

	public void mergeProcessMultipleChild(PartyType partyType, MdmUpsertPartyResponse upsertPartyResponse)
			throws ServiceProcessingException {

		LOG.info("Executing mergeProcessMultipleChild()");
		Map<String, List<String>> addrTypeMap = new HashMap<String, List<String>>();
		Map<String, List<String>> commTypeMap = new HashMap<String, List<String>>();
		List<String> addrRowidList = null;
		List<String> commRowidList = null;

		UserTransaction transaction = null;
		SiperianClient siperianClient = null;

		try {
			
			LOG.info("Preparing type-wise rowid_object list for Address");
			for (int indx = 0; indx < partyType.getAddress().size(); indx++) {
				String addrType = partyType.getAddress().get(indx).getADDRTYPE();
				if (!addrTypeMap.containsKey(addrType)) {
					addrRowidList = new ArrayList<String>();
					addrTypeMap.put(addrType, addrRowidList);
				}
				addrTypeMap.get(addrType).add(partyType.getAddress().get(indx).getROWIDADDRESS());
			}

			LOG.info("Preparing type-wise rowid_object list for Communication");
			
			for (int indx = 0; indx < partyType.getCommunication().size(); indx++) {
				String commType = partyType.getCommunication().get(indx).getCOMMTYPE();
				if (!commTypeMap.containsKey(commType)) {
					commRowidList = new ArrayList<String>();
					commTypeMap.put(commType, commRowidList);
				}
				commTypeMap.get(commType).add(partyType.getCommunication().get(indx).getROWIDCOMMUNICATION());
			}

			LOG.info("Type-wise rowid_object list for Communication created");
		} catch (Exception ex) {
			LOG.error("Exception occured while preparing child entity records for Multi-merge: ", ex);
			ServiceProcessingException customException = new ServiceProcessingException(ex);
			customException.setMessage("Failed to prepare child entity records for Multi-merge: " + ex.getMessage());
			throw customException;
		}

		try {

			siperianClient = checkOut();
			transaction = ((EjbSiperianClient) siperianClient).createTX(300000);
			transaction.begin();

			LOG.info("Calling multi-merge process for Address and Communication");
			// call multi-merge for address and Communication child
			
			Map<String, String> typeToSurvivingRowidMapAddr = multiMergeProcessChild(MDMAttributeNames.ADDRESS_BO,
					addrTypeMap, siperianClient);
			Map<String, String> typeToSurvivingRowidMapComm = multiMergeProcessChild(MDMAttributeNames.COMM_BO,
					commTypeMap, siperianClient);

			transaction.commit();
			LOG.info("Multi-merge process for  Address and Communication completed");

			if (upsertPartyResponse != null) {
				upsertPartyResponse.setStatus(upsertPartyResponse.getStatus() + "\n ");
				if (typeToSurvivingRowidMapAddr != null && typeToSurvivingRowidMapAddr.size() > 1) {
					upsertPartyResponse.setStatus(upsertPartyResponse.getStatus() + "Address records got merged.");
				}
				if (typeToSurvivingRowidMapComm != null && typeToSurvivingRowidMapComm.size() > 1) {
					upsertPartyResponse
							.setStatus(upsertPartyResponse.getStatus() + "Communication records got merged.");
				}
			}
		} catch (ServiceProcessingException excp) {
			LOG.error("Exception in Merge operation for child entities: ", excp);

			try {
				transaction.rollback();
				LOG.debug("Transaction rolled back successfully.");
			} catch (SystemException txExcp) {
				LOG.error("Failed to rollback transaction for Merge operation : " + txExcp.toString());
			}
			throw excp;
		} catch (Exception ex) {
			LOG.error("Exception occured in Merge operation for child entities: ", ex);
			try {
				transaction.rollback();
				LOG.debug("Transaction rolled back successfully.");
			} catch (SystemException txExcp) {
				LOG.error("Failed to rollback transaction for Merge operation: " + txExcp.toString());
				txExcp.printStackTrace();
			}
			ServiceProcessingException customException = new ServiceProcessingException(ex);
			customException.setMessage("Failed to process Merge operation for child entities: " + ex.getMessage());
			throw customException;
		} finally {
			checkIn(siperianClient);
		}

		LOG.info("Executed mergeProcessMultipleChild()");
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	private Map<String, String> multiMergeProcessChild(String baseObjTable, Map<String, List<String>> childTypeMap,
			SiperianClient siperianClient) throws ServiceProcessingException {
		LOG.info("Executing multiMergeProcessChild()");
		List<String> recordList = null;
		List<Integer> intRecordList = null;
		String childRecType = null;
		Map<String, String> recIdToSurvivingRowidMap = new HashMap<String, String>();
		String survivingRowid = null;

		try {
			LOG.info("Before executing child multi-merge process on " + baseObjTable);
			for (Entry entry : childTypeMap.entrySet()) {
				childRecType = entry.getKey().toString();
				recordList = (List<String>) entry.getValue();

				// if more than one rowid in list, go for multi-merge
				if (recordList != null && recordList.size() > 1) {
					updateCI(recordList, baseObjTable,siperianClient);
					MultiMergeRequest request = new MultiMergeRequest();
					ArrayList<RecordKey> recordKeys = new ArrayList<RecordKey>();
					StringBuilder rowIds = new StringBuilder();
					//request.setOrsId(configProps.getProperty("orsId"));
					intRecordList = new ArrayList<Integer>();
					for (String str : recordList) {
						intRecordList.add(new Integer(str.trim()));
					}
					Collections.sort(intRecordList); // To make sure existing
														// rowid survives

					for (int indx = 0; indx < intRecordList.size(); indx++) {
						RecordKey key = new RecordKey();
						key.setRowid(Util.padSpace(intRecordList.get(indx).toString(), 14));
						recordKeys.add(key);
						rowIds.append(intRecordList.get(indx));
						rowIds.append(", ");
						if (indx == 0) {
							survivingRowid = intRecordList.get(indx).toString();
						}
						recIdToSurvivingRowidMap.put(intRecordList.get(indx).toString(), survivingRowid);
					}

					request.setRecordKeyList(recordKeys);

					Record record = new Record();
					record.setSiperianObjectUid(SiperianObjectType.BASE_OBJECT.makeUid(baseObjTable));
					request.setRecord(record);

					LOG.info("To multi-merge on record_type: " + childRecType + " | Rowid_objects to merge: "
							+ rowIds.toString());
					LOG.info("========================================"+baseObjTable+"====================================================");
					ArrayList recList = request.getRecordKeyList();
					LOG.info("RecordKeyList:");
					for(Object ob : recList){
						LOG.info(ob.toString());
					}
					LOG.info("SiperianObjectUid:"+request.getSiperianObjectUid());
					LOG.info("getRequestName:"+request.getRequestName());
					LOG.info("getTaskId:"+request.getTaskId());
					LOG.info("============================================================================================");
					MultiMergeResponse response = (MultiMergeResponse) siperianClient.process(request);

					childMergeInd = true;
					LOG.debug(" Message from MultiMergeResponse :" + response.getMessage());
				} else {
					LOG.info("Sufficient records not found for multi-merge for type " + childRecType);
				}
			} // Modified code
		} catch (SiperianServerException sifExcp) {
			childMergeInd = false;
			LOG.error("SiperianServerException occured while processing Child multi-Merge operation: ", sifExcp);
			ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
			customException.setMessage("SIF exception occured while processing muti-Merge request for " + baseObjTable
					+ ": " + sifExcp.getMessage());
			throw customException;
		} catch (Exception ex) {
			childMergeInd = false;
			LOG.error("Child Merge operation failed with exception for " + baseObjTable, ex);
			ServiceProcessingException customException = new ServiceProcessingException(ex);
			customException.setMessage("Failed to process Merge request for " + baseObjTable + ": " + ex.getMessage());
			throw customException;
		}
		LOG.info("Executed multiMergeProcessChild()");

		return recIdToSurvivingRowidMap;
	}

	private void updateCI(List<String> recordList, String baseObjTable) throws ServiceProcessingException {
		LOG.debug("Inside updateCI()");
		Connection jdbcConn = null;
		Statement statement = null;
		JDBCConnectionProvider jDBCConnectionProvider = null;
		int rowCnt = 0;
		StringBuilder sqlQry = new StringBuilder();

		sqlQry.append("UPDATE ");
		sqlQry.append(baseObjTable);
		sqlQry.append(" SET CONSOLIDATION_IND = '4' WHERE ROWID_OBJECT in (");
		for (String partyRowId : recordList) {
			sqlQry.append("'" + partyRowId.trim() + "',");
		}
		sqlQry.deleteCharAt(sqlQry.length() - 1).toString();
		sqlQry.append(")");

		LOG.debug("SQL in updateCI()--> " + sqlQry);

		try {
			jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
			jdbcConn = jDBCConnectionProvider.getJdbcConnectionFromDS();
			statement = jdbcConn.createStatement();
			rowCnt = statement.executeUpdate(sqlQry.toString());

			// jdbcConn.commit();
			LOG.debug("RowidObject Updated for CI : " + rowCnt);
			// LOG.debug("APPRVD_FOR_MERGE value updated to N in C_B_PARTY for
			// partyID: " + survivingRowidObject);

		} catch (SQLException exp) {
			LOG.error("Caught SQLException in updateCI() ", exp);

		} finally {
			try {
				// Closing connections
				// if (resultSet != null) resultSet.close();
				if (statement != null)
					statement.close();
				if (jdbcConn != null)
					jdbcConn.close();
			} catch (SQLException exp) {
				LOG.error("SQLexp caught in updateCI(): ", exp);
			}

		}

		LOG.debug(" Executed updateCI() successfully ");
	}

	/**
	 * Processing Account-Contact Relation mapping
	 * <ol>
	 * <li>Retrieve data from temp table MDM_RTS_MRKT_ACC_CONTACT_REL</li>
	 * <li>Create composite list of contact PKEY from incoming data & temp table
	 * data</li>
	 * <li>Check in XRef for those Pkeys</li>
	 * <li>If found then CleasePut in Golden record and delete from temp table
	 * </li>
	 * <li>Else insert data in temp table for any new incoming data</li>
	 * </ol>
	 * 
	 * @param upsertResponse
	 * @param partyContactRelList
	 * @param rowIdParty
	 * @param srcSystem
	 * @param srcPkey
	 * @throws ServiceProcessingException
	 */
	private void processAcntCntctRel(MdmUpsertPartyResponse upsertResponse,
			List<PartyContactRelationshipXrefType> partyContactRelList, String rowIdParty, String srcSystem,
			String srcPkey, String boClassCode) throws ServiceProcessingException {
		LOG.debug("[processAcntCntctRel] ENTER");
		List<AcntCntctRelData> actnCntctRelDataList = prospectPartyDAO.getPendingAcntCntctRel(srcSystem, srcPkey,
				boClassCode, false);
		Map<String, Boolean> contactPkeyMap = new HashMap<String, Boolean>();
		if (!CollectionUtils.isEmpty(partyContactRelList)) {
			for (PartyContactRelationshipXrefType partyContactRel : partyContactRelList) {
				if (!Util.isNullOrEmpty(partyContactRel.getSRCPKEY())) {
					contactPkeyMap.put(partyContactRel.getSRCPKEY(), Boolean.FALSE);
				}
			}
		}

		if (!CollectionUtils.isEmpty(actnCntctRelDataList)) {
			for (AcntCntctRelData actnCntctRelData : actnCntctRelDataList) {
				contactPkeyMap.put(actnCntctRelData.getCntctSrcPkey(), Boolean.TRUE);
			}
		}

		// For Prospect Account
		if (CollectionUtils.isEmpty(contactPkeyMap.keySet())) {
			LOG.debug("[processAcntCntctRel] No Contact Rel to process");
		} else {
			LOG.debug("[processAcntCntctRel] contactPkeyMap to process for Account::" + contactPkeyMap);
			String contactPkeys = StringUtils.collectionToDelimitedString(contactPkeyMap.keySet(), Constant.STR_COMMA,
					Constant.STR_SINGLE_QUOTE, Constant.STR_SINGLE_QUOTE);
			List<CntctPkeyRowIdRelData> existingContactRowidList = prospectPartyDAO
					.getAdobeContactRowIdsFromPkeys(contactPkeys);
			List<String> pkeysToDeleteFromTempTable = new ArrayList<String>();
			List<String> pkeysToInsertIntoTempTable = new ArrayList<String>();
			if (!CollectionUtils.isEmpty(existingContactRowidList)) {
				cleansePutAccountContactRel(upsertResponse,
						existingContactRowidList, rowIdParty, srcSystem, srcPkey, null);
				// for (PutResponseDataHolder actnCntctDataHolder :
				// actnCntctDataHolderList) {
				for (CntctPkeyRowIdRelData existingContactRowid : existingContactRowidList) {
					if (existingContactRowid.getIsCleansePut()) {
						String curContactPkey = existingContactRowid.getContactPkey();
						if (contactPkeyMap.containsKey(curContactPkey) && contactPkeyMap.get(curContactPkey)) {
							pkeysToDeleteFromTempTable.add(curContactPkey);
						}
						contactPkeyMap.remove(curContactPkey);
					}
				}
			}
			for (String pkey : contactPkeyMap.keySet()) {
				if (!contactPkeyMap.get(pkey)) {
					pkeysToInsertIntoTempTable.add(pkey);
				}
			}
			prospectPartyDAO.insertPkeysInTempTable(pkeysToInsertIntoTempTable, srcSystem, srcPkey, rowIdParty, false);
			prospectPartyDAO.deletePkeysFromTempTable(
					StringUtils.collectionToDelimitedString(pkeysToDeleteFromTempTable, Constant.STR_COMMA,
							Constant.STR_SINGLE_QUOTE, Constant.STR_SINGLE_QUOTE),
					srcSystem, srcPkey, Boolean.TRUE, Boolean.FALSE);
		}
		
				LOG.debug("[processAcntCntctRel] EXIT::");
	}

	// Method for CreatingTask for Administrator
	private void processCreateTaskRequest(String tgtPartyRowId, String rowIdObject, String taskType, String title,
			String comment) {

		LOG.info("Executing processCreateTaskRequest()");
		SiperianClient siperianClient = null;

		try {
			String mergeOwnerUID = configProps.getProperty("mergeOwnerUID");
			String ownerUid = configProps.getProperty("ownerUID");
			String subjectAreaUID = configProps.getProperty("subjectAreaUID");

			CreateTaskResponse response = null;
			CreateTaskRequest request = new CreateTaskRequest();
			TaskData taskData = new TaskData();

			if (taskType.equalsIgnoreCase("Merge")) {
				taskData.setOwnerUid(mergeOwnerUID);
				taskData.setPriority(1);

			} else {
				taskData.setOwnerUid(ownerUid);

			}

			TaskRecord taskRecord = new TaskRecord();
			RecordKey recordKey = new RecordKey();
			taskRecord.setSiperianObjectUid(SiperianObjectType.BASE_OBJECT.makeUid(MDMAttributeNames.PARTY_BO));
			recordKey.setRowid(rowIdObject);
			LOG.debug("rowIdObject: " + rowIdObject);
			taskRecord.setRecordKey(recordKey);
			List<TaskRecord> recordList = new ArrayList<TaskRecord>();
			recordList.add(taskRecord);

			if (taskType.equalsIgnoreCase("Merge")) {

				// for (HighestScoreRecordHolder srcRecHolder :
				// mergeSorceHolderMap.values())
				// tgtPartyRowId = srcRecHolder.getPartyRowIDObject();

				TaskRecord taskRecord2 = new TaskRecord();
				taskRecord2.setSiperianObjectUid(SiperianObjectType.BASE_OBJECT.makeUid(MDMAttributeNames.PARTY_BO));
				RecordKey recordKey2 = new RecordKey();
				recordKey2.setRowid(tgtPartyRowId);
				LOG.debug("tgtPartyRowId :" + tgtPartyRowId);
				taskRecord2.setRecordKey(recordKey2);
				recordList.add(0, taskRecord2);
			}

			taskData.setTaskRecords(recordList);
			request.setTaskData(taskData);
			taskData.setTitle(title);
			taskData.setComment(comment);

			Calendar cal = Calendar.getInstance();
			cal.setTime(new Date(System.currentTimeMillis()));
			cal.add(Calendar.DATE, 7);

			taskData.setDueDate(cal.getTime());
			// taskData.setSubjectAreaUid("SUBJECT_AREA.test|Person");
			taskData.setSubjectAreaUid(subjectAreaUID);
			// taskData.setTaskType("ReviewNoApprove");
			taskData.setTaskType(taskType);

			siperianClient = (SiperianClient) checkOut();

			LOG.info("processing CreateTaskRequest");
			response = (CreateTaskResponse) siperianClient.process(request);
			LOG.info("CreateTaskResponse result: " + response.getMessage());
			LOG.info("CreateTaskResponse taskId: " + response.getTaskId());
			LOG.info("CreateTaskResponse interactionId: " + response.getInteractionId());
			LOG.info("after response");
		} catch (Exception excp) {
			LOG.error("Caught Exception in CreateTaskRequest Error Message: " + excp);
		} finally {
			checkIn(siperianClient);
		}
		LOG.info("Executed processCreateTaskRequest()");
	}

	/**
	 * Checking the given rowid object falls under match exclusion pattern
	 * 
	 * @param rowidobject
	 * @return
	 * @throws ServiceProcessingException
	 */
	private boolean isMatchExclusionPatternExists(String rowidobject) throws ServiceProcessingException {

		boolean exclusionPatternExists = false;
		int patternExist = getPartyDAO.checkExclusionPatternProspect(rowidobject);
		if (patternExist > 0) {
			exclusionPatternExists = true;
			getPartyDAO.updatePartyConsolidationInd(rowidobject);
		}

		return exclusionPatternExists;
	}

	private String getRowidFromPkey(XREFType xref, String BO) {
		LOG.info("Execute getRowidFromPkey()");
		String rowidObject = null;
		try {
			GetRequest getReq = new GetRequest();
			getReq.setSiperianObjectUid(SiperianObjectType.BASE_OBJECT.makeUid(BO));
			RecordKey recordKey = new RecordKey();
			recordKey.setSourceKey(xref.getSRCPKEY());
			recordKey.setSystemName(xref.getSRCSYSTEM());
			getReq.setRecordKey(recordKey);
			SiperianClient siperianClient = (SiperianClient) checkOut();
			GetResponse getResp = (GetResponse) siperianClient.process(getReq);
			rowidObject = getResp.getRecordKey().getRowid();
			LOG.info("Party rowid_object of newly created record = " + rowidObject);

		} catch (Exception exp) {
			LOG.error("Error getting rowidObject for pkey " + xref.getSRCPKEY());
			// return null;
		}
		return rowidObject;
	}

	private void setUCNSeq(String rowidObject, String partyType) throws ServiceProcessingException {

		String ucnValue = null;
		try {
			// Get the next UCN value from Sequence Function
			ucnValue = prospectPartyDAO.getNextUCNValue(partyType);
			if (!Util.isNullOrEmpty(ucnValue)) {
				// Put the fetched UCN into
				putUCNRequest(rowidObject, ucnValue);
			}

		} catch (ServiceProcessingException spExcp) {
			LOG.error("Error in setUCNSeq(): " + spExcp.getMessage());
			throw spExcp;
		}
	}

	// Put UCN in base object & XREF tables.
	public void putUCNRequest(String rowidObject, String ucnValue) throws ServiceProcessingException {
		LOG.info("Executing putUCNRequest()");

		SiperianClient siperianClient = null;
		UserTransaction transaction = null;
		String systemUser = "admin";

		try {
			PutRequest putRequest = new PutRequest();
			PutResponse putResponse = null;
			// String systemUser = "Admin";
			String srcSystem = "Admin"; // trimming not required
			String srcPkey = null; // trimming not required
			String srcRowid = rowidObject; // trimming not required
			LOG.info("Executing PutRequest with src_system=" + srcSystem + " | scr_pkey=" + srcPkey + " | rowid_object="
					+ srcRowid);

			// Fetch Siperian Object from
			siperianClient = (SiperianClient) checkOut();
			// create transaction - commit if Delete and Put requests both
			// succeeded
			transaction = ((EjbSiperianClient) siperianClient).createTX(1200); // in
																				// seconds
			transaction.begin();

			// prepare PutRequest
			RecordKey recordKey = new RecordKey();
			recordKey.setRowid(srcRowid);
			recordKey.setSystemName(srcSystem);
			putRequest.setRecordKey(recordKey);

			Record record = new Record();
			record.setSiperianObjectUid(SiperianObjectType.BASE_OBJECT.makeUid(MDMAttributeNames.PARTY_BO));
			record.setField(new Field(MDMAttributeNames.SRC_UPDT_BY, systemUser));
			record.setField(new Field(PartyAttributes.UCN, ucnValue));
			record.setField(new Field(PartyAttributes.STATUS_CD, "A"));

			putRequest.setRecord(record);
			// execute Put request
			putResponse = (PutResponse) siperianClient.process(putRequest);

			LOG.info("Committing UCN transaction");
			transaction.commit();
			LOG.info("Put request for UCN assignment processed successfully: Action Type = "
					+ putResponse.getActionType() + " | Msg = " + putResponse.getMessage());

		} catch (SiperianServerException sifExcp) {
			LOG.error("SiperianServerException occured while assigning UCN by Put request: ", sifExcp);
			ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
			customException.setMessage(
					"SiperianServerException occured while assigning UCN by Put request: " + sifExcp.getMessage());
			throw customException;
		} catch (Exception excp) {
			LOG.error("Exception occured while assigning UCN by Put request: ", excp);
			ServiceProcessingException customException = new ServiceProcessingException(excp);
			customException.setMessage("Exception occured while assigning UCN by Put request: " + excp.getMessage());
			throw customException;
		} finally {
			checkIn(siperianClient);
		}

		LOG.info("Executed putUCNRequest()");

	}

	/**
	 * Updates Prospect Account
	 * 
	 * @param partyXrefType
	 * @param srcSystem
	 * @param srcPkey
	 * @param upsertResponse
	 */
	private void updateProspectAccount(PartyXrefType partyXrefType, String srcSystem, String srcPkey,
			Integer mrktRowCount, MdmUpsertPartyResponse upsertResponse) {
		LOG.debug("[updateProspectAccount] ENTER");
		String rowIdParty = null;
		try {
			Boolean isOnlyUpdatePropect = (mrktRowCount == 1);
			if (!isOnlyUpdatePropect) {
				rowIdParty = prospectPartyDAO.getPartyRowIdBySrcPkey(srcPkey, srcSystem);
				isOnlyUpdatePropect = searchProspectDao.findSelfMatchProspect(partyXrefType, rowIdParty);
			}
			LOG.debug("[updateProspectAccount] isOnlyUpdatePropect::" + isOnlyUpdatePropect);
			// BRD 3.5.7
			/**
			 * 
			 * If the incoming account only matches with an Adobe cluster with
			 * only one record, MDM will update the prospect account record and
			 * continue to the Customer Deduplication Rule set.
			 */
			if (isOnlyUpdatePropect) {
				if (partyXrefType.getPartyRel() != null) {
					partyXrefType.getPartyRel().getPARTYPERSONREL().clear();
				}
			} // BRD 3.5.8
			/**
			 * If the incoming account matches with an Adobe cluster with multiple
			 * records, MDM will perform the following: o Soft delete the
			 * prospect account/contact relationship o Unmerge prospect account
			 * match from existing cluster o Update record with data from
			 * prospect account o Create pending relationship with best
			 * match/newly created account id and inbound contact id
			 * 
			 */
			else {
				selfMatchFail = true;
				//prospect self match is failed so updating SEND_FOR_DNB
				putProcessStateInd(null, Constant.SEND_FOR_DNB, rowIdParty,"Admin");
				
				//getting contact rel rowid to removed account contact relationship
				List<String> contactRowIdList = prospectPartyDAO.getContactRowIdsByAccountPkey(srcPkey);
				
				//unmerge req srcPkey and srcSystem data from existing cluster
				UnmergeResponse unMergeResponse = mergeProspectPartyDAO.unMergeProspectParties(srcPkey, srcSystem);
				
				if(contactRowIdList!=null && !CollectionUtils.isEmpty(contactRowIdList)){
				String contactRowIds = StringUtils.collectionToDelimitedString(contactRowIdList,
						Constant.STR_COMMA, Constant.STR_SINGLE_QUOTE, Constant.STR_SINGLE_QUOTE);
				
				List<String> contactRelRowIdList = getcontactRelRowId(contactRowIds,rowIdParty);
				
				String rowIdUnmergedCluster = unMergeResponse.getRecordKey().getRowid();
				
				if (!CollectionUtils.isEmpty(contactRelRowIdList)) {
					if (prospectPartyDAO.isRootUnmerge(rowIdUnmergedCluster, srcPkey, srcSystem)) {
						LOG.debug("[processUpsertRequestForIndividualAccount] Root Unmerge. Contacts will be associated with::"+ rowIdUnmergedCluster);
						
						//soft deleting account contact relationship in C_B_PARTY_REL
						deleteProspectPartyDAO.deleteContactRel(contactRelRowIdList);
						
						for (String contactRowId : contactRowIdList) {
							
							int cleansePutAccountContactcountOfRetry = Integer.parseInt(configProps.getProperty("NoOfRetries"));
							boolean iscleansePutRetrySuccess = false;
							try {
								cleansePutAccountContactRel(upsertResponse, contactRowId, rowIdUnmergedCluster,
										srcSystem, srcPkey, null);
							} catch (Exception servExcp) {
								/** US478 : Retry on cleanse Put Start **/
								LOG.error("Exception occured while cleansePut AccountContact: ", servExcp);
								for (int i = 0; i < cleansePutAccountContactcountOfRetry; i++) {
									try {
										LOG.debug("Retrying cleansePut AccountContact for " + (i + 1) + "th time");
										cleansePutAccountContactRel(upsertResponse, contactRowId, rowIdUnmergedCluster,
												srcSystem, srcPkey, null);
										LOG.debug("Retry cleansePut AccountContact is successful on attempt no. "
												+ (i + 1));
										iscleansePutRetrySuccess = true;
										break;
									} catch (Exception excp) {
										LOG.error("Exception occured in cleansePut AccountContact Retry on attempt no. "
												+ (i + 1));
										LOG.error("Exception occured in cleansePut AccountContact RetryMechanism...");
									}

								}
								if (!iscleansePutRetrySuccess) {
									upsertResponse.setErrorMsg(
											"CleansePut operation failed for Account - Contact Rel" + srcPkey);
									ServiceProcessingException customException = new ServiceProcessingException(
											servExcp);
									customException.setMessage(
											"SIF exception occured while processing cleansePut AccountContact : "
													+ customException.getMessage());
									throw customException;
								}
							}

							/** US478 : Retry on cleanse Put END **/

						}
					} else {
						LOG.debug("[updateProspectAccount] NOT a Root Unmerge.");
					}
				}
			}
			} // end 3.5.8

			processCleansePut(partyXrefType, upsertResponse, false);
			rowIdParty = ((PutResponseDataHolder) dataHolderMap.get(MDMAttributeNames.ENTITY_PARTY)).getRowidObject();
			//PutResponseDataHolder putRespDataParty = (PutResponseDataHolder) dataHolderMap.get(MDMAttributeNames.ENTITY_PARTY);

			rowIdParty = performProspectMatchAndMerge(partyXrefType, rowIdParty, upsertResponse);
			
		} catch (ServiceProcessingException servexp) {
			LOG.error("[updateProspectAccount]Caught ServiceProcessingException", servexp);
		} catch (Exception exp) {
			LOG.error("[updateProspectAccount]Caught exception in processMarketingUpsertRequest()", exp);
			createAccountUpsertErrorResponse(upsertResponse, Constant.ERROR_UPSERT_ACCOUNT_EXCEPTION, srcPkey, exp);
		}
		LOG.debug("[updateProspectAccount] EXIT");
	}

	public void upsertMatchMergeProcess(PartyXrefType upsertParty, MdmUpsertPartyResponse upsertPartyResponse,
			boolean retry, boolean executeNextStep, String rowidObject) throws ServiceProcessingException {

	}

	public void upsertUCNStampProcess(PartyXrefType ptyXrefType, MdmUpsertPartyResponse upsertPartyResponse,
			boolean excuteNextStep, boolean retry, String rowidObject) throws ServiceProcessingException {

		LOG.info("Executing upsertUCNStampProcess()");
		int maxCountOfRetry = Integer.parseInt(configProps.getProperty("NoOfRetries"));
		boolean isMaxRetrySuccess = false;
		PerformanceLoggerUtil perfLog = new PerformanceLoggerUtil();
		
		XREFType xref = ptyXrefType.getXREF().get(0);
		String existingUCN = null;
		rowidObject = getRowidFromPkey(xref, "C_B_PARTY");
		
		boolean isLegacyUCN = false;
		try {
			if(!Util.isNullOrEmpty(rowidObject)){
			existingUCN = prospectPartyDAO.checkifUCNExists(rowidObject);
			// Setting UCN value by Calling GET_UCN
			if (Util.isNullOrEmpty(existingUCN)) {
				isLegacyUCN = false;
				LOG.info("UCN for the surviving/new party is Null. Creating UCN for Party ");
				setUCNSeq(rowidObject, null);
				LOG.debug("UCN value successfully assigned.");
				upsertPartyResponse.setStatus(upsertPartyResponse.getStatus() + " UCN value assigned successfully.");
			}
			}
		} catch (ServiceProcessingException spExcp) {

			LOG.error("Failed to set UCN: ", spExcp);
			warning.append("UCN update process failed, Retry \n");
			try {
				if (rowidObject != null) {

					for (int i = 0; i < maxCountOfRetry;) {
						try {
							if (!isLegacyUCN) {
								setUCNSeq(rowidObject, null);
							}
						} catch (Exception e) {
							i++;
						}
						isMaxRetrySuccess = true;
						break;
					}
				}

			} catch (Exception exp) {
				LOG.error("SiperianServerException occured while retrying UCN Stamping for Party");

				isMaxRetrySuccess = false;
			}
			if (!isMaxRetrySuccess) {
				upsertPartyResponse.setErrorMsg("UCN Stamp Process failed: " + spExcp.getMessage());
				validatorUtil.updateErrorStatus(ptyXrefType, upsertPartyResponse,
				Constant.ERROR_ACC_UCN_STAMP_FAIL, rowidObject);
				throw new ServiceProcessingException(Constant.ERROR_ACC_UCN_STAMP_FAIL);
			}

		} catch (Exception Excp) {

			LOG.error("Caught exception while updating UCN: ", Excp);

			warning.append("UCN update process failed, Retry \n");
			try {
				if (rowidObject != null) {

					for (int i = 0; i < maxCountOfRetry;) {
						try {
							if (!isLegacyUCN) {
								setUCNSeq(rowidObject, null);
							}
						} catch (Exception e) {
							i++;
						}
						isMaxRetrySuccess = true;
						break;
					}
				}

			} catch (Exception exp) {
				LOG.error("SiperianServerException occured while retrying TokenizeRequest for Party");

				isMaxRetrySuccess = false;
			}
			if (!isMaxRetrySuccess) {
				upsertPartyResponse.setErrorMsg("UCN update process failed: " + Excp.getMessage());

				validatorUtil.updateErrorStatus(ptyXrefType, upsertPartyResponse,
				 Constant.ERROR_ACC_UCN_STAMP_FAIL, rowidObject);
				throw new ServiceProcessingException(Constant.ERROR_ACC_UCN_STAMP_FAIL);

			}
		}
		perfLog.printLog(Constant.PERF_LOG_FLOW_UPSERT_ADB, ptyXrefType.getXREF().get(0).getSRCPKEY(), "STEP 15",
				"Stamp UCN / Legacy UCN Done");

		LOG.info("Executed upsertUCNStampProcess()");
		if (excuteNextStep) 
		processAcntCntctRel(ptyXrefType, upsertPartyResponse, retry, excuteNextStep, rowidObject);

	}

	public void populateUpsertResponse(PartyXrefType upsertParty, MdmUpsertPartyResponse upsertPartyResponse) {
		// set Response Structure
		try {

			PartyType goldenPartyData = null;
			XREFCopy xrefCopy = null;
			Map<String, List<PartyXrefType>> partyXrefMap = null;
			XREFType xref = upsertParty.getXREF().get(0);
			String survivingPartyRowid = null;
			if (isAccountAssociatedWithCustomerOrDNB) {
				survivingPartyRowid = upsertParty.getROWIDOBJECT();
			} else {
				survivingPartyRowid = getRowidFromPkey(xref, "C_B_PARTY");
			}
			LOG.info("populateUpsertResponse for RowidObject" + survivingPartyRowid);
			// Update C_REPOS_MQ_DATA_CHANGE table to sent flag 99 for ADB
			// records for which ADB record has created
			if (survivingPartyRowid != null) {
				LOG.info("Update C_REPOS_MQ_DATA_CHANGE table to sent flag 99");
				commonUtil.setMsgSentFlagInTable(survivingPartyRowid, Constant.SRC_SYSTEM_ADB);

			} else {
				LOG.error("----------No update on C_REPOS_MQ_DATA_CHANGE ------------");
			}

			if (upsertPartyResponse.getParty().size() > 0) {
				upsertPartyResponse.getParty().clear();
			}

			if (survivingPartyRowid != null) {
				// fetch golden record
				// common package need to be created in MDM to fetch golden copy
				// for customer and prospect

				goldenPartyData = getPartyDAO.getBOPartyForAdobe(survivingPartyRowid.trim());
				partyXrefMap = searchPartyDAO.getXrefRecforAdobeID(survivingPartyRowid.trim());

			}

			if (goldenPartyData != null) {

				PartyUpsertRespType partyUpsertResp = new PartyUpsertRespType();
				Account accInfo = null;
				List<Account> accountList = new ArrayList<Account>();
				Address address = null;
				List<Address> addressList = new ArrayList<Address>();
				Communication communication = null;
				List<Communication> commList = new ArrayList<Communication>();
				Classification classfction = null;
				List<Classification> classificationList = new ArrayList<Classification>();
				PartyOrgExt partyOrgExt = null;
				List<PartyOrgExt> partyOrgExtList = new ArrayList<PartyOrgExt>();
				PartyRel partyRel = null;
				//PartyAccountRelationshipType partyAccountRelationship = null;
				List<PartyAccountRelationshipType> partyAccountRelList = new ArrayList<PartyAccountRelationshipType>();
				int itemIndex = 0;
				// set all column of Party into response
				// if (goldenPartyData != null) {
				// partyUpsertResp = new PartyUpsertRespType();
				partyUpsertResp.setROWIDOBJECT(goldenPartyData.getROWIDOBJECT());
				partyUpsertResp.setSRCSYSTEM(upsertParty.getXREF().get(0).getSRCSYSTEM());
				partyUpsertResp.setSRCSYSTEMID(upsertParty.getXREF().get(0).getSRCPKEY().replaceAll(Constant.ADB_ACT_PREFIX, Constant.STR_BLANK));
				partyUpsertResp.setBOCLASSCODE(goldenPartyData.getBOCLASSCODE());
				partyUpsertResp.setPARTYTYPE(goldenPartyData.getPARTYTYPE());
				partyUpsertResp.setPARTYNAME(goldenPartyData.getPARTYNAME());
				partyUpsertResp.setGEO(goldenPartyData.getGEO());
				partyUpsertResp.setREGION(goldenPartyData.getREGION());
				partyUpsertResp.setSTATUSCD(goldenPartyData.getSTATUSCD());
				partyUpsertResp.setVATREGNBR(goldenPartyData.getVATREGNBR());
				partyUpsertResp.setTAXJURSDCTNCD(goldenPartyData.getTAXJURSDCTNCD());
				partyUpsertResp.setSALESBLOCKCD(goldenPartyData.getSALESBLOCKCD());
				partyUpsertResp.setUCN(goldenPartyData.getUCN());
				partyUpsertResp.setMSGTRKNID(upsertParty.getMSGTRKNID());
				partyUpsertResp.setPHYSICALGEO(goldenPartyData.getPHYSICALGEO());
				partyUpsertResp.setPHYSICALREGION(goldenPartyData.getPHYSICALREGION());
				// retrive child from goldenPartyData
				AccountType accountParam = null;
				boolean isAccountAdded = false;
				String rowidAccount = isAccountExist(goldenPartyData.getROWIDOBJECT());
				for (itemIndex = 0; itemIndex < goldenPartyData.getAccount().size(); itemIndex++) {
					accountParam = goldenPartyData.getAccount().get(itemIndex);
					if (accountParam.getROWIDACCOUNT() != null) {

						LOG.debug("============setting Account");
						accInfo = new Account();

						LOG.debug("accountParam.getROWIDACCOUNT()::"+accountParam.getROWIDACCOUNT().trim());
						LOG.debug("accountParam.getACCTNAME()::"+accountParam.getACCTNAME());
						LOG.debug("goldenPartyData.getPARTYTYPE()::"+goldenPartyData.getPARTYTYPE()+":");
						LOG.debug("accountParam.getACCTTYPE()::"+accountParam.getACCTTYPE()+":");
						LOG.debug("accountParam.getCUSTGROUP()::"+accountParam.getCUSTGROUP());
						accInfo.setROWIDACCOUNT(accountParam.getROWIDACCOUNT().trim());
						accInfo.setACCTNAME(accountParam.getACCTNAME());
						accInfo.setALIASNAME(accountParam.getALIASNAME());
						accInfo.setACCTSTATUS(accountParam.getACCTSTATUS());
						accInfo.setACCTTYPE(accountParam.getACCTTYPE());
						accInfo.setACCOUNTREGION(accountParam.getACCOUNTREGION());
						accInfo.setACCOUNTGEO(accountParam.getACCOUNTGEO());
						accInfo.setMARKET(accountParam.getMARKET());
						accInfo.setCUSTGROUP(accountParam.getCUSTGROUP());
						accInfo.setPRICEGROUP(accountParam.getPRICEGROUP());
						accInfo.setCOMPANYCD(accountParam.getCOMPANYCD());
						accInfo.setACCOUNTVATREGNBR(accountParam.getACCOUNTVATREGNBR());
						accInfo.setTAXTYPE(accountParam.getTAXTYPE());
						accInfo.setACCOUNTTAXJURSDCTNCD(accountParam.getACCOUNTTAXJURSDCTNCD());
						accInfo.setBILLBLOCKCD(accountParam.getBILLBLOCKCD());
						accInfo.setORDRBLOCKCD(accountParam.getORDRBLOCKCD());
						accInfo.setDLVRYBLOCKCD(accountParam.getDLVRYBLOCKCD());
						accInfo.setPOSTBLOCKCD(accountParam.getPOSTBLOCKCD());
						accInfo.setSALEBLOCKCD(accountParam.getSALEBLOCKCD());
						accInfo.setCHANNELID(accountParam.getCHANNELID());
						accInfo.setPARTNERTYPE(accountParam.getPARTNERTYPE());
						accInfo.setVENDORNBR(accountParam.getVENDORNBR());
						accInfo.setDIRECTIND(accountParam.getDIRECTIND());
						accInfo.setNAMEDACCTIND(accountParam.getNAMEDACCTIND());
						accInfo.setNONVALACCTIND(accountParam.getNONVALACCTIND());
						accInfo.setPARTNERIND(accountParam.getPARTNERIND());
						accInfo.setSIEBELROWID(accountParam.getSIEBELROWID());
						accInfo.setSAPCUSTNUMBER(accountParam.getSAPCUSTNUMBER());
						// accInfo.setMDMLEGACYID(accountParam.getMDMLEGACYID());
						accInfo.setSAPNAME1(accountParam.getSAPNAME1());
						accInfo.setSAPNAME2(accountParam.getSAPNAME2());
						accInfo.setSAPNAME3(accountParam.getSAPNAME3());
						accInfo.setSAPNAME4(accountParam.getSAPNAME4());
						// accInfo.setDATASRCSYSTEM(accountParam.getField("DATA_SRC_SYSTEM").getStringValue());
						accInfo.setSalesForceID(accountParam.getSalesForceID());
						accInfo.setDraftAccountFlag(accountParam.getDraftAccountFlag());
						accInfo.setLOCALNAME(accountParam.getLOCALNAME());
						accInfo.setTAXID(accountParam.getTAXID());
						accInfo.setCURRENCYCD(accountParam.getCURRENCYCD());
						accInfo.setPRICEBANDAGGREMENT(accountParam.getPRICEBANDAGGREMENT());
						accInfo.setSITEDESIGNATION(accountParam.getSITEDESIGNATION());
						accInfo.setRESELLLEVEL(accountParam.getRESELLLEVEL());
						accInfo.setPARTNERSHIPSTATUS(accountParam.getPARTNERSHIPSTATUS());
						LOG.debug("===Inserting into Account List===");
						LOG.debug("isAccountAdded::"+isAccountAdded);
						String accountType = "";
						if(!Util.isNullOrEmpty(accountParam.getACCTTYPE())){
							accountType = accountParam.getACCTTYPE().trim();
						}
						if(!isAccountAdded){
							if((!Util.isNullOrEmpty(rowidAccount)) && (rowidAccount.trim().equals(accountParam.getROWIDACCOUNT().trim())) && !(Constant.PARTY_TYPE_PROSPECT_ACCOUNT.equalsIgnoreCase(accountType))){
								accountList.add(accInfo);
								isAccountAdded = true;
								LOG.debug("Added customer account");
							}else if(Util.isNullOrEmpty(rowidAccount) && Constant.PARTY_TYPE_PROSPECT_ACCOUNT.equalsIgnoreCase(accountType)){
								accountList.add(accInfo);
								isAccountAdded = true;
								LOG.debug("Added prospect customer account");
							}
						}
					}

				}
				if(commonUtil.isPartyBillingAddressExist( goldenPartyData.getAddress())){
					addressList=commonUtil.popoulateAddress(goldenPartyData.getAddress(), Constant.ADDRESS_TYPE_BILLING);
					
				}else{
					addressList=commonUtil.popoulateAddress(goldenPartyData.getAddress(), Constant.ADDRESS_TYPE_MAILING);
				}
				
				/*AddressType addrParam = null;
				for (itemIndex = 0; itemIndex < goldenPartyData.getAddress().size(); itemIndex++) {
					addrParam = goldenPartyData.getAddress().get(itemIndex);
					if (addrParam.getROWIDADDRESS() != null) {

						LOG.debug("============setting Address");
						address = new Address();

						address.setROWIDADDRESS(addrParam.getROWIDADDRESS().trim());
						address.setADDRLN1(addrParam.getADDRLN1());
						address.setADDRLN2(addrParam.getADDRLN2());
						address.setADDRLN3(addrParam.getADDRLN3());
						address.setADDRLN4(addrParam.getADDRLN4());
						address.setCITY(addrParam.getCITY());
						address.setCOUNTY(addrParam.getCOUNTY());
						address.setDISTRICT(addrParam.getDISTRICT());
						address.setSTATECD(addrParam.getSTATECD());
						address.setPOSTALCD(addrParam.getPOSTALCD());
						address.setCOUNTRYCD(addrParam.getCOUNTRYCD());
						address.setLANGCD(addrParam.getLANGCD());
						address.setLONGITUDE(addrParam.getLONGITUDE());
						address.setLATITUDE(addrParam.getLATITUDE());
						address.setADDRTYPE(addrParam.getADDRTYPE());
						address.setADDRSTATUS(addrParam.getADDRSTATUS());
						if (address.getADDRSTATUS().equalsIgnoreCase("A")
								|| address.getADDRSTATUS().equalsIgnoreCase("I")
								|| address.getADDRSTATUS().equalsIgnoreCase("D")) {
							LOG.debug("===Inserting into Address List===");
							addressList.add(address);
						}
					}

				}*/
				CommunicationType commParam = null;
				for (itemIndex = 0; itemIndex < goldenPartyData.getCommunication().size(); itemIndex++) {
					commParam = goldenPartyData.getCommunication().get(itemIndex);
					if (commParam.getROWIDCOMMUNICATION() != null) {

						LOG.debug("============setting communication");

						communication = new Communication();

						communication.setROWIDCOMMUNICATION(commParam.getROWIDCOMMUNICATION().trim());
						communication.setCOMMTYPE(commParam.getCOMMTYPE());
						communication.setCOMMVALUE(commParam.getCOMMVALUE());
						communication.setCOMMSTATUS(commParam.getCOMMSTATUS());
						communication.setPRFRDCOMMIND(commParam.getPRFRDCOMMIND());
						communication.setWEBDOMAIN(commParam.getWEBDOMAIN());

						LOG.debug("===Inserting into communication List===");
						commList.add(communication);

					}

				}
				ClassificationType clsfparam = null;
				for (itemIndex = 0; itemIndex < goldenPartyData.getClassification().size(); itemIndex++) {
					clsfparam = goldenPartyData.getClassification().get(itemIndex);
					if (clsfparam.getROWIDCLASSIFICTN() != null) {

						classfction = new Classification();
						LOG.debug("============adding Classification ");

						classfction.setROWIDCLASSIFICTN(clsfparam.getROWIDCLASSIFICTN().trim());
						classfction.setCLASSIFICTNTYPE(clsfparam.getCLASSIFICTNTYPE());
						classfction.setCLASSIFICTNVALUE(clsfparam.getCLASSIFICTNVALUE());
						classfction.setSTARTDATE(clsfparam.getSTARTDATE());
						classfction.setENDDATE(clsfparam.getENDDATE());

						LOG.debug("===Inserting into Classification List===");
						classificationList.add(classfction);

					}

				}
				PartyOrgExtType orgExtnparam = null;
				for (itemIndex = 0; itemIndex < goldenPartyData.getPartyOrgExt().size(); itemIndex++) {
					orgExtnparam = goldenPartyData.getPartyOrgExt().get(itemIndex);
					if (orgExtnparam.getROWIDORGEXTN() != null) {

						partyOrgExt = new PartyOrgExt();
						LOG.debug("============adding partyOrgExtn ");

						// classfction.setROWIDCLASSIFICTN(clsfparam.getROWIDCLASSIFICTN());

						partyOrgExt.setROWIDORGEXTN(orgExtnparam.getROWIDORGEXTN().trim());
						partyOrgExt.setORGDUNSNBR(orgExtnparam.getORGDUNSNBR());
						partyOrgExt.setTRADENAME(orgExtnparam.getTRADENAME());
						partyOrgExt.setTRADENAME2(orgExtnparam.getTRADENAME2());
						partyOrgExt.setSITEEMPLCNT(orgExtnparam.getSITEEMPLCNT());
						partyOrgExt.setGLBLEMPLCNT(orgExtnparam.getGLBLEMPLCNT());
						partyOrgExt.setVERTICAL(orgExtnparam.getVERTICAL());
						partyOrgExt.setREVENUE(orgExtnparam.getREVENUE());
						partyOrgExt.setLINEOFBUS(orgExtnparam.getLINEOFBUS());
						partyOrgExt.setPRIMSIC(orgExtnparam.getPRIMSIC());
						partyOrgExt.setSECSIC(orgExtnparam.getSECSIC());
						partyOrgExt.setSALESVOLUME(orgExtnparam.getSALESVOLUME());
						partyOrgExt.setSALESAMOUNT(orgExtnparam.getSALESAMOUNT());
						partyOrgExt.setCURRENCYCD(orgExtnparam.getCURRENCYCD());
						partyOrgExt.setOUTOFBUSIND(orgExtnparam.getOUTOFBUSIND());
						partyOrgExt.setGLBLULTIND(orgExtnparam.getGLBLULTIND());
						partyOrgExt.setFORTUNEINFO(orgExtnparam.getFORTUNEINFO());
						partyOrgExt.setHIERARCHYLEVEL(orgExtnparam.getHIERARCHYLEVEL());
						partyOrgExt.setORGHQPARENTDUNS(orgExtnparam.getORGHQPARENTDUNS());
						partyOrgExt.setORGDOMULTDUNS(orgExtnparam.getORGDOMULTDUNS());
						partyOrgExt.setORGGLBULTDUNS(orgExtnparam.getORGGLBULTDUNS());
						partyOrgExt.setMFEGLBLPARENTNM(orgExtnparam.getMFEGLBLPARENTNM());
						partyOrgExt.setMFEPARENTNM(orgExtnparam.getMFEPARENTNM());
						partyOrgExt.setMFEPRTNRPARENTORG(orgExtnparam.getMFEPRTNRPARENTORG());
						partyOrgExt.setSALESREVNUOVRID(orgExtnparam.getSALESREVNUOVRID());
						partyOrgExt.setMFEEMPCNTOVERIDE(orgExtnparam.getMFEEMPCNTOVERIDE());
						partyOrgExt.setSICCDOVRIDE(orgExtnparam.getSICCDOVRIDE());
						partyOrgExt.setMFECOUNTRYULTUCN(orgExtnparam.getMFECOUNTRYULTUCN());
						partyOrgExt.setMFEGLBLPARENTUCN(orgExtnparam.getMFEGLBLPARENTUCN());
						partyOrgExt.setMFEGLOBALPARNMOVRIDE(orgExtnparam.getMFEGLOBALPARNMOVRIDE());
						partyOrgExt.setMFENEXTLVLSUBSPARNM(orgExtnparam.getMFENEXTLVLSUBSPARNM());
						partyOrgExt.setMFENEXTLVLSUBSPARUCN(orgExtnparam.getMFENEXTLVLSUBSPARNM());
						partyOrgExt.setMFESUBSDRYPARENTNM(orgExtnparam.getMFESUBSDRYPARENTNM());
						partyOrgExt.setMFESUBSDRYPARENTPRTNNM(orgExtnparam.getMFESUBSDRYPARENTPRTNNM());
						partyOrgExt.setMFESUBSPARENTNMOVRIDE(orgExtnparam.getMFESUBSPARENTNMOVRIDE());
						partyOrgExt.setMFESUBSPARENTUCN(orgExtnparam.getMFESUBSPARENTUCN());
						partyOrgExt.setMFETXN5YRFLG(orgExtnparam.getMFETXN5YRFLG());
						partyOrgExt.setMFETXN7YRFLG(orgExtnparam.getMFETXN7YRFLG());
						partyOrgExt.setMFEWWPARENTNM(orgExtnparam.getMFEWWPARENTNM());
						partyOrgExt.setMFEWWPARENTPRTNNM(orgExtnparam.getMFEWWPARENTPRTNNM());
						partyOrgExt.setTXN5YRFLG(orgExtnparam.getTXN5YRFLG());
						partyOrgExt.setTXN7YRFLG(orgExtnparam.getTXN7YRFLG());
						partyOrgExt.setGLBEMPCNTOVERRIDE(orgExtnparam.getGLBEMPCNTOVERRIDE());
						partyOrgExt.setACTIVETXNFLG(orgExtnparam.getACTIVETXNFLG());
						partyOrgExt.setPARENTFLG(orgExtnparam.getPARENTFLG());
						partyOrgExt.setPARTNERFLG(orgExtnparam.getPARTNERFLG());
						partyOrgExt.setCUSTFLG(orgExtnparam.getCUSTFLG());
						partyOrgExt.setGLBFLG(orgExtnparam.getGLBFLG());
						partyOrgExt.setCOUNTRYULTIND(orgExtnparam.getCOUNTRYULTIND());
						partyOrgExt.setCUSTOMPARENTUCN(orgExtnparam.getCUSTOMPARENTUCN());
						partyOrgExt.setCUSTOMPARENTNAME(orgExtnparam.getCUSTOMPARENTNAME());
						partyOrgExt.setMFECOUNTRYULTUCN(orgExtnparam.getMFECOUNTRYULTUCN());
						partyOrgExt.setSUBSIDIARYIND(orgExtnparam.getSUBSIDIARYIND());
						partyOrgExt.setMDMPARENTUCN(orgExtnparam.getMDMPARENTUCN());
						partyOrgExt.setCUSTOMERPARENTFLAG(orgExtnparam.getCUSTOMERPARENTFLAG());
						partyOrgExt.setG2KFLG(orgExtnparam.getG2KFLG());
						partyOrgExt.setGLBSALESREVNUOVRID(orgExtnparam.getGLBSALESREVNUOVRID());
						partyOrgExt.setPTRPARENTNM(orgExtnparam.getPTRPARENTNM());
						partyOrgExt.setPTRPARENTUCN(orgExtnparam.getPTRPARENTUCN());
						partyOrgExt.setPTRGLBLPARENTUCN(orgExtnparam.getPTRGLBLPARENTUCN());
						LOG.debug("===Inserting into partyOrgExtn List===");
						partyOrgExtList.add(partyOrgExt);

					}

				}
				PartyAccountRelationshipType partyAccRelparam = null;
				for (itemIndex = 0; itemIndex < goldenPartyData.getPartyRel().getPARTYACCOUNTREL()
						.size(); itemIndex++) {
					partyAccRelparam = goldenPartyData.getPartyRel().getPARTYACCOUNTREL().get(itemIndex);
					if (partyAccRelparam != null) {
						partyRel = new PartyRel();
						LOG.debug("===Inserting into PARTYACCOUNTREL List===");
						partyAccountRelList.add(partyAccRelparam);
						partyRel.getPARTYACCOUNTREL().addAll(partyAccountRelList);
					}

				}
				partyUpsertResp.getAccount().addAll(accountList);
				partyUpsertResp.getAddress().addAll(addressList);
				partyUpsertResp.getCommunication().addAll(commList);
				partyUpsertResp.getClassification().addAll(classificationList);
				partyUpsertResp.getPartyOrgExt().addAll(partyOrgExtList);
				partyUpsertResp.setPartyRel(partyRel);
				upsertPartyResponse.setUPDATEDATE(goldenPartyData.getUPDATEDATE());
				upsertPartyResponse.getParty().add(partyUpsertResp);
				if (partyXrefMap.containsKey(survivingPartyRowid)) {
					xrefCopy = new XREFCopy();
					LOG.debug("Adding XREF Copies in master response ");
					xrefCopy.getPartyXref().addAll(partyXrefMap.get(survivingPartyRowid));
					// xrefCopyList.add(xrefCopy);
					upsertPartyResponse.getXREFCopy().add(xrefCopy);
				}
				// }

			}
		} catch (Exception excp) {
			LOG.error("Exception occured while processing mdmUpsertPartyResponse  for Party "
					+ upsertParty.getXREF().get(0).getSRCPKEY(), excp);
			ServiceProcessingException customException = new ServiceProcessingException(excp);
			if(excp.getMessage().contains(Constant.DB_CONN_FAILURE)){
				upsertPartyResponse.setErrorCd(Constant.DB_CONN_FAILURE);
				upsertPartyResponse.setErrorMsg(excp.getMessage());
			}
			customException.setMessage("Exception occured while processing mdmUpsertPartyResponsefor Party. "
					+ customException.getMessage());
			// throw customException;
		}

		if (warning != null && warning.length() > 0) {
			upsertPartyResponse.setWarningMsg(warning.toString());
		}
	}

	private String isAccountExist(String rowidParty) throws ServiceProcessingException{
		LOG.debug("Inside isAccountExist()");
		Connection jdbcConn = null;
		PreparedStatement statement = null;
		JDBCConnectionProvider jDBCConnectionProvider = null;
		String rowidAccount = "";
		StringBuilder sqlQry = new StringBuilder();
		ResultSet resultSet = null;
		sqlQry.append("SELECT acc.ROWID_OBJECT FROM C_B_ACCOUNT acc, C_B_ACCOUNT_XREF xref");
		sqlQry.append(" WHERE acc.rowid_object = xref.rowid_object and xref.rowid_system in ('ADB','FNO','SBL','SAP','SFC','DNB')");
		sqlQry.append(" and acc.ROWID_PARTY in('"+rowidParty.trim()+"')");
		LOG.debug("SQL in isAccountExist()--> " + sqlQry);
		try {
			jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
			jdbcConn = jDBCConnectionProvider.getJdbcConnectionFromDS();
			statement = jdbcConn.prepareStatement(sqlQry.toString());
			resultSet = statement.executeQuery();
			if (resultSet.next()) {
				rowidAccount = resultSet.getString(1);
			}
			LOG.debug("rowidAccount value is: " + rowidAccount);

		} catch (Exception exp) {
			LOG.error("Caught SQLException in isAccountExist()."+exp.getMessage());
		} finally {
			try {
				if (resultSet != null)
					resultSet.close();
				if (statement != null)
					statement.close();
				if (jdbcConn != null)
					jdbcConn.close();
			} catch (SQLException exp) {
				LOG.error("Caught SQLException in isAccountExist()."+exp.getMessage());
			}
		}
		return rowidAccount;
	}

	private PutResponseDataHolder cleansePutParty(PartyXrefType partyParam, SiperianClient siperianClient,boolean isCustomer)
			throws ServiceProcessingException {
		LOG.info("Executing cleansePutParty()");
		int itemIndex = 0;
		CleansePutRequest cleansePutRequest = new CleansePutRequest();
		CleansePutResponse cleansePutResponse = null;
		PutResponseDataHolder responseDataHolder = null;

		try {

			// prepare CleansePutRequest
			Record record = new Record();
			// set mapping name
			record.setSiperianObjectUid(Util.getMappingObjectUid(partyParam.getXREF().get(itemIndex).getSRCSYSTEM(),
					MDMAttributeNames.ENTITY_PARTY));
			// set input values
			/*if (partyParam.getLASTUPDATEDATE() != null && partyParam.getLASTUPDATEDATE().length() > 0) {
				record.setField(new Field(MDMAttributeNames.LAST_UPDATE_DATE, partyParam.getLASTUPDATEDATE()));
			} else {*/
				LOG.info("Performing cleansePutParty with sysdate from HUB: " + lastUpdateDate);
				record.setField(new Field(MDMAttributeNames.LAST_UPDATE_DATE, lastUpdateDate));
			/*}*/
			if (partyParam.getSRCCREATEDT() != null && partyParam.getSRCCREATEDT().length() > 0) {
				record.setField(new Field(MDMAttributeNames.SRC_CREATE_DT, partyParam.getSRCCREATEDT()));
			}else{
				record.setField(new Field(MDMAttributeNames.SRC_CREATE_DT, lastUpdateDate));
			}

			record.setField(new Field(MDMAttributeNames.SRC_UPDT_BY, partyParam.getUPDATEBY()));
			record.setField(
					new Field(MDMAttributeNames.SRC_SYSTEM, (partyParam.getXREF().get(itemIndex)).getSRCSYSTEM()));
			record.setField(
					new Field(MDMAttributeNames.SRC_SYS_KEY, (partyParam.getXREF().get(itemIndex)).getSRCPKEY()));
			record.setField(new Field(PartyAttributes.ENTITY_TYPE, partyParam.getBOCLASSCODE()));
			record.setField(new Field(PartyAttributes.PARTY_NAME, partyParam.getPARTYNAME()));
			record.setField(new Field(PartyAttributes.PARTY_TYPE, isCustomer?Constant.PARTY_TYPE_CUSTOMER:Constant.PARTY_TYPE_PROSPECT_ACCOUNT));
			record.setField(new Field(PartyAttributes.GEO, partyParam.getGEO()));
			record.setField(new Field(PartyAttributes.REGION, partyParam.getREGION()));
			record.setField(new Field(PartyAttributes.SALES_BLOCK_CD, partyParam.getSALESBLOCKCD()));
			record.setField(new Field(PartyAttributes.TAX_JURSDCTN_CD, partyParam.getTAXJURSDCTNCD()));
			record.setField(new Field(PartyAttributes.VAT_REG_NBR, partyParam.getVATREGNBR()));
			if(!Util.isNullOrEmpty(partyParam.getSTATUSCD()) && partyParam.getSTATUSCD().trim().length()==1){
				record.setField(new Field(PartyAttributes.STATUS_CD, getStatusDesc(partyParam.getSTATUSCD().trim())));
			}else{
				record.setField(new Field(PartyAttributes.STATUS_CD, partyParam.getSTATUSCD()));
			}

			if (!Util.isNullOrEmpty(partyParam.getUCN())) {
				LOG.info("============UCN UCN UCN=========="+partyParam.getUCN());
				record.setField(new Field(PartyAttributes.UCN, partyParam.getUCN()));
			}
			 
			
			if (!Util.isNullOrEmpty(partyParam.getAddress().get(0).getCOUNTRYCD())
					&& partyParam.getAddress().get(0).getCOUNTRYCD().trim().length() == 2) {
				record.setField(new Field(AddressAttributes.COUNTRY_CD,
						getADBCountryName(partyParam.getAddress().get(0).getCOUNTRYCD())));
			} else {
				record.setField(new Field(AddressAttributes.COUNTRY_CD, partyParam.getAddress().get(0).getCOUNTRYCD()));
			}

			record.setField(new Field(PartyAttributes.ENGLISH_NAME, partyParam.getENGLISHNAME()));

			LOG.info("============MSG_TRKN_ID=========="+partyParam.getMSGTRKNID());
			record.setField(new Field(PartyAttributes.MSG_TRKN_ID, partyParam.getMSGTRKNID()));

			if(selfMatchFail){
				record.setField(new Field(PartyAttributes.PROCESS_STATE_IND, Constant.SEND_FOR_DNB));
			}
			
			cleansePutRequest.setRecord(record);
			// execute Put request
			cleansePutResponse = (CleansePutResponse) siperianClient.process(cleansePutRequest);
			LOG.info("Party cleansePut request processed successfully: " + cleansePutResponse.getMessage());
			// extract result
			RecordKey recordKey = cleansePutResponse.getRecordKey();

			responseDataHolder = new PutResponseDataHolder();
			responseDataHolder.setActionType(cleansePutResponse.getActionType());
			responseDataHolder.setActionMessage(cleansePutResponse.getMessage());
			responseDataHolder.setRowidObject(recordKey.getRowid());
			responseDataHolder.setRowidXREF(recordKey.getRowidXref());
			responseDataHolder.setSourceKey(recordKey.getSourceKey());
			responseDataHolder.setSystemName(recordKey.getSystemName());
			LOG.info("ROWID_OBJECT of created Party record = " + recordKey.getRowid());

			LOG.debug("Action Type = " + responseDataHolder.getActionType());
			LOG.debug("Action Msg = " + responseDataHolder.getActionMessage());
			LOG.debug("Rowid_xref = " + responseDataHolder.getRowidXREF());
			LOG.debug("Src key = " + responseDataHolder.getSourceKey());
			LOG.debug("System = " + responseDataHolder.getSystemName());

		} catch (SiperianServerException sifExcp) {
			LOG.error("SiperianServerException occured while processing CleansePutRequest for Party: ", sifExcp);
			LOG.error("Get Message: " + sifExcp.getMessage());
			LOG.error("sifExcp msg " + sifExcp);
			sifExcp.printStackTrace();
			ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
			customException.setRootExceptionMsg(sifExcp + " CleansePut operation failed for Party "
					+ (partyParam.getXREF().get(itemIndex)).getSRCPKEY().replaceAll(Constant.ADB_ACT_PREFIX, Constant.STR_BLANK));
			customException.setMessage(
					"SIF exception occured while processing Put request for Party." + customException.getMessage());
			throw customException;
		} catch (Exception excp) {
			LOG.error("Exception occured while processing CleansePutRequest for Party: ", excp);
			LOG.error("excp msg " + excp);
			ServiceProcessingException customException = new ServiceProcessingException(excp);
			customException.setMessage(
					"Exception occured while processing Put request for Party." + customException.getMessage());
			customException.setRootExceptionMsg(excp + " CleansePut operation failed for Party "
					+ (partyParam.getXREF().get(itemIndex)).getSRCPKEY().replaceAll(Constant.ADB_ACT_PREFIX, Constant.STR_BLANK));
			throw customException;
		}

		LOG.info("Executed cleansePutParty()");
		return responseDataHolder;
	}

	private String getStatusDesc(String statusCode) {
		String status = "";
		if("A".equals(statusCode)){
			status = "Active";
		}else if("I".equals(statusCode)){
			status = "Inactive";
		}
		else if("M".equals(statusCode)){
			status = "Merger";
		}
		
		return status;
	}

	/**
	 * The method prepares and executes CleansePutRequest on ACCOUNT landing
	 * table for the given Account profiles.
	 *
	 * @param addressList
	 *            List of Accounts provided to the web service request
	 * @param partyParam
	 *            Party profile provided to the web service request
	 * @param siperianClient
	 *            SiperianClient SIF connection to MDM Hub
	 * @return List of PutResponseDataHolder object containing processing
	 *         results
	 * @throws ServiceProcessingException
	 */
	private List<PutResponseDataHolder> cleansePutAccount(List<AccountXrefType> accountList, PartyXrefType partyParam,
			SiperianClient siperianClient) throws ServiceProcessingException {
		LOG.info("Executing cleansePutAccount()");
		int itemIndex = 0;
		CleansePutRequest cleansePutRequest = null;
		CleansePutResponse cleansePutResponse = null;
		List<PutResponseDataHolder> responseDataHolderList = new ArrayList<PutResponseDataHolder>(accountList.size());
		AccountXrefType accountParam = null;

		try {
			for (itemIndex = 0; itemIndex < accountList.size(); itemIndex++) {
				cleansePutRequest = new CleansePutRequest();
				accountParam = accountList.get(itemIndex);
				// prepare CleansePutRequest
				Record record = new Record();
				// set mapping name
				String srcSystem = partyParam.getAccount().get(itemIndex).getSRCSYSTEM();

				record.setSiperianObjectUid(Util.getMappingObjectUid(srcSystem, MDMAttributeNames.ENTITY_ACCOUNT));
				// set input values
				/*if (partyParam.getLASTUPDATEDATE() != null && partyParam.getLASTUPDATEDATE().length() > 0) {
					record.setField(new Field(MDMAttributeNames.LAST_UPDATE_DATE, partyParam.getLASTUPDATEDATE()));
				} else {*/
					LOG.info("Performing cleansePutAccount with sysdate from HUB: " + lastUpdateDate);
					record.setField(new Field(MDMAttributeNames.LAST_UPDATE_DATE, lastUpdateDate));
				/*}*/
				record.setField(new Field(MDMAttributeNames.SRC_UPDT_BY, accountParam.getUPDATEBY()));
				record.setField(new Field(MDMAttributeNames.SRC_SYSTEM, srcSystem));
				record.setField(new Field(MDMAttributeNames.SRC_SYS_KEY, accountParam.getSRCPKEY()));
				record.setField(new Field(AccountAttributes.ACCOUNT_GEO, accountParam.getACCOUNTGEO()));
				record.setField(new Field(AccountAttributes.ACCOUNT_REGION, accountParam.getACCOUNTREGION()));
				record.setField(
						new Field(AccountAttributes.ACCOUNT_TAX_JURSDCTN_CD, accountParam.getACCOUNTTAXJURSDCTNCD()));
				record.setField(new Field(AccountAttributes.ACCOUNT_VAT_REG_NBR, accountParam.getACCOUNTVATREGNBR()));
				record.setField(
						new Field(AccountAttributes.NAME_QUALITY_IDENTIFIER, accountParam.getNAMEQUALITYIDENTIFIER()));

				/* Change for MDMP-2885 :: START */
				record.setField(new Field(AccountAttributes.IS_DENIED_FLG, accountParam.getISDENIEDFLG()));
				/* Change for MDMP-2885 :: END */

				LOG.debug("ACCOUNT_VAT_REG_NBR : " + accountParam.getACCOUNTVATREGNBR());
				record.setField(new Field(AccountAttributes.ACCT_NAME, partyParam.getPARTYNAME()));

				record.setField(new Field(AccountAttributes.ACCT_STATUS, "Active"));
				record.setField(new Field(AccountAttributes.ACCT_TYPE, accountParam.getACCTTYPE()));
				record.setField(new Field(AccountAttributes.ALIAS_NAME, accountParam.getALIASNAME()));
				record.setField(new Field(AccountAttributes.BILL_BLOCK_CD, accountParam.getBILLBLOCKCD()));
				record.setField(new Field(AccountAttributes.CHANNEL_ID, accountParam.getCHANNELID()));
				record.setField(new Field(AccountAttributes.COMPANY_CD, accountParam.getCOMPANYCD()));
				record.setField(new Field(AccountAttributes.CUST_GROUP, accountParam.getCUSTGROUP()));
				record.setField(new Field(AccountAttributes.DIRECT_IND, accountParam.getDIRECTIND()));
				record.setField(new Field(AccountAttributes.DLVRY_BLOCK_CD, accountParam.getDLVRYBLOCKCD()));
				record.setField(new Field(AccountAttributes.MARKET, accountParam.getMARKET()));
				record.setField(new Field(AccountAttributes.NAMED_ACCT_IND, accountParam.getNAMEDACCTIND()));
				record.setField(new Field(AccountAttributes.NON_VAL_ACCT_IND, accountParam.getNONVALACCTIND()));
				record.setField(new Field(AccountAttributes.ORDR_BLOCK_CD, accountParam.getORDRBLOCKCD()));
				record.setField(new Field(AccountAttributes.PARTNER_IND, accountParam.getPARTNERIND()));
				record.setField(new Field(AccountAttributes.PARTNER_TYPE, accountParam.getPARTNERTYPE()));
				record.setField(new Field(AccountAttributes.POST_BLOCK_CD, accountParam.getPOSTBLOCKCD()));
				record.setField(new Field(AccountAttributes.PRICE_GROUP, accountParam.getPRICEGROUP()));
				record.setField(new Field(AccountAttributes.SALE_BLOCK_CD, accountParam.getSALEBLOCKCD()));
				record.setField(new Field(AccountAttributes.TAX_TYPE, accountParam.getTAXTYPE()));
				record.setField(new Field(AccountAttributes.VENDOR_NBR, accountParam.getVENDORNBR()));
				// Do not overwrite SBL_Rowid with null
				if (!Util.isNullOrEmpty(accountParam.getSIEBELROWID())) {
					record.setField(new Field(AccountAttributes.SIEBEL_ROWID, accountParam.getSIEBELROWID()));
				}
				// Do not overwrite SAP_Cust_Nbr with null
				if (!Util.isNullOrEmpty(accountParam.getSAPCUSTNUMBER())) {
					record.setField(new Field(AccountAttributes.SAP_CUST_NUMBER, accountParam.getSAPCUSTNUMBER()));
				}

				record.setField(new Field(AccountAttributes.DATA_SRC_SYSTEM, accountParam.getDATASRCSYSTEM()));
				record.setField(new Field(AccountAttributes.SAP_NAME_1, accountParam.getSAPNAME1()));
				record.setField(new Field(AccountAttributes.SAP_NAME_2, accountParam.getSAPNAME2()));
				record.setField(new Field(AccountAttributes.SAP_NAME_3, accountParam.getSAPNAME3()));
				record.setField(new Field(AccountAttributes.SAP_NAME_4, accountParam.getSAPNAME4()));

				/** Modified for SFDC START */
				record.setField(new Field(AccountAttributes.SFID, accountParam.getSalesForceID()));
				record.setField(new Field(AccountAttributes.DRAFT_FLG, accountParam.getDraftAccountFlag()));
				/** Modified for SFDC END */
				/** changes for Sales Force Integration -Start */
				record.setField(new Field(AccountAttributes.LOCAL_NAME, accountParam.getLOCALNAME()));
				record.setField(new Field(AccountAttributes.CURRENCY_CD, accountParam.getCURRENCYCD()));
				record.setField(new Field(AccountAttributes.TAX_ID, accountParam.getTAXID()));
				record.setField(new Field(AccountAttributes.PRICING_BAND_AGRMNT, accountParam.getPRICEBANDAGGREMENT()));
				/** changes for Sales Force Integration -End */
				/** changes for Track-2 -Start */
				record.setField(new Field(AccountAttributes.SITE_DESIGNATION, accountParam.getSITEDESIGNATION()));
				/** changes for Track-2 -End */
				record.setField(
						new Field(MDMAttributeNames.PARTY_SRC_SYS_KEY, partyParam.getXREF().get(0).getSRCPKEY()));

				/** changes for Track-3 -Start */
				record.setField(new Field(AccountAttributes.CLEANSE_IND, accountParam.getCLEANSEIND()));
				record.setField(new Field(AccountAttributes.RESELL_LEVEL, accountParam.getRESELLLEVEL()));
				if (!Util.isNullOrEmpty(accountParam.getPARTNERSHIPSTATUS())) {
					record.setField(
							new Field(AccountAttributes.PARTNERSHIP_STATUS, accountParam.getPARTNERSHIPSTATUS()));
				}
				/** changes for Track-3 -End */

				cleansePutRequest.setRecord(record);
				LOG.info("Account cleansePut request NAME_QUALITY_IDENTIFIER : "
						+ accountParam.getNAMEQUALITYIDENTIFIER());
				// execute Put request
				cleansePutResponse = (CleansePutResponse) siperianClient.process(cleansePutRequest);
				LOG.info("Account cleansePut request processed successfully: " + cleansePutResponse.getMessage());
				// extract result
				RecordKey recordKey = cleansePutResponse.getRecordKey();

				PutResponseDataHolder responseDataHolder = new PutResponseDataHolder();
				responseDataHolder.setActionType(cleansePutResponse.getActionType());
				responseDataHolder.setActionMessage(cleansePutResponse.getMessage());
				responseDataHolder.setRowidObject(recordKey.getRowid());
				responseDataHolder.setRowidXREF(recordKey.getRowidXref());
				responseDataHolder.setSourceKey(recordKey.getSourceKey());
				responseDataHolder.setSystemName(recordKey.getSystemName());
				responseDataHolderList.add(responseDataHolder);
				LOG.info("ROWID_OBJECT of created Account record = " + recordKey.getRowid());
				LOG.debug("Action Type = " + responseDataHolder.getActionType());
				LOG.debug("Action Msg = " + responseDataHolder.getActionMessage());
			}
		} catch (SiperianServerException sifExcp) {
			LOG.error("SiperianServerException occured while processing CleansePutRequest for Account: " + sifExcp);
			LOG.error("Root Cause: " + sifExcp.getCause().getMessage());
			LOG.error("msg ", sifExcp);
			sifExcp.printStackTrace();
			ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
			customException.setMessage(
					"SIF exception occured while processing Put request for Account. " + customException.getMessage());
			customException.setRootExceptionMsg(
					sifExcp + " CleansePut operation failed for Account " + accountParam.getSRCPKEY().replaceAll(Constant.ADB_ACT_PREFIX, Constant.STR_BLANK));
			throw customException;
		} catch (Exception excp) {
			LOG.error("Exception occured while processing CleansePutRequest for Party: " + excp);
			excp.printStackTrace();
			ServiceProcessingException customException = new ServiceProcessingException(excp);
			customException.setMessage(
					"Exception occured while processing Put request for Account. " + customException.getMessage());
			customException.setRootExceptionMsg(
					excp + " CleansePut operation failed for Account " + accountParam.getSRCPKEY().replaceAll(Constant.ADB_ACT_PREFIX, Constant.STR_BLANK));
			throw customException;
		}

		LOG.info("Executed cleansePutAccount()");
		return responseDataHolderList;
	}

	private List<PutResponseDataHolder> cleansePutProspectCustomer(PartyXrefType partyParam,
			SiperianClient siperianClient) throws ServiceProcessingException {
		LOG.debug("[cleansePutProspectCustomer] ENTER");
		CleansePutRequest cleansePutRequest = null;
		CleansePutResponse cleansePutResponse = null;
		List<PutResponseDataHolder> responseDataHolderList = new ArrayList<PutResponseDataHolder>();
			try {
				cleansePutRequest = new CleansePutRequest();
				// prepare CleansePutRequest
				Record record = new Record();
				// set mapping name
				record.setSiperianObjectUid(
						Util.getMappingObjectUid(partyParam.getXREF().get(0).getSRCSYSTEM(), MDMAttributeNames.ENTITY_PROSPECT));
				// set input values
				/*if (partyParam.getLASTUPDATEDATE() != null && partyParam.getLASTUPDATEDATE().length() > 0) {
					record.setField(new Field(MDMAttributeNames.LAST_UPDATE_DATE, partyParam.getLASTUPDATEDATE()));
				} else {*/
					LOG.info("[cleansePutProspect]Performing cleansePutProspect with sysdate from HUB: "
							+ lastUpdateDate);
					record.setField(new Field(MDMAttributeNames.LAST_UPDATE_DATE, lastUpdateDate));
				/*}*/
				record.setField(new Field(MDMAttributeNames.SRC_SYSTEM, Constant.SRC_SYSTEM_ADB));
					record.setField(new Field(MDMAttributeNames.SRC_SYS_KEY, partyParam.getXREF().get(0).getSRCPKEY()));
				
				record.setField(new Field(ProspectAttributes.PROSPECT_NAME, partyParam.getPARTYNAME()));
				record.setField(new Field(ProspectAttributes.PROSPECT_STATUS, Constant.DEAFULT_PROSPECT_STATUS));
				record.setField(new Field(ProspectAttributes.PROSPECT_TYPE, Constant.PARTY_TYPE_PROSPECT_ACCOUNT));
				record.setField(new Field(ProspectAttributes.PROSPECT_GROUP, Constant.PARTY_TYPE_PROSPECT_ACCOUNT));
				record.setField(new Field(ProspectAttributes.DATA_SRC_SYSTEM, Constant.SRC_SYSTEM_ADB));
				record.setField(new Field(MDMAttributeNames.PARTY_SRC_SYS_KEY, partyParam.getXREF().get(0).getSRCPKEY()));
				
				

				cleansePutRequest.setRecord(record);
				// execute Put request
				cleansePutResponse = (CleansePutResponse) siperianClient.process(cleansePutRequest);
				LOG.info("ProspectCustomer cleansePut request processed successfully: " + cleansePutResponse.getMessage());
				// extract result
				RecordKey recordKey = cleansePutResponse.getRecordKey();

				PutResponseDataHolder responseDataHolder = new PutResponseDataHolder();
				responseDataHolder.setActionType(cleansePutResponse.getActionType());
				responseDataHolder.setActionMessage(cleansePutResponse.getMessage());
				responseDataHolder.setRowidObject(recordKey.getRowid());
				responseDataHolder.setRowidXREF(recordKey.getRowidXref());
				responseDataHolder.setSourceKey(recordKey.getSourceKey());
				responseDataHolder.setSystemName(recordKey.getSystemName());
				responseDataHolderList.add(responseDataHolder);
				LOG.info("ROWID_OBJECT of created Prospect record = " + recordKey.getRowid());
				LOG.debug("Action Type = " + responseDataHolder.getActionType());
				LOG.debug("Action Msg = " + responseDataHolder.getActionMessage());
			} catch (SiperianServerException sifExcp) {
				LOG.error("SiperianServerException occured while processing CleansePutRequest for Prospect: " + sifExcp);
				LOG.error("Root Cause: " + sifExcp.getCause().getMessage());
				LOG.error("msg ", sifExcp);
				sifExcp.printStackTrace();
				ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
				customException.setMessage("SIF exception occured while processing Put request for prospect. "
						+ customException.getMessage());
				customException.setRootExceptionMsg(
						sifExcp + " CleansePut operation failed for prospect " + partyParam.getXREF().get(0).getSRCPKEY().replaceAll(Constant.ADB_ACT_PREFIX, Constant.STR_BLANK));
				throw customException;
			} catch (Exception excp) {
				LOG.error("Exception occured while processing CleansePutRequest for prospect: " + excp);
				excp.printStackTrace();
				ServiceProcessingException customException = new ServiceProcessingException(excp);
				customException.setMessage(
						"Exception occured while processing Put request for prospect. " + customException.getMessage());
				customException.setRootExceptionMsg(
						excp + " CleansePut operation failed for prospect " + partyParam.getXREF().get(0).getSRCPKEY().replaceAll(Constant.ADB_ACT_PREFIX, Constant.STR_BLANK));
				throw customException;
			}
		

		LOG.debug("[cleansePutProspectCustomer] EXIT");
		return responseDataHolderList;
	}
	private List<PutResponseDataHolder> cleansePutProspect(List<AccountXrefType> prospectList, PartyXrefType partyParam,
			SiperianClient siperianClient) throws ServiceProcessingException {
		LOG.debug("[cleansePutProspect] ENTER");
		CleansePutRequest cleansePutRequest = null;
		CleansePutResponse cleansePutResponse = null;
		List<PutResponseDataHolder> responseDataHolderList = new ArrayList<PutResponseDataHolder>(prospectList.size());
		for (AccountXrefType prospectParam : prospectList) {
			try {
				cleansePutRequest = new CleansePutRequest();
				// prepare CleansePutRequest
				Record record = new Record();
				// set mapping name
				record.setSiperianObjectUid(
						Util.getMappingObjectUid(prospectParam.getSRCSYSTEM(), MDMAttributeNames.ENTITY_PROSPECT));
				// set input values
				/*if (partyParam.getLASTUPDATEDATE() != null && partyParam.getLASTUPDATEDATE().length() > 0) {
					record.setField(new Field(MDMAttributeNames.LAST_UPDATE_DATE, partyParam.getLASTUPDATEDATE()));
				} else {*/
					LOG.info("[cleansePutProspect]Performing cleansePutProspect with sysdate from HUB: "
							+ lastUpdateDate);
					record.setField(new Field(MDMAttributeNames.LAST_UPDATE_DATE, lastUpdateDate));
				/*}*/
				record.setField(new Field(MDMAttributeNames.SRC_SYSTEM, Constant.SRC_SYSTEM_ADB));
				if (Util.isNullOrEmpty(prospectParam.getSRCPKEY())) {
					record.setField(new Field(MDMAttributeNames.SRC_SYS_KEY, partyParam.getXREF().get(0).getSRCPKEY()));
				} else {
					record.setField(new Field(MDMAttributeNames.SRC_SYS_KEY, prospectParam.getSRCPKEY()));
				}
				
				record.setField(new Field(ProspectAttributes.PROSPECT_NAME, partyParam.getPARTYNAME()));
				if (Util.isNullOrEmpty(prospectParam.getACCTSTATUS())) {
					record.setField(new Field(ProspectAttributes.PROSPECT_STATUS, Constant.DEAFULT_PROSPECT_STATUS));
				} else {
					record.setField(new Field(ProspectAttributes.PROSPECT_STATUS, prospectParam.getACCTSTATUS()));
				}
				record.setField(new Field(ProspectAttributes.PROSPECT_TYPE, Constant.PARTY_TYPE_PROSPECT_ACCOUNT));
				record.setField(new Field(ProspectAttributes.PROSPECT_GROUP, Constant.PARTY_TYPE_PROSPECT_ACCOUNT));
				record.setField(new Field(ProspectAttributes.DATA_SRC_SYSTEM, Constant.SRC_SYSTEM_ADB));
				record.setField(new Field(MDMAttributeNames.PARTY_SRC_SYS_KEY, partyParam.getXREF().get(0).getSRCPKEY()));
				/*
				record.setField(new Field(ProspectAttributes.PROSPECT_GEO, prospectParam.getACCOUNTGEO()));
				record.setField(new Field(ProspectAttributes.PROSPECT_REGION, prospectParam.getACCOUNTREGION()));
				record.setField(new Field(ProspectAttributes.ALIAS_NAME, prospectParam.getALIASNAME()));
				record.setField(new Field(ProspectAttributes.NON_VAL_ACCT_IND, prospectParam.getNONVALACCTIND()));
				record.setField(new Field(ProspectAttributes.NAME_QUALITY_IDENTIFIER,prospectParam.getNAMEQUALITYIDENTIFIER()));
				*/
				

				cleansePutRequest.setRecord(record);
				// execute Put request
				cleansePutResponse = (CleansePutResponse) siperianClient.process(cleansePutRequest);
				LOG.info("Prospect cleansePut request processed successfully: " + cleansePutResponse.getMessage());
				// extract result
				RecordKey recordKey = cleansePutResponse.getRecordKey();

				PutResponseDataHolder responseDataHolder = new PutResponseDataHolder();
				responseDataHolder.setActionType(cleansePutResponse.getActionType());
				responseDataHolder.setActionMessage(cleansePutResponse.getMessage());
				responseDataHolder.setRowidObject(recordKey.getRowid());
				responseDataHolder.setRowidXREF(recordKey.getRowidXref());
				responseDataHolder.setSourceKey(recordKey.getSourceKey());
				responseDataHolder.setSystemName(recordKey.getSystemName());
				responseDataHolderList.add(responseDataHolder);
				LOG.info("ROWID_OBJECT of created Account record = " + recordKey.getRowid());
				LOG.debug("Action Type = " + responseDataHolder.getActionType());
				LOG.debug("Action Msg = " + responseDataHolder.getActionMessage());
			} catch (SiperianServerException sifExcp) {
				LOG.error("SiperianServerException occured while processing CleansePutRequest for Account: " + sifExcp);
				LOG.error("Root Cause: " + sifExcp.getCause().getMessage());
				LOG.error("msg ", sifExcp);
				sifExcp.printStackTrace();
				ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
				customException.setMessage("SIF exception occured while processing Put request for Account. "
						+ customException.getMessage());
				customException.setRootExceptionMsg(
						sifExcp + " CleansePut operation failed for Account " + prospectParam.getSRCPKEY().replaceAll(Constant.ADB_ACT_PREFIX, Constant.STR_BLANK));
				throw customException;
			} catch (Exception excp) {
				LOG.error("Exception occured while processing CleansePutRequest for Party: " + excp);
				excp.printStackTrace();
				ServiceProcessingException customException = new ServiceProcessingException(excp);
				customException.setMessage(
						"Exception occured while processing Put request for Account. " + customException.getMessage());
				customException.setRootExceptionMsg(
						excp + " CleansePut operation failed for Account " + prospectParam.getSRCPKEY().replaceAll(Constant.ADB_ACT_PREFIX, Constant.STR_BLANK));
				throw customException;
			}
		}

		LOG.debug("[cleansePutProspect] EXIT");
		return responseDataHolderList;
	}

	private List<PutResponseDataHolder> cleansePutAddress(List<AddressXrefType> addressList, PartyXrefType partyParam,
			SiperianClient siperianClient, boolean isCustomer) throws ServiceProcessingException {
		LOG.info("Executing cleansePutAddress()");

		CleansePutRequest cleansePutRequest = null;
		CleansePutResponse cleansePutResponse = null;
		List<PutResponseDataHolder> responseDataHolderList = new ArrayList<PutResponseDataHolder>(addressList.size());
		for (AddressXrefType addressParam : addressList) {
			try {
				cleansePutRequest = new CleansePutRequest();
				// prepare CleansePutRequest
				Record record = new Record();
				// set mapping name
				record.setSiperianObjectUid(
						Util.getMappingObjectUid(addressParam.getSRCSYSTEM(), MDMAttributeNames.ENTITY_ADDRESS));
				// set input values
				/*if (partyParam.getLASTUPDATEDATE() != null && partyParam.getLASTUPDATEDATE().length() > 0) {
					record.setField(new Field(MDMAttributeNames.LAST_UPDATE_DATE, partyParam.getLASTUPDATEDATE()));
				} else {*/
					LOG.info("Performing cleansePutAddress with sysdate from HUB: " + lastUpdateDate);
					record.setField(new Field(MDMAttributeNames.LAST_UPDATE_DATE, lastUpdateDate));
				/*}*/
				record.setField(new Field(MDMAttributeNames.SRC_UPDT_BY, addressParam.getUPDATEBY()));
				record.setField(new Field(MDMAttributeNames.SRC_SYSTEM, addressParam.getSRCSYSTEM()));
				if (Util.isNullOrEmpty(addressParam.getSRCPKEY())) {
					record.setField(new Field(MDMAttributeNames.SRC_SYS_KEY, partyParam.getXREF().get(0).getSRCPKEY()));
				} else {
					record.setField(new Field(MDMAttributeNames.SRC_SYS_KEY, addressParam.getSRCPKEY()));
				}
				record.setField(new Field(AddressAttributes.ADDR_LN1, addressParam.getADDRLN1()));
				record.setField(new Field(AddressAttributes.ADDR_LN2, addressParam.getADDRLN2()));
				record.setField(new Field(AddressAttributes.ADDR_LN3, addressParam.getADDRLN3()));
				record.setField(new Field(AddressAttributes.ADDR_LN4, addressParam.getADDRLN4()));
				if(!Util.isNullOrEmpty(addressParam.getADDRSTATUS()) && addressParam.getADDRSTATUS().trim().length()==1){
					record.setField(new Field(AddressAttributes.ADDR_STATUS, getStatusDesc(addressParam.getADDRSTATUS().trim())));
				}else{
					record.setField(new Field(AddressAttributes.ADDR_STATUS, addressParam.getADDRSTATUS()));
				}
				
				
				if(isCustomer){
					record.setField(new Field(AddressAttributes.ADDR_TYPE, Constant.ADDRESS_TYPE_BILLING));
				}else{
					record.setField(new Field(AddressAttributes.ADDR_TYPE, Constant.ADDRESS_TYPE_MAILING));	
				}

				record.setField(new Field(AddressAttributes.CITY, addressParam.getCITY()));
				LOG.debug("addressParam.getCOUNTRYCD(): " + addressParam.getCOUNTRYCD());
				
				if(!Util.isNullOrEmpty(addressParam.getCOUNTRYCD()) && addressParam.getCOUNTRYCD().trim().length()==2){
				record.setField(new Field(AddressAttributes.COUNTRY_CD, getADBCountryName(addressParam.getCOUNTRYCD())));
				}else{
					record.setField(new Field(AddressAttributes.COUNTRY_CD, addressParam.getCOUNTRYCD()));
				}
				
				record.setField(new Field(AddressAttributes.COUNTY, addressParam.getCOUNTY()));
				record.setField(new Field(AddressAttributes.DISTRICT, addressParam.getDISTRICT()));
				record.setField(new Field(AddressAttributes.LANG_CD, addressParam.getLANGCD()));
				record.setField(new Field(AddressAttributes.LATITUDE, addressParam.getLATITUDE()));
				record.setField(new Field(AddressAttributes.LONGITUDE, addressParam.getLONGITUDE()));
				record.setField(new Field(AddressAttributes.POSTAL_CD, addressParam.getPOSTALCD()));
				LOG.debug("addressParam.getSTATECD(): " + addressParam.getSTATECD());
				record.setField(new Field(AddressAttributes.STATE_CD, addressParam.getSTATECD()));
				record.setField(new Field(AddressAttributes.ADDRESS_QUALITY_IDENTIFIER,
						addressParam.getADDRESSQUALITYIDENTIFIER()));
				// record.setField(new Field(AddressAttributes.ADDR_MKTG_PREF,
				// addressParam.getADDRMKTGPREF()));
				record.setField(
						new Field(MDMAttributeNames.PARTY_SRC_SYS_KEY, partyParam.getXREF().get(0).getSRCPKEY()));

				cleansePutRequest.setRecord(record);
				// execute Put request
				cleansePutResponse = (CleansePutResponse) siperianClient.process(cleansePutRequest);
				LOG.info("Address cleansePut request processed successfully: " + cleansePutResponse.getMessage());
				// extract result
				RecordKey recordKey = cleansePutResponse.getRecordKey();

				PutResponseDataHolder responseDataHolder = new PutResponseDataHolder();
				responseDataHolder.setActionType(cleansePutResponse.getActionType());
				responseDataHolder.setActionMessage(cleansePutResponse.getMessage());
				responseDataHolder.setRowidObject(recordKey.getRowid());
				responseDataHolder.setRowidXREF(recordKey.getRowidXref());
				responseDataHolder.setSourceKey(recordKey.getSourceKey());
				responseDataHolder.setSystemName(recordKey.getSystemName());
				responseDataHolderList.add(responseDataHolder);
				LOG.info("ROWID_OBJECT of created Address record = " + recordKey.getRowid());
				LOG.debug("Action Type = " + responseDataHolder.getActionType());
				LOG.debug("Action Msg = " + responseDataHolder.getActionMessage());
			} catch (SiperianServerException sifExcp) {
				LOG.error("SiperianServerException occured while processing CleansePutRequest for Address: ", sifExcp);
				ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
				customException.setMessage("SIF exception occured while processing Put request for Address. "
						+ customException.getMessage());
				customException.setRootExceptionMsg(
						sifExcp + " CleansePut operation failed for Address " + addressParam.getSRCPKEY().replaceAll(Constant.ADB_ACT_PREFIX, Constant.STR_BLANK));
				throw customException;
			} catch (Exception excp) {
				LOG.error("Exception occured while processing CleansePutRequest for Address: ", excp);
				ServiceProcessingException customException = new ServiceProcessingException(excp);
				customException.setMessage(
						"Exception occured while processing Put request for Address. " + customException.getMessage());
				customException.setRootExceptionMsg(
						excp + " CleansePut operation failed for Address " + addressParam.getSRCPKEY().replaceAll(Constant.ADB_ACT_PREFIX, Constant.STR_BLANK));
				throw customException;
			}
		}

		LOG.info("Executed cleansePutAddress()");
		return responseDataHolderList;
	}

	private List<PutResponseDataHolder> cleansePutCommunication(List<CommunicationXrefType> commList,
			PartyXrefType partyParam, SiperianClient siperianClient) throws ServiceProcessingException {
		LOG.info("Executing cleansePutCommunication()");
		CleansePutRequest cleansePutRequest = null;
		CleansePutResponse cleansePutResponse = null;
		List<PutResponseDataHolder> responseDataHolderList = new ArrayList<PutResponseDataHolder>(commList.size());
		for (CommunicationXrefType commParam : commList) {
			try {
				cleansePutRequest = new CleansePutRequest();
				// prepare CleansePutRequest
				Record record = new Record();
				// set mapping name
				record.setSiperianObjectUid(
						Util.getMappingObjectUid(commParam.getSRCSYSTEM(), MDMAttributeNames.ENTITY_COMM));
				// set input values
				/*if (partyParam.getLASTUPDATEDATE() != null && partyParam.getLASTUPDATEDATE().length() > 0) {
					record.setField(new Field(MDMAttributeNames.LAST_UPDATE_DATE, partyParam.getLASTUPDATEDATE()));
				} else {*/
					LOG.info("Performing cleansePutCommunication with sysdate from HUB: " + lastUpdateDate);
					record.setField(new Field(MDMAttributeNames.LAST_UPDATE_DATE, lastUpdateDate));
				/*}*/
				record.setField(new Field(MDMAttributeNames.SRC_UPDT_BY, commParam.getUPDATEBY()));
				record.setField(new Field(MDMAttributeNames.SRC_SYSTEM, commParam.getSRCSYSTEM()));
				record.setField(new Field(MDMAttributeNames.SRC_SYS_KEY, commParam.getSRCPKEY()));

				record.setField(new Field(CommunicationAttributes.COMM_STATUS, commParam.getCOMMSTATUS()));

				if (commParam.getCOMMTYPE() != null && commParam.getCOMMTYPE().length() > 0) {
					record.setField(new Field(CommunicationAttributes.COMM_TYPE, commParam.getCOMMTYPE()));
				}
				record.setField(new Field(CommunicationAttributes.COMM_VALUE, commParam.getCOMMVALUE()));
				LOG.debug("commParam.getCOMMVALUE() is: " + commParam.getCOMMVALUE());
				record.setField(new Field(CommunicationAttributes.PRFRD_COMM_IND, commParam.getPRFRDCOMMIND()));
				record.setField(new Field(CommunicationAttributes.WEB_DOMAIN, commParam.getWEBDOMAIN()));
				// record.setField(new
				// Field(CommunicationAttributes.COMM_MKTG_PREF,
				// commParam.getCOMMMKTGPREF()));

				record.setField(new Field(CommunicationAttributes.COMM_EXTN, commParam.getCOMMEXTN()));
				record.setField(
						new Field(MDMAttributeNames.PARTY_SRC_SYS_KEY, partyParam.getXREF().get(0).getSRCPKEY()));

				cleansePutRequest.setRecord(record);
				// execute Put request
				cleansePutResponse = (CleansePutResponse) siperianClient.process(cleansePutRequest);
				LOG.info("Communication cleansePut request processed successfully: " + cleansePutResponse.getMessage());
				// extract result
				RecordKey recordKey = cleansePutResponse.getRecordKey();

				PutResponseDataHolder responseDataHolder = new PutResponseDataHolder();
				responseDataHolder.setActionType(cleansePutResponse.getActionType());
				responseDataHolder.setActionMessage(cleansePutResponse.getMessage());
				responseDataHolder.setRowidObject(recordKey.getRowid());
				responseDataHolder.setRowidXREF(recordKey.getRowidXref());
				responseDataHolder.setSourceKey(recordKey.getSourceKey());
				responseDataHolder.setSystemName(recordKey.getSystemName());
				responseDataHolderList.add(responseDataHolder);
				LOG.info("ROWID_OBJECT of created Communication record = " + recordKey.getRowid());
				LOG.debug("Action Type = " + responseDataHolder.getActionType());
				LOG.debug("Action Msg = " + responseDataHolder.getActionMessage());
			} catch (SiperianServerException sifExcp) {
				LOG.error("SiperianServerException occured while processing CleansePutRequest for Communication: "
						+ sifExcp);
				LOG.error("sifExcp msg " + sifExcp);
				ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
				customException.setMessage("SIF exception occured while processing Put request for Communication. "
						+ customException.getMessage());
				customException.setRootExceptionMsg(
						sifExcp + " CleansePut operation failed for Communication " + commParam.getSRCPKEY().replaceAll(Constant.ADB_ACT_PREFIX, Constant.STR_BLANK));
				sifExcp.printStackTrace();
				throw customException;
			} catch (Exception excp) {
				LOG.error("Exception occured while processing CleansePutRequest for Communication: " + excp);
				excp.printStackTrace();
				ServiceProcessingException customException = new ServiceProcessingException(excp);
				customException.setMessage("Exception occured while processing Put request for Communication. "
						+ customException.getMessage());
				customException.setRootExceptionMsg(
						excp + " CleansePut operation failed for Communication " + commParam.getSRCPKEY().replaceAll(Constant.ADB_ACT_PREFIX, Constant.STR_BLANK));
				excp.printStackTrace();
				throw customException;
			}
		}

		LOG.info("Executed cleansePutCommunication()");
		return responseDataHolderList;
	}

	/**
	 * The method prepares and executes CleansePutRequest on PARTY_REL landing
	 * table for the given Contact profiles.
	 * 
	 * @param upsertResponse
	 * @param contactRowid
	 * @param rowIdAccount
	 * @param srcSystem
	 * @param srcPkey
	 * @param relLastUpdateDate
	 * @return putResponseActnCntctDataHolder
	 * @throws ServiceProcessingException
	 */
	private PutResponseDataHolder cleansePutAccountContactRel(MdmUpsertPartyResponse upsertResponse,
			String contactRowid, String rowIdAccount, String srcSystem, String srcPkey, String relLastUpdateDate)
			throws ServiceProcessingException {
		LOG.debug("[cleansePutAccountContactRel] ENTER");
		LOG.debug("[cleansePutAccountContactRel] contactRowid::" + contactRowid + ", rowIdAccount::" + rowIdAccount
				+ ", srcSystem::" + srcSystem + ", srcPkey::" + srcPkey + ", relLastUpdateDate::" + relLastUpdateDate);
		UserTransaction transaction = null;
		SiperianClient siperianClient = null;
		lastUpdateDate = Util.getCurrentTimeZone();
		PutResponseDataHolder responseDataHolder = new PutResponseDataHolder();
		try {
			siperianClient = (SiperianClient) checkOut();
			transaction = ((EjbSiperianClient) siperianClient).createTX(300000);
			transaction.begin();
			CleansePutRequest cleansePutRequest = new CleansePutRequest();
			Record record = new Record();
			record.setSiperianObjectUid(Util.getMappingObjectUid(srcSystem, MDMAttributeNames.ENTITY_RELATION));
			if (Util.isNullOrEmpty(relLastUpdateDate)) {
				LOG.info("Performing cleansePutParty with sysdate from HUB: " + lastUpdateDate);
				record.setField(new Field(MDMAttributeNames.LAST_UPDATE_DATE, lastUpdateDate));
			} else {
				record.setField(new Field(MDMAttributeNames.LAST_UPDATE_DATE, relLastUpdateDate));
			}
			record.setField(new Field(MDMAttributeNames.SRC_SYSTEM, srcSystem));
			record.setField(new Field(MDMAttributeNames.SRC_SYS_KEY, srcPkey));
			record.setField(new Field(MDMAttributeNames.PARENT_ID, rowIdAccount));
			record.setField(new Field(MDMAttributeNames.CHILD_ID, contactRowid));
			record.setField(new Field(MDMAttributeNames.HIERARCHY_CODE, Constant.ROWID_CONTACT_HIERARCHY_TYPE));
			record.setField(new Field(MDMAttributeNames.REL_TYPE_CODE, Constant.ROWID_CONTACT_REL_TYPE));
			cleansePutRequest.setRecord(record);
			CleansePutResponse cleansePutResponse = (CleansePutResponse) siperianClient.process(cleansePutRequest);
			LOG.info("Account Contact Rel Put request processed successfully: " + cleansePutResponse.getMessage());
			RecordKey recordKey = cleansePutResponse.getRecordKey();
			responseDataHolder.setActionType(cleansePutResponse.getActionType());
			responseDataHolder.setActionMessage(cleansePutResponse.getMessage());
			responseDataHolder.setRowidObject(recordKey.getRowid());
			responseDataHolder.setRowidXREF(recordKey.getRowidXref());
			responseDataHolder.setSourceKey(recordKey.getSourceKey());
			responseDataHolder.setSystemName(recordKey.getSystemName());
			LOG.info("ROWID_OBJECT of created Party Account Rel record = " + recordKey.getRowid()
					+ "\nPKEY_SRC  of created Party Account Rel record = " + recordKey.getSourceKey());
			transaction.commit();
		} catch (Exception ex) {

			LOG.error("Exception occured while preparing/processing cleansePut requests: ", ex);
			try {
				transaction.rollback();
			} catch (SystemException txExcp) {
				LOG.error("Failed to rollback transaction for cleansePut requests : ", txExcp);
			}
			ServiceProcessingException customException = new ServiceProcessingException(ex);
			customException.setMessage("Failed to process cleansePut SIF request." + customException.getMessage());
			throw customException;
		} finally {
			checkIn(siperianClient);
		}
		LOG.debug("[cleansePutAccountContactRel] EXIT");
		return responseDataHolder;
	}

	/**
	 * The method prepares and executes CleansePutRequest on PARTY_REL landing
	 * table for the given Contact profiles.
	 * 
	 * @param upsertResponse
	 * @param existingContactRowidList
	 * @param rowIdAccount
	 * @param srcSystem
	 * @param srcPkey
	 * @param relLastUpdateDate
	 * @return putResponseActnCntctDataHolder
	 * @throws ServiceProcessingException
	 */
	private List<PutResponseDataHolder> cleansePutAccountContactRel(MdmUpsertPartyResponse upsertResponse,
			List<CntctPkeyRowIdRelData> existingContactRowidList, String rowIdAccount, String srcSystem, String srcPkey,
			String relLastUpdateDate) throws ServiceProcessingException {
		LOG.debug("[cleansePutAccountContactRel] ENTER");
		List<PutResponseDataHolder> putResponseActnCntctDataHolder = new ArrayList<PutResponseDataHolder>();
		try {
			for (CntctPkeyRowIdRelData existingContactRowid : existingContactRowidList) {

				/** US478 : Retry on cleanse Put Start **/
				int cleansePutAccountContactcountOfRetry = Integer.parseInt(configProps.getProperty("NoOfRetries"));
				boolean iscleansePutRetrySuccess = false;
				PutResponseDataHolder responseDataHolder = null;
				try {
					responseDataHolder = cleansePutAccountContactRel(upsertResponse,
							existingContactRowid.getContactRowId(), rowIdAccount, srcSystem, srcPkey,
							relLastUpdateDate);
				} catch (Exception servExcp) {
					LOG.error("Exception occured while cleansePut AccountContact: ", servExcp);
					for (int i = 0; i < cleansePutAccountContactcountOfRetry; i++) {
						try {
							LOG.debug("Retrying cleansePut AccountContact for " + (i + 1) + "th time");
							responseDataHolder = cleansePutAccountContactRel(upsertResponse,
									existingContactRowid.getContactRowId(), rowIdAccount, srcSystem, srcPkey,
									relLastUpdateDate);
							LOG.debug("Retry cleansePut AccountContact is successful on attempt no. " + (i + 1));
							iscleansePutRetrySuccess = true;
							break;
						} catch (Exception excp) {
							LOG.error("Exception occured in cleansePut AccountContact Retry on attempt no. " + (i + 1));
							LOG.error("Exception occured in cleansePut AccountContact RetryMechanism...");
						}

					}
					if (!iscleansePutRetrySuccess) {
						upsertResponse.setErrorMsg("CleansePut operation failed for Account - Contact Rel" + srcPkey);
						ServiceProcessingException customException = new ServiceProcessingException(servExcp);
						customException.setMessage("SIF exception occured while processing cleansePut AccountContact : "
								+ customException.getMessage());
						throw customException;
					}
				}

				/** US478 : Retry on cleanse Put END **/

				putResponseActnCntctDataHolder.add(responseDataHolder);
				existingContactRowid.setIsCleansePut(Boolean.TRUE);
			}
		} catch (ServiceProcessingException ex) {
			throw ex;
		} catch (Exception ex) {
			upsertResponse.setErrorMsg("CleansePut operation failed for Account - Contact Rel" + srcPkey);
			LOG.error("Exception occured while preparing/processing cleansePut requests: ", ex);
			ServiceProcessingException customException = new ServiceProcessingException(ex);
			customException.setMessage("Failed to process cleansePut SIF request." + customException.getMessage());
			throw customException;
		}
		LOG.debug("[cleansePutAccountContactRel] EXIT");
		return putResponseActnCntctDataHolder;
	}
	
	public String getADBCountryName(String countrycd) {
		LOG.debug("Inside getADBCountryName()");
		PreparedStatement statement = null;
		Connection jdbcConn = null;
		ResultSet resultSet = null;
		String countryName = null;
		JDBCConnectionProvider jDBCConnectionProvider = null;
		try {
			jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
			jdbcConn = jDBCConnectionProvider.getJdbcConnectionFromDS();
			LOG.info("getADBCountryName  countrycode : " + countrycd);
			StringBuilder sql = new StringBuilder();
			sql.append("select ADB_COUNTRY_NM from MDM_COUNTRY where ADB_COUNTRY_CD= ?");
			LOG.debug("SQL Generated is : " + sql.toString());
			statement = jdbcConn.prepareStatement(sql.toString());
			statement.setString(1, countrycd);
			resultSet = statement.executeQuery();
			if (resultSet.next()) {
				countryName = resultSet.getString(1);
			}
			LOG.debug("countryName value is: " + countryName);
		} catch (Exception exp) {
			exp.printStackTrace();
		} finally {
			try {
				if (resultSet != null)
					resultSet.close();
				if (statement != null)
					statement.close();
				if (jdbcConn != null)
					jdbcConn.close();
			} catch (SQLException exp) {
				LOG.error("Caught SQLException in getADBCountryName().");
			}

		}
		return countryName;
	}

	private Map<String, List<String>> fetchPartyRowIdByUcn(String ucn) {
	
		Statement statement = null;
		StringBuilder sqlQry = new StringBuilder();
		List<String> partyRowid = new ArrayList<String>();;
		Connection jdbcConnection = null;
		ResultSet resultSet = null;
		Map<String, List<String>> rowIdPartyTypeMap = new HashMap<String, List<String>>();
		
		try {

			JDBCConnectionProvider jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();

			if ( !Util.isNullOrEmpty(ucn))	{

				LOG.info("Fetching Party_rowid for UCN: " + ucn);

				sqlQry.append("SELECT ROWID_OBJECT FROM C_B_PARTY WHERE UCN = ('" + ucn + "')");
				sqlQry.append(" AND HUB_STATE_IND = '1' AND STATUS_CD = 'A' AND BO_CLASS_CODE = 'Organization' ");
				sqlQry.append(" AND PARTY_TYPE in ('Customer')");

				LOG.debug("Query to fetch Party_rowid using UCN : " + sqlQry);


				jdbcConnection = jDBCConnectionProvider.getJdbcConnectionFromDS();
				statement = jdbcConnection.createStatement();
				resultSet = statement.executeQuery(sqlQry.toString());
				
				while(resultSet.next()){
					String rowid = resultSet.getString(1);
					if(!Util.isNullOrEmpty(rowid)){
						partyRowid.add(rowid);
						break;
					}
					
				}
				
			}			

		} catch (SQLException sqlEx) {
			LOG.error("Exception in fetchPartyRowIdByUcn for ID based Search: " , sqlEx);
			ServiceProcessingException customException = new ServiceProcessingException(sqlEx);
			customException.setMessage("Failed to fetch Party profile from ORS." + customException.getMessage());
		} catch (ServiceProcessingException sqlEx) {
			LOG.error("Exception in fetchPartyRowIdByUcn for ID based Search: " , sqlEx);
			ServiceProcessingException customException = new ServiceProcessingException(sqlEx);
			customException.setMessage("Failed to fetch Party profile from ORS." + customException.getMessage());
		}	finally {
			try {
					if( resultSet != null)	resultSet.close();
					if( statement != null) statement.close();
					if(jdbcConnection != null) jdbcConnection.close();
				} catch (SQLException e) {

					LOG.debug("Caught SQLException in getGoldenRecforID: " , e);
				}
		}
		
		if(partyRowid!=null && !partyRowid.isEmpty()){
			rowIdPartyTypeMap.put(Constant.CURRENT_ACTIVE_PARTY, partyRowid);			
		}
		return rowIdPartyTypeMap;
	}
	
	private List<String> getcontactRelRowId(String contactRowIds, String rowIdParty) {
		
		Statement statement = null;
		StringBuilder sqlQry = new StringBuilder();
		List<String> contactRelRowid = new ArrayList<String>();;
		Connection jdbcConnection = null;
		ResultSet resultSet = null;
		try {

			JDBCConnectionProvider jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
			sqlQry.append("SELECT ROWID_OBJECT FROM C_B_PARTY_REL WHERE ROWID_PARTY_2 in ("+contactRowIds+") ");
			sqlQry.append("AND ROWID_PARTY = '"+rowIdParty+"' ");
			sqlQry.append("AND ROWID_HIERARCHY = '4' AND ROWID_REL_TYPE = '25' AND HUB_STATE_IND<>-1");
			jdbcConnection = jDBCConnectionProvider.getJdbcConnectionFromDS();
			statement = jdbcConnection.createStatement();
			resultSet = statement.executeQuery(sqlQry.toString());
			
			while(resultSet.next()){
				LOG.info("Contact rel rowid list: " +  resultSet.getString(1));
				contactRelRowid.add(resultSet.getString(1));
			}
		}catch (SQLException sqlEx) {
			LOG.error("Exception in fetchPartyRowIdByUcn for ID based Search: " , sqlEx);
			ServiceProcessingException customException = new ServiceProcessingException(sqlEx);
			customException.setMessage("Failed to fetch Party profile from ORS." + customException.getMessage());
		} catch (ServiceProcessingException sqlEx) {
			LOG.error("Exception in fetchPartyRowIdByUcn for ID based Search: " , sqlEx);
			ServiceProcessingException customException = new ServiceProcessingException(sqlEx);
			customException.setMessage("Failed to fetch Party profile from ORS." + customException.getMessage());
		}	finally {
			try {
					if( resultSet != null)	resultSet.close();
					if( statement != null) statement.close();
					if(jdbcConnection != null) jdbcConnection.close();
				} catch (SQLException e) {

					LOG.debug("Caught SQLException in getGoldenRecforID: " , e);
				}
		}

		return contactRelRowid;
	}
	
	private Map<String, List<String>> fetchPartyRowIdByContact(String srcPkey) {
		
		Map<String, List<String>> rowIdPartyTypeMap = new HashMap<String, List<String>>();
		
		Statement statement = null;
		StringBuilder sqlQry = new StringBuilder();
		String partyRowId = "";
		Connection jdbcConnection = null;
		ResultSet resultSet = null;
		List<String> list = new ArrayList<String>();
		try {

			JDBCConnectionProvider jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
			sqlQry.append("select ROWID_PARTY from(SELECT ROWID_PARTY,last_update_date,RANK() OVER (Order BY last_update_date desc) as rank ");
			sqlQry.append(" FROM C_B_PARTY_REL WHERE ROWID_PARTY_2 in (SELECT C_B_PARTY_XREF.ROWID_OBJECT ");
			sqlQry.append(" FROM C_B_PARTY_XREF INNER JOIN C_B_PARTY_PERSON_XREF ON C_B_PARTY_XREF.PKEY_SRC_OBJECT = C_B_PARTY_PERSON_XREF.S_ROWID_PARTY ");
			sqlQry.append(" and C_B_PARTY_PERSON_XREF.PERSON_STATUS='A' and C_B_PARTY_PERSON_XREF.HUB_STATE_IND='1' ");
			sqlQry.append(" and C_B_PARTY_PERSON_XREF.SRC_ACCOUNT_ID = '"+srcPkey+"')");
			sqlQry.append(" AND ROWID_HIERARCHY = '4' AND ROWID_REL_TYPE = '25' AND HUB_STATE_IND<>-1), C_B_PARTY party where ROWID_PARTY =party.rowid_object ");
			sqlQry.append("  and rank=1 and party.party_type='Customer' AND party.HUB_STATE_IND = '1' AND party.STATUS_CD = 'A' AND party.BO_CLASS_CODE = 'Organization'");
			jdbcConnection = jDBCConnectionProvider.getJdbcConnectionFromDS();
			statement = jdbcConnection.createStatement();
			resultSet = statement.executeQuery(sqlQry.toString());
			
			while(resultSet.next()){
				partyRowId = resultSet.getString(1);
				break;
			}
		}catch (SQLException sqlEx) {
			LOG.error("Exception in fetchPartyRowIdByUcn for ID based Search: " , sqlEx);
			ServiceProcessingException customException = new ServiceProcessingException(sqlEx);
			customException.setMessage("Failed to fetch Party profile from ORS." + customException.getMessage());
		} catch (ServiceProcessingException sqlEx) {
			LOG.error("Exception in fetchPartyRowIdByUcn for ID based Search: " , sqlEx);
			ServiceProcessingException customException = new ServiceProcessingException(sqlEx);
			customException.setMessage("Failed to fetch Party profile from ORS." + customException.getMessage());
		}	finally {
			try {
					if( resultSet != null)	resultSet.close();
					if( statement != null) statement.close();
					if(jdbcConnection != null) jdbcConnection.close();
				} catch (SQLException e) {

					LOG.debug("Caught SQLException in getGoldenRecforID: " , e);
				}
		}
		if(!Util.isNullOrEmpty(partyRowId)){
			list.add(partyRowId);
			rowIdPartyTypeMap.put(Constant.CURRENT_ACTIVE_PARTY, list);
		}
		return rowIdPartyTypeMap;
	}
	
	private void processAcntCntctRel(PartyXrefType ptyXrefType, MdmUpsertPartyResponse upsertPartyResponse,
			boolean excuteNextStep, boolean retry, String rowidObject) throws ServiceProcessingException {
		
		LOG.debug("[processAcntCntctRel] ENTER");
		Map<String, Boolean> contactPkeyMap = new HashMap<String, Boolean>();
		XREFType xref = ptyXrefType.getXREF().get(0);
		String rowIdParty = getRowidFromPkey(xref, "C_B_PARTY");
		String srcSystem = ptyXrefType.getXREF().get(0).getSRCSYSTEM();
		String srcPkey = ptyXrefType.getXREF().get(0).getSRCPKEY();
		boolean accountExist = false;
		boolean accountRelExist = false;

		List<AcntCntctRelData> actnCntctRelDataList = prospectPartyDAO.getPendingAcntCntctRel(srcSystem, srcPkey,
				Constant.BO_CLASS_CODE_ORG, false);

		if (!CollectionUtils.isEmpty(actnCntctRelDataList)) {
			for (AcntCntctRelData actnCntctRelData : actnCntctRelDataList) {
				contactPkeyMap.put(actnCntctRelData.getCntctSrcPkey(), Boolean.TRUE);
			}
		}
		if (CollectionUtils.isEmpty(contactPkeyMap.keySet())) {
			LOG.debug("[processAcntCntctRel] No Contact Rel to process");
		} else {
			LOG.debug("[processAcntCntctRel] contactPkeyMap to process for Account::" + contactPkeyMap);
			String contactPkeys = StringUtils.collectionToDelimitedString(contactPkeyMap.keySet(), Constant.STR_COMMA,
					Constant.STR_SINGLE_QUOTE, Constant.STR_SINGLE_QUOTE);
			List<CntctPkeyRowIdRelData> existingContactRowidList = prospectPartyDAO.getContactRowIdsFromPkeysAdb(contactPkeys);
			List<String> pkeysToDeleteFromTempTable = new ArrayList<String>();
			if (!CollectionUtils.isEmpty(existingContactRowidList)) {
				List<PutResponseDataHolder> actnCntctDataHolderList = cleansePutAccountContactRel(upsertPartyResponse,
						existingContactRowidList, rowIdParty, srcSystem, srcPkey, null);
				for (CntctPkeyRowIdRelData existingContactRowid : existingContactRowidList) {
					if (existingContactRowid.getIsCleansePut()) {
						String curContactPkey = existingContactRowid.getContactPkey();
						if (contactPkeyMap.containsKey(curContactPkey) && contactPkeyMap.get(curContactPkey)) {
							pkeysToDeleteFromTempTable.add(curContactPkey);
						}
						contactPkeyMap.remove(curContactPkey);
					}
				}
			}
			prospectPartyDAO.deletePkeysFromTempTable(
					StringUtils.collectionToDelimitedString(pkeysToDeleteFromTempTable, Constant.STR_COMMA,
							Constant.STR_SINGLE_QUOTE, Constant.STR_SINGLE_QUOTE),
					srcSystem, srcPkey, Boolean.TRUE, Boolean.FALSE);
		}

		LOG.debug("[processAcntCntctRel] EXIT::");
		
	}
	
	
	
	public void putProcessStateInd(String Pkey, String processStateInd, String partyId,String srcSystem)
			throws ServiceProcessingException {

		LOG.debug("Inside putProcessStateInd() :: Pkey::"+Pkey+"      partyId::"+partyId);
		
		SiperianClient siperianClient = null;
		try {
			siperianClient = (SiperianClient) checkOut();
			PutRequest putRequest = new PutRequest();
			RecordKey reckey = new RecordKey();
			Record rec = new Record();

			if (Pkey != null) {
				Pkey = Pkey.trim();
				reckey.setSourceKey(Pkey);
			} else {
				reckey.setRowid(partyId);
			}
			reckey.setSystemName(srcSystem);
			putRequest.setRecordKey(reckey);

			rec.setSiperianObjectUid(SiperianObjectType.BASE_OBJECT.makeUid(MDMAttributeNames.PARTY_BO));
			rec.setField(new Field(PartyAttributes.PROCESS_STATE_IND, processStateInd));
			putRequest.setRecord(rec);

			LOG.debug("source key===" + putRequest.getRecordKey().getRowid());
			PutResponse response = (PutResponse) siperianClient.process(putRequest);
			LOG.debug("response msg-----" + response.getMessage());
		} catch (Exception exp) {
			LOG.error("Caught Exception in putPROCESSSTATEIND() ", exp);

		} finally {
			checkIn(siperianClient);
		}

		LOG.debug(" Executed putProcessStateInd() successfully ");

	}
	
	private void updateCI(List<String> recordList, String baseObjTable, SiperianClient siperianClient){
		LOG.info("updateCI usinf siperianClient");
		for(String rowid : recordList){
		SetRecordStateRequest srsReq = new SetRecordStateRequest();              
		srsReq.addRecordKey(RecordKey.rowid(rowid));
		srsReq.setRecordState(RecordState.NEWLY_LOADED); //This sets the consolidation_ind to 4
		srsReq.setSiperianObjectUid(SiperianObjectType.BASE_OBJECT.makeUid(baseObjTable));
		SetRecordStateResponse srsResp = (SetRecordStateResponse) siperianClient.process(srsReq);
		}
		LOG.info("updateCI using siperianClient end");
	}

}
