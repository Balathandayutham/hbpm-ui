package com.mcafee.mdm.dao;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.mcafee.mdm.constants.Constant;
import com.mcafee.mdm.dao.pojo.GlobalHierarchyNode;
import com.mcafee.mdm.dao.pojo.SearchedXrefRecordCollection;
import com.mcafee.mdm.exception.ServiceProcessingException;
import com.mcafee.mdm.generated.AccountXrefType;
import com.mcafee.mdm.generated.AddressXrefType;
import com.mcafee.mdm.generated.ClassificationXrefType;
import com.mcafee.mdm.generated.CommunicationXrefType;
import com.mcafee.mdm.generated.PartyAccountRelationshipType;
import com.mcafee.mdm.generated.PartyAccountRelationshipXrefType;
import com.mcafee.mdm.generated.PartyOrgExtXrefType;
import com.mcafee.mdm.generated.PartyPersonExtXrefType;
import com.mcafee.mdm.generated.PartyRelationshipType;
import com.mcafee.mdm.generated.PartyRelationshipXrefType;
import com.mcafee.mdm.generated.PartyXrefType;
import com.mcafee.mdm.generated.XREFType;
import com.mcafee.mdm.util.CanonicalFormManipulator;
import com.mcafee.mdm.util.JDBCConnectionProvider;
import com.mcafee.mdm.util.ObjectPool;
import com.mcafee.mdm.util.PropertyUtil;
import com.mcafee.mdm.util.Util;

@Component
public class SearchPartyXrefDAO extends ObjectPool {
	private static final Logger LOG = Logger.getLogger(SearchPartyXrefDAO.class.getName());
	Properties configProps = PropertyUtil.getPropertiesFromFile("configProp");
	String priorSRC1 = configProps.getProperty("Priority1");
	String priorSRC2 = configProps.getProperty("Priority2");
	String priorSRC3 = configProps.getProperty("Priority3");
	private String sipPopFromXref = null;
	private boolean hierarchyFuzzySearch = false;


	public String getSipPopFromXref() {
		return sipPopFromXref;
	}
	public void setSipPopFromXref(String sipPopFromXref) {
		this.sipPopFromXref = sipPopFromXref;
	}
	
	public void setHierarchyFuzzySearch(boolean hierarchyFuzzySearch) {
		this.hierarchyFuzzySearch = hierarchyFuzzySearch;
	}
	
	public boolean getHierarchyFuzzySearch() {
		return hierarchyFuzzySearch;
	}
	//Method For Fuzzy Match
	public Map<String, List<PartyXrefType>> processXrefSearchRequest(Set<String> rowidSet,String srcSystem) throws ServiceProcessingException {
		LOG.info("Executing processXrefSearchRequest()");


	//	String rowidObject = rowidObj;
		Map<String, List<PartyXrefType>> partyXrefMap = new HashMap<String, List<PartyXrefType>>();

		partyXrefMap = getAllPartyXref(rowidSet,srcSystem);

/*		SiperianClient siperianClient = null;
  		XREFCopy xrefCopy = null;
		List<XREFCopy> xrefCopyList = null;
		List<PartyXrefType> partyXrefList = new ArrayList<PartyXrefType>();
		List<PartyXrefType> tempPartyXrefList = new ArrayList<PartyXrefType>();
		HashMap<String, List<PartyXrefType>> legacyIdMap = new HashMap<String, List<PartyXrefType>>();

		List<PartyXrefType> legacyPartyXrefList = null;


		SearchQueryRequest searchQueryRequest = null;
		SearchQueryResponse searchQueryResponse = null;

		// StringBuffer criteria = new StringBuffer();
		searchQueryRequest = new SearchQueryRequest();
		searchQueryRequest.setRecordsToReturn(recCntThres); // Required
		searchQueryRequest.setSiperianObjectUid("PKG_XREF_FOR_SEARCH");// Required
		// searchMatchRequest.setSiperianObjectUid(SiperianObjectType.BASE_OBJECT.makeUid("C_B_ACCOUNT"));//
		// Required

	//	System.out.println("Match Rule Set: "+ searchMatchRequest.getMatchRuleSetUid());
	//	System.out.println("Match Type :" + searchMatchRequest.getMatchType());

		StringBuffer criteria = new StringBuffer();
	//	boolean firstParam = false;

		criteria.append(" PARTY_ROWID_OBJECT='"+ rowidObject + "'");

	//	criteria.append(" AND HUB_STATE_IND='" + 1 + "'");

		//Removing Soft-Deleted Records from Search
		criteria.append(" AND HUB_STATE_IND !='" + -1 + "'");
		//Fetching Active Records from Search
		criteria.append(" AND STATUS_CD ='" + "A" + "'");

		LOG.info("Filter Criteria: " + criteria.toString());

		searchQueryRequest.setFilterCriteria(criteria.toString());
		try {
			siperianClient = (SiperianClient) checkOut();

			LOG.info("processing SearchQueryRequest");
			searchQueryResponse = (SearchQueryResponse) siperianClient.process(searchQueryRequest);
			LOG.info("after response");
		} catch (Exception e) {
			// LOG.error(Constant.connectionError + "::" + e.getMessage());
			// throw new SearchFault(Constant.unExpectedError);
			LOG.error(" Error Message: " + e.getMessage());
		} finally {
			checkIn(siperianClient);
		}

		try {
			LOG.info("SearchQueryRequest rec cnt="
					+ searchQueryResponse.getRecords().size());
			if (searchQueryResponse != null
					&& searchQueryResponse.getRecords().size() > 0) {



		//		partyXrefList = new ArrayList<PartyXrefType>();
		//		tempPartyXrefList = new ArrayList<PartyXrefType>();
				xrefCopyList = new ArrayList<XREFCopy>();
				PartyXrefType partyResponse = null;

				XREFType xref = null;
				CommunicationXrefType communication = null;
				AccountXrefType accInfo = null;
				AddressXrefType address = null;
				ClassificationXrefType classfction = null;
				PartyOrgExtXrefType partyOrgExt = null;
				PartyPersonExtXrefType partyPersonExt = null;
				PartyRelationshipXrefType partyRelationship = null;

				List<AccountXrefType> listAccInfo = null;
				List<AddressXrefType> listAddress = null;
				List<CommunicationXrefType> listComm = null;
				Collection listXref = null;
				List<ClassificationXrefType> listClass = null;
				List<PartyOrgExtXrefType> listPartyOrgExt = null;
				List<PartyPersonExtXrefType> listPartyPerson = null;
				List<PartyRelationshipXrefType> listRelType = null;

				List searchRecords = searchQueryResponse.getRecords();


				Map<String, SearchedXrefRecordCollection> searchedRecCollMap = new HashMap<String, SearchedXrefRecordCollection>();
				SearchedXrefRecordCollection searchedRecCollObj;
				boolean bUniqueRec = false;


				if (searchRecords != null && searchRecords.size() != 0) {
					for (Iterator iter = searchRecords.iterator(); iter
							.hasNext();) {

						Record record = (Record) iter.next();

						String partyRowIdXref = record.getField("ORIG_ROWID_OBJECT").getStringValue();

						if (!searchedRecCollMap.containsKey(partyRowIdXref)) {

							LOG.debug("Populate searchedRecCollMap for new PARTY_ROWID " + partyRowIdXref);
							searchedRecCollMap.put(partyRowIdXref, new SearchedXrefRecordCollection());
							bUniqueRec = true;
						}

						searchedRecCollObj = searchedRecCollMap.get(partyRowIdXref);

						if(bUniqueRec)	{

						LOG.debug("============setting PartyResponse");
				//		partyResponse = new PartyXrefType();

						if (record.getField("PARTY_ROWID_OBJECT").getStringValue() != null) {

					//		partyResponse.setROWIDOBJECT(record.getField("PARTY_ROWID_OBJECT").getStringValue());
							searchedRecCollObj.setParty_rowid(record.getField("PARTY_ROWID_OBJECT").getStringValue());
						}
						if (record.getField("ORIG_ROWID_OBJECT").getStringValue() != null) {

					//		partyResponse.setORIGROWIDOBJECT(record.getField("ORIG_ROWID_OBJECT").getStringValue());
							searchedRecCollObj.setOrig_rowid(record.getField("ORIG_ROWID_OBJECT").getStringValue());
						}
						if (record.getField("BO_CLASS_CODE").getStringValue() != null) {

					//		partyResponse.setBOCLASSCODE(record.getField("BO_CLASS_CODE").getStringValue());
							searchedRecCollObj.setBo_class(record.getField("BO_CLASS_CODE").getStringValue());
						}
						if (record.getField("PARTY_TYPE").getStringValue() != null) {

					//		partyResponse.setPARTYTYPE(record.getField("PARTY_TYPE").getStringValue());
							searchedRecCollObj.setParty_type(record.getField("PARTY_TYPE").getStringValue());
						}
						if (record.getField("PARTY_NAME").getStringValue() != null) {

					//		partyResponse.setPARTYNAME(record.getField("PARTY_NAME").getStringValue());
							searchedRecCollObj.setParty_name(record.getField("PARTY_NAME").getStringValue());
						}
						if (record.getField("PARTY_GEO").getStringValue() != null) {
					//		partyResponse.setGEO(record.getField("PARTY_GEO").getStringValue());
							searchedRecCollObj.setGeo(record.getField("PARTY_GEO").getStringValue());
						}
						if (record.getField("PARTY_REGION").getStringValue() != null) {
						//	partyResponse.setREGION(record.getField("PARTY_REGION").getStringValue());
							searchedRecCollObj.setRegion(record.getField("PARTY_REGION").getStringValue());
						}
						if (record.getField("STATUS_CD").getStringValue() != null) {
					//		partyResponse.setSTATUSCD(record.getField("STATUS_CD").getStringValue());
							searchedRecCollObj.setStatus_cd(record.getField("STATUS_CD").getStringValue());
						}
						if (record.getField("PARTY_VAT_REG_NBR").getStringValue() != null) {
					//		partyResponse.setVATREGNBR(record.getField("PARTY_VAT_REG_NBR").getStringValue());
							searchedRecCollObj.setVat_regno(record.getField("PARTY_VAT_REG_NBR").getStringValue());
						}
						if (record.getField("PARTY_TAX_JURSDCTN_CD").getStringValue() != null) {
					//		partyResponse.setTAXJURSDCTNCD(record.getField("PARTY_TAX_JURSDCTN_CD").getStringValue());
							searchedRecCollObj.setTax_jd_cd(record.getField("PARTY_TAX_JURSDCTN_CD").getStringValue());
						}
						if (record.getField("SALES_BLOCK_CD").getStringValue() != null) {
					//		partyResponse.setSALESBLOCKCD(record.getField("SALES_BLOCK_CD").getStringValue());
							searchedRecCollObj.setSales_cd(record.getField("SALES_BLOCK_CD").getStringValue());
						}
						if (record.getField("UCN").getStringValue() != null) {
					//		partyResponse.setUCN(record.getField("UCN").getStringValue());
							searchedRecCollObj.setUcn(record.getField("UCN").getStringValue());
						}



						LOG.debug("============setting XREFType");
						xref = new XREFType();
						xref.setSRCSYSTEM(record.getField("PARTY_ROWID_SYSTEM").getStringValue());
						xref.setSRCPKEY(record.getField("PARTY_PKEY_SRC_OBJECT").getStringValue());

						LOG.debug("===Inserting into XREFType list===");
			//			listXref = new ArrayList<XREFType>();
			//			listXref.add(xref);
			//			partyResponse.getXREF().addAll(listXref);
						searchedRecCollObj.getXrefMap().put(partyRowIdXref, xref);


				}



						if (record.getField("ACCOUNT_ROWID_OBJECT").getStringValue() != null &&
								!searchedRecCollObj.getAccountMap().containsKey(record.getField("ACCOUNT_ROWID_OBJECT").getStringValue())) {

						LOG.debug("============setting AccountType");
						accInfo = new AccountXrefType();

						if (record.getField("ACCOUNT_ROWID_OBJECT").getStringValue() != null) {
							accInfo.setROWIDACCOUNT(record.getField(
									"ACCOUNT_ROWID_OBJECT").getStringValue());
						}
						if (record.getField("ACCOUNT_ROWID_SYSTEM").getStringValue() != null) {
							accInfo.setSRCSYSTEM(record.getField(
									"ACCOUNT_ROWID_SYSTEM").getStringValue());
						}
						if (record.getField("ACCOUNT_PKEY_SRC_OBJECT").getStringValue() != null) {
							accInfo.setSRCPKEY(record.getField(
									"ACCOUNT_PKEY_SRC_OBJECT").getStringValue());
						}

						if (record.getField("ACCT_NAME").getStringValue() != null) {
							accInfo.setACCTNAME(record.getField("ACCT_NAME")
									.getStringValue());
						}
						if (record.getField("ALIAS_NAME").getStringValue() != null) {
							accInfo.setALIASNAME(record.getField("ALIAS_NAME")
									.getStringValue());
						}
						if (record.getField("ACCT_STATUS").getStringValue() != null) {
							accInfo.setACCTSTATUS(record
									.getField("ACCT_STATUS").getStringValue());
						}
						if (record.getField("ACCT_TYPE").getStringValue() != null) {
							accInfo.setACCTTYPE(record.getField("ACCT_TYPE")
									.getStringValue());
						}
						if (record.getField("ACCOUNT_REGION").getStringValue() != null) {
							accInfo.setACCOUNTREGION(record.getField(
									"ACCOUNT_REGION").getStringValue());
						}
						if (record.getField("ACCOUNT_GEO").getStringValue() != null) {
							accInfo.setACCOUNTGEO(record
									.getField("ACCOUNT_GEO").getStringValue());
						}
						if (record.getField("MARKET").getStringValue() != null) {
							accInfo.setMARKET(record.getField("MARKET")
									.getStringValue());
						}
						if (record.getField("CUST_GROUP").getStringValue() != null) {
							accInfo.setCUSTGROUP(record.getField("CUST_GROUP")
									.getStringValue());
						}
						if (record.getField("PRICE_GROUP").getStringValue() != null) {
							accInfo.setPRICEGROUP(record
									.getField("PRICE_GROUP").getStringValue());
						}
						if (record.getField("COMPANY_CD").getStringValue() != null) {
							accInfo.setCOMPANYCD(record.getField("COMPANY_CD")
									.getStringValue());
						}
						if (record.getField("ACCOUNT_VAT_REG_NBR")
								.getStringValue() != null) {
							accInfo.setACCOUNTVATREGNBR(record.getField(
									"ACCOUNT_VAT_REG_NBR").getStringValue());
						}
						if (record.getField("TAX_TYPE").getStringValue() != null) {
							accInfo.setTAXTYPE(record.getField("TAX_TYPE")
									.getStringValue());
						}
						if (record.getField("ACCOUNT_TAX_JURDSCTN_CD").getStringValue() != null) {
							accInfo.setACCOUNTTAXJURSDCTNCD(record.getField("ACCOUNT_TAX_JURDSCTN_CD").getStringValue());
						}
						if (record.getField("BILL_BLOCK_CD").getStringValue() != null) {
							accInfo.setBILLBLOCKCD(record.getField(
									"BILL_BLOCK_CD").getStringValue());
						}
						if (record.getField("ORDR_BLOCK_CD").getStringValue() != null) {
							accInfo.setORDRBLOCKCD(record.getField(
									"ORDR_BLOCK_CD").getStringValue());
						}
						if (record.getField("DLVRY_BLOCK_CD").getStringValue() != null) {
							accInfo.setDLVRYBLOCKCD(record.getField(
									"DLVRY_BLOCK_CD").getStringValue());
						}
						if (record.getField("POST_BLOCK_CD").getStringValue() != null) {
							accInfo.setPOSTBLOCKCD(record.getField(
									"POST_BLOCK_CD").getStringValue());
						}
						if (record.getField("SALE_BLOCK_CD").getStringValue() != null) {
							accInfo.setSALEBLOCKCD(record.getField(
									"SALE_BLOCK_CD").getStringValue());
						}
						if (record.getField("CHANNEL_ID").getStringValue() != null) {
							accInfo.setCHANNELID(record.getField("CHANNEL_ID")
									.getStringValue());
						}
						if (record.getField("PARTNER_TYPE").getStringValue() != null) {
							accInfo.setPARTNERTYPE(record.getField(
									"PARTNER_TYPE").getStringValue());
						}
						if (record.getField("VENDOR_NBR").getStringValue() != null) {
							accInfo.setVENDORNBR(record.getField("VENDOR_NBR")
									.getStringValue());
						}
						if (record.getField("DIRECT_IND").getStringValue() != null) {
							accInfo.setDIRECTIND(record.getField("DIRECT_IND")
									.getStringValue());
						}
						if (record.getField("NAMED_ACCT_IND").getStringValue() != null) {
							accInfo.setNAMEDACCTIND(record.getField(
									"NAMED_ACCT_IND").getStringValue());
						}
						if (record.getField("NON_VAL_ACCT_IND")
								.getStringValue() != null) {
							accInfo.setNONVALACCTIND(record.getField(
									"NON_VAL_ACCT_IND").getStringValue());
						}
						if (record.getField("PARTNER_IND").getStringValue() != null) {
							accInfo.setPARTNERIND(record
									.getField("PARTNER_IND").getStringValue());
						}
						if (record.getField("SIEBEL_ROWID").getStringValue() != null) {
							accInfo.setSIEBELROWID(record
									.getField("SIEBEL_ROWID").getStringValue());
						}
						if (record.getField("SAP_CUST_NUMBER").getStringValue() != null) {
							accInfo.setSAPCUSTNUMBER(record
									.getField("SAP_CUST_NUMBER").getStringValue());
						}
						if (record.getField("MDM_LEGACY_ID").getStringValue() != null) {
							accInfo.setMDMLEGACYID(record.getField("MDM_LEGACY_ID").getStringValue());
						}

						LOG.debug("===Inserting into AccountType Map===");
						searchedRecCollObj.getAccountMap().put(record.getField("ACCOUNT_ROWID_OBJECT").getStringValue(), accInfo);

				}



						if (record.getField("ADDRESS_ROWID_OBJECT").getStringValue() != null &&
								!searchedRecCollObj.getAddressMap().containsKey(record.getField("ADDRESS_ROWID_OBJECT").getStringValue())) {

							LOG.debug("============setting AddressType");
						address = new AddressXrefType();
						if (record.getField("ADDRESS_ROWID_OBJECT").getStringValue() != null) {
							address.setROWIDADDRESS(record.getField(
									"ADDRESS_ROWID_OBJECT").getStringValue());
						}
						if (record.getField("ADDRESS_ROWID_SYSTEM").getStringValue() != null) {
							address.setSRCSYSTEM(record.getField(
									"ADDRESS_ROWID_SYSTEM").getStringValue());
						}
						if (record.getField("ADDRESS_PKEY_SRC_OBJECT").getStringValue() != null) {
							address.setSRCPKEY(record.getField(
									"ADDRESS_PKEY_SRC_OBJECT").getStringValue());
						}
						if (record.getField("ADDR_LN1").getStringValue() != null) {
							address.setADDRLN1(record.getField("ADDR_LN1")
									.getStringValue());
						}
						if (record.getField("ADDR_LN2").getStringValue() != null) {
							address.setADDRLN2(record.getField("ADDR_LN2")
									.getStringValue());
						}
						if (record.getField("ADDR_LN3").getStringValue() != null) {
							address.setADDRLN3(record.getField("ADDR_LN3")
									.getStringValue());
						}
						if (record.getField("ADDR_LN4").getStringValue() != null) {
							address.setADDRLN4(record.getField("ADDR_LN4")
									.getStringValue());
						}
						if (record.getField("CITY").getStringValue() != null) {
							address.setCITY(record.getField("CITY")
									.getStringValue());
						}
						if (record.getField("COUNTY").getStringValue() != null) {
							address.setCOUNTY(record.getField("COUNTY")
									.getStringValue());
						}
						if (record.getField("DISTRICT").getStringValue() != null) {
							address.setDISTRICT(record.getField("DISTRICT")
									.getStringValue());
						}
						if (record.getField("STATE_CD").getStringValue() != null) {
							address.setSTATECD(record.getField("STATE_CD")
									.getStringValue());
						}
						if (record.getField("POSTAL_CD").getStringValue() != null) {
							address.setPOSTALCD(record.getField("POSTAL_CD")
									.getStringValue());
						}
						if (record.getField("COUNTRY_CD").getStringValue() != null) {
							address.setCOUNTRYCD(record.getField("COUNTRY_CD")
									.getStringValue());
						}
						if (record.getField("LANG_CD").getStringValue() != null) {
							address.setLANGCD(record.getField("LANG_CD")
									.getStringValue());
						}
						if (record.getField("LONGITUDE").getStringValue() != null) {
							address.setLONGITUDE(record.getField("LONGITUDE")
									.getStringValue());
						}
						if (record.getField("LATITUDE").getStringValue() != null) {
							address.setLATITUDE(record.getField("LATITUDE")
									.getStringValue());
						}
						if (record.getField("ADDR_TYPE").getStringValue() != null) {
							address.setADDRTYPE(record.getField("ADDR_TYPE")
									.getStringValue());
						}
						if (record.getField("ADDR_STATUS").getStringValue() != null) {
							address.setADDRSTATUS(record
									.getField("ADDR_STATUS").getStringValue());
						}

						LOG.debug("===Inserting into Address Map===");
						searchedRecCollObj.getAddressMap().put(record.getField("ADDRESS_ROWID_OBJECT").getStringValue(), address);

				}





						if (record.getField("COMMUNICATION_ROWID_OBJECT").getStringValue() != null &&
								!searchedRecCollObj.getCommMap().containsKey(record.getField("COMMUNICATION_ROWID_OBJECT").getStringValue())) {


						communication = new CommunicationXrefType();
						LOG.debug("============adding CommunicationType ");

						if (record.getField("COMMUNICATION_ROWID_OBJECT")
								.getStringValue() != null) {
							communication.setROWIDCOMMUNICATION(record
									.getField("COMMUNICATION_ROWID_OBJECT")
									.getStringValue());
						}
						if (record.getField("COMMUNICATION_ROWID_SYSTEM")
								.getStringValue() != null) {
							communication.setSRCSYSTEM(record
									.getField("COMMUNICATION_ROWID_SYSTEM")
									.getStringValue());
						}
						if (record.getField("COMMUNICATION_PKEY_SRC_OBJECT")
								.getStringValue() != null) {
							communication.setSRCPKEY(record
									.getField("COMMUNICATION_PKEY_SRC_OBJECT")
									.getStringValue());
						}
						if (record.getField("COMM_TYPE").getStringValue() != null) {
							communication.setCOMMTYPE(record.getField(
									"COMM_TYPE").getStringValue());
						}
						if (record.getField("COMM_VALUE").getStringValue() != null) {
							communication.setCOMMVALUE(record.getField(
									"COMM_VALUE").getStringValue());
						}
						if (record.getField("COMM_STATUS").getStringValue() != null) {
							communication.setCOMMSTATUS(record.getField(
									"COMM_STATUS").getStringValue());
						}
						if (record.getField("PRFRD_COMM_IND").getStringValue() != null) {
							communication.setPRFRDCOMMIND(record.getField(
									"PRFRD_COMM_IND").getStringValue());
						}
						if (record.getField("WEB_DOMAIN").getStringValue() != null) {
							communication.setWEBDOMAIN(record.getField(
									"WEB_DOMAIN").getStringValue());
						}

						LOG.debug("===Inserting into Communication Map===");
						searchedRecCollObj.getCommMap().put(record.getField("COMMUNICATION_ROWID_OBJECT").getStringValue(), communication);

				}




						if (record.getField("PARTY_ORG_ROWID_OBJECT").getStringValue() != null &&
								!searchedRecCollObj.getPartyOrgMap().containsKey(record.getField("PARTY_ORG_ROWID_OBJECT").getStringValue())) {
							LOG.debug("============adding PartyOrgExtType ");

						partyOrgExt = new PartyOrgExtXrefType();
						LOG.debug("============adding PartyOrgExtType ");

						if (record.getField("PARTY_ORG_ROWID_OBJECT").getStringValue() != null) {
							partyOrgExt.setROWIDORGEXTN(record.getField(
									"PARTY_ORG_ROWID_OBJECT").getStringValue());
						}
						if (record.getField("PARTY_ORG_PKEY_SRC_OBJECT").getStringValue() != null) {
							partyOrgExt.setSRCPKEY(record.getField(
									"PARTY_ORG_PKEY_SRC_OBJECT").getStringValue());
						}
						if (record.getField("PARTY_ORG_ROWID_SYSTEM").getStringValue() != null) {
							partyOrgExt.setSRCSYSTEM(record.getField(
									"PARTY_ORG_ROWID_SYSTEM").getStringValue());
						}
						if (record.getField("ORG_DUNS_NBR").getStringValue() != null) {
							partyOrgExt.setORGDUNSNBR(record.getField(
									"ORG_DUNS_NBR").getStringValue());
						}
						if (record.getField("TRADE_NAME").getStringValue() != null) {
							partyOrgExt.setTRADENAME(record.getField(
									"TRADE_NAME").getStringValue());
						}
						if (record.getField("TRADE_NAME_2").getStringValue() != null) {
							partyOrgExt.setTRADENAME2(record.getField(
									"TRADE_NAME_2").getStringValue());
						}
						if (record.getField("SITE_EMPL_CNT").getStringValue() != null) {
							partyOrgExt.setSITEEMPLCNT(record.getField(
									"SITE_EMPL_CNT").getStringValue());
						}
						if (record.getField("GLBL_EMPL_CNT").getStringValue() != null) {
							partyOrgExt.setGLBLEMPLCNT(record.getField(
									"GLBL_EMPL_CNT").getStringValue());
						}
						if (record.getField("VERTICAL").getStringValue() != null) {
							partyOrgExt.setVERTICAL(record.getField("VERTICAL")
									.getStringValue());
						}
						if (record.getField("REVENUE").getStringValue() != null) {
							partyOrgExt.setREVENUE(record.getField("REVENUE")
									.getStringValue());
						}
						if (record.getField("LINE_OF_BUS").getStringValue() != null) {
							partyOrgExt.setLINEOFBUS(record.getField(
									"LINE_OF_BUS").getStringValue());
						}
						if (record.getField("PRIM_SIC").getStringValue() != null) {
							partyOrgExt.setPRIMSIC(record.getField("PRIM_SIC")
									.getStringValue());
						}
						if (record.getField("SEC_SIC").getStringValue() != null) {
							partyOrgExt.setSECSIC(record.getField("SEC_SIC")
									.getStringValue());
						}
						if (record.getField("SALES_VOLUME").getStringValue() != null) {
							partyOrgExt.setSALESVOLUME(record.getField(
									"SALES_VOLUME").getStringValue());
						}
						if (record.getField("SALES_AMOUNT").getStringValue() != null) {
							partyOrgExt.setSALESAMOUNT(record.getField(
									"SALES_AMOUNT").getStringValue());
						}
						if (record.getField("CURRENCY_CD").getStringValue() != null) {
							partyOrgExt.setCURRENCYCD(record.getField(
									"CURRENCY_CD").getStringValue());
						}
						if (record.getField("OUT_OF_BUS_IND").getStringValue() != null) {
							partyOrgExt.setOUTOFBUSIND(record.getField(
									"OUT_OF_BUS_IND").getStringValue());
						}
						if (record.getField("GLBL_ULT_IND").getStringValue() != null) {
							partyOrgExt.setGLBLULTIND(record.getField(
									"GLBL_ULT_IND").getStringValue());
						}
						if (record.getField("FORTUNE_INFO").getStringValue() != null) {
							partyOrgExt.setFORTUNEINFO(record.getField(
									"FORTUNE_INFO").getStringValue());
						}
						if (record.getField("HIERARCHY_LEVEL").getStringValue() != null) {
							partyOrgExt.setHIERARCHYLEVEL(record.getField(
									"HIERARCHY_LEVEL").getStringValue());
						}
						if (record.getField("ORG_HQ_PARENT_DUNS").getStringValue() != null) {
							partyOrgExt.setORGHQPARENTDUNS(record.getField(
									"ORG_HQ_PARENT_DUNS").getStringValue());
						}
						if (record.getField("ORG_DOM_ULT_DUNS").getStringValue() != null) {
							partyOrgExt.setORGDOMULTDUNS(record.getField(
									"ORG_DOM_ULT_DUNS").getStringValue());
						}
						if (record.getField("ORG_GLB_ULT_DUNS").getStringValue() != null) {
							partyOrgExt.setORGGLBULTDUNS(record.getField(
									"ORG_GLB_ULT_DUNS").getStringValue());
						}

						LOG.debug("===Inserting into PartyOrgExtType Map==");
						searchedRecCollObj.getPartyOrgMap().put(record.getField("PARTY_ORG_ROWID_OBJECT").getStringValue(), partyOrgExt);

				}



						if (record.getField("PARTY_PERSON_ROWID_OBJECT").getStringValue() != null &&
								!searchedRecCollObj.getPartyPersonMap().containsKey(record.getField("PARTY_PERSON_ROWID_OBJECT").getStringValue())) {


						partyPersonExt = new PartyPersonExtXrefType();
						LOG.debug("============adding PartyPersonExtType ");

						if (record.getField("PARTY_PERSON_ROWID_OBJECT").getStringValue() != null) {
							partyPersonExt.setROWIDPRSNEXTN(record.getField(
									"PARTY_PERSON_ROWID_OBJECT").getStringValue());
						}
						if (record.getField("PARTY_PERSON_PKEY_SRC_OBJECT").getStringValue() != null) {
							partyPersonExt.setSRCPKEY(record.getField(
									"PARTY_PERSON_PKEY_SRC_OBJECT").getStringValue());
						}
						if (record.getField("PARTY_PERSON_ROWID_SYSTEM").getStringValue() != null) {
							partyPersonExt.setSRCSYSTEM(record.getField(
									"PARTY_PERSON_ROWID_SYSTEM").getStringValue());
						}
						if (record.getField("PREFIX").getStringValue() != null) {
							partyPersonExt.setPREFIX(record.getField("PREFIX")
									.getStringValue());
						}
						if (record.getField("FIRST_NAME").getStringValue() != null) {
							partyPersonExt.setFIRSTNAME(record.getField(
									"FIRST_NAME").getStringValue());
						}
						if (record.getField("MIDDLE_NAME").getStringValue() != null) {
							partyPersonExt.setLASTNAME(record.getField(
									"MIDDLE_NAME").getStringValue());
						}
						if (record.getField("LAST_NAME").getStringValue() != null) {
							partyPersonExt.setLASTNAME(record.getField(
									"LAST_NAME").getStringValue());
						}
						if (record.getField("SUFFIX").getStringValue() != null) {
							partyPersonExt.setSUFFIX(record.getField("SUFFIX")
									.getStringValue());
						}
						if (record.getField("PERSON_TYPE").getStringValue() != null) {
							partyPersonExt.setPERSONTYPE(record.getField(
									"PERSON_TYPE").getStringValue());
						}

						LOG.debug("===Inserting into PartyPersonExtType List===");
						searchedRecCollObj.getPartyPersonMap().put(record.getField("PARTY_PERSON_ROWID_OBJECT").getStringValue(), partyPersonExt);
				}


						if (record.getField("PARTY_CLASS_ROWID_OBJECT").getStringValue() != null &&
								!searchedRecCollObj.getClassMap().containsKey(record.getField("PARTY_CLASS_ROWID_OBJECT").getStringValue())) {

						LOG.debug("============adding ClassificationType ");
						classfction = new ClassificationXrefType();

						if (record.getField("PARTY_CLASS_ROWID_OBJECT")
								.getStringValue() != null) {
							classfction.setROWIDCLASSIFICTN(record.getField("PARTY_CLASS_ROWID_OBJECT").getStringValue());
						}
						if (record.getField("PARTY_CLASS_PKEY_SRC_OBJECT")
								.getStringValue() != null) {
							classfction.setSRCPKEY(record.getField("PARTY_CLASS_PKEY_SRC_OBJECT").getStringValue());
						}
						if (record.getField("PARTY_CLASS_ROWID_SYSTEM")
								.getStringValue() != null) {
							classfction.setSRCSYSTEM(record.getField("PARTY_CLASS_ROWID_SYSTEM").getStringValue());
						}
						if (record.getField("CLASSIFCTN_TYPE").getStringValue() != null) {
							classfction.setCLASSIFICTNTYPE(record.getField(
									"CLASSIFCTN_TYPE").getStringValue());
						}
						if (record.getField("CLASSIFCTN_VALUE").getStringValue() != null) {
							classfction.setCLASSIFICTNVALUE(record.getField(
									"CLASSIFCTN_VALUE").getStringValue());
						}
						if (record.getField("START_DATE").getStringValue() != null) {
							classfction.setSTARTDATE(record.getField(
									"START_DATE").getStringValue());
						}
						if (record.getField("END_DATE").getStringValue() != null) {
							classfction.setENDDATE(record.getField(
									"END_DATE").getStringValue());
						}


						LOG.debug("===Inserting into Classification Map===");
						searchedRecCollObj.getClassMap().put(record.getField("PARTY_CLASS_ROWID_OBJECT").getStringValue(), classfction);

				}

						if (record.getField("PARTY_REL_ROWID_CHILD").getStringValue() != null &&
								!searchedRecCollObj.getPartyRelMap().containsKey(record.getField("PARTY_REL_ROWID_CHILD").getStringValue())) {
						LOG.debug("============adding RelationshipType ");

						partyRelationship = new PartyRelationshipXrefType();

						if (record.getField("PARTY_REL_ROWID_PARENT")
								.getStringValue() != null) {
							partyRelationship.setPARENTROWIDPARTY(record.getField("PARTY_REL_ROWID_PARENT").getStringValue());
						}
						if (record.getField("PARTY_REL_PKEY_SRC_OBJECT")
								.getStringValue() != null) {
							partyRelationship.setSRCPKEY(record.getField("PARTY_REL_PKEY_SRC_OBJECT").getStringValue());
						}
						if (record.getField("PARTY_REL_ROWID_SYSTEM")
								.getStringValue() != null) {
							partyRelationship.setSRCSYSTEM(record.getField("PARTY_REL_ROWID_SYSTEM").getStringValue());
						}
						if (record.getField("ROWID_REL_TYPE").getStringValue() != null) {
							partyRelationship.setRELTYPE(record.getField(
									"ROWID_REL_TYPE").getStringValue());
						}
						if (record.getField("ROWID_HIERARCHY").getStringValue() != null) {
							partyRelationship.setHIERARCHYTYPE(record.getField(
									"ROWID_HIERARCHY").getStringValue());
						}



						LOG.debug("===Inserting into Relationship Map===");
						searchedRecCollObj.getPartyRelMap().put(record.getField("PARTY_REL_ROWID_CHILD").getStringValue(), partyRelationship);

				}
					bUniqueRec = false;
				}
			}

				for (Entry<String, SearchedXrefRecordCollection> mapEntry : searchedRecCollMap.entrySet()) {


					LOG.debug("====Populating PartyXREFType");

					partyResponse = new PartyXrefType();
					partyResponse.setROWIDOBJECT(mapEntry.getValue().getParty_rowid());
					partyResponse.setORIGROWIDOBJECT(mapEntry.getValue().getOrig_rowid());
					partyResponse.setBOCLASSCODE(mapEntry.getValue().getBo_class());
					partyResponse.setPARTYTYPE(mapEntry.getValue().getParty_type());
					partyResponse.setPARTYNAME(mapEntry.getValue().getParty_name());
					partyResponse.setGEO(mapEntry.getValue().getGeo());
					partyResponse.setREGION(mapEntry.getValue().getRegion());
					partyResponse.setSALESBLOCKCD(mapEntry.getValue().getSales_cd());
					partyResponse.setSTATUSCD(mapEntry.getValue().getStatus_cd());
					partyResponse.setTAXJURSDCTNCD(mapEntry.getValue().getTax_jd_cd());
					partyResponse.setUCN(mapEntry.getValue().getUcn());
					partyResponse.setVATREGNBR(mapEntry.getValue().getVat_regno());

					LOG.debug("==Populating partyXREF's XREFType==");
					xref = new XREFType();
					partyResponse.getXREF().addAll(mapEntry.getValue().getXrefMap().values());


					partyResponse.getAccount().addAll(mapEntry.getValue().getAccountMap().values());
					partyResponse.getAddress().addAll(mapEntry.getValue().getAddressMap().values());
					partyResponse.getCommunication().addAll(mapEntry.getValue().getCommMap().values());
					partyResponse.getPartyOrgExt().addAll(mapEntry.getValue().getPartyOrgMap().values());
					partyResponse.getPartyPersonExt().addAll(mapEntry.getValue().getPartyPersonMap().values());
					partyResponse.getClassification().addAll(mapEntry.getValue().getClassMap().values());
					partyResponse.getPartyRelationship().addAll(mapEntry.getValue().getPartyRelMap().values());


					LOG.debug("====Populating TempList");
			//		xrefCopy = new XREFCopy();
			//		xrefCopy.getPartyXref().add(partyResponse);
			//		xrefCopyList.add(xrefCopy);
					tempPartyXrefList.add(partyResponse);
			//		partyXrefList.add(partyResponse);
			}

			LOG.info("tempPartyXrefList size: " + tempPartyXrefList.size());

			if(tempPartyXrefList != null && tempPartyXrefList.size() > 0)	{
					//Fetching Distinct LegacyID XREF Copy
					for(int indx = 0 ; indx < tempPartyXrefList.size() ; indx ++)	{
						LOG.debug("Executing 1st FOR LOOP.");

						String mdmLegacyId = tempPartyXrefList.get(indx).getAccount().get(0).getMDMLEGACYID();
						if (mdmLegacyId != null)	{

							LOG.info("mdmLegacyId: "+mdmLegacyId);

							if(legacyIdMap.containsKey(mdmLegacyId)) {

								LOG.info("legacyIdMap contains mdmLegacyId: ");
								legacyPartyXrefList.add(tempPartyXrefList.get(indx));
							} else {

								LOG.info("legacyIdMap does not contains mdmLegacyId: ");
								legacyPartyXrefList = new ArrayList<PartyXrefType>();
								legacyPartyXrefList.add(tempPartyXrefList.get(indx));
							}

							legacyIdMap.put(mdmLegacyId,legacyPartyXrefList);
							LOG.debug("Inserted data in legacyIdMap.");
						} else {
							LOG.debug("LegacyID is null for this XREF.");
							partyXrefList.add(tempPartyXrefList.get(indx));
						}
						LOG.debug("Executed 1st FOR LOOP.");
					}


					if (legacyIdMap != null && legacyIdMap.size() > 0)	{
						//Fetching Distinct LegacyID XREF Copy
						for(Entry<String, List<PartyXrefType>> entry : legacyIdMap.entrySet())	{
							LOG.debug("Executing 2nd FOR LOOP.");
							LOG.debug("legacyIdMap Key: "+ entry.getKey());
							List<PartyXrefType> tmpList = (List<PartyXrefType>) entry.getValue();
							if(tmpList.size() >= 2)	{
							//	LOG.debug("tmpList.size() >= 2");
								for(PartyXrefType pXrefType : tmpList)	{
								//	LOG.debug("tmpList PKEY: "+ pXrefType.getXREF().get(0).getSRCPKEY()+".");
								//	LOG.debug("tmpList SRC_SYS: "+ pXrefType.getXREF().get(0).getSRCSYSTEM()+".");
									if(pXrefType.getXREF().get(0).getSRCSYSTEM().trim().equalsIgnoreCase(priorSRC1))	{
										LOG.debug("tmpList SYSTEM: "+pXrefType.getXREF().get(0).getSRCSYSTEM().trim() + ".");
										partyXrefList.add(pXrefType);
										break;
									}
								}
							} else {
								partyXrefList.addAll(tmpList);
							}
							LOG.debug("Executed 2nd FOR LOOP.");
						}
					}
			} else {
				LOG.info("tempPartyXrefList is NULL." );
			}

			LOG.debug("finnaly adding in master response ");
			LOG.debug("XREF Copies for only Priority1: " + priorSRC1 + " are shown.");

			//Populating NULL tags in Response Canonical Format
			if (partyXrefList.size() != 0) {
				for(int indx = 0 ; indx < partyXrefList.size(); indx++)	{
					CanonicalFormManipulator.setDefaultValueInXrefAttributes(partyXrefList.get(indx));
				}
			}

			if (partyXrefList.size() != 0) {
				xrefCopy = new XREFCopy();
				xrefCopy.getPartyXref().addAll(partyXrefList);
				xrefCopyList.add(xrefCopy);
				LOG.debug(partyXrefList.size() + " XREFs successfully found!");
			}

			}	else {
				LOG.debug("No XREF record Found");
				//	xrefCopy.setStatus(Constant.noRecordFound);
				}

		} catch (Exception exp) {
			LOG.error(" Caught Exception in searchQueryResponse");
			exp.printStackTrace();
			ServiceProcessingException customException = new ServiceProcessingException(exp);
			customException.setMessage("Failed to process search request.");
			throw customException;
		}
*/
		LOG.info("Executed processXrefSearchRequest()");
		return partyXrefMap;

	}

	//Fetch XREF Copy of Records from PKG_XREF_FOR_SEARCH.
	public Map<String, List<PartyXrefType>> getAllPartyXref(Set<String> rowidObjectSet,String srcSystem) throws ServiceProcessingException {
		LOG.info("Executing getAllPartyXref()");

		Map<String, List<PartyXrefType>> partyXrefMap = null;
		Statement statement = null;
		PreparedStatement pstmt = null;
		StringBuilder sqlQry = new StringBuilder();
		JDBCConnectionProvider jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();;
		Connection jdbcConnection = null;
		ResultSet resultSet = null;


		try {
			LOG.info("Fetching XREF copies for rowidObjectSet: " + rowidObjectSet);
			LOG.info("value of Herarchyfuzzysearch : " + getHierarchyFuzzySearch());
			if(getHierarchyFuzzySearch()){
				sqlQry.append("SELECT * FROM PKG_XREF_FOR_HIERARCHY_SEARCH WHERE PARTY_ROWID_OBJECT in (");
				
			} else {
				sqlQry.append("SELECT * FROM PKG_XREF_FOR_SEARCH WHERE PARTY_ROWID_OBJECT in (");
			}			
			LOG.info(" sql query for XREF :: " + sqlQry);
			for (String partyRowId : rowidObjectSet) {
				sqlQry.append("'" + partyRowId + "',");
			}
			sqlQry.deleteCharAt(sqlQry.length() - 1).toString();
			sqlQry.append(") AND HUB_STATE_IND <> '" + -1 + "'");
			sqlQry.append(" AND STATUS_CD = '" + "A" + "'");
			sqlQry.append(" AND BO_CLASS_CODE = '" + "Organization" + "'");
			if(getHierarchyFuzzySearch()){
				sqlQry.append(" AND PARTY_TYPE in ('" + "Customer'," + "'Partner'," + "'Reseller',"  + "'Prospect Customer'," + "'Distributor" + "')");				
			} else {
				sqlQry.append(" AND PARTY_TYPE in ('" + "Customer'," + "'Partner'," + "'Reseller'," + "'Distributor" + "')");
			}
			//sqlQry.append(" AND PARTY_TYPE in ('" + "Customer'," + "'Partner'," + "'Reseller'," + "'Distributor" + "')");
			/** changes for Sales Force Integration -Start */
			//if (!Util.isNullOrEmpty(srcSystem) && (srcSystem.equalsIgnoreCase("SFC"))) {
			if (!Util.isNullOrEmpty(srcSystem)) {
				sqlQry.append(" AND PARTY_ROWID_SYSTEM = '" + srcSystem + "'");
			}
			/** changes for Sales Force Integration -End */
			/** Modified for SFDC START */
			sqlQry.append(" AND NVL(DRAFT_FLG,'N')<>'" + "Y" + "'");
			/*Modified for MDMP-3093: Fuzzy Search look up issue:: START*/
			sqlQry.append("AND nvl(trunc(END_DATE),'31-DEC-9999') = '31-DEC-9999'");
			sqlQry.append(" AND NVL(ADDR_HUB_STATE_IND,1)  = 1");
			
			//as per review comments - ODOM-2445
			/*sqlQry.append(" AND NVL(COMM_HUB_STATE_IND,1)  = 1");
			sqlQry.append(" AND NVL(ORG_EXTN_HUB_STATE_IND,1)  = 1");
			sqlQry.append(" AND NVL(CLASSIFCTN_HUB_STATE_IND,1)  = 1");*/
			
			//sqlQry.append(" AND NVL(REL_HUB_STATE_IND,1)  = 1");
			/*Modified for MDMP-3093: Fuzzy Search look up issue:: END*/
			/** Modified for SFDC END */
	//		sqlQry.append("SELECT * FROM PKG_XREF_FOR_SEARCH WHERE HUB_STATE_IND <> '" + -1 + "' AND STATUS_CD = 'A' AND BO_CLASS_CODE = 'Organization'");
	//		sqlQry.append(" AND PARTY_TYPE in ('" + "Customer'," + "'Partner'," + "'Reseller'," + "'Distributor" + "')");
			/** Modified for SFDC START */
	//		sqlQry.append(" AND NVL(DRAFT_FLG,'N')<>'" + "Y" + "'");
			/** Modified for SFDC END */
	//		sqlQry.append(" AND PARTY_ROWID_OBJECT = ?");

			LOG.debug("Query to fetch partyXrefMap:: " + sqlQry);


			jdbcConnection = jDBCConnectionProvider.getJdbcConnectionFromDS();
		//	jdbcConnection = JdbcConn.GetJdbcConnObject();
		//	pstmt = jdbcConnection.prepareStatement(sqlQry.toString());
		/*	
			for (String partyRowId : rowidObjectSet) {
				pstmt.setString(1, partyRowId);
				pstmt.addBatch();
			}
			
			resultSet = pstmt.executeQuery();
			partyXrefMap = createXrefCanonicalForm(resultSet);
		 */
		statement = jdbcConnection.createStatement();
		resultSet = statement.executeQuery(sqlQry.toString());
		if (resultSet != null) {
		partyXrefMap = createXrefCanonicalForm(resultSet);
		}
		
		} catch (SQLException sqlEx) {
			LOG.error("Exception occurred in getAllPartyXref while fetching Party profile: " + sqlEx);
			sqlEx.printStackTrace();
			ServiceProcessingException customException = new ServiceProcessingException(sqlEx);
			customException.setMessage("Failed to fetch Party profile from ORS." + customException.getMessage());
			throw customException;
		} finally {
				try {
					if( resultSet != null) resultSet.close();
					if( pstmt != null) pstmt.close();
					if( statement != null) statement.close();
					if(jdbcConnection != null) jdbcConnection.close();
				} catch (SQLException e) {

					e.printStackTrace();
				}
		}

		LOG.info("Executed getAllPartyXref()");
		hierarchyFuzzySearch = false;
		return partyXrefMap;
	}

	//Method to fetch XREF Canonical Format from ResultSet.
	public Map<String, List<PartyXrefType>> createXrefCanonicalForm(ResultSet resultSet) throws SQLException,ServiceProcessingException {
		LOG.info("Executing createXrefCanonicalForm()");
		PartyXrefType partyResponse = null;
		XREFType xref = null;
		CommunicationXrefType communication = null;
		AccountXrefType accInfo = null;
		AddressXrefType address = null;
		ClassificationXrefType classfction = null;
		PartyOrgExtXrefType partyOrgExt = null;
		PartyPersonExtXrefType partyPersonExt = null;
		//PartyRelationshipXrefType partyRelationship = null;
		
		/** Modified for M4M START */
		PartyAccountRelationshipXrefType partyAccountRelationship = null;
		/** Modified for M4M END */
		
//		XREFCopy xrefCopy = null;
//		List<XREFCopy> xrefCopyList = new ArrayList<XREFCopy>();

		List<PartyXrefType> tempPartyXrefList = null;
		List<PartyXrefType> partyXrefList = null;

		HashMap<String, List<PartyXrefType>> legacyIdMap = null;
		
		/** Modified for SFDC START */
		Map<String, Map<String, String>> legacyIdSfdcMap = null;
		Map<String, String> legacyIdOrigRowIdMap = null;
		/** Modified for SFDC END */
		
		List<PartyXrefType> legacyPartyXrefList = null;

//		ArrayList<XREFType> listXref = null;


		Map<String, SearchedXrefRecordCollection> searchedRecCollMap = new HashMap<String, SearchedXrefRecordCollection>();
		SearchedXrefRecordCollection searchedRecCollObj = null;
		boolean bUniqueRec = false;
		/** changes for Track-2 -Start */
		String hierarchyGRP = configProps.getProperty("HierGRP");
		Map<String, Map<String, SearchedXrefRecordCollection>> searchedRecCollMapAllParties = new HashMap<String, Map<String, SearchedXrefRecordCollection>>();
		Map<String, List<PartyXrefType>> partyXrefListMap = new HashMap<String, List<PartyXrefType>>();
		List<PartyXrefType> finalPartyXrefList = null;

	try{
		while (resultSet.next()) {
			String partyRowId = resultSet.getString("PARTY_ROWID_OBJECT");
			String partyOrigRowId = resultSet.getString("ORIG_ROWID_OBJECT");
			String partyType = resultSet.getString("PARTY_TYPE");
			String isGlobalParent = "N";
			String hierarchyCd = null;
			String rowidRelationship = null;
			/*if (!searchedRecCollMap.containsKey(partyOrigRowId)) {

				LOG.debug("Populate searchedXrefRecCollMap for new PARTY_ROWID " + partyOrigRowId);
				searchedRecCollMap.put(partyOrigRowId, new SearchedXrefRecordCollection());
				bUniqueRec = true;
			}*/

			if (!searchedRecCollMapAllParties.containsKey(partyRowId)) {
				LOG.debug("Populate searchedRecCollMapAllParties for new PARTY_ROWID " + partyRowId);
				searchedRecCollMapAllParties.put(partyRowId, new HashMap<String, SearchedXrefRecordCollection>());
			}
			searchedRecCollMap = searchedRecCollMapAllParties.get(partyRowId);

			if (!searchedRecCollMap.containsKey(partyOrigRowId)) {

				LOG.debug("Populate searchedXrefRecCollMap for new PARTY_ORIG_ROWID " + partyOrigRowId);
				searchedRecCollMap.put(partyOrigRowId, new SearchedXrefRecordCollection());
				bUniqueRec = true;
			}

			searchedRecCollObj = searchedRecCollMap.get(partyOrigRowId);

			if(bUniqueRec)	{

			//	LOG.debug("============setting Xref Copy");

			//	party = new PartyXrefType();
			//	party.setROWIDOBJECT(resultSet.getString("PARTY_ROWID_OBJECT"));
				searchedRecCollObj.setParty_rowid(resultSet.getString("PARTY_ROWID_OBJECT"));
				searchedRecCollObj.setOrig_rowid(resultSet.getString("ORIG_ROWID_OBJECT"));
			//	party.setBOCLASSCODE(resultSet.getString("BO_CLASS_CODE"));
				searchedRecCollObj.setBo_class(resultSet.getString("BO_CLASS_CODE"));
			//	party.setPARTYTYPE(resultSet.getString("PARTY_TYPE"));
				searchedRecCollObj.setParty_type(resultSet.getString("PARTY_TYPE"));
			//	party.setPARTYNAME(resultSet.getString("PARTY_NAME"));
				searchedRecCollObj.setParty_name(resultSet.getString("PARTY_NAME"));
			//	party.setGEO(resultSet.getString("PARTY_GEO"));
				searchedRecCollObj.setGeo(resultSet.getString("PARTY_GEO"));
			//	party.setREGION(resultSet.getString("PARTY_REGION"));
				searchedRecCollObj.setRegion(resultSet.getString("PARTY_REGION"));
			//	party.setSTATUSCD(resultSet.getString("STATUS_CD"));
				searchedRecCollObj.setStatus_cd(resultSet.getString("STATUS_CD"));
			//	party.setVATREGNBR(resultSet.getString("PARTY_VAT_REG_NBR"));
				searchedRecCollObj.setVat_regno(resultSet.getString("PARTY_VAT_REG_NBR"));
			//	party.setTAXJURSDCTNCD(resultSet.getString("PARTY_TAX_JURSDCTN_CD"));
				searchedRecCollObj.setTax_jd_cd(resultSet.getString("PARTY_TAX_JURSDCTN_CD"));
			//	party.setSALESBLOCKCD(resultSet.getString("SALES_BLOCK_CD"));
				searchedRecCollObj.setSales_cd(resultSet.getString("SALES_BLOCK_CD"));
			//	party.setUCN(resultSet.getString("UCN"));
				searchedRecCollObj.setUcn(resultSet.getString("UCN"));
				//Change for English Name :: Adding English name field to XRef
				searchedRecCollObj.setEnglish_name(resultSet.getString("ENGLISH_NAME"));

				sipPopFromXref = resultSet.getString("SIP_POP");

				LOG.debug("============setting XREFType");
				xref = new XREFType();
				xref.setSRCSYSTEM(resultSet.getString("PARTY_ROWID_SYSTEM").trim());
				if(Constant.SRC_SYSTEM_ADB.equalsIgnoreCase(resultSet.getString("PARTY_ROWID_SYSTEM").trim())){
					xref.setSRCPKEY(resultSet.getString("PARTY_PKEY_SRC_OBJECT").replaceAll(Constant.ADB_ACT_PREFIX, Constant.STR_BLANK));	
				}else{
					xref.setSRCPKEY(resultSet.getString("PARTY_PKEY_SRC_OBJECT"));
				}
				

				LOG.debug("===Inserting into XREFType List===");
	//			listXref = new ArrayList<XREFType>();
	//			listXref.add(xref);
	//			partyResponse.getXREF().addAll(listXref);
				searchedRecCollObj.getXrefMap().put(partyOrigRowId, xref);

			}

			if (resultSet.getString("ACCOUNT_ROWID_OBJECT") != null &&
					!searchedRecCollObj.getAccountMap().containsKey(resultSet.getString("ACCOUNT_ROWID_OBJECT"))) {
				LOG.debug("============setting Account info");
				accInfo = new AccountXrefType();
				accInfo.setROWIDACCOUNT(resultSet.getString("ACCOUNT_ROWID_OBJECT"));
				accInfo.setSRCSYSTEM(resultSet.getString("ACCOUNT_ROWID_SYSTEM").trim());
				if(Constant.SRC_SYSTEM_ADB.equalsIgnoreCase(resultSet.getString("ACCOUNT_ROWID_SYSTEM").trim())){
					accInfo.setSRCPKEY(resultSet.getString("ACCOUNT_PKEY_SRC_OBJECT").replaceAll(Constant.ADB_ACT_PREFIX, Constant.STR_BLANK));	
				}else{
					accInfo.setSRCPKEY(resultSet.getString("ACCOUNT_PKEY_SRC_OBJECT"));
				}
				accInfo.setACCTNAME(resultSet.getString("ACCT_NAME"));
				accInfo.setALIASNAME(resultSet.getString("ALIAS_NAME"));
				accInfo.setACCTSTATUS(resultSet.getString("ACCT_STATUS"));
				accInfo.setACCTTYPE(resultSet.getString("ACCT_TYPE"));
				accInfo.setACCOUNTREGION(resultSet.getString("ACCOUNT_REGION"));
				accInfo.setACCOUNTGEO(resultSet.getString("ACCOUNT_GEO"));
				accInfo.setMARKET(resultSet.getString("MARKET"));
				accInfo.setCUSTGROUP(resultSet.getString("CUST_GROUP"));
				accInfo.setPRICEGROUP(resultSet.getString("PRICE_GROUP"));
				accInfo.setCOMPANYCD(resultSet.getString("COMPANY_CD"));
				accInfo.setACCOUNTVATREGNBR(resultSet.getString("ACCOUNT_VAT_REG_NBR"));
				accInfo.setTAXTYPE(resultSet.getString("TAX_TYPE"));
				accInfo.setACCOUNTTAXJURSDCTNCD(resultSet.getString("ACCOUNT_TAX_JURDSCTN_CD"));
				accInfo.setBILLBLOCKCD(resultSet.getString("BILL_BLOCK_CD"));
				accInfo.setORDRBLOCKCD(resultSet.getString("ORDR_BLOCK_CD"));
				accInfo.setDLVRYBLOCKCD(resultSet.getString("DLVRY_BLOCK_CD"));
				accInfo.setPOSTBLOCKCD(resultSet.getString("POST_BLOCK_CD"));
				accInfo.setSALEBLOCKCD(resultSet.getString("SALE_BLOCK_CD"));
				accInfo.setCHANNELID(resultSet.getString("CHANNEL_ID"));
				accInfo.setPARTNERTYPE(resultSet.getString("PARTNER_TYPE"));
				accInfo.setVENDORNBR(resultSet.getString("VENDOR_NBR"));
				accInfo.setDIRECTIND(resultSet.getString("DIRECT_IND"));
				accInfo.setNAMEDACCTIND(resultSet.getString("NAMED_ACCT_IND"));
				accInfo.setNONVALACCTIND(resultSet.getString("NON_VAL_ACCT_IND"));
				accInfo.setPARTNERIND(resultSet.getString("PARTNER_IND"));
				accInfo.setSIEBELROWID(resultSet.getString("SIEBEL_ROWID"));
				accInfo.setSAPCUSTNUMBER(resultSet.getString("SAP_CUST_NUMBER"));
				accInfo.setMDMLEGACYID(resultSet.getString("MDM_LEGACY_ID"));
				
				/** Modified for SFDC START */
				accInfo.setSalesForceID(resultSet.getString("SFID"));
				accInfo.setDraftAccountFlag(resultSet.getString("DRAFT_FLG"));
				/** Modified for SFDC END */
				/** changes for Sales Force Integration -Start */
				accInfo.setLOCALNAME(resultSet.getString("LOCAL_NAME"));
				accInfo.setCURRENCYCD(resultSet.getString("ACCOUNT_CURRENCY_CD"));
				accInfo.setTAXID(resultSet.getString("TAX_ID"));
				accInfo.setPRICEBANDAGGREMENT(resultSet.getString("PRICING_BAND_AGRMNT"));
				/** changes for Sales Force Integration -End */
				/** changes for Track-2 -Start */
				accInfo.setSITEDESIGNATION(resultSet.getString("SITE_DESIGNATION"));
				/** changes for Track-2 -End */
				/** changes for Track-3 -Start */
				accInfo.setRESELLLEVEL(resultSet.getString("RESELL_LEVEL"));
				accInfo.setPARTNERSHIPSTATUS(resultSet.getString("PARTNERSHIP_STATUS"));
				/** changes for Track-3 -End */
				LOG.debug("===Inserting into Account Map===");
				searchedRecCollObj.getAccountMap().put(accInfo.getROWIDACCOUNT(), accInfo);
			}

			if (resultSet.getString("ADDRESS_ROWID_OBJECT") != null &&
					!searchedRecCollObj.getAddressMap().containsKey(resultSet.getString("ADDRESS_ROWID_OBJECT"))) {
				LOG.debug("============setting Address");

				address = new AddressXrefType();
				address.setROWIDADDRESS(resultSet.getString("ADDRESS_ROWID_OBJECT"));
				address.setSRCSYSTEM(resultSet.getString("ADDRESS_ROWID_SYSTEM").trim());
				if(Constant.SRC_SYSTEM_ADB.equalsIgnoreCase(resultSet.getString("ADDRESS_ROWID_SYSTEM").trim())){
					address.setSRCPKEY(resultSet.getString("ADDRESS_PKEY_SRC_OBJECT").replaceAll(Constant.ADB_ACT_PREFIX, Constant.STR_BLANK));	
				}else{
					address.setSRCPKEY(resultSet.getString("ADDRESS_PKEY_SRC_OBJECT"));
				}
				address.setADDRLN1(resultSet.getString("ADDR_LN1"));
				address.setADDRLN2(resultSet.getString("ADDR_LN2"));
				address.setADDRLN3(resultSet.getString("ADDR_LN3"));
				address.setADDRLN4(resultSet.getString("ADDR_LN4"));
				address.setCITY(resultSet.getString("CITY"));
				address.setCOUNTY(resultSet.getString("COUNTY"));
				address.setDISTRICT(resultSet.getString("DISTRICT"));
				address.setSTATECD(resultSet.getString("STATE_CD"));
				address.setPOSTALCD(resultSet.getString("POSTAL_CD"));
				address.setCOUNTRYCD(resultSet.getString("COUNTRY_CD"));
				address.setLANGCD(resultSet.getString("LANG_CD"));
				address.setLONGITUDE(resultSet.getString("LONGITUDE"));
				address.setLATITUDE(resultSet.getString("LATITUDE"));
				address.setADDRTYPE(resultSet.getString("ADDR_TYPE"));
				address.setADDRSTATUS(resultSet.getString("ADDR_STATUS"));

				LOG.debug("===Inserting into Address Map===");
				searchedRecCollObj.getAddressMap().put(address.getROWIDADDRESS(), address);
			}

			if (resultSet.getString("COMMUNICATION_ROWID_OBJECT") != null &&
					!searchedRecCollObj.getCommMap().containsKey(resultSet.getString("COMMUNICATION_ROWID_OBJECT"))) {
				if(resultSet.getString("COMM_HUB_STATE_IND")!=null && resultSet.getString("COMM_HUB_STATE_IND").equals("1")){
				communication = new CommunicationXrefType();
				LOG.debug("============adding Communication");

				communication.setROWIDCOMMUNICATION(resultSet.getString("COMMUNICATION_ROWID_OBJECT"));
				communication.setSRCSYSTEM(resultSet.getString("COMMUNICATION_ROWID_SYSTEM").trim());
				if(Constant.SRC_SYSTEM_ADB.equalsIgnoreCase(resultSet.getString("COMMUNICATION_ROWID_SYSTEM").trim())){
					communication.setSRCPKEY(resultSet.getString("COMMUNICATION_PKEY_SRC_OBJECT").replaceAll(Constant.ADB_ACT_PREFIX, Constant.STR_BLANK));	
				}else{
					communication.setSRCPKEY(resultSet.getString("COMMUNICATION_PKEY_SRC_OBJECT"));
				}
				communication.setCOMMTYPE(resultSet.getString("COMM_TYPE"));
				communication.setCOMMVALUE(resultSet.getString("COMM_VALUE"));
				communication.setCOMMSTATUS(resultSet.getString("COMM_STATUS"));
				communication.setPRFRDCOMMIND(resultSet.getString("PRFRD_COMM_IND"));
				communication.setWEBDOMAIN(resultSet.getString("WEB_DOMAIN"));
				/* changes for SFDC - Track2 -Start */
				communication.setCOMMEXTN(resultSet.getString("COMM_EXTN"));
				communication.setCOMMMKTGPREF(resultSet.getString("COMM_MKTG_PREF"));
				/* changes for SFDC - Track2 -End */
				LOG.debug("===Inserting into Communication Map===");
				searchedRecCollObj.getCommMap().put(communication.getROWIDCOMMUNICATION(), communication);
				}
			}

			if (resultSet.getString("PARTY_ORG_ROWID_OBJECT") != null &&
					!searchedRecCollObj.getPartyOrgMap().containsKey(resultSet.getString("PARTY_ORG_ROWID_OBJECT"))) {
				
				if(resultSet.getString("ORG_EXTN_HUB_STATE_IND")!=null && resultSet.getString("ORG_EXTN_HUB_STATE_IND").equals("1")){
				partyOrgExt = new PartyOrgExtXrefType();
				LOG.debug("============adding PartyOrgExt");

				partyOrgExt.setROWIDORGEXTN(resultSet.getString("PARTY_ORG_ROWID_OBJECT"));
	//			partyOrgExt.setSRCSYSTEM(resultSet.getString("PARTY_ORG_ROWID_SYSTEM"));
	//			partyOrgExt.setSRCPKEY(resultSet.getString("PARTY_ORG_PKEY_SRC_OBJECT"));
				partyOrgExt.setORGDUNSNBR(resultSet.getString("ORG_DUNS_NBR"));
				partyOrgExt.setTRADENAME(resultSet.getString("TRADE_NAME"));
				partyOrgExt.setTRADENAME2(resultSet.getString("TRADE_NAME_2"));
				partyOrgExt.setSITEEMPLCNT(resultSet.getString("SITE_EMPL_CNT"));
				partyOrgExt.setGLBLEMPLCNT(resultSet.getString("GLBL_EMPL_CNT"));
				partyOrgExt.setVERTICAL(resultSet.getString("VERTICAL"));
				partyOrgExt.setREVENUE(resultSet.getString("REVENUE"));
				partyOrgExt.setLINEOFBUS(resultSet.getString("LINE_OF_BUS"));
				partyOrgExt.setPRIMSIC(resultSet.getString("PRIM_SIC"));
				partyOrgExt.setSECSIC(resultSet.getString("SEC_SIC"));
				partyOrgExt.setSALESVOLUME(resultSet.getString("SALES_VOLUME"));
				partyOrgExt.setSALESAMOUNT(resultSet.getString("SALES_AMOUNT"));
				partyOrgExt.setCURRENCYCD(resultSet.getString("CURRENCY_CD"));
				partyOrgExt.setOUTOFBUSIND(resultSet.getString("OUT_OF_BUS_IND"));
				partyOrgExt.setGLBLULTIND(resultSet.getString("GLBL_ULT_IND"));
				partyOrgExt.setFORTUNEINFO(resultSet.getString("FORTUNE_INFO"));
				partyOrgExt.setHIERARCHYLEVEL(resultSet.getString("HIERARCHY_LEVEL"));
				partyOrgExt.setORGHQPARENTDUNS(resultSet.getString("ORG_HQ_PARENT_DUNS"));
				partyOrgExt.setORGDOMULTDUNS(resultSet.getString("ORG_DOM_ULT_DUNS"));
				partyOrgExt.setORGGLBULTDUNS(resultSet.getString("ORG_GLB_ULT_DUNS"));
				/** changes for Track-2 -Start */
				partyOrgExt.setSALESREVNUOVRID(resultSet.getString("SALES_REVNU_OVRID"));
				partyOrgExt.setMFECOUNTRYULTUCN(resultSet.getString("MFE_COUNTRY_ULT_UCN"));
				partyOrgExt.setMFEGLBLPARENTUCN(resultSet.getString("MFE_GLBL_PARENT_UCN"));
				partyOrgExt.setMFEGLOBALPARNMOVRIDE(resultSet.getString("MFE_GLOBAL_PAR_NM_OVRIDE"));
				partyOrgExt.setMFENEXTLVLSUBSPARNM(resultSet.getString("MFE_NEXT_LVL_SUBS_PAR_NM"));
				partyOrgExt.setMFENEXTLVLSUBSPARUCN(resultSet.getString("MFE_NEXT_LVL_SUBS_PAR_UCN"));
				partyOrgExt.setMFESUBSDRYPARENTNM(resultSet.getString("MFE_SUBS_PARENT_NM"));
				partyOrgExt.setMFESUBSDRYPARENTPRTNNM(resultSet.getString("MFE_SUBSDRY_PARENT_PRTN_NM"));
				partyOrgExt.setMFESUBSPARENTNMOVRIDE(resultSet.getString("MFE_SUBS_PARENT_NM_OVRIDE"));
				partyOrgExt.setMFESUBSPARENTUCN(resultSet.getString("MFE_SUBS_PARENT_UCN"));
				partyOrgExt.setMFETXN5YRFLG(resultSet.getString("MFE_TXN_5_YR_FLG"));
				partyOrgExt.setMFETXN7YRFLG(resultSet.getString("MFE_TXN_7_YR_FLG"));
				partyOrgExt.setMFEWWPARENTNM(resultSet.getString("MFE_WW_PARENT_NM"));
				partyOrgExt.setMFEWWPARENTPRTNNM(resultSet.getString("MFE_WW_PARENT_PRTN_NM"));
				partyOrgExt.setTXN5YRFLG(resultSet.getString("TXN_5_YR_FLG"));
				partyOrgExt.setTXN7YRFLG(resultSet.getString("TXN_7_YR_FLG"));
				partyOrgExt.setGLBEMPCNTOVERRIDE(resultSet.getString("GLB_EMP_CNT_OVERRIDE"));
				partyOrgExt.setACTIVETXNFLG(resultSet.getString("ACTIVE_TXN_FLAG"));
				partyOrgExt.setPARENTFLG(resultSet.getString("PARENT_FLAG"));
				partyOrgExt.setPARTNERFLG(resultSet.getString("PARTNER_FLAG"));
				partyOrgExt.setCUSTFLG(resultSet.getString("CUST_FLAG"));
				partyOrgExt.setGLBFLG(resultSet.getString("GLB_FLG"));
				partyOrgExt.setCOUNTRYULTIND(resultSet.getString("COUNTRY_ULT_IND"));	
				//partyOrgExt.setCUSTOMPARENTUCN(resultSet.getString("CUSTOM_PARENT_UCN"));
				//partyOrgExt.setCUSTOMPARENTNAME(resultSet.getString("CUSTOM_PARENT_NAME"));
				partyOrgExt.setSUBSIDIARYIND(resultSet.getString("SUBSIDIARY_IND"));
				partyOrgExt.setMDMPARENTUCN(resultSet.getString("MDM_PARENT_UCN"));
			    //partyOrgExt.setCUSTOMERPARENTFLAG(resultSet.getString("CUSTOMER_PARENT_FLAG"));
				partyOrgExt.setG2KFLG(resultSet.getString("G2K_FLG"));
				partyOrgExt.setGLBSALESREVNUOVRID(resultSet.getString("GLB_SALES_REVNU_OVRID"));
				/** changes for Track-2 -End */
				/** changes for Track-3 -Start */
				partyOrgExt.setPTRPARENTUCN(resultSet.getString("PTR_PARENT_UCN"));
				partyOrgExt.setPTRPARENTNM(resultSet.getString("PTR_PARENT_NM"));
				partyOrgExt.setPTRGLBLPARENTUCN(resultSet.getString("PTR_GLBL_PARENT_UCN"));
				/** changes for Track-3 -End */
				LOG.debug("===Inserting into PartyOrgExtType Map==");
				searchedRecCollObj.getPartyOrgMap().put(partyOrgExt.getROWIDORGEXTN(), partyOrgExt);
				}
			}


		/*	if (resultSet.getString("PARTY_PERSON_ROWID_OBJECT") != null &&
					!searchedRecCollObj.getPartyPersonMap().containsKey(resultSet.getString("PARTY_PERSON_ROWID_OBJECT"))) {

				partyPersonExt = new PartyPersonExtXrefType();
				LOG.debug("============adding PartyPersonExt");

				partyPersonExt.setROWIDPRSNEXTN(resultSet.getString("PARTY_PERSON_ROWID_OBJECT"));
				partyPersonExt.setSRCSYSTEM(resultSet.getString("PARTY_PERSON_ROWID_SYSTEM"));
				partyPersonExt.setSRCPKEY(resultSet.getString("PARTY_PERSON_PKEY_SRC_OBJECT"));
				partyPersonExt.setPREFIX(resultSet.getString("PREFIX"));
				partyPersonExt.setFIRSTNAME(resultSet.getString("FIRST_NAME"));
				partyPersonExt.setMIDDLENAME(resultSet.getString("MIDDLE_NAME"));
				partyPersonExt.setLASTNAME(resultSet.getString("LAST_NAME"));
				partyPersonExt.setSUFFIX(resultSet.getString("SUFFIX"));
				partyPersonExt.setPERSONTYPE(resultSet.getString("PERSON_TYPE"));

				LOG.debug("===Inserting into PartyPersonExtType List===");
				searchedRecCollObj.getPartyPersonMap().put(partyPersonExt.getROWIDPRSNEXTN(), partyPersonExt);
			}	*/

			if (resultSet.getString("PARTY_CLASS_ROWID_OBJECT") != null &&
					!searchedRecCollObj.getClassMap().containsKey(resultSet.getString("PARTY_CLASS_ROWID_OBJECT"))) {
				if(resultSet.getString("CLASSIFCTN_HUB_STATE_IND")!=null && resultSet.getString("CLASSIFCTN_HUB_STATE_IND").equals("1")){
				classfction = new ClassificationXrefType();
				LOG.debug("============adding Classification");

				classfction.setROWIDCLASSIFICTN(resultSet.getString("PARTY_CLASS_ROWID_OBJECT"));
				classfction.setSRCSYSTEM(resultSet.getString("PARTY_CLASS_ROWID_SYSTEM").trim());
				if(Constant.SRC_SYSTEM_ADB.equalsIgnoreCase(resultSet.getString("PARTY_CLASS_ROWID_SYSTEM").trim())){
					classfction.setSRCPKEY(resultSet.getString("PARTY_CLASS_PKEY_SRC_OBJECT").replaceAll(Constant.ADB_ACT_PREFIX, Constant.STR_BLANK));	
				}else{
					classfction.setSRCPKEY(resultSet.getString("PARTY_CLASS_PKEY_SRC_OBJECT"));
				}
				classfction.setCLASSIFICTNTYPE(resultSet.getString("CLASSIFCTN_TYPE"));
				classfction.setCLASSIFICTNVALUE(resultSet.getString("CLASSIFCTN_VALUE"));
				classfction.setSTARTDATE(resultSet.getString("START_DATE"));
				classfction.setENDDATE(resultSet.getString("END_DATE"));
				/* changes for SFDC - Track2 -Start */
				classfction.setCLASSIFICTNMETH(resultSet.getString("CLASSIFCTN_METH"));
				/* changes for SFDC - Track2 -End */
				LOG.debug("===Inserting into Classification Map===");
				searchedRecCollObj.getClassMap().put(classfction.getROWIDCLASSIFICTN(), classfction);
				}
			}
			/** changes for Track-2 -Start */
			if(bUniqueRec)	{
			Map<String,String> ucnMap = getMdmHierarchyView(partyRowId);
			Map<String,String> partnerResellerUCNMap = null;
			if("Reseller".equalsIgnoreCase(partyType) || "Distributor".equalsIgnoreCase(partyType)){
				partnerResellerUCNMap = getPartnerRellserHierarchyView(partyRowId,partyType);
			}else{
				partnerResellerUCNMap = new HashMap<String,String>();
				partnerResellerUCNMap.put("MDM_PRTNR_ORG_UCN","");
				partnerResellerUCNMap.put("PRTNR_ORG_NM","");
			}
			String wwParentUcn = ucnMap.get("PTR_GLBL_PARENT_UCN");
			LOG.debug("WW Parent UCN "+wwParentUcn);
			isGlobalParent = ucnMap.get("GLB_FLG");
			String globalParentName = ucnMap.get("MFE_GLOBAL_PAR_NM_OVRIDE");
			if (resultSet.getString("PARTY_REL_ROWID_OBJECT") != null){
			 if(!searchedRecCollObj.getPartyRelMap().containsKey(resultSet.getString("PARTY_REL_ROWID_OBJECT"))) {

				partyAccountRelationship = new PartyAccountRelationshipXrefType();
				
				LOG.debug("============adding PartyRelationship");

				partyAccountRelationship.setRELTYPE(resultSet.getString("REL_TYPE_CODE"));
				 hierarchyCd = resultSet.getString("HIERARCHY_CODE");
				partyAccountRelationship.setHIERARCHYTYPE(resultSet.getString("HIERARCHY_CODE"));
				partyAccountRelationship.setSINGLESITEFLAG(Constant.STR_N);
				
				if(Constant.McAfee_Hierarchy.equalsIgnoreCase(hierarchyCd)){
					
					partyAccountRelationship.setMDMPARENTUCN(ucnMap.get("MDM_PARENT_UCN"));
					partyAccountRelationship.setMDMPARENTNAME(ucnMap.get("MFE_PARENT_NM"));
					partyAccountRelationship.setMDMGLBPARENTUCN(ucnMap.get("MFE_GLBL_PARENT_UCN"));
					if(Util.isNullOrEmpty(globalParentName))	{
						partyAccountRelationship.setMDMGLBPARENTNAME(ucnMap.get("MFE_GLBL_PARENT_NM"));
						}
						else{
							partyAccountRelationship.setMDMGLBPARENTNAME(ucnMap.get("MFE_GLOBAL_PAR_NM_OVRIDE"));
						}
					
				}else if(Constant.Partner_Hierarchy.equalsIgnoreCase(hierarchyCd)){
				
					/*partyAccountRelationship.setMDMPARENTUCN(ucnMap.get("MDM_PARENT_UCN"));
					partyAccountRelationship.setMDMPARENTNAME(ucnMap.get("MFE_SUBSDRY_PARENT_PRTN_NM"));
					partyAccountRelationship.setMDMGLBPARENTUCN(ucnMap.get("MFE_GLBL_PARENT_UCN"));*/
					if("Reseller".equalsIgnoreCase(partyType) || "Distributor".equalsIgnoreCase(partyType)){
						partyAccountRelationship.setMDMPARENTUCN(partnerResellerUCNMap.get("MDM_PRTNR_ORG_UCN"));
						partyAccountRelationship.setMDMPARENTNAME(partnerResellerUCNMap.get("PRTNR_ORG_NM"));
					}else {
						partyAccountRelationship.setMDMPARENTUCN(ucnMap.get("PTR_PARENT_UCN"));
						partyAccountRelationship.setMDMPARENTNAME(ucnMap.get("PTR_PARENT_NM"));
					}
					partyAccountRelationship.setMDMGLBPARENTUCN(ucnMap.get("PTR_GLBL_PARENT_UCN"));
					partyAccountRelationship.setMDMGLBPARENTNAME(ucnMap.get("MFE_WW_PARENT_PRTN_NM"));
				}
				if (hierarchyGRP.contains(partyAccountRelationship.getHIERARCHYTYPE())){
				LOG.debug("===Inserting into Child Relationship Map===");
				searchedRecCollObj.getPartyRelMap().put(resultSet.getString("PARTY_REL_ROWID_OBJECT"), partyAccountRelationship);
				}
			}
			 if (!Util.isNullOrEmpty(wwParentUcn)) {
				  partyAccountRelationship = new PartyAccountRelationshipXrefType();
					/*partyAccountRelationship.setMDMPARENTUCN(ucnMap.get("MDM_PARENT_UCN"));
					partyAccountRelationship.setMDMPARENTNAME(ucnMap.get("MFE_SUBSDRY_PARENT_PRTN_NM"));
					partyAccountRelationship.setMDMGLBPARENTUCN(ucnMap.get("MFE_GLBL_PARENT_UCN"));*/
				  if("Reseller".equalsIgnoreCase(partyType) || "Distributor".equalsIgnoreCase(partyType)){
						partyAccountRelationship.setMDMPARENTUCN(partnerResellerUCNMap.get("MDM_PRTNR_ORG_UCN"));
						partyAccountRelationship.setMDMPARENTNAME(partnerResellerUCNMap.get("PRTNR_ORG_NM"));
					}else {
						partyAccountRelationship.setMDMPARENTUCN(ucnMap.get("PTR_PARENT_UCN"));
						partyAccountRelationship.setMDMPARENTNAME(ucnMap.get("PTR_PARENT_NM"));
					}
				  	partyAccountRelationship.setMDMPARENTUCN(ucnMap.get("PTR_PARENT_UCN"));
					partyAccountRelationship.setMDMPARENTNAME(ucnMap.get("PTR_PARENT_NM"));
					partyAccountRelationship.setMDMGLBPARENTUCN(ucnMap.get("PTR_GLBL_PARENT_UCN"));
					partyAccountRelationship.setMDMGLBPARENTNAME(ucnMap.get("MFE_WW_PARENT_PRTN_NM"));
					partyAccountRelationship.setHIERARCHYTYPE(Constant.Partner_Hierarchy);
					//if (partyAccountRelationship.getHIERARCHYTYPE() != null && hierarchyGRP.contains(partyAccountRelationship.getHIERARCHYTYPE())){
						LOG.debug("===Inserting into Child Relationship Map===");
						searchedRecCollObj.getPartyRelMap().put(rowidRelationship, partyAccountRelationship);
						//}
				}
				
			}else if ((!Util.isNullOrEmpty(isGlobalParent)) && isGlobalParent.equalsIgnoreCase("Y")) {
				List<GlobalHierarchyNode> globalHierarchyNodeList = getGlobalHierarchy(partyRowId);
				
				for(GlobalHierarchyNode globalHierarchyNode : globalHierarchyNodeList) {
					partyAccountRelationship = new PartyAccountRelationshipXrefType();
					if (globalHierarchyNode.getPartyRelRowid() != null && !searchedRecCollObj.getPartyRelMap()
							.containsKey(globalHierarchyNode.getPartyRelRowid())) {
						LOG.debug("===Inserting into Relationship Map for GLOBAL Parent===" + globalHierarchyNode.getPartyRelRowid());
						partyAccountRelationship.setSINGLESITEFLAG(Constant.STR_N);
						rowidRelationship = globalHierarchyNode.getPartyRelRowid();
						partyAccountRelationship.setRELTYPE(globalHierarchyNode.getRelTypeCode());
						 hierarchyCd = globalHierarchyNode.getHierarchyCode();
						partyAccountRelationship.setHIERARCHYTYPE(hierarchyCd);
						if(hierarchyCd != null){
						if (Constant.McAfee_Hierarchy.equalsIgnoreCase(hierarchyCd)) {

							partyAccountRelationship.setMDMPARENTUCN(ucnMap.get("MDM_PARENT_UCN"));
							partyAccountRelationship.setMDMPARENTNAME(ucnMap.get("MFE_PARENT_NM"));
							partyAccountRelationship.setMDMGLBPARENTUCN(ucnMap.get("MFE_GLBL_PARENT_UCN"));
							if(Util.isNullOrEmpty(globalParentName))	{
								partyAccountRelationship.setMDMGLBPARENTNAME(ucnMap.get("MFE_GLBL_PARENT_NM"));
								}
								else{
									partyAccountRelationship.setMDMGLBPARENTNAME(ucnMap.get("MFE_GLOBAL_PAR_NM_OVRIDE"));
								}
							
						} else if (Constant.Partner_Hierarchy.equalsIgnoreCase(hierarchyCd)) {

							if("Reseller".equalsIgnoreCase(partyType) || "Distributor".equalsIgnoreCase(partyType)){
								partyAccountRelationship.setMDMPARENTUCN(partnerResellerUCNMap.get("MDM_PRTNR_ORG_UCN"));
								partyAccountRelationship.setMDMPARENTNAME(partnerResellerUCNMap.get("PRTNR_ORG_NM"));
							}else {
								partyAccountRelationship.setMDMPARENTUCN(ucnMap.get("PTR_PARENT_UCN"));
								partyAccountRelationship.setMDMPARENTNAME(ucnMap.get("PTR_PARENT_NM"));
							}
							partyAccountRelationship.setMDMGLBPARENTUCN(ucnMap.get("PTR_GLBL_PARENT_UCN"));
							partyAccountRelationship.setMDMGLBPARENTNAME(ucnMap.get("MFE_WW_PARENT_PRTN_NM"));
						}
						if (hierarchyGRP.contains(partyAccountRelationship.getHIERARCHYTYPE())){
							LOG.debug("===Inserting into Parent Relationship Map===");
							searchedRecCollObj.getPartyRelMap().put(rowidRelationship, partyAccountRelationship);
							}
						}
						if (!Util.isNullOrEmpty(wwParentUcn)) {
							PartyAccountRelationshipXrefType partyAccountPtnrRelationship = new PartyAccountRelationshipXrefType();
							if("Reseller".equalsIgnoreCase(partyType) || "Distributor".equalsIgnoreCase(partyType)){
								partyAccountRelationship.setMDMPARENTUCN(partnerResellerUCNMap.get("MDM_PRTNR_ORG_UCN"));
								partyAccountRelationship.setMDMPARENTNAME(partnerResellerUCNMap.get("PRTNR_ORG_NM"));
							}else {
								partyAccountRelationship.setMDMPARENTUCN(ucnMap.get("PTR_PARENT_UCN"));
								partyAccountRelationship.setMDMPARENTNAME(ucnMap.get("PTR_PARENT_NM"));
							}
							partyAccountRelationship.setMDMGLBPARENTUCN(ucnMap.get("PTR_GLBL_PARENT_UCN"));
							partyAccountRelationship.setMDMGLBPARENTNAME(ucnMap.get("MFE_WW_PARENT_PRTN_NM"));
							partyAccountRelationship.setHIERARCHYTYPE(Constant.Partner_Hierarchy);
							LOG.debug("============adding Partner Reseller partyAccountPtnrRelationship "+partyAccountPtnrRelationship.getHIERARCHYTYPE()+rowidRelationship);
							searchedRecCollObj.getPartyRelMap().put(partyAccountPtnrRelationship.getHIERARCHYTYPE()+rowidRelationship, partyAccountPtnrRelationship);
						}
					}
				}
				
			}
			else{
				LOG.debug("============adding dummy partyAccountRelationship ");
				 rowidRelationship = "0";  // As there is no party relation so rel rowid is set as 0
				
				partyAccountRelationship = new PartyAccountRelationshipXrefType();
				if (!Util.isNullOrEmpty(wwParentUcn)) {
					 
						/*partyAccountRelationship.setMDMPARENTUCN(ucnMap.get("MDM_PARENT_UCN"));
						partyAccountRelationship.setMDMPARENTNAME(ucnMap.get("MFE_SUBSDRY_PARENT_PRTN_NM"));
						partyAccountRelationship.setMDMGLBPARENTUCN(ucnMap.get("MFE_GLBL_PARENT_UCN"));*/
					if("Reseller".equalsIgnoreCase(partyType) || "Distributor".equalsIgnoreCase(partyType)){
							partyAccountRelationship.setMDMPARENTUCN(partnerResellerUCNMap.get("MDM_PRTNR_ORG_UCN"));
							partyAccountRelationship.setMDMPARENTNAME(partnerResellerUCNMap.get("PRTNR_ORG_NM"));
						}else {
							partyAccountRelationship.setMDMPARENTUCN(ucnMap.get("PTR_PARENT_UCN"));
							partyAccountRelationship.setMDMPARENTNAME(ucnMap.get("PTR_PARENT_NM"));
						}
						partyAccountRelationship.setMDMGLBPARENTUCN(ucnMap.get("PTR_GLBL_PARENT_UCN"));
						partyAccountRelationship.setMDMGLBPARENTNAME(ucnMap.get("MFE_WW_PARENT_PRTN_NM"));
						partyAccountRelationship.setHIERARCHYTYPE(Constant.Partner_Hierarchy);
					}
					if (partyAccountRelationship.getHIERARCHYTYPE() != null && hierarchyGRP.contains(partyAccountRelationship.getHIERARCHYTYPE())){
					LOG.debug("===Inserting into Child Relationship Map===");
					searchedRecCollObj.getPartyRelMap().put(rowidRelationship, partyAccountRelationship);
				}
					else if(!"Y".equalsIgnoreCase(isGlobalParent)){
					partyAccountRelationship.setMDMPARENTUCN(searchedRecCollObj.getUcn());
					partyAccountRelationship.setMDMPARENTNAME(searchedRecCollObj.getParty_name());
					partyAccountRelationship.setMDMGLBPARENTUCN(searchedRecCollObj.getUcn());
					partyAccountRelationship.setMDMGLBPARENTNAME(searchedRecCollObj.getParty_name());
					partyAccountRelationship.setHIERARCHYTYPE(Constant.McAfee_Hierarchy);
					partyAccountRelationship.setSINGLESITEFLAG(Constant.STR_Y);
				}
				if (partyAccountRelationship.getHIERARCHYTYPE() != null && hierarchyGRP.contains(partyAccountRelationship.getHIERARCHYTYPE())){
				LOG.debug("===Inserting into SingleSite Relationship Map===");
				searchedRecCollObj.getPartyRelMap().put(rowidRelationship, partyAccountRelationship);
				}
			}
			}
			/** changes for Track-2 -End */
			bUniqueRec = false;
		}
	//	Collection<Map<String, SearchedXrefRecordCollection>> tempColl  = searchedRecCollMapAllParties.values();

	//	for (Entry<String, SearchedXrefRecordCollection> mapEntry : ((Map<String, SearchedXrefRecordCollection>) searchedRecCollMapAllParties.values()).entrySet()) {
		for (Entry<String, Map<String, SearchedXrefRecordCollection>> mapEntry : searchedRecCollMapAllParties.entrySet()) {

			tempPartyXrefList = new ArrayList<PartyXrefType>();
			for(Entry<String, SearchedXrefRecordCollection> entry : mapEntry.getValue().entrySet()) {

				LOG.debug("====Populating PartyXREFType");

				partyResponse = new PartyXrefType();
				partyResponse.setROWIDOBJECT(entry.getValue().getParty_rowid());
				partyResponse.setORIGROWIDOBJECT(entry.getValue().getOrig_rowid());
				partyResponse.setBOCLASSCODE(entry.getValue().getBo_class());
				partyResponse.setPARTYTYPE(entry.getValue().getParty_type());
				partyResponse.setPARTYNAME(entry.getValue().getParty_name());
				partyResponse.setGEO(entry.getValue().getGeo());
				partyResponse.setREGION(entry.getValue().getRegion());
				partyResponse.setSALESBLOCKCD(entry.getValue().getSales_cd());
				partyResponse.setSTATUSCD(entry.getValue().getStatus_cd());
				partyResponse.setTAXJURSDCTNCD(entry.getValue().getTax_jd_cd());
				partyResponse.setUCN(entry.getValue().getUcn());
				partyResponse.setVATREGNBR(entry.getValue().getVat_regno());
				//Change for English Name :: Adding English name field to response
				partyResponse.setENGLISHNAME(entry.getValue().getEnglish_name());

				LOG.debug("==Populating partyXREF's XREFType==");
				partyResponse.getXREF().addAll(entry.getValue().getXrefMap().values());

				partyResponse.getAccount().addAll(entry.getValue().getAccountMap().values());
				partyResponse.getAddress().addAll(entry.getValue().getAddressMap().values());
				partyResponse.getCommunication().addAll(entry.getValue().getCommMap().values());
				partyResponse.getPartyOrgExt().addAll(entry.getValue().getPartyOrgMap().values());
				partyResponse.getPartyPersonExt().addAll(entry.getValue().getPartyPersonMap().values());
				partyResponse.getClassification().addAll(entry.getValue().getClassMap().values());
				
				/** Modified for M4M START */
				PartyRelationshipXrefType partyRel = partyResponse.getPartyRel();
				if(partyRel == null) {
					partyRel = new PartyRelationshipXrefType();
				}
				partyRel.getPARTYACCOUNTREL().addAll(entry.getValue().getPartyRelMap().values());
				partyResponse.setPartyRel(partyRel);
				/** Modified for M4M END */

				LOG.debug("====Populating TempList");
				tempPartyXrefList.add(partyResponse);

		//		partyXrefList.add(partyResponse);
			}
		LOG.info("partyXrefListMap key: " + mapEntry.getKey() + "|tempPartyXrefList size: " + tempPartyXrefList.size());
		partyXrefListMap.put(mapEntry.getKey(), tempPartyXrefList);
	//	tempPartyXrefList.clear();
	}

/*		for(Entry<String, List<PartyXrefType>> mapentry : partyXrefListMap.entrySet()) {
			LOG.debug("mapentry key: " + mapentry.getKey() );
			for(PartyXrefType pXref : mapentry.getValue())	{
				LOG.debug("mapentry value OrigID: " + pXref.getORIGROWIDOBJECT() + "|SrcSystem: " + pXref.getXREF().get(0).getSRCSYSTEM() + ".");
			//	LOG.debug("mapentry value SrcSystem: " + pXref.getXREF().get(0).getSRCSYSTEM() );
			}
		}	*/

		for(Entry<String, List<PartyXrefType>> mapentry : partyXrefListMap.entrySet()) {
			partyXrefList = new ArrayList<PartyXrefType>();
			List<PartyXrefType> tempXrefList = mapentry.getValue();
			legacyIdMap = new HashMap<String, List<PartyXrefType>>();
			
			/** Modified for SFDC START */
			legacyIdSfdcMap = new HashMap<String, Map<String,String>>();
			legacyIdOrigRowIdMap = new HashMap<String, String>();
			/** Modified for SFDC END */
			

			if(tempXrefList != null && tempXrefList.size() > 0)	{
				//Fetching Distinct LegacyID XREF Copy
				for(int indx = 0 ; indx < tempXrefList.size() ; indx ++)	{
				LOG.debug("Executing" + indx +"st FOR LOOP.");
				if(tempXrefList.get(indx).getAccount()!= null && tempXrefList.get(indx).getAccount().size() > 0){				
				String mdmLegacyId = tempXrefList.get(indx).getAccount().get(0).getMDMLEGACYID();

				if (mdmLegacyId != null)	{

					LOG.info("mdmLegacyId: " + mdmLegacyId);

					if(legacyIdMap.containsKey(mdmLegacyId)) {

						LOG.info("legacyIdMap contains mdmLegacyId: ");
						legacyPartyXrefList = legacyIdMap.get(mdmLegacyId);
						legacyPartyXrefList.add(tempXrefList.get(indx));
						
						/** Modified for SFDC START */
						if("SAP".equalsIgnoreCase(priorSRC1) && tempXrefList.get(indx).getXREF().get(0).getSRCSYSTEM().trim().equalsIgnoreCase("SBL")) {
							LOG.info("Inside legacyId-SDFC IF Orig RowID: " + tempXrefList.get(indx).getORIGROWIDOBJECT());
							legacyIdOrigRowIdMap.put(mdmLegacyId, tempXrefList.get(indx).getORIGROWIDOBJECT());
							Map<String, String> sfdcMap = new HashMap<String, String>();
							sfdcMap.put("SFID", tempXrefList.get(indx).getAccount().get(0).getSalesForceID());
							sfdcMap.put("DraftFlg", tempXrefList.get(indx).getAccount().get(0).getDraftAccountFlag());
							legacyIdSfdcMap.put(mdmLegacyId, sfdcMap);
						}
						/** Modified for SFDC END */

						
					} else {

						LOG.info("legacyIdMap does not contains mdmLegacyId: ");
						legacyPartyXrefList = new ArrayList<PartyXrefType>();
						legacyPartyXrefList.add(tempXrefList.get(indx));
						
						if("SAP".equalsIgnoreCase(priorSRC1) && tempXrefList.get(indx).getXREF().get(0).getSRCSYSTEM().trim().equalsIgnoreCase("SBL")) {
							LOG.info("Inside legacyId-SDFC IF Orig RowID: " + tempXrefList.get(indx).getORIGROWIDOBJECT());
							if(Util.isNullOrEmpty(legacyIdOrigRowIdMap.get(mdmLegacyId))) {
								legacyIdOrigRowIdMap.put(mdmLegacyId, tempXrefList.get(indx).getORIGROWIDOBJECT());
								Map<String, String> sfdcMap = new HashMap<String, String>();
								sfdcMap.put("SFID", tempXrefList.get(indx).getAccount().get(0).getSalesForceID());
								sfdcMap.put("DraftFlg", tempXrefList.get(indx).getAccount().get(0).getDraftAccountFlag());
								legacyIdSfdcMap.put(mdmLegacyId, sfdcMap);
							} else if(!Util.isNullOrEmpty(tempXrefList.get(indx).getORIGROWIDOBJECT())) {
								BigDecimal selOrigRowIdVal = new BigDecimal(legacyIdOrigRowIdMap.get(mdmLegacyId).trim());
								BigDecimal curOrigRowIdVal = new BigDecimal(tempXrefList.get(indx).getORIGROWIDOBJECT().trim());
								if(selOrigRowIdVal.compareTo(curOrigRowIdVal) > 0) {
									legacyIdOrigRowIdMap.put(mdmLegacyId, tempXrefList.get(indx).getORIGROWIDOBJECT());
									Map<String, String> sfdcMap = new HashMap<String, String>();
									sfdcMap.put("SFID", tempXrefList.get(indx).getAccount().get(0).getSalesForceID());
									sfdcMap.put("DraftFlg", tempXrefList.get(indx).getAccount().get(0).getDraftAccountFlag());
									legacyIdSfdcMap.put(mdmLegacyId, sfdcMap);
								}
							}
						}
					}
					
					legacyIdMap.put(mdmLegacyId,legacyPartyXrefList);
					LOG.debug("Inserted data in legacyIdMap.");
				} 
				
				} else {
					LOG.debug("LegacyID is null for this XREF.");
					if(!tempXrefList.get(indx).getXREF().get(0).getSRCSYSTEM().trim().equalsIgnoreCase("DNB"))	{
						partyXrefList.add(tempXrefList.get(indx));	//XREF copy with No LegacyId.
					} else {
						LOG.debug("Excluding ELQ / DnB Singleton Xref Rowid: " + mapentry.getKey());
					}
				}
				LOG.debug("Executed 1st FOR LOOP.");
				}
			//	tempXrefList.clear();

				if (legacyIdMap != null && legacyIdMap.size() > 0)	{
					//Fetching Distinct LegacyID XREF Copy
					for(Entry<String, List<PartyXrefType>> entry : legacyIdMap.entrySet())	{
						LOG.debug("Executing 2nd FOR LOOP.");
						LOG.debug("legacyIdMap Key: "+ entry.getKey());
						List<PartyXrefType> tmpList = (List<PartyXrefType>) entry.getValue();
						if(tmpList.size() >= 2)	{
							boolean xrefFound = false;
						//	LOG.debug("tmpList.size() >= 2");
							for(PartyXrefType pXrefType : tmpList)	{
							
								if(pXrefType.getXREF().get(0).getSRCSYSTEM().trim().equalsIgnoreCase(priorSRC1))	{
									/** Modified for SFDC START */
									Map<String, String> sfdcMap = legacyIdSfdcMap.get(entry.getKey());
									if(sfdcMap != null) {
										pXrefType.getAccount().get(0).setSalesForceID(sfdcMap.get("SFID"));
										pXrefType.getAccount().get(0).setDraftAccountFlag(sfdcMap.get("DraftFlg"));
									}
									/** Modified for SFDC END */
									partyXrefList.add(pXrefType);	//XREF copy having SRC_SYSTEM = priorSRC1
									LOG.debug("partyRowId with priorSRC1 XREF copy");
									xrefFound =true;
									break;
								}
							}
								//changes for MDMP-3283
							if(!xrefFound){
							for(PartyXrefType pXrefType : tmpList)	{
								if(pXrefType.getXREF().get(0).getSRCSYSTEM().trim().equalsIgnoreCase(priorSRC2))	{
									/** Modified for SFDC START */
									Map<String, String> sfdcMap = legacyIdSfdcMap.get(entry.getKey());
									if(sfdcMap != null) {
										pXrefType.getAccount().get(0).setSalesForceID(sfdcMap.get("SFID"));
										pXrefType.getAccount().get(0).setDraftAccountFlag(sfdcMap.get("DraftFlg"));
									}
									/** Modified for SFDC END */
									partyXrefList.add(pXrefType);	//XREF copy having SRC_SYSTEM = priorSRC2
									LOG.debug("partyRowId with priorSRC2 XREF copy");
									xrefFound =true;
									break;
								}
							}}
							if(!xrefFound){
							for(PartyXrefType pXrefType : tmpList)	{
								if(pXrefType.getXREF().get(0).getSRCSYSTEM().trim().equalsIgnoreCase(priorSRC3))	{
									/** Modified for SFDC START */
									Map<String, String> sfdcMap = legacyIdSfdcMap.get(entry.getKey());
									if(sfdcMap != null) {
										pXrefType.getAccount().get(0).setSalesForceID(sfdcMap.get("SFID"));
										pXrefType.getAccount().get(0).setDraftAccountFlag(sfdcMap.get("DraftFlg"));
									}
									/** Modified for SFDC END */
									partyXrefList.add(pXrefType);	//XREF copy having SRC_SYSTEM = priorSRC3
									LOG.debug("partyRowId with priorSRC3 XREF copy");
									xrefFound =true;
									break;
								}
							}
						}} else {
							partyXrefList.addAll(tmpList);	//partyRowId with single XREF copy.
							LOG.debug("partyRowId with single XREF copy");
						}
						LOG.debug("Executed 2nd FOR LOOP.");
					}
			//		legacyIdMap.clear();
				}
			} else {
				LOG.info("tempXrefList is NULL." );
			}
		//	LOG.debug("finnaly adding in master response ");
		//	LOG.debug("XREF Copies for only Priority1: " + priorSRC1 + " are shown.");

			//Populating NULL tags in Response Canonical Format
			if (partyXrefList.size() != 0) {
				for(int indx = 0 ; indx < partyXrefList.size(); indx++)	{
					CanonicalFormManipulator.setDefaultValueInXrefAttributes(partyXrefList.get(indx));
				}
				LOG.debug("Populating final partyXrefListMap.");
				partyXrefListMap.put(mapentry.getKey(),partyXrefList);
				LOG.debug(partyXrefList.size() + " XREFs successfully found for partyRowId: " + mapentry.getKey());
			}
		//	partyXrefList.clear();
		}
		LOG.debug("XREF Copies for only Priority1: " + priorSRC1 + " are shown.");

/*		if (partyXrefList.size() != 0) {

			for(int indx = 0; indx < partyXrefList.size(); indx++)	{

				String partyRowId = partyXrefList.get(indx).getROWIDOBJECT();
				LOG.info("partyRowId: " + partyRowId);

				if(partyXrefListMap.containsKey(partyRowId)) {

					finalPartyXrefList.add(partyXrefList.get(indx));
				} else {

					finalPartyXrefList = new ArrayList<PartyXrefType>();
					finalPartyXrefList.add(tempPartyXrefList.get(indx));
				}

				partyXrefListMap.put(partyRowId,finalPartyXrefList);
				LOG.debug("Inserted data in partyXrefListMap.");
			}
	//		xrefCopy = new XREFCopy();
	//		xrefCopy.getPartyXref().addAll(partyXrefList);
	//		xrefCopyList.add(xrefCopy);
			LOG.debug(partyXrefList.size() + " XREFs successfully found!");
			for(Entry<String, List<PartyXrefType>> entry : partyXrefListMap.entrySet())	{
				LOG.debug("partyXrefListMap partyRowId: " + entry.getKey() + "| partyXrefListMap Xrefs:" + entry.getValue().size());
			}

		} */


	} catch (Exception exp) {
		LOG.error(" Caught Exception in createXrefCanonicalForm ", exp);
		ServiceProcessingException customException = new ServiceProcessingException(exp);
		customException.setMessage("Failed to process search request." + customException.getMessage());
		throw customException;
	}

	LOG.info("Executed createXrefCanonicalForm()");
	return partyXrefListMap;

	}
	//Modified for Track2
			//Method to get Relationship details from Org extn
		public Map<String,String> getMdmHierarchyView(String rowidParty) throws SQLException	{
			LOG.debug("Inside getMdmHierarchyView" );
			Connection jdbcConn = null;
			PreparedStatement pstatement = null;
			ResultSet resultSet = null;
			JDBCConnectionProvider jDBCConnectionProvider =  null;
		//	jdbcConn = JdbcConn.GetJdbcConnObject();
			Map<String,String> ucnMap = new HashMap<String,String>();
			String sql = "SELECT MDM_PARENT_UCN,MFE_PARENT_NM,MFE_GLBL_PARENT_UCN,MFE_GLBL_PARENT_NM, GLB_FLG,MFE_WW_PARENT_PRTN_NM,MFE_SUBSDRY_PARENT_PRTN_NM,MFE_GLOBAL_PAR_NM_OVRIDE,PTR_PARENT_UCN,PTR_PARENT_NM,PTR_GLBL_PARENT_UCN  FROM C_B_PARTY_ORG_EXTN where ROWID_PARTY= ?";
			try{
				jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
				jdbcConn = jDBCConnectionProvider.getJdbcConnectionFromDS();
				pstatement = jdbcConn.prepareStatement(sql);
				pstatement.setString(1, rowidParty);
				resultSet = pstatement.executeQuery();
			//	System.out.println(pstatement.getMaxRows());

				while (resultSet.next()) {

					ucnMap.put("MDM_PARENT_UCN",resultSet.getString(1));
					ucnMap.put("MFE_PARENT_NM",resultSet.getString(2));
					ucnMap.put("MFE_GLBL_PARENT_UCN", resultSet.getString(3));
					ucnMap.put("MFE_GLBL_PARENT_NM", resultSet.getString(4));
					ucnMap.put("GLB_FLG", resultSet.getString(5));
					ucnMap.put("MFE_WW_PARENT_PRTN_NM", resultSet.getString(6));
					ucnMap.put("MFE_SUBSDRY_PARENT_PRTN_NM", resultSet.getString(7));
					ucnMap.put("MFE_GLOBAL_PAR_NM_OVRIDE", resultSet.getString(8));
					ucnMap.put("PTR_PARENT_UCN", resultSet.getString(9));
					ucnMap.put("PTR_PARENT_NM", resultSet.getString(10));
					ucnMap.put("PTR_GLBL_PARENT_UCN", resultSet.getString(11));
				}
			} catch(SQLException exp)	{
				LOG.error("Caught exception in getMdmHierarchyView()" + exp.getMessage());
			} catch (ServiceProcessingException e) {

				LOG.error("Caught exception in getMdmHierarchyView()" + e.getMessage());
			}
				finally	{
					//Closing connections
					if (resultSet != null)  resultSet.close();
					if (pstatement != null) pstatement.close();
					if (jdbcConn != null) jdbcConn.close();
				}
			LOG.debug("Executed getMdmHierarchyView");
			return ucnMap;
		}
		public static final List<GlobalHierarchyNode>  getGlobalHierarchy(String partyRowId)  throws SQLException{
			LOG.debug("Inside getGlobalHierarchy" );
			Connection jdbcConn = null;
			PreparedStatement pstatement = null;
			ResultSet resultSet = null;
			JDBCConnectionProvider jDBCConnectionProvider =  null;
			List<GlobalHierarchyNode> globalHierarchyList = new ArrayList<GlobalHierarchyNode>();
			String sql = "select * from PKG_PARTY_REL where rowid_object = ? and HIERARCHY_CODE IN ('McAfee Hierarchy','Partner Reseller Hierarchy') and rownum < 2 ";
			
			try{
				jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
				jdbcConn = jDBCConnectionProvider.getJdbcConnectionFromDS();
				pstatement = jdbcConn.prepareStatement(sql);
				pstatement.setString(1, partyRowId);
				resultSet = pstatement.executeQuery();
				while (resultSet.next()) {
					GlobalHierarchyNode globalHierarchyNode = new GlobalHierarchyNode();
					globalHierarchyNode.setRowidObject(resultSet.getString(3));
					globalHierarchyNode.setPartyRelRowid(resultSet.getString(4));
					globalHierarchyNode.setParentPartyRowid(resultSet.getString(5));
					globalHierarchyNode.setHierarchyCode(resultSet.getString(6));
					globalHierarchyNode.setRelTypeCode(resultSet.getString(7));
					globalHierarchyList.add(globalHierarchyNode);
				}
			} catch(SQLException exp)	{
				LOG.error("Caught exception in getGlobalHierarchy()" + exp.getMessage());
			} catch (ServiceProcessingException e) {

				LOG.error("Caught exception in getGlobalHierarchy()" + e.getMessage());
			}
				finally	{
					//Closing connections
					if (resultSet != null)  resultSet.close();
					if (pstatement != null) pstatement.close();
					if (jdbcConn != null) jdbcConn.close();
				}
			LOG.info("Executed getGlobalHierarchy :: " + globalHierarchyList.size());		
			LOG.debug("Executed getGlobalHierarchy");
			return globalHierarchyList;	
		}
		
		private Map<String,String> getPartnerRellserHierarchyView(String rowidParty,String partyType) throws SQLException	{
			LOG.debug("Inside getPartnerRellserHierarchyView" );
			Connection jdbcConn = null;
			PreparedStatement pstatement = null;
			ResultSet resultSet = null;
			JDBCConnectionProvider jDBCConnectionProvider =  null;
			Map<String,String> ucnMap = new HashMap<String,String>();
			String sql = "select DISTINCT MDM_PRTNR_ORG_UCN,PRTNR_ORG_NM from MDM_PRTNR_HIER_DENORM_VIEW where MDM_PRTNR_ACCT_ROWID=? and PARTY_TYPE=?";
			try{
				jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
				jdbcConn = jDBCConnectionProvider.getJdbcConnectionFromDS();
				pstatement = jdbcConn.prepareStatement(sql);
				pstatement.setString(1, rowidParty);
				pstatement.setString(2, partyType);
				resultSet = pstatement.executeQuery();

				while (resultSet.next()) {

					ucnMap.put("MDM_PRTNR_ORG_UCN",resultSet.getString(1));
					ucnMap.put("PRTNR_ORG_NM",resultSet.getString(2));
				}
			} catch(SQLException exp)	{
				LOG.error("Caught exception in getPartnerRellserHierarchyView()" + exp.getMessage());
			} catch (ServiceProcessingException e) {

				LOG.error("Caught exception in getPartnerRellserHierarchyView()" + e.getMessage());
			}
				finally	{
					//Closing connections
					if (resultSet != null)  resultSet.close();
					if (pstatement != null) pstatement.close();
					if (jdbcConn != null) jdbcConn.close();
				}
			LOG.debug("Executed getMdmHierarchyView");
			
			if(ucnMap.size()==0){
				ucnMap.put("MDM_PRTNR_ORG_UCN","");
				ucnMap.put("PRTNR_ORG_NM","");
			}
			return ucnMap;
		}
}
