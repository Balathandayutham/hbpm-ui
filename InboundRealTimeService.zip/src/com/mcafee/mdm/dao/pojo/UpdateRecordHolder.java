package com.mcafee.mdm.dao.pojo;

import java.util.ArrayList;
import java.util.List;

import com.mcafee.mdm.generated.ClassificationXrefType;
import com.mcafee.mdm.generated.CommunicationXrefType;;




/**
 * The POJO class holds field values returned by GETRequest
 */
public class UpdateRecordHolder {

	private String partySrcPkey;
	private String partySrcSys;
	private String acctSrcPkey;
	private String acctSrcSys;
	private String addrSrcPkey;
	private String addrSrcSys;
	private String parOrgExtSrcPkey;
	private String parOrgExtSrcSys;
	private String parPerExtPkey;
	private String parPerExtSys;
	private String commSrcPkey;
	private String commSrcSys;
	private String classSrcPkey;
	private String classSrcSys;
	private String partyRowIDObject;
	private String rowidAccount;
	private String rowidAddress;
	private String rowidPrsnExtn;
	private String rowidOrgExtn;
	private String rowidComm;
	private String rowidClass;
	private List<CommunicationXrefType> commList;
	private List<ClassificationXrefType> classList;
	
	public UpdateRecordHolder()	{
		
		List<CommunicationXrefType> commList = new ArrayList<CommunicationXrefType>();
		List<ClassificationXrefType> classList = new ArrayList<ClassificationXrefType>();
	}
	public String getPartySrcPkey() {
		return partySrcPkey;
	}


	public void setPartySrcPkey(String partySrcPkey) {
		this.partySrcPkey = partySrcPkey;
	}


	public String getPartySrcSys() {
		return partySrcSys;
	}


	public void setPartySrcSys(String partySrcSys) {
		this.partySrcSys = partySrcSys;
	}


	public String getAcctSrcPkey() {
		return acctSrcPkey;
	}


	public void setAcctSrcPkey(String acctSrcPkey) {
		this.acctSrcPkey = acctSrcPkey;
	}


	public String getAcctSrcSys() {
		return acctSrcSys;
	}


	public void setAcctSrcSys(String acctSrcSys) {
		this.acctSrcSys = acctSrcSys;
	}


	public String getAddrSrcPkey() {
		return addrSrcPkey;
	}


	public void setAddrSrcPkey(String addrSrcPkey) {
		this.addrSrcPkey = addrSrcPkey;
	}


	public String getAddrSrcSys() {
		return addrSrcSys;
	}


	public void setAddrSrcSys(String addrSrcSys) {
		this.addrSrcSys = addrSrcSys;
	}




	public String getParOrgExtSrcPkey() {
		return parOrgExtSrcPkey;
	}


	public void setParOrgExtSrcPkey(String parOrgExtSrcPkey) {
		this.parOrgExtSrcPkey = parOrgExtSrcPkey;
	}


	public String getParOrgExtSrcSys() {
		return parOrgExtSrcSys;
	}


	public void setParOrgExtSrcSys(String parOrgExtSrcSys) {
		this.parOrgExtSrcSys = parOrgExtSrcSys;
	}


	public String getParPerExtPkey() {
		return parPerExtPkey;
	}


	public void setParPerExtPkey(String parPerExtPkey) {
		this.parPerExtPkey = parPerExtPkey;
	}


	public String getParPerExtSys() {
		return parPerExtSys;
	}


	public void setParPerExtSys(String parPerExtSys) {
		this.parPerExtSys = parPerExtSys;
	}


	
	public String getPartyRowIDObject() {
		return partyRowIDObject;
	}
	public void setPartyRowIDObject(String partyRowIDObject) {
		this.partyRowIDObject = partyRowIDObject;
	}
	public String getRowidAccount() {
		return rowidAccount;
	}
	public void setRowidAccount(String rowidAccount) {
		this.rowidAccount = rowidAccount;
	}
	public String getRowidAddress() {
		return rowidAddress;
	}
	public void setRowidAddress(String rowidAddress) {
		this.rowidAddress = rowidAddress;
	}
	public String getRowidPrsnExtn() {
		return rowidPrsnExtn;
	}
	public void setRowidPrsnExtn(String rowidPrsnExtn) {
		this.rowidPrsnExtn = rowidPrsnExtn;
	}
	public String getRowidOrgExtn() {
		return rowidOrgExtn;
	}
	public void setRowidOrgExtn(String rowidOrgExtn) {
		this.rowidOrgExtn = rowidOrgExtn;
	}
	public String getCommSrcPkey() {
		return commSrcPkey;
	}
	public void setCommSrcPkey(String commSrcPkey) {
		this.commSrcPkey = commSrcPkey;
	}
	public String getCommSrcSys() {
		return commSrcSys;
	}
	public void setCommSrcSys(String commSrcSys) {
		this.commSrcSys = commSrcSys;
	}
	public String getClassSrcPkey() {
		return classSrcPkey;
	}
	public void setClassSrcPkey(String classSrcPkey) {
		this.classSrcPkey = classSrcPkey;
	}
	public String getClassSrcSys() {
		return classSrcSys;
	}
	public void setClassSrcSys(String classSrcSys) {
		this.classSrcSys = classSrcSys;
	}
	public String getRowidComm() {
		return rowidComm;
	}
	public void setRowidComm(String rowidComm) {
		this.rowidComm = rowidComm;
	}
	public String getRowidClass() {
		return rowidClass;
	}
	public void setRowidClass(String rowidClass) {
		this.rowidClass = rowidClass;
	}
	public List<CommunicationXrefType> getCommList() {
		return commList;
	}
	public void setCommList(List<CommunicationXrefType> commList) {
		this.commList = commList;
	}
	public List<ClassificationXrefType> getClassList() {
		return classList;
	}
	public void setClassList(List<ClassificationXrefType> classList) {
		this.classList = classList;
	}
	public String toString()	{
		
		StringBuilder strB = new StringBuilder(); 
		strB.append(" PartyPkey: "+partySrcPkey + " PartySrcSys: "+partySrcSys +" ACCTPkey: "+acctSrcPkey +" AccSys: "+acctSrcSys);
		strB.append(" AddrPkey: "+ addrSrcPkey +" AddrSys: "+ addrSrcSys);
		strB.append(" PartyOrgExtPkey: " + parOrgExtSrcPkey + " PartyOrgExtSys: " + parOrgExtSrcSys + " PartyPrsnExtPkey: " + parPerExtPkey + " PartyPrsnExtPkey: " + parPerExtSys);
		return strB.toString();
		
	}
	
}
