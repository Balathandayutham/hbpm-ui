package com.mcafee.mdm.dao.pojo;

/**
 * The POJO class holds field values returned by SIF RecordKey object of any Put response
 */
public class PutResponseDataHolder {

	private String actionType;
	private String actionMessage;
	private String rowidObject;
	private String rowidXREF;
	private String sourceKey;
	private String systemName;
	
	public String getActionType() {
		return actionType;
	}
	public void setActionType(String actionType) {
		this.actionType = actionType;
	}
	public String getActionMessage() {
		return actionMessage;
	}
	public void setActionMessage(String actionMessage) {
		this.actionMessage = actionMessage;
	}
	public String getRowidObject() {
		return rowidObject;
	}
	public void setRowidObject(String rowidObject) {
		this.rowidObject = rowidObject;
	}
	public String getRowidXREF() {
		return rowidXREF;
	}
	public void setRowidXREF(String rowidXREF) {
		this.rowidXREF = rowidXREF;
	}
	public String getSourceKey() {
		return sourceKey;
	}
	public void setSourceKey(String sourceKey) {
		this.sourceKey = sourceKey;
	}
	public String getSystemName() {
		return systemName;
	}
	public void setSystemName(String systemName) {
		this.systemName = systemName;
	}
}
