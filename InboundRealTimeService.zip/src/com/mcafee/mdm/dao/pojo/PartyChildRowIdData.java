package com.mcafee.mdm.dao.pojo;

/**
 * Data class to hold Child Row-Ids of a Party
 * 
 * @since M4M Project
 * @author MDM Team Cognizant
 */
public class PartyChildRowIdData {
	private String rowIdParty;
	private String rowIdProspect;
	private String rowIdAddr;

	/**
	 * @return the rowIdParty
	 */
	public String getRowIdParty() {
		return rowIdParty;
	}

	/**
	 * @param rowIdParty
	 *            the rowIdParty to set
	 */
	public void setRowIdParty(String rowIdParty) {
		this.rowIdParty = rowIdParty;
	}

	/**
	 * @return the rowIdProspect
	 */
	public String getRowIdProspect() {
		return rowIdProspect;
	}

	/**
	 * @param rowIdProspect
	 *            the rowIdProspect to set
	 */
	public void setRowIdProspect(String rowIdProspect) {
		this.rowIdProspect = rowIdProspect;
	}

	/**
	 * @return the rowIdAddr
	 */
	public String getRowIdAddr() {
		return rowIdAddr;
	}

	/**
	 * @param rowIdAddr
	 *            the rowIdAddr to set
	 */
	public void setRowIdAddr(String rowIdAddr) {
		this.rowIdAddr = rowIdAddr;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "PartyChildRowIdData [RowIdParty=" + getRowIdParty()
				+ ", RowIdProspect=" + getRowIdProspect() + ", RowIdAddr="
				+ getRowIdAddr() + "]";
	}
}
