package com.mcafee.mdm.dao.pojo;

/**
 * Data class to hold unprocessed Account-Contact Relation
 * 
 * @since M4M Project
 * @author MDM Team Cognizant
 */
public class AcntCntctRelData {
	private String acntSrcSystem;
	private String acntSrcPkey;
	private String cntctSrcSystem;
	private String cntctSrcPkey;
	private String acntRowid;

	/**
	 * @return the acntSrcSystem
	 */
	public String getAcntSrcSystem() {
		return acntSrcSystem;
	}

	/**
	 * @param acntSrcSystem
	 *            the acntSrcSystem to set
	 */
	public void setAcntSrcSystem(String acntSrcSystem) {
		this.acntSrcSystem = acntSrcSystem;
	}

	/**
	 * @return the acntSrcPkey
	 */
	public String getAcntSrcPkey() {
		return acntSrcPkey;
	}

	/**
	 * @param acntSrcPkey
	 *            the acntSrcPkey to set
	 */
	public void setAcntSrcPkey(String acntSrcPkey) {
		this.acntSrcPkey = acntSrcPkey;
	}

	/**
	 * @return the cntctSrcSystem
	 */
	public String getCntctSrcSystem() {
		return cntctSrcSystem;
	}

	/**
	 * @param cntctSrcSystem
	 *            the cntctSrcSystem to set
	 */
	public void setCntctSrcSystem(String cntctSrcSystem) {
		this.cntctSrcSystem = cntctSrcSystem;
	}

	/**
	 * @return the cntctSrcPkey
	 */
	public String getCntctSrcPkey() {
		return cntctSrcPkey;
	}

	/**
	 * @param cntctSrcPkey
	 *            the cntctSrcPkey to set
	 */
	public void setCntctSrcPkey(String cntctSrcPkey) {
		this.cntctSrcPkey = cntctSrcPkey;
	}
	public String getAcntRowid() {
		return acntRowid;
	}

	public void setAcntRowid(String acntRowid) {
		this.acntRowid = acntRowid;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("{acntCntctRelData [acntSrcSystem=");
		builder.append(getAcntSrcSystem());
		builder.append(", acntSrcPkey=");
		builder.append(getAcntSrcPkey());
		builder.append(", cntctSrcSystem=");
		builder.append(getCntctSrcSystem());
		builder.append(", cntctSrcPkey=");
		builder.append(getCntctSrcPkey());
		builder.append(", acntRowid=");
		builder.append(getAcntRowid());
		builder.append("]}");
		return builder.toString();
	}
}
