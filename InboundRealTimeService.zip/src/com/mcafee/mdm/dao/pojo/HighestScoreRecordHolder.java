package com.mcafee.mdm.dao.pojo;

import java.util.HashMap;
import java.util.Map;

/**
 * The POJO class holds field values returned by SIF RecordKey object of any Put response
 */
public class HighestScoreRecordHolder {

	private String partyRowIDObject;
	private String partyType;
	private String sapCustNumber;
	private String OrgDunsNbr;
	private String UCN;
	private String rowidAccount;
	private String rowidPerson;
	//private String rowidAddress;
	Map<String, String> addrMap;
	Map<String, String> commMap;
	Map<String, String> classMap;
	private String rowidPrsnExtn;
	private String rowidOrgExtn;
	
	public HighestScoreRecordHolder()	{
		addrMap = new HashMap<String, String> ();
		classMap = new HashMap<String, String> ();
		commMap = new HashMap<String, String> ();
	}
	public String getPartyRowIDObject() {
		return partyRowIDObject;
	}
	public void setPartyRowIDObject(String partyRowIDObject) {
		this.partyRowIDObject = partyRowIDObject;
	}
	public String getPartyType() {
		return partyType;
	}
	public void setPartyType(String partyType) {
		this.partyType = partyType;
	}
	public String getUCN() {
		return UCN;
	}
	public void setUCN(String uCN) {
		this.UCN = uCN;
	}
	public String getSapCustNumber() {
		return sapCustNumber;
	}
	public void setSapCustNumber(String sapCustNumber) {
		this.sapCustNumber = sapCustNumber;
	}
	public String getOrgDunsNbr() {
		return OrgDunsNbr;
	}
	public void setOrgDunsNbr(String orgDunsNbr) {
		OrgDunsNbr = orgDunsNbr;
	}
	public String getRowidAccount() {
		return rowidAccount;
	}
	public void setRowidAccount(String rowidAccount) {
		this.rowidAccount = rowidAccount;
	}
	/*
	public String getRowidAddress() {
		return rowidAddress;
	}
	public void setRowidAddress(String rowidAddress) {
		this.rowidAddress = rowidAddress;
	}
	public String getRowidCommunication() {
		return rowidCommunication;
	}
	public void setRowidCommunication(String rowidCommunication) {
		this.rowidCommunication = rowidCommunication;
	}
	public String getRowidCLASSIFCTN() {
		return rowidCLASSIFCTN;
	}
	public void setRowidCLASSIFCTN(String rowidCLASSIFCTN) {
		this.rowidCLASSIFCTN = rowidCLASSIFCTN;
	}*/
	public String getRowidPrsnExtn() {
		return rowidPrsnExtn;
	}
	
	public void setRowidPrsnExtn(String rowidPrsnExtn) {
		this.rowidPrsnExtn = rowidPrsnExtn;
	}
	public String getRowidOrgExtn() {
		return rowidOrgExtn;
	}
	public void setRowidOrgExtn(String rowidOrgExtn) {
		this.rowidOrgExtn = rowidOrgExtn;
	}
	public Map<String, String> getAddrMap() {
		return addrMap;
	}
	public void setAddrMap(Map<String, String> addrMap) {
		this.addrMap = addrMap;
	}
	public Map<String, String> getCommMap() {
		return commMap;
	}
	public void setCommMap(Map<String, String> commMap) {
		this.commMap = commMap;
	}
	public Map<String, String> getClassMap() {
		return classMap;
	}
	public void setClassMap(Map<String, String> classMap) {
		this.classMap = classMap;
	}
	
	public String getRowidPerson() {
		return rowidPerson;
	}
	public void setRowidPerson(String rowidPerson) {
		this.rowidPerson = rowidPerson;
	}
	public String toString()	{
		
		StringBuilder strB = new StringBuilder(); 
		strB.append("PartyRowID: "+partyRowIDObject + "|SapCust: "+sapCustNumber +"|OrgDuns: "+OrgDunsNbr +"|AccRowID: "+rowidAccount+"|PartyPersonRowID: "+rowidPerson);
		//strB.append(" AddrRowID: "+rowidAddress +" OrgRowID: "+rowidOrgExtn);
		return strB.toString();
		
	}
	
}
