package com.mcafee.mdm.dao.pojo;

/**
 * Pojo class to hold Rowid_object, party_rel_rowid, parent_party_rowid,
 * Hierarchy_code & rel_type_code.
 * 
 * @author 515189
 * 
 */
public class GlobalHierarchyNode {
	String RowidObject;
	String partyRelRowid;
	String parentPartyRowid;
	String HierarchyCode;
	String relTypeCode;

	public String getRowidObject() {
		return RowidObject;
	}

	public void setRowidObject(String rowidObject) {
		RowidObject = rowidObject;
	}

	public String getPartyRelRowid() {
		return partyRelRowid;
	}

	public void setPartyRelRowid(String partyRelRowid) {
		this.partyRelRowid = partyRelRowid;
	}

	public String getParentPartyRowid() {
		return parentPartyRowid;
	}

	public void setParentPartyRowid(String parentPartyRowid) {
		this.parentPartyRowid = parentPartyRowid;
	}

	public String getHierarchyCode() {
		return HierarchyCode;
	}

	public void setHierarchyCode(String hierarchyCode) {
		HierarchyCode = hierarchyCode;
	}

	public String getRelTypeCode() {
		return relTypeCode;
	}

	public void setRelTypeCode(String relTypeCode) {
		this.relTypeCode = relTypeCode;
	}
}
