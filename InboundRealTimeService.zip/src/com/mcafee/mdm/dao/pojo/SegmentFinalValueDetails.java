package com.mcafee.mdm.dao.pojo;

public class SegmentFinalValueDetails {

	private String partyPkey;
	private String partyRowid;
	private String classifctnPkey;
	private String rowidClassifctn;
	private String rowidSystem;
	private String classfctnValue;
	private String startDate;
	private String endDate;
	
	public String getPartyPkey() {
		return partyPkey;
	}
	public void setPartyPkey(String partyPkey) {
		this.partyPkey = partyPkey;
	}
	
	public String getPartyRowid() {
		return partyRowid;
	}
	public void setPartyRowid(String partyRowid) {
		this.partyRowid = partyRowid;
	}
	public String getClassifctnPkey() {
		return classifctnPkey;
	}
	public void setClassifctnPkey(String classifctnPkey) {
		this.classifctnPkey = classifctnPkey;
	}
	public String getRowidClassifctn() {
		return rowidClassifctn;
	}
	public void setRowidClassifctn(String rowidClassifctn) {
		this.rowidClassifctn = rowidClassifctn;
	}
	
	public String getRowidSystem() {
		return rowidSystem;
	}
	public void setRowidSystem(String rowidSystem) {
		this.rowidSystem = rowidSystem;
	}
	public String getClassfctnValue() {
		return classfctnValue;
	}
	public void setClassfctnValue(String classfctnValue) {
		this.classfctnValue = classfctnValue;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
}
