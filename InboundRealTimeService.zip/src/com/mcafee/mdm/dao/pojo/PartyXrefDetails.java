package com.mcafee.mdm.dao.pojo;

public class PartyXrefDetails {

	private String partyPkey;
	private String partyRowidObject;
	private String partyRowidSystem;
	
	public String getPartyPkey() {
		return partyPkey;
	}
	public void setPartyPkey(String partyPkey) {
		this.partyPkey = partyPkey;
	}
	public String getPartyRowidObject() {
		return partyRowidObject;
	}
	public void setPartyRowidObject(String partyRowidObject) {
		this.partyRowidObject = partyRowidObject;
	}
	public String getPartyRowidSystem() {
		return partyRowidSystem;
	}
	public void setPartyRowidSystem(String partyRowidSystem) {
		this.partyRowidSystem = partyRowidSystem;
	}
}
