package com.mcafee.mdm.dao.pojo;

import java.util.HashMap;
import java.util.Map;

import com.mcafee.mdm.generated.AccountType;
import com.mcafee.mdm.generated.AddressType;
import com.mcafee.mdm.generated.ClassificationType;
import com.mcafee.mdm.generated.CommunicationType;
import com.mcafee.mdm.generated.PartyAccountRelationshipType;
import com.mcafee.mdm.generated.PartyOrgExtType;
import com.mcafee.mdm.generated.PartyPersonExtType;
import com.mcafee.mdm.generated.PartyPersonType;
import com.mcafee.mdm.generated.PartyRelationshipType;
import com.mcafee.mdm.generated.XREFType;

public class SearchedRecordCollection {

	String party_rowid;
	String bo_class;
	String party_type;
	String party_name;
	String geo;
	String region;
	String physicalGeo;
	String physicalRegion;
	String status_cd;
	String vat_regno;
	String tax_jd_cd;
	String sales_cd;
	String ucn;
	String english_name;
	String sipPop;
	String msgTrackingId;
	String srcUpdateBy;
    String updatedate;
	int mtchScoreValue;
	Map<String, AddressType> addressMap;
	Map<String, AccountType> accountMap;
	Map<String, CommunicationType> commMap;
	Map<String, ClassificationType> classMap;
	Map<String, PartyPersonExtType> partyPersonMap;
	Map<String, PartyOrgExtType> partyOrgMap;
	Map<String, PartyPersonType> partyPersnMap;
	/** Modified for M4M START */
	Map<String, PartyRelationshipType> partyRelMap;
	//Map<String, PartyAccountRelationshipType> partyRelMap;
	Map<String, PartyAccountRelationshipType> partyAcctRelMap;
	/** Modified for M4M END */
	Map<String, XREFType> xrefMap;
	
	
	public SearchedRecordCollection() {
		addressMap = new HashMap<String, AddressType>();
		accountMap = new HashMap<String, AccountType>();
		commMap = new HashMap<String, CommunicationType>();
		classMap = new HashMap<String, ClassificationType> ();
		partyPersonMap = new  HashMap<String, PartyPersonExtType> ();
		partyOrgMap = new  HashMap<String, PartyOrgExtType> ();
		partyPersnMap = new HashMap<String, PartyPersonType>();
		/** Modified for M4M START */
		partyRelMap = new  HashMap<String, PartyRelationshipType> ();
		//partyRelMap = new  HashMap<String, PartyAccountRelationshipType> ();
		partyAcctRelMap = new  HashMap<String, PartyAccountRelationshipType> ();
		/** Modified for M4M END */
		xrefMap = new  HashMap<String, XREFType> ();
	}
	
	
	public String getParty_rowid() {
		return party_rowid;
	}

	public void setParty_rowid(String party_rowid) {
		this.party_rowid = party_rowid;
	}

	public String getBo_class() {
		return bo_class;
	}

	public void setBo_class(String bo_class) {
		this.bo_class = bo_class;
	}

	public String getParty_type() {
		return party_type;
	}

	public void setParty_type(String party_type) {
		this.party_type = party_type;
	}

	public String getParty_name() {
		return party_name;
	}

	public void setParty_name(String party_name) {
		this.party_name = party_name;
	}

	public String getGeo() {
		return geo;
	}

	public void setGeo(String geo) {
		this.geo = geo;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getStatus_cd() {
		return status_cd;
	}

	public void setStatus_cd(String status_cd) {
		this.status_cd = status_cd;
	}

	public String getVat_regno() {
		return vat_regno;
	}

	public void setVat_regno(String vat_regno) {
		this.vat_regno = vat_regno;
	}

	public String getTax_jd_cd() {
		return tax_jd_cd;
	}

	public void setTax_jd_cd(String tax_jd_cd) {
		this.tax_jd_cd = tax_jd_cd;
	}

	public String getSales_cd() {
		return sales_cd;
	}

	public void setSales_cd(String sales_cd) {
		this.sales_cd = sales_cd;
	}

	public String getUcn() {
		return ucn;
	}

	public void setUcn(String ucn) {
		this.ucn = ucn;
	}

	
	public Map<String, AddressType> getAddressMap() {
		return addressMap;
	}

	public void setAddressMap(Map<String, AddressType> addressMap) {
		this.addressMap = addressMap;
	}

	public Map<String, AccountType> getAccountMap() {
		return accountMap;
	}

	public void setAccountMap(Map<String, AccountType> accountMap) {
		this.accountMap = accountMap;
	}

	public Map<String, CommunicationType> getCommMap() {
		return commMap;
	}

	public void setCommMap(Map<String, CommunicationType> commMap) {
		this.commMap = commMap;
	}

	public Map<String, ClassificationType> getClassMap() {
		return classMap;
	}

	public void setClassMap(Map<String, ClassificationType> classMap) {
		this.classMap = classMap;
	}

	public Map<String, PartyPersonExtType> getPartyPersonMap() {
		return partyPersonMap;
	}

	public void setPartyPersonMap(Map<String, PartyPersonExtType> partyPersonMap) {
		this.partyPersonMap = partyPersonMap;
	}

	public Map<String, PartyOrgExtType> getPartyOrgMap() {
		return partyOrgMap;
	}

	public void setPartyOrgMap(Map<String, PartyOrgExtType> partyOrgMap) {
		this.partyOrgMap = partyOrgMap;
	}
	
	/** Modified for M4M START */

	public Map<String, PartyRelationshipType> getPartyRelMap() {
		return partyRelMap;
	}

	public void setPartyRelMap(Map<String, PartyRelationshipType> partyRelMap) {
		this.partyRelMap = partyRelMap;
	}
	
	/*public Map<String, PartyAccountRelationshipType> getPartyRelMap() {
		return partyRelMap;
	}


	public void setPartyRelMap(Map<String, PartyAccountRelationshipType> partyRelMap) {
		this.partyRelMap = partyRelMap;
	}*/


	/** Modified for M4M END */

	public Map<String, XREFType> getXrefMap() {
		return xrefMap;
	}

	public void setXrefMap(Map<String, XREFType> xrefMap) {
		this.xrefMap = xrefMap;
	}


	public int getMtchScoreValue() {
		return mtchScoreValue;
	}


	public void setMtchScoreValue(int mtchScoreValue) {
		this.mtchScoreValue = mtchScoreValue;
	}


	public String getEnglish_name() {
		return english_name;
	}


	public void setEnglish_name(String english_name) {
		this.english_name = english_name;
	}


	public Map<String, PartyAccountRelationshipType> getPartyAcctRelMap() {
		return partyAcctRelMap;
	}


	public void setPartyAcctRelMap(
			Map<String, PartyAccountRelationshipType> partyAcctRelMap) {
		this.partyAcctRelMap = partyAcctRelMap;
	}


	public Map<String, PartyPersonType> getPartyPersnMap() {
		return partyPersnMap;
	}


	public void setPartyPersnMap(Map<String, PartyPersonType> partyPersnMap) {
		this.partyPersnMap = partyPersnMap;
	}


	public String getSipPop() {
		return sipPop;
	}


	public void setSipPop(String sipPop) {
		this.sipPop = sipPop;
	}


	public String getMsgTrackingId() {
		return msgTrackingId;
	}


	public void setMsgTrackingId(String msgTrackingId) {
		this.msgTrackingId = msgTrackingId;
	}


	public String getSrcUpdateBy() {
		return srcUpdateBy;
	}


	public void setSrcUpdateBy(String srcUpdateBy) {
		this.srcUpdateBy = srcUpdateBy;
	}


	public String getPhysicalGeo() {
		return physicalGeo;
	}


	public void setPhysicalGeo(String physicalGeo) {
		this.physicalGeo = physicalGeo;
	}


	public String getPhysicalRegion() {
		return physicalRegion;
	}


	public void setPhysicalRegion(String physicalRegion) {
		this.physicalRegion = physicalRegion;
	}


	public String getUpdatedate() {
		return updatedate;
	}


	public void setUpdatedate(String updatedate) {
		this.updatedate = updatedate;
	}


	

	
	
	
	
}
