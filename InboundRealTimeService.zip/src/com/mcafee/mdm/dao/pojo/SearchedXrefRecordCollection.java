package com.mcafee.mdm.dao.pojo;

import java.util.HashMap;
import java.util.Map;

import com.mcafee.mdm.generated.AccountXrefType;
import com.mcafee.mdm.generated.AddressXrefType;
import com.mcafee.mdm.generated.ClassificationXrefType;
import com.mcafee.mdm.generated.CommunicationXrefType;
import com.mcafee.mdm.generated.PartyAccountRelationshipXrefType;
import com.mcafee.mdm.generated.PartyOrgExtXrefType;
import com.mcafee.mdm.generated.PartyPersonExtXrefType;
import com.mcafee.mdm.generated.PartyPersonXrefType;
import com.mcafee.mdm.generated.PartyRelationshipXrefType;
import com.mcafee.mdm.generated.XREFType;

public class SearchedXrefRecordCollection {

	String party_rowid;
	String orig_rowid;
	String bo_class;
	String party_type;
	String party_name;
	String geo;
	String region;
	String status_cd;
	String vat_regno;
	String tax_jd_cd;
	String sales_cd;
	String ucn;
	String english_name;
	String legacyUcn;
	String dnbdbaname;
	String dnbsectradestyle;
	String dnbregname;
	String physicalGeo;
	String physicalRegion;
	String srcLudDate;
	Map<String, AddressXrefType> addressMap;
	Map<String, AccountXrefType> accountMap;
	Map<String, CommunicationXrefType> commMap;
	Map<String, ClassificationXrefType> classMap;
	Map<String, PartyPersonXrefType> partyPersonXrefMap;
	Map<String, PartyPersonExtXrefType> partyPersonMap;
	Map<String, PartyOrgExtXrefType> partyOrgMap;
	/** Modified for M4M START */
	//Map<String, PartyRelationshipXrefType> partyRelMap;
	Map<String, PartyAccountRelationshipXrefType> partyRelMap;
	/** Modified for M4M END */
	Map<String, XREFType> xrefMap;
	
	
	public SearchedXrefRecordCollection() {
		addressMap = new HashMap<String, AddressXrefType>();
		accountMap = new HashMap<String, AccountXrefType>();
		commMap = new HashMap<String, CommunicationXrefType>();
		classMap = new HashMap<String, ClassificationXrefType>();
		partyPersonXrefMap = new HashMap<String, PartyPersonXrefType>();
		partyPersonMap = new  HashMap<String, PartyPersonExtXrefType> ();
		partyOrgMap = new  HashMap<String, PartyOrgExtXrefType> ();
		/** Modified for M4M START */
		//partyRelMap = new  HashMap<String, PartyRelationshipXrefType> ();
		partyRelMap = new  HashMap<String, PartyAccountRelationshipXrefType> ();
		/** Modified for M4M END */
		xrefMap = new  HashMap<String, XREFType> ();
	}
	
	
	public String getParty_rowid() {
		return party_rowid;
	}

	public void setParty_rowid(String party_rowid) {
		this.party_rowid = party_rowid;
	}

	public String getOrig_rowid() {
		return orig_rowid;
	}


	public void setOrig_rowid(String orig_rowid) {
		this.orig_rowid = orig_rowid;
	}


	public String getBo_class() {
		return bo_class;
	}

	public void setBo_class(String bo_class) {
		this.bo_class = bo_class;
	}

	public String getParty_type() {
		return party_type;
	}

	public void setParty_type(String party_type) {
		this.party_type = party_type;
	}

	public String getParty_name() {
		return party_name;
	}

	public void setParty_name(String party_name) {
		this.party_name = party_name;
	}

	public String getGeo() {
		return geo;
	}

	public void setGeo(String geo) {
		this.geo = geo;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getStatus_cd() {
		return status_cd;
	}

	public void setStatus_cd(String status_cd) {
		this.status_cd = status_cd;
	}

	public String getVat_regno() {
		return vat_regno;
	}

	public void setVat_regno(String vat_regno) {
		this.vat_regno = vat_regno;
	}

	public String getTax_jd_cd() {
		return tax_jd_cd;
	}

	public void setTax_jd_cd(String tax_jd_cd) {
		this.tax_jd_cd = tax_jd_cd;
	}

	public String getSales_cd() {
		return sales_cd;
	}

	public void setSales_cd(String sales_cd) {
		this.sales_cd = sales_cd;
	}

	public String getUcn() {
		return ucn;
	}

	public void setUcn(String ucn) {
		this.ucn = ucn;
	}

	

	public Map<String, AddressXrefType> getAddressMap() {
		return addressMap;
	}


	public void setAddressMap(Map<String, AddressXrefType> addressMap) {
		this.addressMap = addressMap;
	}


	public Map<String, AccountXrefType> getAccountMap() {
		return accountMap;
	}


	public void setAccountMap(Map<String, AccountXrefType> accountMap) {
		this.accountMap = accountMap;
	}


	public Map<String, CommunicationXrefType> getCommMap() {
		return commMap;
	}


	public void setCommMap(Map<String, CommunicationXrefType> commMap) {
		this.commMap = commMap;
	}


	public Map<String, ClassificationXrefType> getClassMap() {
		return classMap;
	}


	public void setClassMap(Map<String, ClassificationXrefType> classMap) {
		this.classMap = classMap;
	}


	public Map<String, PartyPersonExtXrefType> getPartyPersonMap() {
		return partyPersonMap;
	}


	public void setPartyPersonMap(Map<String, PartyPersonExtXrefType> partyPersonMap) {
		this.partyPersonMap = partyPersonMap;
	}


	public Map<String, PartyOrgExtXrefType> getPartyOrgMap() {
		return partyOrgMap;
	}


	public void setPartyOrgMap(Map<String, PartyOrgExtXrefType> partyOrgMap) {
		this.partyOrgMap = partyOrgMap;
	}

	/** Modified for M4M START */

/*	public Map<String, PartyRelationshipXrefType> getPartyRelMap() {
		return partyRelMap;
	}


	public void setPartyRelMap(Map<String, PartyRelationshipXrefType> partyRelMap) {
		this.partyRelMap = partyRelMap;
	}*/
	
	
	
	public Map<String, PartyAccountRelationshipXrefType> getPartyRelMap() {
		return partyRelMap;
	}


	public void setPartyRelMap(
			Map<String, PartyAccountRelationshipXrefType> partyRelMap) {
		this.partyRelMap = partyRelMap;
	}


	/** Modified for M4M END */


	public Map<String, XREFType> getXrefMap() {
		return xrefMap;
	}

	public void setXrefMap(Map<String, XREFType> xrefMap) {
		this.xrefMap = xrefMap;
	}


	public String getEnglish_name() {
		return english_name;
	}


	public void setEnglish_name(String english_name) {
		this.english_name = english_name;
	}


	public String getLegacyUcn() {
		return legacyUcn;
	}


	public void setLegacyUcn(String legacyUcn) {
		this.legacyUcn = legacyUcn;
	}


	public String getDnbdbaname() {
		return dnbdbaname;
	}


	public void setDnbdbaname(String dnbdbaname) {
		this.dnbdbaname = dnbdbaname;
	}


	public String getDnbsectradestyle() {
		return dnbsectradestyle;
	}


	public void setDnbsectradestyle(String dnbsectradestyle) {
		this.dnbsectradestyle = dnbsectradestyle;
	}


	public String getDnbregname() {
		return dnbregname;
	}


	public void setDnbregname(String dnbregname) {
		this.dnbregname = dnbregname;
	}


	public Map<String, PartyPersonXrefType> getPartyPersonXrefMap() {
		return partyPersonXrefMap;
	}


	public void setPartyPersonXrefMap(
			Map<String, PartyPersonXrefType> partyPersonXrefMap) {
		this.partyPersonXrefMap = partyPersonXrefMap;
	}

	public String getPhysicalGeo() {
		return physicalGeo;
	}


	public void setPhysicalGeo(String physicalGeo) {
		this.physicalGeo = physicalGeo;
	}


	public String getPhysicalRegion() {
		return physicalRegion;
	}


	public void setPhysicalRegion(String physicalRegion) {
		this.physicalRegion = physicalRegion;
	}


	public String getSrcLudDate() {
		return srcLudDate;
	}


	public void setSrcLudDate(String srcLudDate) {
		this.srcLudDate = srcLudDate;
	}


	
	
	
}
