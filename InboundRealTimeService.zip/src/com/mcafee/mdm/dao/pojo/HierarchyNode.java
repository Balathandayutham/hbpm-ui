package com.mcafee.mdm.dao.pojo;

/**
 * Pojo class to hold rowidParty & mfeGlblParentName for GUCN
 * 
 * @author 515189
 * 
 */
public class HierarchyNode {
	String rowidParty;
	String mfeGlblParentName;
	String mfeGlblParentUcn;

	public String getRowidParty() {
		return rowidParty;
	}

	public void setRowidParty(String rowidParty) {
		this.rowidParty = rowidParty;
	}

	public String getMfeGlblParentName() {
		return mfeGlblParentName;
	}

	public void setMfeGlblParentName(String mfeGlblParentName) {
		this.mfeGlblParentName = mfeGlblParentName;
	}

	public String getMfeGlblParentUcn() {
		return mfeGlblParentUcn;
	}

	public void setMfeGlblParentUcn(String mfeGlblParentUcn) {
		this.mfeGlblParentUcn = mfeGlblParentUcn;
	}

}
