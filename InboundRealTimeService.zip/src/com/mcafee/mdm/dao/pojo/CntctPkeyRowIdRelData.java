package com.mcafee.mdm.dao.pojo;

/**
 * Data class to hold Contact Pkey ROWID Relation
 * 
 * @since M4M Project
 * @author MDM Team Cognizant
 */
public class CntctPkeyRowIdRelData {
	
	private String contactPkey;
	private String contactRowId;
	private Boolean isCleansePut = Boolean.FALSE;
	/**
	 * @return the contactPkey
	 */
	public String getContactPkey() {
		return contactPkey;
	}
	/**
	 * @param contactPkey the contactPkey to set
	 */
	public void setContactPkey(String contactPkey) {
		this.contactPkey = contactPkey;
	}
	/**
	 * @return the contactRowId
	 */
	public String getContactRowId() {
		return contactRowId;
	}
	/**
	 * @param contactRowId the contactRowId to set
	 */
	public void setContactRowId(String contactRowId) {
		this.contactRowId = contactRowId;
	}
	/**
	 * @return the isCleansePut
	 */
	public Boolean getIsCleansePut() {
		return isCleansePut;
	}
	/**
	 * @param isCleansePut the isCleansePut to set
	 */
	public void setIsCleansePut(Boolean isCleansePut) {
		this.isCleansePut = isCleansePut;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "CntctPkeyRowIdRelData [ContactPkey()=" + getContactPkey()
				+ ", ContactRowId()=" + getContactRowId()
				+ ", IsCleansePut()=" + getIsCleansePut() + "]";
	}
}
