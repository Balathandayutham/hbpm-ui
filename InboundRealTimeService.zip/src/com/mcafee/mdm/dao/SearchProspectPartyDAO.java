package com.mcafee.mdm.dao;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.Map.Entry;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.mcafee.mdm.constants.Constant;
import com.mcafee.mdm.constants.MDMAttributeNames;
import com.mcafee.mdm.constants.PartyAttributes;
import com.mcafee.mdm.constants.SearchMatchAttributes;
import com.mcafee.mdm.exception.ServiceProcessingException;
import com.mcafee.mdm.generated.AddressXrefType;
import com.mcafee.mdm.generated.PartyXrefType;
import com.mcafee.mdm.util.ObjectPool;
import com.mcafee.mdm.util.Util;
import com.siperian.sif.client.SiperianClient;
import com.siperian.sif.client.SiperianServerException;
import com.siperian.sif.message.Field;
import com.siperian.sif.message.HubStateIndicator;
import com.siperian.sif.message.MatchType;
import com.siperian.sif.message.Record;
import com.siperian.sif.message.SiperianObjectType;
import com.siperian.sif.message.mrm.SearchMatchRequest;
import com.siperian.sif.message.mrm.SearchMatchResponse;

@Component
public class SearchProspectPartyDAO extends ObjectPool {
	private static final Logger LOG = Logger
			.getLogger(SearchProspectPartyDAO.class.getName());

	@Resource(name = "configProp")
	private Properties configProps;

	@Autowired
	ProspectPartyDAO prospectPartyDAO;

	/**
	 * Get RowId(s) from XRef table and match them
	 * 
	 * @param partyXrefType
	 * @param rowIdParty
	 * @return foundSelfMatch
	 * @throws ServiceProcessingException
	 */
	public Boolean findSelfMatchProspect(PartyXrefType partyXrefType,
			String rowIdParty) throws ServiceProcessingException {
		LOG.debug("[findSelfMatchProspect] START");
		Boolean foundSelfMatch = Boolean.FALSE;
		if (!Util.isNullOrEmpty(rowIdParty)) {
			StringBuilder criteria = new StringBuilder();
			criteria.append(" HUB_STATE_IND <>"
					+ HubStateIndicator.DELETED.getValue());
			criteria.append(" AND ROWID_OBJECT in ('");
			criteria.append(rowIdParty);
			criteria.append("')");
			Set<String> matchedRowIds = matchProspectAccount(partyXrefType,
					criteria.toString());
			foundSelfMatch = !CollectionUtils.isEmpty(matchedRowIds);
		}
		LOG.debug("[findSelfMatchProspect] EXIT::foundSelfMatch::"
				+ foundSelfMatch);
		return foundSelfMatch;
	}

	public Set<String> findStrictMatchProspect(PartyXrefType partyXrefType,
			String rowIdParty) throws ServiceProcessingException {
		LOG.debug("[findStrictMatchProspect] START");
		Set<String> matchedRowIdSet = null;
		try	{
			if (!Util.isNullOrEmpty(rowIdParty)) {
				StringBuilder criteria = new StringBuilder();
				criteria.append(" HUB_STATE_IND <>"
						+ HubStateIndicator.DELETED.getValue());
				criteria.append(" AND ROWID_OBJECT <> '");
				criteria.append(rowIdParty);
				criteria.append("'");
				criteria.append(" AND party_type='Prospect Customer'");
				matchedRowIdSet = matchProspectAccount(partyXrefType,
						criteria.toString());
			}
		} catch (SiperianServerException sifExcp) {
			LOG.error("SiperianServerException occured in findStrictMatchProspect: " , sifExcp);
			ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
			customException.setMessage("SIF exception occured findStrictMatchProspect. " + customException.getMessage());
			throw customException;
		} catch (Exception ex) {
			LOG.error("Exception occured in findStrictMatchProspect: " , ex);
			ServiceProcessingException customException = new ServiceProcessingException(ex);
			customException.setMessage("Failed to process findStrictMatchProspect. " + customException.getMessage());
			throw customException;
		}
		LOG.debug("[findStrictMatchProspect] EXIT::foundStrictMatch::"
				+ matchedRowIdSet);
		return matchedRowIdSet;
	}
	
	public Set<String> matchProspectAccount(PartyXrefType partyXrefType,
			String criteria) throws ServiceProcessingException {
		LOG.debug("[matchProspectAccount] START");
		List<AddressXrefType> addressXrefTypeList = partyXrefType.getAddress();
		Set<String> matchedRowIdSet = null;
		SiperianClient siperianClient = null;
		SearchMatchRequest searchMatchRequest = new SearchMatchRequest();
		List<Record> searchRecords = null;
		String srcSystem = null;
		if(partyXrefType != null && partyXrefType.getXREF() != null){
			srcSystem = partyXrefType.getXREF().get(0).getSRCSYSTEM();
		}
		searchMatchRequest.setRecordsToReturn(Integer.parseInt(configProps
				.getProperty(Constant.FUZZY_SEARCH_DFLT_REC_THRES_COUNT_PROP)));
		searchMatchRequest.setSiperianObjectUid(MDMAttributeNames.PARTY_BO);
		if("ADB".equalsIgnoreCase(srcSystem)){
			searchMatchRequest.setMatchRuleSetUid(SiperianObjectType.MATCH_RULE_SET
					.makeUid(configProps
							.getProperty("matchRuleSetCustomer")));
			Field ucnField_name = new Field("Ex_UCN");
			LOG.info("inserted ucn : " + partyXrefType.getUCN());
			if (!Util.isNullOrEmpty(partyXrefType.getUCN())) {
				ucnField_name.setStringValue(partyXrefType.getUCN());
				LOG.info("Field to search for :" + ucnField_name.getName() + ':' + ucnField_name.getStringValue());
				searchMatchRequest.addMatchColumnField(ucnField_name);
			}
		}else{
			searchMatchRequest.setMatchRuleSetUid(SiperianObjectType.MATCH_RULE_SET
				.makeUid(configProps
						.getProperty(Constant.MATCH_RULE_SET_PROPECT_ACCOUNT)));
		}
		searchMatchRequest.setMatchType(MatchType.BOTH);
		createSearchField(searchMatchRequest,
				SearchMatchAttributes.EX_ORGANIZATION_NAME,
				partyXrefType.getPARTYNAME());
		createSearchField(searchMatchRequest,
				SearchMatchAttributes.ORGANIZATION_NAME,
				partyXrefType.getPARTYNAME());
		createSearchField(searchMatchRequest,
				SearchMatchAttributes.EX_ENTITY_TYPE,
				Constant.BO_CLASS_CODE_ORG);
		createSearchField(searchMatchRequest,
				SearchMatchAttributes.EX_PARTY_TYPE,
				Constant.PARTY_TYPE_PROSPECT_ACCOUNT);

		LOG.debug("[matchProspectAccount]Filter Criteria: " + criteria);

		if (!Util.isNullOrEmpty(criteria)) {
			searchMatchRequest.setFilterCriteria(criteria.toString());
		}

		for (AddressXrefType addressXrefType : addressXrefTypeList) {
			StringBuilder addrLn1Ln2Concat = new StringBuilder();
			if (!Util.isNullOrEmpty(addressXrefType.getADDRLN1())) {
				addrLn1Ln2Concat.append(addressXrefType.getADDRLN1());
			}
			if (!Util.isNullOrEmpty(addressXrefType.getADDRLN2())) {
				addrLn1Ln2Concat.append(Constant.STR_SPACE);
				addrLn1Ln2Concat.append(addressXrefType.getADDRLN2());
			}
			// Setting Address_Part2
			StringBuilder addrCityStateCountryConcat = new StringBuilder();
			if (!(Util.isNullOrEmpty(addressXrefType.getCITY()) || Constant.STR_UNKNOWN
					.equalsIgnoreCase(addressXrefType.getCITY()))) {
				addrCityStateCountryConcat.append(addressXrefType.getCITY());
			}
			if (!Util.isNullOrEmpty(addressXrefType.getSTATECD())) {
				addrCityStateCountryConcat.append(" ");
				addrCityStateCountryConcat.append(addressXrefType.getSTATECD());
			}

			if (!Util.isNullOrEmpty(addressXrefType.getCOUNTRYCD())) {
				addrCityStateCountryConcat.append(" ");
				addrCityStateCountryConcat.append(addressXrefType
						.getCOUNTRYCD());
			}
			createSearchField(searchMatchRequest,
					SearchMatchAttributes.EX_ADDRESS_LN1,
					addressXrefType.getADDRLN1());
			createSearchField(searchMatchRequest,
					SearchMatchAttributes.EX_ADDRESS_LN2,
					addressXrefType.getADDRLN2());
			createSearchField(searchMatchRequest,
					SearchMatchAttributes.EX_ADDRESS_TYPE,
					Constant.ADDRESS_TYPE_MAILING);
			if("ADB".equalsIgnoreCase(srcSystem)){
				createSearchField(searchMatchRequest,
						SearchMatchAttributes.EX_ADDR_PART1,
						addrLn1Ln2Concat.toString()+Constant.STR_SPACE);
				LOG.info("ADDRESS PART1 " + addrLn1Ln2Concat);
			}else{
				createSearchField(searchMatchRequest,
					SearchMatchAttributes.EX_ADDR_PART1,
					addrLn1Ln2Concat.toString());
			}
			createSearchField(searchMatchRequest,
					SearchMatchAttributes.ADDR_PART1,
					addrLn1Ln2Concat.toString());
			createSearchField(searchMatchRequest,
					SearchMatchAttributes.ADDR_PART2,
					addrCityStateCountryConcat.toString());
			createSearchField(searchMatchRequest,
					SearchMatchAttributes.EX_CITY, addressXrefType.getCITY());
			createSearchField(searchMatchRequest,
					SearchMatchAttributes.EX_COUNTRY_CD,
					addressXrefType.getCOUNTRYCD());
			createSearchField(searchMatchRequest,
					SearchMatchAttributes.EX_STATE,
					addressXrefType.getSTATECD());
			createSearchField(searchMatchRequest, PartyAttributes.SIP_POP,
					prospectPartyDAO.getSipPopCountry(addressXrefType
							.getCOUNTRYCD()));
			try {
				siperianClient = (SiperianClient) checkOut();
				LOG.debug("[matchProspectAccount]processing SearchMatchRequest::"
						+ searchMatchRequest.getMatchRuleSetUid()
						+ "::"
						+ searchMatchRequest.getMatchColumnFields());
				SearchMatchResponse searchMatchResponse = (SearchMatchResponse) siperianClient
						.process(searchMatchRequest);
				LOG.debug("[matchProspectAccount]after response");
				if (searchMatchResponse != null
						&& !CollectionUtils.isEmpty(searchMatchResponse
								.getRecords())) {
					if (CollectionUtils.isEmpty(searchRecords)) {
						searchRecords = searchMatchResponse.getRecords();
					} else {
						searchRecords.addAll(searchMatchResponse.getRecords());
					}
					LOG.info("================================================================================================");
					for(int i =0 ; i< searchRecords.size();i++){
						Record record = (Record) searchRecords.get(i);
						record.getFields();
						Collection<String> fields = record.getFields();
						Iterator iterator = fields.iterator();
						 
				        // while loop
				        while (iterator.hasNext()) {
				        Field f = (Field)iterator.next();
				        if(f.getName().equals("BO_CLASS_CODE"))
				        	LOG.info("feild name : " + f.getName() + "feild value :" + f.getValue()+":");
				        else if(f.getName().equals("PARTY_TYPE"))
				        	LOG.info("feild name : " + f.getName() + "feild value :" + f.getValue()+":");
				        else if(f.getName().equals("PARTY_NAME"))
				        	LOG.info("feild name : " + f.getName() + "feild value :" + f.getValue()+":");
				        else if(f.getName().equals("ADDR_LN1"))
				        	LOG.info("feild name : " + f.getName() + "feild value :" + f.getValue()+":");
				        else if(f.getName().equals("ADDR_LN2"))
				        	LOG.info("feild name : " + f.getName() + "feild value :" + f.getValue()+":");
				        else if(f.getName().equals("CITY"))
				        	LOG.info("feild name : " + f.getName() + "feild value :" + f.getValue()+":");
				        else if(f.getName().equals("STATE_CD"))
				        	LOG.info("feild name : " + f.getName() + "feild value :" + f.getValue()+":");
				        else if(f.getName().equals("COUNTRY_CD"))
				        	LOG.info("feild name : " + f.getName() + "feild value :" + f.getValue()+":");
				        else if(f.getName().equals("ROWID_OBJECT"))
				        	LOG.info("feild name : " + f.getName() + "feild value :" + f.getValue()+":");
				        else if(f.getName().equals("UCN"))
				        	LOG.info("feild name : " + f.getName() + "feild value :" + f.getValue()+":");
				        else if(f.getName().equals("SIP_POP"))
				        	LOG.info("feild name : " + f.getName() + "feild value :" + f.getValue()+":");
				        else if(f.getName().equals("ROWID_ADDRESS"))
				        	LOG.info("feild name : " + f.getName() + "feild value :" + f.getValue()+":");
				        else if(f.getName().equals("RULE_NUMBER"))
				        	LOG.info("feild name : " + f.getName() + "feild value :" + f.getValue()+":");
				        else if(f.getName().equals("RULESET_NAME"))
				        	LOG.info("feild name : " + f.getName() + "feild value :" + f.getValue()+":");
				        else if(f.getName().equals("DEFINITE_MATCH_IND"))
				        	LOG.info("feild name : " + f.getName() + "feild value :" + f.getValue()+":");
				        else if(f.getName().equals("MATCH_SCORE"))
				        	LOG.info("feild name : " + f.getName() + "feild value :" + f.getValue()+":");
				        else if(f.getName().equals("LAST_ROWID_SYSTEM"))
				        	LOG.info("feild name : " + f.getName() + "feild value :" + f.getValue()+":");
				        }
				        LOG.info("================================================================================================"); 
					}
				}
			} catch (SiperianServerException sifExcp) {
				LOG.error(
						"[matchProspectAccount]SiperianServerException occured while processing SearchMatchReques",
						sifExcp);
			} catch (Exception exp) {
				LOG.error(
						"[matchProspectAccount]Exception occured while processing SearchMatchRequest",
						exp);
			} finally {
				if (siperianClient != null) {
					checkIn(siperianClient);
				}
			}
		}
		if (!CollectionUtils.isEmpty(searchRecords)) {
			LOG.debug("[matchProspectAccount]SearchMatchResponse rec cnt="
					+ searchRecords.size());
			matchedRowIdSet = new HashSet<String>();
			if("ADB".equalsIgnoreCase(partyXrefType.getXREF().get(0).getSRCSYSTEM())){
				LOG.debug("Match prospect Account Adobe with no duns");
				List<String> rowIdListWithDuns = new ArrayList<String>();
				List<String> rowIdListWithNoDuns = new ArrayList<String>();
				for (Record record : searchRecords) {
					rowIdListWithNoDuns.add(record
							.getField(MDMAttributeNames.ROWID_OBJECT)
							.getStringValue().trim());
				}
				LOG.debug("ROWID WITH NO DUNS BEFORE REMOVING DUNS :" + rowIdListWithNoDuns.toString());
				rowIdListWithDuns = prospectPartyDAO
						.getRowIdsProspectAccountWithDuns(rowIdListWithNoDuns);
				for(String rowId : rowIdListWithDuns){
					LOG.debug("Rowid with duns: "+rowId);
					if(rowIdListWithNoDuns.contains(rowId.trim())){
						LOG.debug("Removing rowid with duns: "+rowId);
						rowIdListWithNoDuns.remove(rowId.trim());
					}
				}
				List<Record> searchRecordsWithNoDuns = new ArrayList<Record>();
				for(Record record:searchRecords){
					if(rowIdListWithNoDuns.contains(record
						.getField(MDMAttributeNames.ROWID_OBJECT)
						.getStringValue().trim())){
					//	searchRecords.remove(record);
						searchRecordsWithNoDuns.add(record);
					}
				}
				List<String> matchedRowIds = getBestMatchedRecord(searchRecordsWithNoDuns);
				matchedRowIdSet = new HashSet<String>(matchedRowIds);
			}else{
			for (Record record : searchRecords) {
				matchedRowIdSet.add(record
						.getField(MDMAttributeNames.ROWID_OBJECT)
						.getStringValue().trim());
			}
			}
		}
		LOG.debug("[matchProspectAccount]Exit::matchedRowIdSet::"
				+ matchedRowIdSet);
		return matchedRowIdSet;
	}
	
	
	/**
	 * Returns rowid after passing Highest score and Lowest UCN tie breaker logic
	 * @param recordCollection
	 * @return
	 */
	public List<String> getBestMatchedRecord(List<Record> recordCollection){
		List<String> rowIdList = new ArrayList<String>();
		List<String> resultRowIdList = new ArrayList<String>();
		HashMap<String, Integer> matchScoreMap = new HashMap<String, Integer>();
		HashMap<String, Long> ucnRowIdMap = new HashMap<String, Long>();
		HashMap<String, Long> newUcnRowIdMap = new HashMap<String, Long>();
		int matchScoreThreshold = 0;
		String rowId = null;
		Integer mtchValue = null;
		Long ucnValue = null;
		if(recordCollection != null && recordCollection.size() > 0){
			for(Record record: recordCollection){
				String mtchScore = record.getField(SearchMatchAttributes.MATCH_SCORE).getValue().toString().trim();
				String matchRuleNo = record.getField("RULE_NUMBER").getStringValue().trim();
				rowId = record.getField(MDMAttributeNames.ROWID_OBJECT).getStringValue();
				String ucnValueStr = record.getField("UCN").getStringValue();
				LOG.debug("ucn value : " +ucnValueStr+" for rowd object :"+rowId);
				if(!Util.isNullOrEmpty(ucnValueStr)){
				ucnValue = Long.parseLong(ucnValueStr);
				}
				mtchValue = Integer.parseInt(mtchScore);
				if (mtchValue == 0) {
						record.setField(new Field(SearchMatchAttributes.MATCH_SCORE, 100));
						Integer newMatchScore = Integer
								.parseInt(record.getField(SearchMatchAttributes.MATCH_SCORE).getStringValue().trim());
						LOG.debug(" matchScore set to :: " + newMatchScore + " MatchRuleNo::" + matchRuleNo);
						mtchValue = newMatchScore;
				}
				matchScoreThreshold = Integer.parseInt(configProps.getProperty("matchScore-Threshold"));
				if(mtchValue>matchScoreThreshold){
					matchScoreMap.put(rowId, mtchValue);
					if(!Util.isNullOrEmpty(ucnValueStr))
						ucnRowIdMap.put(rowId, ucnValue);
				}
			}
			if(matchScoreMap.size() == 1){
				rowIdList = new ArrayList<String>(matchScoreMap.keySet());
				resultRowIdList = rowIdList;
			}else if(matchScoreMap.size()>1){
				rowIdList = maxMatchScore(matchScoreMap);
				if(rowIdList != null && rowIdList.size()>1){
					for(Entry<String,Long> ucnMap : ucnRowIdMap.entrySet()){
						if(rowIdList.contains(ucnMap.getKey())){
							newUcnRowIdMap.put(ucnMap.getKey(), ucnMap.getValue());
						}
					}
					resultRowIdList = minUCNCustNum(newUcnRowIdMap);	
				}else{
					LOG.info("Single matched  record found. Skipping Lowest UCN tie breaker logic");
						resultRowIdList = rowIdList;
					}
			}else{
				LOG.info("No matched record found with the expected match threshold : " +matchScoreThreshold);
			}
		}else{
			LOG.info("No searched record found using MultiGeoRuleSet for Adobe");
		}
		return resultRowIdList;
	}
	
	
	/**
	 * Checks whether record matches with Existing customer or DNB Singleton Record
	 * @param partyXrefType
	 * @return
	 * @throws ServiceProcessingException
	 */
	public Map<String, List<String>> findMultiGeoMatch(
			PartyXrefType partyXrefType) throws ServiceProcessingException {
		LOG.debug("[findMultiGeoMatch] START");
		
		Map<String, List<String>> rowIdPartyTypeMap = null;
		Map<String, Record> searchRecordPartyMap = null;
		Map<String, Record> rowIdProspectRecordMap = null;
		Map<String, Record> rowIdSingletonDunsRecordMap = null;
		List<String> resultMatchScoreList = null;
		
		try{
			List<Record> searchRecordList = matchAccountMultiGeoTillCity(partyXrefType);
			if (CollectionUtils.isEmpty(searchRecordList)) {
				LOG.debug("[findMultiGeoMatch] No Match found");
			} else {
				LOG.info("SearchRecord size not empty : " + searchRecordList.size());
				searchRecordPartyMap = new HashMap<String, Record>();
				rowIdProspectRecordMap = new HashMap<String, Record>();
				rowIdSingletonDunsRecordMap = new HashMap<String, Record>();
				for (Record searchRecord : searchRecordList) {
					
					Integer currentMatchScore = Integer.parseInt(searchRecord
							.getField(SearchMatchAttributes.MATCH_SCORE)
							.getStringValue().trim());
					// setting match score to 100 when match score=0
					String matchRuleNo = searchRecord.getField("RULE_NUMBER")
							.getStringValue().trim();
					if (currentMatchScore == 0) {
							searchRecord.setField(new Field(
									SearchMatchAttributes.MATCH_SCORE, 100));

							Integer newMatchScore = Integer
									.parseInt(searchRecord
											.getField(
													SearchMatchAttributes.MATCH_SCORE)
											.getStringValue().trim());

							LOG.debug("[findMultiGeoMatch] matchScore set to :: "
									+ newMatchScore
									+" MatchRuleNo::"
									+matchRuleNo);
					}
					String partyType = searchRecord.getField(
							PartyAttributes.PARTY_TYPE).getStringValue();
					String rowId = searchRecord.getField(
							MDMAttributeNames.ROWID_OBJECT).getStringValue();
					if (partyType != null) {
						if (partyType
								.equalsIgnoreCase(Constant.PARTY_TYPE_CUSTOMER)) {
							LOG.info("Matched with customer : " + rowId);
							searchRecordPartyMap.put(rowId, searchRecord);
						} else if (partyType
								.equalsIgnoreCase(Constant.PARTY_TYPE_PROSPECT_ACCOUNT)) {
							LOG.info("Matched with Prospect customer : " + rowId);
							rowIdProspectRecordMap.put(rowId, searchRecord);
						}
					} else { 
						LOG.info("Matched with record null partytype : " + rowId);
						rowIdSingletonDunsRecordMap.put(rowId, searchRecord);
					}
				}
				if (!searchRecordPartyMap.isEmpty()) {
					LOG.info("Finding customer  record with highest matchscore and lowest ucn");
					LOG.info("Number of Customer record found : " + searchRecordPartyMap.size());
					rowIdPartyTypeMap = new HashMap<String, List<String>>();
					List<String> rowIdList = new ArrayList<String>();
					List<Record> custRecords =  new ArrayList<Record>(searchRecordPartyMap.values());
					rowIdList = getBestMatchedRecord(custRecords);
					rowIdPartyTypeMap.put(Constant.CURRENT_ACTIVE_PARTY, rowIdList);
				} else if (!rowIdProspectRecordMap.isEmpty()) {
					LOG.info("Finding Prospect customer with DNB record with highest matchscore and lowest ucn");
					LOG.info("Number of records found : " + rowIdProspectRecordMap.size());
					rowIdPartyTypeMap = new HashMap<String, List<String>>();
					List<String> rowIdList = new ArrayList<String>();
					rowIdList.addAll(rowIdProspectRecordMap.keySet());
					rowIdList = prospectPartyDAO
							.getRowIdsProspectAccountWithDuns(rowIdList);
					if (!CollectionUtils.isEmpty(rowIdList)) {
						if(rowIdList.size()==1){
						rowIdPartyTypeMap.put(
								Constant.CURRENT_SINGLETON_OR_PROSPECT_DUNS_PARTY,
								rowIdList);
						}else{
							Map<String, Record> newRowIdProspectRecordWithDunsMap = new HashMap<String, Record>();
							for(Entry<String,Record> prospectRecord : rowIdProspectRecordMap.entrySet()){
								if(rowIdList.contains(prospectRecord.getKey())){
									newRowIdProspectRecordWithDunsMap.put(prospectRecord.getKey(), prospectRecord.getValue());
								}
							}
							resultMatchScoreList = getBestMatchedRecord(new ArrayList<Record>(newRowIdProspectRecordWithDunsMap.values()));
							rowIdPartyTypeMap.put(
									Constant.CURRENT_SINGLETON_OR_PROSPECT_DUNS_PARTY,
									resultMatchScoreList);
						}
					}
				} else if (!rowIdSingletonDunsRecordMap.isEmpty()) {
					LOG.info("Finding Prospect customer with DNB Singleton record with highest matchscore and lowest ucn");
					LOG.info("Number of records found : " + rowIdSingletonDunsRecordMap.size());
					rowIdPartyTypeMap = new HashMap<String, List<String>>();
					List<String> rowIdList = new ArrayList<String>();
					rowIdList.addAll(rowIdSingletonDunsRecordMap.keySet());
					rowIdList = prospectPartyDAO
							.getRowIdsDnbSingletonAccounts(rowIdList);
					if (!CollectionUtils.isEmpty(rowIdList)) {
						if(rowIdList.size()==1){
							rowIdPartyTypeMap.put(
									Constant.CURRENT_SINGLETON_OR_PROSPECT_DUNS_PARTY,
									rowIdList);
							}else{
								Map<String, Record> newrowIdSingletonDunsRecordMap = new HashMap<String, Record>();
								for(Entry<String,Record> singletonDunsRecord : rowIdProspectRecordMap.entrySet()){
									if(rowIdList.contains(singletonDunsRecord.getKey())){
										newrowIdSingletonDunsRecordMap.put(singletonDunsRecord.getKey(), singletonDunsRecord.getValue());
									}
								}
								resultMatchScoreList = getBestMatchedRecord(new ArrayList<Record>(newrowIdSingletonDunsRecordMap.values()));
								rowIdPartyTypeMap.put(
										Constant.CURRENT_SINGLETON_OR_PROSPECT_DUNS_PARTY,
										resultMatchScoreList);
							}
						}
				}
			}
		} catch (SiperianServerException sifExcp) {
			LOG.error("SiperianServerException occured in findBestMatchedMultiGeoCityOrSingletonDunsAccount: " , sifExcp);
			ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
			customException.setMessage("SIF exception occured findBestMatchedMultiGeoCityOrSingletonDunsAccount. " + customException.getMessage());
			throw customException;
		} catch (Exception ex) {
			LOG.error("Exception occured in findBestMatchedMultiGeoCityOrSingletonDunsAccount: " , ex);
			ServiceProcessingException customException = new ServiceProcessingException(ex);
			customException.setMessage("Failed to process findBestMatchedMultiGeoCityOrSingletonDunsAccount. " + customException.getMessage());
			throw customException;
		}
		LOG.debug("[findMultiGeoMatch] EXIT::rowIdPartyTypeMap::"
				+ rowIdPartyTypeMap);
		return rowIdPartyTypeMap;
	}
	
	// Method to calculate highest/maximum Match Score
	private List<String> maxMatchScore(Map<String, Integer> matchScoreMap) {
		Collection<Integer> collVal = matchScoreMap.values();
		List<Integer> scoreList = new ArrayList<Integer>(collVal);
		List rowidObjs = new ArrayList(); //
		// Collections.sort(scoreList);
		// Object maxScore = scoreList.get(scoreList.size()-1);
		Integer maxScore = Collections.max(scoreList);
		int cnt = 0;
		// for (Iterator itr = scoreList.iterator(); itr.hasNext();) {
		for (Entry entry : matchScoreMap.entrySet()) {
			if (maxScore.equals(entry.getValue())) {
				cnt++;
				rowidObjs.add(entry.getKey());
			}
		}
		LOG.debug("No of records having highest match score " + maxScore + ": " + cnt);
		return rowidObjs;
	}
		
	// Method to calculate Lowest/minimum UCNCustNbr
	private List<String> minUCNCustNum(Map<String, Long> UCNCustNumMap) {
		Collection<Long> collVal = UCNCustNumMap.values();
		List<Long> uCNList = new ArrayList<Long>(collVal);
		List rowidObjs = new ArrayList(); //
		// Collections.sort(scoreList);
		// Object maxScore = scoreList.get(scoreList.size()-1);
		Long minUCN = Collections.min(uCNList);
		LOG.debug("Lowest UCNno: " + minUCN);
		int cnt = 0;
		// for (Iterator itr = scoreList.iterator(); itr.hasNext();) {
		for (Entry entry : UCNCustNumMap.entrySet()) {
			if (minUCN.equals(entry.getValue())) {
				cnt++;
				rowidObjs.add(entry.getKey());
			}
		}
		LOG.debug("No of records having lowest UCNtNo :" + cnt);
		return rowidObjs;
	}
		
	public Map<String, List<String>> findBestMatchedMultiGeoCityOrSingletonDunsAccount(
			PartyXrefType partyXrefType) throws ServiceProcessingException {
		LOG.debug("[findBestMatchedMultiGeoCityOrSingletonDunsAccount] START");
		
		Map<String, List<String>> rowIdPartyTypeMap = null;
		Map<String, Record> searchRecordPartyMap = null;
		Map<String, Record> rowIdProspectRecordMap = null;
		Map<String, Record> rowIdSingletonDunsRecordMap = null;
		
		try{
			List<Record> searchRecordList = matchAccountMultiGeoTillCity(partyXrefType);
			if (CollectionUtils.isEmpty(searchRecordList)) {
				LOG.debug("[findBestMatchedMultiGeoCityOrSingletonDunsAccount] No Match found");
			} else {
				searchRecordPartyMap = new HashMap<String, Record>();
				rowIdProspectRecordMap = new HashMap<String, Record>();
				rowIdSingletonDunsRecordMap = new HashMap<String, Record>();
				for (Record searchRecord : searchRecordList) {
					
					/*
					 * US80 Changes START: set matchScore=100 when matchScore=0
					 * for matchRuleNo 1,2,6&10
					 */
					Integer currentMatchScore = Integer.parseInt(searchRecord
							.getField(SearchMatchAttributes.MATCH_SCORE)
							.getStringValue().trim());
					// setting match score to 100 when match score=0
					String matchRuleNo = searchRecord.getField("RULE_NUMBER")
							.getStringValue().trim();
					if (currentMatchScore == 0) {
						if (matchRuleNo.equalsIgnoreCase("1")
								|| matchRuleNo.equalsIgnoreCase("2")
								|| matchRuleNo.equalsIgnoreCase("6")
								|| matchRuleNo.equalsIgnoreCase("10")) {

							searchRecord.setField(new Field(
									SearchMatchAttributes.MATCH_SCORE, 100));

							Integer newMatchScore = Integer
									.parseInt(searchRecord
											.getField(
													SearchMatchAttributes.MATCH_SCORE)
											.getStringValue().trim());

							LOG.debug("[findBestMatchedMultiGeoCityOrSingletonDunsAccount] matchScore set to :: "
									+ newMatchScore
									+" MatchRuleNo::"
									+matchRuleNo);

						}
					}
					/*
					 * US80 Changes END: set matchScore=100 when matchScore=0
					 * for matchRuleNo 1,2,6&10
					 */
					
					String partyType = searchRecord.getField(
							PartyAttributes.PARTY_TYPE).getStringValue();
					String rowId = searchRecord.getField(
							MDMAttributeNames.ROWID_OBJECT).getStringValue();
					if (partyType != null) {
						if (partyType
								.equalsIgnoreCase(Constant.PARTY_TYPE_CUSTOMER)
								|| partyType
										.equalsIgnoreCase(Constant.PARTY_TYPE_PARTNER)
								|| partyType
										.equalsIgnoreCase(Constant.PARTY_TYPE_RESELLER)
								|| partyType
										.equalsIgnoreCase(Constant.PARTY_TYPE_DISTRIBUTOR)) {
	
							searchRecordPartyMap.put(
									partyType,
									compareAndGetHighestMatchScoreRecord(
											searchRecordPartyMap.get(partyType),
											searchRecord));
						} else if (partyType
								.equalsIgnoreCase(Constant.PARTY_TYPE_PROSPECT_ACCOUNT)) {
							rowIdProspectRecordMap.put(
									rowId,
									compareAndGetHighestMatchScoreRecord(
											rowIdProspectRecordMap.get(partyType),
											searchRecord));
						}
					} else {
						rowIdSingletonDunsRecordMap.put(
								rowId,
								compareAndGetHighestMatchScoreRecord(
										rowIdProspectRecordMap.get(partyType),
										searchRecord));
					}
				}
				if (!searchRecordPartyMap.isEmpty()) {
					rowIdPartyTypeMap = new HashMap<String, List<String>>();
					List<String> rowIdList = new ArrayList<String>();
					for (Record searchRecord : searchRecordPartyMap.values()) {
						if (searchRecord != null) {
							rowIdList.add(searchRecord.getField(
									MDMAttributeNames.ROWID_OBJECT)
									.getStringValue());
						}
					}
					rowIdPartyTypeMap.put(Constant.CURRENT_ACTIVE_PARTY, rowIdList);
				} else if (!rowIdProspectRecordMap.isEmpty()) {
					rowIdPartyTypeMap = new HashMap<String, List<String>>();
					List<String> rowIdList = new ArrayList<String>();
					rowIdList.addAll(rowIdProspectRecordMap.keySet());
					rowIdList = prospectPartyDAO
							.getRowIdsProspectAccountWithDuns(rowIdList);
					if (!CollectionUtils.isEmpty(rowIdList)) {
						rowIdPartyTypeMap.put(
								Constant.CURRENT_SINGLETON_OR_PROSPECT_DUNS_PARTY,
								rowIdList);
					}
				} else if (!rowIdSingletonDunsRecordMap.isEmpty()) {
					rowIdPartyTypeMap = new HashMap<String, List<String>>();
					List<String> rowIdList = new ArrayList<String>();
					rowIdList.addAll(rowIdSingletonDunsRecordMap.keySet());
					rowIdList = prospectPartyDAO
							.getRowIdsDnbSingletonAccounts(rowIdList);
					if (!CollectionUtils.isEmpty(rowIdList)) {
						rowIdPartyTypeMap.put(
								Constant.CURRENT_SINGLETON_OR_PROSPECT_DUNS_PARTY,
								rowIdList);
					}
				}
			}
		} catch (SiperianServerException sifExcp) {
			LOG.error("SiperianServerException occured in findBestMatchedMultiGeoCityOrSingletonDunsAccount: " , sifExcp);
			ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
			customException.setMessage("SIF exception occured findBestMatchedMultiGeoCityOrSingletonDunsAccount. " + customException.getMessage());
			throw customException;
		} catch (Exception ex) {
			LOG.error("Exception occured in findBestMatchedMultiGeoCityOrSingletonDunsAccount: " , ex);
			ServiceProcessingException customException = new ServiceProcessingException(ex);
			customException.setMessage("Failed to process findBestMatchedMultiGeoCityOrSingletonDunsAccount. " + customException.getMessage());
			throw customException;
		}
		LOG.debug("[findBestMatchedMultiGeoCityOrSingletonDunsAccount] EXIT::rowIdPartyTypeMap::"
				+ rowIdPartyTypeMap);
		return rowIdPartyTypeMap;
	}

	public List<Record> matchAccountMultiGeoTillCity(PartyXrefType partyXrefType)
			throws ServiceProcessingException {
		LOG.debug("[matchAccountMultiGeoTillCity] START");
		List<AddressXrefType> addressXrefTypeList = partyXrefType.getAddress();
		String srcSystem = partyXrefType.getXREF().get(0).getSRCSYSTEM();
		Set<String> matchedRowIdSet = null;
		SiperianClient siperianClient = null;
		SearchMatchRequest searchMatchRequest = new SearchMatchRequest();
		List<Record> searchRecords = null;
		searchMatchRequest.setRecordsToReturn(Integer.parseInt(configProps
				.getProperty(Constant.FUZZY_SEARCH_DFLT_REC_THRES_COUNT_PROP)));
		searchMatchRequest.setSiperianObjectUid(MDMAttributeNames.PARTY_BO);
		if("ADB".equalsIgnoreCase(srcSystem)){
			searchMatchRequest
			.setMatchRuleSetUid(SiperianObjectType.MATCH_RULE_SET.makeUid(configProps
					.getProperty(Constant.MATCH_RULE_SET_ADOBE_MULTI_GEO_TILL_CITY)));
		}else{
			searchMatchRequest
			.setMatchRuleSetUid(SiperianObjectType.MATCH_RULE_SET.makeUid(configProps
					.getProperty(Constant.MATCH_RULE_SET_MULTI_GEO_TILL_CITY)));
		}
		searchMatchRequest.setMatchType(MatchType.BOTH);
		createSearchField(searchMatchRequest,
				SearchMatchAttributes.ORGANIZATION_NAME,
				partyXrefType.getPARTYNAME());
		createSearchField(searchMatchRequest,
				SearchMatchAttributes.EX_ORGANIZATION_NAME,
				partyXrefType.getPARTYNAME());
		createSearchField(searchMatchRequest,
				SearchMatchAttributes.EX_ENTITY_TYPE,
				Constant.BO_CLASS_CODE_ORG);

		StringBuffer criteria = new StringBuffer();
		criteria.append(" HUB_STATE_IND <>"
				+ HubStateIndicator.DELETED.getValue());
		//commented as per Venkat's review - ODOM-2443
		//Changes for MDMP-3489
		criteria.append("AND CONSOLIDATION_IND <> 9" +" AND " + PartyAttributes.STATUS_CD + " = 'A' " );
		criteria.append(" AND " + Constant.STR_OPEN_BRACKET
				+ PartyAttributes.PARTY_TYPE + " IS NULL OR "
				+ PartyAttributes.PARTY_TYPE + " IN" + Constant.STR_SPACE
				+ Constant.STR_OPEN_BRACKET + Constant.STR_SINGLE_QUOTE
				+ Constant.PARTY_TYPE_CUSTOMER + Constant.STR_SINGLE_QUOTE
				+ Constant.STR_COMMA + Constant.STR_SINGLE_QUOTE
				+ Constant.PARTY_TYPE_PROSPECT_ACCOUNT
				+ Constant.STR_SINGLE_QUOTE + Constant.STR_CLOSE_BRACKET
				+ Constant.STR_CLOSE_BRACKET);

		LOG.debug("[matchAccountMultiGeoTillCity]Filter Criteria: "
				+ criteria.toString());

		searchMatchRequest.setFilterCriteria(criteria.toString());

		for (AddressXrefType addressXrefType : addressXrefTypeList) {
			StringBuilder addrLn1Ln2Concat = new StringBuilder();
			if (!Util.isNullOrEmpty(addressXrefType.getADDRLN1())) {
				addrLn1Ln2Concat.append(addressXrefType.getADDRLN1());
			}
			if (!Util.isNullOrEmpty(addressXrefType.getADDRLN2())) {
				addrLn1Ln2Concat.append(Constant.STR_SPACE);
				addrLn1Ln2Concat.append(addressXrefType.getADDRLN2());
			}
			// Setting Address_Part2
			StringBuilder addrCityStateCountryConcat = new StringBuilder();
			if (!(Util.isNullOrEmpty(addressXrefType.getCITY()) || Constant.STR_UNKNOWN
					.equalsIgnoreCase(addressXrefType.getCITY()))) {
				addrCityStateCountryConcat.append(addressXrefType.getCITY());
			}
			if (!Util.isNullOrEmpty(addressXrefType.getSTATECD())) {
				addrCityStateCountryConcat.append(" ");
				addrCityStateCountryConcat.append(addressXrefType.getSTATECD());
			}

			if (!Util.isNullOrEmpty(addressXrefType.getCOUNTRYCD())) {
				addrCityStateCountryConcat.append(" ");
				addrCityStateCountryConcat.append(addressXrefType
						.getCOUNTRYCD());
			}

			createSearchField(searchMatchRequest,
					SearchMatchAttributes.EX_ADDRESS_LN1,
					addressXrefType.getADDRLN1());
			createSearchField(searchMatchRequest,
					SearchMatchAttributes.EX_ADDRESS_LN2,
					addressXrefType.getADDRLN2());
			createSearchField(searchMatchRequest,
					SearchMatchAttributes.ADDR_PART1,
					addrLn1Ln2Concat.toString());
			createSearchField(searchMatchRequest,
					SearchMatchAttributes.EX_ADDR_PART1,
					addrLn1Ln2Concat.toString());
			createSearchField(searchMatchRequest,
					SearchMatchAttributes.ADDR_PART2,
					addrCityStateCountryConcat.toString());
			createSearchField(searchMatchRequest,
					SearchMatchAttributes.EX_CITY, addressXrefType.getCITY());
			createSearchField(searchMatchRequest,
					SearchMatchAttributes.EX_COUNTRY_CD,
					addressXrefType.getCOUNTRYCD());
			createSearchField(searchMatchRequest, PartyAttributes.SIP_POP,
					prospectPartyDAO.getSipPopCountry(addressXrefType
							.getCOUNTRYCD()));
			createSearchField(searchMatchRequest,
					SearchMatchAttributes.EX_STATE,
					addressXrefType.getSTATECD());
			try {
				siperianClient = (SiperianClient) checkOut();
				LOG.debug("[matchAccountMultiGeoTillCity]processing SearchMatchRequest::"
						+ searchMatchRequest.getMatchRuleSetUid()
						+ "::"
						+ searchMatchRequest.getMatchColumnFields());
				SearchMatchResponse searchMatchResponse = (SearchMatchResponse) siperianClient
						.process(searchMatchRequest);
				LOG.debug("[matchAccountMultiGeoTillCity]after response");
				if (searchMatchResponse != null
						&& !CollectionUtils.isEmpty(searchMatchResponse
								.getRecords())) {
					if (CollectionUtils.isEmpty(searchRecords)) {
						searchRecords = searchMatchResponse.getRecords();
					} else {
						searchRecords.addAll(searchMatchResponse.getRecords());
					}
					LOG.info("================================================================================================");
					for(int i =0 ; i< searchRecords.size();i++){
						Record record = (Record) searchRecords.get(i);
						record.getFields();
						Collection<String> fields = record.getFields();
						Iterator iterator = fields.iterator();
						 
				        // while loop
				        while (iterator.hasNext()) {
				        Field f = (Field)iterator.next();
				        if(f.getName().equals("BO_CLASS_CODE"))
				        	LOG.info("feild name : " + f.getName() + "feild value :" + f.getValue()+":");
				        else if(f.getName().equals("PARTY_TYPE"))
				        	LOG.info("feild name : " + f.getName() + "feild value :" + f.getValue()+":");
				        else if(f.getName().equals("PARTY_NAME"))
				        	LOG.info("feild name : " + f.getName() + "feild value :" + f.getValue()+":");
				        else if(f.getName().equals("ADDR_LN1"))
				        	LOG.info("feild name : " + f.getName() + "feild value :" + f.getValue()+":");
				        else if(f.getName().equals("ADDR_LN2"))
				        	LOG.info("feild name : " + f.getName() + "feild value :" + f.getValue()+":");
				        else if(f.getName().equals("CITY"))
				        	LOG.info("feild name : " + f.getName() + "feild value :" + f.getValue()+":");
				        else if(f.getName().equals("STATE_CD"))
				        	LOG.info("feild name : " + f.getName() + "feild value :" + f.getValue()+":");
				        else if(f.getName().equals("COUNTRY_CD"))
				        	LOG.info("feild name : " + f.getName() + "feild value :" + f.getValue()+":");
				        else if(f.getName().equals("ROWID_OBJECT"))
				        	LOG.info("feild name : " + f.getName() + "feild value :" + f.getValue()+":");
				        else if(f.getName().equals("UCN"))
				        	LOG.info("feild name : " + f.getName() + "feild value :" + f.getValue()+":");
				        else if(f.getName().equals("SIP_POP"))
				        	LOG.info("feild name : " + f.getName() + "feild value :" + f.getValue()+":");
				        else if(f.getName().equals("ROWID_ADDRESS"))
				        	LOG.info("feild name : " + f.getName() + "feild value :" + f.getValue()+":");
				        else if(f.getName().equals("RULE_NUMBER"))
				        	LOG.info("feild name : " + f.getName() + "feild value :" + f.getValue()+":");
				        else if(f.getName().equals("RULESET_NAME"))
				        	LOG.info("feild name : " + f.getName() + "feild value :" + f.getValue()+":");
				        else if(f.getName().equals("DEFINITE_MATCH_IND"))
				        	LOG.info("feild name : " + f.getName() + "feild value :" + f.getValue()+":");
				        else if(f.getName().equals("MATCH_SCORE"))
				        	LOG.info("feild name : " + f.getName() + "feild value :" + f.getValue()+":");
				        else if(f.getName().equals("LAST_ROWID_SYSTEM"))
				        	LOG.info("feild name : " + f.getName() + "feild value :" + f.getValue()+":");
				        }
				        LOG.info("================================================================================================"); 
					}
				}
			} catch (SiperianServerException sifExcp) {
				LOG.error(
						"[matchAccountMultiGeoTillCity]SiperianServerException occured while processing SearchMatchRequest",
						sifExcp);
			} catch (Exception exp) {
				LOG.error(
						"[matchAccountMultiGeoTillCity]Exception occured while processing SearchMatchRequest",
						exp);
			} finally {
				checkIn(siperianClient);
			}
		}
		LOG.debug("[matchAccountMultiGeoTillCity]Exit::searchRecords::"
				+ searchRecords);
		return searchRecords;
	}

	/**
	 * Create and Add field to search match request
	 * 
	 * @param searchMatchRequest
	 * @param fieldName
	 * @param fieldValue
	 */
	private void createSearchField(SearchMatchRequest searchMatchRequest,
			String fieldName, Object fieldValue) {
		LOG.debug("[createSearchField]ENTER::fieldName::" + fieldName
				+ "::fieldValue::" + fieldValue);
		Field field = null;
		if (!Util.isNullOrEmpty(fieldName)) {
			field = new Field(fieldName);
			field.setValue(fieldValue);
		}
		if (field != null) {
			searchMatchRequest.addMatchColumnField(field);
			LOG.debug("[createSearchField]Added Field::" + field.getName()
					+ "::" + field.getStringValue());
		}
		LOG.debug("[createSearchField]EXIT");
	}

	private Record compareAndGetHighestMatchScoreRecord(Record existingRecord,
			Record newRecord) {
		LOG.debug("[compareAndGetHighestMatchScoreRecord]ENTER");
		Record recordToReturn = existingRecord;
		if (recordToReturn == null
				|| recordToReturn.getField(SearchMatchAttributes.MATCH_SCORE) == null
				|| Util.isNullOrEmpty(recordToReturn.getField(
						SearchMatchAttributes.MATCH_SCORE).getStringValue())) {
			recordToReturn = newRecord;
		} else {
			Integer existingMatchScore = Integer.parseInt(recordToReturn
					.getField(SearchMatchAttributes.MATCH_SCORE)
					.getStringValue().trim());
			Integer newMatchScore = null;
			if (newRecord == null
					|| newRecord.getField(SearchMatchAttributes.MATCH_SCORE) == null
					|| Util.isNullOrEmpty(newRecord.getField(
							SearchMatchAttributes.MATCH_SCORE).getStringValue())) {
				LOG.debug("[compareAndGetHighestMatchScoreRecord]No New match Score found");
			} else {
				newMatchScore = Integer.parseInt(newRecord
						.getField(SearchMatchAttributes.MATCH_SCORE)
						.getStringValue().trim());
				LOG.debug("[compareAndGetHighestMatchScoreRecord]existingMatchScore::"
						+ existingMatchScore
						+ "; newMatchScore::"
						+ newMatchScore);
				if (newMatchScore != null) {
					if (newMatchScore > existingMatchScore) {
						recordToReturn = newRecord;
					} else if (newMatchScore == existingMatchScore) {
						recordToReturn = compareAndGetOlderMatchScoreRecord(
								existingRecord, newRecord);
					}
				}
			}
		}
		LOG.debug("[compareAndGetHighestMatchScoreRecord]EXIT");
		return recordToReturn;
	}

	private Record compareAndGetOlderMatchScoreRecord(Record existingRecord,
			Record newRecord) {
		LOG.debug("[compareAndGetOlderMatchScoreRecord]ENTER");
		Record recordToReturn = null;
		if (existingRecord.getField(SearchMatchAttributes.CREATE_DATE) == null
				|| existingRecord.getField(SearchMatchAttributes.CREATE_DATE)
						.getDateValue() == null
				|| newRecord.getField(SearchMatchAttributes.CREATE_DATE) == null
				|| newRecord.getField(SearchMatchAttributes.CREATE_DATE)
						.getDateValue() == null) {
			Integer rowIdExisting = Integer.getInteger(existingRecord.getField(
					MDMAttributeNames.ROWID_OBJECT).getStringValue());
			Integer rowIdNew = Integer.getInteger(newRecord.getField(
					MDMAttributeNames.ROWID_OBJECT).getStringValue());
			if (rowIdNew > rowIdExisting) {
				recordToReturn = newRecord;
			} else {
				recordToReturn = existingRecord;
			}
		} else {
			Date createDateExisting = existingRecord.getField(
					SearchMatchAttributes.CREATE_DATE).getDateValue();
			Date createDateNew = newRecord.getField(
					SearchMatchAttributes.CREATE_DATE).getDateValue();
			if (createDateNew.before(createDateExisting)) {
				recordToReturn = newRecord;
			} else {
				recordToReturn = existingRecord;
			}
		}
		LOG.debug("[compareAndGetHighestMatchScoreRecord]EXIT");
		return recordToReturn;
	}

	
}
