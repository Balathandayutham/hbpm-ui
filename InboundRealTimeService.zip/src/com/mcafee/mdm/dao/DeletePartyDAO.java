package com.mcafee.mdm.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import javax.transaction.SystemException;
import javax.transaction.UserTransaction;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.mcafee.mdm.constants.AccountAttributes;
import com.mcafee.mdm.constants.AddressAttributes;
import com.mcafee.mdm.constants.ClassificationAttributes;
import com.mcafee.mdm.constants.CommunicationAttributes;
import com.mcafee.mdm.constants.Constant;
import com.mcafee.mdm.constants.MDMAttributeNames;
import com.mcafee.mdm.constants.PartyAttributes;
import com.mcafee.mdm.dao.pojo.PutResponseDataHolder;
import com.mcafee.mdm.exception.ServiceProcessingException;
import com.mcafee.mdm.generated.AccountXrefType;
import com.mcafee.mdm.generated.AddressXrefType;
import com.mcafee.mdm.generated.ClassificationXrefType;
import com.mcafee.mdm.generated.CommunicationXrefType;
import com.mcafee.mdm.generated.DeletePartyRequest;
import com.mcafee.mdm.generated.DeletePartyResponse;
import com.mcafee.mdm.generated.DeleteRecordType;
import com.mcafee.mdm.generated.PartyXrefType;
import com.mcafee.mdm.util.JDBCConnectionProvider;
import com.mcafee.mdm.util.ObjectPool;
import com.mcafee.mdm.util.Util;
import com.siperian.sif.client.EjbSiperianClient;
import com.siperian.sif.client.SiperianClient;
import com.siperian.sif.client.SiperianServerException;
import com.siperian.sif.message.Field;
import com.siperian.sif.message.Record;
import com.siperian.sif.message.RecordKey;
import com.siperian.sif.message.SiperianObjectType;
import com.siperian.sif.message.TaskData;
import com.siperian.sif.message.TaskRecord;
import com.siperian.sif.message.mrm.CreateTaskRequest;
import com.siperian.sif.message.mrm.CreateTaskResponse;
import com.siperian.sif.message.mrm.PutRequest;
import com.siperian.sif.message.mrm.PutResponse;

@Component
public class DeletePartyDAO extends ObjectPool {
	
	private static final Logger LOG = Logger.getLogger(DeletePartyDAO.class.getName());
	private Properties configProps = null;
	JDBCConnectionProvider jdbcConnProvider = null;
	Date currDBSysDate = null;
	
	@Autowired
	GetPartyDAO getPartyDAO;
	
	public static void main(String[] args) {
		LOG.info("====================Running DeletePartyDAO from main()=========================");
		
		DeletePartyDAO deletePartyDAO = new DeletePartyDAO();
		DeletePartyRequest delRequest = new DeletePartyRequest();
		delRequest.setBatchID("223"); //851351
		delRequest.setErrorMsg("");
		
		List<DeleteRecordType> delRecTypeList = new ArrayList<DeleteRecordType>();
		/*
		DeleteRecordType delRecType = new DeleteRecordType();
		delRecType.setSRCSYSTEM("SBL");
		delRecType.setSRCSYSTEMID("3-E7F4Q9");
		delRecType.setStatus("Success");
		delRecTypeList.add(delRecType);*/
		delRequest.getDeleteRecord().addAll(delRecTypeList);
		
		Util.printObjectTreeInXML(DeletePartyRequest.class, delRequest);

		DeletePartyResponse delResponse = deletePartyDAO.processDeletePartyRequest(delRequest);
		
		//String mergeFlagUpdtStatus = deletePartyDAO.updateMergePersistentRec(recToDelList);
		
		Util.printObjectTreeInXML(DeletePartyResponse.class, delResponse);
		LOG.info("====================Ends DeletePartyDAO from main()=========================");
	} 
 
	public DeletePartyResponse processDeletePartyRequest(DeletePartyRequest delRequest) {
		LOG.info("Executing processDeletePartyRequest()");
		
		DeletePartyResponse delResponse = new DeletePartyResponse();
		String batchId = delRequest.getBatchID();
		LOG.info("Batch ID in request = " + batchId);
		
		if (!Util.isNullOrEmpty(delRequest.getErrorMsg())) {
			LOG.info("Request contains error, unable to process the request.");
			delResponse.setBatchID(batchId);
			delResponse.setStatus("No action taken");
			delResponse.setErrorMsg("The request contains error, unable to process.");
			return delResponse;
		} else if (Util.isNullOrEmpty(batchId) && 
					(delRequest.getDeleteRecord() == null || delRequest.getDeleteRecord().size() == 0)) {
			LOG.info("Request contains no batch id or record keys, unable to process the request.");
			delResponse.setBatchID(batchId);
			delResponse.setStatus("No action taken");
			delResponse.setErrorMsg("Request contains no batch id or record to delete, unable to process.");
			return delResponse;
		}
		
		SiperianClient siperianClient = null;
		boolean delPutOprSuccess = false;
		StringBuilder successMsgBuilder = new StringBuilder();
		StringBuilder errorMsgBuilder = new StringBuilder();
		
		List<DeleteRecordType> recToDelList = null;
		
		try {
			jdbcConnProvider = JDBCConnectionProvider.getSingleInstance();
			
			//if only batch id provided in request, process all records corresponding to the batch id,
			//and if any record keys provided work with those records only
			if (!Util.isNullOrEmpty(batchId) && 
					(delRequest.getDeleteRecord() == null || delRequest.getDeleteRecord().size() == 0) ||
					Util.isNullOrEmpty(delRequest.getDeleteRecord().get(0).getSRCSYSTEMID())) {
				LOG.info("Fetch all records corresponding to the batch id provided");
				recToDelList = getRecordsForBatchId(batchId);
				
				if (recToDelList.size() == 0) {
					LOG.info("No deletable record found against the batch id provided.");
					delResponse.setBatchID(batchId);
					delResponse.setStatus("No deletable record found against the batch id provided.");
					return delResponse;
				}
			} else {
				LOG.info("To use party records provided instead of batch id");
				recToDelList =  delRequest.getDeleteRecord();
			}
			
			List<PartyXrefType> partyXrefList = new ArrayList<PartyXrefType>();
			
			//fetch all party and child xref records 
			LOG.info("To get party and child xref. Number of party to fetch = " + recToDelList.size());
			for (DeleteRecordType recType : recToDelList) {
				/**US70-Sprint#6 **/
		//		if(!Util.isNullOrEmpty(recType.getSRCSYSTEM()) && (recType.getSRCSYSTEM().equalsIgnoreCase("SAP") 
		//				|| recType.getSRCSYSTEM().equalsIgnoreCase("SBL")) ){
				
				String srcSystem = recType.getSRCSYSTEM();
				String srcPkey = recType.getSRCSYSTEMID();
				
				if("ADB".equalsIgnoreCase(srcSystem)){
					if(!Util.isNullOrEmpty(srcPkey) && !srcPkey.contains(Constant.ADB_ACT_PREFIX)){
						srcPkey = Constant.ADB_ACT_PREFIX+srcPkey;
					}
				}
					partyXrefList.add(getPartyDAO.fetchPartyXrefTypeFromORS(srcSystem, srcPkey, false));
		//		}else {
					LOG.debug("ROWID_SYSTEM is not SAP/SBL: "+ recType.getSRCSYSTEM());
		//			return delResponse;
		//		}
			}
			LOG.info("Number of party xref fetched = " + partyXrefList.size());
			
			if (partyXrefList.size() == 0) {
				String msg = "No party record found for the batch id in the MERGE_REC_CONTROL_TABLE";
				throw new ServiceProcessingException(msg);
			}
			
			//create Siperian client
			siperianClient = (SiperianClient) checkOut();
			
			//Update status of party and all child to 'M' for each party 
			LOG.info("Started updating status of party and child");
			for (PartyXrefType partyXref : partyXrefList) {
				String successStatus = processUpdateRequest(partyXref, siperianClient);
				successMsgBuilder.append(successStatus);
				successMsgBuilder.append(".\n");
			}
			delPutOprSuccess = true;
			LOG.info("Completed updating status of party and child");

		} catch(ServiceProcessingException spExcp)	{
			LOG.error("ServiceProcessingException: ", spExcp);
			errorMsgBuilder.append(spExcp.getMessage());
		} catch(Exception excp)	{
			LOG.error("Exception occurred on DeleteParty request processing: ", excp);
			errorMsgBuilder.append("Exception occurred on fetching record for batch id and updating party status: " + excp.toString());
		} finally {
			if (siperianClient != null) {
				checkIn(siperianClient);
			}
		}
		
		String mergeFlagUpdtStatus = null;
		//Update merge completion flag for orchestration completion
		if (delPutOprSuccess) {
			LOG.info("Calling Merge status flag update process");
			try {
				mergeFlagUpdtStatus = updateMergePersistentRec(recToDelList);
				successMsgBuilder.append(mergeFlagUpdtStatus);
			} catch(ServiceProcessingException spExcp)	{
				//As Put successful for Merge status update, don't set error msg,
				//rather set status msg with merge completion flag update failure and task generation msg 
				successMsgBuilder.append(spExcp.getMessage());
			}
		} else {
			successMsgBuilder.append("Merge status update operation not completed, merge flag update not performed");
			LOG.info("Party status update operation failed, bypassing Merge status flag update");
		}
		
		delResponse.setBatchID(batchId);
		delResponse.setErrorMsg(errorMsgBuilder.toString());
		delResponse.setStatus(successMsgBuilder.toString());
		
		LOG.info("Executed processDeletePartyRequest()");
		return delResponse;
	}
	
	private List<DeleteRecordType> getRecordsForBatchId(String batchId) throws ServiceProcessingException {
		LOG.info("Executing getRecordsForBatchId()");
		
		List<DeleteRecordType> recToDelList = new ArrayList<DeleteRecordType>();
		Connection jdbcConn = null;
		Statement statement = null;
		ResultSet resultSet = null;
		DeleteRecordType delRecType = null;
		
		try {
			//call stored proc
			jdbcConn = jdbcConnProvider.getJdbcConnectionFromDS();
			
			String sql = "SELECT PKEY_SRC_OBJECT, ROWID_SYSTEM FROM MERGE_REC_CONTROL_TABLE " +
							"WHERE BATCH_ID = " + batchId.trim() + " AND LOSER_INDICATOR = 'Y' AND IS_MERGED = 'N'";
			LOG.info("Query to execute: " + sql);
			LOG.info("Preparing to execute query");
			
			statement = jdbcConn.createStatement();
			resultSet = statement.executeQuery(sql);
			
			while (resultSet.next()) {
				delRecType = new DeleteRecordType();
				delRecType.setSRCSYSTEMID(resultSet.getString("PKEY_SRC_OBJECT"));
				delRecType.setSRCSYSTEM(resultSet.getString("ROWID_SYSTEM"));
				recToDelList.add(delRecType);
			}
			LOG.info("Query executed successfully. Number of records fetched = " + recToDelList.size());

		} catch (ServiceProcessingException spEx) {
			LOG.error("Failed to fetch records for batch id " + batchId, spEx);
			spEx.setMessage("Failed to fetch records for batch id " + batchId + ": " + spEx.getMessage());
			throw spEx;
		} catch(Exception exp) {
			LOG.error("Failed to fetch records for batch id " + batchId, exp);
			exp.printStackTrace();
			ServiceProcessingException customException = new ServiceProcessingException(exp);
			customException.setMessage("Failed to fetch records for batch id " + batchId + ": " + exp.getMessage());
			throw customException;
		}  finally	{
			//Closing connections
			try {
				if (resultSet != null) {
					resultSet.close();
				}
				if (statement != null) {
					statement.close();
				}
				if (jdbcConn != null) {
					jdbcConn.close();
				}
			} catch(SQLException exp) {
				exp.getMessage();
			}
		}
		LOG.info("Executed getRecordsForBatchId()");
		
		return recToDelList;
	}
	
	private String updateMergePersistentRec(List<DeleteRecordType> recToDelList) throws ServiceProcessingException {
		LOG.info("Executing updateMergePersistentRec()");
		
		StringBuilder status = new StringBuilder();
		Connection jdbcConn = null;
		PreparedStatement pstatement = null;
		DeleteRecordType delRecType = null;

		String taskTitle = "FinalReview Task for merge status flag update failure.";
		String taskComment = "Merge status flag update failed. Please set the is_merged flag to 'Y' in Merge_Rec_Control_Table";
		
		try {
			//call stored proc
			jdbcConn = jdbcConnProvider.getJdbcConnectionFromDS();
			jdbcConn.setAutoCommit(false);
			
			LOG.info("Preparing to update in batch mode");
			String sql = "Update MERGE_REC_CONTROL_TABLE set is_merged = 'Y' where trim(rowid_system) = ? and pkey_src_object = ?";
			LOG.info("Query to execute: " + sql);
			
			pstatement = jdbcConn.prepareStatement(sql);
			for (int index = 0; index < recToDelList.size(); index++) {
				delRecType = recToDelList.get(index);
				pstatement.setString(1, delRecType.getSRCSYSTEM().trim());
				pstatement.setString(2, delRecType.getSRCSYSTEMID());
				pstatement.addBatch();
				LOG.info("Merge completion flag to update for: " + delRecType.getSRCSYSTEM().trim() + ", " + delRecType.getSRCSYSTEMID());
			}
			
			int[] updtStatusArr = pstatement.executeBatch();
			jdbcConn.commit();
			
			LOG.info("Batch command executed successfully");
			status.append("Merge completion flag updated successfully");
			for (int ind = 0; ind < updtStatusArr.length; ind++) {
				LOG.info("Merge completion flag updation status: " + updtStatusArr[ind]);
			}
		} catch (ServiceProcessingException spEx) {
			LOG.error("Failed to update merge completion flag: ", spEx);
			status.append("Failed to update merge completion flag: " + spEx);
			String taskStatus = processCreateTaskRequest(recToDelList, "FinalReview", taskTitle, taskComment);
			spEx.setMessage(status + " | " + taskStatus);
			throw spEx;
		} catch(Exception exp) {
			LOG.error("Failed to update merge completion flag: ", exp);
			status.append("Failed to update merge completion flag: " + exp);
			String taskStatus = processCreateTaskRequest(recToDelList, "FinalReview", taskTitle, taskComment);
			ServiceProcessingException customException = new ServiceProcessingException(exp);
			customException.setMessage(status + " | " + taskStatus);
			throw customException;
		}  finally	{
			//Closing connections
			try {
				if (pstatement != null) {
					pstatement.close();
				}
				if (jdbcConn != null) {
					jdbcConn.close();
				}
			} catch(SQLException exp) {
				exp.getMessage();
			}
		}
		LOG.info("Executed updateMergePersistentRec()");
		
		return status.toString();
	}
	
	/*
	private String updateMergePersistentRec(List<DeleteRecordType> recToDelList) throws ServiceProcessingException {
		LOG.info("Executing updateMergePersistentRec()");
		
		StringBuilder status = new StringBuilder();
		Connection jdbcConn = null;
		CallableStatement callStmt = null;
		StructDescriptor structDescriptor = null;
		ArrayDescriptor arrayDescriptor = null;
		STRUCT dbTypeTRec2 = null;
		STRUCT[] dbTypeTabArr1 = null;
		Object[] dbTypeTRec2ObjectArr = null;
		DeleteRecordType delRecType = null;

		String taskTitle = "FinalReview Task for merge status flag update failure.";
		String taskComment = "Merge status flag update failed. Please set the is_merged flag to 'Y' in Merge_Rec_Control_Table";
		
		try{
			//call stored proc
			jdbcConn = jdbcConnProvider.getJdbcConnectionFromDS();
			
			LOG.info("Preparing to call stored proc");
			structDescriptor = new StructDescriptor("MFE_SQL_STMTS.t_rec2", jdbcConn);
			arrayDescriptor = ArrayDescriptor.createDescriptor("MFE_SQL_STMTS.TAB_ARR1", jdbcConn);
			
			dbTypeTabArr1 = new STRUCT[recToDelList.size()];
			
			for (int index = 0; index < recToDelList.size(); index++) {
				delRecType = recToDelList.get(index);
				dbTypeTRec2ObjectArr = new Object[] {delRecType.getSRCSYSTEM(), delRecType.getSRCSYSTEMID()};
				dbTypeTRec2 = new STRUCT(structDescriptor, jdbcConn, dbTypeTRec2ObjectArr);
				dbTypeTabArr1[index] = dbTypeTRec2;
			}
			
			ARRAY arrayToPass = new ARRAY( arrayDescriptor, jdbcConn, dbTypeTabArr1 );
			
			callStmt = jdbcConn.prepareCall("{call PROC_UPDATE_MERGE_STATUS(?,?,?)}");
			callStmt.setArray(1, arrayToPass);
			callStmt.registerOutParameter(2, OracleTypes.VARCHAR);
			callStmt.registerOutParameter(3, OracleTypes.NUMBER);
			
			callStmt.execute();
			LOG.info("Stored proc executed");
			
			String opStatus = callStmt.getString(2);
			int errorCode = callStmt.getInt(3);
			
			LOG.info("Stored procedure executed with status = " + opStatus + " || error code = " + errorCode);
			status.append("Merge completion flag updation status: " + opStatus);
		} catch (ServiceProcessingException spEx) {
			LOG.error("Failed to update merge completion flag: " + spEx);
			status.append("Failed to update merge completion flag: " + spEx);
			spEx.printStackTrace();
			String taskStatus = processCreateTaskRequest(recToDelList, "FinalReview", taskTitle, taskComment);
			spEx.setMessage(status + " | " + taskStatus);
			throw spEx;
		} catch(Exception exp) {
			LOG.error("Failed to update merge completion flag: " + exp);
			status.append("Failed to update merge completion flag: " + exp);
			exp.printStackTrace();
			String taskStatus = processCreateTaskRequest(recToDelList, "FinalReview", taskTitle, taskComment);
			ServiceProcessingException customException = new ServiceProcessingException(exp);
			customException.setMessage(status + " | " + taskStatus);
			throw customException;
		}  finally	{
			//Closing connections
			try {
				if (callStmt != null) {
					callStmt.close();
				}
				if (jdbcConn != null) {
					jdbcConn.close();
				}
			} catch(SQLException exp) {
				exp.getMessage();
			}
		}
		LOG.info("Executed updateMergePersistentRec()");
		
		return status.toString();
	} */
	
	//Method for CreatingTask for Administrator
	private String processCreateTaskRequest(List<DeleteRecordType> recToDelList, String taskType, String title, String comment)	{
		LOG.info("Executing processCreateTaskRequest()");
		SiperianClient siperianClient = null;
		StringBuilder status = new StringBuilder("");
		try {
			String ownerUid = configProps.getProperty("ownerUID");
			 String subjectAreaUID = configProps.getProperty("subjectAreaUID");
			 
			 CreateTaskResponse response = null;
			 CreateTaskRequest request = new CreateTaskRequest();
			 TaskData taskData = new TaskData();
			 TaskRecord taskRecord = null;
			 RecordKey recordKey = null;
			 List<TaskRecord> recordList = new ArrayList<TaskRecord>();
			 
			 for (DeleteRecordType delRecType : recToDelList) {
				 recordKey = new RecordKey();
				 recordKey.setSourceKey(delRecType.getSRCSYSTEMID());
				 recordKey.setSystemName(delRecType.getSRCSYSTEM());
				 
				 taskRecord = new TaskRecord();
				 taskRecord.setSiperianObjectUid(SiperianObjectType.XREF.makeUid("C_B_PARTY_XREF"));
					 taskRecord.setRecordKey(recordKey);
					 
					 recordList.add(taskRecord);
			}
			taskData.setOwnerUid(ownerUid);
			taskData.setTaskRecords(recordList);
			request.setTaskData(taskData);
			taskData.setTitle(title);
			taskData.setComment(comment);
			
			Calendar cal = Calendar.getInstance();
			cal.setTime(new Date(System.currentTimeMillis()));
			cal.add(Calendar.DATE, 7); 
			
			taskData.setDueDate(cal.getTime());
			taskData.setSubjectAreaUid(subjectAreaUID);
			taskData.setTaskType(taskType);
 
			siperianClient = (SiperianClient) checkOut();
			
			LOG.info("processing CreateTaskRequest");
			response = (CreateTaskResponse) siperianClient.process(request);
			LOG.info("CreateTaskResponse result: " + response.getMessage());
			LOG.info("CreateTaskResponse taskId: " + response.getTaskId());
			LOG.info("CreateTaskResponse interactionId: " + response.getInteractionId());
			status.append(title);
			status.append(" created for ");
			status.append(ownerUid);
		} catch (Exception excp) {
			LOG.error("Caught Exception in CreateTaskRequest Error Message: ", excp);
			status.append(title);
			status.append(" couldnot be created: ");
			status.append(excp.getMessage());
		} finally {
			checkIn(siperianClient);
		}
		 LOG.info("Executed processCreateTaskRequest()");
		 
		 return status.toString();
	}
	
	private String processUpdateRequest(PartyXrefType partyXref, SiperianClient siperianClient) 
			throws ServiceProcessingException {
		LOG.info("Executing processUpdateRequest()");
	
		String successStatus = null;
		PutResponseDataHolder putRespDataParty = null;
		List<PutResponseDataHolder> putRespDataAccountList = null;
		List<PutResponseDataHolder> putRespDataAddressList = null;
		List<PutResponseDataHolder> putRespDataCommunicationList = null;
		List<PutResponseDataHolder> putRespDataClassificationList = null;

		UserTransaction transaction = null;

		try {
			LOG.info("Processing Merge status update for Party and all childs with Party SrcPKEY=" + partyXref.getXREF().get(0).getSRCPKEY()
					+ " and SrcSYS=" + partyXref.getXREF().get(0).getSRCSYSTEM());
			LOG.info("Fetching SysDate from database");
			currDBSysDate = Util.getCurrentTimeZone();
			LOG.debug("SysDate = " + currDBSysDate.toString());
			
			LOG.debug("Transaction started");
			//Update transaction - commit if Put requests succeed for Party and all the child entities 
			transaction = ((EjbSiperianClient) siperianClient).createTX(300000);
			transaction.begin();

			//Update Party
			putRespDataParty = putParty(partyXref, siperianClient);
			//Update Account
			if (partyXref.getAccount() != null)	{
				putRespDataAccountList = putAccount(partyXref.getAccount(), siperianClient);
			}
			//Update Address
			if (partyXref.getAddress() != null) {
				putRespDataAddressList = putAddress(partyXref.getAddress(), siperianClient);
			}
			//Update Communication
			if (partyXref.getCommunication() != null) {
				putRespDataCommunicationList = putCommunication(partyXref.getCommunication(), siperianClient);
			}
			//Update Classification
			if (partyXref.getClassification() != null) {
				putRespDataClassificationList = putClassification(partyXref.getClassification(), siperianClient);
			}
			
			//commit transaction
			transaction.commit();
			LOG.debug("Transaction committed.");
			successStatus = "Merge status updated for Party and all childs with Party SrcPKEY=" + putRespDataParty.getSourceKey()
					+ " and SrcSYS=" + putRespDataParty.getSystemName();
			LOG.info(successStatus);
		} catch (ServiceProcessingException excp) {
			LOG.error("Exception occured while executing Put requests. Transaction will be rolled back: ", excp);
			try {
				transaction.rollback();
			} catch(SystemException txExcp) {
				LOG.error("Failed to rollback transaction for Put requests : " + txExcp.toString());
			}
			throw excp;
		} catch (Exception ex) {
			LOG.error("Exception occured while executing Put requests. Transaction will be rolled back: ", ex);
			try {
				transaction.rollback();
			} catch(SystemException txExcp) {
				LOG.error("Failed to rollback transaction for cleansePut requests : " + txExcp.toString());
				txExcp.printStackTrace();
			}
			ServiceProcessingException customException = new ServiceProcessingException(ex);
			customException.setMessage("Failed to process Put SIF request: " + ex.getMessage());
			customException.printStackTrace();
			throw customException;
		}
		/*
		try {
			
			LOG.info("Calling Tokenize process for LegacyRef Record.");
			processTokenizeRequest(putRespDataParty);
			
		//	upsertPartyResponse.setStatus(upsertPartyResponse.getStatus() + "\nTokenization operation successful for Party " + putRespDataParty.getSourceKey());
		} catch (SiperianServerException sifExcp) {
			LOG.error("SiperianServerException occured while processing TokenizeRequest for processUpdateRequest()");
			ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
			customException.setMessage("SIF exception occured while processing Tokenize request for processUpdateRequest(). );
			
			//Create Task for Tokenization failure
			String title = "Creating GenericTask for Tokenization failure.";
			String comment = "Tokenization failed while updating LegacyRef Record "+ partyXref.getROWIDOBJECT();
			processCreateTaskRequest(null, partyXref.getROWIDOBJECT(), "FinalReview", title, comment);
			
			throw customException;
		} catch (Exception excp) {
			LOG.error("Exception occured while processing TokenizeRequest for processUpdateRequest()");
			ServiceProcessingException customException = new ServiceProcessingException(excp);
			customException.setMessage("Exception occured while processing Tokenize request for processUpdateRequest(). );
			
			//Create Task for Tokenization failure
			String title = "Creating GenericTask for Tokenization failure.";
			String comment = "Tokenization failed while updating LegacyRef Record "+ partyXref.getROWIDOBJECT();
			processCreateTaskRequest(null, partyXref.getROWIDOBJECT(), "FinalReview", title, comment);
		}	 
		*/
		LOG.info("Executed processUpdateRequest()");

		return successStatus;
	}
	
	/**
	 * The method prepares and executes PutRequest on Party xref table for the given party profile.
	 * @param partyParam
	 * @param siperianClient
	 * @return
	 * @throws ServiceProcessingException
	 */
	private PutResponseDataHolder putParty(PartyXrefType partyParam, SiperianClient siperianClient) 
			throws ServiceProcessingException {
		LOG.info("Executing putParty()");

		PutRequest putRequest = new PutRequest();
		PutResponse putResponse = null;
		PutResponseDataHolder responseDataHolder = null;
	//	CleansePutRequest cleansePutRequest = new CleansePutRequest();
	//	CleansePutResponse cleansePutResponse = null;
		
		try {
			RecordKey recordKey = new RecordKey();
			recordKey.setSourceKey(partyParam.getXREF().get(0).getSRCPKEY());
			recordKey.setSystemName(partyParam.getXREF().get(0).getSRCSYSTEM());
			putRequest.setRecordKey(recordKey);

			Record record = new Record();
			//set mapping name
		//	record.setSiperianObjectUid(SiperianObjectType.PACKAGE.makeUid(MDMAttributeNames.PARTY_PKG));
			record.setSiperianObjectUid(SiperianObjectType.BASE_OBJECT.makeUid(MDMAttributeNames.PARTY_BO));
		//	record.setSiperianObjectUid(Util.getMappingObjectUid(partyParam.getXREF().get(itemIndex).getSRCSYSTEM().trim(), MDMAttributeNames.ENTITY_PARTY));
		//	LOG.info("Performing cleansePutParty with sysdate from HUB: " + currDBSysDate);
		//	record.setField(new Field(MDMAttributeNames.LAST_UPDATE_DATE, currDBSysDate));
		//	record.setField(new Field(MDMAttributeNames.SRC_SYSTEM, (partyParam.getXREF().get(itemIndex)).getSRCSYSTEM()));
		//	record.setField(new Field(MDMAttributeNames.SRC_SYS_KEY, (partyParam.getXREF().get(itemIndex)).getSRCPKEY()));
			//set status
			record.setField(new Field(PartyAttributes.STATUS_CD, "M"));
			record.setField(new Field(PartyAttributes.REGION, partyParam.getREGION()));
			record.setField(new Field(PartyAttributes.TAX_JURSDCTN_CD, partyParam.getTAXJURSDCTNCD()));
			record.setField(new Field(PartyAttributes.VAT_REG_NBR, partyParam.getVATREGNBR()));
			record.setField(new Field(PartyAttributes.PARTY_TYPE, partyParam.getPARTYTYPE()));
			record.setField(new Field(PartyAttributes.SALES_BLOCK_CD, partyParam.getSALESBLOCKCD()));
			record.setField(new Field(PartyAttributes.UCN, partyParam.getUCN()));
			record.setField(new Field(PartyAttributes.PARTY_TYPE, partyParam.getPARTYTYPE()));
			record.setField(new Field(PartyAttributes.PARTY_NAME, partyParam.getPARTYNAME()));
			record.setField(new Field(PartyAttributes.GEO, partyParam.getGEO()));
			record.setField(new Field(PartyAttributes.LEGACY_UCN, partyParam.getLEGACYUCN()));
			
			/** Modified for M4M START */
			record.setField(new Field(PartyAttributes.DNB_DBA_NAME, partyParam.getDNBDBANAME()));
			record.setField(new Field(PartyAttributes.DNB_SECOND_TRADE_STYLE, partyParam.getDNBSECONDTRADESTYLE()));
			record.setField(new Field(PartyAttributes.DNB_REG_NAME, partyParam.getDNBREGNAME()));
			/** Modified for M4M END */
			
			putRequest.setRecord(record);
			//execute Put request
			putResponse = (PutResponse) siperianClient.process(putRequest);
			LOG.info("Party Put request processed successfully: " + putResponse.getMessage());
	//		cleansePutRequest.setRecord(record);
			// execute Put request
	//		cleansePutResponse = (CleansePutResponse) siperianClient.process(cleansePutRequest);
	//		LOG.info("Party cleansePut request processed successfully: " + cleansePutResponse.getMessage());
			
			//extract result
	//		RecordKey recordKey1 = cleansePutResponse.getRecordKey();
			RecordKey recordKey1 = putResponse.getRecordKey();
			
			responseDataHolder = new PutResponseDataHolder();
			responseDataHolder.setActionType(putResponse.getActionType());
			responseDataHolder.setActionMessage(putResponse.getMessage());
			responseDataHolder.setRowidObject(recordKey1.getRowid());
			responseDataHolder.setRowidXREF(recordKey1.getRowidXref());
			responseDataHolder.setSourceKey(recordKey1.getSourceKey());
			responseDataHolder.setSystemName(recordKey1.getSystemName());
			
			LOG.info("ROWID_OBJECT of updated Party record = " + recordKey1.getRowid());
			LOG.debug("Action Type = " + responseDataHolder.getActionType());
			LOG.debug("Action Msg = " + responseDataHolder.getActionMessage());
			LOG.debug("Rowid_xref = " + responseDataHolder.getRowidXREF());
			LOG.debug("Src key = " + responseDataHolder.getSourceKey());
			LOG.debug("System = " + responseDataHolder.getSystemName());
				
		} catch (SiperianServerException sifExcp) {
			LOG.error("SiperianServerException occured while processing PutRequest for Party: ", sifExcp);
			sifExcp.printStackTrace();
			ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
			customException.setRootExceptionMsg("Put operation failed for Party " + (partyParam.getXREF().get(0)).getSRCPKEY());
			customException.setMessage("SIF exception occured while processing Put request for Party: " + sifExcp.getMessage());
			throw customException;
		} catch (Exception excp) {
			LOG.error("Exception occured while processing PutRequest for Party: " + excp);
			excp.printStackTrace();
			ServiceProcessingException customException = new ServiceProcessingException(excp);
			customException.setMessage("Exception occured while processing Put request for Party: " + excp.getMessage());
			customException.setRootExceptionMsg("Put operation failed for Party " + (partyParam.getXREF().get(0)).getSRCPKEY());
			throw customException;
		}
	
		LOG.info("Executed PutParty()");
		return responseDataHolder;
	}
	
	/**
	 * The method prepares and executes PutRequest on Account xref table for the given account profiles.
	 * @param accountList
	 * @param partyParam
	 * @param siperianClient
	 * @return
	 * @throws ServiceProcessingException
	 */
	private List<PutResponseDataHolder>  putAccount(List<AccountXrefType> accountList, SiperianClient siperianClient) 
			throws ServiceProcessingException {
		LOG.info("Executing PutAccount()");
		int itemIndex = 0;
		PutRequest putRequest = null;
		PutResponse putResponse = null;
		List<PutResponseDataHolder> responseDataHolderList = new ArrayList<PutResponseDataHolder>(accountList.size());
		AccountXrefType accountParam = null;

		try {
			for (itemIndex = 0; itemIndex < accountList.size(); itemIndex++) {
				putRequest = new PutRequest();
				accountParam = accountList.get(itemIndex);
				RecordKey recordKey = new RecordKey();
				recordKey.setSourceKey(accountParam.getSRCPKEY());
				recordKey.setSystemName(accountParam.getSRCSYSTEM());
				putRequest.setRecordKey(recordKey);
				
				Record record = new Record();
				//set mapping name
			//	record.setSiperianObjectUid(SiperianObjectType.PACKAGE.makeUid(MDMAttributeNames.ACCOUNT_PKG));
				record.setSiperianObjectUid(SiperianObjectType.BASE_OBJECT.makeUid(MDMAttributeNames.ACCOUNT_BO));
				
				//set input values
				record.setField(new Field(AccountAttributes.ACCT_STATUS, "M"));
				record.setField(new Field(AccountAttributes.PARTNER_TYPE, accountParam.getPARTNERTYPE()));
				record.setField(new Field(AccountAttributes.VENDOR_NBR, accountParam.getVENDORNBR()));
				record.setField(new Field(AccountAttributes.DIRECT_IND, accountParam.getDIRECTIND()));
				record.setField(new Field(AccountAttributes.NAMED_ACCT_IND, accountParam.getNAMEDACCTIND()));
				record.setField(new Field(AccountAttributes.NON_VAL_ACCT_IND, accountParam.getNONVALACCTIND()));
				record.setField(new Field(AccountAttributes.PARTNER_IND, accountParam.getPARTNERIND()));
				record.setField(new Field(AccountAttributes.SIEBEL_ROWID, accountParam.getSIEBELROWID()));
				record.setField(new Field(AccountAttributes.SAP_CUST_NUMBER, accountParam.getSAPCUSTNUMBER()));
				record.setField(new Field(AccountAttributes.MDM_LEGACY_ID, accountParam.getMDMLEGACYID()));
				record.setField(new Field(AccountAttributes.DATA_SRC_SYSTEM, accountParam.getDATASRCSYSTEM()));
				record.setField(new Field(AccountAttributes.ACCT_TYPE, accountParam.getACCTTYPE()));
				record.setField(new Field(AccountAttributes.CUST_GROUP, accountParam.getCUSTGROUP()));
				record.setField(new Field(AccountAttributes.PRICE_GROUP, accountParam.getPRICEGROUP()));
				record.setField(new Field(AccountAttributes.COMPANY_CD, accountParam.getCOMPANYCD()));
				record.setField(new Field(AccountAttributes.ACCOUNT_VAT_REG_NBR, accountParam.getACCOUNTVATREGNBR()));
				record.setField(new Field(AccountAttributes.ACCT_NAME, accountParam.getACCTNAME()));
				record.setField(new Field(AccountAttributes.ACCOUNT_TAX_JURSDCTN_CD, accountParam.getACCOUNTTAXJURSDCTNCD()));
				record.setField(new Field(AccountAttributes.TAX_TYPE, accountParam.getTAXTYPE()));
				record.setField(new Field(AccountAttributes.ALIAS_NAME, accountParam.getALIASNAME()));
				record.setField(new Field(AccountAttributes.BILL_BLOCK_CD, accountParam.getBILLBLOCKCD()));
				record.setField(new Field(AccountAttributes.ORDR_BLOCK_CD, accountParam.getORDRBLOCKCD()));
				record.setField(new Field(AccountAttributes.ACCOUNT_GEO, accountParam.getACCOUNTGEO()));
				record.setField(new Field(AccountAttributes.ACCOUNT_REGION, accountParam.getACCOUNTREGION()));
				record.setField(new Field(AccountAttributes.DLVRY_BLOCK_CD, accountParam.getDLVRYBLOCKCD()));
				record.setField(new Field(AccountAttributes.POST_BLOCK_CD, accountParam.getPOSTBLOCKCD()));
				record.setField(new Field(AccountAttributes.SALE_BLOCK_CD, accountParam.getSALEBLOCKCD()));
				record.setField(new Field(AccountAttributes.CHANNEL_ID, accountParam.getCHANNELID()));
				record.setField(new Field(AccountAttributes.MARKET, accountParam.getMARKET()));
				record.setField(new Field(AccountAttributes.SAP_NAME_1, accountParam.getSAPNAME1()));
				record.setField(new Field(AccountAttributes.SAP_NAME_2, accountParam.getSAPNAME2()));
				record.setField(new Field(AccountAttributes.SAP_NAME_3, accountParam.getSAPNAME3()));
				record.setField(new Field(AccountAttributes.SAP_NAME_4, accountParam.getSAPNAME4()));
				
				//Changed for US487:: START
				record.setField(new Field(AccountAttributes.SFID, accountParam.getSalesForceID()));
				//Changed for US487:: END
				
				putRequest.setRecord(record);
				//execute Put request
				putResponse = (PutResponse) siperianClient.process(putRequest);
				LOG.info("Account Put request processed successfully: " + putResponse.getMessage());
				//extract result
				RecordKey recordKey1 = putResponse.getRecordKey();
				
				PutResponseDataHolder responseDataHolder = new PutResponseDataHolder();
				responseDataHolder.setActionType(putResponse.getActionType());
				responseDataHolder.setActionMessage(putResponse.getMessage());
				responseDataHolder.setRowidObject(recordKey1.getRowid());
				responseDataHolder.setRowidXREF(recordKey1.getRowidXref());
				responseDataHolder.setSourceKey(recordKey1.getSourceKey());
				responseDataHolder.setSystemName(recordKey1.getSystemName());
				responseDataHolderList.add(responseDataHolder);
				
				LOG.info("ROWID_OBJECT of updated Account record = " + recordKey1.getRowid());
				LOG.debug("Action Type = " + responseDataHolder.getActionType());
				LOG.debug("Src key = " + responseDataHolder.getSourceKey());
				LOG.debug("System = " + responseDataHolder.getSystemName());
			}
		} catch (SiperianServerException sifExcp) {
			LOG.error("SiperianServerException occured while processing PutRequest for Account: ", sifExcp);
			ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
			customException.setMessage("SIF exception occured while processing Put request for Account: " + sifExcp.getMessage());
			customException.setRootExceptionMsg("Put operation failed for Account " + accountParam.getSRCPKEY());
			throw customException;
		} catch (Exception excp) {
			LOG.error("Exception occured while processing CleansePutRequest for Party: ", excp);
			ServiceProcessingException customException = new ServiceProcessingException(excp);
			customException.setMessage("Exception occured while processing Put request for Account: " + excp.getMessage());
			customException.setRootExceptionMsg("Put operation failed for Account " + accountParam.getSRCPKEY());
			throw customException;
		}
		
		LOG.info("Executed PutAccount()");
		return responseDataHolderList;
	}
	
	/**
	 * The method prepares and executes PutRequest on ADDRESS xref table for the given Address profiles.
	 * @param addressList List of Addresses provided to the web service request
	 * @param partyParam Party profile provided to the web service request
	 * @param siperianClient SiperianClient SIF connection to MDM Hub
	 * @return List of PutResponseDataHolder object containing processing results
	 * @throws ServiceProcessingException
	 */
	private List<PutResponseDataHolder> putAddress(List<AddressXrefType> addressList, SiperianClient siperianClient) 
			throws ServiceProcessingException {
		LOG.info("Executing PutAddress()");
		int itemIndex = 0;
		PutRequest  putRequest = null;
		PutResponse  putResponse = null;
		List<PutResponseDataHolder> responseDataHolderList = new ArrayList<PutResponseDataHolder>(addressList.size());
		AddressXrefType addressParam = null;
		
		try {
			for (itemIndex = 0; itemIndex < addressList.size(); itemIndex++) {
				putRequest = new PutRequest();
				addressParam = addressList.get(itemIndex);
				RecordKey recordKey = new RecordKey();
				recordKey.setSourceKey(addressParam.getSRCPKEY());
				recordKey.setSystemName(addressParam.getSRCSYSTEM());
				putRequest.setRecordKey(recordKey);

				Record record = new Record();
				//set mapping name
			//	record.setSiperianObjectUid(SiperianObjectType.PACKAGE.makeUid(MDMAttributeNames.ADDRESS_PKG));
				record.setSiperianObjectUid(SiperianObjectType.BASE_OBJECT.makeUid(MDMAttributeNames.ADDRESS_BO));
				//set input values
				record.setField(new Field(AddressAttributes.ADDR_STATUS, "M"));
				record.setField(new Field(AddressAttributes.ADDR_LN1, addressParam.getADDRLN1()));
				record.setField(new Field(AddressAttributes.ADDR_LN2, addressParam.getADDRLN2()));
				record.setField(new Field(AddressAttributes.ADDR_LN3, addressParam.getADDRLN3()));
				record.setField(new Field(AddressAttributes.ADDR_LN4, addressParam.getADDRLN4()));
				record.setField(new Field(AddressAttributes.CITY, addressParam.getCITY()));
				record.setField(new Field(AddressAttributes.COUNTY, addressParam.getCOUNTY()));
				record.setField(new Field(AddressAttributes.DISTRICT, addressParam.getDISTRICT()));
				record.setField(new Field(AddressAttributes.STATE_CD, addressParam.getSTATECD()));
				record.setField(new Field(AddressAttributes.POSTAL_CD, addressParam.getPOSTALCD()));
				record.setField(new Field(AddressAttributes.COUNTRY_CD, addressParam.getCOUNTRYCD()));
				record.setField(new Field(AddressAttributes.LANG_CD, addressParam.getLANGCD()));
				record.setField(new Field(AddressAttributes.LATITUDE, addressParam.getLATITUDE()));
				record.setField(new Field(AddressAttributes.LONGITUDE, addressParam.getLONGITUDE()));
				record.setField(new Field(AddressAttributes.ADDR_TYPE, addressParam.getADDRTYPE()));
		
				putRequest.setRecord(record);
				//execute Put request
				putResponse = (PutResponse) siperianClient.process(putRequest);
				LOG.info("Address Put request processed successfully: " + putResponse.getMessage());
				//extract result
				RecordKey recordKey1 = putResponse.getRecordKey();
				
				PutResponseDataHolder responseDataHolder = new PutResponseDataHolder();
				responseDataHolder.setActionType(putResponse.getActionType());
				responseDataHolder.setActionMessage(putResponse.getMessage());
				responseDataHolder.setRowidObject(recordKey1.getRowid());
				responseDataHolder.setRowidXREF(recordKey1.getRowidXref());
				responseDataHolder.setSourceKey(recordKey1.getSourceKey());
				responseDataHolder.setSystemName(recordKey1.getSystemName());
				responseDataHolderList.add(responseDataHolder);
				
				LOG.info("ROWID_OBJECT of updated Address record = " + recordKey1.getRowid());
				LOG.debug("Action Type = " + responseDataHolder.getActionType());
				LOG.debug("Src key = " + responseDataHolder.getSourceKey());
				LOG.debug("System = " + responseDataHolder.getSystemName());
			}
		} catch (SiperianServerException sifExcp) {
			LOG.error("SiperianServerException occured while processing PutRequest for Address: ", sifExcp);
			ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
			customException.setMessage("SIF exception occured while processing Put request for Address: " + sifExcp.getMessage());
			customException.setRootExceptionMsg("Put operation failed for Address " + addressParam.getSRCPKEY());
			throw customException;
		} catch (Exception excp) {
			LOG.error("Exception occured while processing PutRequest for Address: " + excp);
			ServiceProcessingException customException = new ServiceProcessingException(excp);
			customException.setMessage("Exception occured while processing Put request for Address: " + excp.getMessage());
			customException.setRootExceptionMsg("Put operation failed for Address " + addressParam.getSRCPKEY());
			throw customException;
		}
		
		LOG.info("Executed PutAddress()");
		return responseDataHolderList;
	}
	
	/**
	 * The method prepares and executes PutRequest on COMMUNICATION xref table for the given Communication profiles.
	 * @param commList List of Communications provided to the web service request
	 * @param partyParam Party profile provided to the web service request
	 * @param siperianClient SiperianClient SIF connection to MDM Hub
	 * @return List of PutResponseDataHolder object containing processing results
	 * @throws ServiceProcessingException
	 */
	private List<PutResponseDataHolder> putCommunication(List<CommunicationXrefType> commList, SiperianClient siperianClient) 
			throws ServiceProcessingException {
		LOG.info("Executing PutCommunication()");
		int itemIndex = 0;
		PutRequest putRequest = null;
		PutResponse putResponse = null;
		List<PutResponseDataHolder> responseDataHolderList = new ArrayList<PutResponseDataHolder>(commList.size());
		CommunicationXrefType commParam = null;
		
		try {
			for (itemIndex = 0; itemIndex < commList.size(); itemIndex++) {
				putRequest = new PutRequest();
				commParam = commList.get(itemIndex);
				RecordKey recordKey = new RecordKey();
				recordKey.setSourceKey(commParam.getSRCPKEY());
				recordKey.setSystemName(commParam.getSRCSYSTEM());
				putRequest.setRecordKey(recordKey);
				
				Record record = new Record();
				//set mapping name
			//	record.setSiperianObjectUid(SiperianObjectType.PACKAGE.makeUid(MDMAttributeNames.COMM_PKG));
				record.setSiperianObjectUid(SiperianObjectType.BASE_OBJECT.makeUid(MDMAttributeNames.COMM_BO));
				
				//set input values
				record.setField(new Field(CommunicationAttributes.COMM_STATUS, "M")); 
				record.setField(new Field(CommunicationAttributes.PRFRD_COMM_IND, commParam.getPRFRDCOMMIND()));
				record.setField(new Field(CommunicationAttributes.WEB_DOMAIN, commParam.getWEBDOMAIN()));
				record.setField(new Field(CommunicationAttributes.COMM_TYPE, commParam.getCOMMTYPE()));
				record.setField(new Field(CommunicationAttributes.COMM_VALUE, commParam.getCOMMVALUE()));
				
				putRequest.setRecord(record);
				//execute Put request
				putResponse = (PutResponse) siperianClient.process(putRequest);
				LOG.info("Communication Put request processed successfully: " + putResponse.getMessage());
				//extract result
				RecordKey recordKey1 = putResponse.getRecordKey();
				
				PutResponseDataHolder responseDataHolder = new PutResponseDataHolder();
				responseDataHolder.setActionType(putResponse.getActionType());
				responseDataHolder.setActionMessage(putResponse.getMessage());
				responseDataHolder.setRowidObject(recordKey1.getRowid());
				responseDataHolder.setRowidXREF(recordKey1.getRowidXref());
				responseDataHolder.setSourceKey(recordKey1.getSourceKey());
				responseDataHolder.setSystemName(recordKey1.getSystemName());
				responseDataHolderList.add(responseDataHolder);
				
				LOG.info("ROWID_OBJECT of updated Communication record = " + recordKey1.getRowid());
				LOG.debug("Action Type = " + responseDataHolder.getActionType());
				LOG.debug("Src key = " + responseDataHolder.getSourceKey());
				LOG.debug("System = " + responseDataHolder.getSystemName());
			}
		} catch (SiperianServerException sifExcp) {
			LOG.error("SiperianServerException occured while processing PutRequest for Communication: ", sifExcp);
			ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
			customException.setMessage("SIF exception occured while processing Put request for Communication: " + sifExcp.getMessage());
			customException.setRootExceptionMsg("Put operation failed for Communication " + commParam.getSRCPKEY());
			throw customException;
		} catch (Exception excp) {
			LOG.error("Exception occured while processing PutRequest for Communication: ", excp);
			ServiceProcessingException customException = new ServiceProcessingException(excp);
			customException.setMessage("Exception occured while processing Put request for Communication: " + excp);
			customException.setRootExceptionMsg("Put operation failed for Communication " + commParam.getSRCPKEY());
			throw customException;
		}
		
		LOG.info("Executed PutCommunication()");
		return responseDataHolderList;
	}
	
	/**
	 * The method prepares and executes PutRequest on Classification xref table for the given Classification profiles.
	 * @param commList List of Communications provided to the web service request
	 * @param partyParam Party profile provided to the web service request
	 * @param siperianClient SiperianClient SIF connection to MDM Hub
	 * @return List of PutResponseDataHolder object containing processing results
	 * @throws ServiceProcessingException
	 */
	private List<PutResponseDataHolder> putClassification(List<ClassificationXrefType> classifList, SiperianClient siperianClient) 
			throws ServiceProcessingException {
		LOG.info("Executing putClassification()");
		int itemIndex = 0;
		PutRequest putRequest = null;
		PutResponse putResponse = null;
		List<PutResponseDataHolder> responseDataHolderList = new ArrayList<PutResponseDataHolder>(classifList.size());
		ClassificationXrefType classifParam = null;
		Calendar calStartDate = null;
		Calendar calEndDate = null;
		Calendar calCurrDate = UpsertPartyDAO.convertStringToCalendar(getCurrentTimeStamp().toString());
		
		try {
			LOG.debug("Current Date in Calendar form: " + calCurrDate.getTime());
			for (itemIndex = 0; itemIndex < classifList.size(); itemIndex++) {
				putRequest = new PutRequest();
				classifParam = classifList.get(itemIndex);
				RecordKey recordKey = new RecordKey();
				recordKey.setSourceKey(classifParam.getSRCPKEY());
				recordKey.setSystemName(classifParam.getSRCSYSTEM());
				recordKey.setRowid(classifParam.getROWIDCLASSIFICTN());
				putRequest.setRecordKey(recordKey);
				
				LOG.debug("classifPKEY: "+classifParam.getSRCPKEY()+"|classifSrcSystem: "+classifParam.getSRCSYSTEM()+"|classifParam.getROWID: "+classifParam.getROWIDCLASSIFICTN());
				Record record = new Record();
				//set mapping name
			//	record.setSiperianObjectUid(SiperianObjectType.PACKAGE.makeUid(MDMAttributeNames.CLASS_PKG));
				record.setSiperianObjectUid(SiperianObjectType.BASE_OBJECT.makeUid(MDMAttributeNames.CLASS_BO));
				/**START: US-80 End Date and survive SFV in classification Xref*/
				//Converting END_DATE to Calendar object  
				calEndDate = UpsertPartyDAO.convertStringToCalendar(classifParam.getENDDATE());
				if(null != calEndDate && calEndDate.after(calCurrDate))	{
					if (classifParam.getCLASSIFICTNTYPE().equalsIgnoreCase("Segment - Final Value")){
					//set input values
					record.setField(new Field(ClassificationAttributes.END_DATE, currDBSysDate)); 
					record.setField(new Field(ClassificationAttributes.CLASSIFICTN_TYPE, classifParam.getCLASSIFICTNTYPE()));
					record.setField(new Field(ClassificationAttributes.CLASSIFICTN_VALUE, classifParam.getCLASSIFICTNVALUE()));
					//Converting START_DATE to Calendar object 
					calStartDate = UpsertPartyDAO.convertStringToCalendar(classifParam.getSTARTDATE());
					record.setField(new Field(ClassificationAttributes.START_DATE, calStartDate.getTime()));
					LOG.debug("Existing active record found with START_DATE: " + calStartDate.getTime()+"|END_DATE: "+calEndDate.getTime()); 
					
					putRequest.setRecord(record);
					//execute Put request
					putResponse = (PutResponse) siperianClient.process(putRequest);
					LOG.info("Classification Put request to set End_Date processed successfully: " + putResponse.getMessage());
					//extract result
					RecordKey recordKey1 = putResponse.getRecordKey();
					
					PutResponseDataHolder responseDataHolder = new PutResponseDataHolder();
					responseDataHolder.setActionType(putResponse.getActionType());
					responseDataHolder.setActionMessage(putResponse.getMessage());
					responseDataHolder.setRowidObject(recordKey1.getRowid());
					responseDataHolder.setRowidXREF(recordKey1.getRowidXref());
					responseDataHolder.setSourceKey(recordKey1.getSourceKey());
					responseDataHolder.setSystemName(recordKey1.getSystemName());
					responseDataHolderList.add(responseDataHolder);
					
					LOG.info("ROWID_OBJECT of updated Classification record = " + recordKey1.getRowid());
					LOG.debug("Action Type = " + responseDataHolder.getActionType());
					LOG.debug("Src key = " + responseDataHolder.getSourceKey());
					LOG.debug("System = " + responseDataHolder.getSystemName());
				}//end if-else loop for SFV checking
				}//end if-else loop for END_DATE checking
				/**END: US-80 End Date and survive SFV in classification Xref*/
			}//end for loop
		} catch (SiperianServerException sifExcp) {
			LOG.error("SiperianServerException occured while processing PutRequest for Classification: ", sifExcp);
			ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
			customException.setMessage("SIF exception occured while processing Put request for Classification: " + sifExcp.getMessage());
			customException.setRootExceptionMsg("Put operation failed for Classification " + classifParam.getSRCPKEY());
			throw customException;
		} catch (Exception excp) {
			LOG.error("Exception occured while processing PutRequest for Classification: ", excp);
			ServiceProcessingException customException = new ServiceProcessingException(excp);
			customException.setMessage("Exception occured while processing Put request for Classification: " + excp);
			customException.setRootExceptionMsg("Put operation failed for Classification " + classifParam.getSRCPKEY());
			throw customException;
		}
		
		LOG.info("Executed putClassification()");
		return responseDataHolderList;
	}
	
	//Fetch SYSDATE from Informetica HUB DB.
	public Timestamp getCurrentTimeStamp() {
		LOG.debug("Inside getCurrentTimeStamp()");
		JDBCConnectionProvider jDBCConnnectionProvider = null;
		Connection jdbcConn = null;
		Statement statement = null;
		ResultSet resultSet = null;
		StringBuilder sql = new StringBuilder();
		sql.append("SELECT SYSTIMESTAMP FROM DUAL");
		Timestamp currTmStmp = null;
		Date sysDate = null;
		
		try{
			jDBCConnnectionProvider = JDBCConnectionProvider.getSingleInstance();
			jdbcConn = jDBCConnnectionProvider.getJdbcConnectionFromDS();
			statement = jdbcConn.createStatement();
			resultSet = statement.executeQuery(sql.toString());

			while(resultSet.next())	{
				currTmStmp = resultSet.getTimestamp(1);
			}

		} catch (ServiceProcessingException servExp ){
			LOG.error("Caught SQLException in getCurrentTimeStamp()." + servExp);
			servExp.getMessage();
		} catch (SQLException sqlexp) {
			LOG.error("Caught SQLException in getCurrentTimeStamp()." + sqlexp);
			sqlexp.getMessage();
		} finally {
			try {
				if(resultSet != null) resultSet.close();
				if (statement != null) statement.close();
				if(jdbcConn != null) jdbcConn.close();
				
				} /*catch (ServiceProcessingException servExp ){
					logger.error("Caught SQLException in getCurrentTimeStamp()." + servExp);
					servExp.getMessage();
				}*/catch (SQLException e) {
					LOG.error("Caught SQLException in getCurrentTimeStamp()." + e);
				}
		}
		return currTmStmp;
	}
	

}
