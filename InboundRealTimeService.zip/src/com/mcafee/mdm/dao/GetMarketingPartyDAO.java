package com.mcafee.mdm.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.mcafee.mdm.constants.Constant;
import com.mcafee.mdm.dao.pojo.SearchedXrefRecordCollection;
import com.mcafee.mdm.exception.ServiceProcessingException;
import com.mcafee.mdm.generated.AddressXrefType;
import com.mcafee.mdm.generated.PartyXrefType;
import com.mcafee.mdm.util.ObjectPool;
import com.siperian.sif.client.SiperianClient;
import com.siperian.sif.message.Record;
import com.siperian.sif.message.RecordKey;
import com.siperian.sif.message.mrm.GetRequest;
import com.siperian.sif.message.mrm.GetResponse;

@Component
public class GetMarketingPartyDAO extends ObjectPool {

	private static final Logger LOG = Logger
			.getLogger(GetMarketingPartyDAO.class.getName());

	@Resource(name = "configProp")
	private Properties configProps;

	public PartyXrefType getBOPartyForMrktActn(String partyID, String srcSystem, String srcPkey)
			throws ServiceProcessingException {
		LOG.debug("[getBOPartyForMrktActn] ENTER");

		PartyXrefType partyDetails = null;
		SiperianClient siperianClient = null;

		GetRequest request = new GetRequest();
		GetResponse response = null;
		String pkgNameBO = configProps
				.getProperty(Constant.PKG_MRKT_ACTN_DETAILS_NAME);

		try {
			siperianClient = (SiperianClient) checkOut();

			RecordKey recordKey = new RecordKey();
			recordKey.setRowid(partyID);
			request.setRecordKey(recordKey); // Required
			request.setSiperianObjectUid(pkgNameBO); // Required

			LOG.debug("[getBOPartyForMrktActn]processing GetRequest on "
					+ pkgNameBO + " for partyID " + partyID);
			response = (GetResponse) siperianClient.process(request);
			LOG.debug("[getBOPartyForMrktActn]GetRequest processed");

			if (response != null && response.getRecords().size() > 0) {
				LOG.info("GetRequest rec cnt=" + response.getRecords().size());
				partyDetails = processActnXRefGoldenCopyResults(response
						.getRecords(), srcSystem, srcPkey);
			}
		} catch (Exception excp) {
			LOG.error(
					"[getBOPartyForMrktActn]Exception occurred while fetching Party golden copy:",
					excp);
			ServiceProcessingException customException = new ServiceProcessingException(
					excp);
			customException.setMessage("Failed to fetch Party golden copy: "
					+ excp.getMessage());
			throw customException;
		} finally {
			try {
				checkIn(siperianClient);
			} catch (Exception excp) {
				LOG.error("[getBOPartyForMrktActn]Failed to checkin siperianClient connection to Object pool: "
						+ excp.toString());
			}
		}
		LOG.debug("[getBOPartyForMrktActn]EXIT");
		return partyDetails;
	}

	private PartyXrefType processActnXRefGoldenCopyResults(
			List<Record> searchRecords, String srcSystem, String srcPkey) throws ServiceProcessingException {
		LOG.debug("[processActnXRefGoldenCopyResults]ENTER");
		PartyXrefType partyDetails = null;
		Map<String, SearchedXrefRecordCollection> searchedRecCollMap = new HashMap<String, SearchedXrefRecordCollection>();
		SearchedXrefRecordCollection searchedRecCollObj = null;
		boolean bUniqueRec = false;
		try {
			if (!CollectionUtils.isEmpty(searchRecords)) {
				for (Record record : searchRecords) {
					String partyRowId = record.getField("ROWID_OBJECT")
							.getStringValue();
					partyDetails = new PartyXrefType();

					if (!searchedRecCollMap.containsKey(partyRowId)) {

						LOG.debug("[processActnXRefGoldenCopyResults]Populate searchedRecCollMap for new PARTY_ROWID "
								+ partyRowId);
						searchedRecCollMap.put(partyRowId,
								new SearchedXrefRecordCollection());
						bUniqueRec = true;
					}

					searchedRecCollObj = searchedRecCollMap.get(partyRowId);

					if (bUniqueRec) {
						LOG.debug("[processActnXRefGoldenCopyResults]============setting GoldenCopy");

						searchedRecCollObj.setParty_rowid(partyRowId);
						searchedRecCollObj.setBo_class(record.getField(
								"BO_CLASS_CODE").getStringValue());
						searchedRecCollObj.setParty_type(record.getField(
								"PARTY_TYPE").getStringValue());
						searchedRecCollObj.setParty_name(record.getField(
								"PARTY_NAME").getStringValue());
						searchedRecCollObj.setGeo(record.getField("GEO")
								.getStringValue());
						searchedRecCollObj.setRegion(record.getField("REGION")
								.getStringValue());
						searchedRecCollObj.setStatus_cd(record.getField(
								"STATUS_CD").getStringValue());
						searchedRecCollObj.setVat_regno(record.getField(
								"VAT_REG_NBR").getStringValue());
						searchedRecCollObj.setTax_jd_cd(record.getField(
								"TAX_JURSDCTN_CD").getStringValue());
						searchedRecCollObj.setSales_cd(record.getField(
								"SALES_BLOCK_CD").getStringValue());
						/*searchedRecCollObj.setUcn(record.getField("UCN")
								.getStringValue());*/
						searchedRecCollObj.setEnglish_name(record.getField(
								"ENGLISH_NAME").getStringValue());
					}

					if (record.getField("ADDR_ROWID_OBJECT").getStringValue() != null
							&& !searchedRecCollObj.getAddressMap().containsKey(
									record.getField("ADDR_ROWID_OBJECT")
											.getStringValue())) {

						AddressXrefType address = new AddressXrefType();
						address.setROWIDADDRESS(record.getField(
								"ADDR_ROWID_OBJECT").getStringValue());
						address.setSRCSYSTEM(srcSystem);
						address.setSRCPKEY(srcPkey);
						address.setADDRLN1(record.getField("ADDR_LN1")
								.getStringValue());
						address.setADDRLN2(record.getField("ADDR_LN2")
								.getStringValue());
						address.setADDRLN3(record.getField("ADDR_LN3")
								.getStringValue());
						address.setADDRLN4(record.getField("ADDR_LN4")
								.getStringValue());
						address.setCITY(record.getField("CITY")
								.getStringValue());
						address.setCOUNTY(record.getField("COUNTY")
								.getStringValue());
						address.setDISTRICT(record.getField("DISTRICT")
								.getStringValue());
						address.setSTATECD(record.getField("STATE_CD")
								.getStringValue());
						address.setPOSTALCD(record.getField("POSTAL_CD")
								.getStringValue());
						address.setCOUNTRYCD(record.getField("COUNTRY_CD")
								.getStringValue());
						address.setLANGCD(record.getField("LANG_CD")
								.getStringValue());
						address.setADDRTYPE(record.getField("ADDR_TYPE")
								.getStringValue());
						address.setADDRSTATUS(record.getField("ADDR_STATUS")
								.getStringValue());

						LOG.debug("[processActnXRefGoldenCopyResults]===Inserting into Address Map===");
						searchedRecCollObj.getAddressMap().put(
								record.getField("ADDR_ROWID_OBJECT")
										.getStringValue(), address);

					}
					bUniqueRec = false;
				}

				LOG.debug("====Populating PartyProfileList");

				partyDetails
						.setROWIDOBJECT(searchedRecCollObj.getParty_rowid());
				partyDetails.setBOCLASSCODE(searchedRecCollObj.getBo_class());
				partyDetails.setPARTYTYPE(searchedRecCollObj.getParty_type());
				partyDetails.setPARTYNAME(searchedRecCollObj.getParty_name());
				partyDetails.setGEO(searchedRecCollObj.getGeo());
				partyDetails.setREGION(searchedRecCollObj.getRegion());
				partyDetails.setSTATUSCD(searchedRecCollObj.getStatus_cd());
				partyDetails.setVATREGNBR(searchedRecCollObj.getVat_regno());
				partyDetails
						.setTAXJURSDCTNCD(searchedRecCollObj.getTax_jd_cd());
				partyDetails.setSALESBLOCKCD(searchedRecCollObj.getSales_cd());
				partyDetails.setUCN(searchedRecCollObj.getUcn());
				partyDetails.getAccount().addAll(
						searchedRecCollObj.getAccountMap().values());
				partyDetails.getAddress().addAll(
						searchedRecCollObj.getAddressMap().values());
			}
		} catch (Exception exp) {
			LOG.error(
					"[processActnXRefGoldenCopyResults]Exception occurred in processing golden copy resultset",
					exp);
			ServiceProcessingException customException = new ServiceProcessingException(
					exp);
			customException
					.setMessage("[processActnXRefGoldenCopyResults]Failed to process golden copy resultset: "
							+ exp.getMessage());
			throw customException;
		}
		LOG.debug("[processActnXRefGoldenCopyResults]EXIT");

		return partyDetails;
	}
}