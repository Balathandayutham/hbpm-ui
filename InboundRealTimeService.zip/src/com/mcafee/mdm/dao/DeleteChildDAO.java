package com.mcafee.mdm.dao;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.transaction.SystemException;
import javax.transaction.UserTransaction;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.mcafee.mdm.constants.AddressAttributes;
import com.mcafee.mdm.constants.ClassificationAttributes;
import com.mcafee.mdm.constants.CommunicationAttributes;
import com.mcafee.mdm.constants.Constant;
import com.mcafee.mdm.constants.MDMAttributeNames;
import com.mcafee.mdm.constants.PartyAttributes;
import com.mcafee.mdm.constants.ProspectAttributes;
import com.mcafee.mdm.exception.ServiceProcessingException;
import com.mcafee.mdm.generated.PartyXrefType;
import com.mcafee.mdm.util.ObjectPool;
import com.siperian.sif.client.EjbSiperianClient;
import com.siperian.sif.client.SiperianClient;
import com.siperian.sif.client.SiperianServerException;
import com.siperian.sif.message.Field;
import com.siperian.sif.message.Record;
import com.siperian.sif.message.RecordKey;
import com.siperian.sif.message.SiperianObjectType;
import com.siperian.sif.message.mrm.DeleteRequest;
import com.siperian.sif.message.mrm.DeleteResponse;
import com.siperian.sif.message.mrm.PutRequest;
import com.siperian.sif.message.mrm.PutResponse;

@Component
public class DeleteChildDAO extends ObjectPool {

	private static final Logger LOG = Logger.getLogger(DeleteChildDAO.class.getName());
	private Date sysDate = null;

	
	public Date getSysDate() {
		return sysDate;
	}


	public void setSysDate(Date sysDate) {
		this.sysDate = sysDate;
	}


	public void updateStatus(PartyXrefType upsertPartyPayload, Map<String, List<String>> recToDelList, String BOName, SiperianClient siperianClient) 
			throws ServiceProcessingException {
		LOG.info("Inside updateStatus()");
		
		//UserTransaction transaction = null;
		
		//try	{
			//create transaction - commit if Delete and Put requests both succeeded 
			//transaction = ((EjbSiperianClient) siperianClient).createTX(1200); //in seconds
			//transaction.begin();
			
			String systemUser = "admin";
			String addrStatus = "I";
			String commStatus = "I";
			String srcSystem = null;
			List<String> recList = null;
			Calendar cal = null;
			//Date endDate = Util.getCurrentTimeZone();
			PutRequest putRequest = new PutRequest();
			PutResponse putResponse = null;
			try {
					for (Entry<String, List<String>> entry : recToDelList.entrySet()) {
						
						recList = entry.getValue();
						
						if(upsertPartyPayload != null){
							srcSystem = upsertPartyPayload.getXREF().get(0).getSRCSYSTEM().trim();
						} else {
							srcSystem = "SBL"; //trimming not required
						}
						String srcPkey = entry.getKey().toString(); //trimming not required
						String srcRowid = recList.get(0); //trimming not required
						
						LOG.info("Executing PutRequest with src_system=" + srcSystem + " | scr_pkey=" + srcPkey + " | scr_rowid=" + srcRowid);
						
						//prepare PutRequest
						RecordKey recordKey = new RecordKey();
						recordKey.setRowid(srcRowid); 
						recordKey.setSourceKey(srcPkey); 
						recordKey.setSystemName(srcSystem);
						putRequest.setRecordKey(recordKey);
						
						Record record = new Record();
						if (BOName.equalsIgnoreCase(MDMAttributeNames.ADDRESS_BO)) {
							//set hub object name
							record.setSiperianObjectUid(SiperianObjectType.BASE_OBJECT.makeUid(MDMAttributeNames.ADDRESS_BO));
							//set input values
							record.setField(new Field(AddressAttributes.ADDR_STATUS, addrStatus));
						} else if (BOName.equalsIgnoreCase(MDMAttributeNames.COMM_BO))	{
							//set hub object name
							record.setSiperianObjectUid(SiperianObjectType.BASE_OBJECT.makeUid(MDMAttributeNames.COMM_BO));
							//set input values
							record.setField(new Field(CommunicationAttributes.COMM_STATUS, commStatus));
						} else if (BOName.equalsIgnoreCase(MDMAttributeNames.CLASS_BO))	{
							//set hub object name
							record.setSiperianObjectUid(SiperianObjectType.BASE_OBJECT.makeUid(MDMAttributeNames.CLASS_BO));
							//set input values
							LOG.debug("Classification END_DATE with Timestamp: " + new Timestamp(sysDate.getTime()));
					//		LOG.debug("Classification END_DATE: " + endDate.toString());
							record.setField(new Field(ClassificationAttributes.END_DATE, sysDate));
							//Converting START_DATE to Calendar object 
							cal = UpsertPartyDAO.convertStringToCalendar(recList.get(1));
							record.setField(new Field(ClassificationAttributes.START_DATE, cal.getTime()));
							LOG.debug("Existing active record found with START_DATE: " + cal.getTime()); 
							
					//		record.setField(new Field(MDMAttributeNames.CLASSIFICATION.START_DATE, recList.get(1)));
							record.setField(new Field(ClassificationAttributes.CLASSIFICTN_TYPE, recList.get(3)));
							record.setField(new Field(ClassificationAttributes.CLASSIFICTN_VALUE, recList.get(4)));
						}
						record.setField(new Field(MDMAttributeNames.SRC_UPDT_BY, systemUser));
						
						
						putRequest.setRecord(record);
						//execute Put request
						putResponse = (PutResponse) siperianClient.process(putRequest);
						LOG.info("Put request processed successfully: Action Type = " + putResponse.getActionType() + 
								" | Msg = " + putResponse.getMessage());
		
					}
				} catch (SiperianServerException sifExcp) {
					LOG.error("SiperianServerException occured while processing status update Put request: ", sifExcp);
					LOG.error("SIF exception message: " + sifExcp.getMessage());
					sifExcp.printStackTrace();
					ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
					customException.setMessage("SIF exception occured while processing status update Put request: " + sifExcp.getMessage());
					throw customException;
				} catch (Exception excp) {
					LOG.error("Exception occured while processing status update Put request: ", excp);
					excp.printStackTrace();
					ServiceProcessingException customException = new ServiceProcessingException(excp);
					customException.setMessage("Exception occured while processing status update Put request: " + excp.getMessage());
					throw customException;
				}
				
				//LOG.info("Committing transaction");
				//transaction.commit();
				//LOG.info("Transaction committed");
			/*} catch(ServiceProcessingException spExcp)	{
				LOG.error("ServiceProcessingException occurred on UpdateStatus request processing: ", spExcp);
				try {
					if (transaction != null) {
						transaction.rollback();
						LOG.info("UpdateStatus operation failed. Transaction rolled back.");
					}
				} catch(SystemException txExcp) {
					LOG.error("Failed to rollback transaction for UpdateStatus Put requests : " + txExcp.toString());
				}
				throw spExcp;
			} catch(Exception excp)	{
				LOG.error("Exception occurred on UpdateStatus request processing: ", excp);
				try {
					if (transaction != null) {
						transaction.rollback();
						LOG.info("UpdateStatus operation failed. Transaction rolled back.");
					}
				} catch(SystemException txExcp) {
					LOG.error("Failed to rollback transaction for UpdateStatus Put requests : " + txExcp.toString());
				}
				ServiceProcessingException customException = new ServiceProcessingException(excp);
				customException.setMessage("Failed to process cleansePut SIF request. );
				customException.printStackTrace();
				throw customException;
			} */
		LOG.info("Executed updateStatus()");
		
	}
	
	public PutResponse partyUpdateStatus(String rowidObject, String BOName,SiperianClient siperianClient) 
			throws ServiceProcessingException {
		LOG.info("Inside partyUpdateStatus()");
		
			String systemUser = "admin";
			String partyStatus = "C";
			String srcSystem = "ELQ";
			PutResponse putResponse = null;
			try {
			
				PutRequest putRequest = new PutRequest();
				
						
						//prepare PutRequest
						RecordKey recordKey = new RecordKey();
						recordKey.setRowid(rowidObject); 
						recordKey.setSystemName(srcSystem);
						putRequest.setRecordKey(recordKey);
						
						Record record = new Record();
					if (BOName.equalsIgnoreCase(MDMAttributeNames.PARTY_BO)) {
						// set hub object name
						record.setSiperianObjectUid(SiperianObjectType.BASE_OBJECT.makeUid(MDMAttributeNames.PARTY_BO));
						// set input values
						record.setField(new Field(PartyAttributes.STATUS_CD, partyStatus));
						record.setField(new Field(PartyAttributes.PARTY_TYPE, Constant.PARTY_TYPE_PROSPECT_ACCOUNT));
					} 
					/*else if (BOName.equalsIgnoreCase(MDMAttributeNames.PARTY_PROSPECT_BO)) {
						record.setSiperianObjectUid(
								SiperianObjectType.BASE_OBJECT.makeUid(MDMAttributeNames.PARTY_PROSPECT_BO));
								record.setField(new Field(ProspectAttributes.PROSPECT_TYPE, Constant.PARTY_TYPE_PROSPECT_ACCOUNT));
								record.setField(new Field(ProspectAttributes.PROSPECT_STATUS, partyStatus));
					}*/
					
					 record.setField(new Field(MDMAttributeNames.SRC_UPDT_BY, systemUser));
						putRequest.setRecord(record);
						//execute Put request
						putResponse = (PutResponse) siperianClient.process(putRequest);
						LOG.info("Put request processed successfully: Action Type = " + putResponse.getActionType() + 
								" | Msg = " + putResponse.getMessage());
						
				
			} catch (SiperianServerException sifExcp) {
				LOG.error("SiperianServerException occured while processing status update Put request: ", sifExcp);
				LOG.error("SIF exception message: " + sifExcp.getMessage());
				sifExcp.printStackTrace();
				ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
				customException.setMessage("SIF exception occured while processing status update Put request: " + sifExcp.getMessage());
				throw customException;
			} catch (Exception excp) {
				LOG.error("Exception occured while processing status update Put request: ", excp);
				excp.printStackTrace();
				ServiceProcessingException customException = new ServiceProcessingException(excp);
				customException.setMessage("Exception occured while processing status update Put request: " + excp.getMessage());
				throw customException;
			}
		LOG.info("Executed partyUpdateStatus()");
		return putResponse;
	}
	
	public void updateChildProspectStatus(List<String> sourceKeyList, String BOName, SiperianClient siperianClient) 
			throws ServiceProcessingException {
		LOG.info("Inside updateChildProspectStatus()");
		
		//UserTransaction transaction = null;
		
		//try	{
			//create transaction - commit if Delete and Put requests both succeeded 
			//transaction = ((EjbSiperianClient) siperianClient).createTX(1200); //in seconds
			//transaction.begin();
			
			String systemUser = "admin";
			String Status = "C";
			String srcSystem = "ELQ";
			PutRequest putRequest = new PutRequest();
			PutResponse putResponse = null;
			try {
	
				List<RecordKey> keyList = new ArrayList<RecordKey>();
				for (String sourceKey : sourceKeyList) {
					// prepare PutRequest
					RecordKey recordKey = new RecordKey();
					/*if (BOName.equalsIgnoreCase(MDMAttributeNames.PARTY_PROSPECT_BO)) {
					recordKey.setRowid(RowId);
					}
					else{*/
						recordKey.setSourceKey(sourceKey);
					//}
					LOG.info("Executing PutRequest with src_system=" + srcSystem + " | sourceKey=" + sourceKey);
					recordKey.setSystemName(srcSystem);
					putRequest.setRecordKey(recordKey);
	
					Record record = new Record();
					if (BOName.equalsIgnoreCase(MDMAttributeNames.PARTY_BO)) {
						// set hub object name
						record.setSiperianObjectUid(SiperianObjectType.BASE_OBJECT.makeUid(MDMAttributeNames.PARTY_BO));
						// set input values
						record.setField(new Field(PartyAttributes.STATUS_CD, Status));
						record.setField(new Field(PartyAttributes.PARTY_TYPE, Constant.PARTY_TYPE_PROSPECT_ACCOUNT));
						 record.setField(new Field(MDMAttributeNames.SRC_UPDT_BY, systemUser));
					} 
					else if (BOName.equalsIgnoreCase(MDMAttributeNames.ADDRESS_BO)) {
						// set hub object name
						record.setSiperianObjectUid(SiperianObjectType.BASE_OBJECT.makeUid(MDMAttributeNames.ADDRESS_BO));
						// set input values
						record.setField(new Field(AddressAttributes.ADDR_STATUS, Status));
						record.setField(new Field(MDMAttributeNames.SRC_UPDT_BY, systemUser));
					} else if (BOName.equalsIgnoreCase(MDMAttributeNames.COMM_BO)) {
						// set hub object name
						record.setSiperianObjectUid(SiperianObjectType.BASE_OBJECT.makeUid(MDMAttributeNames.COMM_BO));
						// set input values
						record.setField(new Field(CommunicationAttributes.COMM_STATUS, Status));
						record.setField(new Field(MDMAttributeNames.SRC_UPDT_BY, systemUser));
					}
					else if (BOName.equalsIgnoreCase(MDMAttributeNames.PARTY_PROSPECT_BO)) {
						record.setSiperianObjectUid(
								SiperianObjectType.BASE_OBJECT.makeUid(MDMAttributeNames.PARTY_PROSPECT_BO));
								record.setField(new Field(ProspectAttributes.PROSPECT_TYPE, Constant.PARTY_TYPE_PROSPECT_ACCOUNT));
								record.setField(new Field(ProspectAttributes.PROSPECT_STATUS, Status));
								record.setField(new Field(ProspectAttributes.SRC_UPD_BY, systemUser));
					}
				
	
					putRequest.setRecord(record);
					// execute Put request
					putResponse = (PutResponse) siperianClient.process(putRequest);
					LOG.info("Put request processed successfully: Action Type = " + putResponse.getActionType()
							+ " | Msg = " + putResponse.getMessage());
	
				}
			} catch (SiperianServerException sifExcp) {
					LOG.error("SiperianServerException occured while processing status update Put request: ", sifExcp);
					LOG.error("SIF exception message: " + sifExcp.getMessage());
					sifExcp.printStackTrace();
					ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
					customException.setMessage("SIF exception occured while processing status update Put request: " + sifExcp.getMessage());
					throw customException;
				} catch (Exception excp) {
					LOG.error("Exception occured while processing status update Put request: ", excp);
					excp.printStackTrace();
					ServiceProcessingException customException = new ServiceProcessingException(excp);
					customException.setMessage("Exception occured while processing status update Put request: " + excp.getMessage());
					throw customException;
				}
				
			
		LOG.info("Executed updateStatus()");
		
	}
	
	public DeleteResponse deleteChildBO(List<String> sourceKeyList,String BO)
			throws ServiceProcessingException {
		LOG.debug("[deleteChildBO] ENTER");
		SiperianClient siperianClient = null;
		UserTransaction transaction = null;
		DeleteResponse response = null;
		String srcSystem = "MFE";
		if(BO.equals(MDMAttributeNames.PARTY_PROSPECT_BO)){
			srcSystem=Constant.SRC_SYSTEM_ADB;
		}
		try {
			siperianClient = (SiperianClient) checkOut();
			transaction = ((EjbSiperianClient) siperianClient).createTX(300000);
			transaction.begin();
			DeleteRequest request = new DeleteRequest();
			request.setSiperianObjectUid(SiperianObjectType.BASE_OBJECT.makeUid(BO));
			List<RecordKey> keyList = new ArrayList<RecordKey>();
			for (String sourceKey : sourceKeyList) {
				RecordKey recordKey = new RecordKey();
				recordKey.setSourceKey(sourceKey);
				recordKey.setSystemName(srcSystem);
				LOG.info("Executing DeleteRequest with src_system=" + srcSystem + " | sourceKey=" + sourceKey);
				keyList.add(recordKey);
			}
			request.setRecordKeys(keyList);
			LOG.debug("[deleteChildBO]Before executing Delete process ");
			response = (DeleteResponse) siperianClient.process(request);
			transaction.commit();
			LOG.debug("[deleteChildBO]Delete Completed::Message::"
					+ response.getMessage());
		} catch (Exception ex) {
			LOG.error(
					"Exception occured while deleteChildBO operation requests: ",
					ex);
			try {
				transaction.rollback();
			} catch (SystemException txExcp) {
				LOG.error(
						"Failed to rollback transaction for deleteChildBO operation: ",
						txExcp);
			}
			if (ex instanceof ServiceProcessingException) {
				throw (ServiceProcessingException) ex;
			} else {
				ServiceProcessingException customException = new ServiceProcessingException(
						ex);
				customException
						.setMessage("Failed to process deleteChildBO operation. "
								+ customException.getMessage());
				throw customException;
			}
		} finally {
			if (siperianClient != null) {
				checkIn(siperianClient);
			}
		}
		LOG.debug("[deleteChildBO] EXIT");
		return response;
	}
}
