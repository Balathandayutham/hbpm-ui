package com.mcafee.mdm.dao;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;
import java.util.TreeSet;

import javax.annotation.Resource;
import javax.transaction.SystemException;
import javax.transaction.UserTransaction;

//import org.apache.axis.utils.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.mcafee.mdm.constants.AccountAttributes;
import com.mcafee.mdm.constants.AddressAttributes;
import com.mcafee.mdm.constants.ClassificationAttributes;
import com.mcafee.mdm.constants.CommunicationAttributes;
import com.mcafee.mdm.constants.Constant;
import com.mcafee.mdm.constants.MDMAttributeNames;
import com.mcafee.mdm.constants.PartyAttributes;
import com.mcafee.mdm.constants.SearchMatchAttributes;
import com.mcafee.mdm.dao.pojo.CntctPkeyRowIdRelData;
import com.mcafee.mdm.dao.pojo.HighestScoreRecordHolder;
import com.mcafee.mdm.dao.pojo.PutResponseDataHolder;
import com.mcafee.mdm.dao.pojo.SearchedXrefRecordCollection;
import com.mcafee.mdm.exception.ServiceProcessingException;
import com.mcafee.mdm.generated.Account;
import com.mcafee.mdm.generated.AccountType;
import com.mcafee.mdm.generated.AccountXrefType;
import com.mcafee.mdm.generated.Address;
import com.mcafee.mdm.generated.AddressType;
import com.mcafee.mdm.generated.AddressXrefType;
import com.mcafee.mdm.generated.Classification;
import com.mcafee.mdm.generated.ClassificationType;
import com.mcafee.mdm.generated.ClassificationXrefType;
import com.mcafee.mdm.generated.Communication;
import com.mcafee.mdm.generated.CommunicationType;
import com.mcafee.mdm.generated.CommunicationXrefType;
import com.mcafee.mdm.generated.MdmUpsertPartyRequest;
import com.mcafee.mdm.generated.MdmUpsertPartyResponse;
import com.mcafee.mdm.generated.PartyAccountRelationshipType;
import com.mcafee.mdm.generated.PartyAccountRelationshipXrefType;
import com.mcafee.mdm.generated.PartyOrgExt;
import com.mcafee.mdm.generated.PartyOrgExtType;
import com.mcafee.mdm.generated.PartyOrgExtXrefType;
import com.mcafee.mdm.generated.PartyRel;
import com.mcafee.mdm.generated.PartyRelationshipXrefType;
import com.mcafee.mdm.generated.PartyType;
import com.mcafee.mdm.generated.PartyUpsertRespType;
import com.mcafee.mdm.generated.PartyXrefType;
import com.mcafee.mdm.generated.StatusType;
import com.mcafee.mdm.generated.UpsertPartyRequest;
import com.mcafee.mdm.generated.UpsertPartyResponse;
import com.mcafee.mdm.generated.XREFCopy;
import com.mcafee.mdm.generated.XREFType;
import com.mcafee.mdm.util.CommonUtil;
import com.mcafee.mdm.util.JDBCConnectionProvider;
import com.mcafee.mdm.util.ObjectPool;
import com.mcafee.mdm.util.PerformanceLoggerUtil;
import com.mcafee.mdm.util.PropertyUtil;
import com.mcafee.mdm.util.Util;
import com.mcafee.mdm.util.ValidatorUtil;
import com.siperian.sif.client.EjbSiperianClient;
import com.siperian.sif.client.SiperianClient;
import com.siperian.sif.client.SiperianServerException;
import com.siperian.sif.message.Field;
import com.siperian.sif.message.MatchType;
import com.siperian.sif.message.Record;
import com.siperian.sif.message.RecordKey;
import com.siperian.sif.message.RecordState;
import com.siperian.sif.message.SiperianObjectType;
import com.siperian.sif.message.TaskData;
import com.siperian.sif.message.TaskRecord;
import com.siperian.sif.message.mrm.CleansePutRequest;
import com.siperian.sif.message.mrm.CleansePutResponse;
import com.siperian.sif.message.mrm.CleanseRequest;
import com.siperian.sif.message.mrm.CleanseResponse;
import com.siperian.sif.message.mrm.CreateTaskRequest;
import com.siperian.sif.message.mrm.CreateTaskResponse;
import com.siperian.sif.message.mrm.GetRequest;
import com.siperian.sif.message.mrm.GetResponse;
import com.siperian.sif.message.mrm.MergeRequest;
import com.siperian.sif.message.mrm.MergeResponse;
import com.siperian.sif.message.mrm.MultiMergeRequest;
import com.siperian.sif.message.mrm.MultiMergeResponse;
import com.siperian.sif.message.mrm.PutRequest;
import com.siperian.sif.message.mrm.PutResponse;
import com.siperian.sif.message.mrm.SearchMatchRequest;
import com.siperian.sif.message.mrm.SearchMatchResponse;
import com.siperian.sif.message.mrm.SearchQueryRequest;
import com.siperian.sif.message.mrm.SearchQueryResponse;
import com.siperian.sif.message.mrm.SetRecordStateRequest;
import com.siperian.sif.message.mrm.SetRecordStateResponse;
import com.siperian.sif.message.mrm.TokenizeRequest;
import com.siperian.sif.message.mrm.TokenizeResponse;

import oracle.jdbc.OracleTypes;

/**
 *
 *
 */
@Component
@Scope("prototype")
public class FNOUpsertPartyDAO extends ObjectPool {
	private static final Logger LOG = Logger.getLogger(FNOUpsertPartyDAO.class.getName());

	@Autowired
	private DeleteChildDAO deleteChildDAO;
	@Autowired
	private GetPartyDAO getPartyDAO;
	@Autowired
	private SearchPartyDAO searchPartyDAO;
	@Autowired
	private ProspectPartyDAO prospectPartyDAO;
	@Autowired
	SearchPartyDAO searchDao;
	@Autowired
	private TrilliumCleanserDAO trilliumCleanserDAO;
	@Autowired
	private TrilliumLookUpDAO trilliumLookUpDAO;
	@Resource(name = "m4mMessagesProp")
	private Properties messagesProp;
	@Autowired
	private JdbcTemplate jdbcTemplate;
	@Autowired
	private ValidatorUtil validatorUtil;
	@Autowired
	private CommonUtil commonUtil;
	@Autowired 
	MergeProspectPartyDAO mergeProspectPartyDAO;

	/* Change for MDMP-2885 :: START */
	@Autowired
	private GenericDAO genericDAO;
	/* Change for MDMP-2885 :: END */
	
	boolean mergeInd = false;
	boolean matchInd = false;
	boolean childMergeInd = false;
	int partyCount = 0;
	String tgtRowidObj = null;
	String sipPopVal = null;
	String systemUser = "admin";
	String boXrefUser = "RT-BO-XREF";
	Properties configProps = PropertyUtil.getPropertiesFromFile("configProp");
	int matchScoreThres = Integer.parseInt(configProps.getProperty("matchScore-Threshold"));
	String getPkgName = configProps.getProperty("pkgName");
	StringBuilder warning = new StringBuilder();
	boolean isJapan = Boolean.FALSE;
	boolean isSFC = Boolean.FALSE;
	boolean selfMatchFail = false;
	boolean ucnMatch = false;
	boolean mdmLegacyIdMatch = Boolean.FALSE;
	boolean p2cEligible = Boolean.FALSE;

	Date lastUpdateDate = null;

	public MdmUpsertPartyResponse processUpsertPartyRequest(MdmUpsertPartyRequest upsertPartyRequest)
			throws ServiceProcessingException {
		LOG.info("Executing processUpsertPartyRequest()");
		MdmUpsertPartyResponse upsertPartyResponse = new MdmUpsertPartyResponse();
		String methodName = null;
		int sizeInputParty = upsertPartyRequest.getParty().size();
		for (int index = 0; index < sizeInputParty; index++) {
			try {
				upsertPartyResponse.setUpsertStatus(new StatusType());
				PartyXrefType upsertParty = upsertPartyRequest.getParty().get(index);
				
				validatorUtil.validateMsgTrackingId(upsertParty, upsertPartyResponse,false);
				if (upsertPartyRequest.getUpsertStatus() != null
						&& (upsertPartyRequest.getUpsertStatus().getErrorCode() != null)) {
					methodName = configProps.getProperty(upsertPartyRequest.getUpsertStatus().getErrorCode() + "_API");
				}
				LOG.info("Executing method ");
				StatusType status = new StatusType();
				upsertPartyResponse.setUpsertStatus(status);

				processUpsertRequestForIndividualParty(methodName, upsertParty, upsertPartyResponse);
			} catch (ServiceProcessingException servexp) {
				LOG.error("Caught ServiceProcessingException in processUpsertPartyRequest()", servexp);

			} catch (Exception exp) {
				LOG.error("Caught exception in processUpsertPartyRequest()", exp);
			}
		}
		upsertPartyResponse.setStatus(upsertPartyResponse.getStatus() == null ? "" : upsertPartyResponse.getStatus() + "\n Processing completed for " + partyCount + " party(ies).");

		return upsertPartyResponse;
	}

	public void processUpsertRequestForIndividualParty(String methodName, PartyXrefType upsertParty,
			MdmUpsertPartyResponse upsertPartyResponse)
			throws ServiceProcessingException, SecurityException, ClassNotFoundException {

		LOG.info("Executing processUpsertRequestForIndividualParty()");

		String rowidObject = null;
		boolean retry = false;
		boolean execNext = false;

		if (null != methodName) {
			partyCount = 1;
			retry = true;
			execNext = true;
			try {
				LOG.info("Before reflection Method name : " + methodName.trim());
				Class<? extends FNOUpsertPartyDAO> cls = this.getClass();
				LOG.info("Class : " + cls.toString());

				Method method = cls.getMethod(new String(methodName.trim()), new Class[] { PartyXrefType.class,
						MdmUpsertPartyResponse.class, boolean.class, boolean.class, String.class });
				LOG.info("After get Method : " + method.toString());
				Object[] args = new Object[5];
				args[0] = upsertParty;
				args[1] = upsertPartyResponse;
				args[2] = retry;
				args[3] = execNext;
				args[4] = rowidObject;
				LOG.info("Before invoke");
				method.invoke(this, args);
				LOG.info("After Invoke");
			} catch (NoSuchMethodException e) {
				LOG.error(e);
				throw new ServiceProcessingException(e);
			} catch (IllegalAccessException e) {
				LOG.error(e);
				throw new ServiceProcessingException(e);
			} catch (IllegalArgumentException e) {
				LOG.error(e);
				throw new ServiceProcessingException(e);
			} catch (InvocationTargetException e) {
				LOG.error(e);
				throw new ServiceProcessingException(e);
			}
		} else {
			retry = false;
			execNext = false;
			
			upsertDataValidation(upsertParty, upsertPartyResponse, false, false, rowidObject);

			upsertTrilliumProcessing(upsertParty, upsertPartyResponse, false, false, rowidObject);

			/* Change for MDMP-2885 :: START */
			genericDAO.callIsDeniedPartyService(upsertParty);
			/* Change for MDMP-2885 :: END */

			// Check for data quality in FNO input
			checkDataQualityUpsert(upsertParty, upsertPartyResponse, false, false, rowidObject);
			// Check pre upsert match processes
			preUpsertMatchProcess(upsertParty, upsertPartyResponse, false, false, rowidObject);

			processCleansePutRequest(upsertParty, upsertPartyResponse, false, false, rowidObject);

			upsertTokenize(upsertParty, upsertPartyResponse, false, false, rowidObject);

			upsertMatchMergeProcess(upsertParty, upsertPartyResponse, false, false, rowidObject);

			upsertP2CProcess(upsertParty, upsertPartyResponse, false, false, rowidObject);

			upsertUCNStampProcess(upsertParty, upsertPartyResponse, false, false, rowidObject);

			//processAcntCntctRel(upsertParty, upsertPartyResponse, false, false, rowidObject);

			upsertDataSyncAccSegAssignProcess(upsertParty, upsertPartyResponse, false, false, rowidObject);

		}

		populateUpsertResponse(upsertParty, upsertPartyResponse);

		LOG.info("Executed processUpsertRequestForIndividualParty()");

	}



	private boolean isMatchExclusionPatternExists(String rowidobject) throws ServiceProcessingException {

		boolean exclusionPatternExists = false;
		int patternExist = getPartyDAO.checkMatchExclusionPattern(rowidobject);
		if (patternExist > 0) {
			exclusionPatternExists = true;
			getPartyDAO.updatePartyConsolidationInd(rowidobject);
		}

		return exclusionPatternExists;
	}

	

	/**
	 * The method process cleansePut SIF requests for entire Party profile
	 * (Party and child entities) in the request. It handles transaction as per
	 * business need. After successful put calls, it stores the created
	 * rowid_object of the entities into respective response object
	 *
	 * @param UpsertPartyRequest
	 *            The web service request object
	 * @param UpsertPartyResponse
	 *            response object for web service
	 * @return Map<String, Object> a collection of entity-wise cleansePut
	 *         response values clubbed in PutResponseDataHolder object
	 * @throws ServiceProcessingException
	 */
	public void processCleansePutRequest(PartyXrefType upsertParty, MdmUpsertPartyResponse upsertPartyResponse,
			boolean retry, boolean executeNextStpe, String rowidObject) throws ServiceProcessingException {

		LOG.info("Executing processCleansePutRequest()");
		PerformanceLoggerUtil perfLog = new PerformanceLoggerUtil();

		SiperianClient siperianClient = null;
		UserTransaction transaction = null;

		PartyXrefType partyParam = upsertParty;
		PutResponseDataHolder putRespDataParty = null;
		List<PutResponseDataHolder> putRespDataAccountList = null;
		List<PutResponseDataHolder> putRespDataAddressList = null;
		
		Map<String, Object> putRespDataHolderMap = new HashMap<String, Object>();

		Map<String, String> existingAddrPkeyMap = new HashMap<String, String>();
		List<String> newAddrPkeyList = new ArrayList<String>();
		Map<String, List<String>> recToDelAddrMap = new HashMap<String, List<String>>();


		try {

				// Fetch current existing ADDRESS SRC_PKEYs from MDM DB
				existingAddrPkeyMap = getPresentAddrPkeyList(upsertParty);

				// Fetch new ADDRESS SRC_PKEYs from input request
				for (int itemIndex = 0; itemIndex < partyParam.getAddress().size(); itemIndex++) {
					newAddrPkeyList.add(partyParam.getAddress().get(itemIndex).getSRCPKEY());
					LOG.debug("newAddrPkeyList: " + newAddrPkeyList.get(itemIndex));
				}

				if (existingAddrPkeyMap != null && existingAddrPkeyMap.size() > 0) {
					LOG.debug("existingAddrPkeyMap size: " + existingAddrPkeyMap.size());
					// Finding the Old ADDRESS SRC_PKEYs to be deleted
					for (Entry<String, String> entry : existingAddrPkeyMap.entrySet()) {
						String addrPkey = entry.getKey().toString();
						LOG.debug("existingAddrPkeyMap: " + addrPkey);
						if (!newAddrPkeyList.contains(addrPkey)) {
							List<String> addrList = new ArrayList<String>();
							addrList.add((String) entry.getValue());// ROWID_OBJECT
							// Delete the Existing Address from MDM DB
							recToDelAddrMap.put(addrPkey, addrList);

						}
					}
				}
				

			siperianClient = (SiperianClient) checkOut();

			// create transaction - commit if cleansePut requests succeed for
			// Party and all the child entities
			transaction = ((EjbSiperianClient) siperianClient).createTX(300000);
			transaction.begin();

			lastUpdateDate = Util.getCurrentTimeZone();
			deleteChildDAO.setSysDate(lastUpdateDate);

			// In-activate Old Address 
			if (recToDelAddrMap != null && recToDelAddrMap.size() > 0) {
				deleteChildDAO.updateStatus(upsertParty, recToDelAddrMap, MDMAttributeNames.ADDRESS_BO, siperianClient);
			}

			perfLog.printLog(Constant.PERF_LOG_FLOW_UPSERT_FNO, upsertParty.getXREF().get(0).getSRCPKEY(), "STEP 3",
					"Executed the logics before cleansePut processes start");

			lastUpdateDate = Util.getCurrentTimeZone();
			// Create Party
			putRespDataParty = cleansePutParty(partyParam, siperianClient);
			perfLog.printLog(Constant.PERF_LOG_FLOW_UPSERT_FNO, upsertParty.getXREF().get(0).getSRCPKEY(), "STEP 4",
					"cleansePut Party Done");
			// Create Account
			if (partyParam.getAccount() != null) {
				putRespDataAccountList = cleansePutAccount(partyParam.getAccount(), partyParam, siperianClient);
				perfLog.printLog(Constant.PERF_LOG_FLOW_UPSERT_FNO, upsertParty.getXREF().get(0).getSRCPKEY(),
						"STEP 5", "cleansePut Account Done");
			} else {
				perfLog.printLog(Constant.PERF_LOG_FLOW_UPSERT_FNO, upsertParty.getXREF().get(0).getSRCPKEY(),
						"STEP 5", "cleansePut Account Skipped");
			}
			// Create Address
			if (partyParam.getAddress() != null) {
				putRespDataAddressList = cleansePutAddress(partyParam.getAddress(), partyParam, siperianClient);
				perfLog.printLog(Constant.PERF_LOG_FLOW_UPSERT_FNO, upsertParty.getXREF().get(0).getSRCPKEY(),
						"STEP 6", "cleansePut Address Done");
			} else {
				perfLog.printLog(Constant.PERF_LOG_FLOW_UPSERT_FNO, upsertParty.getXREF().get(0).getSRCPKEY(),
						"STEP 6", "cleansePut Address Skipped");
			}
			
			LOG.info("Control back in processCleansePut().");

			// commit transaction
			transaction.commit();
			perfLog.printLog(Constant.PERF_LOG_FLOW_UPSERT_FNO, upsertParty.getXREF().get(0).getSRCPKEY(), "STEP 9",
					"cleansePut Commit Done");
			LOG.info("Transaction Commited in processCleansePut().");
			partyCount++;

			// set response status
			upsertPartyResponse.setStatus(upsertPartyResponse.getStatus() == null ? "" : "\n");
			upsertPartyResponse.setStatus(upsertPartyResponse.getStatus() + putRespDataParty.getActionType()
					+ " operation successful for Party " + putRespDataParty.getSourceKey());

		} catch (ServiceProcessingException excp) {
			boolean isDataError = commonUtil.fetchErrorMsg(excp.getRootExceptionMsg());
			upsertPartyResponse.setErrorMsg(excp.getRootExceptionMsg());
			upsertParty.setErrorMsg("CleansePut operation failed");
			if(isDataError){
				commonUtil.updateErrorStatus(upsertParty, upsertPartyResponse, Constant.ERROR_LOV_LOOKUP_FAILED, "0");
			}else{
				commonUtil.updateErrorStatus(upsertParty, upsertPartyResponse, Constant.ERROR_ACC_EXT_ACC_PUT_FAIL, "0");	
			}
			LOG.error("Exception occured while preparing/processing cleansePut requests: ", excp);
			try {
				transaction.rollback();

			} catch (SystemException txExcp) {
				LOG.error("Failed to rollback transaction for cleansePut requests : " + txExcp.toString());
			}
			throw excp;
		} catch (Exception ex) {
			upsertPartyResponse.setErrorMsg("CleansePut operation failed for Party " + putRespDataParty.getSourceKey());
			upsertParty.setErrorMsg("CleansePut operation failed");
			commonUtil.updateErrorStatus(upsertParty, upsertPartyResponse, Constant.ERROR_ACC_EXT_ACC_PUT_FAIL, "0");
			LOG.error("Exception occured while preparing/processing cleansePut requests: ", ex);
			ex.printStackTrace();
			try {
				transaction.rollback();
			} catch (SystemException txExcp) {
				LOG.error("Failed to rollback transaction for cleansePut requests : " + txExcp.toString());
				txExcp.printStackTrace();
			}
			ServiceProcessingException customException = new ServiceProcessingException(ex);
			customException.setMessage("Failed to process cleansePut SIF request." + customException.getMessage());
			// customException.printStackTrace();
			throw customException;
		} finally {
			checkIn(siperianClient);
		}
		try {
			// set rowid_object of created records into response and
			// set the PutResponseDataHolder object/list of object into Map
			// against corresponding entity name
			// set rowid_object of Party into response
			PartyUpsertRespType partyUpsertResp = new PartyUpsertRespType();
			Account account = null;
			List<Account> accountList = new ArrayList<Account>();
			Address address = null;
			List<Address> addressList = new ArrayList<Address>();

			// set rowid_object of Party into response
			if (putRespDataParty != null) {
				partyUpsertResp.setROWIDOBJECT(putRespDataParty.getRowidObject());
				partyUpsertResp.setSRCSYSTEM(putRespDataParty.getSystemName());
				partyUpsertResp.setSRCSYSTEMID(putRespDataParty.getSourceKey());
				putRespDataHolderMap.put(MDMAttributeNames.ENTITY_PARTY, putRespDataParty);
			}

			// set rowid_object of Account into response
			if (putRespDataAccountList != null) {
				putRespDataHolderMap.put(MDMAttributeNames.ENTITY_ACCOUNT, putRespDataAccountList);

				for (int index = 0; index < putRespDataAccountList.size(); index++) {

					account = new Account();
					/*if (partyParam.getAccount().get(0).getMDMLEGACYID() != null) {
						String mdmLegacyID = getMdmLegacyId(putRespDataAccountList.get(index).getSourceKey());
						account.setMDMLEGACYID(mdmLegacyID);
					}*/
					account.setROWIDACCOUNT(putRespDataAccountList.get(index).getRowidObject());
					account.setSRCSYSTEM(putRespDataAccountList.get(index).getSystemName());
					account.setSRCSYSTEMID(putRespDataAccountList.get(index).getSourceKey());
					accountList.add(account);

				}
				perfLog.printLog(Constant.PERF_LOG_FLOW_UPSERT_FNO, upsertParty.getXREF().get(0).getSRCPKEY(),
						"STEP 10", "MDM LegacyID get Done");
			} else {
				perfLog.printLog(Constant.PERF_LOG_FLOW_UPSERT_FNO, upsertParty.getXREF().get(0).getSRCPKEY(),
						"STEP 10", "MDM LegacyID get Skipped");
			}
			// set rowid_object of Address into response
			if (putRespDataAddressList != null) {
				putRespDataHolderMap.put(MDMAttributeNames.ENTITY_ADDRESS, putRespDataAddressList);

				for (int index = 0; index < putRespDataAddressList.size(); index++) {
					address = new Address();
					address.setROWIDADDRESS(putRespDataAddressList.get(index).getRowidObject());
					address.setSRCSYSTEM(putRespDataAddressList.get(index).getSystemName());
					address.setSRCSYSTEMID(putRespDataAddressList.get(index).getSourceKey());
					addressList.add(address);

				}
			}
			
			partyUpsertResp.getAccount().addAll(accountList);
			partyUpsertResp.getAddress().addAll(addressList);
			upsertPartyResponse.getParty().add(partyUpsertResp);

		} catch (Exception excp) {
			LOG.error("Exception occured while processing CleansePut response for Party "
					+ putRespDataParty.getSourceKey(), excp);
			ServiceProcessingException customException = new ServiceProcessingException(excp);
			customException.setMessage("Exception occured while processing CleansePut response for Party. "
					+ customException.getMessage());
			// throw customException;
		}

		if (executeNextStpe)
			upsertTokenize(upsertParty, upsertPartyResponse, true, true, rowidObject);

		LOG.info("Executed processCleansePutRequest()");
		return;
	}

	/**
	 * The method prepares and executes CleansePutRequest on PARTY landing table
	 * for the given Party profile.
	 *
	 * @param partyParam
	 *            Party profile provided to the web service request
	 * @param siperianClient
	 *            SiperianClient SIF connection to MDM Hub
	 * @return PutResponseDataHolder object containing processing results
	 * @throws ServiceProcessingException
	 */
	private PutResponseDataHolder cleansePutParty(PartyXrefType partyParam, SiperianClient siperianClient)
			throws ServiceProcessingException {
		LOG.info("Executing cleansePutParty()");
		int itemIndex = 0;
		CleansePutRequest cleansePutRequest = new CleansePutRequest();
		CleansePutResponse cleansePutResponse = null;
		PutResponseDataHolder responseDataHolder = null;
		try {

			// prepare CleansePutRequest
			Record record = new Record();
			// set mapping name
			record.setSiperianObjectUid(Util.getMappingObjectUid(partyParam.getXREF().get(itemIndex).getSRCSYSTEM(),
					MDMAttributeNames.ENTITY_PARTY));
			// set input values
			/*if (partyParam.getLASTUPDATEDATE() != null && partyParam.getLASTUPDATEDATE().length() > 0) {
				record.setField(new Field(MDMAttributeNames.LAST_UPDATE_DATE, partyParam.getLASTUPDATEDATE()));
			} else {
				LOG.info("Performing cleansePutParty with sysdate from HUB: " + lastUpdateDate);*/
			record.setField(new Field(MDMAttributeNames.LAST_UPDATE_DATE, lastUpdateDate));
			/*}*/

			if (partyParam.getSRCCREATEDT() != null && partyParam.getSRCCREATEDT().length() > 0) {
				record.setField(new Field(MDMAttributeNames.SRC_CREATE_DT, partyParam.getSRCCREATEDT()));
			}else{
				record.setField(new Field(MDMAttributeNames.SRC_CREATE_DT, lastUpdateDate));
			}
			record.setField(new Field(MDMAttributeNames.SRC_UPDT_BY, partyParam.getUPDATEBY()));
			String srcSystem = partyParam.getXREF().get(0).getSRCSYSTEM();
			record.setField(new Field(MDMAttributeNames.SRC_SYSTEM, srcSystem));
			record.setField(new Field(MDMAttributeNames.SRC_SYS_KEY, (partyParam.getXREF().get(itemIndex)).getSRCPKEY()));
			if (!Util.isNullOrEmpty(partyParam.getROWIDOBJECT())) {
				record.setField(new Field(MDMAttributeNames.ROWID_OBJECT, partyParam.getROWIDOBJECT()));
			}
			record.setField(new Field(PartyAttributes.ENTITY_TYPE, partyParam.getBOCLASSCODE()));
			record.setField(new Field(PartyAttributes.PARTY_NAME, partyParam.getPARTYNAME()));
			record.setField(new Field(PartyAttributes.PARTY_TYPE, partyParam.getPARTYTYPE()));
			record.setField(new Field(PartyAttributes.GEO, partyParam.getGEO()));
			record.setField(new Field(PartyAttributes.REGION, partyParam.getREGION()));
			record.setField(new Field(PartyAttributes.SALES_BLOCK_CD, partyParam.getSALESBLOCKCD()));
			record.setField(new Field(PartyAttributes.TAX_JURSDCTN_CD, partyParam.getTAXJURSDCTNCD()));
			record.setField(new Field(PartyAttributes.VAT_REG_NBR, partyParam.getVATREGNBR()));
			
			if(!Util.isNullOrEmpty(partyParam.getSTATUSCD())){
					record.setField(new Field(PartyAttributes.STATUS_CD, commonUtil.getStatusDesc(partyParam.getSTATUSCD())));
			}
			if (!Util.isNullOrEmpty(partyParam.getUCN())) {
				record.setField(new Field(PartyAttributes.UCN, partyParam.getUCN()));
			}
			
			if ((!Util.isNullOrEmpty(partyParam.getAddress().get(0).getCOUNTRYCD())) && (!(partyParam.getAddress().get(0).getCOUNTRYCD().length() > 2))) {
				
				record.setField(new Field(PartyAttributes.COUNTRY_CD, getFNOCountryName(partyParam.getAddress().get(0).getCOUNTRYCD())));
			}
			else{
				record.setField(new Field(PartyAttributes.COUNTRY_CD, partyParam.getAddress().get(0).getCOUNTRYCD()));
			}
			record.setField(new Field(PartyAttributes.MSG_TRKN_ID, partyParam.getMSGTRKNID()));
			//record.setField(new Field(PartyAttributes.DRAFT_FLG, partyParam.getAccount().get(0).getDraftAccountFlag()));
			LOG.info("selfMatchFail::"+selfMatchFail);
			if(selfMatchFail){
				record.setField(new Field(PartyAttributes.PROCESS_STATE_IND, Constant.SEND_FOR_DNB));
			}
			record.setField(new Field(PartyAttributes.DO_NOT_MERGE, partyParam.getDONOTMERGE()));
			/** changes for Sales Force Integration -End */
			cleansePutRequest.setRecord(record);
			// execute Put request
			cleansePutResponse = (CleansePutResponse) siperianClient.process(cleansePutRequest);
			LOG.info("Party cleansePut request processed successfully: " + cleansePutResponse.getMessage());
			// extract result
			RecordKey recordKey = cleansePutResponse.getRecordKey();

			responseDataHolder = new PutResponseDataHolder();
			responseDataHolder.setActionType(cleansePutResponse.getActionType());
			responseDataHolder.setActionMessage(cleansePutResponse.getMessage());
			responseDataHolder.setRowidObject(recordKey.getRowid());
			responseDataHolder.setRowidXREF(recordKey.getRowidXref());
			responseDataHolder.setSourceKey(recordKey.getSourceKey());
			responseDataHolder.setSystemName(recordKey.getSystemName());
			LOG.info("ROWID_OBJECT of created Party record = " + recordKey.getRowid());

			LOG.debug("Action Type = " + responseDataHolder.getActionType());
			LOG.debug("Action Msg = " + responseDataHolder.getActionMessage());
			LOG.debug("Rowid_xref = " + responseDataHolder.getRowidXREF());
			LOG.debug("Src key = " + responseDataHolder.getSourceKey());
			LOG.debug("System = " + responseDataHolder.getSystemName());

		} catch (SiperianServerException sifExcp) {
			LOG.error("SiperianServerException occured while processing CleansePutRequest for Party: ", sifExcp);
			LOG.error("Get Message: " + sifExcp.getMessage());
			LOG.error("sifExcp msg " + sifExcp);
			sifExcp.printStackTrace();
			ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
			customException.setRootExceptionMsg(sifExcp + " CleansePut operation failed for Party "
					+ (partyParam.getXREF().get(itemIndex)).getSRCPKEY());
			customException.setMessage(
					"SIF exception occured while processing Put request for Party." + customException.getMessage());
			throw customException;
		} catch (Exception excp) {
			LOG.error("Exception occured while processing CleansePutRequest for Party: ", excp);
			LOG.error("excp msg " + excp);
			ServiceProcessingException customException = new ServiceProcessingException(excp);
			customException.setMessage(
					"Exception occured while processing Put request for Party." + customException.getMessage());
			customException.setRootExceptionMsg(excp + " CleansePut operation failed for Party "
					+ (partyParam.getXREF().get(itemIndex)).getSRCPKEY());
			throw customException;
		}

		LOG.info("Executed cleansePutParty()");
		return responseDataHolder;
	}

	/**
	 * The method prepares and executes CleansePutRequest on ACCOUNT landing
	 * table for the given Account profiles.
	 *
	 * @param addressList
	 *            List of Accounts provided to the web service request
	 * @param partyParam
	 *            Party profile provided to the web service request
	 * @param siperianClient
	 *            SiperianClient SIF connection to MDM Hub
	 * @return List of PutResponseDataHolder object containing processing
	 *         results
	 * @throws ServiceProcessingException
	 */
	private List<PutResponseDataHolder> cleansePutAccount(List<AccountXrefType> accountList, PartyXrefType partyParam,
			SiperianClient siperianClient) throws ServiceProcessingException {
		LOG.info("Executing cleansePutAccount()");
		int itemIndex = 0;
		CleansePutRequest cleansePutRequest = null;
		CleansePutResponse cleansePutResponse = null;
		List<PutResponseDataHolder> responseDataHolderList = new ArrayList<PutResponseDataHolder>(accountList.size());
		AccountXrefType accountParam = null;

		try {
			for (itemIndex = 0; itemIndex < accountList.size(); itemIndex++) {
				cleansePutRequest = new CleansePutRequest();
				accountParam = accountList.get(itemIndex);
				// prepare CleansePutRequest
				Record record = new Record();
				// set mapping name
				String srcSystem = partyParam.getAccount().get(itemIndex).getSRCSYSTEM();
				String partyType = partyParam.getPARTYTYPE().trim();
				LOG.info("partyType::"+partyType);
				if(Util.isNullOrEmpty(srcSystem)){
					srcSystem = Constant.SRC_SYSTEM_FNO;
				}
				
				record.setSiperianObjectUid(Util.getMappingObjectUid(srcSystem, MDMAttributeNames.ENTITY_ACCOUNT));
				// set input values
				/*if (partyParam.getLASTUPDATEDATE() != null && partyParam.getLASTUPDATEDATE().length() > 0) {
					record.setField(new Field(MDMAttributeNames.LAST_UPDATE_DATE, partyParam.getLASTUPDATEDATE()));
				} else {
					LOG.info("Performing cleansePutAccount with sysdate from HUB: " + lastUpdateDate);
					record.setField(new Field(MDMAttributeNames.LAST_UPDATE_DATE, lastUpdateDate));
				}*/
				record.setField(new Field(MDMAttributeNames.LAST_UPDATE_DATE, lastUpdateDate));
				record.setField(new Field(MDMAttributeNames.SRC_UPDT_BY, accountParam.getUPDATEBY()));
				record.setField(new Field(MDMAttributeNames.SRC_SYSTEM, srcSystem));
				record.setField(new Field(MDMAttributeNames.SRC_SYS_KEY, accountParam.getSRCPKEY()));
				record.setField(new Field(AccountAttributes.ACCOUNT_GEO, accountParam.getACCOUNTGEO()));
				record.setField(new Field(AccountAttributes.ACCOUNT_REGION, accountParam.getACCOUNTREGION()));
				record.setField(new Field(AccountAttributes.ACCOUNT_TAX_JURSDCTN_CD, accountParam.getACCOUNTTAXJURSDCTNCD()));
				record.setField(new Field(AccountAttributes.ACCOUNT_VAT_REG_NBR, accountParam.getACCOUNTVATREGNBR()));
				record.setField(new Field(AccountAttributes.NAME_QUALITY_IDENTIFIER, accountParam.getNAMEQUALITYIDENTIFIER()));
				record.setField(new Field(AccountAttributes.IS_DENIED_FLG, accountParam.getISDENIEDFLG()));
				LOG.debug("ACCOUNT_VAT_REG_NBR : " + accountParam.getACCOUNTVATREGNBR());
				record.setField(new Field(AccountAttributes.ACCT_NAME, partyParam.getPARTYNAME()));
				
				if(!Util.isNullOrEmpty(accountParam.getACCTSTATUS())){
					record.setField(new Field(AccountAttributes.ACCT_STATUS, commonUtil.getStatusDesc(accountParam.getACCTSTATUS())));
				}
				
				record.setField(new Field(AccountAttributes.ACCT_TYPE, accountParam.getACCTTYPE()));
				record.setField(new Field(AccountAttributes.ALIAS_NAME, accountParam.getALIASNAME()));
				record.setField(new Field(AccountAttributes.BILL_BLOCK_CD, accountParam.getBILLBLOCKCD()));
				record.setField(new Field(AccountAttributes.CHANNEL_ID, accountParam.getCHANNELID()));
				record.setField(new Field(AccountAttributes.COMPANY_CD, accountParam.getCOMPANYCD()));
				String custGroup = "";
				if(Constant.PARTY_TYPE_CUSTOMER.equalsIgnoreCase(partyType)){
					custGroup = Constant.PARTY_TYPE_CUSTOMER;
				}
				else if(Constant.PARTY_TYPE_RESELLER.equalsIgnoreCase(partyType)){
					custGroup = Constant.PARTY_TYPE_RESELLER;
				}
				else if(Constant.PARTY_TYPE_DISTRIBUTOR.equalsIgnoreCase(partyType)){
					custGroup = Constant.PARTY_TYPE_DISTRIBUTOR;
				}
				
				LOG.info("custGroup::"+custGroup);
				record.setField(new Field(AccountAttributes.CUST_GROUP, custGroup));
				
				record.setField(new Field(AccountAttributes.DIRECT_IND, accountParam.getDIRECTIND()));
				record.setField(new Field(AccountAttributes.DLVRY_BLOCK_CD, accountParam.getDLVRYBLOCKCD()));
				record.setField(new Field(AccountAttributes.MARKET, accountParam.getMARKET()));
				record.setField(new Field(AccountAttributes.NAMED_ACCT_IND, accountParam.getNAMEDACCTIND()));
				record.setField(new Field(AccountAttributes.NON_VAL_ACCT_IND, accountParam.getNONVALACCTIND()));
				record.setField(new Field(AccountAttributes.ORDR_BLOCK_CD, accountParam.getORDRBLOCKCD()));
				record.setField(new Field(AccountAttributes.PARTNER_IND, accountParam.getPARTNERIND()));
				record.setField(new Field(AccountAttributes.PARTNER_TYPE, accountParam.getPARTNERTYPE()));
				record.setField(new Field(AccountAttributes.POST_BLOCK_CD, accountParam.getPOSTBLOCKCD()));
				record.setField(new Field(AccountAttributes.PRICE_GROUP, accountParam.getPRICEGROUP()));
				record.setField(new Field(AccountAttributes.SALE_BLOCK_CD, accountParam.getSALEBLOCKCD()));
				record.setField(new Field(AccountAttributes.TAX_TYPE, accountParam.getTAXTYPE()));
				record.setField(new Field(AccountAttributes.VENDOR_NBR, accountParam.getVENDORNBR()));
				// Do not overwrite SBL_Rowid with null
				if (!Util.isNullOrEmpty(accountParam.getSIEBELROWID())) {
					record.setField(new Field(AccountAttributes.SIEBEL_ROWID, accountParam.getSIEBELROWID()));
				}
				// Do not overwrite SAP_Cust_Nbr with null
				if (!Util.isNullOrEmpty(accountParam.getSAPCUSTNUMBER())) {
					record.setField(new Field(AccountAttributes.SAP_CUST_NUMBER, accountParam.getSAPCUSTNUMBER()));
				}
				
				record.setField(new Field(AccountAttributes.DATA_SRC_SYSTEM, accountParam.getDATASRCSYSTEM()));
				record.setField(new Field(AccountAttributes.SAP_NAME_1, accountParam.getSAPNAME1()));
				record.setField(new Field(AccountAttributes.SAP_NAME_2, accountParam.getSAPNAME2()));
				record.setField(new Field(AccountAttributes.SAP_NAME_3, accountParam.getSAPNAME3()));
				record.setField(new Field(AccountAttributes.SAP_NAME_4, accountParam.getSAPNAME4()));

				/** Modified for SFDC START */
				record.setField(new Field(AccountAttributes.SFID, accountParam.getSalesForceID()));
				record.setField(new Field(AccountAttributes.DRAFT_FLG, accountParam.getDraftAccountFlag()));
				/** Modified for SFDC END */
				/** changes for Sales Force Integration -Start */
				record.setField(new Field(AccountAttributes.LOCAL_NAME, accountParam.getLOCALNAME()));
				record.setField(new Field(AccountAttributes.CURRENCY_CD, accountParam.getCURRENCYCD()));
				record.setField(new Field(AccountAttributes.TAX_ID, accountParam.getTAXID()));
				record.setField(new Field(AccountAttributes.PRICING_BAND_AGRMNT, accountParam.getPRICEBANDAGGREMENT()));
				/** changes for Sales Force Integration -End */
				/** changes for Track-2 -Start */
				record.setField(new Field(AccountAttributes.SITE_DESIGNATION, accountParam.getSITEDESIGNATION()));
				/** changes for Track-2 -End */
				record.setField(new Field(MDMAttributeNames.PARTY_SRC_SYS_KEY, partyParam.getXREF().get(0).getSRCPKEY()));

				/** changes for Track-3 -Start */
				record.setField(new Field(AccountAttributes.CLEANSE_IND, accountParam.getCLEANSEIND()));
				record.setField(new Field(AccountAttributes.RESELL_LEVEL, accountParam.getRESELLLEVEL()));
				if (!Util.isNullOrEmpty(accountParam.getPARTNERSHIPSTATUS())) {
					record.setField(
							new Field(AccountAttributes.PARTNERSHIP_STATUS, accountParam.getPARTNERSHIPSTATUS()));
				}
				/** changes for Track-3 -End */

				cleansePutRequest.setRecord(record);
				LOG.info("Account cleansePut request NAME_QUALITY_IDENTIFIER : "
						+ accountParam.getNAMEQUALITYIDENTIFIER());
				// execute Put request
				cleansePutResponse = (CleansePutResponse) siperianClient.process(cleansePutRequest);
				LOG.info("Account cleansePut request processed successfully: " + cleansePutResponse.getMessage());
				// extract result
				RecordKey recordKey = cleansePutResponse.getRecordKey();

				PutResponseDataHolder responseDataHolder = new PutResponseDataHolder();
				responseDataHolder.setActionType(cleansePutResponse.getActionType());
				responseDataHolder.setActionMessage(cleansePutResponse.getMessage());
				responseDataHolder.setRowidObject(recordKey.getRowid());
				responseDataHolder.setRowidXREF(recordKey.getRowidXref());
				responseDataHolder.setSourceKey(recordKey.getSourceKey());
				responseDataHolder.setSystemName(recordKey.getSystemName());
				responseDataHolderList.add(responseDataHolder);
				LOG.info("ROWID_OBJECT of created Account record = " + recordKey.getRowid());
				LOG.debug("Action Type = " + responseDataHolder.getActionType());
				LOG.debug("Action Msg = " + responseDataHolder.getActionMessage());
			}
		} catch (SiperianServerException sifExcp) {
			LOG.error("SiperianServerException occured while processing CleansePutRequest for Account: " + sifExcp);
			LOG.error("Root Cause: " + sifExcp.getCause().getMessage());
			LOG.error("msg ", sifExcp);
			sifExcp.printStackTrace();
			ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
			customException.setMessage(
					"SIF exception occured while processing Put request for Account. " + customException.getMessage());
			customException.setRootExceptionMsg(
					sifExcp + " CleansePut operation failed for Account " + accountParam.getSRCPKEY());
			throw customException;
		} catch (Exception excp) {
			LOG.error("Exception occured while processing CleansePutRequest for Party: " + excp);
			excp.printStackTrace();
			ServiceProcessingException customException = new ServiceProcessingException(excp);
			customException.setMessage(
					"Exception occured while processing Put request for Account. " + customException.getMessage());
			customException.setRootExceptionMsg(
					excp + " CleansePut operation failed for Account " + accountParam.getSRCPKEY());
			throw customException;
		}

		LOG.info("Executed cleansePutAccount()");
		return responseDataHolderList;
	}

	/**
	 * The method prepares and executes CleansePutRequest on ADDRESS landing
	 * table for the given Address profiles.
	 *
	 * @param addressList
	 *            List of Addresses provided to the web service request
	 * @param partyParam
	 *            Party profile provided to the web service request
	 * @param siperianClient
	 *            SiperianClient SIF connection to MDM Hub
	 * @return List of PutResponseDataHolder object containing processing
	 *         results
	 * @throws ServiceProcessingException
	 */
	private List<PutResponseDataHolder> cleansePutAddress(List<AddressXrefType> addressList, PartyXrefType partyParam,
			SiperianClient siperianClient) throws ServiceProcessingException {
		LOG.info("Executing cleansePutAddress()");
		int itemIndex = 0;
		CleansePutRequest cleansePutRequest = null;
		CleansePutResponse cleansePutResponse = null;
		List<PutResponseDataHolder> responseDataHolderList = new ArrayList<PutResponseDataHolder>(addressList.size());
		AddressXrefType addressParam = null;

		try {
			for (itemIndex = 0; itemIndex < addressList.size(); itemIndex++) {
				cleansePutRequest = new CleansePutRequest();
				addressParam = addressList.get(itemIndex);
				// prepare CleansePutRequest
				Record record = new Record();
				
				String srcSystem = addressParam.getSRCSYSTEM();
				
				if(Util.isNullOrEmpty(srcSystem)){
					srcSystem = Constant.SRC_SYSTEM_FNO;
				}
				// set mapping name
				record.setSiperianObjectUid(Util.getMappingObjectUid(srcSystem, MDMAttributeNames.ENTITY_ADDRESS));
				// set input values
				/*if (partyParam.getLASTUPDATEDATE() != null && partyParam.getLASTUPDATEDATE().length() > 0) {
					record.setField(new Field(MDMAttributeNames.LAST_UPDATE_DATE, partyParam.getLASTUPDATEDATE()));
				} else {
					LOG.info("Performing cleansePutAddress with sysdate from HUB: " + lastUpdateDate);
					record.setField(new Field(MDMAttributeNames.LAST_UPDATE_DATE, lastUpdateDate));
				}*/
				record.setField(new Field(MDMAttributeNames.LAST_UPDATE_DATE, lastUpdateDate));
				record.setField(new Field(MDMAttributeNames.SRC_UPDT_BY, addressParam.getUPDATEBY()));
				record.setField(new Field(MDMAttributeNames.SRC_SYSTEM, srcSystem));
				record.setField(new Field(MDMAttributeNames.SRC_SYS_KEY, addressParam.getSRCPKEY()));
				record.setField(new Field(AddressAttributes.ADDR_LN1, addressParam.getADDRLN1()));
				record.setField(new Field(AddressAttributes.ADDR_LN2, addressParam.getADDRLN2()));
				record.setField(new Field(AddressAttributes.ADDR_LN3, addressParam.getADDRLN3()));
				record.setField(new Field(AddressAttributes.ADDR_LN4, addressParam.getADDRLN4()));
				if(!Util.isNullOrEmpty(addressParam.getADDRSTATUS())){
					record.setField(new Field(AddressAttributes.ADDR_STATUS, commonUtil.getStatusDesc(addressParam.getADDRSTATUS())));
				}
				record.setField(new Field(AddressAttributes.ADDR_TYPE, Constant.ADDRESS_TYPE_BILLING));				
				record.setField(new Field(AddressAttributes.CITY, addressParam.getCITY()));
				LOG.debug("addressParam.getCOUNTRYCD(): " + addressParam.getCOUNTRYCD());
			//	LOG.debug("Set in MDM mapping addressParam.getCOUNTRYCD(): " + getSFDCCountryCName(addressParam.getCOUNTRYCD()));
				if ((!Util.isNullOrEmpty(addressParam.getCOUNTRYCD())) && (!(addressParam.getCOUNTRYCD().length() > 2))) {
					
					record.setField(new Field(AddressAttributes.COUNTRY_CD, getFNOCountryName(addressParam.getCOUNTRYCD())));
				}
				else{
					record.setField(new Field(AddressAttributes.COUNTRY_CD, addressParam.getCOUNTRYCD()));
				}
				
				record.setField(new Field(AddressAttributes.COUNTY, addressParam.getCOUNTY()));
				record.setField(new Field(AddressAttributes.DISTRICT, addressParam.getDISTRICT()));
				record.setField(new Field(AddressAttributes.LANG_CD, addressParam.getLANGCD()));
				record.setField(new Field(AddressAttributes.LATITUDE, addressParam.getLATITUDE()));
				record.setField(new Field(AddressAttributes.LONGITUDE, addressParam.getLONGITUDE()));
				record.setField(new Field(AddressAttributes.POSTAL_CD, addressParam.getPOSTALCD()));
				LOG.debug("addressParam.getSTATECD(): " + addressParam.getSTATECD());
				String stateCode = addressParam.getSTATECD();
				if(!Util.isNullOrEmpty(stateCode)){
					if(!Util.isNullOrEmpty(addressParam.getCOUNTRYCD()) && ("CN".equalsIgnoreCase(addressParam.getCOUNTRYCD()) ||  "CHINA".equalsIgnoreCase(addressParam.getCOUNTRYCD()))){
						stateCode = stateCode.toUpperCase();
					}
				}
				record.setField(new Field(AddressAttributes.STATE_CD, stateCode));
				
				record.setField(new Field(MDMAttributeNames.PARTY_SRC_SYS_KEY, partyParam.getXREF().get(0).getSRCPKEY()));
				record.setField(new Field(AddressAttributes.ADDRESS_QUALITY_IDENTIFIER,addressParam.getADDRESSQUALITYIDENTIFIER()));
				// Added for SFDC Integration-- Start
				//record.setField(new Field(AddressAttributes.ADDRESS_DRAFT_FLAG,partyParam.getAccount().get(0).getDraftAccountFlag()));
				
				cleansePutRequest.setRecord(record);
				// execute Put request
				cleansePutResponse = (CleansePutResponse) siperianClient.process(cleansePutRequest);
				LOG.info("Address cleansePut request processed successfully: " + cleansePutResponse.getMessage());
				// extract result
				RecordKey recordKey = cleansePutResponse.getRecordKey();

				PutResponseDataHolder responseDataHolder = new PutResponseDataHolder();
				responseDataHolder.setActionType(cleansePutResponse.getActionType());
				responseDataHolder.setActionMessage(cleansePutResponse.getMessage());
				responseDataHolder.setRowidObject(recordKey.getRowid());
				responseDataHolder.setRowidXREF(recordKey.getRowidXref());
				responseDataHolder.setSourceKey(recordKey.getSourceKey());
				responseDataHolder.setSystemName(recordKey.getSystemName());
				responseDataHolderList.add(responseDataHolder);
				LOG.info("ROWID_OBJECT of created Address record = " + recordKey.getRowid());
				LOG.debug("Action Type = " + responseDataHolder.getActionType());
				LOG.debug("Action Msg = " + responseDataHolder.getActionMessage());
			}
		} catch (SiperianServerException sifExcp) {
			LOG.error("SiperianServerException occured while processing CleansePutRequest for Address: " + sifExcp);
			sifExcp.printStackTrace();
			ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
			customException.setMessage(
					"SIF exception occured while processing Put request for Address. " + customException.getMessage());
			customException.setRootExceptionMsg(
					sifExcp + " CleansePut operation failed for Address " + addressParam.getSRCPKEY());
			throw customException;
		} catch (Exception excp) {
			LOG.error("Exception occured while processing CleansePutRequest for Address: " + excp);
			excp.printStackTrace();
			ServiceProcessingException customException = new ServiceProcessingException(excp);
			customException.setMessage(
					"Exception occured while processing Put request for Address. " + customException.getMessage());
			customException.setRootExceptionMsg(
					excp + " CleansePut operation failed for Address " + addressParam.getSRCPKEY());
			throw customException;
		}

		LOG.info("Executed cleansePutAddress()");
		return responseDataHolderList;
	}

	/**
	 * The method prepares and executes CleansePutRequest on COMMUNICATION
	 * landing table for the given Communication profiles.
	 *
	 * @param commList
	 *            List of Communications provided to the web service request
	 * @param partyParam
	 *            Party profile provided to the web service request
	 * @param siperianClient
	 *            SiperianClient SIF connection to MDM Hub
	 * @return List of PutResponseDataHolder object containing processing
	 *         results
	 * @throws ServiceProcessingException
	 */
	private List<PutResponseDataHolder> cleansePutCommunication(List<CommunicationXrefType> commList,
			PartyXrefType partyParam, SiperianClient siperianClient) throws ServiceProcessingException {
		LOG.info("Executing cleansePutCommunication()");
		int itemIndex = 0;
		CleansePutRequest cleansePutRequest = null;
		CleansePutResponse cleansePutResponse = null;
		List<PutResponseDataHolder> responseDataHolderList = new ArrayList<PutResponseDataHolder>(commList.size());
		CommunicationXrefType commParam = null;

		try {
			for (itemIndex = 0; itemIndex < commList.size(); itemIndex++) {
				cleansePutRequest = new CleansePutRequest();
				commParam = commList.get(itemIndex);
				// prepare CleansePutRequest
				Record record = new Record();
				
				String srcSystem = commParam.getSRCSYSTEM();
				
				if(Util.isNullOrEmpty(srcSystem)){
					srcSystem = Constant.SRC_SYSTEM_FNO;
				}
				
				// set mapping name
				record.setSiperianObjectUid(
						Util.getMappingObjectUid(commParam.getSRCSYSTEM(), MDMAttributeNames.ENTITY_COMM));
				// set input values
				if (partyParam.getLASTUPDATEDATE() != null && partyParam.getLASTUPDATEDATE().length() > 0) {
					record.setField(new Field(MDMAttributeNames.LAST_UPDATE_DATE, partyParam.getLASTUPDATEDATE()));
				} else {
					LOG.info("Performing cleansePutCommunication with sysdate from HUB: " + lastUpdateDate);
					record.setField(new Field(MDMAttributeNames.LAST_UPDATE_DATE, lastUpdateDate));
				}
				record.setField(new Field(MDMAttributeNames.SRC_UPDT_BY, commParam.getUPDATEBY()));
				record.setField(new Field(MDMAttributeNames.SRC_SYSTEM, srcSystem));
				record.setField(new Field(MDMAttributeNames.SRC_SYS_KEY, commParam.getSRCPKEY()));
				record.setField(new Field(CommunicationAttributes.COMM_STATUS, commParam.getCOMMSTATUS()));
				if (commParam.getCOMMTYPE() != null && commParam.getCOMMTYPE().length() > 0) {
					record.setField(new Field(CommunicationAttributes.COMM_TYPE, commParam.getCOMMTYPE()));
				}
				record.setField(new Field(CommunicationAttributes.COMM_VALUE, commParam.getCOMMVALUE()));
				record.setField(new Field(CommunicationAttributes.PRFRD_COMM_IND, commParam.getPRFRDCOMMIND()));
				record.setField(new Field(CommunicationAttributes.WEB_DOMAIN, commParam.getWEBDOMAIN()));
				record.setField(
						new Field(MDMAttributeNames.PARTY_SRC_SYS_KEY, partyParam.getXREF().get(0).getSRCPKEY()));
				// Added for SFDC Integration-- Start
				record.setField(new Field(CommunicationAttributes.COMM_DRAFT_FLAG,
						partyParam.getAccount().get(0).getDraftAccountFlag()));
				// Added for SFDC Integration-- End
				cleansePutRequest.setRecord(record);
				// execute Put request
				cleansePutResponse = (CleansePutResponse) siperianClient.process(cleansePutRequest);
				LOG.info("Communication cleansePut request processed successfully: " + cleansePutResponse.getMessage());
				// extract result
				RecordKey recordKey = cleansePutResponse.getRecordKey();

				PutResponseDataHolder responseDataHolder = new PutResponseDataHolder();
				responseDataHolder.setActionType(cleansePutResponse.getActionType());
				responseDataHolder.setActionMessage(cleansePutResponse.getMessage());
				responseDataHolder.setRowidObject(recordKey.getRowid());
				responseDataHolder.setRowidXREF(recordKey.getRowidXref());
				responseDataHolder.setSourceKey(recordKey.getSourceKey());
				responseDataHolder.setSystemName(recordKey.getSystemName());
				responseDataHolderList.add(responseDataHolder);
				LOG.info("ROWID_OBJECT of created Communication record = " + recordKey.getRowid());
				LOG.debug("Action Type = " + responseDataHolder.getActionType());
				LOG.debug("Action Msg = " + responseDataHolder.getActionMessage());
			}
		} catch (SiperianServerException sifExcp) {
			LOG.error(
					"SiperianServerException occured while processing CleansePutRequest for Communication: " + sifExcp);
			LOG.error("sifExcp msg " + sifExcp);
			ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
			customException.setMessage("SIF exception occured while processing Put request for Communication. "
					+ customException.getMessage());
			customException.setRootExceptionMsg(
					sifExcp + " CleansePut operation failed for Communication " + commParam.getSRCPKEY());
			sifExcp.printStackTrace();
			throw customException;
		} catch (Exception excp) {
			LOG.error("Exception occured while processing CleansePutRequest for Communication: " + excp);
			excp.printStackTrace();
			ServiceProcessingException customException = new ServiceProcessingException(excp);
			customException.setMessage("Exception occured while processing Put request for Communication. "
					+ customException.getMessage());
			customException.setRootExceptionMsg(
					excp + " CleansePut operation failed for Communication " + commParam.getSRCPKEY());
			excp.printStackTrace();
			throw customException;
		}

		LOG.info("Executed cleansePutCommunication()");
		return responseDataHolderList;
	}

	/**
	 * The method prepares and executes CleansePutRequest on
	 * PARTY_CLASSIFICATION landing table for the given Party_Classification
	 * profiles.
	 *
	 * @param commList
	 *            List of Party_Classification provided to the web service
	 *            request
	 * @param partyParam
	 *            Party profile provided to the web service request
	 * @param siperianClient
	 *            SiperianClient SIF connection to MDM Hub
	 * @return List of PutResponseDataHolder object containing processing
	 *         results
	 * @throws ServiceProcessingException
	 */
	private List<PutResponseDataHolder> cleansePutClassification(Map<String, List> existingClassPkeyMap,
			List<ClassificationXrefType> classificationList, PartyXrefType partyParam, SiperianClient siperianClient,
			boolean isSAPDummyUpdate) throws ServiceProcessingException {
		LOG.info("Executing cleansePutClassification()");
		int itemIndex = 0;
		CleansePutRequest cleansePutRequest = null;
		CleansePutResponse cleansePutResponse = null;
		List<PutResponseDataHolder> responseDataHolderList = new ArrayList<PutResponseDataHolder>(
				classificationList.size());
		ClassificationXrefType classifictnParam = null;

		try {
			for (itemIndex = 0; itemIndex < classificationList.size(); itemIndex++) {
				boolean isEndDateProvided = false;
				cleansePutRequest = new CleansePutRequest();
				classifictnParam = classificationList.get(itemIndex);
				// prepare CleansePutRequest				
				String srcSystem = classifictnParam.getSRCSYSTEM();
				if(Util.isNullOrEmpty(srcSystem)){
					srcSystem = Constant.SRC_SYSTEM_FNO;
				}
				Record record = new Record();
				// set mapping name
				record.setSiperianObjectUid(
						Util.getMappingObjectUid(srcSystem, MDMAttributeNames.ENTITY_CLASSIF));
				// set input values
				/*
				 * if (partyParam.getLASTUPDATEDATE() != null &&
				 * partyParam.getLASTUPDATEDATE().length() > 0) {
				 * record.setField(new Field(MDMAttributeNames.LAST_UPDATE_DATE,
				 * partyParam.getLASTUPDATEDATE())); } else {
				 */
				// for merge surviving record determination need to set sysdate
				// only
				LOG.info("Performing cleansePutClassification with sysdate from HUB: " + lastUpdateDate);
				record.setField(new Field(MDMAttributeNames.LAST_UPDATE_DATE, lastUpdateDate));
				// }
				record.setField(new Field(MDMAttributeNames.SRC_UPDT_BY, classifictnParam.getUPDATEBY()));
				record.setField(new Field(MDMAttributeNames.SRC_SYSTEM, srcSystem));
				record.setField(new Field(MDMAttributeNames.SRC_SYS_KEY, classifictnParam.getSRCPKEY()));
				if (classifictnParam.getCLASSIFICTNTYPE() != null
						&& classifictnParam.getCLASSIFICTNTYPE().length() > 1) {
					record.setField(new Field(ClassificationAttributes.CLASSIFICTN_TYPE,
							classifictnParam.getCLASSIFICTNTYPE()));
				}
				record.setField(
						new Field(ClassificationAttributes.CLASSIFICTN_VALUE, classifictnParam.getCLASSIFICTNVALUE()));
				if (classifictnParam.getENDDATE() != null && classifictnParam.getENDDATE().length() >= 1) {
				
					isEndDateProvided = true;
					LOG.debug("End_Date from payload is ignored.");
				}
				if (classifictnParam.getSTARTDATE() != null && classifictnParam.getSTARTDATE().length() >= 1) {
					LOG.debug("Start_Date from payload is ignored.");
				} 
					// if record exists with same pkey, do not set null
					// start_date, else set current date
				boolean isExistingActiveRec = false;
				boolean isExistingInactiveRec = false;
				boolean isupdateFromSAPRec = false;
				Calendar cal = null;
				String consSAPPkey = null;
				String costructedPkey = partyParam.getClassification().get(itemIndex).getSRCPKEY() + ":"
						+ partyParam.getClassification().get(itemIndex).getCLASSIFICTNTYPE() + ":"
						+ partyParam.getClassification().get(itemIndex).getCLASSIFICTNVALUE();
				LOG.debug("costructedPkey is: " + costructedPkey);

				// For SAP record checking for Update Event
				if (partyParam.getXREF().get(0).getSRCSYSTEM().equalsIgnoreCase("SAP") && !isSAPDummyUpdate) {
					consSAPPkey = partyParam.getClassification().get(itemIndex).getSRCPKEY() + ":"
							+ partyParam.getClassification().get(itemIndex).getCLASSIFICTNTYPE();
					LOG.debug("costructed_SAP_Pkey is: " + consSAPPkey);

					for (Entry<String, List> entry : existingClassPkeyMap.entrySet()) {
						LOG.debug("existingClassPkey: " + entry.getKey());
						if (entry.getKey().contains(consSAPPkey)) {
							LOG.debug("CLASSIFICATION Update from SAP is received");
							isupdateFromSAPRec = true;
							break;
						}
					}
				} else {
					// For non-SAP records
					for (Entry<String, List> entry : existingClassPkeyMap.entrySet()) {
						LOG.debug("existingClassPkey: " + entry.getKey());
						if (entry.getKey().contains(costructedPkey)) {
							LOG.debug("End_Date for matching existingClassPkey: " + entry.getValue().get(2).toString());
							if (entry.getValue().get(2).toString().contains("9999")) {// IF
																						// END_DATE
																						// =
																						// 31-DEC-9999
																						// -
																						// it's
																						// Active
																						// Record
								isExistingActiveRec = true;
								// Date startDate = null
								// convertStringToDate(entry.getValue().get(1),
								// startDate);
								cal = convertStringToCalendar(entry.getValue().get(1).toString());// START_DATE
								record.setField(new Field(ClassificationAttributes.START_DATE, cal.getTime()));
								LOG.debug("Existing active record found with START_DATE: " + cal.getTime()
										+ ", existingClassPkey: " + entry.getKey() + " will be updated");
								break;
							} else {
								LOG.debug("Existing record is in inactive status");
								isExistingInactiveRec = true;
							}

						}
					}
				}

				// If CLASSIFICATION Update came from SAP System then bypass
				// CleansePut operation for this classification record.
				if (isupdateFromSAPRec) {
					LOG.debug(
							"CLASSIFICATION Update came from SAP System, hence bypass CleansePut operation for this classification record.");
					continue; // loop for next classification record in payload
				}

				// 1. if existing active/inactive record not found set current
				// date as start date to create a new record,
				// 2. if existing inactive record found but no existing active
				// record and end date is not provided in payload,
				// set current date as start date to create a new record,
				// 3. if existing inactive record found but no existing active
				// record and end date is provided in payload, need not to do
				// any cleansePut
				if (!(isExistingActiveRec || isExistingInactiveRec)) {
					LOG.debug("costructedPkey is not within existingClassPkeyMap.");
					LOG.debug("Creating record with START_DATE: " + new Timestamp(lastUpdateDate.getTime()));
					record.setField(new Field(ClassificationAttributes.START_DATE, lastUpdateDate));
				} else if (isExistingInactiveRec && !isExistingActiveRec && !isEndDateProvided) {
					LOG.debug(
							"costructedPkey is matched with existing inactive record, no existing active record found, End_date is not provided");
					LOG.debug("Creating record with START_DATE with Timestamp: "
							+ new Timestamp(lastUpdateDate.getTime()));
					record.setField(new Field(ClassificationAttributes.START_DATE, lastUpdateDate));
				} else if (isExistingInactiveRec && !isExistingActiveRec && isEndDateProvided) {
					LOG.debug(
							"costructedPkey is matched with existing inactive record, no existing active record found, End_date is provided");
					LOG.info("CleansePut operation for classification record will be skipped");
					continue; // loop for next classification record in payload
				}

				// } //end of else
				record.setField(
						new Field(MDMAttributeNames.PARTY_SRC_SYS_KEY, partyParam.getXREF().get(0).getSRCPKEY()));

				cleansePutRequest.setRecord(record);
				// execute Put request
				cleansePutResponse = (CleansePutResponse) siperianClient.process(cleansePutRequest);
				LOG.info("Party_Classification cleansePut request processed successfully: "
						+ cleansePutResponse.getMessage());
				// extract result
				RecordKey recordKey = cleansePutResponse.getRecordKey();

				PutResponseDataHolder responseDataHolder = new PutResponseDataHolder();
				responseDataHolder.setActionType(cleansePutResponse.getActionType());
				responseDataHolder.setActionMessage(cleansePutResponse.getMessage());
				responseDataHolder.setRowidObject(recordKey.getRowid());
				responseDataHolder.setRowidXREF(recordKey.getRowidXref());
				responseDataHolder.setSourceKey(recordKey.getSourceKey());
				responseDataHolder.setSystemName(recordKey.getSystemName());
				responseDataHolderList.add(responseDataHolder);
				LOG.info("ROWID_OBJECT of created Party_Classification record = " + recordKey.getRowid());
				LOG.debug("Action Type = " + responseDataHolder.getActionType());
				LOG.debug("Action Msg = " + responseDataHolder.getActionMessage());
			}
		} catch (SiperianServerException sifExcp) {
			LOG.error("SiperianServerException occured while processing CleansePutRequest for Party_Classification: "
					+ sifExcp);
			LOG.error("Get Error Message in Classification: " + sifExcp.getMessage());
			LOG.error("sifExcp msg: ", sifExcp);
			ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
			customException.setMessage("SIF exception occured while processing Put request for Party_Classification. "
					+ customException.getMessage());
			customException.setRootExceptionMsg(
					sifExcp + " CleansePut operation failed for Party_Classification " + classifictnParam.getSRCPKEY());
			throw customException;
		} catch (Exception excp) {
			LOG.error("Exception occured while processing CleansePutRequest for Party_Classification: " + excp);
			LOG.error("sifExcp msg: ", excp);
			ServiceProcessingException customException = new ServiceProcessingException(excp);
			customException.setMessage("Exception occured while processing Put request for Party_Classification. "
					+ customException.getMessage());
			customException.setRootExceptionMsg(
					excp + " CleansePut operation failed for Party_Classification " + classifictnParam.getSRCPKEY());
			throw customException;
		}

		LOG.info("Executed cleansePutClassification()");
		return responseDataHolderList;
	}

	private String processMatchAndMergeParty(PartyXrefType partyTypeParam, int matchScoreThres,
			HighestScoreRecordHolder highestScoreRecordHoldertgt, String rowidIdPut, SiperianClient siperianClient)
			throws ServiceProcessingException {

		LOG.info("Executing processMatchAndMergeParty()");
		
		String sorceRowidObject = null;
		boolean isError = false;

		/** GTM Sprint#1 US335 */
		int matchCountOfRetry = Integer.parseInt(configProps.getProperty("NoOfRetries"));
		boolean isMatchRetrySuccess = false;
		List searchRecords = new ArrayList();
		/** GTM Sprint#1 US335 */
		// SiperianClient siperianClient = null;
		HighestScoreRecordHolder highestScoreRecordHolder = null;
		HighestScoreRecordHolder finalMatchedRecord = new HighestScoreRecordHolder();
		HashMap<Integer, HighestScoreRecordHolder> highestScoreRecordHolderMap = new HashMap<Integer, HighestScoreRecordHolder>();
		SearchMatchRequest searchMatchRequest = new SearchMatchRequest();
		SearchMatchResponse searchMatchResponse = null;
		List<Object> tempkeyList = new ArrayList<Object>();
		String putRowidObject = null;
		try {
			if (rowidIdPut != null) {
				putRowidObject = rowidIdPut;
			} else {
				putRowidObject = getRowidFromPkey(partyTypeParam.getXREF().get(0), "C_B_PARTY");
			}
			try {

				try {
					searchRecords = matchParty(partyTypeParam, siperianClient);

					LOG.debug("Party SearchMatch is successful !!");

				} catch (SiperianServerException sifExcp) {
					matchInd = false;
					LOG.error("SiperianServerException occured while processing SearchMatchRequest on PARTY_BO: ",
							sifExcp);
					for (int i = 0; i < matchCountOfRetry; i++) {
						try {
							LOG.debug("Retrying SearchMatchRequest process for " + (i + 1) + "th time");
							searchRecords = matchParty(partyTypeParam, siperianClient);
							LOG.debug("SearchMatchRequest on Party is successful on attempt no. " + (i + 1));
							isMatchRetrySuccess = true;
							matchInd = true;
							break;
						} catch (Exception ex) {
							LOG.error(
									"Exception occured in SearchMatchRequest RetryMechanism on attempt no. " + (i + 1));
							LOG.error(
									"SiperianServerException occured in SearchMatchRequest RetryMechanism on PARTY_BO");
						}
					}
					if (!isMatchRetrySuccess) {
						ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
						customException.setMessage(
								"SiperianServerException occured in SearchMatchRequest RetryMechanism on PARTY_BO: "
										+ customException.getMessage());
						throw customException;
					}
				} catch (Exception ex) {
					matchInd = false;
					LOG.error("Exception occured while processing SearchMatchRequest on PARTY_BO: ", ex);
					for (int i = 0; i < matchCountOfRetry; i++) {
						try {
							LOG.debug("Retrying SearchMatchRequest process for " + (i + 1) + "th time");
							matchParty(partyTypeParam, siperianClient);
							LOG.debug("SearchMatchRequest on Party is successful on attempt no. " + (i + 1));
							isMatchRetrySuccess = true;
							matchInd = true;
							break;
						} catch (Exception excp) {
							LOG.error(
									"Exception occured in SearchMatchRequest RetryMechanism on attempt no. " + (i + 1));
							LOG.error(
									"SiperianServerException occured in SearchMatchRequest RetryMechanism on PARTY_BO");
						}
					}
					if (!isMatchRetrySuccess) {
						ServiceProcessingException customException = new ServiceProcessingException(ex);
						customException.setMessage(
								"SiperianServerException occured in SearchMatchRequest RetryMechanism on PARTY_BO: "
										+ customException.getMessage());
						throw customException;
					}
				}

				
				
				// Store Match Score
				HashMap<Integer, Integer> matchScoreMap = new HashMap<Integer, Integer>();
				List<Integer> resultMatchScoreList = null;
				
				// Store Duns Number
				HashMap<Integer, Integer> dunsNbrMap = new HashMap<Integer, Integer>();
				List<Integer> dunsNbrMapList = null;

				HashMap<Integer, Long> ucnCustNumMap = new HashMap<Integer, Long>();
				List<Integer> ucnCustNumMapList = null;
				
				List<Integer> rowidList = null;
				boolean isAutoRuleMatched = false;
				String unmergeFlag = "N";
				String countryCode = partyTypeParam.getAddress().get(0).getCOUNTRYCD();
				if (searchRecords != null && searchRecords.size() > 0) {
					if ("Japan".equalsIgnoreCase(countryCode) || "JPN".equalsIgnoreCase(countryCode)
							|| "JP".equalsIgnoreCase(countryCode)) {
						for (Iterator iter = searchRecords.iterator(); iter.hasNext();) {
							isAutoRuleMatched = false;
							unmergeFlag = "N";

							Record record = (Record) iter.next();
							String matchInd = record.getField("DEFINITE_MATCH_IND").getStringValue();
							String rowidObjectMatched = record.getField("ROWID_OBJECT").getStringValue();
							LOG.debug("matchInd:::::" + matchInd + "isAutoRuleMatched:::" + isAutoRuleMatched +"  rowidObjectMatched" + rowidObjectMatched);
							if (!rowidObjectMatched.trim().equals(putRowidObject.trim())) {
							if (matchInd.equals("1")) {
								unmergeFlag = checkUnMergeByDS(rowidObjectMatched, putRowidObject);
								LOG.debug("Checking UNM By DS before merge process::"  + unmergeFlag);
								if (unmergeFlag.equalsIgnoreCase("N")){
								LOG.debug("Japan record matched with Auto rule, continuing merge process");
								isAutoRuleMatched = true;
								break;
							}
							}
							}
						}

						if (!isAutoRuleMatched) {
							for (Iterator iter = searchRecords.iterator(); iter.hasNext();) {
								Record record = (Record) iter.next();
								String matchInd = record.getField("DEFINITE_MATCH_IND").getStringValue();
								if (matchInd.equals("0")) {
									
									String rowidObjectMatched = record.getField("ROWID_OBJECT").getStringValue();
									String title ="Japan record matched with manual rule : " +putRowidObject.trim();
									String comment = "Japan record rowidobject: "+putRowidObject.trim()+" is matched with manual rule RowIdObject: "+rowidObjectMatched.trim();
									if (!rowidObjectMatched.trim().equals(putRowidObject.trim())) {
										unmergeFlag = checkUnMergeByDS(rowidObjectMatched, putRowidObject);
										LOG.debug("Checking UNM By DS before task create process::"  + unmergeFlag);
										if (unmergeFlag.equalsIgnoreCase("N")){
									processCreateTaskRequest(rowidObjectMatched,putRowidObject,"Merge",title,comment);
									mergeInd = false;
									return null;
									}
									}
								}

							}
							/*mergeInd = false;
							return null;*/

						}

					}
					for (Iterator iter = searchRecords.iterator(); iter.hasNext();) {
						Record record = (Record) iter.next();
						highestScoreRecordHolder = null;
						String recRowid = record.getField("ROWID_OBJECT").getStringValue().trim();
						putRowidObject = putRowidObject.trim();
						LOG.debug("recRowid: " + recRowid);
						LOG.debug("putRowidObject:  " + putRowidObject);
						// Excluding self-matching record
						if (!recRowid.equals(putRowidObject)) {
							LOG.debug("Matching recRowid: " + recRowid);
							int rowidKey = Integer.parseInt(recRowid);

							if (!highestScoreRecordHolderMap.containsKey(rowidKey)) {

								LOG.debug("Populate highestScoreRecordHolderMap for matched PARTY_ROWID " + recRowid);
								highestScoreRecordHolderMap.put(rowidKey, new HighestScoreRecordHolder());
							}

							highestScoreRecordHolder = highestScoreRecordHolderMap.get(rowidKey);

							if (record.getField("ROWID_OBJECT").getStringValue() != null) {
								highestScoreRecordHolder
										.setPartyRowIDObject(record.getField("ROWID_OBJECT").getStringValue().trim());
							}
							
							if (record.getField("ORG_DUNS_NBR")!=null && !Util.isNullOrEmpty(record.getField("ORG_DUNS_NBR").getStringValue())) {
								highestScoreRecordHolder.setOrgDunsNbr(record.getField("ORG_DUNS_NBR").getStringValue().trim());
							}
							
							if (record.getField("UCN")!=null && !Util.isNullOrEmpty(record.getField("UCN").getStringValue())) {
								highestScoreRecordHolder.setUCN(record.getField("UCN").getStringValue().trim());
							}
							
							// Populate Match Score Map
							String mtchScore = record.getField("MATCH_SCORE").getValue().toString().trim();
							int mtchValue = Integer.parseInt(mtchScore);
							LOG.info("MatchScoreMap rowid_object :" + rowidKey + " scoreValue :" + mtchValue);
							// need to check the mtchValue = 0
							if (mtchValue == 0) {
								mtchValue = 100;
							}
							matchScoreMap.put(rowidKey, mtchValue);

							// highestScoreRecordHolderMap.put(rowidKey,highestScoreRecordHolder);
						} else if (recRowid.equals(putRowidObject)) {
							LOG.debug("Self Matching record found with rowidOb: " + recRowid);
						}
					}
					// Variables for tie-breaker
					int highestScore = 0;
					int olderRowid = 0;

					if (matchScoreMap != null && matchScoreMap.size() > 0) {
						if (matchScoreMap.size() > 1) {
							highestScore = highestMatchScore(matchScoreMap);

							int matchScoreThreshold = Integer.parseInt(configProps.getProperty("matchScore-Threshold"));

							if (matchScoreThreshold > highestScore) {
								LOG.info(" Highest Match Score of MatchedRecords is smaller than ThresholdValue");
								return null;
								// return false;
							} else {
								matchInd = true;

								// Method invocation for fetching Records/Rowids
								// with
								// Highest Match Score
								if (matchScoreMap != null && matchScoreMap.size() > 0) {
									resultMatchScoreList = maxMatchScore(matchScoreMap);
								}
								// If Multiple Records/Rowids have Highest Match
								// Score
								if ((resultMatchScoreList != null && resultMatchScoreList.size() > 0)
										&& (highestScoreRecordHolderMap.size() > 1)) {
									
									HighestScoreRecordHolder highestScoreRecordHolder2 = new HighestScoreRecordHolder();

									// Removing Lower MatchScore Records
									for (Entry<Integer, HighestScoreRecordHolder> entry : highestScoreRecordHolderMap
											.entrySet()) {
										if (!resultMatchScoreList.contains(entry.getKey())) {
											LOG.info("Removing Record with RowID: " + entry.getKey());
											tempkeyList.add(entry.getKey());
										}
									}
									for (Object obj : tempkeyList) {
										highestScoreRecordHolderMap.remove(obj);
									}
									tempkeyList.clear();

									// If Multiple Records in HolderMap after
									// Removing Lower MatchScores
									if (highestScoreRecordHolderMap.size() > 1) {
										
										for (Entry entry : highestScoreRecordHolderMap.entrySet()) {
											highestScoreRecordHolder2 = (HighestScoreRecordHolder) entry.getValue();

											// Populate DunsNBR Map
											int rowidKey = Integer.parseInt(highestScoreRecordHolder2.getPartyRowIDObject());
											if (highestScoreRecordHolder2.getOrgDunsNbr() != null && highestScoreRecordHolder2.getOrgDunsNbr().length() > 0) {
												int dunsValue = Integer.parseInt(highestScoreRecordHolder2.getOrgDunsNbr());
												LOG.info("DunsNoMap rowid_object :" + rowidKey + " scoreValue :" + dunsValue);
												dunsNbrMap.put(rowidKey, dunsValue);
											} else {
												LOG.info(" Null DunsValue is: " + highestScoreRecordHolder2.getOrgDunsNbr());
											}
										}
										
										// Method invocation for fetching Records
										// with Highest Duns Number
										if (dunsNbrMap != null && dunsNbrMap.size() > 0)
											dunsNbrMapList = maxDunsNbr(dunsNbrMap);

										HighestScoreRecordHolder highestScoreRecordHolder3 = null;

										// Removing Lower DunsNumber Records
										if (dunsNbrMapList != null && dunsNbrMapList.size() > 0) {
											for (Entry entry : highestScoreRecordHolderMap.entrySet()) {
												if (!dunsNbrMapList.contains(entry.getKey())) {
													LOG.info("Removing Record with RowID: " + entry.getKey());
													tempkeyList.add(entry.getKey());
												}
											}
											for (Object obj : tempkeyList) {
												highestScoreRecordHolderMap.remove(obj);
											}
											tempkeyList.clear();
										}
										
									// If Multiple Records in HolderMap after
										// Removing Lower DunsNumbers
											if (highestScoreRecordHolderMap.size() > 1) {

												for (Entry entry : highestScoreRecordHolderMap.entrySet()) {
													highestScoreRecordHolder3 = (HighestScoreRecordHolder) entry.getValue();
													// Populate ucn Map
													if (highestScoreRecordHolder3.getUCN() != null && highestScoreRecordHolder3.getUCN().length() > 0) {
														int rowidKey = Integer.parseInt(highestScoreRecordHolder3.getPartyRowIDObject());
														long ucnValue = Long.parseLong(highestScoreRecordHolder3.getUCN());
														LOG.info("UCNCustMap rowid_object :" + rowidKey + " UCNValue :" + ucnValue);
														ucnCustNumMap.put(rowidKey, ucnValue);
													} else {
														LOG.info("Null ucnCustNum is: " + highestScoreRecordHolder3.getUCN());
													}
												}

												// Method invocation for fetching
												// Records with Lowest UCN
												if (ucnCustNumMap != null && ucnCustNumMap.size() > 0)
													ucnCustNumMapList = minUCNCustNum(ucnCustNumMap);
												
												//Taking the record with lower UCN
												if(ucnCustNumMapList != null && ucnCustNumMapList.size() > 0){
													finalMatchedRecord = highestScoreRecordHolderMap.get(ucnCustNumMapList.get(0));
													LOG.debug("finalMatchedRecord is: " + finalMatchedRecord.getPartyRowIDObject());
												}
												
											} else {
												// highestScoreRecordHolderMap contains
												// only 1 Matching Record
												LOG.debug("highestScoreRecordHolderMap contains only 1 Matching Record after duns number tie breaker logic -->"
														+ highestScoreRecordHolderMap.keySet());
												for (Map.Entry<Integer, HighestScoreRecordHolder> recMapEntry : highestScoreRecordHolderMap
														.entrySet()) {
													finalMatchedRecord = recMapEntry.getValue();
													LOG.debug("finalMatchedRecord value is: " + finalMatchedRecord);
												}
											}
										
									
									} else {
										// highestScoreRecordHolderMap contains
										// only 1 Matching Record
										LOG.debug("highestScoreRecordHolderMap contains only 1 Matching Record -->"
												+ highestScoreRecordHolderMap.keySet());
										for (Map.Entry<Integer, HighestScoreRecordHolder> recMapEntry : highestScoreRecordHolderMap
												.entrySet()) {
											finalMatchedRecord = recMapEntry.getValue();
											LOG.debug("finalMatchedRecord value is: " + finalMatchedRecord);
										}
									}
								} else {
									// highestScoreRecordHolderMap contains only
									// 1 Matching Record
									LOG.debug("highestScoreRecordHolderMap contains only 1 Matching Record -->"
											+ highestScoreRecordHolderMap.keySet());
									for (Map.Entry<Integer, HighestScoreRecordHolder> recMapEntry : highestScoreRecordHolderMap
											.entrySet()) {
										finalMatchedRecord = recMapEntry.getValue();
										LOG.debug("finalMatchedRecord value is: " + finalMatchedRecord);
									}
								}
							}

							LOG.info("Final Map Size: " + highestScoreRecordHolderMap.size());
							LOG.info("Target RecordKey is found: " + finalMatchedRecord);
						} else {

							LOG.info("Final Map Size: " + highestScoreRecordHolderMap.size());
							LOG.info("Record holder map contains only 1 matched record: "
									+ highestScoreRecordHolderMap.keySet());
							for (Map.Entry<Integer, HighestScoreRecordHolder> recMapEntry : highestScoreRecordHolderMap
									.entrySet()) {
								finalMatchedRecord = recMapEntry.getValue();
								LOG.debug("finalMatchedRecord value is: " + finalMatchedRecord);
							}
						}
					} else {
						LOG.info("No matching record found after searchMatch resultset processing");
						try{
							commonUtil.updateCI(putRowidObject.trim(),false);
							}catch(Exception e){
								LOG.info("Exception occured while updating CONSOLIDATION_IND");
							}
						return null;
					}

				} else {
					LOG.info("No matching record found by searchMatch");
					try{
					commonUtil.updateCI(putRowidObject.trim(),false);
					}catch(Exception e){
						LOG.info("Exception occured while updating CONSOLIDATION_IND");
					}
					return null;
				}

			} catch (SiperianServerException sifExcp) {
				LOG.error("SiperianServerException occured while processing Party Match operation: ", sifExcp);
				isError = true;
				warning.append("SearchMatch Process failed\n");
				ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
				customException.setMessage("SIF exception occured while processing Match request for Party. "
						+ customException.getMessage());
				throw customException;
			} catch (Exception ex) {
				LOG.error("Party Match operation failed with exception: ", ex);
				isError = true;
				ServiceProcessingException customException = new ServiceProcessingException(ex);
				customException
						.setMessage("Failed to process Match request for Party. " + customException.getMessage());

				warning.append("SearchMatch Process failed\n");

				throw customException;
			}

			
			if (!Util.isNullOrEmpty(finalMatchedRecord.getPartyRowIDObject())) {
				sorceRowidObject = finalMatchedRecord.getPartyRowIDObject().trim();
				LOG.info("Target party rowid_object for merge: " + sorceRowidObject);
			}

			int countOfRetry = Integer.parseInt(configProps.getProperty("NoOfRetries"));
			boolean isMergeRetrySuccess = false;
			String dnBExistFlag = "N";
			String parentExistFlag = "N";
			StringBuffer sBuffer = new StringBuffer(5);
			try {
				// merge Exclusion - merge skip if both the account having DNB,If both the account have Parent
				if ((!Util.isNullOrEmpty(sorceRowidObject)) && (!sorceRowidObject.equals(putRowidObject.trim()))) {

					try {
						LOG.debug("Step-1,Check DNBExist for matchedRowid object" + sorceRowidObject + "putRowid object"+putRowidObject);
						/*if (!Util.isNullOrEmpty(sorceRowidObject)) {
							dnBExist = checkDnbExist(sorceRowidObject.trim());
						}
						if (!Util.isNullOrEmpty(putRowidObject)) {
							dnBExist = checkDnbExist(putRowidObject.trim());
						}*/
						sBuffer = CommonUtil.checkBothDnbandParentExist(putRowidObject, sorceRowidObject);
						parentExistFlag = sBuffer.substring(0,1);
						dnBExistFlag = sBuffer.substring(1);
								LOG.debug("Step-2,Check DNBExist and Parent exist for dnBExistFlag" + dnBExistFlag + "parentExistFlag"+parentExistFlag);
					} catch (Exception exp) {
						LOG.error("Caught exception while Checking DNBExist " + exp);
					}
					

					String unmergeFlag = "N";
					List<String> rowidList = new ArrayList<String>();
					unmergeFlag = checkUnMergeByDS(sorceRowidObject, putRowidObject);
					String sourceUCN = null;
					String targetUCN = null;
					 if (parentExistFlag.equalsIgnoreCase("Y"))
						{
						 try {
							sourceUCN = checkifUCNExists(putRowidObject);
							 targetUCN = checkifUCNExists(sorceRowidObject);
						} catch (Exception e) {
							LOG.error("Caught exception in checkifUCNExists()", e);
						}
							String title ="Auto Merge Restricted for Accounts  : " +sourceUCN +"  and " + targetUCN;
							String comment = "Auto Merge Restricted for Accounts : "+sourceUCN+" and "+ targetUCN + "  since both are having Active Parents. Please review and take action.";
							
							processCreateTaskRequest(sorceRowidObject,putRowidObject,"Merge",title,comment);
						}
						if ((dnBExistFlag.equalsIgnoreCase("Y"))) {
							putProcessStateInd(null, Constant.SEND_FOR_DS, putRowidObject.trim(),Constant.SRC_SYSTEM_FNO);
						}
					
					if ((unmergeFlag.equalsIgnoreCase("N")) 
							&& (dnBExistFlag.equalsIgnoreCase("N")) && (parentExistFlag.equalsIgnoreCase("N"))) {
						LOG.debug("Step-3,Check DNBExist and Parent exist for dnBExistFlag:: " + dnBExistFlag.trim() + "parentExistFlag:: "+parentExistFlag.trim() + "unmergeFlag:: " + unmergeFlag);
						rowidList.add(putRowidObject);
						updateCI(rowidList, "C_B_PARTY",siperianClient);
						mergeParty(sorceRowidObject, putRowidObject, siperianClient);
						LOG.debug("Party Merge is successful !!");
					} 
									
					else {
						LOG.info("Merge Operation Skipped Reason::might be Dnb exist ,might be Both Account Parent exist and might be unmerged by DS !!");
						sorceRowidObject = putRowidObject;
					}
					
				} else {
					LOG.info("No matched target record key found. Merge Operation not done");
					// mergeInd = false;
					// return null;
					// return false;
				}
			} catch (SiperianServerException sifExcp) {
				mergeInd = false;
				LOG.error("SiperianServerException occured while processing Merge operation on PARTY_BO: ", sifExcp);
				for (int i = 0; i < countOfRetry; i++) {
					try {
						LOG.debug("Retrying Merge process for " + (i + 1) + "th time");
						mergeParty(sorceRowidObject, putRowidObject, siperianClient);
						LOG.debug("Party Merge is successful on attempt no. " + (i + 1));
						isMergeRetrySuccess = true;
						mergeInd = true;
						break;
					} catch (Exception ex) {
						LOG.error("Exception occured in MergeRetryMechanism on attempt no. " + (i + 1));
						LOG.error("SiperianServerException occured in MergeRetryMechanism on PARTY_BO");
					}
				}
				if (!isMergeRetrySuccess) {
					ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
					customException.setMessage("SIF exception occured while processing Merge request on PARTY BO: "
							+ customException.getMessage());
					throw customException;
				}
			} catch (Exception ex) {
				mergeInd = false;
				LOG.error("Exception occured while processing Merge operation on PARTY_BO: ", ex);
				for (int i = 0; i < countOfRetry; i++) {
					try {
						LOG.debug("Retrying Merge process for " + (i + 1) + "th time");
						mergeParty(sorceRowidObject, putRowidObject, siperianClient);
						LOG.debug("Party Merge is successful on attempt no. " + (i + 1));
						isMergeRetrySuccess = true;
						mergeInd = true;
						break;
					} catch (Exception excp) {
						LOG.error("Exception occured in MergeRetryMechanism on attempt no. " + (i + 1));
						LOG.error("Exception occured in MergeRetryMechanism on PARTY_BO");
					}
				}
				if (!isMergeRetrySuccess) {
					ServiceProcessingException customException = new ServiceProcessingException(ex);
					customException.setMessage("SIF exception occured while processing Merge request on PARTY BO: "
							+ customException.getMessage());
					throw customException;
				}
			}

		} catch (SiperianServerException sifExcp) {
			LOG.error("SiperianServerException occured while processing Party Merge operation: ", sifExcp);
			isError = true;
			ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
			customException.setMessage(
					"SIF exception occured while processing Merge request for Party. " + customException.getMessage());
			throw customException;
		} catch (ServiceProcessingException excp) {
			LOG.error("Party Merge operation failed due to ServiceProcessingException with exception: ", excp);
			isError = true;
			throw excp;
		} catch (Exception ex) {
			LOG.error("Party Merge operation failed with exception: ", ex);
			isError = true;
			ServiceProcessingException customException = new ServiceProcessingException(ex);
			customException.setMessage("Failed to process Merge request for Party. " + customException.getMessage());
			throw customException;
		} finally {
			// checkIn(siperianClient);
			if (isError) {
				tgtRowidObj = sorceRowidObject;
			}
		}

		LOG.info("Executed processMatchAndMergeParty()");
		return sorceRowidObject;
	}

	/* Execute SearchMatch API on Party & Address BO Table */
	private List matchParty(PartyXrefType partyTypeParam, SiperianClient siperianClient)
			throws ServiceProcessingException {

		LOG.info("Executing matchParty()...");
		
		String ruleSetNonJPN="";
		String ruleSetJPNCustomer = configProps.getProperty("matchRuleSetCustomerJPN");
		String ruleSetJPNResellerDistributor = configProps.getProperty("matchRuleSetResellerDistributorJPN");
		
		
		List searchRecords = new ArrayList();

		try {
			SearchMatchRequest searchMatchRequest = new SearchMatchRequest();
			SearchMatchResponse searchMatchResponse = null;

			searchMatchRequest.setRecordsToReturn(100); // Required
			//searchMatchRequest.setSiperianObjectUid("BASE_OBJECT.C_B_PARTY");
			//LOG.info("base object set for search match : BASE_OBJECT.C_B_PARTY" );
			//searchMatchRequest.setSiperianObjectUid(getPkgName);
			searchMatchRequest.setSiperianObjectUid("BASE_OBJECT.C_B_PARTY");
			LOG.info("Match Rule Set: before setting " + searchMatchRequest.getMatchRuleSetUid());
			String countryCode = partyTypeParam.getAddress().get(0).getCOUNTRYCD();
			if ("Japan".equalsIgnoreCase(countryCode) || "JPN".equalsIgnoreCase(countryCode)
					|| "JP".equalsIgnoreCase(countryCode)) {
			//	searchMatchRequest.setMatchRuleSetUid(SiperianObjectType.MATCH_RULE_SET.makeUid(ruleSetJPN));// Kanji_Org_Name_Mod

				if (partyTypeParam.getPARTYTYPE().equalsIgnoreCase(Constant.PARTY_TYPE_CUSTOMER)) {
					searchMatchRequest.setMatchRuleSetUid(SiperianObjectType.MATCH_RULE_SET.makeUid(ruleSetJPNCustomer));
				}
				if(Constant.PARTY_TYPE_RESELLER.equalsIgnoreCase(partyTypeParam.getPARTYTYPE()) 
						|| Constant.PARTY_TYPE_DISTRIBUTOR.equalsIgnoreCase(partyTypeParam.getPARTYTYPE())){
					searchMatchRequest.setMatchRuleSetUid(
							SiperianObjectType.MATCH_RULE_SET.makeUid(ruleSetJPNResellerDistributor));
				}
				/*Field ucnField_name = new Field("Ex_UCN");
				LOG.info("inserted ucn : " + partyTypeParam.getUCN());
				if (!Util.isNullOrEmpty(partyTypeParam.getUCN())) {
					ucnField_name.setStringValue(partyTypeParam.getUCN());
					LOG.info("Field to search for :" + ucnField_name.getName() + ':' + ucnField_name.getStringValue());
					searchMatchRequest.addMatchColumnField(ucnField_name);
				}*/

			
			} else {
				
				String partyType = partyTypeParam.getPARTYTYPE();
				
				if(Constant.PARTY_TYPE_CUSTOMER.equalsIgnoreCase(partyType)){
					ruleSetNonJPN = configProps.getProperty("matchRuleSetCustomer");
				}
				
				if(Constant.PARTY_TYPE_RESELLER.equalsIgnoreCase(partyType) || Constant.PARTY_TYPE_DISTRIBUTOR.equalsIgnoreCase(partyType)){
					ruleSetNonJPN = configProps.getProperty("matchRuleSetResellerDistributor");
				}
				if(!Util.isNullOrEmpty(ruleSetNonJPN)){
					searchMatchRequest.setMatchRuleSetUid(SiperianObjectType.MATCH_RULE_SET.makeUid(ruleSetNonJPN));
				}
			}

			searchMatchRequest.setMatchType(MatchType.BOTH);

			LOG.info("Match Rule Set: " + searchMatchRequest.getMatchRuleSetUid());
			LOG.info("Match Type :" + searchMatchRequest.getMatchType());

			Field field_name = new Field("Organization_Name");
			if (!Util.isNullOrEmpty(partyTypeParam.getPARTYNAME())) {
				field_name.setStringValue(partyTypeParam.getPARTYNAME());
				LOG.info("Field to search for :" + field_name.getName() + ':' + field_name.getStringValue());
				searchMatchRequest.addMatchColumnField(field_name);
			}
			
			/*Field ucnField_name = new Field("Ex_UCN");
			LOG.info("inserted ucn : " + partyTypeParam.getUCN());
			if (!Util.isNullOrEmpty(partyTypeParam.getUCN())) {
				ucnField_name.setStringValue(partyTypeParam.getUCN());
				LOG.info("Field to search for :" + ucnField_name.getName() + ':' + ucnField_name.getStringValue());
				searchMatchRequest.addMatchColumnField(ucnField_name);
			}*/
			
			AddressXrefType addressXref = partyTypeParam.getAddress() == null ? null
					: partyTypeParam.getAddress().get(0);
			if (null != addressXref) {
				// Setting Address_Part1
				Field field_addr1 = new Field("Address_Part1");
				StringBuilder addrLn1Ln2Concat = new StringBuilder();
				if (!Util.isNullOrEmpty(addressXref.getADDRLN1())) {
					addrLn1Ln2Concat.append(addressXref.getADDRLN1());

				}
				if (!Util.isNullOrEmpty(addressXref.getADDRLN2())) {
					addrLn1Ln2Concat.append(" ");
					addrLn1Ln2Concat.append(addressXref.getADDRLN2());

				} else {
					addrLn1Ln2Concat.append(" ");
				}
				if (addrLn1Ln2Concat != null && addrLn1Ln2Concat.length() > 1) {
					field_addr1.setStringValue(addrLn1Ln2Concat.toString());
					searchMatchRequest.addMatchColumnField(field_addr1);
				}
				LOG.info("Field to search for :" + field_addr1.getName() + ':' + field_addr1.getStringValue());

				if (!Util.isNullOrEmpty(addressXref.getADDRLN1()))
					createSearchField(searchMatchRequest, SearchMatchAttributes.EX_ADDRESS_LN1,
							addressXref.getADDRLN1());
				if (!Util.isNullOrEmpty(addressXref.getADDRLN2()))
					createSearchField(searchMatchRequest, SearchMatchAttributes.EX_ADDRESS_LN2,
							addressXref.getADDRLN2());

				if (addrLn1Ln2Concat != null && addrLn1Ln2Concat.length() > 1) {
					if (!Util.isNullOrEmpty(addressXref.getADDRLN2())) {
						createSearchField(searchMatchRequest, SearchMatchAttributes.EX_ADDR_PART1,
								addrLn1Ln2Concat.toString()+Constant.STR_SPACE);	
					}else{
						createSearchField(searchMatchRequest, SearchMatchAttributes.EX_ADDR_PART1,
								addrLn1Ln2Concat.toString());
					}
					
				}
				if (!Util.isNullOrEmpty(addressXref.getCITY()))
					createSearchField(searchMatchRequest, SearchMatchAttributes.EX_CITY, addressXref.getCITY());
				if (!Util.isNullOrEmpty(addressXref.getCOUNTRYCD()))
					createSearchField(searchMatchRequest, SearchMatchAttributes.EX_COUNTRY_CD,
							addressXref.getCOUNTRYCD());
				if (!Util.isNullOrEmpty(addressXref.getSTATECD()))
					createSearchField(searchMatchRequest, SearchMatchAttributes.EX_STATE, addressXref.getSTATECD());
				
				LOG.info("State search : " + addressXref.getSTATECD());
				LOG.info("country search : " + addressXref.getCOUNTRYCD());
				LOG.info("addresspart1 search: " + addrLn1Ln2Concat);
				LOG.info("Search organization name : " + partyTypeParam.getPARTYNAME());
				LOG.info("searrch entity type : " + Constant.BO_CLASS_CODE_ORG);
				LOG.info("searrch for UCN : " + partyTypeParam.getUCN());
				LOG.info("searrch for city : " + addressXref.getCITY());
				// Setting Address_Part2

				Field addr_part2 = new Field("Address_Part2");
				StringBuilder addrPart2Concat = new StringBuilder();
				if (!Util.isNullOrEmpty(addressXref.getCITY())) {
					addrPart2Concat.append(addressXref.getCITY());
				}
				if (!Util.isNullOrEmpty(addressXref.getSTATECD())) {
					if (addrPart2Concat != null && addrPart2Concat.length() > 1)
						addrPart2Concat.append(" ");
					addrPart2Concat.append(addressXref.getSTATECD());
				}
				if (!Util.isNullOrEmpty(addressXref.getCOUNTRYCD())) {
					if (addrPart2Concat != null && addrPart2Concat.length() > 1)
						addrPart2Concat.append(" ");
					addrPart2Concat.append(addressXref.getCOUNTRYCD());
				}
				if (addrPart2Concat != null && addrPart2Concat.length() > 1) {
					addr_part2.setStringValue(addrPart2Concat.toString());
					LOG.info("Field to search for :" + addr_part2.getName() + ':' + addr_part2.getStringValue());
					searchMatchRequest.addMatchColumnField(addr_part2);
				}

			}

			createSearchField(searchMatchRequest, SearchMatchAttributes.EX_ORGANIZATION_NAME,
					partyTypeParam.getPARTYNAME());

			createSearchField(searchMatchRequest, SearchMatchAttributes.EX_ENTITY_TYPE, Constant.BO_CLASS_CODE_ORG);
			if (partyTypeParam.getPARTYTYPE().equalsIgnoreCase(Constant.PARTY_TYPE_CUSTOMER)) {
				createSearchField(searchMatchRequest, SearchMatchAttributes.EX_PARTY_TYPE,
						Constant.PARTY_TYPE_CUSTOMER);
				LOG.info("entering search for customer party type "+ Constant.PARTY_TYPE_CUSTOMER);
			} else if (partyTypeParam.getPARTYTYPE().equalsIgnoreCase(Constant.PARTY_TYPE_RESELLER)) {
				createSearchField(searchMatchRequest, SearchMatchAttributes.EX_PARTY_TYPE,
						Constant.PARTY_TYPE_RESELLER);
			} else if (partyTypeParam.getPARTYTYPE().equalsIgnoreCase(Constant.PARTY_TYPE_DISTRIBUTOR)) {
				createSearchField(searchMatchRequest, SearchMatchAttributes.EX_PARTY_TYPE,
						Constant.PARTY_TYPE_DISTRIBUTOR);
			} else {
				LOG.info(
						"Account is not created since it's PARTY_TYPE is not in ('Customer', 'Reseller', 'Distributor')");
			}

			// Adding SIP_POP
			Field field_SIPPOP = new Field("SIP_POP");
			field_SIPPOP.setStringValue(sipPopVal);
			searchMatchRequest.addMatchColumnField(field_SIPPOP);
			LOG.info("Field to match for :" + field_SIPPOP.getName() + ':' + field_SIPPOP.getStringValue());

			StringBuffer criteria = new StringBuffer();
			boolean firstParam = true;
			// Append filter for self rowid
			/*
			 * if (firstParam) { criteria.append(" ROWID_OBJECT <> '"
			 * +partyTypeParam.getROWIDOBJECT()+"'"); firstParam = false; } else
			 * { criteria.append(" AND ROWID_OBJECT <> '"
			 * +partyTypeParam.getROWIDOBJECT()+"'"); }
			 */
			if (firstParam) {
				criteria.append(" CONSOLIDATION_IND <> 9 ");
				firstParam = false;
			} else {
				criteria.append(" AND CONSOLIDATION_IND <> 9 ");
			}
			//commented as per Venkat's review - ODOM-2443
			/*if (firstParam) {
				criteria.append(" STATUS_CD = 'A' ");
				firstParam = false;
			} else {
				criteria.append(" AND STATUS_CD = 'A' ");
			}*/
			LOG.info("Filter Criteria: " + criteria.toString());

			searchMatchRequest.setFilterCriteria(criteria.toString());
			
			LOG.info("================================================================================================");
			List<Field> searchMatchField = searchMatchRequest.getMatchColumnFields();
			for(int j=0;j<searchMatchField.size();j++){
				Field f = (Field)searchMatchField.get(j);
				LOG.info("Search field name : " + f.getName()+": Search field value :" + f.getValue()+":");
				
			}
			LOG.info("================================================================================================");

			LOG.info("processing SearchMatchRequest");
			searchMatchResponse = (SearchMatchResponse) siperianClient.process(searchMatchRequest);

			searchRecords = searchMatchResponse.getRecords();
			LOG.info("================================================================================================");
			for(int i =0 ; i< searchRecords.size();i++){
				Record record = (Record) searchRecords.get(i);
				record.getFields();
				Collection<String> fields = record.getFields();
				Iterator iterator = fields.iterator();
				 
		        // while loop
		        while (iterator.hasNext()) {
		        Field f = (Field)iterator.next();
		        if(f.getName().equals("BO_CLASS_CODE"))
		        	LOG.info("feild name : " + f.getName() + "feild value :" + f.getValue()+":");
		        else if(f.getName().equals("PARTY_TYPE"))
		        	LOG.info("feild name : " + f.getName() + "feild value :" + f.getValue()+":");
		        else if(f.getName().equals("PARTY_NAME"))
		        	LOG.info("feild name : " + f.getName() + "feild value :" + f.getValue()+":");
		        else if(f.getName().equals("ADDR_LN1"))
		        	LOG.info("feild name : " + f.getName() + "feild value :" + f.getValue()+":");
		        else if(f.getName().equals("ADDR_LN2"))
		        	LOG.info("feild name : " + f.getName() + "feild value :" + f.getValue()+":");
		        else if(f.getName().equals("CITY"))
		        	LOG.info("feild name : " + f.getName() + "feild value :" + f.getValue()+":");
		        else if(f.getName().equals("STATE_CD"))
		        	LOG.info("feild name : " + f.getName() + "feild value :" + f.getValue()+":");
		        else if(f.getName().equals("COUNTRY_CD"))
		        	LOG.info("feild name : " + f.getName() + "feild value :" + f.getValue()+":");
		        else if(f.getName().equals("ROWID_OBJECT"))
		        	LOG.info("feild name : " + f.getName() + "feild value :" + f.getValue()+":");
		        else if(f.getName().equals("UCN"))
		        	LOG.info("feild name : " + f.getName() + "feild value :" + f.getValue()+":");
		        else if(f.getName().equals("SIP_POP"))
		        	LOG.info("feild name : " + f.getName() + "feild value :" + f.getValue()+":");
		        else if(f.getName().equals("ROWID_ADDRESS"))
		        	LOG.info("feild name : " + f.getName() + "feild value :" + f.getValue()+":");
		        else if(f.getName().equals("RULE_NUMBER"))
		        	LOG.info("feild name : " + f.getName() + "feild value :" + f.getValue()+":");
		        else if(f.getName().equals("RULESET_NAME"))
		        	LOG.info("feild name : " + f.getName() + "feild value :" + f.getValue()+":");
		        else if(f.getName().equals("DEFINITE_MATCH_IND"))
		        	LOG.info("feild name : " + f.getName() + "feild value :" + f.getValue()+":");
		        else if(f.getName().equals("MATCH_SCORE"))
		        	LOG.info("feild name : " + f.getName() + "feild value :" + f.getValue()+":");
		        }
		        LOG.info("================================================================================================"); 
			}
		} catch (SiperianServerException sifExcp) {

			LOG.error("SiperianServerException occured while processing SearchMatchRequest on PARTY BO: ", sifExcp);

			ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
			customException.setMessage("SIF exception occured while processing SearchMatchRequest on PARTY BO: "
					+ customException.getMessage());
			throw customException;
		} catch (Exception ex) {

			LOG.error("PARTY BO Merge operation failed with exception: ", ex);

			ServiceProcessingException customException = new ServiceProcessingException(ex);
			customException
					.setMessage("Failed to process SearchMatchRequest on PARTY BO: " + customException.getMessage());
			throw customException;
		}

		LOG.info("Completed matchParty()...");
		return searchRecords;
	}

	/* Execute Merge API on Party BO Table */
	private void mergeParty(String tgtRowidObject, String srcRowid, SiperianClient siperianClient)
			throws ServiceProcessingException {

		LOG.debug("Inside MergeRequest for PARTY BO...");

		try {
			// get rowid_object of record which has highest match score
			String rowidHighestMtchScr = tgtRowidObject;
			
			MergeRequest request = new MergeRequest();
			request.setSiperianObjectUid("BASE_OBJECT.C_B_PARTY");
			//request.setOrsId(configProps.getProperty("orsId"));
			// newly created record will be merged to the existing record
			request.setSourceRecordKey(RecordKey.rowid(srcRowid));
			LOG.info(" src row id :   "+ srcRowid);
			// existing record will be the survivor
			request.setTargetRecordKey(RecordKey.rowid(rowidHighestMtchScr));
			LOG.info(" target row id :  "  + rowidHighestMtchScr);
			LOG.info(" Before executing Merge process ");
			LOG.info("====================================================================");
			LOG.info(request.getOrsId());
			LOG.info(request.getSourceRecordKey());
			LOG.info(request.getTargetRecordKey());
			LOG.info(request.getTaskId());
			LOG.info(request.getTransactionAttributeType());
			LOG.info(request.getSiperianObjectUid());
			LOG.info("====================================================================");
			MergeResponse response = (MergeResponse) siperianClient.process(request);
			LOG.info(" After executing Merge process. Message from MergeResponse: " + response.getMessage());
			mergeInd = true;

		} catch (SiperianServerException sifExcp) {
			// mergeInd = false;
			LOG.error("SiperianServerException occured while processing Merge operation on PARTY BO: ", sifExcp);
			// sifExcp.printStackTrace();
			ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
			customException.setMessage("SIF exception occured while processing Merge request on PARTY BO: "
					+ customException.getMessage());
			throw customException;
		} catch (Exception ex) {
			// mergeInd = false;
			LOG.error("PARTY BO Merge operation failed with exception: ", ex);
			// ex.printStackTrace();
			ServiceProcessingException customException = new ServiceProcessingException(ex);
			customException.setMessage("Failed to process Merge request on PARTY BO: " + customException.getMessage());
			throw customException;
		}
		LOG.debug("Completed MergeRequest for PARTY BO...");
	}

	/* Execute Merge API on Account BO Table */
	private void mergeProcessChild(String siperianObjectUid, String sourceRowid, String targetRowid,
			SiperianClient siperianClient) throws ServiceProcessingException {

		LOG.info("Executing mergeProcessChild()");
		// SiperianClient siperianClient = null;

		try {

			// siperianClient = (SiperianClient) checkOut();

			if (sourceRowid != null && sourceRowid.length() > 0 && targetRowid != null && targetRowid.length() > 0) {
				/*
				 * sourceRowid = sourceRowid.trim(); targetRowid =
				 * targetRowid.trim();
				 */
				MergeRequest request = new MergeRequest();
				MergeResponse response = null;
				request.setSiperianObjectUid(siperianObjectUid);
				//request.setOrsId(configProps.getProperty("orsId"));
				// newly created record will merged into existing one
				request.setSourceRecordKey(RecordKey.rowid(sourceRowid));
				// existing rec will survive
				request.setTargetRecordKey(RecordKey.rowid(targetRowid));		
				// LOG.info("Child Target Key: "+ request.getTargetRecordKey());
				LOG.info(" Before executing Child Merge process ");
				LOG.info("siperianObjectUid: " + siperianObjectUid + ", ChildSourceRowid: " + sourceRowid
						+ ", ChildTargetRowid: " + targetRowid);
				LOG.info("====================================================================");
				LOG.info(request.getOrsId());
				LOG.info(request.getSourceRecordKey());
				LOG.info(request.getTargetRecordKey());
				LOG.info(request.getTaskId());
				LOG.info(request.getTransactionAttributeType());
				LOG.info(request.getSiperianObjectUid());
				LOG.info("====================================================================");
				response = (MergeResponse) siperianClient.process(request);
				mergeInd = true;
				LOG.debug(" After executing Child Merge process ");
				String msg = response.getMessage();
				LOG.debug(" Message from MergeResponse :" + msg);
			} else {
				LOG.info("Either SourceRowID or TargetRowID is null");
			}
		} catch (SiperianServerException sifExcp) {
			mergeInd = false;
			LOG.error("SiperianServerException occured while processing Child Merge operation: ", sifExcp);
			// sifExcp.printStackTrace();
			ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
			customException.setMessage(
					"SIF exception occured while processing Merge request for Child. " + customException.getMessage());
			throw customException;
		} catch (Exception ex) {
			mergeInd = false;
			LOG.error("Child Merge operation failed with exception: ", ex);
			// ex.printStackTrace();
			ServiceProcessingException customException = new ServiceProcessingException(ex);
			customException.setMessage("Failed to process Merge request for Child. " + customException.getMessage());
			throw customException;
		} finally {
			// checkIn(siperianClient);
		}
		LOG.info("Executed mergeProcessChild()");
	}

	private Map<String, String> multiMergeProcessChild(String baseObjTable, Map<String, List<String>> childTypeMap,
			SiperianClient siperianClient, boolean isP2C) throws ServiceProcessingException {
		LOG.info("Executing multiMergeProcessChild()");
		List<String> recordList = null;
		List<Integer> intRecordList = null;
		String childRecType = null;
		Map<String, String> recIdToSurvivingRowidMap = new HashMap<String, String>();
		String survivingRowid = null;

		try {
			LOG.info("Before executing child multi-merge process on " + baseObjTable);
			for (Entry entry : childTypeMap.entrySet()) {
				childRecType = entry.getKey().toString();
				recordList = (List<String>) entry.getValue();

				// if more than one rowid in list, go for multi-merge
				if (recordList != null && recordList.size() > 1) {
					updateCI(recordList, baseObjTable,siperianClient);
					MultiMergeRequest request = new MultiMergeRequest();
					ArrayList<RecordKey> recordKeys = new ArrayList<RecordKey>();
					StringBuilder rowIds = new StringBuilder();

					intRecordList = new ArrayList<Integer>();
					for (String str : recordList) {
						intRecordList.add(new Integer(str.trim()));
					}
					if(isP2C && (baseObjTable.equals(MDMAttributeNames.ADDRESS_BO) || baseObjTable.equals(MDMAttributeNames.COMM_BO))){
						Collections.sort(intRecordList, Collections.reverseOrder());
					}else{
						Collections.sort(intRecordList); // To make sure existing rowid survives
					}

					for (int indx = 0; indx < intRecordList.size(); indx++) {
						RecordKey key = new RecordKey();
						key.setRowid(Util.padSpace(intRecordList.get(indx).toString(), 14));
						recordKeys.add(key);
						rowIds.append(intRecordList.get(indx));
						rowIds.append(", ");
						if (indx == 0) {
							survivingRowid = intRecordList.get(indx).toString();
						}
						recIdToSurvivingRowidMap.put(intRecordList.get(indx).toString(), survivingRowid);
					}
					request.setRecordKeyList(recordKeys);

					Record record = new Record();
					record.setSiperianObjectUid(SiperianObjectType.BASE_OBJECT.makeUid(baseObjTable));
					request.setRecord(record);

					LOG.info("To multi-merge on record_type: " + childRecType + " | Rowid_objects to merge: "
							+ rowIds.toString());

					MultiMergeResponse response = (MultiMergeResponse) siperianClient.process(request);

					childMergeInd = true;
					LOG.debug(" Message from MultiMergeResponse :" + response.getMessage());
				} else {
					LOG.info("Sufficient records not found for multi-merge for type " + childRecType);
				}
			} // Modified code
		} catch (SiperianServerException sifExcp) {
			childMergeInd = false;
			LOG.error("SiperianServerException occured while processing Child multi-Merge operation: ", sifExcp);
			ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
			customException.setMessage("SIF exception occured while processing muti-Merge request for " + baseObjTable
					+ ": " + sifExcp.getMessage());
			throw customException;
		} catch (Exception ex) {
			childMergeInd = false;
			LOG.error("Child Merge operation failed with exception for " + baseObjTable, ex);
			ServiceProcessingException customException = new ServiceProcessingException(ex);
			customException.setMessage("Failed to process Merge request for " + baseObjTable + ": " + ex.getMessage());
			throw customException;
		}
		LOG.info("Executed multiMergeProcessChild()");

		return recIdToSurvivingRowidMap;
	}

	private void updateCI(List<String> recordList, String baseObjTable) throws ServiceProcessingException {
		LOG.debug("Inside updateCI()");
		Connection jdbcConn = null;
		Statement statement = null;
		JDBCConnectionProvider jDBCConnectionProvider = null;
		int rowCnt = 0;
		StringBuilder sqlQry = new StringBuilder();

		sqlQry.append("UPDATE ");
		sqlQry.append(baseObjTable);
		sqlQry.append(" SET CONSOLIDATION_IND = '4' WHERE ROWID_OBJECT in (");
		for (String partyRowId : recordList) {
			sqlQry.append("'" + partyRowId.trim() + "',");
		}
		sqlQry.deleteCharAt(sqlQry.length() - 1).toString();
		sqlQry.append(")");

		LOG.debug("SQL in updateCI()--> " + sqlQry);

		try {
			jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
			jdbcConn = jDBCConnectionProvider.getJdbcConnectionFromDS();
			statement = jdbcConn.createStatement();
			rowCnt = statement.executeUpdate(sqlQry.toString());

			// jdbcConn.commit();
			LOG.debug("RowidObject Updated for CI : " + rowCnt);
			// LOG.debug("APPRVD_FOR_MERGE value updated to N in C_B_PARTY for
			// partyID: " + survivingRowidObject);

		} catch (SQLException exp) {
			LOG.error("Caught SQLException in updateCI() ", exp);

		} finally {
			try {
				// Closing connections
				// if (resultSet != null) resultSet.close();
				if (statement != null)
					statement.close();
				if (jdbcConn != null)
					jdbcConn.close();
			} catch (SQLException exp) {
				LOG.error("SQLexp caught in updateCI(): ", exp);
			}

		}

		LOG.debug(" Executed updateCI() successfully ");
	}

	public HashMap<Integer, HighestScoreRecordHolder> mergeProcessParty(
			HashMap<Integer, HighestScoreRecordHolder> mergeSorceHolderMap, MdmUpsertPartyResponse upsertPartyResponse,
			HighestScoreRecordHolder highestScoreRecordHoldertgt, PartyXrefType insertedPartyData, String rowidObject)
			throws ServiceProcessingException {

		LOG.info("Executing mergeProcessParty() method." + ucnMatch);
		String survivorRowidObject = null;
		UserTransaction transaction = null;
		SiperianClient siperianClient = null;
		boolean isError = false;
		String targetRowid = null;
		List<String> targetRowidList = new ArrayList<String>();

		int countOfRetry = Integer.parseInt(configProps.getProperty("NoOfRetries"));
		boolean isMergeRetrySuccess = false;
		List<String> rowidList = new ArrayList<String>();
		// execute Match and Merge SIF operation
		try {

			siperianClient = checkOut();
			transaction = ((EjbSiperianClient) siperianClient).createTX((300000));
			transaction.begin();
			if(!ucnMatch){
			try {
				survivorRowidObject = processMatchAndMergeParty((PartyXrefType) insertedPartyData, matchScoreThres,
						highestScoreRecordHoldertgt, rowidObject, siperianClient);
				LOG.debug(" Controlled returned after processMatchAndMergeParty");
				// LOG.info("survivorRowidObject===" + survivorRowidObject);
				
			} catch (Exception excp) {
				LOG.error("Caught exception within mergeProcessParty: ", excp);
				isError = true;
				throw excp;
			}
			}
			if (survivorRowidObject == null) {
				survivorRowidObject = rowidObject;
			}
			
			if (survivorRowidObject != null) {	
				targetRowidList = getAccountId(survivorRowidObject.trim());
				// newly created record will merge to existing record
				String sourceRowid = null;
				if(insertedPartyData!=null && insertedPartyData.getAccount()!=null && insertedPartyData.getAccount().size()>0){
					sourceRowid = insertedPartyData.getAccount().get(0).getROWIDACCOUNT();
				}
				if (targetRowidList != null && targetRowidList.size() > 0) {
					for (Iterator<String> iter = targetRowidList.iterator(); iter.hasNext();) {
						String tempId = iter.next();
						if (!Util.isNullOrEmpty(tempId)) {
							if (tempId.trim().equals(sourceRowid.trim())) {
								continue;
							} else {
								targetRowid = tempId;
							}
						}
					}
				}
				LOG.debug("AccountSorce Key: " + sourceRowid + " | AccountTarget Key: " + targetRowid);

				String siperianObjectUid = "BASE_OBJECT.C_B_ACCOUNT";
				/** Merge Retry Mechanism */
				try {
					if ((!Util.isNullOrEmpty(targetRowid)) && (!targetRowid.trim().equals(sourceRowid.trim()))) {
						rowidList.add(sourceRowid);
						rowidList.add(targetRowid);
						updateCI(rowidList, "C_B_ACCOUNT",siperianClient);
						mergeProcessChild(siperianObjectUid, sourceRowid, targetRowid, siperianClient);
						LOG.debug("Account Merge is successful !!");
					} else {
						LOG.debug("Account Merge for ELQ is successfully skipped !!");
					}
				} catch (Exception sifExcp) {
					// mergeInd = false;
					LOG.error("Exception occured while processing Merge operation on C_B_ACCOUNT: ", sifExcp);
					for (int i = 0; i < countOfRetry; i++) {
						try {
							LOG.debug("Retrying C_B_ACCOUNT Merge process for " + (i + 1) + "th time");
							//rowidList.add(sourceRowid);
							//rowidList.add(targetRowid);
							updateCI(rowidList, "C_B_ACCOUNT",siperianClient);
							mergeProcessChild(siperianObjectUid, sourceRowid, targetRowid, siperianClient);
							LOG.debug("Account Merge is successful on attempt no. " + (i + 1));
							isMergeRetrySuccess = true;
							// mergeInd = true;
							break;
						} catch (Exception ex) {
							LOG.error("Exception occured in C_B_ACCOUNT MergeRetryMechanism on attempt no. " + (i + 1));
							LOG.error("Exception occured in MergeRetryMechanism on C_B_ACCOUNT");
						}
					}
					if (!isMergeRetrySuccess) {
						ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
						customException
								.setMessage("SIF exception occured while processing Merge request on C_B_ACCOUNT: "
										+ customException.getMessage());
						throw customException;
					}
				} // end try/catch

				// }//end for Iterator on AccountList

			}
			transaction.commit();

			// if newly created record got merged, set rowid_object of it to
			// that
			// of surviving target record
			if (mergeInd) {
				LOG.info(
						"Setting rowid_object of new record to that of surviving target record " + survivorRowidObject);
				
				if(upsertPartyResponse.getParty()!=null && upsertPartyResponse.getParty().size()>0){
					upsertPartyResponse.getParty().get(0).setROWIDOBJECT(survivorRowidObject);
				}
			}
		} catch (ServiceProcessingException excp) {
			LOG.error("Caught exception in ProcessMatchAndMerge operation.", excp);
			isError = true;
			upsertPartyResponse.setErrorMsg("ProcessMatchAndMerge operation failed for PartyID: "
					+ insertedPartyData.getXREF().get(0).getSRCPKEY());

			try {
				transaction.rollback();

			} catch (SystemException txExcp) {
				LOG.error("Failed to rollback transaction for ProcessMatchAndMerge operation : " + txExcp.toString());
			}
			throw excp;
		} catch (Exception ex) {
			LOG.error("Exception occured while ProcessMatchAndMerge operation requests: ", ex);
			isError = true;

			try {
				transaction.rollback();
			} catch (SystemException txExcp) {
				LOG.error("Failed to rollback transaction for ProcessMatchAndMerge operation: " + txExcp.toString());
				// txExcp.printStackTrace();
			}
			ServiceProcessingException customException = new ServiceProcessingException(ex);
			customException
					.setMessage("Failed to process ProcessMatchAndMerge operation. " + customException.getMessage());
			// customException.printStackTrace();
			throw customException;
		} finally {
			checkIn(siperianClient);
			if (isError) {
				tgtRowidObj = targetRowid;
			}
		}

		try {

			// Updating APPRVD_FOR_MERGE to N after Party & Account Match &
			// Merge
			if (mergeInd) {
				updateApprvdForMerge(survivorRowidObject);
			}

			// Perform Tokenization after Match & Merge
			PutResponseDataHolder putTokenizeDataParty = new PutResponseDataHolder();
			String sorceRowidObject = null;
			if (mergeInd) {
				for (HighestScoreRecordHolder hsrh : mergeSorceHolderMap.values()) {
					sorceRowidObject = hsrh.getPartyRowIDObject();
				}

				if (!Util.isNullOrEmpty(sorceRowidObject)) {
					putTokenizeDataParty.setRowidObject(sorceRowidObject);
					putTokenizeDataParty.setActionType("Merge");
					processTokenizeRequest(sorceRowidObject, "C_B_PARTY");
				}
			}
		} catch (SiperianServerException sifExcp) {
			LOG.error("SiperianServerException occured while processing TokenizeRequest for Party after MatchMerge.",
					sifExcp);
			ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
			customException
					.setMessage("SIF exception occured while processing Tokenize request for Party after MatchMerge. "
							+ customException.getMessage());

		} catch (Exception excp) {
			LOG.error("Exception occured while processing TokenizeRequest for Party after MatchMerge.", excp);
			ServiceProcessingException customException = new ServiceProcessingException(excp);
			customException
					.setMessage("Exception occured while processing Tokenize request for Party after MatchMerge. "
							+ customException.getMessage());

		}

		LOG.info("Executed mergeProcessParty() method.");
		return mergeSorceHolderMap;
	}

	public void mergeProcessMultipleChild(PartyType partyType, MdmUpsertPartyResponse upsertPartyResponse, boolean isP2C)
			throws ServiceProcessingException {
		LOG.info("Executing mergeProcessMultipleChild()");
		Map<String, List<String>> accTypeMap = new HashMap<String, List<String>>();
		Map<String, List<String>> addrTypeMap = new HashMap<String, List<String>>();
		Map<String, List<String>> commTypeMap = new HashMap<String, List<String>>();
		Map<String, List<String>> classifTypeMap = new HashMap<String, List<String>>();
		List<String> accRowidList = null;
		List<String> addrRowidList = null;
		List<String> commRowidList = null;
		List<String> classifRowidList = null;

		UserTransaction transaction = null;
		SiperianClient siperianClient = null;

		try {
			LOG.info("Preparing type-wise rowid_object list for Addr/Comm/Classifictn");
			if(isP2C){
			for (int indx = 0; indx < partyType.getAccount().size(); indx++) {
				String accType = "Account";
				if (!accTypeMap.containsKey(accType)) {
					accRowidList = new ArrayList<String>();
					accTypeMap.put(accType, accRowidList);
				}
				accTypeMap.get(accType).add(partyType.getAccount().get(indx).getROWIDACCOUNT());
			}
			}
			
			for (int indx = 0; indx < partyType.getAddress().size(); indx++) {
				String addrType = partyType.getAddress().get(indx).getADDRTYPE();
				if (!addrTypeMap.containsKey(addrType)) {
					addrRowidList = new ArrayList<String>();
					addrTypeMap.put(addrType, addrRowidList);
				}
				addrTypeMap.get(addrType).add(partyType.getAddress().get(indx).getROWIDADDRESS());
			}

			for (int indx = 0; indx < partyType.getCommunication().size(); indx++) {
				String commType = partyType.getCommunication().get(indx).getCOMMTYPE();
				if (!commTypeMap.containsKey(commType)) {
					commRowidList = new ArrayList<String>();
					commTypeMap.put(commType, commRowidList);
				}
				commTypeMap.get(commType).add(partyType.getCommunication().get(indx).getROWIDCOMMUNICATION());
			}

			for (int indx = 0; indx < partyType.getClassification().size(); indx++) {
				String classType = partyType.getClassification().get(indx).getCLASSIFICTNTYPE();
				if (!classifTypeMap.containsKey(classType)) {
					classifRowidList = new ArrayList<String>();
					classifTypeMap.put(classType, classifRowidList);
				}
				classifTypeMap.get(classType).add(partyType.getClassification().get(indx).getROWIDCLASSIFICTN());
			}

			LOG.info("Type-wise rowid_object list for Addr/Comm/Classifictn created");
		} catch (Exception ex) {
			LOG.error("Exception occured while preparing child entity records for Multi-merge: ", ex);
			ServiceProcessingException customException = new ServiceProcessingException(ex);
			customException.setMessage("Failed to prepare child entity records for Multi-merge: " + ex.getMessage());
			throw customException;
		}

		try {

			siperianClient = checkOut();
			transaction = ((EjbSiperianClient) siperianClient).createTX(300000);
			transaction.begin();

			LOG.info("Calling multi-merge process for Addr/Comm/Classifictn");
			// call multi-merge for each child
			if(isP2C){
				multiMergeProcessChild(MDMAttributeNames.ACCOUNT_BO,accTypeMap, siperianClient, isP2C);
			}
			Map<String, String> typeToSurvivingRowidMapAddr = multiMergeProcessChild(MDMAttributeNames.ADDRESS_BO,
					addrTypeMap, siperianClient, isP2C);
			Map<String, String> typeToSurvivingRowidMapComm = multiMergeProcessChild(MDMAttributeNames.COMM_BO,
					commTypeMap, siperianClient, isP2C);
			Map<String, String> typeToSurvivingRowidMapClassif = multiMergeProcessChild(MDMAttributeNames.CLASS_BO,
					classifTypeMap, siperianClient, isP2C);

			transaction.commit();
			LOG.info("Multi-merge process for Addr/Comm/Classifictn completed");

			if (upsertPartyResponse != null) {
				upsertPartyResponse.setStatus(upsertPartyResponse.getStatus() + "\n ");
				if (typeToSurvivingRowidMapAddr != null && typeToSurvivingRowidMapAddr.size() > 1) {
					upsertPartyResponse.setStatus(upsertPartyResponse.getStatus() + "Address records got merged.");
				}
				if (typeToSurvivingRowidMapComm != null && typeToSurvivingRowidMapComm.size() > 1) {
					upsertPartyResponse
							.setStatus(upsertPartyResponse.getStatus() + "Communication records got merged.");
				}
				if (typeToSurvivingRowidMapClassif != null && typeToSurvivingRowidMapClassif.size() > 1) {
					upsertPartyResponse
							.setStatus(upsertPartyResponse.getStatus() + "Classification records got merged.");
				}
			}
		} catch (ServiceProcessingException excp) {
			LOG.error("Exception in Merge operation for child entities: ", excp);

			try {
				transaction.rollback();
				LOG.debug("Transaction rolled back successfully.");
			} catch (SystemException txExcp) {
				LOG.error("Failed to rollback transaction for Merge operation : " + txExcp.toString());
			}
			throw excp;
		} catch (Exception ex) {
			LOG.error("Exception occured in Merge operation for child entities: ", ex);
			try {
				transaction.rollback();
				LOG.debug("Transaction rolled back successfully.");
			} catch (SystemException txExcp) {
				LOG.error("Failed to rollback transaction for Merge operation: " + txExcp.toString());
				txExcp.printStackTrace();
			}
			ServiceProcessingException customException = new ServiceProcessingException(ex);
			customException.setMessage("Failed to process Merge operation for child entities: " + ex.getMessage());
			throw customException;
		} finally {
			checkIn(siperianClient);
		}

		LOG.info("Executed mergeProcessMultipleChild()");
	}

	// Method to calculate highest/maximum Match Score
	private List<Integer> maxMatchScore(Map<Integer, Integer> matchScoreMap) {
		Collection<Integer> collVal = matchScoreMap.values();
		List<Integer> scoreList = new ArrayList<Integer>(collVal);
		List rowidObjs = new ArrayList(); //
		// Collections.sort(scoreList);
		// Object maxScore = scoreList.get(scoreList.size()-1);
		Integer maxScore = Collections.max(scoreList);
		int cnt = 0;
		// for (Iterator itr = scoreList.iterator(); itr.hasNext();) {
		for (Entry entry : matchScoreMap.entrySet()) {
			if (maxScore.equals(entry.getValue())) {
				cnt++;
				rowidObjs.add(entry.getKey());
			}
		}
		LOG.debug("No of records having highest match score " + maxScore + ": " + cnt);
		return rowidObjs;
	}

	// Method to calculate highest/maximum DunsNbr
	private List<Integer> maxDunsNbr(Map<Integer, Integer> dunsNbrMap) {
		Collection<Integer> collVal = dunsNbrMap.values();
		List<Integer> dunsList = new ArrayList<Integer>(collVal);
		List rowidObjs = new ArrayList(); //
		// Collections.sort(scoreList);
		// Object maxScore = scoreList.get(scoreList.size()-1);
		Integer maxDuns = Collections.max(dunsList);
		LOG.debug("Lowest Duns Num: " + maxDuns);
		int cnt = 0;
		// for (Iterator itr = scoreList.iterator(); itr.hasNext();) {
		for (Entry entry : dunsNbrMap.entrySet()) {
			if (maxDuns.equals(entry.getValue())) {
				cnt++;
				rowidObjs.add(entry.getKey());
			}
		}
		LOG.debug("No of records having highest match score :" + cnt);
		return rowidObjs;
	}
	
	// Method to calculate Lowest/minimum UCNCustNbr
		private List<Integer> minUCNCustNum(Map<Integer, Long> UCNCustNumMap) {
			Collection<Long> collVal = UCNCustNumMap.values();
			List<Long> uCNList = new ArrayList<Long>(collVal);
			List rowidObjs = new ArrayList(); //
			// Collections.sort(scoreList);
			// Object maxScore = scoreList.get(scoreList.size()-1);
			Long minUCN = Collections.min(uCNList);
			LOG.debug("Lowest UCNno: " + minUCN);
			int cnt = 0;
			// for (Iterator itr = scoreList.iterator(); itr.hasNext();) {
			for (Entry entry : UCNCustNumMap.entrySet()) {
				if (minUCN.equals(entry.getValue())) {
					cnt++;
					rowidObjs.add(entry.getKey());
				}
			}
			LOG.debug("No of records having lowest UCNtNo :" + cnt);
			return rowidObjs;
		}

	// Method to calculate Lowest/minimum SapCustNbr
	private List<Integer> minSapCustNum(Map<Integer, Integer> sapCustNumMap) {
		Collection<Integer> collVal = sapCustNumMap.values();
		List<Integer> sapList = new ArrayList<Integer>(collVal);
		List rowidObjs = new ArrayList(); //
		// Collections.sort(scoreList);
		// Object maxScore = scoreList.get(scoreList.size()-1);
		Integer minSap = Collections.min(sapList);
		LOG.debug("Lowest SapCustNo: " + minSap);
		int cnt = 0;
		// for (Iterator itr = scoreList.iterator(); itr.hasNext();) {
		for (Entry entry : sapCustNumMap.entrySet()) {
			if (minSap.equals(entry.getValue())) {
				cnt++;
				rowidObjs.add(entry.getKey());
			}
		}
		LOG.debug("No of records having lowest SapCustNo :" + cnt);
		return rowidObjs;
	}

	// Method to calculate HighestMatchScore
	private Integer highestMatchScore(Map<Integer, Integer> matchScoreMap) {
		Collection<Integer> collVal = matchScoreMap.values();
		List<Integer> scoreList = new ArrayList<Integer>(collVal);
		// Collections.sort(scoreList);
		// Object maxScore = scoreList.get(scoreList.size()-1);
		Integer maxScore = Collections.max(scoreList);
		LOG.debug("Highest Match score " + maxScore);

		return maxScore;
	}

	// Fetch MDMLegacyID for a specific ACCOUNT
	private String getMdmLegacyId(String pkeySrcObject) throws SQLException, ServiceProcessingException {
		Connection jdbcConn = null;
		JDBCConnectionProvider jDBCConnectionProvider = null;
		Statement statement = null;
		ResultSet resultSet = null;
		String mdmLegacyId = null;
		StringBuilder sql = new StringBuilder();
		sql.append("SELECT MDM_LEGACY_ID FROM C_B_ACCOUNT_XREF WHERE PKEY_SRC_OBJECT = ");
		sql.append("'" + pkeySrcObject + "'");
		LOG.info("SQL in getMdmLegacyId()->" + sql);
		try {
			jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
			jdbcConn = jDBCConnectionProvider.getJdbcConnectionFromDS();
			statement = jdbcConn.createStatement();
			resultSet = statement.executeQuery(sql.toString());

			while (resultSet.next()) {

				mdmLegacyId = resultSet.getString("MDM_LEGACY_ID");
			}
		} catch (SQLException exp) {
			LOG.error("Caught exception in getMdmLegacyId ", exp);
			// throw exp;
		} finally {
			// Closing connections
			if (resultSet != null)
				resultSet.close();
			if (statement != null)
				statement.close();
			if (jdbcConn != null)
				jdbcConn.close();
		}
		return mdmLegacyId;
	}

	public void setUcnSeq(String rowidObject, String partyType, String entityName) throws ServiceProcessingException {

		String ucnValue = null;
		try {
			// Get the next UCN value from Sequence Function
			ucnValue = getNextUCNValue(partyType);
			if (!Util.isNullOrEmpty(ucnValue)) {
				putUcnRequest(rowidObject, ucnValue, entityName);
			}

		} catch (ServiceProcessingException spExcp) {
			LOG.error("Error in setUCNSeq(): " + spExcp.getMessage());
			throw spExcp;
		}
	}

	public String getNextUCNValue(String partyType) throws ServiceProcessingException {

		LOG.debug("Executing getNextUCNValue()");
		String ucnFunction = configProps.getProperty("MFE_GET_UCN_BY_PARTY_TYPE");
		Connection jdbcConn = null;
		Statement statement = null;
		ResultSet resultSet = null;
		JDBCConnectionProvider jDBCConnectionProvider = null;
		String ucn = null;
		StringBuilder sql = new StringBuilder();
		sql.append("SELECT " + ucnFunction + "('" + partyType + "') FROM DUAL");
		LOG.debug("SQL for getNextUCNValue()--> " + sql);

		try {
			jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
			jdbcConn = jDBCConnectionProvider.getJdbcConnectionFromDS();
			statement = jdbcConn.createStatement();
			resultSet = statement.executeQuery(sql.toString());

			while (resultSet.next()) {
				ucn = resultSet.getString(1);
			}

			LOG.info("UCN obtained from Sequence function: " + ucn);

		} catch (SQLException exp) {
			LOG.error("SQLException in getting UCN sequence: ", exp);
			ServiceProcessingException customException = new ServiceProcessingException(exp);
			customException.setMessage("SQLException occured in getting UCN sequence: " + exp.getMessage());
			throw customException;
		} finally {
			// Closing connections
			try {
				if (resultSet != null)
					resultSet.close();
				if (statement != null)
					statement.close();
				if (jdbcConn != null)
					jdbcConn.close();
			} catch (SQLException sqlEx) {
				LOG.error("Error in closing resultSet/statement: " + sqlEx.getMessage());
			}
			// if (jDBCConnectionProvider != null)
			// jDBCConnectionProvider.closeJdbcConnection(jdbcConn);
		}

		LOG.debug("Executed getNextUCNValue()");
		return ucn;
	}

	// Put UCN in base object & XREF tables.
	public void putUcnRequest(String rowidObject, String ucnValue, String entityName)
			throws ServiceProcessingException {
		LOG.info("Executing putUCNRequest()");

		SiperianClient siperianClient = null;
		UserTransaction transaction = null;

		try {
			PutRequest putRequest = new PutRequest();
			PutResponse putResponse = null;
			String partyStatus = "A";
			// String systemUser = "Admin";
			String srcSystem = "Admin"; // trimming not required
			String srcPkey = null; // trimming not required
			String srcRowid = rowidObject; // trimming not required
			LOG.info("Executing PutRequest with src_system=" + srcSystem + " | scr_pkey=" + srcPkey + " | rowid_object="
					+ srcRowid);

			// Fetch Siperian Object from
			siperianClient = (SiperianClient) checkOut();
			// create transaction - commit if Delete and Put requests both
			// succeeded
			transaction = ((EjbSiperianClient) siperianClient).createTX(1200); // in
																				// seconds
			transaction.begin();

			// prepare PutRequest
			RecordKey recordKey = new RecordKey();
			recordKey.setRowid(srcRowid);
			recordKey.setSystemName(srcSystem);
			putRequest.setRecordKey(recordKey);

			Record record = new Record();
			record.setSiperianObjectUid(SiperianObjectType.BASE_OBJECT.makeUid(entityName));
			record.setField(new Field(PartyAttributes.UCN, ucnValue));
			if (entityName.equalsIgnoreCase(MDMAttributeNames.PARTY_BO)) {
				record.setField(new Field(MDMAttributeNames.SRC_UPDT_BY, systemUser));
				record.setField(new Field(PartyAttributes.STATUS_CD, partyStatus));
			}
			putRequest.setRecord(record);
			// execute Put request
			putResponse = (PutResponse) siperianClient.process(putRequest);

			LOG.info("Committing UCN transaction");
			transaction.commit();
			LOG.info("Put request for UCN assignment processed successfully: Action Type = "
					+ putResponse.getActionType() + " | Msg = " + putResponse.getMessage());

		} catch (SiperianServerException sifExcp) {
			LOG.error("SiperianServerException occured while assigning UCN by Put request: ", sifExcp);
			ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
			customException.setMessage(
					"SiperianServerException occured while assigning UCN by Put request: " + sifExcp.getMessage());
			throw customException;
		} catch (Exception excp) {
			LOG.error("Exception occured while assigning UCN by Put request: ", excp);
			ServiceProcessingException customException = new ServiceProcessingException(excp);
			customException.setMessage("Exception occured while assigning UCN by Put request: " + excp.getMessage());
			throw customException;
		} finally {
			checkIn(siperianClient);
		}

		LOG.info("Executed putUCNRequest()");

	}

	public void putmdmlegacyId(String srcPkey, String srcSystem, String mdmLegacyId) throws ServiceProcessingException {
		LOG.info("Executing putmdmlegacyId()");

		SiperianClient siperianClient = null;
		UserTransaction transaction = null;

		try {
			PutRequest putRequest = new PutRequest();
			PutResponse putResponse = null;
			// String partyStatus = "A";
			// String srcPkey = null;
			// String srcRowid = rowidObject; //trimming not required
			LOG.info("Executing putmdmlegacyId with src_system=" + srcSystem + " | mdmLegacyId=" + mdmLegacyId
					+ " | srcPkey=" + srcPkey);

			// Fetch Siperian Object from
			siperianClient = (SiperianClient) checkOut();
			// create transaction - commit if Delete and Put requests both
			// succeeded
			transaction = ((EjbSiperianClient) siperianClient).createTX(1200); // in
																				// seconds
			transaction.begin();

			// prepare PutRequest
			RecordKey recordKey = new RecordKey();
			// recordKey.setRowid(srcRowid);
			recordKey.setSourceKey(srcPkey);
			recordKey.setSystemName(srcSystem);
			putRequest.setRecordKey(recordKey);

			Record record = new Record();
			record.setSiperianObjectUid(SiperianObjectType.BASE_OBJECT.makeUid("C_B_PARTY"));
			record.setField(new Field(PartyAttributes.MDM_LEGACY_ID, mdmLegacyId));
			record.setField(new Field(MDMAttributeNames.SRC_UPDT_BY, systemUser));
			// record.setField(new
			// Field(PartyAttributes.STATUS_CD,partyStatus));
			putRequest.setRecord(record);
			// execute Put request
			putResponse = (PutResponse) siperianClient.process(putRequest);

			LOG.info("Committing legacyid transaction");
			transaction.commit();
			LOG.info("Put request for mdmLegacyId assignment processed successfully: Action Type = "
					+ putResponse.getActionType() + " | Msg = " + putResponse.getMessage());

		} catch (SiperianServerException sifExcp) {
			LOG.error("SiperianServerException occured while assigning mdmLegacyId by Put request: ", sifExcp);
			ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
			customException.setMessage(
					"SiperianServerException occured while assigning UCN by Put request: " + sifExcp.getMessage());
			throw customException;
		} catch (Exception excp) {
			LOG.error("Exception occured while assigning mdmLegacyId by Put request: ", excp);
			ServiceProcessingException customException = new ServiceProcessingException(excp);
			customException
					.setMessage("Exception occured while assigning mdmLegacyId by Put request: " + excp.getMessage());
			throw customException;
		} finally {
			checkIn(siperianClient);
		}

		LOG.info("Executed putmdmlegacyId()");

	}

	// To check if UCN is already present in Surviving Record or not.
	public String checkifUCNExists(String survivingRowidObject) throws ServiceProcessingException {

		LOG.debug("Executing checkifUCNExists()");
		Connection jdbcConn = null;
		Statement statement = null;
		PreparedStatement pstatement = null;
		ResultSet resultSet = null;
		JDBCConnectionProvider jDBCConnectionProvider = null;
		String ucn = null;
		StringBuilder sql = new StringBuilder();
		sql.append("SELECT UCN FROM C_B_PARTY_XREF WHERE ROWID_OBJECT = '" + survivingRowidObject
				+ "' AND ROWID_SYSTEM = 'SYS0' AND UCN IS NOT NULL ");
		// sql.append("SELECT UCN FROM C_B_PARTY_XREF WHERE ROWID_OBJECT = ? AND
		// ROWID_SYSTEM = 'SYS0' AND UCN IS NOT NULL ");
		LOG.debug("SQL for checkifUCNExists()--> " + sql);

		try {
			jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
			jdbcConn = jDBCConnectionProvider.getJdbcConnectionFromDS();
			// pstatement = jdbcConn.prepareStatement(sql.toString());
			// pstatement.setString(1, survivingRowidObject);

			// resultSet = pstatement.executeQuery();
			statement = jdbcConn.createStatement();
			resultSet = statement.executeQuery(sql.toString());

			while (resultSet.next()) {
				ucn = resultSet.getString(1);
			}

			LOG.debug("UCN exists & value is: " + ucn);

		} catch (SQLException exp) {
			LOG.error("SQLException in checkifUCNExists: ", exp);
			ServiceProcessingException customException = new ServiceProcessingException(exp);
			customException.setMessage("SQLException occured checkifUCNExists: " + exp.getMessage());
			throw customException;
		} finally {
			// Closing connections
			try {
				if (resultSet != null)
					resultSet.close();
				if (pstatement != null)
					pstatement.close();
				if (statement != null)
					statement.close();
				if (jdbcConn != null)
					jdbcConn.close();
			} catch (SQLException sqlEx) {
				LOG.error("Error in closing resultSet/statement: " + sqlEx.getMessage());
			}
		}

		LOG.debug("Executed checkifUCNExists()");
		return ucn;
	}

	// Search if Record exists in Hierarchy or not.
	private List<Integer> searchHierarchy(List<Integer> dunsNbrMapList)
			throws SQLException, ServiceProcessingException {
		Connection jdbcConn = null;
		Statement statement = null;
		ResultSet resultSet = null;
		JDBCConnectionProvider jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
		jdbcConn = jDBCConnectionProvider.getJdbcConnectionFromDS();

		Set<Integer> rowidSet = new HashSet<Integer>();
		StringBuilder sql = new StringBuilder();
		try {
			sql.append("select ROWID_PARTY,ROWID_PARTY_2 from C_B_PARTY_REL where TRIM(ROWID_PARTY) in (");

			for (Integer inVal : dunsNbrMapList) {
				sql.append(inVal + ",");
			}

			sql.deleteCharAt(sql.length() - 1).toString();

			sql.append(") or TRIM(ROWID_PARTY_2) in (");

			for (Integer inVal : dunsNbrMapList) {
				sql.append(inVal + ",");
			}

			sql.deleteCharAt(sql.length() - 1).toString();
			sql.append(")");

			LOG.info("SQL-->" + sql);

			statement = jdbcConn.createStatement();
			resultSet = statement.executeQuery(sql.toString());

			while (resultSet.next()) {

				rowidSet.add(Integer.parseInt(resultSet.getString("ROWID_PARTY").trim()));
				rowidSet.add(Integer.parseInt(resultSet.getString("ROWID_PARTY_2").trim()));
			}
		} finally {
			try {
				// Closing connections
				if (resultSet != null)
					resultSet.close();
				if (statement != null)
					statement.close();
				if (jdbcConn != null)
					jdbcConn.close();
			} catch (SQLException sqlEx) {
				LOG.error("Error in closing resultSet/statement: " + sqlEx);
			}
		}

		List<Integer> rowidList = new ArrayList<Integer>(rowidSet);

		return rowidList;
	}

	// Method for CreatingTask for Administrator
	private void processCreateTaskRequest(String tgtPartyRowId, String rowIdObject, String taskType, String title,
			String comment) {

		LOG.info("Executing processCreateTaskRequest()");
		SiperianClient siperianClient = null;

		try {
			String mergeOwnerUID = configProps.getProperty("mergeOwnerUID");
			String ownerUid = configProps.getProperty("ownerUID");
			String subjectAreaUID = configProps.getProperty("subjectAreaUID");

			CreateTaskResponse response = null;
			CreateTaskRequest request = new CreateTaskRequest();
			TaskData taskData = new TaskData();

			if (taskType.equalsIgnoreCase("Merge")) {
				taskData.setOwnerUid(mergeOwnerUID);
				taskData.setPriority(1);

			} else {
				taskData.setOwnerUid(ownerUid);

			}

			TaskRecord taskRecord = new TaskRecord();
			RecordKey recordKey = new RecordKey();
			taskRecord.setSiperianObjectUid(SiperianObjectType.BASE_OBJECT.makeUid(MDMAttributeNames.PARTY_BO));
			recordKey.setRowid(rowIdObject);
			LOG.debug("rowIdObject: " + rowIdObject);
			taskRecord.setRecordKey(recordKey);
			List<TaskRecord> recordList = new ArrayList<TaskRecord>();
			recordList.add(taskRecord);

			if (taskType.equalsIgnoreCase("Merge")) {

				// for (HighestScoreRecordHolder srcRecHolder :
				// mergeSorceHolderMap.values())
				// tgtPartyRowId = srcRecHolder.getPartyRowIDObject();

				TaskRecord taskRecord2 = new TaskRecord();
				taskRecord2.setSiperianObjectUid(SiperianObjectType.BASE_OBJECT.makeUid(MDMAttributeNames.PARTY_BO));
				RecordKey recordKey2 = new RecordKey();
				recordKey2.setRowid(tgtPartyRowId);
				LOG.debug("tgtPartyRowId :" + tgtPartyRowId);
				taskRecord2.setRecordKey(recordKey2);
				recordList.add(0, taskRecord2);
			}

			taskData.setTaskRecords(recordList);
			//request.setTaskData(taskData);
			taskData.setTitle(title);
			taskData.setComment(comment);

			Calendar cal = Calendar.getInstance();
			cal.setTime(new Date(System.currentTimeMillis()));
			cal.add(Calendar.DATE, 7);

			taskData.setDueDate(cal.getTime());
			// taskData.setSubjectAreaUid("SUBJECT_AREA.test|Person");
			taskData.setSubjectAreaUid(subjectAreaUID);
			// taskData.setTaskType("ReviewNoApprove");
			taskData.setTaskType(taskType);
			request.setTaskData(taskData);
			siperianClient = (SiperianClient) checkOut();

			LOG.info("processing CreateTaskRequest");
			response = (CreateTaskResponse) siperianClient.process(request);
			LOG.info("CreateTaskResponse result: " + response.getMessage());
			LOG.info("CreateTaskResponse taskId: " + response.getTaskId());
			LOG.info("CreateTaskResponse interactionId: " + response.getInteractionId());
			LOG.info("after response");
		} catch (Exception excp) {
			LOG.error("Caught Exception in CreateTaskRequest Error Message: " + excp);
		} finally {
			checkIn(siperianClient);
		}
		LOG.info("Executed processCreateTaskRequest()");
	}

	// generate match token for the party record
	private void processTokenizeRequest(String rowidObject, String BO) throws ServiceProcessingException {

		if (!Util.isNullOrEmpty(rowidObject)) {
			rowidObject = rowidObject.trim();
		}
		LOG.debug("Executing processTokenizeRequest()" + rowidObject);
		SiperianClient siperianClient = null;

		try {
			siperianClient = (SiperianClient) checkOut();

			TokenizeRequest tokenizeRequest = new TokenizeRequest();
			tokenizeRequest.setSiperianObjectUid(SiperianObjectType.BASE_OBJECT.makeUid(BO));
			RecordKey recordKey = new RecordKey();
			recordKey.setRowid(rowidObject);
			tokenizeRequest.setRecordKey(recordKey);
			tokenizeRequest.setActionType("Update");
			TokenizeResponse tokenizeResponse = (TokenizeResponse) siperianClient.process(tokenizeRequest);
			LOG.info("Match Token generated for PartyID: " + rowidObject + " Token msg: "
					+ tokenizeResponse.getMessage());
			// Delete Junk token after Tokenize for party
			if (BO.equalsIgnoreCase("C_B_PARTY")) {
				prospectPartyDAO.deleteJunkToken(rowidObject);
			}
			LOG.info("Junk Token has deleted Successfully");
			LOG.debug("Executed processTokenizeRequest()");
		} catch (Exception excp) {
			LOG.error("Caught exception within processTokenizeRequest() " + excp.getMessage());

			ServiceProcessingException customExcp = new ServiceProcessingException(excp);
			throw customExcp;
		} finally {
			checkIn(siperianClient);
		}
	}
	/*
	 * private void processTokenizeRequest(PutResponseDataHolder
	 * putRespDataParty) throws ServiceProcessingException {
	 * 
	 * LOG.debug("Executing processTokenizeRequest()"); SiperianClient
	 * siperianClient = null;
	 * 
	 * try { siperianClient = (SiperianClient) checkOut();
	 * 
	 * TokenizeRequest tokenizeRequest = new TokenizeRequest();
	 * tokenizeRequest.setSiperianObjectUid(SiperianObjectType.BASE_OBJECT.
	 * makeUid("C_B_PARTY")); RecordKey recordKey = new RecordKey();
	 * recordKey.setRowid(putRespDataParty.getRowidObject());
	 * 
	 * tokenizeRequest.setRecordKey(recordKey); //
	 * if(putRespDataParty.getActionType().equalsIgnoreCase("No Action")) // {
	 * // tokenizeRequest.setActionType("Update"); // } else {
	 * tokenizeRequest.setActionType(putRespDataParty.getActionType()); // }
	 * TokenizeResponse tokenizeResponse = (TokenizeResponse)
	 * siperianClient.process(tokenizeRequest); LOG.info(
	 * "Match Token generated for PartyID: " + putRespDataParty.getRowidObject()
	 * + " Token msg: " + tokenizeResponse.getMessage());
	 * 
	 * LOG.debug("Executed processTokenizeRequest()"); } catch (Exception excp)
	 * { LOG.error("Caught exception within processTokenizeRequest() " +
	 * excp.getMessage()); ServiceProcessingException customExcp = new
	 * ServiceProcessingException(excp); throw customExcp; } finally {
	 * checkIn(siperianClient); } }
	 */

	public PartyXrefType processUpdateRequest(PartyXrefType upsertParty, PartyXrefType insertedPartyData,
			List<String> sendToSrcList, String survivingPartyRowid, PartyType survivingPartyProfileFromBO)
			throws ServiceProcessingException {
		LOG.info("Executing processUpdateRequest()");

		SiperianClient siperianClient = null;
		UserTransaction transaction = null;

		// PartyXrefType updatePartyParam = insertedPartyData;
		PartyXrefType legacyPartyData = null;
		UpsertPartyResponse upsertPartyResponse = new UpsertPartyResponse();
		int updatePartyCnt = 0;

		// UpdateRecordHolder updateRecordHolder = null;
		PutResponseDataHolder putRespDataParty = null;
		List<PutResponseDataHolder> putRespDataAccountList = null;
		List<PutResponseDataHolder> putRespDataAddressList = null;
		List<PutResponseDataHolder> putRespDataCommunicationList = null;
		List<PutResponseDataHolder> putRespDataClassificationList = null;
		List<PutResponseDataHolder> putRespDataPartyOrgExtList = null;
		Map<String, Object> putRespDataHolderMap = new HashMap<String, Object>();
		PartyXrefType upsertPartyPayload = null;
		List<PartyXrefType> partyList = new ArrayList<PartyXrefType>();

		try {
			if (insertedPartyData != null) {
				partyList = getLegacyRefRecords(insertedPartyData, sendToSrcList, survivingPartyRowid);
			}
		} catch (SQLException sqlexp) {
			LOG.error("Caught exception during getLegacyRefRecords().", sqlexp);
		} // Checking for draft account
		String draftFlag = insertedPartyData.getAccount().get(0).getDraftAccountFlag();
		boolean isDraftAcc = Constant.STR_Y.equalsIgnoreCase(draftFlag) ? true : false;
		LOG.info("Is draft acount " + isDraftAcc);
		// checking JP country
		if (!Util.isNullOrEmpty(upsertParty.getAddress().get(0).getCOUNTRYCD())) {
			if (!upsertParty.getAddress().get(0).getCOUNTRYCD().equalsIgnoreCase("JAPAN")
					&& !upsertParty.getAddress().get(0).getCOUNTRYCD().equalsIgnoreCase("JPN")
					&& !upsertParty.getAddress().get(0).getCOUNTRYCD().equalsIgnoreCase("JP")) {
				LOG.info("Non JP Country exist");
			} else {
				LOG.info("JP Country exist");
				isJapan = Boolean.TRUE;
			}
		}

		try {

			siperianClient = (SiperianClient) checkOut();
			if (partyList != null && partyList.size() > 0) {
				for (int index = 0; index < partyList.size(); index++) {
					legacyPartyData = new PartyXrefType();
					legacyPartyData = partyList.get(index);

					// Setting
					if (legacyPartyData != null) {
						String sourceName = legacyPartyData.getXREF().get(0).getSRCSYSTEM();
						String sourceKey = legacyPartyData.getXREF().get(0).getSRCPKEY();
						LOG.debug("Checking the xref presence src system: " + sourceName + "PKEY  " + sourceKey);

						// Party and children Of LegacyRef record overwritten
						// with inserted values
						// Condtion to check Source system is SFC and Draft Flag
						// is Y -

						if (!isDraftAcc) {
							overwriteForOrchestration(insertedPartyData, legacyPartyData, survivingPartyProfileFromBO);
							LOG.debug("Populated Legacy Party: " + legacyPartyData.getROWIDOBJECT());
						}

						lastUpdateDate = Util.getCurrentTimeZone();

						/*
						 * all the successful put calls will return rowid_object
						 * of newly created records and that will be set into
						 * corresponding response object. Response will also
						 * contain all the input values of Party and child
						 * entities. So before executing Put calls copy all
						 * request attributes to response
						 */

						// create transaction - commit if cleansePut requests
						// succeed for
						// Party and all the child entities
						transaction = ((EjbSiperianClient) siperianClient).createTX(300000);
						transaction.begin();

						if (!isDraftAcc) {
							// Create Party
							putRespDataParty = putParty(legacyPartyData, siperianClient);
							// Create Account
							if (legacyPartyData.getAccount() != null) {
								putRespDataAccountList = putAccount(legacyPartyData.getAccount(), legacyPartyData,
										siperianClient);
							}
							// Create Address
							if (legacyPartyData.getAddress() != null) {
								putRespDataAddressList = putAddress(legacyPartyData.getAddress(), legacyPartyData,
										siperianClient);
							}
							// Create Communication
							if (legacyPartyData.getCommunication() != null) {
								putRespDataCommunicationList = putCommunication(legacyPartyData.getCommunication(),
										legacyPartyData, siperianClient);
							}
							LOG.info(updatePartyCnt
									+ " LegacyRef Party/Address/Comm for non draft record has been updated");
						}

						/*if (isJapan) {
							if (legacyPartyData.getClassification() != null) {
								putClassification(legacyPartyData.getClassification(), legacyPartyData, siperianClient);
							}
							LOG.info("Classification data for  Japan record has been updated");
						}*/
						// Create Classification(from BO to xref for Nonjapan)
						upsertAccSegAssignProcess(insertedPartyData, survivingPartyProfileFromBO, siperianClient); //need to check with Venkat
						// commit transaction
						transaction.commit();
						updatePartyCnt++;
						LOG.info(updatePartyCnt + " count of record updated");
					} else {
						LOG.info("No MDM_LEGACY Ref Record Found. Hence Bypassing Put process.");
						return null;
					}
				}

			}

			upsertPartyResponse.setStatus(upsertPartyResponse.getStatus() == null ? "" : "\n");

			upsertPartyResponse.setStatus(upsertPartyResponse.getStatus() + " Updated LegacyRef PartySrcPKEY: "
					+ upsertParty.getXREF().get(0).getSRCPKEY() + " PartySrcSYS: "
					+ upsertParty.getXREF().get(0).getSRCSYSTEM());

		} catch (ServiceProcessingException excp) {

			LOG.error("Exception occured while getting LegacyParty Put requests: ", excp);

			// warning.append("Process failed while Updating LegayID Ref
			// Record.Task generated for Admin group for LegacyREF Update. \n");
			try {
				transaction.rollback();

			} catch (SystemException txExcp) {
				LOG.error("Failed to rollback transaction for Put requests : " + txExcp.toString());
			}
			throw excp;
		} catch (Exception ex) {
			// upsertPartyResponse.setErrorMsg(upsertPartyResponse.getErrorMsg()
			// + "CleansePut operation failed for Party " +
			// putRespDataParty.getSourceKey());
			// upsertParty.setErrorMsg("CleansePut operation failed");

			LOG.error("Exception occured while getting LegacyParty Put requests: ", ex);

			// warning.append("Process failed while Updating LegayID Ref
			// Record.Task generated for Admin group for LegacyREF Update. \n");
			try {
				transaction.rollback();
			} catch (SystemException txExcp) {
				LOG.error("Failed to rollback transaction for cleansePut requests : " + txExcp.toString());
				txExcp.printStackTrace();
			}
			ServiceProcessingException customException = new ServiceProcessingException(ex);
			customException.setMessage("Failed to process cleansePut SIF request. " + customException.getMessage());

			throw customException;
		} finally {
			checkIn(siperianClient);
		}
		try {
			// set rowid_object of created records into response and
			// set the PutResponseDataHolder object/list of object into Map
			// against corresponding entity name
			// set rowid_object of Party into response

			PartyUpsertRespType partyUpsertResp = new PartyUpsertRespType();
			Account account = null;
			List<Account> accountList = new ArrayList<Account>();
			Address address = null;
			List<Address> addressList = new ArrayList<Address>();
			Communication comm = null;
			List<Communication> commList = new ArrayList<Communication>();
			Classification classification = null;
			List<Classification> classificationList = new ArrayList<Classification>();
			PartyOrgExt partyOrgExt = null;
			List<PartyOrgExt> partyOrgExtList = new ArrayList<PartyOrgExt>();

			// set rowid_object of Party into response
			if (putRespDataParty != null) {
				partyUpsertResp.setROWIDOBJECT(putRespDataParty.getRowidObject());
				partyUpsertResp.setSRCSYSTEM(putRespDataParty.getSystemName().trim());
				partyUpsertResp.setSRCSYSTEMID(putRespDataParty.getSourceKey());
				putRespDataHolderMap.put(MDMAttributeNames.ENTITY_PARTY, putRespDataParty);
			}

			// set rowid_object of Account into response
			if (putRespDataAccountList != null) {
				putRespDataHolderMap.put(MDMAttributeNames.ENTITY_ACCOUNT, putRespDataAccountList);

				for (int index = 0; index < putRespDataAccountList.size(); index++) {

					account = new Account();

					account.setROWIDACCOUNT(putRespDataAccountList.get(index).getRowidObject());
					account.setSRCSYSTEM(putRespDataAccountList.get(index).getSystemName().trim());
					account.setSRCSYSTEMID(putRespDataAccountList.get(index).getSourceKey());
					accountList.add(account);

				}
			}
			// set rowid_object of Address into response
			if (putRespDataAddressList != null) {
				putRespDataHolderMap.put(MDMAttributeNames.ENTITY_ADDRESS, putRespDataAddressList);

				for (int index = 0; index < putRespDataAddressList.size(); index++) {
					address = new Address();
					address.setROWIDADDRESS(putRespDataAddressList.get(index).getRowidObject());
					address.setSRCSYSTEM(putRespDataAddressList.get(index).getSystemName().trim());
					address.setSRCSYSTEMID(putRespDataAddressList.get(index).getSourceKey());
					addressList.add(address);

				}
			}
			// set rowid_object of Communication into response
			if (putRespDataCommunicationList != null) {
				putRespDataHolderMap.put(MDMAttributeNames.ENTITY_COMM, putRespDataCommunicationList);

				for (int index = 0; index < putRespDataCommunicationList.size(); index++) {
					comm = new Communication();
					comm.setROWIDCOMMUNICATION(
							((PutResponseDataHolder) putRespDataCommunicationList.get(index)).getRowidObject());
					comm.setSRCSYSTEM(
							((PutResponseDataHolder) putRespDataCommunicationList.get(index)).getSystemName().trim());
					comm.setSRCSYSTEMID(
							((PutResponseDataHolder) putRespDataCommunicationList.get(index)).getSourceKey());
					commList.add(comm);

				}
			}
			// set rowid_object of Classification into response
			if (putRespDataClassificationList != null) {
				putRespDataHolderMap.put(MDMAttributeNames.ENTITY_CLASSIF, putRespDataClassificationList);

				for (int index = 0; putRespDataClassificationList != null
						&& index < putRespDataClassificationList.size(); index++) {
					classification = new Classification();
					classification.setROWIDCLASSIFICTN(
							((PutResponseDataHolder) putRespDataClassificationList.get(index)).getRowidObject());
					classification.setSRCSYSTEM(
							((PutResponseDataHolder) putRespDataClassificationList.get(index)).getSystemName().trim());
					classification.setSRCSYSTEMID(
							((PutResponseDataHolder) putRespDataClassificationList.get(index)).getSourceKey());
					classificationList.add(classification);

				}
			}
			// set rowid_object of Party_Org_Ext into response
			if (putRespDataPartyOrgExtList != null) {
				putRespDataHolderMap.put(MDMAttributeNames.ENTITY_ORG_EXT, putRespDataPartyOrgExtList);

				for (int index = 0; putRespDataPartyOrgExtList != null
						&& index < putRespDataPartyOrgExtList.size(); index++) {
					partyOrgExt = new PartyOrgExt();
					partyOrgExt.setROWIDORGEXTN(
							((PutResponseDataHolder) putRespDataPartyOrgExtList.get(index)).getRowidObject());
					partyOrgExt.setSRCSYSTEM(
							((PutResponseDataHolder) putRespDataPartyOrgExtList.get(index)).getSystemName().trim());
					partyOrgExt.setSRCSYSTEMID(
							((PutResponseDataHolder) putRespDataPartyOrgExtList.get(index)).getSourceKey());
					partyOrgExtList.add(partyOrgExt);

				}
			}
			partyUpsertResp.getAccount().addAll(accountList);
			partyUpsertResp.getAddress().addAll(addressList);
			partyUpsertResp.getCommunication().addAll(commList);
			partyUpsertResp.getClassification().addAll(classificationList);
			partyUpsertResp.getPartyOrgExt().addAll(partyOrgExtList);
			upsertPartyResponse.getParty().add(partyUpsertResp);

			// Logging UpsertPartyResponse details
			LOG.debug("Printing DummyUpdate service response:-");
			Util.printObjectTreeInXML(UpsertPartyResponse.class, upsertPartyResponse);

		} catch (Exception excp) {
			LOG.error("Exception occured while getting LegacyParty Put response for Party ");
			ServiceProcessingException customException = new ServiceProcessingException(excp);
			customException.setMessage("Exception occured while getting LegacyParty Put response for Party. "
					+ customException.getMessage());
			throw customException;
		}

		try {

			if (!isDraftAcc) {
				LOG.info("Calling Tokenize process for LegacyRef Record.");
				processTokenizeRequest(survivingPartyProfileFromBO.getROWIDOBJECT(), "C_B_PARTY");
			}

		} catch (SiperianServerException sifExcp) {
			LOG.error("SiperianServerException occured while processing TokenizeRequest for processUpdateRequest()");
			ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
			customException
					.setMessage("SIF exception occured while processing Tokenize request for processUpdateRequest(). "
							+ customException.getMessage());

			throw customException;
		} catch (Exception excp) {
			LOG.error("Exception occured while processing TokenizeRequest for processUpdateRequest()");
			ServiceProcessingException customException = new ServiceProcessingException(excp);
			customException
					.setMessage("Exception occured while processing Tokenize request for processUpdateRequest(). "
							+ customException.getMessage());
		}

		LOG.info("Executed processUpdateRequest()");
		return legacyPartyData;
	}
	public PartyXrefType processSelfUpdateRequest(PartyXrefType upsertParty, PartyXrefType insertedPartyData,
			PartyXrefType legacyPartyData, String survivingPartyRowid, PartyType survivingPartyProfileFromBO)
			throws ServiceProcessingException {
		LOG.info("Executing processUpdateRequest()");

		SiperianClient siperianClient = null;
		UserTransaction transaction = null;

		// PartyXrefType updatePartyParam = insertedPartyData;
		UpsertPartyResponse upsertPartyResponse = new UpsertPartyResponse();
		int updatePartyCnt = 0;

		// UpdateRecordHolder updateRecordHolder = null;
		PutResponseDataHolder putRespDataParty = null;
		List<PutResponseDataHolder> putRespDataAccountList = null;
		List<PutResponseDataHolder> putRespDataAddressList = null;
		List<PutResponseDataHolder> putRespDataCommunicationList = null;
		List<PutResponseDataHolder> putRespDataClassificationList = null;
		List<PutResponseDataHolder> putRespDataPartyOrgExtList = null;
		Map<String, Object> putRespDataHolderMap = new HashMap<String, Object>();

		String draftFlag = insertedPartyData.getAccount().get(0).getDraftAccountFlag();
		boolean isDraftAcc = Constant.STR_Y.equalsIgnoreCase(draftFlag) ? true : false;
		LOG.info("Is draft acount " + isDraftAcc);
		// checking JP country
		if (!Util.isNullOrEmpty(upsertParty.getAddress().get(0).getCOUNTRYCD())) {
			if (!upsertParty.getAddress().get(0).getCOUNTRYCD().equalsIgnoreCase("JAPAN")
					&& !upsertParty.getAddress().get(0).getCOUNTRYCD().equalsIgnoreCase("JPN")
					&& !upsertParty.getAddress().get(0).getCOUNTRYCD().equalsIgnoreCase("JP")) {
				LOG.info("Non JP Country exist");
			} else {
				LOG.info("JP Country exist");
				isJapan = Boolean.TRUE;
			}
		}

		try {

			siperianClient = (SiperianClient) checkOut();
			
					
					// Setting
					if (legacyPartyData != null) {
						String sourceName = legacyPartyData.getXREF().get(0).getSRCSYSTEM();
						String sourceKey = legacyPartyData.getXREF().get(0).getSRCPKEY();
						LOG.debug("Checking the xref presence src system: " + sourceName + "PKEY  " + sourceKey);

						// Party and children Of LegacyRef record overwritten
						// with inserted values
						// Condtion to check Source system is SFC and Draft Flag
						// is Y -

						if (!isDraftAcc) {
							overwriteForOrchestration(insertedPartyData, legacyPartyData, survivingPartyProfileFromBO);
							LOG.debug("Populated Legacy Party: " + legacyPartyData.getROWIDOBJECT());
						}

						lastUpdateDate = Util.getCurrentTimeZone();

						/*
						 * all the successful put calls will return rowid_object
						 * of newly created records and that will be set into
						 * corresponding response object. Response will also
						 * contain all the input values of Party and child
						 * entities. So before executing Put calls copy all
						 * request attributes to response
						 */

						// create transaction - commit if cleansePut requests
						// succeed for
						// Party and all the child entities
						transaction = ((EjbSiperianClient) siperianClient).createTX(300000);
						transaction.begin();

						if (!isDraftAcc) {
							// Create Party
							putRespDataParty = putParty(legacyPartyData, siperianClient);
							// Create Account
							if (legacyPartyData.getAccount() != null) {
								putRespDataAccountList = putAccount(legacyPartyData.getAccount(), legacyPartyData,
										siperianClient);
							}
							// Create Address
							if (legacyPartyData.getAddress() != null) {
								putRespDataAddressList = putAddress(legacyPartyData.getAddress(), legacyPartyData,
										siperianClient);
							}
							// Create Communication
							if (legacyPartyData.getCommunication() != null) {
								putRespDataCommunicationList = putCommunication(legacyPartyData.getCommunication(),
										legacyPartyData, siperianClient);
							}
							LOG.info(updatePartyCnt
									+ " LegacyRef Party/Address/Comm for non draft record has been updated");
						}

						/*if (isJapan) {
							if (legacyPartyData.getClassification() != null) {
								putClassification(legacyPartyData.getClassification(), legacyPartyData, siperianClient);
							}
							LOG.info("Classification data for  Japan record has been updated");
						}
						// Create Classification(from BO to xref for Nonjapan)
						upsertAccSegAssignProcess(insertedPartyData, survivingPartyProfileFromBO, siperianClient);*/
						// commit transaction
						transaction.commit();
						updatePartyCnt++;
						LOG.info(updatePartyCnt + " count of record updated");
					} else {
						LOG.info("No MDM_LEGACY Ref Record Found. Hence Bypassing Put process.");
						return null;
					}
				

			upsertPartyResponse.setStatus(upsertPartyResponse.getStatus() == null ? "" : "\n");

			upsertPartyResponse.setStatus(upsertPartyResponse.getStatus() + " Updated LegacyRef PartySrcPKEY: "
					+ upsertParty.getXREF().get(0).getSRCPKEY() + " PartySrcSYS: "
					+ upsertParty.getXREF().get(0).getSRCSYSTEM());

		} catch (ServiceProcessingException excp) {

			LOG.error("Exception occured while getting LegacyParty Put requests: ", excp);

			// warning.append("Process failed while Updating LegayID Ref
			// Record.Task generated for Admin group for LegacyREF Update. \n");
			try {
				transaction.rollback();

			} catch (SystemException txExcp) {
				LOG.error("Failed to rollback transaction for Put requests : " + txExcp.toString());
			}
			throw excp;
		} catch (Exception ex) {
			// upsertPartyResponse.setErrorMsg(upsertPartyResponse.getErrorMsg()
			// + "CleansePut operation failed for Party " +
			// putRespDataParty.getSourceKey());
			// upsertParty.setErrorMsg("CleansePut operation failed");

			LOG.error("Exception occured while getting LegacyParty Put requests: ", ex);

			// warning.append("Process failed while Updating LegayID Ref
			// Record.Task generated for Admin group for LegacyREF Update. \n");
			try {
				transaction.rollback();
			} catch (SystemException txExcp) {
				LOG.error("Failed to rollback transaction for cleansePut requests : " + txExcp.toString());
				txExcp.printStackTrace();
			}
			ServiceProcessingException customException = new ServiceProcessingException(ex);
			customException.setMessage("Failed to process cleansePut SIF request. " + customException.getMessage());

			throw customException;
		} finally {
			checkIn(siperianClient);
		}
		

		try {

			if (!isDraftAcc) {
				LOG.info("Calling Tokenize process for LegacyRef Record.");
				processTokenizeRequest(survivingPartyProfileFromBO.getROWIDOBJECT(), "C_B_PARTY");
			}

		} catch (SiperianServerException sifExcp) {
			LOG.error("SiperianServerException occured while processing TokenizeRequest for processUpdateRequest()");
			ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
			customException
					.setMessage("SIF exception occured while processing Tokenize request for processUpdateRequest(). "
							+ customException.getMessage());

			throw customException;
		} catch (Exception excp) {
			LOG.error("Exception occured while processing TokenizeRequest for processUpdateRequest()");
			ServiceProcessingException customException = new ServiceProcessingException(excp);
			customException
					.setMessage("Exception occured while processing Tokenize request for processUpdateRequest(). "
							+ customException.getMessage());
		}

		LOG.info("Executed processUpdateRequest()");
		return legacyPartyData;
	}
	private List<PutResponseDataHolder> putLegacyClassification(PartyXrefType upsertPartyPayload,
			SiperianClient siperianClient) {
		LOG.debug("Inside putLegacyClassification()");

		boolean isSAPDummyUpdate = true;
		List<PutResponseDataHolder> putRespDataClassificationList = null;

		Map<String, List> existingClassPkeyMap = new HashMap<String, List>();
		List<String> newClassPkeyList = new ArrayList<String>();
		Map<String, List<String>> recToDelClassMap = new HashMap<String, List<String>>();

		try {
			// Fetch current existing CLASSIFICATION SRC_PKEYs from MDM DB for
			// SAP and SBL
			existingClassPkeyMap = getPresentClassPkeyList(upsertPartyPayload);

			// Fetch new CLASSIFICATION SRC_PKEYs from input request
			for (int itemIndex = 0; itemIndex < upsertPartyPayload.getClassification().size(); itemIndex++) {
				String tmpstr = upsertPartyPayload.getClassification().get(itemIndex).getSRCPKEY() + ":"
						+ upsertPartyPayload.getClassification().get(itemIndex).getCLASSIFICTNTYPE() + ":"
						+ upsertPartyPayload.getClassification().get(itemIndex).getCLASSIFICTNVALUE();
				newClassPkeyList.add(tmpstr);
				LOG.debug("newClassPkeyList: " + newClassPkeyList.get(itemIndex));
			}

			if (existingClassPkeyMap != null && existingClassPkeyMap.size() > 0) {
				LOG.debug("existingClassPkeyMap size: " + existingClassPkeyMap.size());
				// Finding the Old CLASSIFICATION SRC_PKEYs to be deleted
				for (Entry<String, List> entry : existingClassPkeyMap.entrySet()) {
					String classExistingPkey = entry.getKey();
					boolean matchingRecFound = false;
					LOG.debug("existingClassPkey in Map: " + classExistingPkey);
					for (String newPkey : newClassPkeyList) {
						LOG.debug("newPkey: " + newPkey);
						if (classExistingPkey.contains(newPkey)) {
							// Delete the Existing CLASSIFICATION from MDM DB
							matchingRecFound = true;
							LOG.debug("classExistingPkey: " + classExistingPkey + " |contains newPkey: " + newPkey);
							break;
						}
					}
					if (!matchingRecFound) {
						LOG.debug("Existing classification record is not matching with records in payload");
						LOG.debug("End_date of existing classification record: " + entry.getValue().get(2).toString());
						if (((String) entry.getValue().get(2)).contains("9999")) {// IF
																					// END_DATE
																					// =
																					// 31-DEC-9999,
																					// it's
																					// Active
																					// Record
							List<String> classfctnList = new ArrayList<String>();
							classfctnList.add((String) entry.getValue().get(0));// ROWID_OBJECT
							classfctnList.add((String) entry.getValue().get(1));// START_DATE
							classfctnList.add((String) entry.getValue().get(2));// END_DATE
							classfctnList.add((String) entry.getValue().get(3));// CLASSIFCTN_TYPE
							classfctnList.add((String) entry.getValue().get(4));// CLASSIFCTN_VALUE
							recToDelClassMap.put(classExistingPkey, classfctnList);
							LOG.debug("classExistingPkey: " + classExistingPkey + " will be in-activated.");
						}
					}
				} // end of for
			}

			lastUpdateDate = Util.getCurrentTimeZone();
			deleteChildDAO.setSysDate(lastUpdateDate);

			// In-activate Old CLASSFCTN Records For SBL/SAP
			if (recToDelClassMap != null && recToDelClassMap.size() > 0) {
				deleteChildDAO.updateStatus(upsertPartyPayload, recToDelClassMap, MDMAttributeNames.CLASS_BO,
						siperianClient);
			}

			lastUpdateDate = Util.getCurrentTimeZone();

			if (upsertPartyPayload.getClassification() != null) {
				putRespDataClassificationList = cleansePutClassification(existingClassPkeyMap,
						upsertPartyPayload.getClassification(), upsertPartyPayload, siperianClient, isSAPDummyUpdate);
			}

		} catch (ServiceProcessingException excp) {

			LOG.error("Exception occured inside putLegacyClassification requests: ", excp);

		} catch (Exception ex) {

			LOG.error("Exception occured while inside putLegacyClassification requests: ", ex);
			ServiceProcessingException customException = new ServiceProcessingException(ex);
			customException.setMessage("Failed to process cleansePut SIF request." + customException.getMessage());
			customException.printStackTrace();
			// throw customException;
		}

		LOG.debug("Completed putLegacyClassification()");
		return putRespDataClassificationList;
	}

	private PartyXrefType copyLegacyClassfToUpsertClassfRequest(PartyXrefType upsertParty,
			PartyXrefType legacyPartyData) {
		LOG.debug("Inside copyLegacyClassfToUpsertClassfRequest");

		// Setting Classification
		// clear all the existing classification record from legacy party and
		// create only all the 'Segment - Final Value' records from inserted
		// party.
		// CleansePut will be used for legacy classification record update
		ClassificationXrefType classificationXref = null;
		List<ClassificationXrefType> classificationXrefList = new ArrayList<ClassificationXrefType>();

		for (int index = 0; index < legacyPartyData.getClassification().size(); index++) {
			// if ("Segment - Final
			// Value".equals(legacyPartyData.getClassification().get(index).getCLASSIFICTNTYPE()))
			// {
			if (legacyPartyData.getClassification().get(index).getCLASSIFICTNTYPE()
					.equalsIgnoreCase("Segment - Final Value")
					|| legacyPartyData.getClassification().get(index).getCLASSIFICTNTYPE()
							.equalsIgnoreCase("Segmentation Process Code")
					|| legacyPartyData.getClassification().get(index).getCLASSIFICTNTYPE()
							.equalsIgnoreCase("Segment - System Assigned Value")) {
				LOG.info(
						"Copying 'Segment - Final Value' classification records from upsertPartyRequest to temp Object");
				classificationXref = new ClassificationXrefType();
				classificationXref.setSRCPKEY(legacyPartyData.getClassification().get(index).getSRCPKEY().trim());
				classificationXref.setSRCSYSTEM(legacyPartyData.getXREF().get(0).getSRCSYSTEM().trim());
				classificationXref
						.setCLASSIFICTNTYPE(legacyPartyData.getClassification().get(index).getCLASSIFICTNTYPE());
				classificationXref
						.setCLASSIFICTNVALUE(legacyPartyData.getClassification().get(index).getCLASSIFICTNVALUE());
				classificationXref.setSTARTDATE(legacyPartyData.getClassification().get(index).getSTARTDATE());
				classificationXref.setENDDATE(legacyPartyData.getClassification().get(index).getENDDATE());
				classificationXrefList.add(classificationXref);

			}
		}
		if (upsertParty.getClassification().size() > 0) {
			upsertParty.getClassification().clear();
		}
		// Keeping Only 'Segment - Final Value' classification records in
		// upsertPartyRequest
		upsertParty.getClassification().addAll(classificationXrefList);

		// Copying Legacy SRC_PKEY & SRC_SYSTEM in upsertPartyRequest
		// Classification records
		for (int index = 0; index < upsertParty.getClassification().size(); index++) {
			upsertParty.getClassification().get(index).setSRCPKEY(legacyPartyData.getXREF().get(0).getSRCPKEY().trim());
			upsertParty.getClassification().get(index)
					.setSRCSYSTEM(legacyPartyData.getXREF().get(0).getSRCSYSTEM().trim());
		}

		// Copying Legacy SRC_PKEY & SRC_SYSTEM in upsertPartyRequest XREF
		upsertParty.getXREF().get(0).setSRCPKEY(legacyPartyData.getXREF().get(0).getSRCPKEY().trim());
		upsertParty.getXREF().get(0).setSRCSYSTEM(legacyPartyData.getXREF().get(0).getSRCSYSTEM().trim());

		LOG.debug("Printing UpsertPartyClassfctn Request after overwrite:");
		UpsertPartyRequest upsertRequest = new UpsertPartyRequest();
		upsertRequest.getParty().add(upsertParty);
		Util.printObjectTreeInXML(UpsertPartyRequest.class, upsertRequest);

		LOG.debug("Executed copyLegacyClassfToUpsertClassfRequest");
		return upsertParty;
	}

	// Overwriting LegacyRef Party with Original InsertedPartyData
	/*
	 * insertedPartyDataXref - SFDC Xref legacyPartyData - SAP,SBL,SFC xref
	 * insertedPartyData - BO copy
	 */
	public void overwriteForOrchestration(PartyXrefType insertedPartyDataXref, PartyXrefType legacyPartyData,
			PartyType insertedPartyData) throws ServiceProcessingException {
		LOG.info("Executing overwriteForOrchestration()");
		// Setting Party
		// replace the rowid object with orig rowidobject for legacy PUT call
		legacyPartyData.setROWIDOBJECT(insertedPartyData.getROWIDOBJECT());
		if (!Util.isNullOrEmpty(insertedPartyData.getUCN())) {
			legacyPartyData.setUCN(insertedPartyData.getUCN());
		}
		legacyPartyData.setPARTYNAME(insertedPartyData.getPARTYNAME());
		legacyPartyData.setUPDATEBY(insertedPartyData.getSRCUPDTBY());
		/*if (insertedPartyDataXref.getAccount().get(0).getMDMLEGACYID()
				.equalsIgnoreCase(legacyPartyData.getAccount().get(0).getMDMLEGACYID())) {
			LOG.info("Minigolden copy for party");
			legacyPartyData.setSTATUSCD(insertedPartyDataXref.getSTATUSCD());
			legacyPartyData.setPARTYTYPE(insertedPartyDataXref.getPARTYTYPE());
			if ((legacyPartyData.getXREF().get(0).getSRCSYSTEM().trim().equalsIgnoreCase("SBL"))
					|| (legacyPartyData.getXREF().get(0).getSRCSYSTEM().trim().equalsIgnoreCase("SAP"))
							|| (legacyPartyData.getXREF().get(0).getSRCSYSTEM().trim().equalsIgnoreCase("FNO"))) {
				legacyPartyData.setLEGACYUCN(insertedPartyDataXref.getLEGACYUCN());
			}
		}*/
		if (legacyPartyData.getXREF().get(0).getSRCSYSTEM().trim().equalsIgnoreCase("SFC")) {
			legacyPartyData.setPHYSICALGEO(insertedPartyData.getPHYSICALGEO());
			legacyPartyData.setPHYSICALREGION(insertedPartyData.getPHYSICALREGION());
		}
		if ((legacyPartyData.getXREF().get(0).getSRCSYSTEM().trim().equalsIgnoreCase("SBL"))
				|| (legacyPartyData.getXREF().get(0).getSRCSYSTEM().trim().equalsIgnoreCase("SAP"))
						|| (legacyPartyData.getXREF().get(0).getSRCSYSTEM().trim().equalsIgnoreCase("FNO"))) {
			if(!Util.isNullOrEmpty(insertedPartyData.getENGLISHNAME())){
				legacyPartyData.setENGLISHNAME(insertedPartyData.getENGLISHNAME());
			}
			legacyPartyData.setGEO(insertedPartyData.getGEO());
			legacyPartyData.setREGION(insertedPartyData.getREGION());
			legacyPartyData.setVATREGNBR(insertedPartyData.getVATREGNBR());
			legacyPartyData.setTAXJURSDCTNCD(insertedPartyData.getTAXJURSDCTNCD());
		}
		// Setting Account
		if (insertedPartyData.getAccount() != null && insertedPartyData.getAccount().size() > 0) {
			if (legacyPartyData.getAccount() != null && legacyPartyData.getAccount().size() > 0) {
				for (int index = 0; index < insertedPartyData.getAccount().size(); index++) {
					for (int index1 = 0; index1 < legacyPartyData.getAccount().size(); index1++) {

						// if(!Util.isNullOrEmpty(insertedPartyData.getAccount().get(index).getACCTNAME()))
						// {
						legacyPartyData.getAccount().get(index1)
								.setACCTNAME(insertedPartyData.getAccount().get(index).getACCTNAME());
						// }
						// if(!Util.isNullOrEmpty(insertedPartyData.getAccount().get(index).getALIASNAME()))
						// {
						legacyPartyData.getAccount().get(index1)
								.setALIASNAME(insertedPartyData.getAccount().get(index).getALIASNAME());
						// }
						legacyPartyData.getAccount().get(index1)
								.setCURRENCYCD(insertedPartyData.getAccount().get(index).getCURRENCYCD());
						// SFC specific Attributes update
						if (legacyPartyData.getXREF().get(0).getSRCSYSTEM().trim().equalsIgnoreCase("SFC") 
								|| legacyPartyData.getXREF().get(0).getSRCSYSTEM().trim().equalsIgnoreCase("FNO")) {
							legacyPartyData.getAccount().get(index1)
									.setLOCALNAME(insertedPartyData.getAccount().get(index).getLOCALNAME());
							legacyPartyData.getAccount().get(index1).setPRICEBANDAGGREMENT(
									insertedPartyData.getAccount().get(index).getPRICEBANDAGGREMENT());
							legacyPartyData.getAccount().get(index1)
									.setTAXID(insertedPartyData.getAccount().get(index).getTAXID());
							legacyPartyData.getAccount().get(index1).setDraftAccountFlag(
									insertedPartyData.getAccount().get(index).getDraftAccountFlag());
						}
						// SAP,SBL specific Attributes update
						if ((legacyPartyData.getXREF().get(0).getSRCSYSTEM().trim().equalsIgnoreCase("SBL"))
								|| (legacyPartyData.getXREF().get(0).getSRCSYSTEM().trim().equalsIgnoreCase("SAP"))) {
							legacyPartyData.getAccount().get(index1)
									.setSAPNAME1(insertedPartyData.getAccount().get(index).getSAPNAME1());

							legacyPartyData.getAccount().get(index1)
									.setSAPNAME2(insertedPartyData.getAccount().get(index).getSAPNAME2());

							legacyPartyData.getAccount().get(index1)
									.setSAPNAME3(insertedPartyData.getAccount().get(index).getSAPNAME3());

							legacyPartyData.getAccount().get(index1)
									.setSAPNAME4(insertedPartyData.getAccount().get(index).getSAPNAME4());
							// }
							// if(!Util.isNullOrEmpty(insertedPartyData.getAccount().get(index).getACCOUNTTAXJURSDCTNCD()))
							// {
							legacyPartyData.getAccount().get(index1).setACCOUNTTAXJURSDCTNCD(
									insertedPartyData.getAccount().get(index).getACCOUNTTAXJURSDCTNCD());
							// }
							// if(!Util.isNullOrEmpty(insertedPartyData.getAccount().get(index).getACCOUNTVATREGNBR()))
							// {
							legacyPartyData.getAccount().get(index1).setACCOUNTVATREGNBR(
									insertedPartyData.getAccount().get(index).getACCOUNTVATREGNBR());
							// }
							legacyPartyData.getAccount().get(index1)
									.setTAXTYPE(insertedPartyData.getAccount().get(index).getTAXTYPE());
							legacyPartyData.getAccount().get(index1)
									.setVENDORNBR(insertedPartyData.getAccount().get(index).getVENDORNBR());

						}

					}
				}
			}
		}
		
		//commented since FNO does not have mdm legacy id
/*		// setting mini golden copy for Account if having same MDMLEGACYID
		if (insertedPartyDataXref.getAccount() != null && insertedPartyDataXref.getAccount().size() > 0) {
			if (legacyPartyData.getAccount() != null && legacyPartyData.getAccount().size() > 0) {
				for (int index = 0; index < insertedPartyDataXref.getAccount().size(); index++) {
					for (int index1 = 0; index1 < legacyPartyData.getAccount().size(); index1++) {
						if (insertedPartyDataXref.getAccount().get(index).getMDMLEGACYID()
								.equalsIgnoreCase(legacyPartyData.getAccount().get(index1).getMDMLEGACYID())) {

							LOG.info("Minigolden copy for Account");
							// if(!Util.isNullOrEmpty(insertedPartyDataXref.getAccount().get(index).getCUSTGROUP()))
							// {
							legacyPartyData.getAccount().get(index1)
									.setCUSTGROUP(insertedPartyDataXref.getAccount().get(index).getCUSTGROUP());
							// }
							// if(!Util.isNullOrEmpty(insertedPartyDataXref.getAccount().get(index).getSIEBELROWID()))
							// {
							legacyPartyData.getAccount().get(index1)
									.setSIEBELROWID(insertedPartyDataXref.getAccount().get(index).getSIEBELROWID());
							// }
							// if(!Util.isNullOrEmpty(insertedPartyDataXref.getAccount().get(index).getSAPCUSTNUMBER()))
							// {
							legacyPartyData.getAccount().get(index1)
									.setSAPCUSTNUMBER(insertedPartyDataXref.getAccount().get(index).getSAPCUSTNUMBER());
							// }
							// if(!Util.isNullOrEmpty(insertedPartyDataXref.getAccount().get(index).getACCTSTATUS()))
							// {
							legacyPartyData.getAccount().get(index1)
									.setACCTSTATUS(insertedPartyDataXref.getAccount().get(index).getACCTSTATUS());
							legacyPartyData.getAccount().get(index1)
									.setACCTTYPE(insertedPartyDataXref.getAccount().get(index).getACCTTYPE());
							if ((insertedPartyDataXref.getXREF().get(index).getSRCSYSTEM().trim()
									.equalsIgnoreCase("SBL"))
									|| (insertedPartyDataXref.getXREF().get(index).getSRCSYSTEM().trim()
											.equalsIgnoreCase("SAP"))
											|| (insertedPartyDataXref.getXREF().get(index).getSRCSYSTEM().trim()
													.equalsIgnoreCase("FNO"))) {
								legacyPartyData.getAccount().get(index1)
										.setMDMLEGACYID(insertedPartyDataXref.getAccount().get(index).getMDMLEGACYID());
								// if(!Util.isNullOrEmpty(insertedPartyData.getAccount().get(index).getCHANNELID()))
								// {
								legacyPartyData.getAccount().get(index1)
										.setCHANNELID(insertedPartyDataXref.getAccount().get(index).getCHANNELID());
								// }
								// if(!Util.isNullOrEmpty(insertedPartyData.getAccount().get(index).getCOMPANYCD()))
								// {
								legacyPartyData.getAccount().get(index1)
										.setCOMPANYCD(insertedPartyDataXref.getAccount().get(index).getCOMPANYCD());
								// }

							}
							if ((legacyPartyData.getXREF().get(0).getSRCSYSTEM().trim().equalsIgnoreCase("SBL"))
									|| (legacyPartyData.getXREF().get(0).getSRCSYSTEM().trim()
											.equalsIgnoreCase("SFC"))) {
								legacyPartyData.getAccount().get(index1).setSalesForceID(
										insertedPartyDataXref.getAccount().get(index).getSalesForceID());
							}
						}
					}
				}
			}
		}*/

		// Setting Address
		for (int index = 0; index < insertedPartyData.getAddress().size(); index++) {
			for (int index1 = 0; index1 < legacyPartyData.getAddress().size(); index1++) {
				if (legacyPartyData.getAddress().get(index1).getADDRTYPE()
						.equalsIgnoreCase(insertedPartyData.getAddress().get(index).getADDRTYPE())) {

					if (!Util.isNullOrEmpty(insertedPartyData.getAddress().get(index).getADDRLN1())) {
						legacyPartyData.getAddress().get(index1)
								.setADDRLN1(insertedPartyData.getAddress().get(index).getADDRLN1());
					}
					// if(!Util.isNullOrEmpty(insertedPartyData.getAddress().get(index).getADDRLN2()))
					// {
					legacyPartyData.getAddress().get(index1)
							.setADDRLN2(insertedPartyData.getAddress().get(index).getADDRLN2());
					// }
					// if(!Util.isNullOrEmpty(insertedPartyData.getAddress().get(index).getADDRLN3()))
					// {
					legacyPartyData.getAddress().get(index1)
							.setADDRLN3(insertedPartyData.getAddress().get(index).getADDRLN3());
					// }
					// if(!Util.isNullOrEmpty(insertedPartyData.getAddress().get(index).getADDRLN4()))
					// {
					legacyPartyData.getAddress().get(index1)
							.setADDRLN4(insertedPartyData.getAddress().get(index).getADDRLN4());
					// }
					if (!Util.isNullOrEmpty(insertedPartyData.getAddress().get(index).getCITY())) {
						legacyPartyData.getAddress().get(index1)
								.setCITY(insertedPartyData.getAddress().get(index).getCITY());
					}

					if (!Util.isNullOrEmpty(insertedPartyData.getAddress().get(index).getSTATECD())) {
						legacyPartyData.getAddress().get(index1)
								.setSTATECD(insertedPartyData.getAddress().get(index).getSTATECD());
					}
					// if(!Util.isNullOrEmpty(insertedPartyData.getAddress().get(index).getPOSTALCD()))
					// {
					legacyPartyData.getAddress().get(index1)
							.setPOSTALCD(insertedPartyData.getAddress().get(index).getPOSTALCD());
					// }
					if (!Util.isNullOrEmpty(insertedPartyData.getAddress().get(index).getCOUNTRYCD())) {
						legacyPartyData.getAddress().get(index1)
								.setCOUNTRYCD(insertedPartyData.getAddress().get(index).getCOUNTRYCD());
					}
					/*
					 * //
					 * if(!Util.isNullOrEmpty(insertedPartyData.getAddress().get
					 * (index).getADDRSTATUS())) {
					 * legacyPartyData.getAddress().get(index1).setADDRSTATUS(
					 * insertedPartyData.getAddress().get(index).getADDRSTATUS()
					 * ); // }
					 */

					if ((legacyPartyData.getXREF().get(0).getSRCSYSTEM().trim().equalsIgnoreCase("SBL"))
							|| (legacyPartyData.getXREF().get(0).getSRCSYSTEM().trim().equalsIgnoreCase("SAP"))
							|| (legacyPartyData.getXREF().get(0).getSRCSYSTEM().trim().equalsIgnoreCase("FNO"))) {
						// if(!Util.isNullOrEmpty(insertedPartyData.getAddress().get(index).getLONGITUDE()))
						// {
						legacyPartyData.getAddress().get(index1)
								.setLONGITUDE(insertedPartyData.getAddress().get(index).getLONGITUDE());
						// }
						// if(!Util.isNullOrEmpty(insertedPartyData.getAddress().get(index).getLATITUDE()))
						// {
						legacyPartyData.getAddress().get(index1)
								.setLATITUDE(insertedPartyData.getAddress().get(index).getLATITUDE());
						// }
						if (!Util.isNullOrEmpty(insertedPartyData.getAddress().get(index).getLANGCD())) {
							legacyPartyData.getAddress().get(index1)
									.setLANGCD(insertedPartyData.getAddress().get(index).getLANGCD());
						}
						// if(!Util.isNullOrEmpty(insertedPartyData.getAddress().get(index).getCOUNTY()))
						// {
						legacyPartyData.getAddress().get(index1)
								.setCOUNTY(insertedPartyData.getAddress().get(index).getCOUNTY());
						// }
						// if(!Util.isNullOrEmpty(insertedPartyData.getAddress().get(index).getDISTRICT()))
						// {
						legacyPartyData.getAddress().get(index1)
								.setDISTRICT(insertedPartyData.getAddress().get(index).getDISTRICT());
						// }
					}
				}
			}
		}

		// Setting Communication
		for (int index = 0; index < insertedPartyData.getCommunication().size(); index++) {
			for (int index1 = 0; index1 < legacyPartyData.getCommunication().size(); index1++) {
				if (legacyPartyData.getCommunication().get(index1).getCOMMTYPE()
						.equalsIgnoreCase(insertedPartyData.getCommunication().get(index).getCOMMTYPE())) {

					/*
					 * if(insertedPartyData.getXREF().get(0).getSRCSYSTEM().
					 * equalsIgnoreCase("SAP") &&
					 * insertedPartyData.getCommunication().get(index).
					 * getPRFRDCOMMIND() != null) {
					 * 
					 * legacyPartyData.getCommunication().get(index1).
					 * setCOMMVALUE(insertedPartyData.getCommunication().get(
					 * index).getCOMMVALUE()); } else {
					 */
					// if(!Util.isNullOrEmpty(insertedPartyData.getCommunication().get(index).getCOMMVALUE()))
					// {
					legacyPartyData.getCommunication().get(index1)
							.setCOMMVALUE(insertedPartyData.getCommunication().get(index).getCOMMVALUE());
					// }
					// }
					/*
					 * if(!Util.isNullOrEmpty(insertedPartyData.getCommunication
					 * ().get(index).getCOMMSTATUS())) {
					 * legacyPartyData.getCommunication().get(index1).
					 * setCOMMSTATUS(insertedPartyData.getCommunication().get(
					 * index).getCOMMSTATUS()); }
					 */
					// if(!Util.isNullOrEmpty(insertedPartyData.getCommunication().get(index).getPRFRDCOMMIND()))
					// {
					legacyPartyData.getCommunication().get(index1)
							.setPRFRDCOMMIND(insertedPartyData.getCommunication().get(index).getPRFRDCOMMIND());
					// }
					// if(!Util.isNullOrEmpty(insertedPartyData.getCommunication().get(index).getWEBDOMAIN()))
					// {
					legacyPartyData.getCommunication().get(index1)
							.setWEBDOMAIN(insertedPartyData.getCommunication().get(index).getWEBDOMAIN());
					// }
					/*if ((legacyPartyData.getXREF().get(index1).getSRCSYSTEM().trim().equalsIgnoreCase("SBL"))
							|| (legacyPartyData.getXREF().get(index1).getSRCSYSTEM().trim().equalsIgnoreCase("SAP"))) {*/
						legacyPartyData.getCommunication().get(index1)
								.setCOMMEXTN(insertedPartyData.getCommunication().get(index).getCOMMEXTN());
						legacyPartyData.getCommunication().get(index1)
								.setCOMMMKTGPREF(insertedPartyData.getCommunication().get(index).getCOMMMKTGPREF());
						// }
					//}
				}
			}
		}

		// Setting Classification
		// clear all the existing classification record from legacy party and
		// create only all the 'Segment - Final Value' records from inserted
		// party.
		// CleansePut will be used for legacy classification record update
		LOG.debug("Classification copy for SFDC/SBL/SAP" + isJapan);
		if (isJapan && insertedPartyDataXref.getClassification().size() > 0) {
			// legacyPartyData.getClassification().clear();
			for (ClassificationXrefType classXref : insertedPartyDataXref.getClassification()) {

				if (classXref.getCLASSIFICTNTYPE().equalsIgnoreCase("Segment - Final Value")
						|| classXref.getCLASSIFICTNTYPE().equalsIgnoreCase("Segmentation Process Code")
						|| classXref.getCLASSIFICTNTYPE().equalsIgnoreCase("Segment - System Assigned Value")) {

				}
				LOG.info("Copying 'Segment - Final Value' classification records from updated party to legacy party");
				String existingPkey = classXref.getSRCPKEY();
				/*
				 * StringTokenizer strToken = new StringTokenizer(existingPkey,
				 * ":", false); List<String> tokenList = new
				 * ArrayList<String>(4); while (strToken.hasMoreTokens()) {
				 * tokenList.add(strToken.nextToken()); } LOG.debug(
				 * "Token count = " + tokenList.size()); String classifValue =
				 * tokenList.get(2);
				 */ // raw classification value from source

				ClassificationXrefType classificationXref = new ClassificationXrefType();
				classificationXref.setSRCPKEY(legacyPartyData.getXREF().get(0).getSRCPKEY().trim());
				classificationXref.setSRCSYSTEM(legacyPartyData.getXREF().get(0).getSRCSYSTEM().trim());
				classificationXref.setCLASSIFICTNTYPE(classXref.getCLASSIFICTNTYPE());
				classificationXref.setCLASSIFICTNVALUE(classXref.getCLASSIFICTNVALUE());
				classificationXref.setSTARTDATE(classXref.getSTARTDATE());
				classificationXref.setENDDATE(classXref.getENDDATE());

				legacyPartyData.getClassification().add(classificationXref);
			}
		}

		LOG.debug("Printing Legacy Update Request canonical structure:");
		UpsertPartyRequest legacyPartyRequest = new UpsertPartyRequest();
		legacyPartyRequest.getParty().add(legacyPartyData);
		Util.printObjectTreeInXML(UpsertPartyRequest.class, legacyPartyRequest);
		LOG.info("Executed overwriteForOrchestration()");
	}

	// For SFDC,Copy all SBL Classification records to SFDC upsertParty,for SFDC
	// there is no classification record
	// Copy the BO classification to SFDC classification if SFDC dont have SFV
	// value - Dev acceptance 2 review
	public PartyXrefType accountsegmentationProcess(PartyXrefType legacySFDCData,
			PartyType survivingPartyProfileFromBO) {
		LOG.info("Execute accountsegmentationProcess()");
		/*
		 * ifPartyXrefType legacySFDCData = null; PartyXrefType legacySBLData =
		 * null; PartyXrefType legacyPartyData = null; (legacymultiplePartyData
		 * != null && legacymultiplePartyData.size() > 0) { for (int index = 0;
		 * index < legacymultiplePartyData.size(); index++) { legacyPartyData =
		 * new PartyXrefType(); legacyPartyData =
		 * legacymultiplePartyData.get(index);
		 * 
		 * // Setting if (legacyPartyData != null) { LOG.debug(
		 * "Checking the xref presence Src system: " + index +
		 * legacyPartyData.getXREF().get(0).getSRCSYSTEM() + "PKEY  " +
		 * legacyPartyData.getXREF().get(0).getSRCPKEY());
		 * if(legacyPartyData.getXREF().get(0).getSRCSYSTEM().trim().
		 * equalsIgnoreCase("SBL")){ legacySBLData = new PartyXrefType();
		 * LOG.debug("Coping SBL data"); legacySBLData = legacyPartyData; } else
		 * if(legacyPartyData.getXREF().get(0).getSRCSYSTEM().trim().
		 * equalsIgnoreCase("SFC")){ legacySFDCData = new PartyXrefType();
		 * LOG.debug("Coping SFDC data"); legacySFDCData = legacyPartyData;
		 * }else { //do nothing } if (legacyPartyData.getClassification().size()
		 * > 0) { legacyPartyData.getClassification().clear(); }
		 */
		if (legacySFDCData != null) {
			for (int index1 = 0; index1 < survivingPartyProfileFromBO.getClassification().size(); index1++) {
				// if ("Segment - Final
				// Value".equals(legacySBLData.getClassification().get(index).getCLASSIFICTNTYPE()))
				// {
				if (survivingPartyProfileFromBO.getClassification().get(index1).getCLASSIFICTNTYPE()
						.equalsIgnoreCase("Segment - Final Value")
						|| survivingPartyProfileFromBO.getClassification().get(index1).getCLASSIFICTNTYPE()
								.equalsIgnoreCase("Segmentation Process Code")
						|| survivingPartyProfileFromBO.getClassification().get(index1).getCLASSIFICTNTYPE()
								.equalsIgnoreCase("Segment - System Assigned Value")) {
					LOG.info("Copying 'Segment - Final Value' classification records from SBL party to SFDC party");

					ClassificationXrefType classificationXref = new ClassificationXrefType();
					classificationXref.setSRCPKEY(legacySFDCData.getXREF().get(0).getSRCPKEY().trim());
					classificationXref.setSRCSYSTEM(legacySFDCData.getXREF().get(0).getSRCSYSTEM().trim());
					classificationXref.setROWIDCLASSIFICTN(
							survivingPartyProfileFromBO.getClassification().get(index1).getROWIDCLASSIFICTN());
					classificationXref.setCLASSIFICTNTYPE(
							survivingPartyProfileFromBO.getClassification().get(index1).getCLASSIFICTNTYPE());
					classificationXref.setCLASSIFICTNVALUE(
							survivingPartyProfileFromBO.getClassification().get(index1).getCLASSIFICTNVALUE());
					classificationXref
							.setSTARTDATE(survivingPartyProfileFromBO.getClassification().get(index1).getSTARTDATE());
					classificationXref
							.setENDDATE(survivingPartyProfileFromBO.getClassification().get(index1).getENDDATE());
					legacySFDCData.getClassification().add(classificationXref);
				}
			}
			/*
			 * } } }
			 */
		}
		LOG.info("Executed accountsegmentationProcess()");
		return legacySFDCData;
	}

	private PutResponseDataHolder putParty(PartyXrefType partyParam, SiperianClient siperianClient)
			throws ServiceProcessingException {
		LOG.info("Executing putParty()");
		PutRequest putRequest = new PutRequest();
		PutResponse putResponse = null;
		PutResponseDataHolder responseDataHolder = null;
		Calendar cal = null;
		try {
			RecordKey recordKey = new RecordKey();
			// recordKey.setRowid(partyParam.getROWIDOBJECT());
			recordKey.setSourceKey(partyParam.getXREF().get(0).getSRCPKEY());
			recordKey.setSystemName(partyParam.getXREF().get(0).getSRCSYSTEM());
			putRequest.setRecordKey(recordKey);
			// prepare CleansePutRequest
			Record record = new Record();
			// set mapping name
			// record.setSiperianObjectUid(SiperianObjectType.PACKAGE.makeUid(MDMAttributeNames.PARTY_PKG));
			record.setSiperianObjectUid(SiperianObjectType.BASE_OBJECT.makeUid(MDMAttributeNames.PARTY_BO));
			// set input values
			//record.setField(new Field(MDMAttributeNames.SRC_UPDT_BY, partyParam.getUPDATEBY()));
			record.setField(new Field(MDMAttributeNames.SRC_UPDT_BY, boXrefUser));
			// record.setField(new Field(MDMAttributeNames.SRC_SYSTEM,
			// (partyParam.getXREF().get(itemIndex)).getSRCSYSTEM()));
			// record.setField(new Field(MDMAttributeNames.SRC_SYS_KEY,
			// (partyParam.getXREF().get(itemIndex)).getSRCPKEY()));
			record.setField(new Field(PartyAttributes.BO_CLASS_CODE, partyParam.getBOCLASSCODE()));
			record.setField(new Field(PartyAttributes.PARTY_NAME, partyParam.getPARTYNAME()));
			record.setField(new Field(PartyAttributes.PARTY_TYPE, partyParam.getPARTYTYPE()));
			record.setField(new Field(PartyAttributes.GEO, partyParam.getGEO()));
			record.setField(new Field(PartyAttributes.REGION, partyParam.getREGION()));
			record.setField(new Field(PartyAttributes.SALES_BLOCK_CD, partyParam.getSALESBLOCKCD()));
			record.setField(new Field(PartyAttributes.TAX_JURSDCTN_CD, partyParam.getTAXJURSDCTNCD()));
			record.setField(new Field(PartyAttributes.VAT_REG_NBR, partyParam.getVATREGNBR()));
			// record.setField(new Field(PartyAttributes.SIP_POP, sipPopVal));
			record.setField(new Field(PartyAttributes.PHYSICAL_GEO, partyParam.getPHYSICALGEO()));
			record.setField(new Field(PartyAttributes.PHYSICAL_REGION, partyParam.getPHYSICALREGION()));
			record.setField(new Field(PartyAttributes.STATUS_CD, partyParam.getSTATUSCD()));
			record.setField(new Field(PartyAttributes.UCN, partyParam.getUCN()));
			if(!Util.isNullOrEmpty(partyParam.getENGLISHNAME())){
			record.setField(new Field(PartyAttributes.ENGLISH_NAME, partyParam.getENGLISHNAME()));
			}
			if (partyParam.getSRCCREATEDT() != null && partyParam.getSRCCREATEDT().length() >= 1) {
				cal = CommonUtil.convertStringToCalendar_TZ(partyParam.getSRCCREATEDT());
				//LOG.info("SRC LUD  of updated Party record = " + cal.getTime());
				putRequest.setLastUpdateDate(cal.getTime());
			}
			
			
			putRequest.setRecord(record);
			// execute Put request
			putResponse = (PutResponse) siperianClient.process(putRequest);
			LOG.info("Party Put request processed successfully: " + putResponse.getMessage());
			// extract result
			RecordKey recordKey1 = putResponse.getRecordKey();

			responseDataHolder = new PutResponseDataHolder();
			responseDataHolder.setActionType(putResponse.getActionType());
			responseDataHolder.setActionMessage(putResponse.getMessage());
			responseDataHolder.setRowidObject(recordKey1.getRowid());
			responseDataHolder.setRowidXREF(recordKey1.getRowidXref());
			responseDataHolder.setSourceKey(recordKey1.getSourceKey());
			responseDataHolder.setSystemName(recordKey1.getSystemName());
			LOG.info("ROWID_OBJECT of updated Party record = " + recordKey1.getRowid());

			LOG.debug("Action Type = " + responseDataHolder.getActionType());
			LOG.debug("Action Msg = " + responseDataHolder.getActionMessage());
			LOG.debug("Rowid_xref = " + responseDataHolder.getRowidXREF());
			LOG.debug("Src key = " + responseDataHolder.getSourceKey());
			LOG.debug("System = " + responseDataHolder.getSystemName());

		} catch (SiperianServerException sifExcp) {
			LOG.error("SiperianServerException occured while processing PutRequest for Party: " + sifExcp);
			sifExcp.printStackTrace();
			ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
			customException.setRootExceptionMsg(
					"Put operation failed for Party " + (partyParam.getXREF().get(0)).getSRCPKEY());
			customException.setMessage(
					"SIF exception occured while processing Put request for Party. " + customException.getMessage());
			throw customException;
		} catch (Exception excp) {
			LOG.error("Exception occured while processing PutRequest for Party: " + excp);
			excp.printStackTrace();
			ServiceProcessingException customException = new ServiceProcessingException(excp);
			customException.setMessage(
					"Exception occured while processing Put request for Party. " + customException.getMessage());
			customException.setRootExceptionMsg(
					"Put operation failed for Party " + (partyParam.getXREF().get(0)).getSRCPKEY());
			throw customException;
		}

		LOG.info("Executed PutParty()");
		return responseDataHolder;
	}

	private List<PutResponseDataHolder> putAccount(List<AccountXrefType> accountList, PartyXrefType partyParam,
			SiperianClient siperianClient) throws ServiceProcessingException {
		LOG.info("Executing PutAccount()");
		// String systemUser = "admin";
		int itemIndex = 0;
		PutRequest putRequest = null;
		PutResponse putResponse = null;
		List<PutResponseDataHolder> responseDataHolderList = new ArrayList<PutResponseDataHolder>(accountList.size());
		AccountXrefType accountParam = null;
		Calendar cal = null;
		try {
			for (itemIndex = 0; itemIndex < accountList.size(); itemIndex++) {
				putRequest = new PutRequest();
				accountParam = accountList.get(itemIndex);
				RecordKey recordKey = new RecordKey();
				// recordKey.setRowid(accountParam.getROWIDACCOUNT());
				recordKey.setSourceKey(accountParam.getSRCPKEY());
				recordKey.setSystemName(accountParam.getSRCSYSTEM());
				putRequest.setRecordKey(recordKey);
				// prepare CleansePutRequest
				Record record = new Record();
				// set mapping name
				// record.setSiperianObjectUid(SiperianObjectType.PACKAGE.makeUid(MDMAttributeNames.ACCOUNT_PKG));
				record.setSiperianObjectUid(SiperianObjectType.BASE_OBJECT.makeUid(MDMAttributeNames.ACCOUNT_BO));
				// set input values
				record.setField(new Field(MDMAttributeNames.SRC_UPDT_BY, boXrefUser));
				// record.setField(new Field(MDMAttributeNames.SRC_SYSTEM,
				// (partyParam.getXREF().get(itemIndex)).getSRCSYSTEM()));
				// record.setField(new Field(MDMAttributeNames.SRC_SYS_KEY,
				// (partyParam.getXREF().get(itemIndex)).getSRCPKEY()));
				record.setField(new Field(AccountAttributes.ACCOUNT_GEO, accountParam.getACCOUNTGEO()));
				record.setField(new Field(AccountAttributes.ACCOUNT_REGION, accountParam.getACCOUNTREGION()));
				record.setField(
						new Field(AccountAttributes.ACCOUNT_TAX_JURSDCTN_CD, accountParam.getACCOUNTTAXJURSDCTNCD()));
				record.setField(new Field(AccountAttributes.ACCOUNT_VAT_REG_NBR, accountParam.getACCOUNTVATREGNBR()));
				record.setField(new Field(AccountAttributes.ACCT_NAME, accountParam.getACCTNAME()));
				record.setField(new Field(AccountAttributes.ACCT_STATUS, accountParam.getACCTSTATUS()));
				record.setField(new Field(AccountAttributes.ACCT_TYPE, accountParam.getACCTTYPE()));
				record.setField(new Field(AccountAttributes.ALIAS_NAME, accountParam.getALIASNAME()));
				record.setField(new Field(AccountAttributes.BILL_BLOCK_CD, accountParam.getBILLBLOCKCD()));
				record.setField(new Field(AccountAttributes.CHANNEL_ID, accountParam.getCHANNELID()));
				record.setField(new Field(AccountAttributes.COMPANY_CD, accountParam.getCOMPANYCD()));
				record.setField(new Field(AccountAttributes.CUST_GROUP, accountParam.getCUSTGROUP()));
				record.setField(new Field(AccountAttributes.DIRECT_IND, accountParam.getDIRECTIND()));
				record.setField(new Field(AccountAttributes.DLVRY_BLOCK_CD, accountParam.getDLVRYBLOCKCD()));
				record.setField(new Field(AccountAttributes.MARKET, accountParam.getMARKET()));
				record.setField(new Field(AccountAttributes.NAMED_ACCT_IND, accountParam.getNAMEDACCTIND()));
				record.setField(new Field(AccountAttributes.NON_VAL_ACCT_IND, accountParam.getNONVALACCTIND()));
				record.setField(new Field(AccountAttributes.ORDR_BLOCK_CD, accountParam.getORDRBLOCKCD()));
				record.setField(new Field(AccountAttributes.PARTNER_IND, accountParam.getPARTNERIND()));
				record.setField(new Field(AccountAttributes.PARTNER_TYPE, accountParam.getPARTNERTYPE()));
				record.setField(new Field(AccountAttributes.POST_BLOCK_CD, accountParam.getPOSTBLOCKCD()));
				record.setField(new Field(AccountAttributes.PRICE_GROUP, accountParam.getPRICEGROUP()));
				record.setField(new Field(AccountAttributes.SALE_BLOCK_CD, accountParam.getSALEBLOCKCD()));
				record.setField(new Field(AccountAttributes.TAX_TYPE, accountParam.getTAXTYPE()));
				record.setField(new Field(AccountAttributes.VENDOR_NBR, accountParam.getVENDORNBR()));
				// Do not overwrite SBL_Rowid with null
				if (!Util.isNullOrEmpty(accountParam.getSIEBELROWID())) {
					record.setField(new Field(AccountAttributes.SIEBEL_ROWID, accountParam.getSIEBELROWID()));
				}
				// Do not overwrite SAP_Cust_Nbr with null
				if (!Util.isNullOrEmpty(accountParam.getSAPCUSTNUMBER())) {
					record.setField(new Field(AccountAttributes.SAP_CUST_NUMBER, accountParam.getSAPCUSTNUMBER()));
				}
				// record.setField(new
				// Field(MDMAttributeNames.ACCOUNT.MDM_LEGACY_ID,
				// accountParam.getMDMLEGACYID()));
				// record.setField(new
				// Field(MDMAttributeNames.ACCOUNT.DATA_SRC_SYSTEM, (
				// partyParam.getXREF().get(itemIndex)).getSRCSYSTEM()));
				// record.setField(new
				// Field(MDMAttributeNames.PARTY_SRC_SYS_KEY,
				// partyParam.getXREF().get(itemIndex).getSRCPKEY()));
				record.setField(new Field(AccountAttributes.SAP_NAME_1, accountParam.getSAPNAME1()));
				record.setField(new Field(AccountAttributes.SAP_NAME_2, accountParam.getSAPNAME2()));
				record.setField(new Field(AccountAttributes.SAP_NAME_3, accountParam.getSAPNAME3()));
				record.setField(new Field(AccountAttributes.SAP_NAME_4, accountParam.getSAPNAME4()));
				/** changes for Sales Force Integration -Start */
				record.setField(new Field(AccountAttributes.LOCAL_NAME, accountParam.getLOCALNAME()));
				record.setField(new Field("CURRENCY_CD", accountParam.getCURRENCYCD()));
				record.setField(new Field(AccountAttributes.TAX_ID, accountParam.getTAXID()));
				record.setField(new Field(AccountAttributes.PRICING_BAND_AGRMNT, accountParam.getPRICEBANDAGGREMENT()));
				record.setField(new Field(AccountAttributes.IS_DENIED_FLG, accountParam.getISDENIEDFLG()));
				/** changes for Sales Force Integration -End */
				if (accountParam.getLASTUPDATEDATE() != null && accountParam.getLASTUPDATEDATE().length() >= 1) {
					cal = CommonUtil.convertStringToCalendar_TZ(accountParam.getLASTUPDATEDATE());
					//LOG.info("SRC LUD  of updated Account record test= " + cal.getTime());
					putRequest.setLastUpdateDate(cal.getTime());
				}
				putRequest.setRecord(record);
				// execute Put request
				putResponse = (PutResponse) siperianClient.process(putRequest);
				LOG.info("Account Put request processed successfully: " + putResponse.getMessage());
				// extract result
				RecordKey recordKey1 = putResponse.getRecordKey();

				PutResponseDataHolder responseDataHolder = new PutResponseDataHolder();
				responseDataHolder.setActionType(putResponse.getActionType());
				responseDataHolder.setActionMessage(putResponse.getMessage());
				responseDataHolder.setRowidObject(recordKey1.getRowid());
				responseDataHolder.setRowidXREF(recordKey1.getRowidXref());
				responseDataHolder.setSourceKey(recordKey1.getSourceKey());
				responseDataHolder.setSystemName(recordKey1.getSystemName());
				responseDataHolderList.add(responseDataHolder);
				LOG.info("ROWID_OBJECT of updated Account record = " + recordKey1.getRowid());
			}
		} catch (SiperianServerException sifExcp) {
			LOG.error("SiperianServerException occured while processing PutRequest for Account: " + sifExcp);
			LOG.error("Root Cause: " + sifExcp.getCause().getMessage());
			sifExcp.printStackTrace();
			ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
			customException.setMessage(
					"SIF exception occured while processing Put request for Account. " + customException.getMessage());
			customException.setRootExceptionMsg(
					"Put operation failed for Account " + (partyParam.getXREF().get(0)).getSRCPKEY());
			throw customException;
		} catch (Exception excp) {
			LOG.error("Exception occured while processing CleansePutRequest for Party: " + excp);
			excp.printStackTrace();
			ServiceProcessingException customException = new ServiceProcessingException(excp);
			customException.setMessage(
					"Exception occured while processing Put request for Account. " + customException.getMessage());
			customException.setRootExceptionMsg(
					"Put operation failed for Account " + (partyParam.getXREF().get(0)).getSRCPKEY());
			throw customException;
		}

		LOG.info("Executed PutAccount()");
		return responseDataHolderList;
	}

	/**
	 * The method prepares and executes CleansePutRequest on ADDRESS landing
	 * table for the given Address profiles.
	 *
	 * @param addressList
	 *            List of Addresses provided to the web service request
	 * @param partyParam
	 *            Party profile provided to the web service request
	 * @param siperianClient
	 *            SiperianClient SIF connection to MDM Hub
	 * @return List of PutResponseDataHolder object containing processing
	 *         results
	 * @throws ServiceProcessingException
	 */
	private List<PutResponseDataHolder> putAddress(List<AddressXrefType> addressList, PartyXrefType partyParam,
			SiperianClient siperianClient) throws ServiceProcessingException {
		LOG.info("Executing PutAddress()");
		// String systemUser = "admin";
		int itemIndex = 0;
		PutRequest putRequest = null;
		PutResponse putResponse = null;
		List<PutResponseDataHolder> responseDataHolderList = new ArrayList<PutResponseDataHolder>(addressList.size());
		AddressXrefType addressParam = null;
		Calendar cal = null;
		try {
			for (itemIndex = 0; itemIndex < addressList.size(); itemIndex++) {
				putRequest = new PutRequest();
				addressParam = addressList.get(itemIndex);
				RecordKey recordKey = new RecordKey();
				// recordKey.setRowid(addressParam.getROWIDADDRESS());
				recordKey.setSourceKey(addressParam.getSRCPKEY());
				recordKey.setSystemName(addressParam.getSRCSYSTEM());
				putRequest.setRecordKey(recordKey);
				// prepare CleansePutRequest
				Record record = new Record();
				// set mapping name
				// record.setSiperianObjectUid(SiperianObjectType.PACKAGE.makeUid(MDMAttributeNames.ADDRESS_PKG));
				record.setSiperianObjectUid(SiperianObjectType.BASE_OBJECT.makeUid(MDMAttributeNames.ADDRESS_BO));
				// set input values
				record.setField(new Field(MDMAttributeNames.SRC_UPDT_BY, boXrefUser));
				// record.setField(new Field(MDMAttributeNames.SRC_SYSTEM,
				// addressParam.getSRCSYSTEM()));
				// record.setField(new Field(MDMAttributeNames.SRC_SYS_KEY,
				// addressParam.getSRCPKEY()));
				record.setField(new Field(AddressAttributes.ADDR_LN1, addressParam.getADDRLN1()));
				record.setField(new Field(AddressAttributes.ADDR_LN2, addressParam.getADDRLN2()));
				record.setField(new Field(AddressAttributes.ADDR_LN3, addressParam.getADDRLN3()));
				record.setField(new Field(AddressAttributes.ADDR_LN4, addressParam.getADDRLN4()));
				record.setField(new Field(AddressAttributes.ADDR_STATUS, addressParam.getADDRSTATUS()));
				// if (addressParam.getADDRTYPE() != null &
				// addressParam.getADDRTYPE().length() > 0) {
				record.setField(new Field(AddressAttributes.ADDR_TYPE, "Billing"));
				// }
				record.setField(new Field(AddressAttributes.CITY, addressParam.getCITY()));
				record.setField(new Field(AddressAttributes.COUNTRY_CD, addressParam.getCOUNTRYCD()));
				record.setField(new Field(AddressAttributes.COUNTY, addressParam.getCOUNTY()));
				record.setField(new Field(AddressAttributes.DISTRICT, addressParam.getDISTRICT()));
				record.setField(new Field(AddressAttributes.LANG_CD, addressParam.getLANGCD()));
				record.setField(new Field(AddressAttributes.LATITUDE, addressParam.getLATITUDE()));
				record.setField(new Field(AddressAttributes.LONGITUDE, addressParam.getLONGITUDE()));
				record.setField(new Field(AddressAttributes.POSTAL_CD, addressParam.getPOSTALCD()));
				record.setField(new Field(AddressAttributes.STATE_CD, addressParam.getSTATECD()));
				if (partyParam.getSRCCREATEDT() != null && partyParam.getSRCCREATEDT().length() >= 1) {
					cal = CommonUtil.convertStringToCalendar_TZ(partyParam.getSRCCREATEDT());
					//LOG.info("SRC LUD  of updated Address record = " + cal.getTime());
					putRequest.setLastUpdateDate(cal.getTime());
				}
				// record.setField(new
				// Field(MDMAttributeNames.PARTY_SRC_SYS_KEY, ((XREFType)
				// partyParam.getXREF().get(itemIndex)).getSRCPKEY()));

				putRequest.setRecord(record);
				// execute Put request
				putResponse = (PutResponse) siperianClient.process(putRequest);
				LOG.info("Address Put request processed successfully: " + putResponse.getMessage());
				// extract result
				RecordKey recordKey1 = putResponse.getRecordKey();

				PutResponseDataHolder responseDataHolder = new PutResponseDataHolder();
				responseDataHolder.setActionType(putResponse.getActionType());
				responseDataHolder.setActionMessage(putResponse.getMessage());
				responseDataHolder.setRowidObject(recordKey1.getRowid());
				responseDataHolder.setRowidXREF(recordKey1.getRowidXref());
				responseDataHolder.setSourceKey(recordKey1.getSourceKey());
				responseDataHolder.setSystemName(recordKey1.getSystemName());
				responseDataHolderList.add(responseDataHolder);
				LOG.info("ROWID_OBJECT of updated Address record = " + recordKey1.getRowid());
			}
		} catch (SiperianServerException sifExcp) {
			LOG.error("SiperianServerException occured while processing PutRequest for Address: " + sifExcp);
			sifExcp.printStackTrace();
			ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
			customException.setMessage(
					"SIF exception occured while processing Put request for Address. " + customException.getMessage());
			customException.setRootExceptionMsg("Put operation failed for Address " + addressParam.getSRCPKEY());
			throw customException;
		} catch (Exception excp) {
			LOG.error("Exception occured while processing PutRequest for Address: " + excp);
			excp.printStackTrace();
			ServiceProcessingException customException = new ServiceProcessingException(excp);
			customException.setMessage(
					"Exception occured while processing Put request for Address. " + customException.getMessage());
			customException.setRootExceptionMsg("Put operation failed for Address " + addressParam.getSRCPKEY());
			throw customException;
		}

		LOG.info("Executed PutAddress()");
		return responseDataHolderList;
	}

	/**
	 * The method prepares and executes CleansePutRequest on COMMUNICATION
	 * landing table for the given Communication profiles.
	 *
	 * @param commList
	 *            List of Communications provided to the web service request
	 * @param partyParam
	 *            Party profile provided to the web service request
	 * @param siperianClient
	 *            SiperianClient SIF connection to MDM Hub
	 * @return List of PutResponseDataHolder object containing processing
	 *         results
	 * @throws ServiceProcessingException
	 */
	private List<PutResponseDataHolder> putCommunication(List<CommunicationXrefType> commList, PartyXrefType partyParam,
			SiperianClient siperianClient) throws ServiceProcessingException {

		LOG.info("Executing PutCommunication()");

		int itemIndex = 0;
		PutRequest putRequest = null;
		PutResponse putResponse = null;
		List<PutResponseDataHolder> responseDataHolderList = new ArrayList<PutResponseDataHolder>(commList.size());
		CommunicationXrefType commParam = null;
		Calendar cal = null;
		try {
			for (itemIndex = 0; itemIndex < commList.size(); itemIndex++) {
				putRequest = new PutRequest();
				commParam = commList.get(itemIndex);
				RecordKey recordKey = new RecordKey();
				// recordKey.setRowid(commParam.getROWIDCOMMUNICATION());
				recordKey.setSourceKey(commParam.getSRCPKEY());
				recordKey.setSystemName(commParam.getSRCSYSTEM());
				putRequest.setRecordKey(recordKey);
				// prepare CleansePutRequest
				Record record = new Record();
				// set mapping name

				record.setSiperianObjectUid(SiperianObjectType.BASE_OBJECT.makeUid(MDMAttributeNames.COMM_BO));
				// set input values
				record.setField(new Field(MDMAttributeNames.SRC_UPDT_BY, boXrefUser));

				record.setField(new Field(CommunicationAttributes.COMM_STATUS, commParam.getCOMMSTATUS()));

				record.setField(new Field(CommunicationAttributes.COMM_TYPE, commParam.getCOMMTYPE()));
				record.setField(new Field(CommunicationAttributes.COMM_VALUE, commParam.getCOMMVALUE()));

				record.setField(new Field(CommunicationAttributes.PRFRD_COMM_IND, commParam.getPRFRDCOMMIND()));
				record.setField(new Field(CommunicationAttributes.WEB_DOMAIN, commParam.getWEBDOMAIN()));
				if (partyParam.getSRCCREATEDT() != null && partyParam.getSRCCREATEDT().length() >= 1) {
					cal = CommonUtil.convertStringToCalendar_TZ(partyParam.getSRCCREATEDT());
					//LOG.info("SRC LUD  of updated Comm record = " + cal.getTime());
					putRequest.setLastUpdateDate(cal.getTime());
				}
				// record.setField(new
				// Field(MDMAttributeNames.PARTY_SRC_SYS_KEY, ((XREFType)
				// partyParam.getXREF().get(itemIndex)).getSRCPKEY()));
				LOG.debug("lastUpdateDate for communication in PUT " + lastUpdateDate);

				putRequest.setLastUpdateDate(lastUpdateDate);
				putRequest.setRecord(record);
				// execute Put request
				putResponse = (PutResponse) siperianClient.process(putRequest);
				LOG.info("Communication Put request processed successfully: " + putResponse.getMessage());
				// extract result
				RecordKey recordKey1 = putResponse.getRecordKey();

				PutResponseDataHolder responseDataHolder = new PutResponseDataHolder();
				responseDataHolder.setActionType(putResponse.getActionType());
				responseDataHolder.setActionMessage(putResponse.getMessage());
				responseDataHolder.setRowidObject(recordKey1.getRowid());
				responseDataHolder.setRowidXREF(recordKey1.getRowidXref());
				responseDataHolder.setSourceKey(recordKey1.getSourceKey());
				responseDataHolder.setSystemName(recordKey1.getSystemName());
				responseDataHolderList.add(responseDataHolder);
				LOG.info("ROWID_OBJECT of updated Communication record = " + recordKey1.getRowid());
			}
		} catch (SiperianServerException sifExcp) {
			LOG.error("SiperianServerException occured while processing PutRequest for Communication: " + sifExcp);
			sifExcp.printStackTrace();
			ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
			customException.setMessage("SIF exception occured while processing Put request for Communication. "
					+ customException.getMessage());
			customException.setRootExceptionMsg("Put operation failed for Communication " + commParam.getSRCPKEY());
			throw customException;
		} catch (Exception excp) {
			LOG.error("Exception occured while processing PutRequest for Communication: " + excp);
			excp.printStackTrace();
			ServiceProcessingException customException = new ServiceProcessingException(excp);
			customException.setMessage("Exception occured while processing Put request for Communication. "
					+ customException.getMessage());
			customException.setRootExceptionMsg("Put operation failed for Communication " + commParam.getSRCPKEY());
			throw customException;
		}

		LOG.info("Executed PutCommunication()");
		return responseDataHolderList;
	}

	/**
	 * 
	 * @param clftnList
	 * @param siperianClient
	 * @return
	 * @throws ServiceProcessingException
	 */
	private String putClassification(List<ClassificationXrefType> clftnList, PartyXrefType partyParam,
			SiperianClient siperianClient) throws ServiceProcessingException {
		LOG.info("Executing putClassification()");
		// String systemUser = "admin";
		int itemIndex = 0;
		CleansePutRequest putRequest = null;
		CleansePutResponse putResponse = null;
		List<PutResponseDataHolder> responseDataHolderList = new ArrayList<PutResponseDataHolder>(clftnList.size());
		ClassificationXrefType classifictnParam = null;
		Calendar cal = null;
		String clsfnId = null;
		lastUpdateDate = Util.getCurrentTimeZone();

		try {
			for (itemIndex = 0; itemIndex < clftnList.size(); itemIndex++) {
				putRequest = new CleansePutRequest();
				List<String> sfvCodeList = new ArrayList<String>();
				String sfvCode = null;
				String srcSystem = null;
				classifictnParam = clftnList.get(itemIndex);
				/*
				 * String costructedPkey = null; costructedPkey =
				 * classifictnParam.getSRCPKEY() + ":" +
				 * classifictnParam.getCLASSIFICTNTYPE() + ":" +
				 * classifictnParam.getCLASSIFICTNVALUE(); LOG.debug(
				 * "costructedPkey is: " + costructedPkey + "Pkey"
				 * +classifictnParam.getSRCPKEY());
				 */
				Record record = new Record();
				// set mapping name
				record.setSiperianObjectUid(Util.getMappingObjectUid(classifictnParam.getSRCSYSTEM().trim(),
						MDMAttributeNames.ENTITY_CLASSIF));
				// set input values
				/*
				 * if (partyParam.getLASTUPDATEDATE() != null &&
				 * partyParam.getLASTUPDATEDATE().length() > 0) {
				 * record.setField(new Field(MDMAttributeNames.LAST_UPDATE_DATE,
				 * partyParam.getLASTUPDATEDATE())); } else {
				 */
				// for merge surviving record determination need to set sysdate
				// only
				LOG.info("Performing putClassification with sysdate from HUB: " + lastUpdateDate);
				record.setField(new Field(MDMAttributeNames.LAST_UPDATE_DATE, lastUpdateDate));
				// }
				record.setField(new Field(MDMAttributeNames.SRC_UPDT_BY, systemUser));
				record.setField(new Field(MDMAttributeNames.SRC_SYSTEM, classifictnParam.getSRCSYSTEM()));
				record.setField(new Field(MDMAttributeNames.SRC_SYS_KEY, classifictnParam.getSRCPKEY()));
				record.setField(
						new Field(ClassificationAttributes.CLASSIFICTN_TYPE, classifictnParam.getCLASSIFICTNTYPE()));

				LOG.debug("CLASSIFCTN_VALUE Actual is: " + classifictnParam.getCLASSIFICTNVALUE());
				sfvCodeList = getSFVCode(classifictnParam.getCLASSIFICTNVALUE());
				srcSystem = classifictnParam.getSRCSYSTEM().trim();
				if (sfvCodeList != null && sfvCodeList.size() > 0) {
					if (srcSystem.equalsIgnoreCase("SBL")) {
						if (!Util.isNullOrEmpty(sfvCodeList.get(0))) {
							sfvCode = sfvCodeList.get(0);// SIEBEL_CD
						}
					} else if (srcSystem.equalsIgnoreCase("SAP")) {
						if (!Util.isNullOrEmpty(sfvCodeList.get(1))) {
							sfvCode = sfvCodeList.get(1);// SAP_CD
						}
					} else if (srcSystem.equalsIgnoreCase("SFC")) {
						if (!Util.isNullOrEmpty(sfvCodeList.get(2))) {
							sfvCode = sfvCodeList.get(2);// SFDC_CD
						}
					}
				}
				LOG.debug("CLASSIFCTN_VALUE is: " + sfvCode);
				if (!Util.isNullOrEmpty(sfvCode)) {
					record.setField(new Field(ClassificationAttributes.CLASSIFICTN_VALUE, sfvCode));
				}
				if (classifictnParam.getSTARTDATE() != null && classifictnParam.getSTARTDATE().length() >= 1) {
					cal = convertStringToCalendar(classifictnParam.getSTARTDATE());
					record.setField(new Field(ClassificationAttributes.START_DATE, cal.getTime()));
				}
				if (classifictnParam.getENDDATE() != null && classifictnParam.getENDDATE().length() >= 1) {
					cal = convertStringToCalendar(classifictnParam.getENDDATE());
					record.setField(new Field(ClassificationAttributes.END_DATE, cal.getTime()));
				}
				record.setField(
						new Field(MDMAttributeNames.PARTY_SRC_SYS_KEY, partyParam.getXREF().get(0).getSRCPKEY()));
				putRequest.setRecord(record);
				// execute Put request
				putResponse = (CleansePutResponse) siperianClient.process(putRequest);
				LOG.info("Classification Put request processed successfully: " + putResponse.getMessage());
				// extract result
				RecordKey recordKey1 = putResponse.getRecordKey();
				clsfnId = recordKey1.getRowid();
				PutResponseDataHolder responseDataHolder = new PutResponseDataHolder();
				responseDataHolder.setActionType(putResponse.getActionType());
				responseDataHolder.setActionMessage(putResponse.getMessage());
				responseDataHolder.setRowidObject(recordKey1.getRowid());
				responseDataHolder.setRowidXREF(recordKey1.getRowidXref());
				responseDataHolder.setSourceKey(recordKey1.getSourceKey());
				responseDataHolder.setSystemName(recordKey1.getSystemName());
				responseDataHolderList.add(responseDataHolder);
				LOG.info("ROWID_OBJECT of updated Classification record = " + recordKey1.getRowid());
			}
		} catch (SiperianServerException sifExcp) {
			LOG.error("SiperianServerException occured while processing PutRequest for Classification: " + sifExcp);
			sifExcp.printStackTrace();
			ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
			customException.setMessage("SIF exception occured while processing Put request for Classification. "
					+ customException.getMessage());
			customException
					.setRootExceptionMsg("Put operation failed for Classification " + classifictnParam.getSRCPKEY());
			throw customException;
		} catch (Exception excp) {
			LOG.error("Exception occured while processing PutRequest for Classification: " + excp);
			excp.printStackTrace();
			ServiceProcessingException customException = new ServiceProcessingException(excp);
			customException.setMessage("Exception occured while processing Put request for Classification. "
					+ customException.getMessage());
			customException
					.setRootExceptionMsg("Put operation failed for Classification " + classifictnParam.getSRCPKEY());
			throw customException;
		}

		LOG.info("Executed putClassification()");
		return clsfnId;
	}

	private List<PartyXrefType> getLegacyRefRecords(PartyXrefType insertedPartyData, List<String> sendToSrcList,
			String survivingPartyRowid) throws SQLException, ServiceProcessingException {

		LOG.debug("Inside getLegacyRefRecords().");
		PartyXrefType legacyPartyData = null;
		Connection jdbcConn = null;
		Statement statement = null;
		PreparedStatement pstatement = null;
		ResultSet resultSet = null;
		JDBCConnectionProvider jDBCConnectionProvider = null;
		List<PartyXrefType> partyList = new ArrayList<PartyXrefType>();
		StringBuilder sql = new StringBuilder();
		boolean activeorgExtnExist = false;
		boolean activeclfctnExist = false;
		

		try {
			
			activeclfctnExist = commonUtil.checkActiveClsfnXrefcExistById(survivingPartyRowid);
			activeorgExtnExist = commonUtil.checkActiveOrgExtnXrefExistById(survivingPartyRowid);
			
			sql.append("SELECT * FROM PKG_XREF_FOR_SEARCH WHERE PARTY_ROWID_OBJECT = ");
			sql.append("'" + survivingPartyRowid.trim() + "'");
			
			sql.append(" and STATUS_CD IN ('A', 'I', 'D')");
			sql.append(" and PARTY_ROWID_SYSTEM in (");
			for (String sentTo : sendToSrcList) {
				sql.append("'" + sentTo + "',");
			}
			sql.deleteCharAt(sql.length() - 1).toString();
			sql.append(")");
			if (p2cEligible || (!activeclfctnExist) || (!activeorgExtnExist)){
				sql.append(" AND HUB_STATE_IND = '1'");
			}
			else{
				sql.append(" AND HUB_STATE_IND = '" + 1 + "'" + "AND NVL(ORG_EXTN_HUB_STATE_IND,1) <> '-1' AND NVL(CLASSIFCTN_HUB_STATE_IND,1) <> '-1'");
			}
			sql.append(" AND nvl(trunc(END_DATE),'31-DEC-9999') = '31-DEC-9999'");
			LOG.debug("SQL for getLegacyRefRecords()-->" + sql);
			
			jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
			jdbcConn = jDBCConnectionProvider.getJdbcConnectionFromDS();
			statement = jdbcConn.createStatement();
			resultSet = statement.executeQuery(sql.toString());
			partyList = createXrefCanonicalForm(resultSet);
			// Fetching SAP,SBL,SFDC Xref copies
			// xrefRecMap =
			// searchPartyDAO.createXrefCanonicalFormMultipleParty(resultSet);
		} catch (SQLException exp) {
			exp.getMessage();
		} catch (ServiceProcessingException sexcp) {
			LOG.error("Caught exception in getLegacyRefRecords()" + sexcp);
		} finally {
			// Closing connections
			if (resultSet != null)
				resultSet.close();
			if (pstatement != null)
				pstatement.close();
			if (statement != null)
				statement.close();
			if (jdbcConn != null)
				jdbcConn.close();// jDBCConnectionProvider.closeJdbcConnection(jdbcConn);
		}

		LOG.debug("Executed getLegacyRefRecords().");
		return partyList;
	}

	private List<PartyXrefType> createXrefCanonicalForm(ResultSet resultSet) throws SQLException {
		LOG.info("Executing Local createXrefCanonicalForm()");
		PartyXrefType party = null;
		ArrayList<PartyXrefType> partyList = new ArrayList<PartyXrefType>();
		XREFType xref = null;
		CommunicationXrefType communication = null;
		AccountXrefType accInfo = null;
		AddressXrefType address = null;
		ClassificationXrefType classfction = null;
		PartyOrgExtXrefType partyOrgExt = null;
		PartyRelationshipXrefType partyRelationship = null;

		/** Modified for M4M START */
		PartyAccountRelationshipXrefType partyAccountRelationship = null;
		/** Modified for M4M END */

		ArrayList<XREFType> listXref = null;

		Map<String, SearchedXrefRecordCollection> searchedRecCollMap = new HashMap<String, SearchedXrefRecordCollection>();
		SearchedXrefRecordCollection searchedRecCollObj = null;
		boolean bUniqueRec = false;

		while (resultSet.next()) {
			String partyRowId = resultSet.getString("ORIG_ROWID_OBJECT");

			if (!searchedRecCollMap.containsKey(partyRowId)) {

				LOG.debug("Populate searchedXrefRecCollMap for new ORIG_ROWID_OBJECT " + partyRowId);
				searchedRecCollMap.put(partyRowId, new SearchedXrefRecordCollection());
				bUniqueRec = true;
			}

			searchedRecCollObj = searchedRecCollMap.get(partyRowId);

			if (bUniqueRec) {

				// LOG.debug("============setting Xref Copy");

				party = new PartyXrefType();
				party.setROWIDOBJECT(resultSet.getString("PARTY_ROWID_OBJECT"));
				searchedRecCollObj.setParty_rowid(resultSet.getString("PARTY_ROWID_OBJECT"));
				party.setROWIDOBJECT(resultSet.getString("ORIG_ROWID_OBJECT"));
				searchedRecCollObj.setOrig_rowid(resultSet.getString("ORIG_ROWID_OBJECT"));
				party.setBOCLASSCODE(resultSet.getString("BO_CLASS_CODE"));
				searchedRecCollObj.setBo_class(resultSet.getString("BO_CLASS_CODE"));
				party.setPARTYTYPE(resultSet.getString("PARTY_TYPE"));
				searchedRecCollObj.setParty_type(resultSet.getString("PARTY_TYPE"));
				party.setPARTYNAME(resultSet.getString("PARTY_NAME"));
				searchedRecCollObj.setParty_name(resultSet.getString("PARTY_NAME"));
				party.setGEO(resultSet.getString("PARTY_GEO"));
				searchedRecCollObj.setGeo(resultSet.getString("PARTY_GEO"));
				party.setREGION(resultSet.getString("PARTY_REGION"));
				searchedRecCollObj.setRegion(resultSet.getString("PARTY_REGION"));
				party.setSTATUSCD(resultSet.getString("STATUS_CD"));
				searchedRecCollObj.setStatus_cd(resultSet.getString("STATUS_CD"));
				party.setVATREGNBR(resultSet.getString("PARTY_VAT_REG_NBR"));
				searchedRecCollObj.setVat_regno(resultSet.getString("PARTY_VAT_REG_NBR"));
				party.setTAXJURSDCTNCD(resultSet.getString("PARTY_TAX_JURSDCTN_CD"));
				searchedRecCollObj.setTax_jd_cd(resultSet.getString("PARTY_TAX_JURSDCTN_CD"));
				party.setSALESBLOCKCD(resultSet.getString("SALES_BLOCK_CD"));
				searchedRecCollObj.setSales_cd(resultSet.getString("SALES_BLOCK_CD"));
				party.setUCN(resultSet.getString("UCN"));
				searchedRecCollObj.setUcn(resultSet.getString("UCN"));
				party.setENGLISHNAME(resultSet.getString("ENGLISH_NAME"));
				searchedRecCollObj.setEnglish_name(resultSet.getString("ENGLISH_NAME"));
				 Date updateDate = resultSet.getDate("SRC_LUD");
                 if(updateDate != null) {
                     String formatedStartDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(updateDate);     
                    // LOG.debug("============setting PartyXREFType formatedStartDate " + formatedStartDate);
                     searchedRecCollObj.setSrcLudDate(formatedStartDate);    
                     party.setSRCCREATEDT(formatedStartDate);
                 }

				LOG.debug("============setting PartyXREFType");
				xref = new XREFType();
				xref.setSRCSYSTEM(resultSet.getString("PARTY_ROWID_SYSTEM"));
				xref.setSRCPKEY(resultSet.getString("PARTY_PKEY_SRC_OBJECT"));

				// LOG.debug("===Inserting into XREFType list===");
				listXref = new ArrayList<XREFType>();
				listXref.add(xref);
				party.getXREF().addAll(listXref);

				// }

				if (resultSet.getString("ACCOUNT_ROWID_OBJECT") != null && !searchedRecCollObj.getAccountMap()
						.containsKey(resultSet.getString("ACCOUNT_ROWID_OBJECT"))) {
					LOG.debug("============setting Account info");
					accInfo = new AccountXrefType();
					accInfo.setROWIDACCOUNT(resultSet.getString("ACCOUNT_ROWID_OBJECT"));
					accInfo.setSRCSYSTEM(resultSet.getString("ACCOUNT_ROWID_SYSTEM"));
					accInfo.setSRCPKEY(resultSet.getString("ACCOUNT_PKEY_SRC_OBJECT"));
					accInfo.setACCTNAME(resultSet.getString("ACCT_NAME"));
					accInfo.setALIASNAME(resultSet.getString("ALIAS_NAME"));
					accInfo.setACCTSTATUS(resultSet.getString("ACCT_STATUS"));
					accInfo.setACCTTYPE(resultSet.getString("ACCT_TYPE"));
					accInfo.setACCOUNTREGION(resultSet.getString("ACCOUNT_REGION"));
					accInfo.setACCOUNTGEO(resultSet.getString("ACCOUNT_GEO"));
					accInfo.setMARKET(resultSet.getString("MARKET"));
					accInfo.setCUSTGROUP(resultSet.getString("CUST_GROUP"));
					accInfo.setPRICEGROUP(resultSet.getString("PRICE_GROUP"));
					accInfo.setCOMPANYCD(resultSet.getString("COMPANY_CD"));
					accInfo.setACCOUNTVATREGNBR(resultSet.getString("ACCOUNT_VAT_REG_NBR"));
					accInfo.setTAXTYPE(resultSet.getString("TAX_TYPE"));
					accInfo.setACCOUNTTAXJURSDCTNCD(resultSet.getString("ACCOUNT_TAX_JURDSCTN_CD"));
					accInfo.setBILLBLOCKCD(resultSet.getString("BILL_BLOCK_CD"));
					accInfo.setORDRBLOCKCD(resultSet.getString("ORDR_BLOCK_CD"));
					accInfo.setDLVRYBLOCKCD(resultSet.getString("DLVRY_BLOCK_CD"));
					accInfo.setPOSTBLOCKCD(resultSet.getString("POST_BLOCK_CD"));
					accInfo.setSALEBLOCKCD(resultSet.getString("SALE_BLOCK_CD"));
					accInfo.setCHANNELID(resultSet.getString("CHANNEL_ID"));
					accInfo.setPARTNERTYPE(resultSet.getString("PARTNER_TYPE"));
					accInfo.setVENDORNBR(resultSet.getString("VENDOR_NBR"));
					accInfo.setDIRECTIND(resultSet.getString("DIRECT_IND"));
					accInfo.setNAMEDACCTIND(resultSet.getString("NAMED_ACCT_IND"));
					accInfo.setNONVALACCTIND(resultSet.getString("NON_VAL_ACCT_IND"));
					accInfo.setPARTNERIND(resultSet.getString("PARTNER_IND"));
					accInfo.setSIEBELROWID(resultSet.getString("SIEBEL_ROWID"));
					accInfo.setSAPCUSTNUMBER(resultSet.getString("SAP_CUST_NUMBER"));
					//accInfo.setMDMLEGACYID(resultSet.getString("MDM_LEGACY_ID"));
					accInfo.setSAPNAME1(resultSet.getString("SAP_NAME_1"));
					accInfo.setSAPNAME2(resultSet.getString("SAP_NAME_2"));
					accInfo.setSAPNAME3(resultSet.getString("SAP_NAME_3"));
					accInfo.setSAPNAME4(resultSet.getString("SAP_NAME_4"));
					Date accountUpdateDate = resultSet.getDate("ACCOUNT_SRC_LUD");
	                 if(accountUpdateDate != null) {
	                     String formatedStartDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(accountUpdateDate);     
	                    // LOG.debug("============setting AccountXREFType formatedStartDate " + formatedStartDate);
	                     accInfo.setLASTUPDATEDATE(formatedStartDate);
	                 }
					accInfo.setNAMEQUALITYIDENTIFIER(resultSet.getString("NAME_QUALITY_IDENTIFIER"));

					LOG.debug("===Inserting into Account Map===");
					searchedRecCollObj.getAccountMap().put(accInfo.getROWIDACCOUNT(), accInfo);
				}

				if (resultSet.getString("ADDRESS_ROWID_OBJECT") != null && !searchedRecCollObj.getAddressMap()
						.containsKey(resultSet.getString("ADDRESS_ROWID_OBJECT"))) {
					LOG.debug("============setting Address");

					address = new AddressXrefType();
					address.setROWIDADDRESS(resultSet.getString("ADDRESS_ROWID_OBJECT"));
					address.setSRCSYSTEM(resultSet.getString("ADDRESS_ROWID_SYSTEM"));
					address.setSRCPKEY(resultSet.getString("ADDRESS_PKEY_SRC_OBJECT"));
					address.setADDRLN1(resultSet.getString("ADDR_LN1"));
					address.setADDRLN2(resultSet.getString("ADDR_LN2"));
					address.setADDRLN3(resultSet.getString("ADDR_LN3"));
					address.setADDRLN4(resultSet.getString("ADDR_LN4"));
					address.setCITY(resultSet.getString("CITY"));
					address.setCOUNTY(resultSet.getString("COUNTY"));
					address.setDISTRICT(resultSet.getString("DISTRICT"));
					address.setSTATECD(resultSet.getString("STATE_CD"));
					address.setPOSTALCD(resultSet.getString("POSTAL_CD"));
					address.setCOUNTRYCD(resultSet.getString("COUNTRY_CD"));
					address.setLANGCD(resultSet.getString("LANG_CD"));
					address.setLONGITUDE(resultSet.getString("LONGITUDE"));
					address.setLATITUDE(resultSet.getString("LATITUDE"));
					address.setADDRTYPE(resultSet.getString("ADDR_TYPE"));
					address.setADDRSTATUS(resultSet.getString("ADDR_STATUS"));

					address.setADDRESSQUALITYIDENTIFIER(resultSet.getString("ADDRESS_QUALITY_IDENTIFIER"));

					LOG.debug("===Inserting into Address Map===");
					searchedRecCollObj.getAddressMap().put(address.getROWIDADDRESS(), address);
				}

				if (resultSet.getString("COMMUNICATION_ROWID_OBJECT") != null && !searchedRecCollObj.getCommMap()
						.containsKey(resultSet.getString("COMMUNICATION_ROWID_OBJECT"))) {
					communication = new CommunicationXrefType();
					LOG.debug("============adding Communication");

					communication.setROWIDCOMMUNICATION(resultSet.getString("COMMUNICATION_ROWID_OBJECT"));
					communication.setSRCSYSTEM(resultSet.getString("COMMUNICATION_ROWID_SYSTEM"));
					communication.setSRCPKEY(resultSet.getString("COMMUNICATION_PKEY_SRC_OBJECT"));
					communication.setCOMMTYPE(resultSet.getString("COMM_TYPE"));
					communication.setCOMMVALUE(resultSet.getString("COMM_VALUE"));
					communication.setCOMMSTATUS(resultSet.getString("COMM_STATUS"));
					communication.setPRFRDCOMMIND(resultSet.getString("PRFRD_COMM_IND"));
					communication.setWEBDOMAIN(resultSet.getString("WEB_DOMAIN"));

					LOG.debug("===Inserting into Communication Map===");
					searchedRecCollObj.getCommMap().put(communication.getROWIDCOMMUNICATION(), communication);
				}

				if (resultSet.getString("PARTY_ORG_ROWID_OBJECT") != null && !searchedRecCollObj.getPartyOrgMap()
						.containsKey(resultSet.getString("PARTY_ORG_ROWID_OBJECT"))) {
					partyOrgExt = new PartyOrgExtXrefType();
					LOG.debug("============adding PartyOrgExt");

					partyOrgExt.setROWIDORGEXTN(resultSet.getString("PARTY_ORG_ROWID_OBJECT"));
					// partyOrgExt.setSRCSYSTEM(resultSet.getString("PARTY_ORG_ROWID_SYSTEM"));
					// partyOrgExt.setSRCPKEY(resultSet.getString("PARTY_ORG_PKEY_SRC_OBJECT"));
					partyOrgExt.setORGDUNSNBR(resultSet.getString("ORG_DUNS_NBR"));
					partyOrgExt.setTRADENAME(resultSet.getString("TRADE_NAME"));
					partyOrgExt.setTRADENAME2(resultSet.getString("TRADE_NAME_2"));
					partyOrgExt.setSITEEMPLCNT(resultSet.getString("SITE_EMPL_CNT"));
					partyOrgExt.setGLBLEMPLCNT(resultSet.getString("GLBL_EMPL_CNT"));
					partyOrgExt.setVERTICAL(resultSet.getString("VERTICAL"));
					partyOrgExt.setREVENUE(resultSet.getString("REVENUE"));
					partyOrgExt.setLINEOFBUS(resultSet.getString("LINE_OF_BUS"));
					partyOrgExt.setPRIMSIC(resultSet.getString("PRIM_SIC"));
					partyOrgExt.setSECSIC(resultSet.getString("SEC_SIC"));
					partyOrgExt.setSALESVOLUME(resultSet.getString("SALES_VOLUME"));
					partyOrgExt.setSALESAMOUNT(resultSet.getString("SALES_AMOUNT"));
					partyOrgExt.setCURRENCYCD(resultSet.getString("CURRENCY_CD"));
					partyOrgExt.setOUTOFBUSIND(resultSet.getString("OUT_OF_BUS_IND"));
					partyOrgExt.setGLBLULTIND(resultSet.getString("GLBL_ULT_IND"));
					partyOrgExt.setFORTUNEINFO(resultSet.getString("FORTUNE_INFO"));
					partyOrgExt.setHIERARCHYLEVEL(resultSet.getString("HIERARCHY_LEVEL"));
					partyOrgExt.setORGHQPARENTDUNS(resultSet.getString("ORG_HQ_PARENT_DUNS"));
					partyOrgExt.setORGDOMULTDUNS(resultSet.getString("ORG_DOM_ULT_DUNS"));
					partyOrgExt.setORGGLBULTDUNS(resultSet.getString("ORG_GLB_ULT_DUNS"));

					LOG.debug("===Inserting into PartyOrgExtType Map==");
					searchedRecCollObj.getPartyOrgMap().put(partyOrgExt.getROWIDORGEXTN(), partyOrgExt);
				}

				/*
				 * if (resultSet.getString("PARTY_PERSON_ROWID_OBJECT") != null
				 * &&
				 * !searchedRecCollObj.getPartyPersonMap().containsKey(resultSet
				 * .getString("PARTY_PERSON_ROWID_OBJECT"))) {
				 * 
				 * partyPersonExt = new PartyPersonExtXrefType(); LOG.debug(
				 * "============adding PartyPersonExt");
				 * 
				 * partyPersonExt.setROWIDPRSNEXTN(resultSet.getString(
				 * "PARTY_PERSON_ROWID_OBJECT"));
				 * partyPersonExt.setSRCSYSTEM(resultSet.getString(
				 * "PARTY_PERSON_ROWID_SYSTEM"));
				 * partyPersonExt.setSRCPKEY(resultSet.getString(
				 * "PARTY_PERSON_PKEY_SRC_OBJECT"));
				 * partyPersonExt.setPREFIX(resultSet.getString("PREFIX"));
				 * partyPersonExt.setFIRSTNAME(resultSet.getString("FIRST_NAME")
				 * ); partyPersonExt.setMIDDLENAME(resultSet.getString(
				 * "MIDDLE_NAME"));
				 * partyPersonExt.setLASTNAME(resultSet.getString("LAST_NAME"));
				 * partyPersonExt.setSUFFIX(resultSet.getString("SUFFIX"));
				 * partyPersonExt.setPERSONTYPE(resultSet.getString(
				 * "PERSON_TYPE"));
				 * 
				 * LOG.debug("===Inserting into PartyPersonExtType List===");
				 * searchedRecCollObj.getPartyPersonMap().put(partyPersonExt.
				 * getROWIDPRSNEXTN(), partyPersonExt); }
				 */

				if (resultSet.getString("PARTY_CLASS_ROWID_OBJECT") != null && !searchedRecCollObj.getClassMap()
						.containsKey(resultSet.getString("PARTY_CLASS_ROWID_OBJECT"))) {

					classfction = new ClassificationXrefType();
					LOG.debug("============adding Classification");

					classfction.setROWIDCLASSIFICTN(resultSet.getString("PARTY_CLASS_ROWID_OBJECT"));
					classfction.setSRCSYSTEM(resultSet.getString("PARTY_CLASS_ROWID_SYSTEM"));
					classfction.setSRCPKEY(resultSet.getString("PARTY_CLASS_PKEY_SRC_OBJECT"));
					classfction.setCLASSIFICTNTYPE(resultSet.getString("CLASSIFCTN_TYPE"));
					classfction.setCLASSIFICTNVALUE(resultSet.getString("CLASSIFCTN_VALUE"));

					LOG.debug("Fetched START_DATE: " + resultSet.getDate("START_DATE"));
					classfction.setSTARTDATE(resultSet.getDate("START_DATE").toString());

					LOG.debug("Fetched END_DATE: " + resultSet.getDate("END_DATE"));
					classfction.setENDDATE(resultSet.getDate("END_DATE").toString());

					LOG.debug("===Inserting into Classification Map===");
					searchedRecCollObj.getClassMap().put(classfction.getROWIDCLASSIFICTN(), classfction);

				}

				if (resultSet.getString("PARTY_REL_ROWID_OBJECT") != null && !searchedRecCollObj.getPartyRelMap()
						.containsKey(resultSet.getString("PARTY_REL_ROWID_OBJECT"))) {

					partyRelationship = new PartyRelationshipXrefType();

					/** Modified for M4M START */

					partyAccountRelationship = new PartyAccountRelationshipXrefType();

					LOG.debug("============adding PartyRelationship");

					// partyRelationship.setSRCPKEY(resultSet.getString("PARTY_REL_PKEY_SRC_OBJECT"));
					// partyRelationship.setSRCSYSTEM(resultSet.getString("PARTY_REL_ROWID_SYSTEM"));
					partyAccountRelationship.setHIERARCHYTYPE(resultSet.getString("ROWID_HIERARCHY"));
					// partyRelationship.setPARENTROWIDPARTY(resultSet.getString("PARTY_REL_ROWID_PARENT"));
					partyAccountRelationship.setRELTYPE(resultSet.getString("ROWID_REL_TYPE"));

					LOG.debug("===Inserting into Relationship Map===");
					// searchedRecCollObj.getPartyRelMap().put(resultSet.getString("PARTY_REL_ROWID_OBJECT"),
					// partyRelationship);
					searchedRecCollObj.getPartyRelMap().put(resultSet.getString("PARTY_REL_ROWID_OBJECT"),
							partyAccountRelationship);
					/** Modified for M4M END */

				}

				bUniqueRec = false;
				LOG.debug("====Populating Party records");
				if (party != null && searchedRecCollObj != null) {
					party.getAccount().addAll(searchedRecCollObj.getAccountMap().values());
					party.getAddress().addAll(searchedRecCollObj.getAddressMap().values());
					party.getCommunication().addAll(searchedRecCollObj.getCommMap().values());
					party.getPartyOrgExt().addAll(searchedRecCollObj.getPartyOrgMap().values());
					//party.getPartyPersonExt().addAll(searchedRecCollObj.getPartyPersonMap().values());
					party.getClassification().addAll(searchedRecCollObj.getClassMap().values());

					/** Modified for M4M START */
					PartyRelationshipXrefType partyRel = party.getPartyRel();
					if (partyRel == null) {
						partyRel = new PartyRelationshipXrefType();
					}
					partyRel.getPARTYACCOUNTREL().addAll(searchedRecCollObj.getPartyRelMap().values());
					party.setPartyRel(partyRel);
					/** Modified for M4M END */
				}
				partyList.add(party);
			}
		}
		/*
		 * LOG.debug("====Populating Party records"); if (party != null &&
		 * searchedRecCollObj != null) {
		 * party.getAccount().addAll(searchedRecCollObj.getAccountMap().values()
		 * );
		 * party.getAddress().addAll(searchedRecCollObj.getAddressMap().values()
		 * ); party.getCommunication().addAll(searchedRecCollObj.getCommMap().
		 * values());
		 * party.getPartyOrgExt().addAll(searchedRecCollObj.getPartyOrgMap().
		 * values());
		 * party.getPartyPersonExt().addAll(searchedRecCollObj.getPartyPersonMap
		 * ().values());
		 * party.getClassification().addAll(searchedRecCollObj.getClassMap().
		 * values());
		 * 
		 *//** Modified for M4M START */
		/*
		 * PartyRelationshipXrefType partyRel = party.getPartyRel(); if(partyRel
		 * == null) { partyRel = new PartyRelationshipXrefType(); }
		 * partyRel.getPARTYACCOUNTREL().addAll(searchedRecCollObj.
		 * getPartyRelMap().values()); party.setPartyRel(partyRel);
		 *//** Modified for M4M END *//*
										 * } partyList.add(party);
										 */
		LOG.info("Executed Local createXrefCanonicalForm()");
		return partyList;

	}

	// Get Current Existing ADDR PKEYs from MDM DB
	private Map<String, String> getPresentAddrPkeyList(PartyXrefType upsertParty)
			throws ServiceProcessingException, SQLException {

		LOG.debug("Inside getPresentAddrPkeyList()");
		Connection jdbcConn = null;
		Statement statement = null;
		ResultSet resultSet = null;
		JDBCConnectionProvider jDBCConnectionProvider = null;
		StringBuilder sql = new StringBuilder();
		Map<String, String> currentAddrPkeyMap = new HashMap<String, String>();

		sql.append(
				"SELECT ADDR_XREF.PKEY_SRC_OBJECT, ADDR_XREF.ROWID_OBJECT FROM C_B_ADDRESS_XREF ADDR_XREF, C_B_PARTY_XREF PARTY_XREF ");
		sql.append("WHERE ADDR_XREF.S_ROWID_PARTY = PARTY_XREF.PKEY_SRC_OBJECT ");
		sql.append("AND PARTY_XREF.PKEY_SRC_OBJECT = ");
		sql.append("'" + upsertParty.getXREF().get(0).getSRCPKEY() + "'");
		sql.append(" AND PARTY_XREF.ROWID_SYSTEM = ");
		sql.append("'" + upsertParty.getXREF().get(0).getSRCSYSTEM() + "'");
		sql.append(" AND ADDR_XREF.HUB_STATE_IND != -1");

		LOG.debug("SQL for getPresentAddrPkeyList()-->" + sql);

		try {
			jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
			jdbcConn = jDBCConnectionProvider.getJdbcConnectionFromDS();
			statement = jdbcConn.createStatement();
			resultSet = statement.executeQuery(sql.toString());

			while (resultSet.next()) {
				currentAddrPkeyMap.put(resultSet.getString(1), resultSet.getString(2));

			}

		} catch (SQLException e) {
			LOG.info("Caught SQLException in getPresentAddrPkeyList().");
		} finally {
			if (resultSet != null)
				resultSet.close();
			if (statement != null)
				statement.close();
			if (jdbcConn != null)
				jdbcConn.close();// jDBCConnectionProvider.closeJdbcConnection(jdbcConn);
		}

		LOG.debug("Executed getPresentAddrPkeyList()");
		return currentAddrPkeyMap;

	}

	// Get Current Existing COMM PKEYs from MDM DB
	private Map<String, String> getPresentCommPkeyList(PartyXrefType upsertParty)
			throws ServiceProcessingException, SQLException {

		LOG.debug("Inside getPresentCommPkeyList()");
		Connection jdbcConn = null;
		Statement statement = null;
		ResultSet resultSet = null;
		JDBCConnectionProvider jDBCConnectionProvider = null;
		StringBuilder sql = new StringBuilder();
		Map<String, String> currentCommPkeyMap = new HashMap<String, String>();

		sql.append(
				"SELECT COMM_XREF.PKEY_SRC_OBJECT, COMM_XREF.ROWID_OBJECT FROM C_B_PARTY_COMM_XREF COMM_XREF, C_B_PARTY_XREF PARTY_XREF ");
		sql.append("WHERE COMM_XREF.S_ROWID_PARTY = PARTY_XREF.PKEY_SRC_OBJECT ");
		sql.append("AND PARTY_XREF.PKEY_SRC_OBJECT = ");
		sql.append("'" + upsertParty.getXREF().get(0).getSRCPKEY() + "'");
		sql.append(" AND PARTY_XREF.ROWID_SYSTEM = ");
		sql.append("'" + upsertParty.getXREF().get(0).getSRCSYSTEM() + "'");
		sql.append(" AND COMM_XREF.HUB_STATE_IND != -1");

		LOG.debug("SQL for getPresentCommPkeyList()-->" + sql);

		try {
			jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
			jdbcConn = jDBCConnectionProvider.getJdbcConnectionFromDS();
			statement = jdbcConn.createStatement();
			resultSet = statement.executeQuery(sql.toString());

			while (resultSet.next()) {
				currentCommPkeyMap.put(resultSet.getString(1), resultSet.getString(2));

			}

		} catch (SQLException e) {
			LOG.info("Caught SQLException in getPresentCommPkeyList().");
		} finally {
			if (resultSet != null)
				resultSet.close();
			if (statement != null)
				statement.close();
			if (jdbcConn != null)
				jdbcConn.close();// jDBCConnectionProvider.closeJdbcConnection(jdbcConn);
		}

		LOG.debug("Executed getPresentCommPkeyList()");
		return currentCommPkeyMap;

	}

	// Get Current Existing COMM PKEYs from MDM DB
	private Map<String, List> getPresentClassPkeyList(PartyXrefType upsertParty) throws ServiceProcessingException {

		LOG.debug("Inside getPresentClassPkeyList()");
		Connection jdbcConn = null;
		Statement statement = null;
		ResultSet resultSet = null;
		JDBCConnectionProvider jDBCConnectionProvider = null;
		StringBuilder sql = new StringBuilder();
		Map<String, List> currentClassPkeyMap = new HashMap<String, List>();

		sql.append(
				"SELECT CLASS_XREF.PKEY_SRC_OBJECT, CLASS_XREF.ROWID_OBJECT, START_DATE, TO_CHAR(END_DATE, 'dd-MON-YYYY'), CLASSIFCTN_TYPE, CLASSIFCTN_VALUE FROM C_B_PARTY_CLASSIFCTN_XREF CLASS_XREF, C_B_PARTY_XREF PARTY_XREF ");
		sql.append("WHERE CLASS_XREF.S_ROWID_PARTY = PARTY_XREF.PKEY_SRC_OBJECT ");
		sql.append("AND PARTY_XREF.PKEY_SRC_OBJECT = ");
		sql.append("'" + upsertParty.getXREF().get(0).getSRCPKEY() + "'");
		sql.append(" AND PARTY_XREF.ROWID_SYSTEM = ");
		sql.append("'" + upsertParty.getXREF().get(0).getSRCSYSTEM() + "'");
		sql.append(" AND CLASS_XREF.HUB_STATE_IND != -1");

		LOG.debug("SQL for getPresentClassPkeyList()-->" + sql);

		try {
			List valList = null;
			jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
			jdbcConn = jDBCConnectionProvider.getJdbcConnectionFromDS();
			statement = jdbcConn.createStatement();
			resultSet = statement.executeQuery(sql.toString());

			while (resultSet.next()) {
				valList = new ArrayList();
				valList.add(resultSet.getString(2)); // ROWID_OBJECT
				valList.add(resultSet.getString(3)); // START_DATE
				valList.add(resultSet.getString(4)); // END_DATE
				valList.add(resultSet.getString(5)); // CLASSIFCTN_TYPE
				valList.add(resultSet.getString(6)); // CLASSIFCTN_VALUE
				currentClassPkeyMap.put(resultSet.getString(1), valList);
			}

		} catch (SQLException e) {
			LOG.error("Caught SQLException in getPresentClassPkeyList().");
		} finally {
			try {
				if (resultSet != null)
					resultSet.close();
				if (statement != null)
					statement.close();
				if (jdbcConn != null)
					jdbcConn.close();
			} catch (SQLException exp) {
				LOG.error("Caught SQLException in getPresentClassPkeyList()." + exp);
			}

		}

		LOG.debug("Executed getPresentClassPkeyList()");
		return currentClassPkeyMap;

	}

	// Stamping MDM_LEGACY_ID from C_B_ACCOUNT_XREF to C_B_PARTY_XREF
	/*private void stampMdmLegacyId(String pkeySrcObject) throws ServiceProcessingException {

		LOG.debug("Inside stampMdmLegacyId()");
		Connection jdbcConn = null;
		Statement statement = null;
		JDBCConnectionProvider jDBCConnectionProvider = null;
		int rowCnt = 0;

		String sql = "UPDATE C_B_PARTY_XREF SET MDM_LEGACY_ID = (SELECT MDM_LEGACY_ID FROM C_B_ACCOUNT_XREF WHERE S_ROWID_PARTY = '"
				+ pkeySrcObject + "') WHERE PKEY_SRC_OBJECT = '" + pkeySrcObject + "'";

		LOG.debug("SQL in stampMdmLegacyId()--> " + sql);

		try {
			jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
			jdbcConn = jDBCConnectionProvider.getJdbcConnectionFromDS();
			statement = jdbcConn.createStatement();
			rowCnt = statement.executeUpdate(sql);

			//jdbcConn.commit();
			LOG.debug("No Of Records Stamped with MDM_LEGACY_ID : " + rowCnt);
			LOG.debug("MDM_LEGACY_ID value stamped in C_B_PARTY_XREF for partyID: " + pkeySrcObject);

		} catch (SQLException exp) {
			LOG.error("Caught SQLException in stampMdmLegacyId() ", exp);

		} finally {
			try {
				// Closing connections
				// if (resultSet != null) resultSet.close();
				if (statement != null)
					statement.close();
				if (jdbcConn != null)
					jdbcConn.close();
			} catch (SQLException exp) {
				LOG.error("SQLexp caught in stampMdmLegacyId(): ", exp);
			}

		}

		LOG.debug(" Executed stampMdmLegacyId() successfully ");
	}*/
	
	private void stampMdmLegacyId(String pkeySrcObject, String srcSys) throws ServiceProcessingException {

		LOG.debug("Inside stampMdmLegacyId()");

		try {
			String mdmLegacyID = getMdmLegacyId(pkeySrcObject);
			if (!Util.isNullOrEmpty(mdmLegacyID)) {
				LOG.debug("Calling put mdm legacy id in party");

				putmdmlegacyId(pkeySrcObject, srcSys, mdmLegacyID);
			}

		} catch (SQLException exp) {
			LOG.error("Caught Exception in stampMdmLegacyId() ", exp);

		}
		LOG.debug(" Executed stampMdmLegacyId() successfully ");
	}
	
	

	// Updating APPRVD_FOR_MERGE = N in C_B_PARTY for Survivor Record if
	// APPRVD_FOR_MERGE is set
	private void updateApprvdForMerge(String survivingRowidObject) throws ServiceProcessingException {

		LOG.debug("Inside updateApprvdForMerge()");
		Connection jdbcConn = null;
		Statement statement = null;
		JDBCConnectionProvider jDBCConnectionProvider = null;
		int rowCnt = 0;

		String sql = "UPDATE C_B_PARTY SET APPRVD_FOR_MERGE = 'N' WHERE APPRVD_FOR_MERGE = 'Y' AND ROWID_OBJECT = '"
				+ survivingRowidObject + "'";

		LOG.debug("SQL in updateApprvdForMerge()--> " + sql);

		try {
			jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
			jdbcConn = jDBCConnectionProvider.getJdbcConnectionFromDS();
			statement = jdbcConn.createStatement();
			rowCnt = statement.executeUpdate(sql);

			jdbcConn.commit();
			LOG.debug("No of records Updated with APPRVD_FOR_MERGE : " + rowCnt);
			LOG.debug("APPRVD_FOR_MERGE value updated to N in C_B_PARTY for partyID: " + survivingRowidObject);

		} catch (SQLException exp) {
			LOG.error("Caught SQLException in updateApprvdForMerge() ", exp);

		} finally {
			try {
				// Closing connections
				// if (resultSet != null) resultSet.close();
				if (statement != null)
					statement.close();
				if (jdbcConn != null)
					jdbcConn.close();
			} catch (SQLException exp) {
				LOG.error("SQLexp caught in updateApprvdForMerge(): ", exp);
			}

		}

		LOG.debug(" Executed updateApprvdForMerge() successfully ");
	}

	public static Calendar convertStringToCalendar(String inputDate) {
		LOG.debug(" Executing convertStringToCalendar()." + inputDate);
		String dateformat = null;
		if (!Util.isNullOrEmpty(inputDate) && inputDate.length() == 10) {
			dateformat = "yyyy-MM-dd";
		} else if (!Util.isNullOrEmpty(inputDate) && inputDate.length() > 10) {
			dateformat = "yyyy-MM-dd HH:mm:ss";
		}
		DateFormat sdf = new SimpleDateFormat(dateformat);
		// DateFormat sdf = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
		// String convertedDate = null;
		Calendar cal = Calendar.getInstance();
		Date dateObject = null;

		if (!Util.isNullOrEmpty(inputDate)) {
			LOG.debug("InputDate from request: " + inputDate);
			try {
				dateObject = sdf.parse(inputDate);
				cal.setTime(dateObject);
				// convertedDate = sdf.format(dateObject);
				LOG.debug("Converted dateObject: " + cal.getTime());
			} catch (ParseException pexp) {
				LOG.error("Parse Exception in convertStringToCalendar(): ", pexp);
			}
		}
		LOG.debug(" Executed convertStringToCalendar().");
		return cal;
	}

	/** Modified for SFDC START */

	/**
	 * This method will check if SBL update is trying to make update a non-draft
	 * account to draft
	 * 
	 * @param accountList
	 * @param upsertPartyResponse
	 * @return
	 */
	private Boolean isDraftUpdateForNonDraftAccount(List<AccountXrefType> accountList,
			MdmUpsertPartyResponse upsertPartyResponse) {
		LOG.debug("[isDraftUpdateForNonDraftAccount] ENTER");

		Boolean isDraftUpdate = Boolean.FALSE;
		Connection jdbcConn = null;
		PreparedStatement pstatement = null;
		ResultSet resultSet = null;
		JDBCConnectionProvider jDBCConnectionProvider = null;

		// String sql = "SELECT 1 FROM C_B_ACCOUNT_XREF WHERE ROWID_SYSTEM='SBL'
		// AND DRAFT_FLG='N' AND PKEY_SRC_OBJECT = ?";
		String sql = "SELECT 1 FROM C_B_ACCOUNT_XREF WHERE ROWID_SYSTEM='SFC' AND DRAFT_FLG='N' AND PKEY_SRC_OBJECT = ?";

		if (!CollectionUtils.isEmpty(accountList)) {
			try {
				jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
				jdbcConn = jDBCConnectionProvider.getJdbcConnectionFromDS();
				for (AccountXrefType account : accountList) {
					if (Constant.STR_Y.equals(account.getDraftAccountFlag())) {
						pstatement = jdbcConn.prepareStatement(sql);
						pstatement.setString(1, account.getSRCPKEY());
						resultSet = pstatement.executeQuery();
						if (resultSet.next()) {
							isDraftUpdate = Boolean.TRUE;
							upsertPartyResponse.setStatus(
									"SFDC Party " + account.getSRCPKEY() + " is an existing non draft account "
											+ "and can not be updated as a draft account. " + "Update is rejected");
							break;
						}
					}
				}
			} catch (SQLException exp) {
				LOG.error("[isDraftUpdateForNonDraftAccount] Caught SQLexception:", exp);
			} catch (ServiceProcessingException servexp) {

				LOG.error("[isDraftUpdateForNonDraftAccount]Caught ServiceProcessingException::", servexp);
			} finally {
				try {
					// Closing connections
					if (resultSet != null)
						resultSet.close();
					if (pstatement != null)
						pstatement.close();
					if (jdbcConn != null)
						jdbcConn.close();

				} catch (SQLException sqlexp) {
					LOG.error("[isDraftUpdateForNonDraftAccount]SQL excpetion in getSicCodeDesc():", sqlexp);
				}
			}
		}

		LOG.debug("[isDraftUpdateForNonDraftAccount]EXIT::isDraftUpdate::" + isDraftUpdate);

		return isDraftUpdate;
	}

	/** Modified for SFDC END */

	/**
	 * Create and Add field to search match request
	 * 
	 * @param searchMatchRequest
	 * @param fieldName
	 * @param fieldValue
	 */
	private void createSearchField(SearchMatchRequest searchMatchRequest, String fieldName, Object fieldValue) {
		LOG.debug("[createSearchField]ENTER::fieldName::" + fieldName + "::fieldValue::" + fieldValue);
		Field field = null;
		if (!Util.isNullOrEmpty(fieldName)) {
			field = new Field(fieldName);
			field.setValue(fieldValue);
		}
		if (field != null) {
			searchMatchRequest.addMatchColumnField(field);
			LOG.debug("[createSearchField]Added Field::" + field.getName() + "::" + field.getStringValue());
		}
		LOG.debug("[createSearchField]EXIT");
	}

	/**
	 * validate input MSG_TRKN_ID
	 * 
	 * @param curParty
	 * @param upsertResponse
	 */
	private void validateMsgTrackingId(PartyXrefType curParty, MdmUpsertPartyResponse upsertResponse)
			throws ServiceProcessingException {
		LOG.debug("[validateMsgTrackingId] ENTER");
		try {
			if (Util.isNullOrEmpty(curParty.getMSGTRKNID())) {
				String respMsg = "No Message Tracking ID found";// messagesProp.getProperty(Constant.INFO_MSG_TRKN_ID_VALIDATION);
				if (Util.isNullOrEmpty(upsertResponse.getStatus())) {
					upsertResponse.setStatus(respMsg);
				} else {
					upsertResponse.setStatus(upsertResponse.getStatus() + "\n" + respMsg);
				}
				upsertResponse.setErrorCd(Constant.ERROR_ACCOUNT_MSG_TRKN_ID_VALIDATION);
				upsertResponse.setErrorMsg(respMsg);
				commonUtil.updateErrorStatus(curParty, upsertResponse, Constant.ERROR_ACCOUNT_MSG_TRKN_ID_VALIDATION, "0");

				throw new ServiceProcessingException(Constant.ERROR_ACCOUNT_MSG_TRKN_ID_VALIDATION);

			}
		} catch (ServiceProcessingException e) {
			if (Constant.ERROR_ACCOUNT_MSG_TRKN_ID_VALIDATION.equals(e.getMessage())) {
				commonUtil.updateErrorStatus(curParty, upsertResponse, Constant.ERROR_ACCOUNT_MSG_TRKN_ID_VALIDATION, "0");
			}
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception exp) {
			if (Constant.ERROR_ACCOUNT_MSG_TRKN_ID_VALIDATION.equals(exp.getMessage())) {
				commonUtil.updateErrorStatus(curParty, upsertResponse, Constant.ERROR_ACCOUNT_MSG_TRKN_ID_VALIDATION, "0");
			}
			// TODO Auto-generated catch block
			exp.printStackTrace();
		}
		LOG.debug("[validateMsgTrackingId] EXIT");
	}

	/* Execute SearchMatch API on Party & Address BO Table */
	@SuppressWarnings("rawtypes")
	private List selfMatchParty(PartyXrefType partyTypeParam, PartyType existingParty, SiperianClient siperianClient)
			throws ServiceProcessingException {

		LOG.info("Executing selfMatchParty()...");

		String ruleSetNonJPN="";
		String ruleSetJPNCustomer = configProps.getProperty("matchRuleSetCustomerJPN");
		String ruleSetJPNResellerDistributor = configProps.getProperty("matchRuleSetResellerDistributorJPN");
		List searchRecords = new ArrayList();

		try {
			SearchMatchRequest searchMatchRequest = new SearchMatchRequest();
			SearchMatchResponse searchMatchResponse = null;

			searchMatchRequest.setRecordsToReturn(100);
			searchMatchRequest.setSiperianObjectUid("BASE_OBJECT.C_B_PARTY");
			
			String countryCode = partyTypeParam.getAddress().get(0).getCOUNTRYCD();
			if ("Japan".equalsIgnoreCase(countryCode) || "JPN".equalsIgnoreCase(countryCode)|| "JP".equalsIgnoreCase(countryCode)) {
				
				//searchMatchRequest.setMatchRuleSetUid(SiperianObjectType.MATCH_RULE_SET.makeUid(ruleSetJPN));// Kanji_Org_Name_Mod

					if (partyTypeParam.getPARTYTYPE().equalsIgnoreCase(Constant.PARTY_TYPE_CUSTOMER)) {
						searchMatchRequest.setMatchRuleSetUid(SiperianObjectType.MATCH_RULE_SET.makeUid(ruleSetJPNCustomer));
					}
					if(Constant.PARTY_TYPE_RESELLER.equalsIgnoreCase(partyTypeParam.getPARTYTYPE()) 
							|| Constant.PARTY_TYPE_DISTRIBUTOR.equalsIgnoreCase(partyTypeParam.getPARTYTYPE())){
						searchMatchRequest.setMatchRuleSetUid(
								SiperianObjectType.MATCH_RULE_SET.makeUid(ruleSetJPNResellerDistributor));
					}
			
			}  else {
				
				String partyType = partyTypeParam.getPARTYTYPE();
				
				if(Constant.PARTY_TYPE_CUSTOMER.equalsIgnoreCase(partyType)){
					ruleSetNonJPN = configProps.getProperty("matchRuleSetCustomer");
				}
				
				if(Constant.PARTY_TYPE_RESELLER.equalsIgnoreCase(partyType) || Constant.PARTY_TYPE_DISTRIBUTOR.equalsIgnoreCase(partyType)){
					ruleSetNonJPN = configProps.getProperty("matchRuleSetResellerDistributor");
				}
				if(!Util.isNullOrEmpty(ruleSetNonJPN)){
					searchMatchRequest.setMatchRuleSetUid(SiperianObjectType.MATCH_RULE_SET.makeUid(ruleSetNonJPN));
				}
			}

			searchMatchRequest.setMatchType(MatchType.BOTH);

			LOG.info("Match Rule Set: " + searchMatchRequest.getMatchRuleSetUid());
			LOG.info("Match Type :" + searchMatchRequest.getMatchType());

			// setting Ex_Address_Ln1,Ex_Address_Ln2,Ex_City, Ex_State,
			// Ex_Country_Cd,Ex_Entity_Type,Ex_Organization_Name,
			// Ex_Party_Type,Organization_Name
			Field field_name = new Field("Organization_Name");
			if (!Util.isNullOrEmpty(partyTypeParam.getPARTYNAME())) {
				field_name.setStringValue(partyTypeParam.getPARTYNAME());
				LOG.info("Field to search for :" + field_name.getName() + ':' + field_name.getStringValue());
				searchMatchRequest.addMatchColumnField(field_name);
			}
			AddressXrefType addressXref = partyTypeParam.getAddress() == null ? null : partyTypeParam.getAddress().get(0);
			if (null != addressXref) {
				// Setting Address_Part1
				Field field_addr1 = new Field("Address_Part1");
				StringBuilder addrLn1Ln2Concat = new StringBuilder();
				if (!Util.isNullOrEmpty(addressXref.getADDRLN1())) {
					addrLn1Ln2Concat.append(addressXref.getADDRLN1());

				}
				if (!Util.isNullOrEmpty(addressXref.getADDRLN2())) {
					addrLn1Ln2Concat.append(" ");
					addrLn1Ln2Concat.append(addressXref.getADDRLN2());

				} else {
					addrLn1Ln2Concat.append(" ");
				}
				if (addrLn1Ln2Concat != null && addrLn1Ln2Concat.length() > 1) {
					field_addr1.setStringValue(addrLn1Ln2Concat.toString());
					searchMatchRequest.addMatchColumnField(field_addr1);
				}
				LOG.info("Field to search for :" + field_addr1.getName() + ':' + field_addr1.getStringValue());

				if (!Util.isNullOrEmpty(addressXref.getADDRLN1()))
					createSearchField(searchMatchRequest, SearchMatchAttributes.EX_ADDRESS_LN1,
							addressXref.getADDRLN1());
				if (!Util.isNullOrEmpty(addressXref.getADDRLN2()))
					createSearchField(searchMatchRequest, SearchMatchAttributes.EX_ADDRESS_LN2,
							addressXref.getADDRLN2());

				if (addrLn1Ln2Concat != null && addrLn1Ln2Concat.length() > 1) {
					if (!Util.isNullOrEmpty(addressXref.getADDRLN2())) {
						createSearchField(searchMatchRequest, SearchMatchAttributes.EX_ADDR_PART1,
								addrLn1Ln2Concat.toString()/*+Constant.STR_SPACE*/);	
					}else{
						createSearchField(searchMatchRequest, SearchMatchAttributes.EX_ADDR_PART1,
								addrLn1Ln2Concat.toString());
					}
					
				}
				
				if (!Util.isNullOrEmpty(addressXref.getCITY()))
					createSearchField(searchMatchRequest, SearchMatchAttributes.EX_CITY, addressXref.getCITY());
				// converting from name to country code,as DB has cd value
				if ((!Util.isNullOrEmpty(addressXref.getCOUNTRYCD())) && (addressXref.getCOUNTRYCD().length() > 2)) {
					addressXref.setCOUNTRYCD(getFNOCountryCode(addressXref.getCOUNTRYCD()));
					createSearchField(searchMatchRequest, SearchMatchAttributes.EX_COUNTRY_CD,
							addressXref.getCOUNTRYCD());
				} else {
					createSearchField(searchMatchRequest, SearchMatchAttributes.EX_COUNTRY_CD,
							addressXref.getCOUNTRYCD());
				}
				if (!Util.isNullOrEmpty(addressXref.getSTATECD()))
					createSearchField(searchMatchRequest, SearchMatchAttributes.EX_STATE, addressXref.getSTATECD());
				// Setting Address_Part2

				Field addr_part2 = new Field("Address_Part2");
				StringBuilder addrPart2Concat = new StringBuilder();
				if (!Util.isNullOrEmpty(addressXref.getCITY())) {
					addrPart2Concat.append(addressXref.getCITY());
				}
				if (!Util.isNullOrEmpty(addressXref.getSTATECD())) {
					if (addrPart2Concat != null && addrPart2Concat.length() > 1)
						addrPart2Concat.append(" ");
					addrPart2Concat.append(addressXref.getSTATECD());
				}
				if (!Util.isNullOrEmpty(addressXref.getCOUNTRYCD())) {
					if (addrPart2Concat != null && addrPart2Concat.length() > 1)
						addrPart2Concat.append(" ");
					addrPart2Concat.append(addressXref.getCOUNTRYCD());
				}
				if (addrPart2Concat != null && addrPart2Concat.length() > 1) {
					addr_part2.setStringValue(addrPart2Concat.toString());
					LOG.info("Field to search for :" + addr_part2.getName() + ':' + addr_part2.getStringValue());
					searchMatchRequest.addMatchColumnField(addr_part2);
				}

			}
			
			createSearchField(searchMatchRequest, SearchMatchAttributes.EX_ORGANIZATION_NAME,partyTypeParam.getPARTYNAME());
			createSearchField(searchMatchRequest, SearchMatchAttributes.EX_ENTITY_TYPE, Constant.BO_CLASS_CODE_ORG);
			createSearchField(searchMatchRequest, SearchMatchAttributes.EX_PARTY_TYPE,existingParty.getPARTYTYPE());
			
			// Adding SIP_POP
			Field field_SIPPOP = new Field("SIP_POP");
			field_SIPPOP.setStringValue(existingParty.getSIPPOP());
			searchMatchRequest.addMatchColumnField(field_SIPPOP);
			LOG.info("Field to match for :" + field_SIPPOP.getName() + ':' + field_SIPPOP.getStringValue());

			StringBuffer criteria = new StringBuffer();
			boolean firstParam = true;

			if (firstParam) {
				criteria.append(" CONSOLIDATION_IND <> 9 ");
				firstParam = false;
			} else {
				criteria.append(" AND CONSOLIDATION_IND <> 9 ");
			}
			if (firstParam) {
				criteria.append(" STATUS_CD = 'A' ");
				firstParam = false;
			} else {
				criteria.append(" AND STATUS_CD = 'A' ");
			}
			LOG.info("Filter Criteria: " + criteria.toString());

			searchMatchRequest.setFilterCriteria(criteria.toString());

			LOG.info("processing SearchMatchRequest");
			searchMatchResponse = (SearchMatchResponse) siperianClient.process(searchMatchRequest);

			searchRecords = searchMatchResponse.getRecords();
		} catch (SiperianServerException sifExcp) {
			LOG.error("SiperianServerException occured while processing SearchMatchRequest on PARTY BO: ", sifExcp);
			ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
			customException.setMessage("SIF exception occured while processing SearchMatchRequest on PARTY BO: "+ customException.getMessage());
			throw customException;
		} catch (Exception ex) {
			LOG.error("PARTY BO Merge operation failed with exception: ", ex);
			ServiceProcessingException customException = new ServiceProcessingException(ex);
			customException.setMessage("Failed to process SearchMatchRequest on PARTY BO: " + customException.getMessage());
			throw customException;
		}

		LOG.info("Completed selfMatchParty()...");
		return searchRecords;
	}

	@SuppressWarnings("rawtypes")
	private List ucnSearchParty(PartyXrefType partyTypeParam, SiperianClient siperianClient)
			throws ServiceProcessingException {

		LOG.info("Executing ucnSearchParty()...");

		List searchRecords = new ArrayList();
		try {

			// Search query to match UCN and party type to convert patry type
			LOG.info("Executing UCN search Query...");
			SearchQueryRequest request = new SearchQueryRequest();
			request.setRecordsToReturn(5); // Required
			request.setSiperianObjectUid("BASE_OBJECT.C_B_PARTY");
			// Required // Changed for 3220
			/*request.setFilterCriteria("UCN = '" + partyTypeParam.getUCN()
					+ "' and CONSOLIDATION_IND <> 9 and STATUS_CD = 'A' and (PARTY_TYPE in ('Customer','Reseller','Distributor') or PARTY_TYPE is null)");*/
			request.setFilterCriteria("UCN = '" + partyTypeParam.getUCN()
			+ "'  and STATUS_CD = 'A' and (PARTY_TYPE in ('Customer','Reseller','Distributor') or PARTY_TYPE is null)");
			SearchQueryResponse response = (SearchQueryResponse) siperianClient.process(request);
			LOG.info("search sucessful.");
			searchRecords = response.getRecords();

		} catch (SiperianServerException sifExcp) {
			LOG.error("SiperianServerException occured while processing UCNSearchParty on PARTY BO: ", sifExcp);
			// sifExcp.printStackTrace();
			ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
			customException.setMessage("SIF exception occured while processing UCNSearchParty on PARTY BO: "
					+ customException.getMessage());
			throw customException;
		} catch (Exception ex) {
			LOG.error("UCNSearchParty operation failed with exception: ", ex);
			// ex.printStackTrace();
			ServiceProcessingException customException = new ServiceProcessingException(ex);
			customException
					.setMessage("Failed to process UCNSearchParty on PARTY BO: " + customException.getMessage());
			throw customException;
		}

		LOG.info("Completed UCNSearchParty()...");
		return searchRecords;

	}

	private List UCNMatchParty(PartyXrefType partyTypeParam, SiperianClient siperianClient)
			throws ServiceProcessingException {

		LOG.info("Executing matchParty()...");

		String ruleSetName = configProps.getProperty("matchRuleSet");
		String ruleSetJPN = configProps.getProperty("matchRuleSetCustomerJPN");
		List searchRecords = new ArrayList();

		try {
			SearchMatchRequest searchMatchRequest = new SearchMatchRequest();
			SearchMatchResponse searchMatchResponse = null;

			searchMatchRequest.setRecordsToReturn(100);
			searchMatchRequest.setSiperianObjectUid("BASE_OBJECT.C_B_PARTY");

			String countryCode = partyTypeParam.getAddress().get(0).getCOUNTRYCD();
			if ("Japan".equalsIgnoreCase(countryCode) || "JPN".equalsIgnoreCase(countryCode)
					|| "JP".equalsIgnoreCase(countryCode)) {
				searchMatchRequest.setMatchRuleSetUid(SiperianObjectType.MATCH_RULE_SET.makeUid(ruleSetJPN));// Kanji_Org_Name_Mod
			} else {
				searchMatchRequest.setMatchRuleSetUid(
						SiperianObjectType.MATCH_RULE_SET.makeUid("Customer Deduplication Ruleset"));// Org_addr_fuzzy_RealTime
			}

			searchMatchRequest.setMatchType(MatchType.BOTH);

			LOG.info("Match Rule Set: " + searchMatchRequest.getMatchRuleSetUid());
			LOG.info("Match Type :" + searchMatchRequest.getMatchType());

			// setting Ex_Entity_Type,Ex_Organization_Name,
			// Ex_Party_Type,Organization_Name
			Field field_name = new Field("Organization_Name");
			if (!Util.isNullOrEmpty(partyTypeParam.getPARTYNAME())) {
				field_name.setStringValue(partyTypeParam.getPARTYNAME());
				LOG.info("Field to search for :" + field_name.getName() + ':' + field_name.getStringValue());
				searchMatchRequest.addMatchColumnField(field_name);
			}

			// set Ex_UCN
			createSearchField(searchMatchRequest, SearchMatchAttributes.EX_UCN, partyTypeParam.getUCN());
			StringBuffer criteria = new StringBuffer();
			boolean firstParam = true;
			// Append filter for consolidation_ind
			if (firstParam) {
				criteria.append(" CONSOLIDATION_IND <> 9 ");
				firstParam = false;
			} else {
				criteria.append(" AND CONSOLIDATION_IND <> 9 ");
			}
			// Append filter for status cd
			if (firstParam) {
				criteria.append(" STATUS_CD = 'A' ");
				firstParam = false;
			} else {
				criteria.append(" AND STATUS_CD = 'A' ");
			}
			LOG.info("Filter Criteria: " + criteria.toString());

			searchMatchRequest.setFilterCriteria(criteria.toString());

			LOG.info("processing SearchMatchRequest");
			searchMatchResponse = (SearchMatchResponse) siperianClient.process(searchMatchRequest);

			searchRecords = searchMatchResponse.getRecords();
		} catch (SiperianServerException sifExcp) {
			// matchInd = false;
			LOG.error("SiperianServerException occured while processing SearchMatchRequest on PARTY BO: ", sifExcp);
			// sifExcp.printStackTrace();
			ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
			customException.setMessage("SIF exception occured while processing SearchMatchRequest on PARTY BO: "
					+ customException.getMessage());
			throw customException;
		} catch (Exception ex) {
			// matchInd = false;
			LOG.error("PARTY BO Merge operation failed with exception: ", ex);
			// ex.printStackTrace();
			ServiceProcessingException customException = new ServiceProcessingException(ex);
			customException
					.setMessage("Failed to process SearchMatchRequest on PARTY BO: " + customException.getMessage());
			throw customException;
		}

		LOG.info("Completed matchParty()...");
		return searchRecords;
	}

	// Fetch Party Pkeys for party-Rowid
	public List<String> getPartyPkeys(String partyID, String srcSystem) throws ServiceProcessingException {
		LOG.debug("Inside getPartyPkeys");
		Connection jdbcConn = null;
		Statement statement = null;
		ResultSet resultSet = null;
		List<String> pkeyList = new ArrayList<String>();

		StringBuilder sql = new StringBuilder();
		sql.append("select PKEY_SRC_OBJECT from C_B_PARTY_XREF where ROWID_OBJECT = (");
		sql.append("'" + partyID.trim() + "'");
		sql.append(") and ROWID_SYSTEM in ('"+srcSystem+"')");

		LOG.debug("Query for getPartyPkeys: " + sql.toString());

		try {
			JDBCConnectionProvider jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
			jdbcConn = jDBCConnectionProvider.getJdbcConnectionFromDS();
			statement = jdbcConn.createStatement();
			resultSet = statement.executeQuery(sql.toString());

			while (resultSet.next()) {
				pkeyList.add(resultSet.getString(1));
			}
		} catch (SQLException sqlex) {
			LOG.error("Caught sql exception in getPartyPkeys()." + sqlex);
		} finally {
			try { // Closing connections
				if (resultSet != null)
					resultSet.close();
				if (statement != null)
					statement.close();
				if (jdbcConn != null)
					jdbcConn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		LOG.debug("Executed getPartyPkeys");
		return pkeyList;
	}

	private void putProcessStateInd(String Pkey, String processStateInd, String partyId,String srcSystem)
			throws ServiceProcessingException {

		LOG.debug("Inside putProcessStateInd()");
		
		SiperianClient siperianClient = null;
		try {
			siperianClient = (SiperianClient) checkOut();
			PutRequest putRequest = new PutRequest();
			RecordKey reckey = new RecordKey();
			Record rec = new Record();

			if (Pkey != null) {
				Pkey = Pkey.trim();
				reckey.setSourceKey(Pkey);
			} else {
				reckey.setRowid(partyId);
			}
			reckey.setSystemName(srcSystem);
			putRequest.setRecordKey(reckey);
			rec.setSiperianObjectUid(SiperianObjectType.BASE_OBJECT.makeUid(MDMAttributeNames.PARTY_BO));
			rec.setField(new Field(PartyAttributes.PROCESS_STATE_IND, processStateInd));
			putRequest.setRecord(rec);

			LOG.debug("source key===" + putRequest.getRecordKey().getRowid());
			PutResponse response = (PutResponse) siperianClient.process(putRequest);
			LOG.debug("response msg-----" + response.getMessage());
		} catch (Exception exp) {
			LOG.error("Caught Exception in putPROCESSSTATEIND() ", exp);

		} finally {
			checkIn(siperianClient);
		}

		LOG.debug(" Executed putProcessStateInd() successfully ");

	}

	private List<String> checkP2CEligible(String rowidObject) throws ServiceProcessingException {
		LOG.info("Executing checkP2CEligible()");

		Statement statement = null;
		StringBuilder sqlQry = new StringBuilder();
		JDBCConnectionProvider jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
		Connection jdbcConnection = null;
		ResultSet resultSet = null;
		int recordCount = 0;
		List<String> srcPkeyList = new ArrayList<String>();

		try {
			sqlQry.append(Constant.ADOBE_COUNT_FROM_PARTY_XREF);
			sqlQry.append("'" + rowidObject + "'");
			jdbcConnection = jDBCConnectionProvider.getJdbcConnectionFromDS();
			statement = jdbcConnection.createStatement();
			resultSet = statement.executeQuery(sqlQry.toString());
			LOG.info("Query to fetch presence of ADB record: " + sqlQry);

			while (resultSet.next()) {
				srcPkeyList.add(resultSet.getString(1));
				LOG.info("Record  with P2C Eligible = " + resultSet.getString(1));
			}
			// LOG.info("Record with P2C Eligible = " + resultSet.getString(1));
			if (srcPkeyList != null && srcPkeyList.size() > 0) {
				p2cEligible = true;
			}

		} catch (SQLException sqlEx) {
			LOG.error("Exception occurred while checking the presence of ELQ Record: ", sqlEx);
			// sqlEx.printStackTrace();
			ServiceProcessingException customException = new ServiceProcessingException(sqlEx);
			customException.setMessage("Failed to check the presence of of ELQ Record: " + sqlEx.getMessage());
			throw customException;
		} finally {
			try {
				if (resultSet != null)
					resultSet.close();
				if (statement != null)
					statement.close();
				if (jdbcConnection != null)
					jdbcConnection.close();
			} catch (SQLException e) {

				e.printStackTrace();
			}
		}

		LOG.info("Executed checkP2CEligible()");

		return srcPkeyList;
	}

	public boolean checkDnbExist(String rowidObject) throws ServiceProcessingException {
		LOG.info("Executing checkDnbExist()");

		Statement statement = null;
		StringBuilder sqlQry = new StringBuilder();
		JDBCConnectionProvider jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
		;
		Connection jdbcConnection = null;
		ResultSet resultSet = null;
		int recordCount = 0;
		boolean dnBExist = false;

		try {
			sqlQry.append(Constant.QUERY_GET_SYSTEMS_IN_PARTY_BY_ROWID);
			sqlQry.append("'" + rowidObject + "'");
			jdbcConnection = jDBCConnectionProvider.getJdbcConnectionFromDS();
			// statement =
			// jdbcConnection.prepareStatement(Constant.COUNT_FROM_PARTY_XREF);
			statement = jdbcConnection.createStatement();
			resultSet = statement.executeQuery(sqlQry.toString());
			LOG.info("Query to fetch presence of DNB record: " + sqlQry);

			while (resultSet.next()) {
				recordCount = resultSet.getInt(1);

			}
			LOG.info("Record count with DnB  = " + recordCount);
			if (recordCount > 0) {
				dnBExist = true;
			}

		} catch (SQLException sqlEx) {
			LOG.error("Exception occurred while checking the presence of DNB Record: ", sqlEx);
			// sqlEx.printStackTrace();
			ServiceProcessingException customException = new ServiceProcessingException(sqlEx);
			customException.setMessage("Failed to check the presence of of DNB Record: " + sqlEx.getMessage());
			throw customException;
		} finally {
			try {
				if (resultSet != null)
					resultSet.close();
				if (statement != null)
					statement.close();
				if (jdbcConnection != null)
					jdbcConnection.close();
			} catch (SQLException e) {

				e.printStackTrace();
			}
		}

		LOG.info("Executed checkDnbExist()");

		return dnBExist;
	}

	public String checkUnMergeByDS(String rowid, String matchedrowid) throws ServiceProcessingException {
		LOG.debug("[checkUnMerge] Enter");
		String unmergeFlag = null;
		Connection jdbcConn = null;

		if (rowid != null && matchedrowid != null) {
			CallableStatement callStmt = null;
			try {
				JDBCConnectionProvider jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
				jdbcConn = jDBCConnectionProvider.getJdbcConnectionFromDS();
				callStmt = jdbcConn.prepareCall("{call CHECK_IF_USER_IN_DS_ROLE_RT(?,?,?,?)}");
				callStmt.setString(1, rowid);
				callStmt.setString(2, matchedrowid);
				callStmt.registerOutParameter(3, OracleTypes.VARCHAR);
				callStmt.registerOutParameter(4, OracleTypes.VARCHAR);
				LOG.debug("[checkUnMerge] Calling   CHECK_IF_USER_IN_DS_ROLE_RT" + " for ROWID::" + rowid);
				callStmt.execute();
				unmergeFlag = callStmt.getString(4);
				LOG.debug("[checkUnMerge] Calling   CHECK_IF_USER_IN_DS_ROLE_RT" + " for unmergeFlag::" + unmergeFlag);
			} catch (SQLException sqlex) {
				LOG.error("Caught sql exception in checkUnMergeByDS()." + sqlex);
			} finally {
				if (callStmt != null) {
					try {
						callStmt.close();
					} catch (SQLException e) {
					}
				}
			}

		}
		LOG.debug("[checkUnMerge] Exit");
		return unmergeFlag;
	}

	/**
	 * Validating Account name and Account address for null, empty and junk condition.
	 * 
	 * @param upsertParty
	 * @param upsertPartyResponse
	 * @param retry
	 * @param executeNextStep
	 * @param rowidObject
	 * @throws ServiceProcessingException
	 */
	public void checkDataQualityUpsert(PartyXrefType upsertParty, MdmUpsertPartyResponse upsertPartyResponse,
			boolean retry, boolean executeNextStep, String rowidObject) throws ServiceProcessingException {

		LOG.info("Executing checkDataQualityUpsert()");

		//PerformanceLoggerUtil perfLog = new PerformanceLoggerUtil();
		/**
		 * MDM service will reject account that comes with party name of Unknown
		 * START
		 */
		if (!validatorUtil.validateAccountName(upsertParty, upsertPartyResponse)) {
			// Account name is Not Valid
			LOG.debug("FNO Account record does not have Valid PARTY_NAME, hence bypassing FNO Account insertion: ");
			upsertPartyResponse.setErrorMsg("ACCOUNT_NAME is Empty or Null or UNKNOWN OR Junk Value. Request is not processed");
			commonUtil.updateErrorStatus(upsertParty, upsertPartyResponse, Constant.ERROR_ACCOUNT_NAME_UNKWN, "0");
			throw new ServiceProcessingException(upsertPartyResponse.getStatus());
		}
		// check for Account Address for Empty, Null or Unknown
		LOG.debug("[updateFNOAccount] check for Account Address for Null or Unknown");
		if (!validatorUtil.validateAccountAddressNullUnknown(upsertParty, upsertPartyResponse, "Addressline1")) {
			// REPORTED ADDRESS OR CITY HAVE null or unknown
			LOG.debug("FNO Account record have NULL or Unknown addressline1" + upsertParty.getXREF().get(0).getSRCPKEY());
			upsertPartyResponse.setErrorMsg("Address is blank or Unknown or Junk Value");
			//upsertPartyResponse.getUpsertStatus().setCURRENTPROCESSSTEP(configProps.getProperty(upsertPartyResponse.getStatus() + "_RETRY"));
			commonUtil.updateErrorStatus(upsertParty, upsertPartyResponse, Constant.ERROR_ACCOUNT_ADDR_LN1_UNKWN, "0");
			throw new ServiceProcessingException(upsertPartyResponse.getStatus());
		}
		// check for Account Address(City) for Empty, Null or Unknown
		LOG.debug("[updateFNOAccount] check for Account City for Null or Unknown");
		if (!validatorUtil.validateAccountAddressNullUnknown(upsertParty, upsertPartyResponse, "City")) {
			// REPORTED CITY HAVE null or unknown
			LOG.debug("FNO Account record have NULL or Unknown City " + upsertParty.getXREF().get(0).getSRCPKEY());
			upsertPartyResponse.setErrorMsg("City is blank or Unknown or Junk Value");
			//upsertPartyResponse.getUpsertStatus().setCURRENTPROCESSSTEP(configProps.getProperty(upsertPartyResponse.getStatus() + "_RETRY"));
			commonUtil.updateErrorStatus(upsertParty, upsertPartyResponse, Constant.ERROR_ACCOUNT_CITY_UNKWN, "0");
			throw new ServiceProcessingException(upsertPartyResponse.getStatus());
		}
		LOG.debug("[updateFNOAccount] check for Account Address for Junk");
		// check for Account Address for Junk and reject the account request
		if (!validatorUtil.validateAccountAddressJunk(upsertParty, upsertPartyResponse)) {
			LOG.debug("FNO Account record have AddressLn1 or city junk ::Rejecting"
					+ upsertParty.getXREF().get(0).getSRCPKEY());
			upsertPartyResponse.setErrorMsg("Address has Junk Value");
			//upsertPartyResponse.getUpsertStatus().setCURRENTPROCESSSTEP(configProps.getProperty(upsertPartyResponse.getStatus() + "_RETRY"));
			commonUtil.updateErrorStatus(upsertParty, upsertPartyResponse, Constant.ERROR_ACCOUNT_CITY_UNKWN, "0");
			throw new ServiceProcessingException(upsertPartyResponse.getStatus());

		}
		
		// ReSetting PartyType = 'Partner' OR 'Prospective Partner'
		// resetPartyType(upsertParty);
		if (executeNextStep)
			preUpsertMatchProcess(upsertParty, upsertPartyResponse, retry, executeNextStep, rowidObject);

	}

	
	/**
	 * @param upsertParty
	 * @param upsertPartyResponse
	 * @throws ServiceProcessingException
	 */
	@SuppressWarnings("rawtypes")
	public void preUpsertMatchProcess(PartyXrefType upsertParty, MdmUpsertPartyResponse upsertPartyResponse,
			boolean retry, boolean executeNextStep, String rowidObject) throws ServiceProcessingException {

		String rowid_object = null;
		int matchCountOfRetry = Integer.parseInt(configProps.getProperty("NoOfRetries"));
		boolean isMatchRetrySuccess = false;
		List searchRecords = new ArrayList();
		
		String srcSystem = upsertParty.getXREF().get(0).getSRCSYSTEM();
		
		// Check if party exist
		rowid_object = searchDao.getPartyRowidObject(upsertParty.getXREF().get(0).getSRCPKEY(),srcSystem);
		
		// calling match rule for existing party
		if (!Util.isNullOrEmpty(rowid_object)) {
			SiperianClient siperianClient = null;
			PartyType existingPartyData = null;
			existingPartyData = getPartyDAO.getBOParty(rowid_object, false);
			
			if (!Util.isNullOrEmpty(upsertParty.getUCN())) {
				String ucn = checkifUCNExists(rowid_object);
				if (!Util.isNullOrEmpty(ucn) && !(ucn.equals(upsertParty.getUCN()))) {
					upsertParty.setUCN(ucn);
				}
			}
			
			//ODOM-92-Accounts will not be updated if the PARTY_TYPE does not match with any existing PARTY_TYPE
			if(!upsertParty.getPARTYTYPE().equalsIgnoreCase(existingPartyData.getPARTYTYPE())){
				
				LOG.info("Account is not updated since the  PARTY_TYPE is not matched with the existing PARTY_TYPE)");
				upsertPartyResponse.setStatus("Account is not updated since the  PARTY_TYPE is not matched with the existing PARTY_TYPE");
				upsertPartyResponse.setErrorMsg("Account is not updated since the  PARTY_TYPE is not matched with the existing PARTY_TYPE");
				commonUtil.updateErrorStatus(upsertParty, upsertPartyResponse, Constant.ERROR_ACCOUNT_WRONG_ACC_TYP, "0");
				throw new ServiceProcessingException(Constant.ERROR_ACCOUNT_WRONG_ACC_TYP);
			}

			try {
				siperianClient = (SiperianClient) checkOut();
				searchRecords = selfMatchParty(upsertParty, existingPartyData, siperianClient);
				LOG.debug("Party selfSearchMatch is successful !!");

			} catch (SiperianServerException sifExcp) {
				matchInd = false;
				LOG.error("SiperianServerException occured while processing SearchMatchRequest on PARTY_BO: ", sifExcp);
				for (int i = 0; i < matchCountOfRetry; i++) {
					try {
						LOG.debug("Retrying SearchMatchRequest process for " + (i + 1) + "th time");
						searchRecords = selfMatchParty(upsertParty, existingPartyData, siperianClient);
						LOG.debug("SearchMatchRequest on Party is successful on attempt no. " + (i + 1));
						isMatchRetrySuccess = true;
						matchInd = true;
						break;
					} catch (Exception ex) {
						LOG.error("Exception occured in SearchMatchRequest RetryMechanism on attempt no. " + (i + 1));
						LOG.error("SiperianServerException occured in SearchMatchRequest RetryMechanism on PARTY_BO");
					}
				}
				if (!isMatchRetrySuccess) {
					upsertPartyResponse.setErrorMsg("self Match Failed");
					commonUtil.updateErrorStatus(upsertParty, upsertPartyResponse, Constant.ERROR_ACC_EXT_ACC_SLF_MTCH_FAIL, "0");
					throw new ServiceProcessingException(Constant.ERROR_ACC_EXT_ACC_SLF_MTCH_FAIL);
				}
			} catch (Exception ex) {
				matchInd = false;
				LOG.error("Exception occured while processing SearchMatchRequest on PARTY_BO: ", ex);
				for (int i = 0; i < matchCountOfRetry; i++) {
					try {
						LOG.debug("Retrying SearchMatchRequest process for " + (i + 1) + "th time");
						searchRecords = selfMatchParty(upsertParty, existingPartyData, siperianClient);
						LOG.debug("SearchMatchRequest on Party is successful on attempt no. " + (i + 1));
						isMatchRetrySuccess = true;
						matchInd = true;
						break;
					} catch (Exception excp) {
						LOG.error("Exception occured in SearchMatchRequest RetryMechanism on attempt no. " + (i + 1));
						LOG.error("SiperianServerException occured in SearchMatchRequest RetryMechanism on PARTY_BO");
					}
				}
				if (!isMatchRetrySuccess) {
					ServiceProcessingException customException = new ServiceProcessingException(ex);
					customException.setMessage("SiperianServerException occured in SearchMatchRequest RetryMechanism on PARTY_BO: "
									+ customException.getMessage());
					upsertPartyResponse.setErrorMsg("self Match Failed");
					commonUtil.updateErrorStatus(upsertParty, upsertPartyResponse, Constant.ERROR_ACC_EXT_ACC_SLF_MTCH_FAIL, "0");
					throw customException;
				}
			} finally {
				checkIn(siperianClient);
			}
			if (searchRecords != null && searchRecords.size() > 0) {
				boolean selfMatch = false;
				for (Iterator iter = searchRecords.iterator(); iter.hasNext();) {
					Record record = (Record) iter.next();
					String recRowid = record.getField("ROWID_OBJECT").getStringValue().trim();
					if (recRowid.equals(rowid_object.trim())) {
						LOG.debug("Self Matching record found with rowidOb: " + rowid_object);
						selfMatch = true;
					}
				}
				if(!selfMatch){
					// self match fail
					selfMatchFail = true;
					LOG.info("matching records found but self match failed");
					/*putProcessStateInd(upsertParty.getXREF().get(0).getSRCPKEY(), Constant.SEND_FOR_DNB, rowid_object,Constant.SRC_SYSTEM_FNO);
					putProcessStateInd(null, Constant.SEND_FOR_DNB, rowid_object,"Admin");*/
				}

			} else {
				selfMatchFail = true;
				LOG.info("No matching record found by searchMatch");
				/*putProcessStateInd(upsertParty.getXREF().get(0).getSRCPKEY(), Constant.SEND_FOR_DNB, rowid_object,Constant.SRC_SYSTEM_FNO);
				putProcessStateInd(null, Constant.SEND_FOR_DNB, rowid_object,"Admin");*/
			}

		}
		// Ex_UCN match rule call for New party
		else {
			String ucn = upsertParty.getUCN();
			SiperianClient siperianClient = null;
			if (!Util.isNullOrEmpty(ucn)) {

				try {
					siperianClient = (SiperianClient) checkOut();
					searchRecords = ucnSearchParty(upsertParty, siperianClient);
					LOG.debug("for New Party UCNMatchParty is successful !!");

				} catch (SiperianServerException sifExcp) {
					matchInd = false;
					LOG.error("SiperianServerException occured while processing SearchMatchRequest on PARTY_BO: ",
							sifExcp);
					for (int i = 0; i < matchCountOfRetry; i++) {
						try {
							LOG.debug("Retrying SearchMatchRequest process for " + (i + 1) + "th time");
							searchRecords = ucnSearchParty(upsertParty, siperianClient);
							LOG.debug("SearchMatchRequest on Party is successful on attempt no. " + (i + 1));
							isMatchRetrySuccess = true;
							matchInd = true;
							break;
						} catch (Exception ex) {
							LOG.error("Exception occured in SearchMatchRequest RetryMechanism on attempt no. " + (i + 1));
							LOG.error("SiperianServerException occured in SearchMatchRequest RetryMechanism on PARTY_BO");
						}
					}
					if (!isMatchRetrySuccess) {
						upsertPartyResponse.setErrorMsg("UCN Match Failed");
						commonUtil.updateErrorStatus(upsertParty, upsertPartyResponse, Constant.ERROR_ACC_NEW_ACC_UCN_MTCH_FAIL,"0");
						throw new ServiceProcessingException(Constant.ERROR_ACC_NEW_ACC_UCN_MTCH_FAIL);
					}
				} catch (Exception ex) {
					matchInd = false;
					LOG.error("Exception occured while processing SearchMatchRequest on PARTY_BO: ", ex);
					for (int i = 0; i < matchCountOfRetry; i++) {
						try {
							LOG.debug("Retrying SearchMatchRequest process for " + (i + 1) + "th time");
							searchRecords = ucnSearchParty(upsertParty, siperianClient);
							LOG.debug("SearchMatchRequest on Party is successful on attempt no. " + (i + 1));
							isMatchRetrySuccess = true;
							matchInd = true;
							break;
						} catch (Exception excp) {
							LOG.error("Exception occured in SearchMatchRequest RetryMechanism on attempt no. " + (i + 1));
							LOG.error("SiperianServerException occured in SearchMatchRequest RetryMechanism on PARTY_BO");
						}
					}
					if (!isMatchRetrySuccess) {
						ServiceProcessingException customException = new ServiceProcessingException(ex);
						customException.setMessage("SiperianServerException occured in SearchMatchRequest RetryMechanism on PARTY_BO: "
										+ customException.getMessage());
						upsertPartyResponse.setErrorMsg("UCN Match Failed");
						commonUtil.updateErrorStatus(upsertParty, upsertPartyResponse, Constant.ERROR_ACC_NEW_ACC_UCN_MTCH_FAIL,"0");
						throw customException;
					}
				} finally {
					checkIn(siperianClient);
				}
			}
			if (searchRecords != null && searchRecords.size() > 0) {
				for (Iterator iter = searchRecords.iterator(); iter.hasNext();) {
					Record record = (Record) iter.next();
					String recRowid = record.getField("ROWID_OBJECT").getStringValue().trim();
					LOG.debug("UCN based Matching record found with rowidOb: " + recRowid);
					upsertParty.setROWIDOBJECT(recRowid);
					ucnMatch = true;
					// upsertParty.setPROCESSSTATEIND(Constant.SEND_FOR_DNB);
				}

			} else {
				upsertParty.setUCN("");
				LOG.info("No matching record found by searchMatch");
			}

		}
		if (executeNextStep)
			processCleansePutRequest(upsertParty, upsertPartyResponse, retry, executeNextStep, rowidObject);
	}
	

	public void upsertMatchMergeProcess(PartyXrefType upsertParty, MdmUpsertPartyResponse upsertPartyResponse,
			boolean retry, boolean executeNextStep, String rowidObject) throws ServiceProcessingException {

		PerformanceLoggerUtil perfLog = new PerformanceLoggerUtil();
		PutResponseDataHolder putRespDataParty = null;
		try {
			
			// Check match exclusion and process match and merge the party
			matchMergeProcessParty(upsertParty, upsertPartyResponse);
			// Merge child records
			childMultiMergeParty(upsertParty, upsertPartyResponse, putRespDataParty, false);
			if(!Util.isNullOrEmpty(upsertParty.getDONOTMERGE()) && Constant.STR_N.equalsIgnoreCase(upsertParty.getDONOTMERGE())){	
				commonUtil.updateMergeExclusionList(upsertParty.getXREF().get(0).getSRCPKEY(),"DELETE");
			}else if(!Util.isNullOrEmpty(upsertParty.getDONOTMERGE()) && Constant.STR_Y.equalsIgnoreCase(upsertParty.getDONOTMERGE())){
				commonUtil.updateMergeExclusionList(upsertParty.getXREF().get(0).getSRCPKEY(),"INSERT");
				LOG.info("Merge process is skipped because of DO_NOT_MERGR flag is enabled");
			}
			
		} catch (ServiceProcessingException e) {
			commonUtil.updateErrorStatus(upsertParty, upsertPartyResponse, Constant.ERROR_ACC_MERGE_FAIL, rowidObject);
			throw e;
		} catch (Exception exp) {
			commonUtil.updateErrorStatus(upsertParty, upsertPartyResponse, Constant.ERROR_ACC_MERGE_FAIL, rowidObject);
			throw exp;
		}
		perfLog.printLog(Constant.PERF_LOG_FLOW_UPSERT_FNO, upsertParty.getXREF().get(0).getSRCPKEY(), "STEP 14",
				"matchMergeProcessParty Done");
		if (executeNextStep)
			upsertP2CProcess(upsertParty, upsertPartyResponse, retry, executeNextStep, rowidObject);

	}
	
	public void upsertMatchMergeProcessForMdmLegacyId(PartyXrefType upsertParty,
			MdmUpsertPartyResponse upsertPartyResponse, String putRowidObject, String mdmLegacyID)
			throws ServiceProcessingException {
		LOG.info("Executing upsertMatchMergeProcessForMdmLegacyId");
		PerformanceLoggerUtil perfLog = new PerformanceLoggerUtil();
		PutResponseDataHolder putRespDataParty = null;
		Set<Integer> partyIds = new TreeSet<Integer>();
		int olderRowid = 0;

		try {
			LOG.info("putRowidObject" + putRowidObject);
			LOG.info("mdmLegacyID for match" + mdmLegacyID);
			// get the party ids from mdmLegacyID
			if (mdmLegacyID != null)
				partyIds = getpartyIds(putRowidObject, mdmLegacyID);
			LOG.info("mdmLegacyID present for no.of party " + partyIds.size());
			if (partyIds != null && partyIds.size() > 0) {
				olderRowid = Collections.min(partyIds);
			}
			LOG.info("mdmLegacyID for match olderRowid" + olderRowid);
			if (olderRowid != 0) {
				mdmLegacyIdMatch = true;
				mergeProcessPartyForMdmLegacyId(putRowidObject, String.valueOf(olderRowid), upsertParty,
						upsertPartyResponse);
				// Merge child records
				childMultiMergeParty(upsertParty, upsertPartyResponse, putRespDataParty,false);
			}

		} catch (ServiceProcessingException e) {
			commonUtil.updateErrorStatus(upsertParty, upsertPartyResponse, Constant.ERROR_ACC_MERGE_FAIL, putRowidObject);
			throw e;
		} catch (Exception exp) {
			commonUtil.updateErrorStatus(upsertParty, upsertPartyResponse, Constant.ERROR_ACC_MERGE_FAIL, putRowidObject);
			try {
				throw exp;
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		perfLog.printLog(Constant.PERF_LOG_FLOW_UPSERT_SAP_SBL, upsertParty.getXREF().get(0).getSRCPKEY(), "STEP 13",
				"Match Merge MDM LegacyID Done");
		LOG.info("Executed upsertMatchMergeProcessForMdmLegacyId");

	}

	public void matchMergeProcessParty(PartyXrefType upsertParty, MdmUpsertPartyResponse upsertPartyResponse) {
		// fetch inserted party details and use that for match and merge
		PartyXrefType insertedPartyData = new PartyXrefType();
		String rowidObject = null;
		HashMap<Integer, HighestScoreRecordHolder> mergeSorceHolderMap = new HashMap<Integer, HighestScoreRecordHolder>();
		HighestScoreRecordHolder highestScoreRecordHoldertgt = new HighestScoreRecordHolder();
		int matchCountOfRetry = Integer.parseInt(configProps.getProperty("NoOfRetries"));
		boolean exclusionPatternExists = false;
		PerformanceLoggerUtil perfLog = new PerformanceLoggerUtil();
		try {
			insertedPartyData = getPartyDAO.fetchPartyXrefTypeFromORS(upsertParty.getXREF().get(0).getSRCSYSTEM(),
					upsertParty.getXREF().get(0).getSRCPKEY(), false);
			rowidObject = insertedPartyData.getROWIDOBJECT();
			LOG.info("inserted ucn : " + insertedPartyData.getUCN()+":");
			sipPopVal = getPartyDAO.getSipPopFromXref();
			LOG.info("Getting insertedPartyData from GetPartyDAO for PartyID: " + insertedPartyData.getROWIDOBJECT());
			LOG.info("sipPopVal from GetPartyDAO: " + sipPopVal);
			perfLog.printLog(Constant.PERF_LOG_FLOW_UPSERT_FNO, upsertParty.getXREF().get(0).getSRCPKEY(),
					"STEP 12", "Create canonical format Done");
			try {
				 //Changes for MDMP-3371 
				//if(!ucnMatch && !mdmLegacyIdMatch){
				if(!ucnMatch ){
				exclusionPatternExists = isMatchExclusionPatternExists(rowidObject);
				}
				if (exclusionPatternExists) {
					LOG.info(
							"Match exclusion pattern exists for the party, bypassing match & merge process and creating task for DS");

					String title = "Match Exclusion";
					String comment = "Match Exclusion pattern is present for the PartyID: " + rowidObject;
					processCreateTaskRequest(null, rowidObject, "FinalReview", title, comment);

				} else {
					mergeProcessParty(mergeSorceHolderMap, upsertPartyResponse, highestScoreRecordHoldertgt,
							insertedPartyData, rowidObject);
					LOG.debug("Merge is successful on PARTY & ACCOUNT entities !!");
				}
			} catch (ServiceProcessingException servExcp) {

				LOG.error("Caught ServiceProcessingException in mergeProcessParty: ", servExcp);
				LOG.error("Root Exception Message: " + servExcp.getRootExceptionMsg());
				LOG.error("Localized Message: " + servExcp.getCause().getLocalizedMessage());
				LOG.error(" Message: " + servExcp.getCause().getMessage());
				throw servExcp;

			} catch (Exception Excp) {
				LOG.error("Caught exception in mergeProcessParty: ", Excp);
				warning.append("Merge Process failed. \n");

				// Checking whether Match and Merge Operation Done or not
				if (matchInd) {
					upsertPartyResponse
							.setStatus(upsertPartyResponse.getStatus() + " Matching record found for Party.");
					matchInd = false;
				} else {
					upsertPartyResponse
							.setStatus(upsertPartyResponse.getStatus() + " No matching record found for Party.");
				}
				if (mergeInd) {
					upsertPartyResponse.setStatus(
							upsertPartyResponse.getStatus() + " Merge operation successful for Party and Account "
									+ upsertParty.getXREF().get(0).getSRCPKEY() + ". Surviving rowid_object = "
									+ upsertPartyResponse.getParty().get(0).getROWIDOBJECT());
				} else {
					upsertPartyResponse.setStatus(upsertPartyResponse.getStatus() + " Merge not done for Party "
							+ upsertParty.getXREF().get(0).getSRCPKEY());
				}
				throw Excp;

			}
		} catch (Exception exp) {
			LOG.error("Caught ServiceProcessingException in mergeProcessParty: ", exp);
			LOG.error("Root Exception Message: " + exp.getMessage());
			commonUtil.updateErrorStatus(upsertParty, upsertPartyResponse, Constant.ERROR_ACC_MERGE_FAIL, rowidObject);
		}
		return;
	}

	/**
	 * Validating CUST_GRP, BO_CLASS_CODE and PARTY_TYPE
	 * 
	 * @param upsertParty
	 * @param upsertPartyResponse
	 * @param excuteNextStep
	 * @param executeFromStart
	 * @param rowidObject
	 * @throws ServiceProcessingException
	 */
	public void upsertDataValidation(PartyXrefType upsertParty, MdmUpsertPartyResponse upsertPartyResponse,
			boolean excuteNextStep, boolean executeFromStart, String rowidObject) throws ServiceProcessingException {

		LOG.info("Executing upsertDataValidation()");
		// Check for Account Record Type
		try {
			// Check if BO_CLASS_CODE == 'Organization'
			if (((!Util.isNullOrEmpty(upsertParty.getBOCLASSCODE()))
					&& upsertParty.getBOCLASSCODE().equalsIgnoreCase(Constant.BO_CLASS_CODE_ORG))) {
				LOG.info("Valid BO CLASS CODE ");
				
				String partyType = upsertParty.getPARTYTYPE();
				if(Constant.PARTY_TYPE_CUSTOMER.equalsIgnoreCase(partyType)){
					partyType = Constant.PARTY_TYPE_CUSTOMER;
				}
				else if(Constant.PARTY_TYPE_RESELLER.equalsIgnoreCase(partyType)){
					partyType = Constant.PARTY_TYPE_RESELLER;
				}
				else if(Constant.PARTY_TYPE_DISTRIBUTOR.equalsIgnoreCase(partyType)){
					partyType = Constant.PARTY_TYPE_DISTRIBUTOR;
				}else{
					partyType = null;
				}
				
				if ((!Util.isNullOrEmpty(partyType))) {
					LOG.info("Valid PartyType ");
					upsertParty.setPARTYTYPE(partyType);
				} else {
					LOG.info(
							"Account is not created since it's PARTY_TYPE is not in ('Customer', 'Reseller', 'Distributor')");
					upsertPartyResponse
							.setStatus("Account blocking successful for invalid PARTY_TYPE. Account with PARTY_TYPE = '"
									+ upsertParty.getPARTYTYPE() + "' not created in MDM");
					upsertPartyResponse.setErrorMsg(
							"Account blocking successful for invalid PARTY_TYPE. Account with PARTY_TYPE = '"
									+ upsertParty.getPARTYTYPE() + "' not created in MDM");
					throw new ServiceProcessingException(Constant.ERROR_ACCOUNT_INVALID_PTY_TYP);
				}

			} else {
				LOG.info("Account is not created since it's BO_CLASS_CODE != 'Organization'");
				upsertPartyResponse.setStatus(
						"Account blocking successful for invalid BO_CLASS_CODE. Account with BO_CLASS_CODE = '"
								+ upsertParty.getBOCLASSCODE() + "' not created in MDM");
				upsertPartyResponse.setErrorMsg(
						"Account blocking successful for invalid BO_CLASS_CODE. Account with BO_CLASS_CODE = '"
								+ upsertParty.getBOCLASSCODE() + "' not created in MDM");
				throw new ServiceProcessingException(Constant.ERROR_ACCOUNT_WRONG_ORG);

			}

		} catch (ServiceProcessingException e) {
			LOG.error("Data validation check failed Due to Invalid Input: " + e.getMessage());
			if (Constant.ERROR_ACCOUNT_CUST_GROUP_INVALID.equals(e.getMessage())) {
				commonUtil.updateErrorStatus(upsertParty, upsertPartyResponse, Constant.ERROR_ACCOUNT_CUST_GROUP_INVALID, "0");
			} else if (Constant.ERROR_ACCOUNT_INVALID_PTY_TYP.equals(e.getMessage())) {
				commonUtil.updateErrorStatus(upsertParty, upsertPartyResponse, Constant.ERROR_ACCOUNT_INVALID_PTY_TYP, "0");
			} else if (Constant.ERROR_ACCOUNT_WRONG_ORG.equals(e.getMessage())) {
				commonUtil.updateErrorStatus(upsertParty, upsertPartyResponse, Constant.ERROR_ACCOUNT_WRONG_ORG, "0");
			} else {
				commonUtil.updateErrorStatus(upsertParty, upsertPartyResponse, Constant.ERROR_ACCOUNT_DATA_VALID_FAIL, "0");
			}
			throw new ServiceProcessingException(e);
		} catch (Exception excp) {
			LOG.error("Data validation check failed: " + excp.getMessage());

			upsertPartyResponse.setErrorMsg("Data validation check failed Due to Error: " + excp.getMessage());

			commonUtil.updateErrorStatus(upsertParty, upsertPartyResponse, Constant.ERROR_ACCOUNT_DATA_VALID_FAIL, "0");
			throw new ServiceProcessingException(Constant.ERROR_ACCOUNT_DATA_VALID_FAIL);
		}

		// Execute next step in upsert flow
		String rowidObj = null;
		if (excuteNextStep)
			upsertTrilliumProcessing(upsertParty, upsertPartyResponse, true, true, rowidObj);

		LOG.info("Executed upsertDataValidation()");
		return;
	}

	
	/* call Trillium Cleanser service to cleanse Name and Addressattributes in request.
	* original request attributes will be overwritten by the cleansed values
	*/
	public void upsertTrilliumProcessing(PartyXrefType curParty, MdmUpsertPartyResponse upsertPartyResponse,
			boolean excuteNextStep, boolean executeFromStart, String rowidObject) throws ServiceProcessingException {
		LOG.info("Executing upsertTrilliumProcessing()");

		PerformanceLoggerUtil perfLog = new PerformanceLoggerUtil();
		String mdmStateCountryArr[] = new String[10];
		boolean setTrilliumValue = false;
		boolean isInTrilliumList = false;
		try {

			// get Cleanse flag
			String cleansFlag = getCleanseFlag(curParty.getPARTYTYPE(), curParty.getXREF().get(0).getSRCSYSTEM());
			LOG.info("Executing upsertTrilliumProcessing()  cleansFlag " + cleansFlag);
			// reset cleanse ind if null
			if (Util.isNullOrEmpty(curParty.getAccount().get(0).getCLEANSEIND())) {
				curParty.getAccount().get(0).setCLEANSEIND(Constant.STR_Y);
			}
			if ((curParty.getAccount().get(0).getCLEANSEIND().equalsIgnoreCase(Constant.STR_Y))
					&& (Constant.STR_Y.equalsIgnoreCase(cleansFlag))) {

				// Checking if Country_CD within list of 71 Countries.
				isInTrilliumList = trilliumLookUpDAO.checkInTrilliumCountryProjectMap(curParty);
				if (isInTrilliumList) {
					LOG.info("Going For TRILLIUM Procedure");
					// Before Trillium LookUP Process
					mdmStateCountryArr = trilliumLookUpDAO.convertSRCToMDMDataUpsert(curParty,
							curParty.getXREF().get(0).getSRCSYSTEM());
					
					// call Trillium Cleanser service to cleanse Name and Address attributes in request
					if (!Util.isNullOrEmpty(mdmStateCountryArr[1])) {
						curParty.getAddress().get(0).setSTATECD(mdmStateCountryArr[0]);
						// parameters.getParty().get(index).getAddress().get(index).setCOUNTRYCD(mdmStateCountryArr[1]);
					}
					if (!Util.isNullOrEmpty(curParty.getAddress().get(0).getSTATECD()) && Util.isNullOrEmpty(mdmStateCountryArr[0])) {
						curParty.getAddress().get(0).setSTATECD("");
					}
					LOG.info("Trillium Call is being made.");
					/* Change for US427 START */
					setTrilliumValue = trilliumCleanserDAO.callTrilliumCleanser(curParty, Boolean.FALSE);
					perfLog.printLog(Constant.PERF_LOG_FLOW_UPSERT_FNO, curParty.getXREF().get(0).getSRCPKEY(),
							"STEP 1", "Trillium Call done");
					/* Change for US427 END */
					// After Trillium LookUP Process
					/* changes for Sales Force Integration -Start */
					// DQ check on Name Quality Indicator
					if (!Util.isNullOrEmpty(curParty.getAccount().get(0).getNAMEQUALITYIDENTIFIER())) {
						String nameQualityIdentifier = curParty.getAccount().get(0).getNAMEQUALITYIDENTIFIER();
						for (int i = 0; i != nameQualityIdentifier.length(); i++) {
							char c = nameQualityIdentifier.charAt(i);
							if ((i == 0 && c == 'V') || (i == 1 && c == 'J') || (i == 2 && c == 'L')
									|| (i == 3 && c == 'G') || (i == 4 && c == 'D')) {
								String respMsg = "Request is not processed due to Name quality Identifier,Please review the party name";

								upsertPartyResponse.setStatus("Processing completed for 0 Party(ies).\n" + respMsg);
								upsertPartyResponse.setErrorCd(respMsg);
								upsertPartyResponse.getUpsertStatus().setCURRENTPROCESSSTEP("NO");
								Util.printObjectTreeInXML(MdmUpsertPartyResponse.class, upsertPartyResponse);
								throw new ServiceProcessingException(Constant.ERROR_ACCOUNT_INVALID_TRL_NM_IND);
							}
						}
					}
					/* changes for FNO Integration -Start */
					trilliumLookUpDAO.convertTrilliumToSRCData(setTrilliumValue, curParty,
							curParty.getXREF().get(0).getSRCSYSTEM());
					trilliumLookUpDAO.convertTrilliumToSRCCountry(curParty, curParty.getXREF().get(0).getSRCSYSTEM());
					perfLog.printLog(Constant.PERF_LOG_FLOW_UPSERT_FNO, curParty.getXREF().get(0).getSRCPKEY(),
							"STEP 2", "Transformation after trillium call to source state and country value");
					// }
				} else {
					
					mdmStateCountryArr = trilliumLookUpDAO.convertSRCToMDMDataUpsert(curParty,curParty.getXREF().get(0).getSRCSYSTEM());
					if (!Util.isNullOrEmpty(curParty.getAddress().get(0).getSTATECD()) && Util.isNullOrEmpty(mdmStateCountryArr[0])) {
						curParty.getAddress().get(0).setSTATECD("");
					}
					LOG.info("Input Country not within list of 71 Countries, So No TRILLIUM Call.");
					perfLog.printLog(Constant.PERF_LOG_FLOW_UPSERT_FNO, curParty.getXREF().get(0).getSRCPKEY(),
							"STEP 1-2", "Trillium call Skipped");
				}
			} else {
				LOG.info("Reset Country code to country Name for non Trillium");
				// Reset Country code to country Name
				if (!Util.isNullOrEmpty(curParty.getAddress().get(0).getCOUNTRYCD())) {
					curParty.getAddress().get(0)
							.setCOUNTRYCD(getFNOCountryName(curParty.getAddress().get(0).getCOUNTRYCD()));
				}
				LOG.info("BY Passing TRILLIUM Call Since Required cleanse  indicator is N");
				perfLog.printLog(Constant.PERF_LOG_FLOW_UPSERT_FNO, curParty.getXREF().get(0).getSRCPKEY(),
						"STEP 1-2", "Trillium call Skipped");
			}

		} catch (ServiceProcessingException e) {
			LOG.error("Trillium Cleanse failed Due to Invalid name identifier: " + e.getMessage());
			String errorMsg = "";
			if(!Util.isNullOrEmpty(upsertPartyResponse.getErrorCd())){
				errorMsg = upsertPartyResponse.getErrorCd();
			}else{
				errorMsg = "Trillim cleanse failed: " + e.getMessage();
			}
			upsertPartyResponse.setStatus(errorMsg);
			if (Constant.ERROR_ACCOUNT_INVALID_TRL_NM_IND.equals(e.getMessage())) {
				commonUtil.updateErrorStatus(curParty, upsertPartyResponse, Constant.ERROR_ACCOUNT_INVALID_TRL_NM_IND, "0");
			} else {
				commonUtil.updateErrorStatus(curParty, upsertPartyResponse, Constant.ERROR_ACCOUNT_DQ_CHECK_FAIL, "0");
			}
			upsertPartyResponse.setErrorMsg(errorMsg);
			throw new ServiceProcessingException(e);
		} catch (Exception excp) {
			LOG.error("Trillim cleanse failed: " + excp.getMessage());
			// upsertPartyResponse = new MdmUpsertPartyResponse();
			String errorMsg = "";
			if(!Util.isNullOrEmpty(upsertPartyResponse.getErrorCd())){
				errorMsg = upsertPartyResponse.getErrorCd();
			}else{
				errorMsg = "Trillim cleanse failed: " + excp.getMessage();
			}
			upsertPartyResponse.setStatus(errorMsg);
			commonUtil.updateErrorStatus(curParty, upsertPartyResponse, Constant.ERROR_ACCOUNT_DQ_CHECK_FAIL, "0");
			upsertPartyResponse.setErrorMsg(errorMsg);
			throw new ServiceProcessingException(Constant.ERROR_ACCOUNT_DQ_CHECK_FAIL);
		}

		// Execute next step in upsert flow
		String rowidObj = null;
		if (excuteNextStep)
			checkDataQualityUpsert(curParty, upsertPartyResponse, true, true, rowidObj);

		LOG.info("Executed upsertTrilliumProcessing()");
		return;
	}

	public void upsertTokenize(PartyXrefType ptyXrefType, MdmUpsertPartyResponse upsertPartyResponse, boolean retry,
			boolean executeNextStep, String rowidObjectRequest) throws ServiceProcessingException {
		LOG.info("Executing upsertTokenize()");

		PerformanceLoggerUtil perfLog = new PerformanceLoggerUtil();
		SiperianClient siperianClient = null;
		String rowidObject = null;
		String rowidAccount = null;
		int maxCountOfRetry = Integer.parseInt(configProps.getProperty("NoOfRetries"));
		boolean isMaxRetrySuccess = false;
		XREFType xref = null;

		try {

			xref = ptyXrefType.getXREF().get(0);
			siperianClient = (SiperianClient) checkOut();
			rowidObject = getRowidFromPkey(xref, "C_B_PARTY");
			rowidAccount = getRowidFromPkey(xref, "C_B_ACCOUNT");
			LOG.info("Calling Party processTokenizeRequest() rowidObject::" + rowidObject);
			if(!Util.isNullOrEmpty(rowidObject)){
				processTokenizeRequest(rowidObject, "C_B_PARTY");
			}
			LOG.info("Calling Account processTokenizeRequest() rowidAccount::" + rowidAccount);
			if(!Util.isNullOrEmpty(rowidAccount)){
				processTokenizeRequest(rowidAccount, "C_B_ACCOUNT");
			}
			perfLog.printLog(Constant.PERF_LOG_FLOW_UPSERT_FNO, xref.getSRCPKEY(), "STEP 11", "Tokenization Done");

			upsertPartyResponse.setStatus(upsertPartyResponse.getStatus()
					+ "\nTokenization operation successful for Party " + xref.getSRCPKEY());
		} catch (SiperianServerException sifExcp) {
			LOG.error("SiperianServerException occured while processing TokenizeRequest for Party");
			ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
			customException.setMessage("SIF exception occured while processing Tokenize request for Party. "
					+ customException.getMessage());
			try {
				if (rowidObject != null) {

					for (int i = 0; i < maxCountOfRetry;) {
						try {
							processTokenizeRequest(rowidObject, "C_B_PARTY");
						} catch (Exception e) {
							i++;
						}
						isMaxRetrySuccess = true;
						break;
					}
				}

			} catch (Exception exp) {
				LOG.error("SiperianServerException occured while retrying TokenizeRequest for Party");

				isMaxRetrySuccess = false;
			}
			if (!isMaxRetrySuccess) {
				upsertPartyResponse = new MdmUpsertPartyResponse();
				upsertPartyResponse.setErrorMsg("Tokenization failed: " + sifExcp.getMessage());

				commonUtil.updateErrorStatus(ptyXrefType, upsertPartyResponse, Constant.ERROR_ACC_TOKENIZE_FAIL, rowidObject);

			}

		} catch (Exception excp) {
			LOG.error("Exception occured while processing TokenizeRequest for Party");
			ServiceProcessingException customException = new ServiceProcessingException(excp);
			customException.setMessage(
					"Exception occured while processing Tokenize request for Party." + customException.getMessage());

			upsertPartyResponse.setErrorMsg("Tokenization failed: " + excp.getMessage());
			commonUtil.updateErrorStatus(ptyXrefType, upsertPartyResponse, Constant.ERROR_ACC_TOKENIZE_FAIL, rowidObject);
			throw new ServiceProcessingException(Constant.ERROR_ACC_TOKENIZE_FAIL);
		} finally {
			checkIn(siperianClient);
		}
		LOG.info("Executed upsertTokenize()");

		if (executeNextStep)
			upsertMatchMergeProcess(ptyXrefType, upsertPartyResponse, true, true, rowidObject);

	}

	/*public void upsertP2CProcess(PartyXrefType ptyXrefType, MdmUpsertPartyResponse upsertPartyResponse,
			boolean excuteNextStep, boolean retry, String survivingPartyRowid) {
		LOG.info("Executing upsertP2CProcess()");

		
		List<String> RowIdXrefList = new ArrayList<String>();
		try {
			survivingPartyRowid = upsertPartyResponse.getParty().get(0).getROWIDOBJECT();
			LOG.debug("Step-1,p2cEligible Rowid object" + survivingPartyRowid);
			if (!Util.isNullOrEmpty(survivingPartyRowid)) {
				
				// P2C_Eligible Checking
				RowIdXrefList = checkP2CEligible(survivingPartyRowid.trim());
				if (RowIdXrefList != null && RowIdXrefList.size() > 0) {
					
					LOG.info("p2cEligible Rowid object" + survivingPartyRowid);
					// fetch classification rowid objects
					List<String> clsfnRowIdList = getRowidsByPartyRowId(RowIdXrefList, MDMAttributeNames.CLASS_BO);
					// soft delete Classification
					deleteChildDAO.deleteChildBO(clsfnRowIdList, MDMAttributeNames.CLASS_BO);
					
					// fetch Org Extn rowid objects
					List<String> orgExtnRowIdList = getRowidsByPartyRowId(RowIdXrefList, MDMAttributeNames.PARTY_ORG_BO);
					// soft delete Org Extn
					deleteChildDAO.deleteChildBO(orgExtnRowIdList, MDMAttributeNames.PARTY_ORG_BO);
					
					LOG.info("Soft delete done for Classification and Org extn for P2C");
					
					// Party status update to C
					if (!Util.isNullOrEmpty(survivingPartyRowid)) {
						// call update propspect Status
						UpdateProspectStatus(survivingPartyRowid.trim(), RowIdXrefList);
						LOG.info("Party status updated to C for P2C");
					}
				}
			}
		} catch (Exception exp) {
			LOG.error("Caught exception while Checking P2cEligible " + exp);
			updateErrorStatus(ptyXrefType, upsertPartyResponse, Constant.ERROR_ACC_P2C_FAIL, "0");
		}

		LOG.info("Executed upsertP2CProcess()");
		if (excuteNextStep)
			try {
				upsertUCNStampProcess(ptyXrefType, upsertPartyResponse, retry, excuteNextStep, survivingPartyRowid);
			} catch (ServiceProcessingException e) {
				e.printStackTrace();
			}
	}*/

	public void upsertUCNStampProcess(PartyXrefType ptyXrefType, MdmUpsertPartyResponse upsertPartyResponse,
			boolean excuteNextStep, boolean retry, String rowidObject) throws ServiceProcessingException {

		LOG.info("Executing upsertUCNStampProcess()");
		int maxCountOfRetry = Integer.parseInt(configProps.getProperty("NoOfRetries"));
		boolean isMaxRetrySuccess = false;
		PerformanceLoggerUtil perfLog = new PerformanceLoggerUtil();
		String survivingPartyRowid;

		XREFType xref = ptyXrefType.getXREF().get(0);
		String existingUCN = null;
		survivingPartyRowid = getRowidFromPkey(xref, "C_B_PARTY");
		boolean isLegacyUCN = false;
		try {
			existingUCN = checkifUCNExists(survivingPartyRowid);
			// Setting UCN value by Calling GET_UCN
			if (Util.isNullOrEmpty(existingUCN)) {
				isLegacyUCN = false;
				LOG.info("UCN for the surviving/new party is Null. Creating UCN for Party ");
				setUcnSeq(survivingPartyRowid, null, MDMAttributeNames.PARTY_BO);
				LOG.debug("UCN value successfully assigned.");
				upsertPartyResponse.setStatus(upsertPartyResponse.getStatus() + " UCN value assigned successfully.");
			}
		} catch (ServiceProcessingException spExcp) {

			LOG.error("Failed to set UCN: ", spExcp);
			warning.append("UCN update process failed, Retry \n");
			try {
				if (survivingPartyRowid != null) {

					for (int i = 0; i < maxCountOfRetry;) {
						try {
							if (!isLegacyUCN) {
								setUcnSeq(survivingPartyRowid, null, MDMAttributeNames.PARTY_BO);
							}
						} catch (Exception e) {
							i++;
						}
						isMaxRetrySuccess = true;
						break;
					}
				}

			} catch (Exception exp) {
				LOG.error("SiperianServerException occured while retrying UCN Stamping for Party");

				isMaxRetrySuccess = false;
			}
			if (!isMaxRetrySuccess) {
				upsertPartyResponse = new MdmUpsertPartyResponse();
				upsertPartyResponse.setErrorMsg("UCN Stamp Process failed: " + spExcp.getMessage());
				commonUtil.updateErrorStatus(ptyXrefType, upsertPartyResponse, Constant.ERROR_ACC_UCN_STAMP_FAIL, rowidObject);
				throw new ServiceProcessingException(Constant.ERROR_ACC_UCN_STAMP_FAIL);
			}

		} catch (Exception Excp) {

			LOG.error("Caught exception while updating UCN: ", Excp);

			warning.append("UCN update process failed, Retry \n");
			try {
				if (rowidObject != null) {

					for (int i = 0; i < maxCountOfRetry;) {
						try {
							if (!isLegacyUCN) {
								setUcnSeq(survivingPartyRowid, null, MDMAttributeNames.PARTY_BO);
							}
						} catch (Exception e) {
							i++;
						}
						isMaxRetrySuccess = true;
						break;
					}
				}

			} catch (Exception exp) {
				LOG.error("SiperianServerException occured while retrying TokenizeRequest for Party");

				isMaxRetrySuccess = false;
			}
			if (!isMaxRetrySuccess) {
				upsertPartyResponse = new MdmUpsertPartyResponse();
				upsertPartyResponse.setErrorMsg("UCN update process failed: " + Excp.getMessage());

				commonUtil.updateErrorStatus(ptyXrefType, upsertPartyResponse, Constant.ERROR_ACC_UCN_STAMP_FAIL, survivingPartyRowid);
				throw new ServiceProcessingException(Constant.ERROR_ACC_UCN_STAMP_FAIL);

			}
		}
		perfLog.printLog(Constant.PERF_LOG_FLOW_UPSERT_FNO, ptyXrefType.getXREF().get(0).getSRCPKEY(), "STEP 15",
				"Stamp UCN / Legacy UCN Done");

		LOG.info("Executed upsertUCNStampProcess()");
		
		if(selfMatchFail){
			putProcessStateInd(null, Constant.SEND_FOR_DNB, survivingPartyRowid,"Admin");
		}
		
		
		if (excuteNextStep)
			upsertDataSyncAccSegAssignProcess(ptyXrefType, upsertPartyResponse, retry, excuteNextStep, survivingPartyRowid);
	}

	public void upsertDataSyncAccSegAssignProcess(PartyXrefType ptyXrefType, MdmUpsertPartyResponse upsertPartyResponse,
			boolean excuteNextStep, boolean retry, String rowidObject) {

		LOG.info("Executing upsertDataSyncAccSegAssignProcess()");

		PerformanceLoggerUtil perfLog = new PerformanceLoggerUtil();
		PartyType survivingPartyProfileFromBO = null;

		// Orchestration update legacy referenced record for SAP,SBL
		XREFType xref = ptyXrefType.getXREF().get(0);
		String sourceKey = xref.getSRCPKEY();
		String srcName = xref.getSRCSYSTEM();
		String survivingPartyRowid = rowidObject;

		PartyXrefType legacyRefParty = new PartyXrefType();
		List<String> sendToSrcList = null;

		perfLog.printLog(Constant.PERF_LOG_FLOW_UPSERT_FNO, sourceKey, "STEP 16",
				"Check for which source system to send Done");

		// Invoking processUpdateRequest() for Dummy Update process.
		try {
			sendToSrcList = getPartyDAO.getSentToList(sourceKey, srcName, false);
			
			if(sendToSrcList!=null && sendToSrcList.size()>0){
			if (StringUtils.isEmpty(survivingPartyRowid)) {
				survivingPartyRowid = getRowidFromPkey(xref, "C_B_PARTY");
			}
			survivingPartyProfileFromBO = getPartyDAO.getBOParty(survivingPartyRowid, p2cEligible);
			PartyXrefType insertedPartyData = new PartyXrefType();
			insertedPartyData = getPartyDAO.fetchPartyXrefTypeFromORS(srcName,sourceKey, p2cEligible);
			LOG.info("Invoking processUpdateRequest() to get LegecyRef Record.");
			legacyRefParty = processUpdateRequest(ptyXrefType, insertedPartyData, sendToSrcList, survivingPartyRowid,
					survivingPartyProfileFromBO);
			}else{
				LOG.info("sendToSrcList is not found for sourceKey:"+sourceKey+" and srcName:"+srcName);
			}

		} catch (ServiceProcessingException Excp) {
			LOG.error("Caught Service Exception while updating LegayID Ref Record: ", Excp);
			upsertPartyResponse.setErrorMsg("Process failed while Updating LegayID Ref Record \n");
			commonUtil.updateErrorStatus(ptyXrefType, upsertPartyResponse, Constant.ERROR_ACC_XREF_UPDATE_FAIL, "0");
		} catch (Exception Excp) {
			LOG.error("Caught Generic Exception while updating LegayID Ref Record: ", Excp);
			upsertPartyResponse.setErrorMsg("Process failed while Updating LegayID Ref Record \n");
			commonUtil.updateErrorStatus(ptyXrefType, upsertPartyResponse, Constant.ERROR_ACC_XREF_UPDATE_FAIL, "0");

		}

		perfLog.printLog(Constant.PERF_LOG_FLOW_UPSERT_FNO, sourceKey, "STEP 17",
				"Get legacy ref record and orchestration Done");
		LOG.info("Executed upsertDataSyncAccSegAssignProcess()");
		return;
	}

	public void upsertAccSegAssignProcess(PartyXrefType insertedPartyref, PartyType survivingPartyProfileFromBO,
			SiperianClient siperianClient) throws ServiceProcessingException {
		LOG.info("Executing upsertAccSegAssignProcess()");

		String sourceClsfnId = null;
		String targetClsfnId = null;
		List<String> targetRowidList = new ArrayList<String>();
		// Create Classification BO to XREF
		if (!isJapan) {
			LOG.debug("Account segment calling for SFDC/SBL/SAP" + isJapan);
			if (insertedPartyref != null) {
				if (insertedPartyref.getClassification() == null
						|| (insertedPartyref.getClassification().size() == 0)) {
					// If golden copy has SFV classification value
					for (int index1 = 0; index1 < survivingPartyProfileFromBO.getClassification().size(); index1++) {
						if ((insertedPartyref.getXREF().get(0).getSRCSYSTEM().trim().equalsIgnoreCase("SFC"))
								&& (survivingPartyProfileFromBO.getClassification().get(index1).getCLASSIFICTNTYPE()
										.equalsIgnoreCase("Segment - Final Value"))) {
							LOG.info(
									"Copying 'Segment - Final Value' classification records from BO copy  to insertedPartyref party for SFC");
							ClassificationXrefType classificationXref = new ClassificationXrefType();
							classificationXref.setSRCPKEY(insertedPartyref.getXREF().get(0).getSRCPKEY().trim());
							classificationXref.setSRCSYSTEM(insertedPartyref.getXREF().get(0).getSRCSYSTEM().trim());
							classificationXref.setROWIDCLASSIFICTN(
									survivingPartyProfileFromBO.getClassification().get(index1).getROWIDCLASSIFICTN());
							classificationXref.setCLASSIFICTNTYPE(
									survivingPartyProfileFromBO.getClassification().get(index1).getCLASSIFICTNTYPE());
							classificationXref.setCLASSIFICTNVALUE(
									survivingPartyProfileFromBO.getClassification().get(index1).getCLASSIFICTNVALUE());
							classificationXref.setSTARTDATE(
									survivingPartyProfileFromBO.getClassification().get(index1).getSTARTDATE());
							classificationXref.setENDDATE(
									survivingPartyProfileFromBO.getClassification().get(index1).getENDDATE());
							insertedPartyref.getClassification().add(classificationXref);
						} else if ((insertedPartyref.getXREF().get(0).getSRCSYSTEM().trim().equalsIgnoreCase("SBL"))
								|| (insertedPartyref.getXREF().get(0).getSRCSYSTEM().trim().equalsIgnoreCase("SAP"))) {
							if (survivingPartyProfileFromBO.getClassification().get(index1).getCLASSIFICTNTYPE()
									.equalsIgnoreCase("Segment - Final Value")
									|| survivingPartyProfileFromBO.getClassification().get(index1).getCLASSIFICTNTYPE()
											.equalsIgnoreCase("Segmentation Process Code")
									|| survivingPartyProfileFromBO.getClassification().get(index1).getCLASSIFICTNTYPE()
											.equalsIgnoreCase("Segment - System Assigned Value")
									|| survivingPartyProfileFromBO.getClassification().get(index1).getCLASSIFICTNTYPE()
											.equalsIgnoreCase("Industry_Vertical")) {
								LOG.info(
										"Copying 'Segment - Final Value' classification records from BO copy  to insertedPartyref party for SAP/SBL");

								ClassificationXrefType classificationXref = new ClassificationXrefType();
								classificationXref.setSRCPKEY(insertedPartyref.getXREF().get(0).getSRCPKEY().trim());
								classificationXref
										.setSRCSYSTEM(insertedPartyref.getXREF().get(0).getSRCSYSTEM().trim());
								classificationXref.setROWIDCLASSIFICTN(survivingPartyProfileFromBO.getClassification()
										.get(index1).getROWIDCLASSIFICTN());
								classificationXref.setCLASSIFICTNTYPE(survivingPartyProfileFromBO.getClassification()
										.get(index1).getCLASSIFICTNTYPE());
								classificationXref.setCLASSIFICTNVALUE(survivingPartyProfileFromBO.getClassification()
										.get(index1).getCLASSIFICTNVALUE());
								classificationXref.setSTARTDATE(
										survivingPartyProfileFromBO.getClassification().get(index1).getSTARTDATE());
								classificationXref.setENDDATE(
										survivingPartyProfileFromBO.getClassification().get(index1).getENDDATE());
								insertedPartyref.getClassification().add(classificationXref);
							}
						} else {
							LOG.info(
									"New Account Segmentation on Classification is ignored since Invalid Classification");
						}
					}

					if (insertedPartyref.getClassification() != null
							&& insertedPartyref.getClassification().size() > 0) {
						LOG.debug("Account segment put call for SFDC");
						sourceClsfnId = putClassification(insertedPartyref.getClassification(), insertedPartyref,
								siperianClient);
						LOG.debug("ClassificationSource Key: " + sourceClsfnId);
						// merge classification
						LOG.debug("Calling Classification SFV merge");
						try {
							targetRowidList = getclsfnTargetId(insertedPartyref.getROWIDOBJECT().trim());
						} catch (SQLException e) {
							LOG.error("SQL Exception occured while fetching target classification Id");
						} catch (Exception ex) {
							LOG.error("Exception occured while fetching target classification Id");
						}
						// newly created record will merge to existing record
						if (targetRowidList != null && targetRowidList.size() > 0) {
							for (Iterator<String> iter = targetRowidList.iterator(); iter.hasNext();) {
								String tempId = iter.next();
								LOG.debug("ClassificationTargetKey in loop: " + tempId);
								if (!Util.isNullOrEmpty(tempId)) {
									if (tempId.trim().equals(sourceClsfnId.trim())) {
										continue;
									} else {
										targetClsfnId = tempId;
									}
								}
							}
						}
						LOG.debug("ClassificationSource Key: " + sourceClsfnId + " | ClassificationTarget Key: "
								+ targetClsfnId);

						String siperianObjectUid = "BASE_OBJECT.C_B_PARTY_CLASSIFCTN";
						/** Merge Retry Mechanism */
						try {
							if ((!Util.isNullOrEmpty(targetClsfnId))
									&& (!targetClsfnId.trim().equals(sourceClsfnId.trim()))) {
								mergeProcessChild(siperianObjectUid, sourceClsfnId, targetClsfnId, siperianClient);
								LOG.debug("Classification Merge is successful !!");
							} else {
								LOG.debug("Classification Merge  is successfully skipped targetClsfnId not found!!");
							}
						} catch (Exception sifExcp) {

							LOG.error("Exception occured in C_B_PARTY_CLASSIFCTN Merge ");
						}
					}

				} else {
					LOG.info("New Account Segmentation on Classification is ignored since Classification is present");
				}
			}

		} else {
			LOG.info("New Account Segmentation on Classification is ignored since CountryCd isJapan is: " + isJapan);
		}
		/*
		 * if (insertedPartyref.getClassification() != null &&
		 * insertedPartyref.getClassification().size() > 0) { LOG.debug(
		 * "Account segment put call for SFDC");
		 * putClassification(insertedPartyref.getClassification(),
		 * insertedPartyref, siperianClient); } }else{ LOG.info(
		 * "New Account Segmentation on Classification is ignored since CountryCd isJapan is: "
		 * +isJapan); }
		 */
		// PerformanceLoggerUtil perfLog = new PerformanceLoggerUtil();
		LOG.info("Executed upsertAccSegAssignProcess()");
		return;
	}

	private String getRowidFromPkey(XREFType xref, String BO) {
		LOG.info("Execute getRowidFromPkey()");
		String rowidObject = null;
		try {
			GetRequest getReq = new GetRequest();
			getReq.setSiperianObjectUid(SiperianObjectType.BASE_OBJECT.makeUid(BO));
			RecordKey recordKey = new RecordKey();
			recordKey.setSourceKey(xref.getSRCPKEY());
			recordKey.setSystemName(xref.getSRCSYSTEM());
			getReq.setRecordKey(recordKey);
			SiperianClient siperianClient = (SiperianClient) checkOut();
			GetResponse getResp = (GetResponse) siperianClient.process(getReq);
			rowidObject = getResp.getRecordKey().getRowid();
			LOG.info("Party rowid_object of newly created record = " + rowidObject);

		} catch (Exception exp) {
			LOG.error("Error getting rowidObject for pkey " + xref.getSRCPKEY());
			// return null;
		}
		return rowidObject;
	}

	private void childMultiMergeParty(PartyXrefType upsertParty, MdmUpsertPartyResponse upsertPartyResponse,
			PutResponseDataHolder putRespDataParty, boolean isP2C) throws ServiceProcessingException {

		PartyType survivingPartyProfileFromBO = null;
		String survivingPartyRowid = null;
		PerformanceLoggerUtil perfLog = new PerformanceLoggerUtil();
		if(upsertPartyResponse.getParty()!=null && upsertPartyResponse.getParty().size()>0){
			survivingPartyRowid = upsertPartyResponse.getParty().get(0).getROWIDOBJECT();
		}
		if(!Util.isNullOrEmpty(survivingPartyRowid)){
		LOG.info("Party rowid_object of merged/newly created record = " + survivingPartyRowid);
		
		SiperianClient siperianClient = null;
		String rowidObject = null;
		int maxCountOfRetry = Integer.parseInt(configProps.getProperty("NoOfRetries"));
		boolean isMaxRetrySuccess = false;

		int multiMergecountOfRetry = Integer.parseInt(configProps.getProperty("NoOfRetries"));
		boolean isMergeRetrySuccess = false;

		// Fetch base object records for new party or surviving party using
		// canonical structure
		survivingPartyProfileFromBO = getPartyDAO.getBOParty(survivingPartyRowid, p2cEligible);

		// Merge address and classification child entities
		try {
			mergeProcessMultipleChild(survivingPartyProfileFromBO, upsertPartyResponse, isP2C);
			LOG.debug("Multi-Merge is successful on Address, Communication and Classification child entities");
		} catch (Exception servExcp) {
			// mergeInd = false;
			LOG.error("Exception occured while Multi-Merge on Address, Communication and Classification: ", servExcp);
			for (int i = 0; i < multiMergecountOfRetry; i++) {
				try {
					LOG.debug("Retrying Multi-Merge process for " + (i + 1) + "th time");
					mergeProcessMultipleChild(survivingPartyProfileFromBO, upsertPartyResponse, isP2C);
					LOG.debug("Multi-Merge is successful on attempt no. " + (i + 1));
					isMergeRetrySuccess = true;
					// mergeInd = true;
					break;
				} catch (Exception excp) {
					LOG.error("Exception occured in Multi-Merge Retry on attempt no. " + (i + 1));
					LOG.error("Exception occured in Multi-Merge RetryMechanism...");
				}
			}
			if (!isMergeRetrySuccess) {
				ServiceProcessingException customException = new ServiceProcessingException(servExcp);
				customException.setMessage(
						"SIF exception occured while processing Multi-Merge on Address, Communication and Classification: "
								+ customException.getMessage());
				commonUtil.updateErrorStatus(upsertParty, upsertPartyResponse, Constant.ERROR_ACC_MERGE_FAIL, survivingPartyRowid);
				throw customException;
			}

		}
		}

		perfLog.printLog(Constant.PERF_LOG_FLOW_UPSERT_FNO, upsertParty.getXREF().get(0).getSRCPKEY(), "STEP 13",
				"Match and Merge process Done");

	}

	public void populateUpsertResponse(PartyXrefType upsertParty, MdmUpsertPartyResponse upsertPartyResponse) {

		// set Response Structure
		try {

			PartyXrefType crossrefPartyData = null;
			PartyType goldenPartyData = null;
			List<XREFCopy> xrefCopyList = new ArrayList<XREFCopy>();
			XREFCopy xrefCopy = null;
			Map<String, List<PartyXrefType>> partyXrefMap = null;
			XREFType xref = upsertParty.getXREF().get(0);
			String survivingPartyRowid = getRowidFromPkey(xref, "C_B_PARTY");

			LOG.info("populateUpsertResponse for RowidObject" + survivingPartyRowid);
			// Update C_REPOS_MQ_DATA_CHANGE table to sent flag 9 for FNO records for which FNO record has created
			if (survivingPartyRowid != null) {
				LOG.info("Update C_REPOS_MQ_DATA_CHANGE table to sent flag 99");
				commonUtil.setMsgSentFlagInTable(survivingPartyRowid,Constant.SRC_SYSTEM_FNO);
				
			} else {
				LOG.error("----------No update on C_REPOS_MQ_DATA_CHANGE ------------");
			}
			
			if (upsertPartyResponse.getParty().size() > 0) {
				upsertPartyResponse.getParty().clear();
			}
			
			
			if (survivingPartyRowid != null) {
				//fetch golden record
				goldenPartyData = getPartyDAO.getBOParty(survivingPartyRowid.trim(), p2cEligible);
				partyXrefMap = searchPartyDAO.getXrefRecforID(survivingPartyRowid.trim(), null,goldenPartyData.getPARTYTYPE(), p2cEligible);
			}

			if (goldenPartyData != null) {
				
				PartyUpsertRespType partyUpsertResp = new PartyUpsertRespType();
				Account accInfo = null;
				List<Account> accountList = new ArrayList<Account>();
				Address address = null;
				List<Address> addressList = new ArrayList<Address>();
				Communication communication = null;
				List<Communication> commList = new ArrayList<Communication>();
				Classification classfction = null;
				List<Classification> classificationList = new ArrayList<Classification>();
				PartyOrgExt partyOrgExt = null;
				List<PartyOrgExt> partyOrgExtList = new ArrayList<PartyOrgExt>();
				PartyRel partyRel = null;
				PartyAccountRelationshipType partyAccountRelationship = null;
				List<PartyAccountRelationshipType> partyAccountRelList = new ArrayList<PartyAccountRelationshipType>();
				
				int itemIndex = 0;
				
				String rowIdParty = goldenPartyData.getROWIDOBJECT();
				// set all column of Party into response
				//if (goldenPartyData != null) {
					// partyUpsertResp = new PartyUpsertRespType();
					partyUpsertResp.setROWIDOBJECT(goldenPartyData.getROWIDOBJECT());
					partyUpsertResp.setSRCSYSTEM(upsertParty.getXREF().get(0).getSRCSYSTEM());
					partyUpsertResp.setSRCSYSTEMID(upsertParty.getXREF().get(0).getSRCPKEY());
					partyUpsertResp.setBOCLASSCODE(goldenPartyData.getBOCLASSCODE());
					partyUpsertResp.setPARTYTYPE(goldenPartyData.getPARTYTYPE());
					partyUpsertResp.setPARTYNAME(goldenPartyData.getPARTYNAME());
					partyUpsertResp.setGEO(goldenPartyData.getGEO());
					partyUpsertResp.setREGION(goldenPartyData.getREGION());
					partyUpsertResp.setSTATUSCD(goldenPartyData.getSTATUSCD());
					partyUpsertResp.setVATREGNBR(goldenPartyData.getVATREGNBR());
					partyUpsertResp.setTAXJURSDCTNCD(goldenPartyData.getTAXJURSDCTNCD());
					partyUpsertResp.setSALESBLOCKCD(goldenPartyData.getSALESBLOCKCD());
					partyUpsertResp.setUCN(goldenPartyData.getUCN());
					partyUpsertResp.setMSGTRKNID(upsertParty.getMSGTRKNID());
					partyUpsertResp.setPHYSICALGEO(goldenPartyData.getPHYSICALGEO());
					partyUpsertResp.setPHYSICALREGION(goldenPartyData.getPHYSICALREGION());
					partyUpsertResp.setENGLISHNAME(goldenPartyData.getENGLISHNAME());
					// retrive child from goldenPartyData
					AccountType accountParam = null;
					for (itemIndex = 0; itemIndex < goldenPartyData.getAccount().size(); itemIndex++) {
						accountParam = goldenPartyData.getAccount().get(itemIndex);
						if (accountParam.getROWIDACCOUNT() != null) {

							LOG.debug("============setting Account");
							accInfo = new Account();

							accInfo.setROWIDACCOUNT(accountParam.getROWIDACCOUNT().trim());
							accInfo.setACCTNAME(accountParam.getACCTNAME());
							accInfo.setALIASNAME(accountParam.getALIASNAME());
							accInfo.setACCTSTATUS(accountParam.getACCTSTATUS());
							accInfo.setACCTTYPE(accountParam.getACCTTYPE());
							accInfo.setACCOUNTREGION(accountParam.getACCOUNTREGION());
							accInfo.setACCOUNTGEO(accountParam.getACCOUNTGEO());
							accInfo.setMARKET(accountParam.getMARKET());
							accInfo.setCUSTGROUP(accountParam.getCUSTGROUP());
							accInfo.setPRICEGROUP(accountParam.getPRICEGROUP());
							accInfo.setCOMPANYCD(accountParam.getCOMPANYCD());
							accInfo.setACCOUNTVATREGNBR(accountParam.getACCOUNTVATREGNBR());
							accInfo.setTAXTYPE(accountParam.getTAXTYPE());
							accInfo.setACCOUNTTAXJURSDCTNCD(accountParam.getACCOUNTTAXJURSDCTNCD());
							accInfo.setBILLBLOCKCD(accountParam.getBILLBLOCKCD());
							accInfo.setORDRBLOCKCD(accountParam.getORDRBLOCKCD());
							accInfo.setDLVRYBLOCKCD(accountParam.getDLVRYBLOCKCD());
							accInfo.setPOSTBLOCKCD(accountParam.getPOSTBLOCKCD());
							accInfo.setSALEBLOCKCD(accountParam.getSALEBLOCKCD());
							accInfo.setCHANNELID(accountParam.getCHANNELID());
							accInfo.setPARTNERTYPE(accountParam.getPARTNERTYPE());
							accInfo.setVENDORNBR(accountParam.getVENDORNBR());
							accInfo.setDIRECTIND(accountParam.getDIRECTIND());
							accInfo.setNAMEDACCTIND(accountParam.getNAMEDACCTIND());
							accInfo.setNONVALACCTIND(accountParam.getNONVALACCTIND());
							accInfo.setPARTNERIND(accountParam.getPARTNERIND());
							accInfo.setSIEBELROWID(accountParam.getSIEBELROWID());
							accInfo.setSAPCUSTNUMBER(accountParam.getSAPCUSTNUMBER());
							//accInfo.setMDMLEGACYID(accountParam.getMDMLEGACYID());
							accInfo.setSAPNAME1(accountParam.getSAPNAME1());
							accInfo.setSAPNAME2(accountParam.getSAPNAME2());
							accInfo.setSAPNAME3(accountParam.getSAPNAME3());
							accInfo.setSAPNAME4(accountParam.getSAPNAME4());
							// accInfo.setDATASRCSYSTEM(accountParam.getField("DATA_SRC_SYSTEM").getStringValue());

							/** Modified for SFDC START */
							accInfo.setSalesForceID(accountParam.getSalesForceID());
							accInfo.setDraftAccountFlag(accountParam.getDraftAccountFlag());
							/** Modified for SFDC END */
							accInfo.setLOCALNAME(accountParam.getLOCALNAME());
							accInfo.setTAXID(accountParam.getTAXID());
							accInfo.setCURRENCYCD(accountParam.getCURRENCYCD());
							accInfo.setPRICEBANDAGGREMENT(accountParam.getPRICEBANDAGGREMENT());
							/** changes for Track-2 -Start */
							accInfo.setSITEDESIGNATION(accountParam.getSITEDESIGNATION());
							/** changes for Track-2 -End */
							/** changes for Track-3 -Start */
							accInfo.setRESELLLEVEL(accountParam.getRESELLLEVEL());
							accInfo.setPARTNERSHIPSTATUS(accountParam.getPARTNERSHIPSTATUS());
							/** changes for Track-3 -End */
							LOG.debug("===Inserting into Account List===");
							accountList.add(accInfo);

						}

					}
					if( commonUtil.isPartyBillingAddressExist( goldenPartyData.getAddress())){
						addressList=commonUtil.popoulateAddress(goldenPartyData.getAddress(), Constant.ADDRESS_TYPE_BILLING);
						
					}else{
						addressList=commonUtil.popoulateAddress(goldenPartyData.getAddress(), Constant.ADDRESS_TYPE_MAILING);
					}
					/*AddressType addrParam = null;
					for (itemIndex = 0; itemIndex < goldenPartyData.getAddress().size(); itemIndex++) {
						addrParam = goldenPartyData.getAddress().get(itemIndex);
						if (addrParam.getROWIDADDRESS() != null) {

							LOG.debug("============setting Address");
							address = new Address();

							address.setROWIDADDRESS(addrParam.getROWIDADDRESS().trim());
							address.setADDRLN1(addrParam.getADDRLN1());
							address.setADDRLN2(addrParam.getADDRLN2());
							address.setADDRLN3(addrParam.getADDRLN3());
							address.setADDRLN4(addrParam.getADDRLN4());
							address.setCITY(addrParam.getCITY());
							address.setCOUNTY(addrParam.getCOUNTY());
							address.setDISTRICT(addrParam.getDISTRICT());
							address.setSTATECD(addrParam.getSTATECD());
							address.setPOSTALCD(addrParam.getPOSTALCD());
							address.setCOUNTRYCD(addrParam.getCOUNTRYCD());
							address.setLANGCD(addrParam.getLANGCD());
							address.setLONGITUDE(addrParam.getLONGITUDE());
							address.setLATITUDE(addrParam.getLATITUDE());
							address.setADDRTYPE(addrParam.getADDRTYPE());
							address.setADDRSTATUS(addrParam.getADDRSTATUS());
							if (address.getADDRSTATUS().equalsIgnoreCase("A")
									|| address.getADDRSTATUS().equalsIgnoreCase("I")
									|| address.getADDRSTATUS().equalsIgnoreCase("D")) {
								LOG.debug("===Inserting into Address List===");
								addressList.add(address);
							}
						}

					}*/
					CommunicationType commParam = null;
					for (itemIndex = 0; itemIndex < goldenPartyData.getCommunication().size(); itemIndex++) {
						commParam = goldenPartyData.getCommunication().get(itemIndex);
						if (commParam.getROWIDCOMMUNICATION() != null) {

							LOG.debug("============setting communication");

							communication = new Communication();

							communication.setROWIDCOMMUNICATION(commParam.getROWIDCOMMUNICATION().trim());
							communication.setCOMMTYPE(commParam.getCOMMTYPE());
							communication.setCOMMVALUE(commParam.getCOMMVALUE());
							communication.setCOMMSTATUS(commParam.getCOMMSTATUS());
							communication.setPRFRDCOMMIND(commParam.getPRFRDCOMMIND());
							communication.setWEBDOMAIN(commParam.getWEBDOMAIN());

							LOG.debug("===Inserting into communication List===");
							commList.add(communication);

						}

					}
					ClassificationType clsfparam = null;
					boolean isSalesSegmentExists = false;
					for (itemIndex = 0; itemIndex < goldenPartyData.getClassification().size(); itemIndex++) {
						clsfparam = goldenPartyData.getClassification().get(itemIndex);
						if (clsfparam.getROWIDCLASSIFICTN() != null) {
							if(!(clsfparam.getCLASSIFICTNTYPE().equals("Sales_Segment"))){
							classfction = new Classification();
							LOG.debug("============adding Classification ");

							classfction.setROWIDCLASSIFICTN(clsfparam.getROWIDCLASSIFICTN().trim());
							classfction.setCLASSIFICTNTYPE(clsfparam.getCLASSIFICTNTYPE());
							classfction.setCLASSIFICTNVALUE(clsfparam.getCLASSIFICTNVALUE());
							classfction.setSTARTDATE(clsfparam.getSTARTDATE());
							classfction.setENDDATE(clsfparam.getENDDATE());

							LOG.debug("===Inserting into Classification List===");
							classificationList.add(classfction);
							}else{
							isSalesSegmentExists = true;
							}
						}
					}
					if(isSalesSegmentExists){
						Classification classfictn = getLastUpdatedClassficationValue(rowIdParty);
						classificationList.add(classfictn);
					}
					PartyOrgExtType orgExtnparam = null;
					for (itemIndex = 0; itemIndex < goldenPartyData.getPartyOrgExt().size(); itemIndex++) {
						orgExtnparam = goldenPartyData.getPartyOrgExt().get(itemIndex);
						if (orgExtnparam.getROWIDORGEXTN() != null) {

							partyOrgExt = new PartyOrgExt();
							LOG.debug("============adding partyOrgExtn ");

							// classfction.setROWIDCLASSIFICTN(clsfparam.getROWIDCLASSIFICTN());

							partyOrgExt.setROWIDORGEXTN(orgExtnparam.getROWIDORGEXTN().trim());
							partyOrgExt.setORGDUNSNBR(orgExtnparam.getORGDUNSNBR());
							partyOrgExt.setTRADENAME(orgExtnparam.getTRADENAME());
							partyOrgExt.setTRADENAME2(orgExtnparam.getTRADENAME2());
							partyOrgExt.setSITEEMPLCNT(orgExtnparam.getSITEEMPLCNT());
							partyOrgExt.setGLBLEMPLCNT(orgExtnparam.getGLBLEMPLCNT());
							partyOrgExt.setVERTICAL(orgExtnparam.getVERTICAL());
							partyOrgExt.setREVENUE(orgExtnparam.getREVENUE());
							partyOrgExt.setLINEOFBUS(orgExtnparam.getLINEOFBUS());
							partyOrgExt.setPRIMSIC(orgExtnparam.getPRIMSIC());
							partyOrgExt.setSECSIC(orgExtnparam.getSECSIC());
							partyOrgExt.setSALESVOLUME(orgExtnparam.getSALESVOLUME());
							partyOrgExt.setSALESAMOUNT(orgExtnparam.getSALESAMOUNT());
							partyOrgExt.setCURRENCYCD(orgExtnparam.getCURRENCYCD());
							partyOrgExt.setOUTOFBUSIND(orgExtnparam.getOUTOFBUSIND());
							partyOrgExt.setGLBLULTIND(orgExtnparam.getGLBLULTIND());
							partyOrgExt.setFORTUNEINFO(orgExtnparam.getFORTUNEINFO());
							partyOrgExt.setHIERARCHYLEVEL(orgExtnparam.getHIERARCHYLEVEL());
							partyOrgExt.setORGHQPARENTDUNS(orgExtnparam.getORGHQPARENTDUNS());
							partyOrgExt.setORGDOMULTDUNS(orgExtnparam.getORGDOMULTDUNS());
							partyOrgExt.setORGGLBULTDUNS(orgExtnparam.getORGGLBULTDUNS());
							partyOrgExt.setMFEGLBLPARENTNM(orgExtnparam.getMFEGLBLPARENTNM());
							partyOrgExt.setMFEPARENTNM(orgExtnparam.getMFEPARENTNM());
							partyOrgExt.setMFEPRTNRPARENTORG(orgExtnparam.getMFEPRTNRPARENTORG());
							partyOrgExt.setSALESREVNUOVRID(orgExtnparam.getSALESREVNUOVRID());
							partyOrgExt.setMFEEMPCNTOVERIDE(orgExtnparam.getMFEEMPCNTOVERIDE());
							partyOrgExt.setSICCDOVRIDE(orgExtnparam.getSICCDOVRIDE());
							/** changes for Track-2 -Start */
							partyOrgExt.setMFECOUNTRYULTUCN(orgExtnparam.getMFECOUNTRYULTUCN());
							partyOrgExt.setMFEGLBLPARENTUCN(orgExtnparam.getMFEGLBLPARENTUCN());
							partyOrgExt.setMFEGLOBALPARNMOVRIDE(orgExtnparam.getMFEGLOBALPARNMOVRIDE());
							partyOrgExt.setMFENEXTLVLSUBSPARNM(orgExtnparam.getMFENEXTLVLSUBSPARNM());
							partyOrgExt.setMFENEXTLVLSUBSPARUCN(orgExtnparam.getMFENEXTLVLSUBSPARNM());
							partyOrgExt.setMFESUBSDRYPARENTNM(orgExtnparam.getMFESUBSDRYPARENTNM());
							partyOrgExt.setMFESUBSDRYPARENTPRTNNM(orgExtnparam.getMFESUBSDRYPARENTPRTNNM());
							partyOrgExt.setMFESUBSPARENTNMOVRIDE(orgExtnparam.getMFESUBSPARENTNMOVRIDE());
							partyOrgExt.setMFESUBSPARENTUCN(orgExtnparam.getMFESUBSPARENTUCN());
							partyOrgExt.setMFETXN5YRFLG(orgExtnparam.getMFETXN5YRFLG());
							partyOrgExt.setMFETXN7YRFLG(orgExtnparam.getMFETXN7YRFLG());
							partyOrgExt.setMFEWWPARENTNM(orgExtnparam.getMFEWWPARENTNM());
							partyOrgExt.setMFEWWPARENTPRTNNM(orgExtnparam.getMFEWWPARENTPRTNNM());
							partyOrgExt.setTXN5YRFLG(orgExtnparam.getTXN5YRFLG());
							partyOrgExt.setTXN7YRFLG(orgExtnparam.getTXN7YRFLG());
							partyOrgExt.setGLBEMPCNTOVERRIDE(orgExtnparam.getGLBEMPCNTOVERRIDE());
							partyOrgExt.setACTIVETXNFLG(orgExtnparam.getACTIVETXNFLG());
							partyOrgExt.setPARENTFLG(orgExtnparam.getPARENTFLG());
							partyOrgExt.setPARTNERFLG(orgExtnparam.getPARTNERFLG());
							partyOrgExt.setCUSTFLG(orgExtnparam.getCUSTFLG());
							partyOrgExt.setGLBFLG(orgExtnparam.getGLBFLG());
							partyOrgExt.setCOUNTRYULTIND(orgExtnparam.getCOUNTRYULTIND());
							partyOrgExt.setCUSTOMPARENTUCN(orgExtnparam.getCUSTOMPARENTUCN());
							partyOrgExt.setCUSTOMPARENTNAME(orgExtnparam.getCUSTOMPARENTNAME());
							partyOrgExt.setMFECOUNTRYULTUCN(orgExtnparam.getMFECOUNTRYULTUCN());
							partyOrgExt.setSUBSIDIARYIND(orgExtnparam.getSUBSIDIARYIND());
							partyOrgExt.setMDMPARENTUCN(orgExtnparam.getMDMPARENTUCN());
							partyOrgExt.setCUSTOMERPARENTFLAG(orgExtnparam.getCUSTOMERPARENTFLAG());
							partyOrgExt.setG2KFLG(orgExtnparam.getG2KFLG());
							partyOrgExt.setGLBSALESREVNUOVRID(orgExtnparam.getGLBSALESREVNUOVRID());
							/** changes for Track-2 -End */
							/** changes for Track-3 -Start */
							partyOrgExt.setPTRPARENTNM(orgExtnparam.getPTRPARENTNM());
							partyOrgExt.setPTRPARENTUCN(orgExtnparam.getPTRPARENTUCN());
							partyOrgExt.setPTRGLBLPARENTUCN(orgExtnparam.getPTRGLBLPARENTUCN());
							/** changes for Track-3 -End */
							LOG.debug("===Inserting into partyOrgExtn List===");
							partyOrgExtList.add(partyOrgExt);

						}

					}
					PartyAccountRelationshipType partyAccRelparam = null;
					for (itemIndex = 0; itemIndex < goldenPartyData.getPartyRel().getPARTYACCOUNTREL()
							.size(); itemIndex++) {
						partyAccRelparam = goldenPartyData.getPartyRel().getPARTYACCOUNTREL().get(itemIndex);
						if (partyAccRelparam != null) {
							partyRel = new PartyRel();
							LOG.debug("===Inserting into PARTYACCOUNTREL List===");
							partyAccountRelList.add(partyAccRelparam);
							partyRel.getPARTYACCOUNTREL().addAll(partyAccountRelList);
						}

					}
					partyUpsertResp.getAccount().addAll(accountList);
					partyUpsertResp.getAddress().addAll(addressList);
					partyUpsertResp.getCommunication().addAll(commList);
					partyUpsertResp.getClassification().addAll(classificationList);
					partyUpsertResp.getPartyOrgExt().addAll(partyOrgExtList);
					partyUpsertResp.setPartyRel(partyRel);
                    //set UPDATE_DATE
					//LOG.debug("Adding update date in  master response " + goldenPartyData.getUPDATEDATE());
					upsertPartyResponse.setUPDATEDATE(goldenPartyData.getUPDATEDATE());
					upsertPartyResponse.getParty().add(partyUpsertResp);
					if (partyXrefMap.containsKey(survivingPartyRowid)) {
						xrefCopy = new XREFCopy();
						LOG.debug("Adding XREF Copies in master response ");
						xrefCopy.getPartyXref().addAll(partyXrefMap.get(survivingPartyRowid));
						// xrefCopyList.add(xrefCopy);
						upsertPartyResponse.getXREFCopy().add(xrefCopy);
					}
				//}

			}
		} catch (Exception excp) {
			LOG.error("Exception occured while processing mdmUpsertPartyResponse  for Party "
					+ upsertParty.getXREF().get(0).getSRCPKEY(), excp);
			ServiceProcessingException customException = new ServiceProcessingException(excp);
			if(excp.getMessage().contains(Constant.DB_CONN_FAILURE)){
				upsertPartyResponse.setErrorCd(Constant.DB_CONN_FAILURE);
				upsertPartyResponse.setErrorMsg(excp.getMessage());
			}
			customException.setMessage("Exception occured while processing mdmUpsertPartyResponsefor Party. "
					+ customException.getMessage());
			// throw customException;
		}

		if (warning != null && warning.length() > 0) {
			upsertPartyResponse.setWarningMsg(warning.toString());
		}
	}

	// Fetch AccountID for a specific ACCOUNT
	// private String getAccountId(String partyId) throws SQLException,
	// ServiceProcessingException {
	private List<String> getAccountId(String partyId) throws SQLException, ServiceProcessingException {
		Connection jdbcConn = null;
		JDBCConnectionProvider jDBCConnectionProvider = null;
		Statement statement = null;
		ResultSet resultSet = null;
		List<String> accountId = new ArrayList<String>();
		StringBuilder sql = new StringBuilder();
		// sql.append("select b.rowid_object as ROWID_OBJECT from c_b_party_xref
		// a,c_b_account_xref b where a.pkey_src_object = b.s_rowid_party and
		// a.hub_state_ind = 1 and b.hub_state_ind = 1 and a.rowid_object = ");
		sql.append("SELECT ROWID_OBJECT FROM C_B_ACCOUNT WHERE HUB_STATE_IND = 1  AND ROWID_PARTY =");
		sql.append("'" + partyId + "'");
		LOG.info("SQL in getAccountId()->" + sql);
		try {
			jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
			jdbcConn = jDBCConnectionProvider.getJdbcConnectionFromDS();
			statement = jdbcConn.createStatement();
			resultSet = statement.executeQuery(sql.toString());

			while (resultSet.next()) {

				accountId.add(resultSet.getString("ROWID_OBJECT"));
			}
		} catch (SQLException exp) {
			LOG.error("Caught exception in getAccountId ", exp);
			// throw exp;
		} finally {
			// Closing connections
			if (resultSet != null)
				resultSet.close();
			if (statement != null)
				statement.close();
			if (jdbcConn != null)
				jdbcConn.close();
		}
		return accountId;
	}
	
	public Classification getLastUpdatedClassficationValue(String partyId) throws SQLException, ServiceProcessingException {
		LOG.debug("[getLastUpdatedClassficationValue] ENTER");
		Connection jdbcConn = null;
		JDBCConnectionProvider jDBCConnectionProvider = null;
		Statement statement = null;
		ResultSet resultSet = null;
		List<String> accountId = new ArrayList<String>();
		StringBuilder sql = new StringBuilder();
		Classification classfction = null;
		sql.append("SELECT * FROM (SELECT PC.ROWID_OBJECT, PC.LAST_UPDATE_DATE, PC.START_DATE, PC.END_DATE, PC.CLASSIFCTN_TYPE, PC.CLASSIFCTN_VALUE, ROW_NUMBER() OVER(PARTITION BY PC.ROWID_PARTY ORDER BY PC.LAST_UPDATE_DATE DESC) as ROW_NBR FROM C_B_PARTY_CLASSIFCTN PC WHERE PC.CLASSIFCTN_TYPE = 'Sales_Segment' AND ROWID_PARTY=");
		sql.append("'" + partyId + "')");
		sql.append(" CLASFTN_TABLE WHERE CLASFTN_TABLE.ROW_NBR = 1");
		LOG.info("SQL in getAccountId()->" + sql);
		try {
			jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
			jdbcConn = jDBCConnectionProvider.getJdbcConnectionFromDS();
			statement = jdbcConn.createStatement();
			resultSet = statement.executeQuery(sql.toString());

			while (resultSet.next()) {
				classfction = new Classification();
				LOG.debug("============adding Classification ");

				classfction.setROWIDCLASSIFICTN(resultSet.getString("ROWID_OBJECT"));
				classfction.setCLASSIFICTNTYPE(resultSet.getString("CLASSIFCTN_TYPE"));
				classfction.setCLASSIFICTNVALUE(resultSet.getString("CLASSIFCTN_VALUE"));
				classfction.setSTARTDATE(resultSet.getString("START_DATE"));
				classfction.setENDDATE(resultSet.getString("END_DATE"));
			}
			LOG.debug("Retrieved last updated classification rowid : " +classfction.getROWIDCLASSIFICTN());
			LOG.debug("Retrieved last updated classification type : " +classfction.getCLASSIFICTNTYPE());
			LOG.debug("Retrieved last updated classification value : " +classfction.getCLASSIFICTNVALUE());
			LOG.debug("Retrieved last updated classification start date : " +classfction.getSTARTDATE());
			LOG.debug("Retrieved last updated classification end date : " +classfction.getENDDATE());
		} catch (SQLException exp) {
			LOG.error("Caught exception in getAccountId ", exp);
			// throw exp;
		} finally {
			// Closing connections
			if (resultSet != null)
				resultSet.close();
			if (statement != null)
				statement.close();
			if (jdbcConn != null)
				jdbcConn.close();
		}
		LOG.debug("[getLastUpdatedClassficationValue] EXIT:");
		return classfction;
	}

	private List<String> getclsfnTargetId(String partyId) throws SQLException, ServiceProcessingException {
		Connection jdbcConn = null;
		JDBCConnectionProvider jDBCConnectionProvider = null;
		Statement statement = null;
		ResultSet resultSet = null;
		List<String> accountId = new ArrayList<String>();
		StringBuilder sql = new StringBuilder();

		sql.append(
				"SELECT ROWID_OBJECT FROM C_B_PARTY_CLASSIFCTN where HUB_STATE_IND = 1  AND  classifctn_type = 'Segment - Final Value' AND ROWID_PARTY = ");
		sql.append("'" + partyId + "'");
		LOG.info("SQL in getclsfnTargetId()->" + sql);
		try {
			jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
			jdbcConn = jDBCConnectionProvider.getJdbcConnectionFromDS();
			statement = jdbcConn.createStatement();
			resultSet = statement.executeQuery(sql.toString());

			while (resultSet.next()) {

				// accountId = resultSet.getString("ROWID_OBJECT");
				accountId.add(resultSet.getString("ROWID_OBJECT"));
			}
		} catch (SQLException exp) {
			LOG.error("Caught exception in getclsfnTargetId ", exp);
			// throw exp;
		} finally {
			// Closing connections
			if (resultSet != null)
				resultSet.close();
			if (statement != null)
				statement.close();
			if (jdbcConn != null)
				jdbcConn.close();
		}
		return accountId;
	}

	private List<String> getSFVCode(String salesSegValue) throws ServiceProcessingException {

		LOG.debug("Inside getSFVCode()");
		Connection jdbcConn = null;
		Statement statement = null;
		ResultSet resultSet = null;
		JDBCConnectionProvider jDBCConnectionProvider = null;
		StringBuilder sql = new StringBuilder();
		List<String> classValCode = new ArrayList<String>();

		sql.append(
				"select siebel_cd, sap_cd, sfdc_cd from mdm_list_of_values where LOV_TYPE= 'MFE_ACCNT_SEGMENT' and upper(lov_value) = ");
		sql.append("upper(q'$" + salesSegValue + "$')");

		LOG.debug("SQL for getSFVCode()-->" + sql);

		try {
			jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
			jdbcConn = jDBCConnectionProvider.getJdbcConnectionFromDS();
			statement = jdbcConn.createStatement();
			resultSet = statement.executeQuery(sql.toString());

			while (resultSet.next()) {
				classValCode.add(resultSet.getString(1)); // siebel_cd
				classValCode.add(resultSet.getString(2)); // sap_cd
				classValCode.add(resultSet.getString(3)); // sfdc_cd
			}

		} catch (SQLException e) {
			LOG.error("Caught SQLException in getSFVCode().");
		} finally {
			try {
				if (resultSet != null)
					resultSet.close();
				if (statement != null)
					statement.close();
				if (jdbcConn != null)
					jdbcConn.close();
			} catch (SQLException exp) {
				LOG.error("Caught SQLException in getSFVCode().");
			}

		}

		LOG.debug("Executed getSFVCode()");
		return classValCode;

	}

	public String getCleanseFlag(String partyType, String srcName) {
		LOG.debug("Inside getCleanseFlag()");
		PreparedStatement statement = null;
		Connection jdbcConn = null;
		ResultSet resultSet = null;
		String cleansFlag = null;
		JDBCConnectionProvider jDBCConnectionProvider = null;
		try {
			jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
			jdbcConn = jDBCConnectionProvider.getJdbcConnectionFromDS();
			LOG.info("getCleanseFlag  partyType : " + partyType + " srcName is : " + srcName);
			StringBuilder sql = new StringBuilder();
			sql.append("select CLEANSE_FLAG from DATA_FLOW_CLEANSE  where PARTY_TYPE = ? and SOURCE_SYSTEM = ?");
			LOG.debug("SQL Generated is : " + sql.toString());
			statement = jdbcConn.prepareStatement(sql.toString());
			statement.setString(1, partyType);
			statement.setString(2, srcName);
			resultSet = statement.executeQuery();
			if (resultSet.next()) {
				cleansFlag = resultSet.getString(1);
			}
			LOG.debug("cleansFlag value is: " + cleansFlag);
		} catch (Exception exp) {
			exp.printStackTrace();
		} finally {
			try {
				if (resultSet != null)
					resultSet.close();
				if (statement != null)
					statement.close();
				if (jdbcConn != null)
					jdbcConn.close();
			} catch (SQLException exp) {
				LOG.error("Caught SQLException in getCleanseFlag().");
			}

		}
		return cleansFlag;
	}

	// Check Partner Type exist
	public boolean checkpartnerTypeExist(String partnerType) throws ServiceProcessingException {
		LOG.info("Executing checkpartnerTypeExist()");

		Statement statement = null;
		StringBuilder sqlQry = new StringBuilder();
		JDBCConnectionProvider jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
		;
		Connection jdbcConnection = null;
		ResultSet resultSet = null;
		int recordCount = 0;
		boolean partnerTypeExist = false;

		try {
			sqlQry.append("Select 1 from mdm_list_of_values where lov_type = 'PARTNER_TYPE' and SFDC_CD = ");
			sqlQry.append("'" + partnerType + "'");
			jdbcConnection = jDBCConnectionProvider.getJdbcConnectionFromDS();
			// statement =
			// jdbcConnection.prepareStatement(Constant.COUNT_FROM_PARTY_XREF);
			statement = jdbcConnection.createStatement();
			resultSet = statement.executeQuery(sqlQry.toString());
			LOG.info("Query to fetch presence of partnerType record: " + sqlQry);

			while (resultSet.next()) {
				recordCount = resultSet.getInt(1);

			}
			LOG.info("Record count with partnerType  = " + recordCount);
			if (recordCount > 0) {
				partnerTypeExist = true;
			}

		} catch (SQLException sqlEx) {
			LOG.error("Exception occurred while checking the presence of partnerType Record: ", sqlEx);
			// sqlEx.printStackTrace();
			ServiceProcessingException customException = new ServiceProcessingException(sqlEx);
			customException.setMessage("Failed to check the presence of of partnerType Record: " + sqlEx.getMessage());
			throw customException;
		} finally {
			try {
				if (resultSet != null)
					resultSet.close();
				if (statement != null)
					statement.close();
				if (jdbcConnection != null)
					jdbcConnection.close();
			} catch (SQLException e) {

				e.printStackTrace();
			}
		}

		LOG.info("Executed checkpartnerTypeExist()");

		return partnerTypeExist;
	}

	private void resetAccountSite(PartyXrefType upsertParty, PartyType existingPartyData) {
		LOG.debug("Before ReSetting AccountSiteDesignation in Input payload before CleansePut.");
		List<AccountXrefType> accountList = upsertParty.getAccount();
		String priorirtyFlag = null;
		String mdmSiteDegn = null;
		String mdmSiteDegnSFDCCD = null;
		if (!Util.isNullOrEmpty(existingPartyData.getAccount().get(0).getSITEDESIGNATION())) {
			mdmSiteDegn = existingPartyData.getAccount().get(0).getSITEDESIGNATION();
			LOG.debug("mdmSiteDegn old  " + existingPartyData.getAccount().get(0).getSITEDESIGNATION());
		}

		for (int index = 0; index < accountList.size(); index++) {
			if (!Util.isNullOrEmpty(mdmSiteDegn)) {
				LOG.debug("mdmSiteDegn New  " + accountList.get(index).getSITEDESIGNATION());
				priorirtyFlag = getSFDCpriorirtyFlag(accountList.get(index).getSITEDESIGNATION());
				if (!Util.isNullOrEmpty(priorirtyFlag) && priorirtyFlag.equalsIgnoreCase("Y")
						&& !Util.isNullOrEmpty(accountList.get(index).getSITEDESIGNATION())) {
					LOG.debug("mdmSiteDegn New priorirtyFlag Y " + accountList.get(index).getSITEDESIGNATION());
					upsertParty.getAccount().get(index).setSITEDESIGNATION(accountList.get(index).getSITEDESIGNATION());
				} else {
					mdmSiteDegnSFDCCD = getSFDCCDSiteDesg(mdmSiteDegn);
					LOG.debug("Setting mdmSiteDegnSFDCCD  " + mdmSiteDegnSFDCCD);
					upsertParty.getAccount().get(index).setSITEDESIGNATION(mdmSiteDegnSFDCCD);
				}

			}
		}
		LOG.debug("After ReSetting AccountSiteDesignation in Input payload before CleansePut.");
	}

	public String getSFDCpriorirtyFlag(String sitedegn) {
		LOG.debug("Inside getSFDCpriorirtyFlag()");
		PreparedStatement statement = null;
		Connection jdbcConn = null;
		ResultSet resultSet = null;
		String priorirtyFlag = null;
		JDBCConnectionProvider jDBCConnectionProvider = null;
		try {
			jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
			jdbcConn = jDBCConnectionProvider.getJdbcConnectionFromDS();
			LOG.info("getSFDCpriorirtyFlag  sitedegn : " + sitedegn);
			StringBuilder sql = new StringBuilder();
			sql.append("Select SFDC_PRIORITY from mdm_list_of_values where lov_type = 'SITE_DESGNTN' and SFDC_CD = ?");
			LOG.debug("SQL Generated is : " + sql.toString());
			statement = jdbcConn.prepareStatement(sql.toString());
			statement.setString(1, sitedegn);
			resultSet = statement.executeQuery();
			if (resultSet.next()) {
				priorirtyFlag = resultSet.getString(1);
			}
			LOG.debug("SFDCpriorirtyFlag value is: " + priorirtyFlag);
		} catch (Exception exp) {
			exp.printStackTrace();
		} finally {
			try {
				if (resultSet != null)
					resultSet.close();
				if (statement != null)
					statement.close();
				if (jdbcConn != null)
					jdbcConn.close();
			} catch (SQLException exp) {
				LOG.error("Caught SQLException in getSFDCpriorirtyFlag().");
			}

		}
		return priorirtyFlag;
	}

	/**
	 * Processing Account-Contact Relation mapping
	 * <ol>
	 * <li>Retrieve data from temp table MDM_RTS_MRKT_ACC_CONTACT_REL</li>
	 * <li>Create composite list of contact PKEY from incoming data & temp table
	 * data</li>
	 * <li>Check in XRef for those Pkeys</li>
	 * <li>If found then CleasePut in Golden record and delete from temp table
	 * </li>
	 * <li>Else insert data in temp table for any new incoming data</li>
	 * </ol>
	 * 
	 * @param upsertResponse
	 * @param partyContactRelList
	 * @param rowIdParty
	 * @param srcSystem
	 * @param srcPkey
	 * @throws ServiceProcessingException
	 */
	/*private void processAcntCntctRel(PartyXrefType ptyXrefType, MdmUpsertPartyResponse upsertPartyResponse,
			boolean excuteNextStep, boolean retry, String rowidObject) throws ServiceProcessingException {
		LOG.debug("[processAcntCntctRel] ENTER");
		
		Map<String, Boolean> contactPkeyMap = new HashMap<String, Boolean>();
		XREFType xref = ptyXrefType.getXREF().get(0);
		String rowIdParty = getRowidFromPkey(xref, "C_B_PARTY");
		String srcSystem = ptyXrefType.getXREF().get(0).getSRCSYSTEM();
		String srcPkey = ptyXrefType.getXREF().get(0).getSRCPKEY();

		List<AcntCntctRelData> actnCntctRelDataList = prospectPartyDAO.getPendingAcntCntctRel(srcSystem, srcPkey,
				Constant.BO_CLASS_CODE_ORG, true);

		if (!CollectionUtils.isEmpty(actnCntctRelDataList)) {
			for (AcntCntctRelData actnCntctRelData : actnCntctRelDataList) {
				contactPkeyMap.put(actnCntctRelData.getCntctSrcPkey(), Boolean.TRUE);
			}
		}
		if (CollectionUtils.isEmpty(contactPkeyMap.keySet())) {
			LOG.debug("[processAcntCntctRel] No Contact Rel to process");
		} else {
			LOG.debug("[processAcntCntctRel] contactPkeyMap to process for Account::" + contactPkeyMap);
			String contactPkeys = StringUtils.collectionToDelimitedString(contactPkeyMap.keySet(), Constant.STR_COMMA,
					Constant.STR_SINGLE_QUOTE, Constant.STR_SINGLE_QUOTE);
			List<CntctPkeyRowIdRelData> existingContactRowidList = prospectPartyDAO
					.getContactRowIdsFromPkeys(contactPkeys, true);
			List<String> pkeysToDeleteFromTempTable = new ArrayList<String>();
			if (!CollectionUtils.isEmpty(existingContactRowidList)) {
				List<PutResponseDataHolder> actnCntctDataHolderList = cleansePutAccountContactRel(upsertPartyResponse,
						existingContactRowidList, rowIdParty, srcSystem, srcPkey, null);
				for (CntctPkeyRowIdRelData existingContactRowid : existingContactRowidList) {
					if (existingContactRowid.getIsCleansePut()) {
						String curContactPkey = existingContactRowid.getContactPkey();
						if (contactPkeyMap.containsKey(curContactPkey) && contactPkeyMap.get(curContactPkey)) {
							pkeysToDeleteFromTempTable.add(curContactPkey);
						}
						contactPkeyMap.remove(curContactPkey);
					}
				}
			}
			prospectPartyDAO.deletePkeysFromTempTable(
					StringUtils.collectionToDelimitedString(pkeysToDeleteFromTempTable, Constant.STR_COMMA,
							Constant.STR_SINGLE_QUOTE, Constant.STR_SINGLE_QUOTE),
					srcSystem, srcPkey, Boolean.TRUE, Boolean.TRUE);
		}

		LOG.debug("[processAcntCntctRel] EXIT::");
		if (excuteNextStep)
			upsertDataSyncAccSegAssignProcess(ptyXrefType, upsertPartyResponse, retry, excuteNextStep, rowidObject);
	}*/

	/**
	 * The method prepares and executes CleansePutRequest on PARTY_REL landing
	 * table for the given Contact profiles.
	 * 
	 * @param upsertResponse
	 * @param contactRowid
	 * @param rowIdAccount
	 * @param srcSystem
	 * @param srcPkey
	 * @param relLastUpdateDate
	 * @return putResponseActnCntctDataHolder
	 * @throws ServiceProcessingException
	 */
	private PutResponseDataHolder cleansePutAccountContactRel(MdmUpsertPartyResponse upsertResponse,
			String contactRowid, String rowIdAccount, String srcSystem, String srcPkey, String relLastUpdateDate)
			throws ServiceProcessingException {
		LOG.debug("[cleansePutAccountContactRel] ENTER");
		LOG.debug("[cleansePutAccountContactRel] contactRowid::" + contactRowid + ", rowIdAccount::" + rowIdAccount
				+ ", srcSystem::" + srcSystem + ", srcPkey::" + srcPkey + ", relLastUpdateDate::" + relLastUpdateDate);
		UserTransaction transaction = null;
		SiperianClient siperianClient = null;
		lastUpdateDate = Util.getCurrentTimeZone();
		PutResponseDataHolder responseDataHolder = new PutResponseDataHolder();
		try {
			siperianClient = (SiperianClient) checkOut();
			transaction = ((EjbSiperianClient) siperianClient).createTX(300000);
			transaction.begin();
			CleansePutRequest cleansePutRequest = new CleansePutRequest();
			Record record = new Record();
			record.setSiperianObjectUid(Util.getMappingObjectUid(srcSystem, MDMAttributeNames.ENTITY_RELATION));
			if (Util.isNullOrEmpty(relLastUpdateDate)) {
				LOG.info("Performing cleansePutParty with sysdate from HUB: " + lastUpdateDate);
				record.setField(new Field(MDMAttributeNames.LAST_UPDATE_DATE, lastUpdateDate));
			} else {
				record.setField(new Field(MDMAttributeNames.LAST_UPDATE_DATE, relLastUpdateDate));
			}
			record.setField(new Field(MDMAttributeNames.SRC_SYSTEM, srcSystem));
			record.setField(new Field(MDMAttributeNames.SRC_SYS_KEY, srcPkey));
			record.setField(new Field(MDMAttributeNames.PARENT_ID, rowIdAccount));
			record.setField(new Field(MDMAttributeNames.CHILD_ID, contactRowid));
			record.setField(new Field(MDMAttributeNames.HIERARCHY_CODE, Constant.ROWID_CONTACT_HIERARCHY_TYPE));
			record.setField(new Field(MDMAttributeNames.REL_TYPE_CODE, Constant.ROWID_CONTACT_REL_TYPE));
			cleansePutRequest.setRecord(record);
			CleansePutResponse cleansePutResponse = (CleansePutResponse) siperianClient.process(cleansePutRequest);
			LOG.info("Account Contact Rel Put request processed successfully: " + cleansePutResponse.getMessage());
			RecordKey recordKey = cleansePutResponse.getRecordKey();
			responseDataHolder.setActionType(cleansePutResponse.getActionType());
			responseDataHolder.setActionMessage(cleansePutResponse.getMessage());
			responseDataHolder.setRowidObject(recordKey.getRowid());
			responseDataHolder.setRowidXREF(recordKey.getRowidXref());
			responseDataHolder.setSourceKey(recordKey.getSourceKey());
			responseDataHolder.setSystemName(recordKey.getSystemName());
			LOG.info("ROWID_OBJECT of created Party Account Rel record = " + recordKey.getRowid()
					+ "\nPKEY_SRC  of created Party Account Rel record = " + recordKey.getSourceKey());
			transaction.commit();
		} catch (Exception ex) {

			LOG.error("Exception occured while preparing/processing cleansePut requests: ", ex);
			try {
				transaction.rollback();
			} catch (SystemException txExcp) {
				LOG.error("Failed to rollback transaction for cleansePut requests : ", txExcp);
			}
			ServiceProcessingException customException = new ServiceProcessingException(ex);
			customException.setMessage("Failed to process cleansePut SIF request." + customException.getMessage());
			throw customException;
		} finally {
			checkIn(siperianClient);
		}
		LOG.debug("[cleansePutAccountContactRel] EXIT");
		return responseDataHolder;
	}

	/**
	 * The method prepares and executes CleansePutRequest on PARTY_REL landing
	 * table for the given Contact profiles.
	 * 
	 * @param upsertResponse
	 * @param existingContactRowidList
	 * @param rowIdAccount
	 * @param srcSystem
	 * @param srcPkey
	 * @param relLastUpdateDate
	 * @return putResponseActnCntctDataHolder
	 * @throws ServiceProcessingException
	 */
	private List<PutResponseDataHolder> cleansePutAccountContactRel(MdmUpsertPartyResponse upsertResponse,
			List<CntctPkeyRowIdRelData> existingContactRowidList, String rowIdAccount, String srcSystem, String srcPkey,
			String relLastUpdateDate) throws ServiceProcessingException {
		LOG.debug("[cleansePutAccountContactRel] ENTER");
		List<PutResponseDataHolder> putResponseActnCntctDataHolder = new ArrayList<PutResponseDataHolder>();
		try {
			for (CntctPkeyRowIdRelData existingContactRowid : existingContactRowidList) {

				/** Retry on cleanse Put Start **/
				int cleansePutAccountContactcountOfRetry = Integer.parseInt(configProps.getProperty("NoOfRetries"));
				boolean iscleansePutRetrySuccess = false;
				PutResponseDataHolder responseDataHolder = null;
				try {
					responseDataHolder = cleansePutAccountContactRel(upsertResponse,
							existingContactRowid.getContactRowId(), rowIdAccount, srcSystem, srcPkey,
							relLastUpdateDate);
				} catch (Exception servExcp) {
					LOG.error("Exception occured while cleansePut AccountContact: ", servExcp);
					for (int i = 0; i < cleansePutAccountContactcountOfRetry; i++) {
						try {
							LOG.debug("Retrying cleansePut AccountContact for " + (i + 1) + "th time");
							responseDataHolder = cleansePutAccountContactRel(upsertResponse,
									existingContactRowid.getContactRowId(), rowIdAccount, srcSystem, srcPkey,
									relLastUpdateDate);
							LOG.debug("Retry cleansePut AccountContact is successful on attempt no. " + (i + 1));
							iscleansePutRetrySuccess = true;
							break;
						} catch (Exception excp) {
							LOG.error("Exception occured in cleansePut AccountContact Retry on attempt no. " + (i + 1));
							LOG.error("Exception occured in cleansePut AccountContact RetryMechanism...");
						}

					}
					if (!iscleansePutRetrySuccess) {
						upsertResponse.setErrorMsg("CleansePut operation failed for Account - Contact Rel" + srcPkey);
						ServiceProcessingException customException = new ServiceProcessingException(servExcp);
						customException.setMessage("SIF exception occured while processing cleansePut AccountContact : "
								+ customException.getMessage());
						throw customException;
					}
				}

				/** Retry on cleanse Put END **/

				putResponseActnCntctDataHolder.add(responseDataHolder);
				existingContactRowid.setIsCleansePut(Boolean.TRUE);
			}
		} catch (ServiceProcessingException ex) {
			throw ex;
		} catch (Exception ex) {
			upsertResponse.setErrorMsg("CleansePut operation failed for Account - Contact Rel" + srcPkey);
			LOG.error("Exception occured while preparing/processing cleansePut requests: ", ex);
			ServiceProcessingException customException = new ServiceProcessingException(ex);
			customException.setMessage("Failed to process cleansePut SIF request." + customException.getMessage());
			throw customException;
		}
		LOG.debug("[cleansePutAccountContactRel] EXIT");
		return putResponseActnCntctDataHolder;
	}

	public String getSFDCCDSiteDesg(String sitedegn) {
		LOG.debug("Inside getSFDCCDSiteDesg()");
		PreparedStatement statement = null;
		Connection jdbcConn = null;
		ResultSet resultSet = null;
		String sitedegnSFDCCD = null;
		JDBCConnectionProvider jDBCConnectionProvider = null;
		try {
			jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
			jdbcConn = jDBCConnectionProvider.getJdbcConnectionFromDS();
			LOG.info("getSFDCCDSiteDesg  sitedegn : " + sitedegn);
			StringBuilder sql = new StringBuilder();
			sql.append("Select SFDC_CD from mdm_list_of_values where lov_type = 'SITE_DESGNTN' and LOV_VALUE = ?");
			LOG.debug("SQL Generated is : " + sql.toString());
			statement = jdbcConn.prepareStatement(sql.toString());
			statement.setString(1, sitedegn);
			resultSet = statement.executeQuery();
			if (resultSet.next()) {
				sitedegnSFDCCD = resultSet.getString(1);
			}
			LOG.debug("sitedegnSFDCCD value is: " + sitedegnSFDCCD);
		} catch (Exception exp) {
			exp.printStackTrace();
		} finally {
			try {
				if (resultSet != null)
					resultSet.close();
				if (statement != null)
					statement.close();
				if (jdbcConn != null)
					jdbcConn.close();
			} catch (SQLException exp) {
				LOG.error("Caught SQLException in getSFDCCDSiteDesg().");
			}

		}
		return sitedegnSFDCCD;
	}

	public String getFNOCountryName(String countrycd) {
		LOG.debug("Inside getFNOCountryCName()");
		PreparedStatement statement = null;
		Connection jdbcConn = null;
		ResultSet resultSet = null;
		String countryName = null;
		JDBCConnectionProvider jDBCConnectionProvider = null;
		try {
			jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
			jdbcConn = jDBCConnectionProvider.getJdbcConnectionFromDS();
			LOG.info("getFNOCountryCName  countrycode : " + countrycd);
			StringBuilder sql = new StringBuilder();
			sql.append("select FNO_COUNTRY_NM from MDM_COUNTRY  WHERE FNO_COUNTRY_CD = ?");
			LOG.debug("SQL Generated is : " + sql.toString());
			statement = jdbcConn.prepareStatement(sql.toString());
			statement.setString(1, countrycd);
			resultSet = statement.executeQuery();
			if (resultSet.next()) {
				countryName = resultSet.getString(1);
			}
			LOG.debug("countryName value is: " + countryName);
		} catch (Exception exp) {
			exp.printStackTrace();
		} finally {
			try {
				if (resultSet != null)
					resultSet.close();
				if (statement != null)
					statement.close();
				if (jdbcConn != null)
					jdbcConn.close();
			} catch (SQLException exp) {
				LOG.error("Caught SQLException in getFNOCountryCName().");
			}

		}
		return countryName;
	}

	public String getFNOCountryCode(String countryNm) {
		LOG.debug("Inside getSFDCCountryCode()");
		PreparedStatement statement = null;
		Connection jdbcConn = null;
		ResultSet resultSet = null;
		String countryName = null;
		JDBCConnectionProvider jDBCConnectionProvider = null;
		try {
			jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
			jdbcConn = jDBCConnectionProvider.getJdbcConnectionFromDS();
			LOG.info("getSFDCCountryCode  countryNm : " + countryNm);
			StringBuilder sql = new StringBuilder();
			sql.append("select FNO_COUNTRY_CD from MDM_COUNTRY  WHERE upper(FNO_COUNTRY_NM) = upper(q'$" + countryNm + "$')");
			LOG.debug("SQL Generated is : " + sql.toString());
			statement = jdbcConn.prepareStatement(sql.toString());
			//statement.setString(1, countryNm);
			resultSet = statement.executeQuery();
			if (resultSet.next()) {
				countryName = resultSet.getString(1);
			}
			LOG.debug("countryName value is: " + countryName);
		} catch (Exception exp) {
			exp.printStackTrace();
		} finally {
			try {
				if (resultSet != null)
					resultSet.close();
				if (statement != null)
					statement.close();
				if (jdbcConn != null)
					jdbcConn.close();
			} catch (SQLException exp) {
				LOG.error("Caught SQLException in getFNOCountryCode().");
			}

		}
		return countryName;
	}

	private boolean checkMdmLegacyIdExist(String putRowId, String mdmLegacyId)
			throws SQLException, ServiceProcessingException {
		Connection jdbcConn = null;
		JDBCConnectionProvider jDBCConnectionProvider = null;
		Statement statement = null;
		ResultSet resultSet = null;
		int recordCount = 0;
		boolean morePartyExist = false;
		Set<Integer> partyIds = new TreeSet<Integer>();
		StringBuilder sql = new StringBuilder();
		sql.append("SELECT 1 FROM C_B_ACCOUNT WHERE HUB_STATE_IND = 1  AND ACCT_STATUS = 'A' AND  ROWID_PARTY <>  ");
		sql.append("'" + putRowId + "'");
		sql.append(" AND MDM_LEGACY_ID =");
		sql.append("'" + mdmLegacyId + "'");
		LOG.info("SQL in getpartyIds()->" + sql);
		try {
			jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
			jdbcConn = jDBCConnectionProvider.getJdbcConnectionFromDS();
			statement = jdbcConn.createStatement();
			resultSet = statement.executeQuery(sql.toString());

			while (resultSet.next()) {
				recordCount = resultSet.getInt(1);

			}
			LOG.info("Record count with morePartyExist  = " + recordCount);
			if (recordCount > 0) {
				morePartyExist = true;
			}
		} catch (SQLException exp) {
			LOG.error("Caught exception in getpartyIds ", exp);
			// throw exp;
		} finally {
			// Closing connections
			if (resultSet != null)
				resultSet.close();
			if (statement != null)
				statement.close();
			if (jdbcConn != null)
				jdbcConn.close();
		}
		return morePartyExist;
	}

	private Set<Integer> getpartyIds(String putRowId, String mdmLegacyId)
			throws SQLException, ServiceProcessingException {
		Connection jdbcConn = null;
		JDBCConnectionProvider jDBCConnectionProvider = null;
		Statement statement = null;
		ResultSet resultSet = null;
		Set<Integer> partyIds = new TreeSet<Integer>();
		StringBuilder sql = new StringBuilder();
		sql.append(
				"SELECT ROWID_PARTY FROM C_B_ACCOUNT WHERE HUB_STATE_IND = 1  AND ACCT_STATUS = 'A' AND  ROWID_PARTY <>  ");
		sql.append("'" + putRowId + "'");
		sql.append(" AND MDM_LEGACY_ID =");
		sql.append("'" + mdmLegacyId + "'");
		LOG.info("SQL in getpartyIds()->" + sql);
		try {
			jDBCConnectionProvider = JDBCConnectionProvider.getSingleInstance();
			jdbcConn = jDBCConnectionProvider.getJdbcConnectionFromDS();
			statement = jdbcConn.createStatement();
			resultSet = statement.executeQuery(sql.toString());

			while (resultSet.next()) {
				LOG.info("Matched party id with same MDM legacy id "+resultSet.getString("ROWID_PARTY"));
				int rowidKey = Integer.parseInt(resultSet.getString("ROWID_PARTY").trim());
				partyIds.add(rowidKey);
			}
			LOG.info("Matched party id Size with same MDM legacy id "+partyIds.size());
		} catch (SQLException exp) {
			LOG.error("Caught exception in getpartyIds ", exp);
			// throw exp;
		} finally {
			// Closing connections
			if (resultSet != null)
				resultSet.close();
			if (statement != null)
				statement.close();
			if (jdbcConn != null)
				jdbcConn.close();
		}
		return partyIds;
	}

	public void mergeProcessPartyForMdmLegacyId(String putRowidObject, String matchRowId, PartyXrefType upsertParty,
			MdmUpsertPartyResponse upsertPartyResponse) throws ServiceProcessingException {

		LOG.info("Executing mergeProcessPartyForMdmLegacyId() method.");
		String survivorRowidObject = null;
		UserTransaction transaction = null;
		SiperianClient siperianClient = null;
		boolean isError = false;
		String targetRowid = null;
		List<String> targetRowidList = new ArrayList<String>();

		int countOfRetry = Integer.parseInt(configProps.getProperty("NoOfRetries"));
		boolean isMergeRetrySuccess = false;
		List<String> rowidList = new ArrayList<String>();
		List<String> rowidAccountList = new ArrayList<String>();
		// execute Match and Merge SIF operation
		try {

			siperianClient = checkOut();
			transaction = ((EjbSiperianClient) siperianClient).createTX(300000);
			transaction.begin();

			survivorRowidObject = matchRowId;
			if (survivorRowidObject != null && putRowidObject != null) {
				//rowidList.add(survivorRowidObject);
				rowidList.add(putRowidObject);
				updateCI(rowidList, "C_B_PARTY");
				mergeParty(survivorRowidObject, putRowidObject, siperianClient);
				LOG.debug("Party Merge is successful !!");
				targetRowidList = getAccountId(survivorRowidObject.trim());
				// newly created record will merge to existing record
				String sourceRowid = getRowidFromPkey(upsertParty.getXREF().get(0), "C_B_ACCOUNT");
				if (targetRowidList != null && targetRowidList.size() > 0) {
					for (Iterator<String> iter = targetRowidList.iterator(); iter.hasNext();) {
						String tempId = iter.next();
						if (!Util.isNullOrEmpty(tempId)) {
							if (tempId.trim().equals(sourceRowid.trim())) {
								continue;
							} else {
								targetRowid = tempId;
							}
						}
					}
				}
				LOG.debug("AccountSorce Key: " + sourceRowid + " | AccountTarget Key: " + targetRowid);

				String siperianObjectUid = "BASE_OBJECT.C_B_ACCOUNT";
				/** Merge Retry Mechanism */
				try {
					if ((!Util.isNullOrEmpty(targetRowid)) && (!targetRowid.trim().equals(sourceRowid.trim()))) {
						/*rowidAccountList.add(sourceRowid);
						rowidAccountList.add(targetRowid);
						updateCI(rowidAccountList, "C_B_ACCOUNT");*/
						mergeProcessChild(siperianObjectUid, sourceRowid, targetRowid, siperianClient);
						LOG.debug("Account Merge is successful !!");
					} else {
						LOG.debug("Account Merge for ELQ is successfully skipped !!");
					}
				} catch (Exception sifExcp) {
					// mergeInd = false;
					LOG.error("Exception occured while processing Merge operation on C_B_ACCOUNT: ", sifExcp);
					for (int i = 0; i < countOfRetry; i++) {
						try {
							LOG.debug("Retrying C_B_ACCOUNT Merge process for " + (i + 1) + "th time");
							/*rowidAccountList.add(sourceRowid);
							rowidAccountList.add(targetRowid);*/
							updateCI(rowidAccountList, "C_B_ACCOUNT");
							mergeProcessChild(siperianObjectUid, sourceRowid, targetRowid, siperianClient);
							LOG.debug("Account Merge is successful on attempt no. " + (i + 1));
							isMergeRetrySuccess = true;
							// mergeInd = true;
							break;
						} catch (Exception ex) {
							LOG.error("Exception occured in C_B_ACCOUNT MergeRetryMechanism on attempt no. " + (i + 1));
							LOG.error("Exception occured in MergeRetryMechanism on C_B_ACCOUNT");
						}
					}
					if (!isMergeRetrySuccess) {
						ServiceProcessingException customException = new ServiceProcessingException(sifExcp);
						customException
								.setMessage("SIF exception occured while processing Merge request on C_B_ACCOUNT: "
										+ customException.getMessage());
						throw customException;
					}
				} // end try/catch

				// }//end for Iterator on AccountList

			}
			transaction.commit();

			// if newly created record got merged, set rowid_object of it to
			// that
			// of surviving target record
			if (mergeInd) {
				// String survivorRowidObject = null;
				/*
				 * for (HighestScoreRecordHolder hsrh :
				 * mergeSorceHolderMap.values()) { survivorRowidObject =
				 * hsrh.getPartyRowIDObject(); }
				 */
				LOG.info(
						"Setting rowid_object of new record to that of surviving target record " + survivorRowidObject);
				upsertPartyResponse.getParty().get(0).setROWIDOBJECT(survivorRowidObject.trim());
			}
		} catch (ServiceProcessingException excp) {
			LOG.error("Caught exception in ProcessMatchAndMerge operation.", excp);
			isError = true;
			upsertPartyResponse.setErrorMsg("ProcessMatchAndMerge operation failed for PartyID: "
					+ upsertPartyResponse.getParty().get(0).getSRCSYSTEMID());

			try {
				transaction.rollback();

			} catch (SystemException txExcp) {
				LOG.error("Failed to rollback transaction for ProcessMatchAndMerge operation : " + txExcp.toString());
			}
			throw excp;
		} catch (Exception ex) {
			LOG.error("Exception occured while ProcessMatchAndMerge operation requests: ", ex);
			isError = true;

			try {
				transaction.rollback();
			} catch (SystemException txExcp) {
				LOG.error("Failed to rollback transaction for ProcessMatchAndMerge operation: " + txExcp.toString());
				// txExcp.printStackTrace();
			}
			ServiceProcessingException customException = new ServiceProcessingException(ex);
			customException
					.setMessage("Failed to process ProcessMatchAndMerge operation. " + customException.getMessage());
			// customException.printStackTrace();
			throw customException;
		} finally {
			checkIn(siperianClient);
			if (isError) {
				tgtRowidObj = targetRowid;
			}
		}

		

		LOG.info("Executed mergeProcessParty() method.");
	}
	
	public void upsertP2CProcess(PartyXrefType ptyXrefType, MdmUpsertPartyResponse upsertPartyResponse,
			boolean excuteNextStep, boolean retry, String survivingPartyRowid) throws ServiceProcessingException{
		LOG.info("Executing upsertP2CProcess()");

		PerformanceLoggerUtil perfLog = new PerformanceLoggerUtil();
		// P2C_Eligible Checking
		List<String> adobeSrcPkeyList = new ArrayList<String>();
		try {
			XREFType xref = ptyXrefType.getXREF().get(0);
			survivingPartyRowid = getRowidFromPkey(xref, "C_B_PARTY");
			//survivingPartyRowid = upsertPartyResponse.getParty().get(0).getROWIDOBJECT();
			LOG.debug("Step-1,p2cEligible Rowid object" + survivingPartyRowid);
			if (!Util.isNullOrEmpty(survivingPartyRowid)) {
				adobeSrcPkeyList = checkP2CEligible(survivingPartyRowid.trim());
				// P2C conversion
				if ((adobeSrcPkeyList != null && adobeSrcPkeyList.size() > 0) || retry) {
					// soft delete Org Extn and Classification
					LOG.debug("p2cEligible Rowid object" + survivingPartyRowid);
					
					// fetch classification rowid objects
					List<String> clsfnSrcPkeyList = commonUtil.getRowidsByPartyRowId(survivingPartyRowid, MDMAttributeNames.CLASS_BO);
					deleteChildDAO.deleteChildBO(clsfnSrcPkeyList, MDMAttributeNames.CLASS_BO);
					
					List<String> orgExtnSrcPkeyList = commonUtil.getRowidsByPartyRowId(survivingPartyRowid,MDMAttributeNames.PARTY_ORG_BO);
					deleteChildDAO.deleteChildBO(orgExtnSrcPkeyList, MDMAttributeNames.PARTY_ORG_BO);
					
					//adobe changes start
					List<String> prospectSrcPkeyList = commonUtil.getRowidsByPartyRowId(survivingPartyRowid,MDMAttributeNames.PARTY_PROSPECT_BO);
					deleteChildDAO.deleteChildBO(prospectSrcPkeyList, MDMAttributeNames.PARTY_PROSPECT_BO);
					LOG.debug("Soft delete done for Classification, Org extn and prospect for P2C");
					//adobe changes end
					
					
					SiperianClient siperianClient = null;
					UserTransaction transaction = null;
					List<PutResponseDataHolder> cleansedAccountPkeyList = new ArrayList<PutResponseDataHolder>();
					List<PutResponseDataHolder> cleansedAddressPkeyList = new ArrayList<PutResponseDataHolder>();
					List<PutResponseDataHolder> cleansedCommPkeyList = new ArrayList<PutResponseDataHolder>();
					
					List<PutResponseDataHolder>	putRespDataAccountList= null;
					List<PutResponseDataHolder> putRespDataAddressList = null;
					List<PutResponseDataHolder> putRespDataCommList = null;
					PutResponseDataHolder putResponseDataParty = null;
					String rowIdAccount=null;
					String rowIdAddress=null;
					List<String> sorceRowidObjectADBList = new ArrayList<String>();
					
					PartyType prtyType=getPartyDAO.getBOParty(survivingPartyRowid, p2cEligible);
					
					try{
					
					siperianClient = (SiperianClient) checkOut();
					transaction = ((EjbSiperianClient) siperianClient).createTX(300000);
					transaction.begin();
					
					for(String srcPkey : adobeSrcPkeyList){
						PartyXrefType existingCustXref = commonUtil.preparePartyXref(prtyType,srcPkey);
						
						putResponseDataParty = cleansePutParty(existingCustXref, siperianClient);
						String sorceRowidObjectADB = putResponseDataParty.getRowidObject();
						sorceRowidObjectADBList.add(sorceRowidObjectADB);
						if (existingCustXref.getAccount() != null) {
							putRespDataAccountList = cleansePutAccount(existingCustXref.getAccount(), existingCustXref, siperianClient);
							for(PutResponseDataHolder accountRowIds : putRespDataAccountList){
							cleansedAccountPkeyList.add(accountRowIds);
							}
						} 	
						if (existingCustXref.getAddress() != null) {
							putRespDataAddressList = cleansePutAddress(existingCustXref.getAddress(), existingCustXref, siperianClient);
							for(PutResponseDataHolder addressRowIds : putRespDataAddressList){
							cleansedAddressPkeyList.add(addressRowIds);
							}
						}
						
						if (existingCustXref.getCommunication() != null) {
							putRespDataCommList = cleansePutCommunication(existingCustXref.getCommunication(), existingCustXref,siperianClient);
							for(PutResponseDataHolder commRowIds : putRespDataCommList){
								cleansedCommPkeyList.add(commRowIds);
							}
							
						}
					}
					transaction.commit();
					} catch (Exception ex) {
						LOG.error("Exception occured in P2C: ",ex);
						try {
							transaction.rollback();
						} catch (SystemException txExcp) {
							LOG.error("Failed to rollback transaction for P2C operation: ",txExcp);
						}
						cleansedAccountPkeyList = new ArrayList<PutResponseDataHolder>();
						cleansedAddressPkeyList = new ArrayList<PutResponseDataHolder>();
						cleansedCommPkeyList = new ArrayList<PutResponseDataHolder>();
						sorceRowidObjectADBList = new ArrayList<String>();
						throw ex;
					}
					finally {
						if (siperianClient != null) {
							checkIn(siperianClient);
						}
					}
					
						for (String rowId : sorceRowidObjectADBList) {
							processTokenizeRequest(rowId, "C_B_PARTY");
						}
						if(upsertPartyResponse.getParty()!=null && upsertPartyResponse.getParty().size()>0){
							upsertPartyResponse.getParty().get(0).setROWIDOBJECT(survivingPartyRowid.trim());	
						}else{
							PartyUpsertRespType party = new PartyUpsertRespType();
							party.setROWIDOBJECT(survivingPartyRowid.trim());
							upsertPartyResponse.getParty().add(0, party);
						}
						
						PutResponseDataHolder putRespDataParty = null;
						childMultiMergeParty(ptyXrefType, upsertPartyResponse, putRespDataParty, true);
				}
						
					LOG.debug("End of the P2C process");
				
			}
		}catch (ServiceProcessingException exp) {
			String respMsg ="Error in P2C process"; 
			LOG.error("Caught exception while Checking P2cEligible " + exp);
			if (Util.isNullOrEmpty(upsertPartyResponse.getStatus())) {
				upsertPartyResponse.setStatus(respMsg);
			} else {
				upsertPartyResponse.setStatus(upsertPartyResponse.getStatus() + "\n" + respMsg);
			}
			commonUtil.updateErrorStatus(ptyXrefType, upsertPartyResponse, Constant.ERROR_ACC_P2C_FAIL, survivingPartyRowid);
			throw exp;
		} catch (Exception ex) {
			LOG.error("Caught exception while Checking P2cEligible " + ex);
			String respMsg ="Error in P2C process"; 
			if (Util.isNullOrEmpty(upsertPartyResponse.getStatus())) {
				upsertPartyResponse.setStatus(respMsg);
			} else {
				upsertPartyResponse.setStatus(upsertPartyResponse.getStatus() + "\n" + respMsg);
			}
			commonUtil.updateErrorStatus(ptyXrefType, upsertPartyResponse, Constant.ERROR_ACC_P2C_FAIL, survivingPartyRowid);
			throw new ServiceProcessingException(Constant.ERROR_ACC_P2C_FAIL);
		}

		LOG.info("Executed upsertP2CProcess()");
		if (excuteNextStep){
			try {
				upsertUCNStampProcess(ptyXrefType, upsertPartyResponse, retry, excuteNextStep, survivingPartyRowid);
			} catch (ServiceProcessingException e) {
				e.printStackTrace();
			}
		}
	}
	
	private void updateCI(List<String> recordList, String baseObjTable, SiperianClient siperianClient){
		LOG.info("updateCI usinf siperianClient");
		for(String rowid : recordList){
		SetRecordStateRequest srsReq = new SetRecordStateRequest();              
		srsReq.addRecordKey(RecordKey.rowid(rowid));
		srsReq.setRecordState(RecordState.NEWLY_LOADED); //This sets the consolidation_ind to 4
		srsReq.setSiperianObjectUid(SiperianObjectType.BASE_OBJECT.makeUid(baseObjTable));
		SetRecordStateResponse srsResp = (SetRecordStateResponse) siperianClient.process(srsReq);
		}
		LOG.info("updateCI using siperianClient end");
	}
	
}
