package com.mcafee.mdm.dao;

import javax.transaction.SystemException;
import javax.transaction.UserTransaction;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.mcafee.mdm.constants.MDMAttributeNames;
import com.mcafee.mdm.exception.ServiceProcessingException;
import com.mcafee.mdm.util.ObjectPool;
import com.siperian.sif.client.EjbSiperianClient;
import com.siperian.sif.client.SiperianClient;
import com.siperian.sif.message.RecordKey;
import com.siperian.sif.message.SiperianObjectType;
import com.siperian.sif.message.XrefKey;
import com.siperian.sif.message.mrm.MergeRequest;
import com.siperian.sif.message.mrm.MergeResponse;
import com.siperian.sif.message.mrm.UnmergeRequest;
import com.siperian.sif.message.mrm.UnmergeResponse;

@Component
public class MergeProspectPartyDAO extends ObjectPool {
	private static final Logger LOG = Logger
			.getLogger(MergeProspectPartyDAO.class.getName());

	public MergeResponse mergeProspectParties(String boEntity, String srcRowId,
			String targetRowId) throws ServiceProcessingException {
		LOG.debug("[mergeProspectParties] ENTER");
		SiperianClient siperianClient = null;
		UserTransaction transaction = null;
		MergeResponse response = null;
		try {
			siperianClient = (SiperianClient) checkOut();
			transaction = ((EjbSiperianClient) siperianClient).createTX(300000);
			transaction.begin();
			MergeRequest request = new MergeRequest();
			request.setSiperianObjectUid(SiperianObjectType.BASE_OBJECT
					.makeUid(boEntity));
			request.setSourceRecordKey(RecordKey.rowid(srcRowId));
			request.setTargetRecordKey(RecordKey.rowid(targetRowId));
			LOG.debug(" Before executing Merge process ");
			response = (MergeResponse) siperianClient.process(request);
			transaction.commit();
			LOG.debug(" After executing Merge process. Message from MergeResponse: "
					+ response.getMessage());
			LOG.debug("[mergeProspectParties] EXIT");
		} catch (Exception ex) {
			LOG.error(
					"Exception occured while ProcessMatchAndMerge operation requests: ",
					ex);
			try {
				transaction.rollback();
			} catch (SystemException txExcp) {
				LOG.error(
						"Failed to rollback transaction for ProcessMatchAndMerge operation: ",
						txExcp);
			}
			if (ex instanceof ServiceProcessingException) {
				throw (ServiceProcessingException) ex;
			} else {
				ServiceProcessingException customException = new ServiceProcessingException(
						ex);
				customException
						.setMessage("Failed to process ProcessMatchAndMerge operation. "
								+ customException.getMessage());
				throw customException;
			}
		} finally {
			checkIn(siperianClient);
		}
		return response;
	}

	public UnmergeResponse unMergeProspectParties(String srcPkey,
			String srcSystem) throws ServiceProcessingException {
		LOG.debug("[unMergeProspectParties] ENTER");
		SiperianClient siperianClient = null;
		UserTransaction transaction = null;
		UnmergeResponse response = null;
		try {
			siperianClient = (SiperianClient) checkOut();
			transaction = ((EjbSiperianClient) siperianClient).createTX(300000);
			transaction.begin();
			UnmergeRequest request = new UnmergeRequest();
			request.setSiperianObjectUid(SiperianObjectType.BASE_OBJECT
					.makeUid(MDMAttributeNames.PARTY_BO));
			XrefKey xrefKey = new XrefKey();
			xrefKey.setSourceKey(srcPkey);
			xrefKey.setSystemName(srcSystem);
			request.setXrefKey(xrefKey);
			request.setTreeUnmerge(Boolean.FALSE);
			LOG.debug("[unMergeProspectParties]Before executing Merge process ");
			response = (UnmergeResponse) siperianClient.process(request);
			transaction.commit();
			LOG.debug(" After executing Merge process. Message from MergeResponse: "
					+ response.getMessage()
					+ "::ROWID Obj::"
					+ response.getRecordKey().getRowid()
					+ "::PKEY::"
					+ response.getRecordKey().getSourceKey());
		} catch (Exception ex) {
			LOG.error(
					"Exception occured while Process UnMerge operation requests: ",
					ex);
			try {
				transaction.rollback();
			} catch (SystemException txExcp) {
				LOG.error(
						"Failed to rollback transaction for Process UnMerge operation: ",
						txExcp);
			}
			if (ex instanceof ServiceProcessingException) {
				throw (ServiceProcessingException) ex;
			} else {
				ServiceProcessingException customException = new ServiceProcessingException(
						ex);
				customException
						.setMessage("Failed to process Process UnMerge operation. "
								+ customException.getMessage());
				throw customException;
			}
		} finally {
			checkIn(siperianClient);
		}
		LOG.debug("[unMergeProspectParties] EXIT");
		return response;
	}
}
