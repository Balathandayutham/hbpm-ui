package com.mcafee.mdm.dao;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.SystemException;
import javax.transaction.UserTransaction;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.mcafee.mdm.constants.MDMAttributeNames;
import com.mcafee.mdm.exception.ServiceProcessingException;
import com.mcafee.mdm.util.ObjectPool;
import com.siperian.sif.client.EjbSiperianClient;
import com.siperian.sif.client.SiperianClient;
import com.siperian.sif.message.RecordKey;
import com.siperian.sif.message.SiperianObjectType;
import com.siperian.sif.message.mrm.DeleteRequest;
import com.siperian.sif.message.mrm.DeleteResponse;

@Component
public class DeleteProspectPartyDAO extends ObjectPool {
	private static final Logger LOG = Logger
			.getLogger(DeleteProspectPartyDAO.class.getName());

	public DeleteResponse deleteContactRel(List<String> contactRelRowIdList)
			throws ServiceProcessingException {
		LOG.debug("[deleteContactRel] ENTER");
		SiperianClient siperianClient = null;
		UserTransaction transaction = null;
		DeleteResponse response = null;
		try {
			siperianClient = (SiperianClient) checkOut();
			transaction = ((EjbSiperianClient) siperianClient).createTX(300000);
			transaction.begin();
			DeleteRequest request = new DeleteRequest();
			request.setSiperianObjectUid(SiperianObjectType.BASE_OBJECT.makeUid(MDMAttributeNames.PARTY_REL_BO));
			List<RecordKey> keyList = new ArrayList<RecordKey>();
			for (String contactRelRowId : contactRelRowIdList) {
				RecordKey recordKey = new RecordKey();
				recordKey.setRowid(contactRelRowId);
				keyList.add(recordKey);
			}
			request.setRecordKeys(keyList);
			LOG.debug("[deleteContactRel]Before executing Delete process ");
			response = (DeleteResponse) siperianClient.process(request);
			transaction.commit();
			LOG.debug("[deleteContactRel]Delete Completed::Message::"
					+ response.getMessage());
		} catch (Exception ex) {
			LOG.error(
					"Exception occured while DeleteContactRel operation requests: ",
					ex);
			try {
				transaction.rollback();
			} catch (SystemException txExcp) {
				LOG.error(
						"Failed to rollback transaction for DeleteContactRel operation: ",
						txExcp);
			}
			if (ex instanceof ServiceProcessingException) {
				throw (ServiceProcessingException) ex;
			} else {
				ServiceProcessingException customException = new ServiceProcessingException(
						ex);
				customException
						.setMessage("Failed to process DeleteContactRel operation. "
								+ customException.getMessage());
				throw customException;
			}
		} finally {
			if (siperianClient != null) {
				checkIn(siperianClient);
			}
		}
		LOG.debug("[deleteContactRel] EXIT");
		return response;
	}
}